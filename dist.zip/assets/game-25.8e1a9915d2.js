/* ===== js/scene.js ===== */
/* Một Đời — tranh pixel: chân dung nhân vật & khung cảnh gia đình (SVG thuần, không cần ảnh ngoài). */
(function (G) {
  'use strict';
  var E = G.E;

  function hash(n) { n = (n ^ 61) ^ (n >>> 16); n = n + (n << 3); n = n ^ (n >>> 4); n = Math.imul(n, 0x27d4eb2d); n = n ^ (n >>> 15); return (n >>> 0) / 4294967296; }
  function R(l, k) { return hash(((l.rs | 0) + k * 7919) | 0); }
  function rect(o, x, y, w, h, c, op) { o.push('<rect x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" fill="' + c + '"' + (op != null ? ' opacity="' + op + '"' : '') + '/>'); }
  function svg(w, h, body, cls) { return '<svg class="' + (cls || '') + '" viewBox="0 0 ' + w + ' ' + h + '" xmlns="http://www.w3.org/2000/svg" shape-rendering="crispEdges" preserveAspectRatio="xMidYMid meet">' + body.join('') + '</svg>'; }

  var AFRICA = /^(afr|afw|afe|afs|et|so|ss|ao|ht|car)$/, BROWN = /^(in|pk|bd|lk|np|ar|fa|af|tr|es_la|br|ph|id|my|th|kh|la|mm|mg|pac|az|ca|tj|he|hy|ka|sq)$/, EASTASIA = /^(vn|cn|kr|kp|jp|sg|mn)$/;
  function skinOf(l, k) {
    var p = l.pool || 'vn', t = R(l, 11 + (k || 0));
    if (AFRICA.test(p)) return ['#6b3f26', '#7a4a2e', '#8d5a3b'][Math.floor(t * 3)];
    if (BROWN.test(p)) return ['#b97e52', '#c48a5c', '#a86f45'][Math.floor(t * 3)];
    if (EASTASIA.test(p)) return ['#efc4a0', '#e8b98f', '#f3cfae'][Math.floor(t * 3)];
    return ['#f2d0b5', '#ecc3a4', '#f6dac4'][Math.floor(t * 3)];
  }
  function hairOf(l, age, k) {
    if (age >= 75) return '#e8e8e8';
    if (age >= 58) return '#b5b5b5';
    var p = l.pool || 'vn', t = R(l, 21 + (k || 0));
    if (EASTASIA.test(p) || AFRICA.test(p) || BROWN.test(p)) return t < 0.85 ? '#1d1612' : '#4a2f1f';
    return ['#2a1d14', '#5a3a22', '#8a5a2e', '#d8b25e', '#b5552a'][Math.floor(t * 5)];
  }
  function stageOf(a) { return a < 2 ? 'baby' : a < 12 ? 'child' : a < 18 ? 'teen' : a < 60 ? 'adult' : 'elder'; }
  function outfit(l, a) {
    var c = l.job ? E.jobDef(l) : null, cat = c ? c.cat : '';
    if (l.jailUntil != null && l.age < l.jailUntil) return { body: '#3d4f6a', stripe: '#c9a227', hat: null };
    if (a < 18 && l.school && G.E.isVN(l)) return { body: '#f4f4f0', pants: '#24407a', scarf: a <= 14 ? '#d12f2f' : null };
    if (c && c.id === 'cong_an') return { body: '#2f4f86', hat: 'police', hatC: '#24406e' };
    if (c && c.id === 'quan_doi') return { body: '#4d6a34', hat: 'army', hatC: '#3d5728' };
    if (cat === 'med') return { body: '#f3f6f8', steth: true };
    if (cat === 'farm' && G.E.isVN(l)) return { body: '#6f5a3c', hat: 'non' };
    if (cat === 'office' || cat === 'sale') return { body: '#2f3e5c', tie: '#b23b3b' };
    if (cat === 'crime') return { body: '#1e1e22', chain: true };
    if (cat === 'show' || cat === 'creator') return { body: ['#b0397f', '#3b7fd1', '#e0a422'][Math.floor(R(l, 31) * 3)], star: true };
    if (cat === 'sport') return { body: '#d23a3a', num: true };
    if (cat === 'worker' || cat === 'poor') return { body: '#c7782f' };
    if (a >= 60) return { body: G.E.isVN(l) && l.sex === 'F' ? '#6b4f7a' : '#7d6a55', hat: G.E.isVN(l) && !l.urban && R(l, 41) < 0.5 ? 'non' : null };
    return { body: ['#3d7a6a', '#7a3d5c', '#3d5a8a', '#8a6d3d', '#5a3d8a'][Math.floor(R(l, 33) * 5)] };
  }

  // ---------- chân dung 16×16 ----------
  function avatar(l) {
    var a = l.alive ? l.age : l.death.age, st = stageOf(a), F = l.sex === 'F';
    var skin = skinOf(l), hair = hairOf(l, a), o = [], fit = outfit(l, a);
    var hap = l.st ? l.st.hap : 60;
    rect(o, 0, 0, 16, 16, '#17283a');
    rect(o, 0, 11, 16, 5, '#1d3247');
    if (st === 'baby') {
      rect(o, 3, 11, 10, 5, '#f6e7c8'); rect(o, 4, 10, 8, 1, '#f6e7c8');
      rect(o, 4, 4, 8, 7, skin); rect(o, 5, 3, 6, 1, skin); rect(o, 5, 11, 6, 0.01, skin);
      rect(o, 7, 2, 2, 2, hair);
      rect(o, 6, 7, 1, 1, '#1b1b1b'); rect(o, 9, 7, 1, 1, '#1b1b1b');
      rect(o, 5, 8, 1, 1, '#f2a0a0', 0.8); rect(o, 10, 8, 1, 1, '#f2a0a0', 0.8);
      rect(o, 7, 9, 2, 1, '#c0605a');
      return svg(16, 16, o, 'px avatar');
    }
    var small = st === 'child';
    var hx = small ? 5 : 4, hw = small ? 6 : 8, hy = small ? 5 : 3, hh = small ? 6 : 8;
    // tóc dài phía sau (nữ)
    if (F && st !== 'elder') rect(o, hx - 1, hy, hw + 2, hh + (small ? 3 : 5), hair);
    if (F && st === 'elder') rect(o, hx + 1, hy - 2, hw - 2, 2, hair); // búi tóc
    // thân
    var bx = small ? 4 : 3, bw = small ? 8 : 10, by = hy + hh + 1;
    rect(o, bx, by, bw, 16 - by, fit.body);
    rect(o, bx + 1, by - 1, bw - 2, 1, fit.body);
    if (fit.stripe) { for (var sy = by + 1; sy < 16; sy += 2) rect(o, bx, sy, bw, 1, fit.stripe, 0.7); }
    if (fit.scarf) { rect(o, 6.5, by - 1, 3, 1, fit.scarf); rect(o, 7, by, 2, 2, fit.scarf); }
    if (fit.tie) { rect(o, 7.5, by, 1, 3, fit.tie); rect(o, 6, by, 1, 1, '#e8e8e8'); rect(o, 9, by, 1, 1, '#e8e8e8'); }
    if (fit.steth) { rect(o, 5, by + 1, 1, 2, '#555'); rect(o, 10, by + 1, 1, 2, '#555'); rect(o, 6, by + 3, 4, 1, '#555'); }
    if (fit.chain) rect(o, 6, by + 1, 4, 1, '#d4af37');
    if (fit.star) rect(o, 10, by + 2, 1, 1, '#ffe27a');
    if (fit.num) { rect(o, 7, by + 1, 2, 2, '#fff'); }
    // cổ & đầu
    rect(o, 7, by - 1, 2, 1, skin);
    rect(o, hx + 1, hy, hw - 2, 1, skin); rect(o, hx, hy + 1, hw, hh - 1, skin); rect(o, hx + 1, hy + hh, hw - 2, 1, skin);
    // tóc trên
    rect(o, hx, hy - 1, hw, 2, hair); rect(o, hx - (F ? 1 : 0), hy, 1, F ? 6 : 3, hair); rect(o, hx + hw - (F ? 0 : 1), hy, 1, F ? 6 : 3, hair);
    if (!F) rect(o, hx + 1, hy + 1, 3, 1, hair);
    else rect(o, hx + 1, hy + 1, hw - 2, 1, hair);
    if (st === 'adult' && !F && a >= 35 && R(l, 51) < 0.4) rect(o, hx + 2, hy + hh - 1, hw - 4, 1, hair, 0.55); // râu
    // mặt
    var ey = hy + (small ? 3 : 4);
    rect(o, hx + (small ? 1 : 2), ey, 1, 1, '#1b1b1b'); rect(o, hx + hw - (small ? 2 : 3), ey, 1, 1, '#1b1b1b');
    if (st === 'elder') { rect(o, hx + 1, ey, 3, 1, '#9aa7b0', 0.55); rect(o, hx + hw - 4, ey, 3, 1, '#9aa7b0', 0.55); }
    if (small || st === 'teen') { rect(o, hx + 1, ey + 2, 1, 1, '#f2a0a0', 0.7); rect(o, hx + hw - 2, ey + 2, 1, 1, '#f2a0a0', 0.7); }
    var my = ey + (small ? 2 : 3), mx = hx + hw / 2 - 1;
    if (hap >= 55) { rect(o, mx, my, 2, 1, '#9c3d3a'); rect(o, mx - 1, my - 1, 1, 1, '#9c3d3a'); rect(o, mx + 2, my - 1, 1, 1, '#9c3d3a'); }
    else if (hap >= 35) rect(o, mx, my, 2, 1, '#9c3d3a');
    else { rect(o, mx, my - 1, 2, 1, '#9c3d3a'); rect(o, mx - 1, my, 1, 1, '#9c3d3a'); rect(o, mx + 2, my, 1, 1, '#9c3d3a'); }
    // mũ
    if (fit.hat === 'non') { rect(o, 7, 0, 2, 1, '#e8d39a'); rect(o, 5, 1, 6, 1, '#e8d39a'); rect(o, 3, 2, 10, 1, '#dcc584'); rect(o, 2, 3, 12, 1, '#c9b06c'); }
    if (fit.hat === 'police' || fit.hat === 'army') { rect(o, hx - 1, hy - 2, hw + 2, 2, fit.hatC); rect(o, hx - 1, hy, hw + 2, 1, '#14213a'); rect(o, 7, hy - 2, 2, 1, '#e0b84a'); }
    if (!l.alive) rect(o, 0, 0, 16, 16, '#000', 0.35);
    return svg(16, 16, o, 'px avatar');
  }

  // ---------- người tí hon trong khung cảnh ----------
  function figure(o, x, gy, p) {
    var h = p.st === 'baby' ? 4 : p.st === 'child' ? 7 : p.st === 'teen' ? 9 : 10;
    var top = gy - h;
    if (p.st === 'baby') { rect(o, x + 1, top, 3, 2, p.skin); rect(o, x, top + 2, 5, 2, '#f6e7c8'); return; }
    var head = p.st === 'child' ? 2 : 3, body = p.st === 'child' ? 3 : 4;
    rect(o, x + 1, top, 3, 1, p.hair);
    rect(o, x + 1, top + 1, 3, head - 1 + 1, p.skin);
    if (p.F) { rect(o, x, top, 1, head + 1, p.hair); rect(o, x + 4, top, 1, head + 1, p.hair); }
    rect(o, x, top + head + 1, 5, body, p.cloth);
    rect(o, x + 1, gy - (h - head - 1 - body), 1, h - head - 1 - body, p.legs || '#2b2b33');
    rect(o, x + 3, gy - (h - head - 1 - body), 1, h - head - 1 - body, p.legs || '#2b2b33');
    if (p.cane) rect(o, x + 5, top + head + 2, 1, h - head - 2, '#7a5a3a');
    if (p.hat === 'non') { rect(o, x + 2, top - 2, 1, 1, '#e8d39a'); rect(o, x, top - 1, 5, 1, '#dcc584'); }
    if (p.me) { rect(o, x, top - 6, 5, 1, '#ffd166'); rect(o, x + 1, top - 5, 3, 1, '#ffd166'); rect(o, x + 2, top - 4, 1, 1, '#ffd166'); }
  }
  function person(l, age, sex, k, cloth, me) {
    return { st: stageOf(age), F: sex === 'F', skin: skinOf(l, k), hair: hairOf(l, age, k), cloth: cloth, me: me, cane: age >= 75, hat: G.E.isVN(l) && !l.urban && age >= 25 && R(l, 61 + k) < 0.35 ? 'non' : null };
  }

  function houseKind(l) {
    if (l.jailUntil != null && l.age < l.jailUntil) return 'prison';
    if (l.abroad && l.abroad.trapped) return 'compound';
    var q = l.fam.q, a = l.age;
    if (l.indep && a >= 20) {
      if (l.ownHouse) return l.urban ? (q >= 4 || (l.houseVal > l.base * 40) ? 'villa' : 'ong') : 'tile';
      return l.urban ? 'tro' : 'tile';
    }
    var t = l.houseType || '';
    if (/sàn/.test(t)) return 'san'; if (/trình/.test(t)) return 'trinh'; if (/dài/.test(t)) return 'dai';
    if (/chung cư/.test(t)) return 'cc'; if (/ống|hẻm/.test(t)) return 'ong';
    if (l.fam.home === 'nhà tạm') return 'tam';
    if (q >= 5) return 'villa';
    if (!G.E.isVN(l)) return l.urban ? (q >= 4 ? 'cc' : 'ong') : (q <= 2 ? 'tam' : 'tile');
    return l.urban ? 'ong' : 'tile';
  }
  var HOUSE_NAME = { tile: 'nhà mái ngói', ong: 'nhà ống', cc: 'căn hộ chung cư', villa: 'biệt thự', san: 'nhà sàn', trinh: 'nhà trình tường', tam: 'nhà tạm', dai: 'nhà dài', tro: 'phòng trọ', prison: 'trại giam', compound: 'khu nhà rào kẽm gai' };

  function drawHouse(o, kind, night, l) {
    var win = night ? '#ffd66b' : '#9fc4d8', gy = 40;
    function w(x, y, ww, hh) { rect(o, x, y, ww || 3, hh || 3, win); }
    function roof(x0, x1, y0, rows, c) { for (var i = 0; i < rows; i++) rect(o, x0 + (rows - i), y0 + i, (x1 - x0) - 2 * (rows - i), 1, c); }
    if (kind === 'tile') { rect(o, 10, 29, 26, 11, '#d9c7a3'); roof(8, 38, 22, 7, '#a33b2b'); rect(o, 21, 33, 4, 7, '#6b4226'); w(13, 32); w(30, 32); }
    else if (kind === 'ong') { var c = ['#c99bd6', '#9cc7a8', '#e2b07a', '#9bb7e0'][Math.floor(R(l, 71) * 4)]; rect(o, 14, 12, 16, 28, c); for (var f = 0; f < 3; f++) { w(17, 15 + f * 8, 4, 3); w(23, 15 + f * 8, 4, 3); rect(o, 14, 20 + f * 8, 16, 1, '#00000033'); } rect(o, 20, 34, 4, 6, '#5a3a24'); rect(o, 13, 11, 18, 1, '#555'); }
    else if (kind === 'cc') { rect(o, 6, 6, 34, 34, '#7d8a99'); for (var yy = 9; yy < 36; yy += 5) for (var xx = 9; xx < 38; xx += 5) rect(o, xx, yy, 3, 3, R(l, xx * yy) < 0.6 ? win : '#3a4655'); rect(o, 20, 35, 6, 5, '#2e3742'); }
    else if (kind === 'villa') { rect(o, 4, 26, 40, 14, '#f1ede4'); roof(2, 46, 19, 7, '#b33a2b'); w(8, 30, 5, 4); w(16, 30, 5, 4); w(32, 30, 5, 4); rect(o, 23, 31, 5, 9, '#6b4226'); rect(o, 0, 37, 48, 3, '#3f7a3a'); rect(o, 2, 33, 2, 4, '#2f6a2a'); rect(o, 44, 33, 2, 4, '#2f6a2a'); }
    else if (kind === 'san') { rect(o, 8, 28, 30, 2, '#6b4426'); for (var px = 9; px < 38; px += 6) rect(o, px, 30, 1, 10, '#5a3a20'); rect(o, 10, 21, 26, 7, '#8a5a34'); roof(6, 40, 13, 8, '#b89a5a'); w(14, 23, 3, 3); w(29, 23, 3, 3); rect(o, 20, 30, 1, 10, '#8a6a3a'); rect(o, 21, 31, 3, 1, '#8a6a3a'); rect(o, 21, 34, 3, 1, '#8a6a3a'); rect(o, 21, 37, 3, 1, '#8a6a3a'); }
    else if (kind === 'trinh') { rect(o, 10, 26, 26, 14, '#c49a5c'); roof(8, 38, 18, 8, '#6b5a3a'); rect(o, 21, 32, 4, 8, '#4a3220'); w(13, 30); }
    else if (kind === 'tam') { rect(o, 12, 30, 22, 10, '#7f95a3'); rect(o, 10, 28, 26, 2, '#9aa9b2'); rect(o, 16, 33, 3, 7, '#4a3a2a'); rect(o, 26, 32, 3, 3, win); rect(o, 22, 29, 6, 1, '#a8642f'); }
    else if (kind === 'dai') { rect(o, 3, 27, 42, 2, '#6b4426'); for (var dx = 4; dx < 45; dx += 5) rect(o, dx, 29, 1, 11, '#5a3a20'); rect(o, 4, 21, 40, 6, '#8a5a34'); roof(1, 47, 14, 7, '#a88a4a'); }
    else if (kind === 'tro') { rect(o, 4, 27, 40, 13, '#c7b8a0'); rect(o, 3, 25, 42, 2, '#8b8b8b'); for (var t = 0; t < 3; t++) { rect(o, 8 + t * 13, 32, 4, 8, '#5a6a7a'); w(13 + t * 13, 30, 3, 3); } rect(o, 16, 26, 16, 2, '#d12f2f'); }
    else if (kind === 'prison') { rect(o, 0, 12, 120, 28, '#596470'); for (var b = 4; b < 120; b += 5) rect(o, b, 14, 1, 24, '#2b3138'); rect(o, 0, 12, 120, 2, '#3a424b'); }
    else if (kind === 'compound') { rect(o, 2, 16, 44, 24, '#6c6f74'); for (var c2 = 4; c2 < 46; c2 += 4) rect(o, c2, 14, 1, 2, '#9aa0a6'); rect(o, 2, 14, 44, 1, '#9aa0a6'); for (var r2 = 6; r2 < 44; r2 += 6) rect(o, r2, 22, 3, 3, win); }
  }

  function companions(l) {
    var a = l.age, f = l.fam, list = [], k = 0;
    var dad = { sex: 'M', age: f.fAge + a }, mom = { sex: 'F', age: f.mAge + a };
    var withParents = !l.indep || a < 20 || l.flags.caring;
    var meCloth = outfit(l, a).body;
    if (withParents) {
      if (f.fAlive && !f.noDad) list.push(person(l, dad.age, 'M', ++k, '#3d5a8a'));
      if (f.mAlive) list.push(person(l, mom.age, 'F', ++k, G.E.isVN(l) ? '#b44a5a' : '#8a3d6a'));
    }
    if (!l.indep || a < 18) for (var s = 0; s < Math.min(3, f.sibs); s++) list.push(person(l, a + 2 + s * 2, R(l, 81 + s) < 0.5 ? 'M' : 'F', ++k, ['#5a8a3d', '#d18a2f', '#3d8a8a'][s]));
    var me = person(l, a, l.sex, 0, meCloth, true); me.skin = skinOf(l); me.hair = hairOf(l, a);
    list.push(me);
    if (l.partner && l.partner.status !== 'dating') list.push(person(l, l.partner.age, l.partner.sex, ++k, '#7a5ac0'));
    l.kids.filter(function (c) { return c.alive && a - c.born < 25; }).slice(0, 4).forEach(function (c, i) { list.push(person(l, Math.max(0, a - c.born), c.sex, ++k, ['#e07a5f', '#3d8a6a', '#e0b84a', '#6a7ae0'][i])); });
    return list.slice(0, 9);
  }

  // ---------- khung cảnh 120×48 ----------
  function scene(l) {
    var o = [], W = 120, H = 48, gy = 40;
    var hap = l.st ? l.st.hap : 60, alive = l.alive;
    var time = !alive ? 'night' : hap >= 62 ? 'day' : hap >= 40 ? 'dusk' : 'night';
    var sky = { day: ['#7fc4e8', '#a9dbf2', '#d4eefa'], dusk: ['#3c3b6e', '#c46a5a', '#f2b27a'], night: ['#0d1630', '#16244a', '#24365e'] }[time];
    rect(o, 0, 0, W, 14, sky[0]); rect(o, 0, 14, W, 12, sky[1]); rect(o, 0, 26, W, 14, sky[2]);
    if (time === 'night') { for (var s = 0; s < 22; s++) rect(o, Math.floor(R(l, 100 + s) * W), Math.floor(R(l, 200 + s) * 24), 1, 1, '#fff', 0.5 + R(l, 300 + s) * 0.5); rect(o, 92, 5, 6, 6, '#f4f1d8'); rect(o, 91, 6, 1, 4, '#f4f1d8'); rect(o, 98, 6, 1, 4, '#f4f1d8'); rect(o, 95, 6, 2, 2, '#dcd8b8'); }
    else if (time === 'day') { rect(o, 94, 5, 8, 8, '#ffe27a'); rect(o, 93, 6, 10, 6, '#ffe27a'); rect(o, 92, 4, 12, 10, '#fff3b0', 0.25); }
    else { rect(o, 90, 22, 12, 6, '#ffb36b'); rect(o, 88, 24, 16, 4, '#ff9a5a', 0.6); }
    // mây
    for (var c = 0; c < 3; c++) { var cx = Math.floor(R(l, 400 + c) * 100), cy = 4 + Math.floor(R(l, 500 + c) * 10); var cc = time === 'night' ? '#2c3a5c' : time === 'dusk' ? '#e6a08a' : '#ffffff'; rect(o, cx, cy, 12, 3, cc, 0.85); rect(o, cx + 3, cy - 2, 6, 2, cc, 0.85); }
    // phông nền
    var reg = l.region || '', urban = l.urban || (l.abroad && l.abroad.perm), kind = houseKind(l);
    if (kind !== 'prison') {
      if (urban) { for (var b = 0; b < 12; b++) { var bh = 8 + Math.floor(R(l, 600 + b) * 22), bx = b * 10; rect(o, bx, gy - bh, 9, bh, time === 'night' ? '#1c2740' : '#7a8aa3', 0.85); if (time !== 'day') for (var wy = gy - bh + 2; wy < gy - 2; wy += 4) if (R(l, bx * wy) < 0.5) rect(o, bx + 2 + Math.floor(R(l, wy) * 4), wy, 1, 1, '#ffd66b'); } }
      else if (reg === 'MNPB' || reg === 'TN' || /af|np|bt|ka|hy|kp/.test(l.pool || '')) { var mc = time === 'night' ? '#1e2f3a' : '#5d7f6a'; for (var m = 0; m < 3; m++) { var mx = m * 45 - 10; for (var i = 0; i < 16; i++) rect(o, mx + i, gy - 4 - i, 40 - 2 * i, 1, mc); } }
      else if (l.coast) { rect(o, 0, gy - 6, W, 6, time === 'night' ? '#14304a' : '#3f8fc2'); for (var wv = 0; wv < W; wv += 7) rect(o, wv, gy - 5 + (wv % 3), 3, 1, '#e8f6ff', 0.6); }
    }
    // mặt đất
    var ground = urban ? (time === 'night' ? '#2c3138' : '#7b7f86') : (time === 'night' ? '#1f3a24' : '#5b8a3c');
    rect(o, 0, gy, W, H - gy, ground);
    if (!urban) { for (var rw = 0; rw < W; rw += 4) rect(o, rw, gy + 2 + (rw % 8 ? 0 : 2), 2, 1, time === 'night' ? '#2c5233' : '#7fb35a'); if (reg === 'DBSCL') rect(o, 0, gy + 4, W, 3, time === 'night' ? '#1d3f5a' : '#4f9fd1'); }
    else { rect(o, 0, gy + 3, W, 1, '#e8e8e8', 0.4); for (var lm = 6; lm < W; lm += 30) { rect(o, lm, gy - 14, 1, 14, '#444'); rect(o, lm - 1, gy - 15, 3, 1, time === 'day' ? '#bbb' : '#ffd66b'); } }
    // cây
    if (!urban && kind !== 'prison') { [52, 110].forEach(function (tx, i) { rect(o, tx + 2, gy - 6, 2, 6, '#6b4426'); rect(o, tx - 1, gy - 13, 8, 7, time === 'night' ? '#1f4a2a' : '#3f7a3a'); rect(o, tx + 1, gy - 15, 4, 2, time === 'night' ? '#1f4a2a' : '#3f7a3a'); if (G.E.isVN(l) && i === 1 && R(l, 700) < 0.6) { rect(o, tx + 2, gy - 22, 1, 9, '#7a6a3a'); rect(o, tx - 1, gy - 23, 7, 2, '#3f7a3a'); } }); }
    // nhà
    if (alive) drawHouse(o, kind, time === 'night', l);
    else { rect(o, 26, gy - 12, 10, 12, '#8a8f96'); rect(o, 27, gy - 13, 8, 1, '#8a8f96'); rect(o, 29, gy - 9, 4, 1, '#5a5f66'); rect(o, 30, gy - 11, 2, 5, '#5a5f66'); rect(o, 38, gy - 6, 1, 6, '#c96a3a'); rect(o, 38, gy - 8, 1, 2, '#ffd66b'); rect(o, 22, gy - 3, 3, 3, '#e05a7a'); }
    // người
    if (alive && kind !== 'prison') {
      var people = companions(l), x0 = kind === 'villa' || kind === 'dai' || kind === 'tro' ? 52 : 50;
      people.forEach(function (p, i) { figure(o, x0 + i * 7, gy, p); });
      var px2 = x0 + people.length * 7 + 1;
      E.H.pets(l).slice(0, 2).forEach(function (pt) { drawPet(o, pt, px2, gy); px2 += pt.k === 'chim' ? 7 : 6; });
    } else if (alive && kind === 'prison') { var me = person(l, l.age, l.sex, 0, '#3d4f6a', true); figure(o, 58, gy, me); }
    if (time === 'night' && hap < 30 && alive) for (var rn = 0; rn < 40; rn++) rect(o, Math.floor(R(l, 800 + rn + l.age) * W), Math.floor(R(l, 900 + rn + l.age) * 38), 1, 2, '#9fb6d6', 0.6);
    return svg(W, H, o, 'px scene');
  }

  // thú cưng pixel theo loài
  var PET_COL = { 'Corgi': '#e0a050', 'Husky': '#9aa6b2', 'Alaska': '#c8c8c8', 'Poodle': '#a0522d', 'Golden': '#e3b25a', 'Phốc sóc': '#f0a040', 'chó Phú Quốc': '#5a4030', 'mèo mướp': '#c9a36a', 'mèo Anh lông ngắn': '#8d99a6', 'mèo Ba Tư': '#f2efe8', 'mèo Xiêm': '#e8dcc4' };
  function drawPet(o, pt, x, gy) {
    var k = pt.k, c = PET_COL[pt.br] || (/Mực/.test(pt.n) ? '#333' : k === 'chó' ? '#c79a5a' : '#8a8a8a');
    if (k === 'chó') { rect(o, x, gy - 3, 4, 2, c); rect(o, x + 3, gy - 4, 2, 2, c); rect(o, x, gy - 1, 1, 1, c); rect(o, x + 3, gy - 1, 1, 1, c); rect(o, x - 1, gy - 4, 1, 1, c); }
    else if (k === 'mèo') { rect(o, x, gy - 3, 4, 2, c); rect(o, x + 3, gy - 4, 2, 2, c); rect(o, x + 3, gy - 5, 1, 1, c); rect(o, x + 4, gy - 5, 1, 1, c); rect(o, x, gy - 1, 1, 1, c); rect(o, x + 3, gy - 1, 1, 1, c); rect(o, x - 1, gy - 5, 1, 3, c); }
    else if (k === 'cá cảnh') { rect(o, x, gy - 4, 4, 4, '#9fd3ef', 0.75); rect(o, x + 1, gy - 3, 2, 1, pt.br === 'cá rồng' ? '#d33' : '#f08a24'); }
    else if (k === 'chim') { rect(o, x, gy - 8, 5, 1, '#b08a3a'); rect(o, x, gy - 7, 1, 7, '#b08a3a'); rect(o, x + 2, gy - 7, 1, 7, '#b08a3a', 0.6); rect(o, x + 4, gy - 7, 1, 7, '#b08a3a'); rect(o, x + 1, gy - 4, 2, 2, pt.br === 'vẹt' ? '#3fae4a' : '#e8c13a'); rect(o, x, gy - 1, 5, 1, '#b08a3a'); }
    else if (k === 'thỏ') { rect(o, x, gy - 3, 3, 3, '#eeeeee'); rect(o, x + 2, gy - 6, 1, 3, '#eeeeee'); }
    else if (k === 'rùa') { rect(o, x, gy - 2, 4, 2, '#4f7a3a'); rect(o, x + 4, gy - 2, 1, 1, '#8aa060'); }
    else rect(o, x, gy - 2, 3, 2, '#d9a066');
  }
  function caption(l) {
    var kind = houseKind(l), f = l.fam, a = l.age;
    if (!l.alive) return 'Nơi an nghỉ của ' + l.name;
    if (kind === 'prison') return 'Trại giam · còn ' + (l.jailUntil - a) + ' năm';
    if (kind === 'compound') return 'Một trại lừa đảo ở Campuchia';
    var where = l.abroad ? (l.abroad.perm ? l.place + ', ' + l.abroad.name : l.abroad.name) : l.cityStudent ? l.cityStudent.city : l.movedTo || (l.urban ? l.place : U2(l.place));
    var who = [];
    if (!l.indep || a < 20) { if (f.fAlive || f.mAlive) who.push(f.fAlive && f.mAlive ? 'bố mẹ' : f.mAlive ? 'mẹ' : 'bố'); if (f.sibs) who.push(f.sibs + ' anh chị'); }
    else { if (l.partner && l.partner.status !== 'dating') who.push(E.H.partnerWord(l, l.partner)); var k = l.kids.filter(function (c) { return c.alive && a - c.born < 25; }).length; if (k) who.push(k + ' con'); if (l.flags.caring) who.push(f.mAlive ? 'mẹ già' : 'bố già'); }
    E.H.pets(l).slice(0, 2).forEach(function (pt) { who.push(pt.k + ' ' + pt.n); });
    return where + ' · ' + HOUSE_NAME[kind] + (who.length ? ' · cùng ' + who.join(', ') : ' · một mình');
  }
  function U2(s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) : s; }

  E.art = { avatar: avatar, scene: scene, caption: caption, houseKind: houseKind };
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
/* ===== js/scene2d.js ===== */
/* Minh họa anime 2D bằng SVG: tóc nhiều lớp, mắt cel và phong cảnh có ánh sáng. Giữ kích thước và vị trí của tranh cũ.
   Ngoại hình lấy từ danh tính cố định, không đổi mỗi khi RNG của cuộc đời chạy. */
(function (G) {
  'use strict';
  var E = G.E, oldKind = E.art.houseKind;
  function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
  function seed(l, k) { var s = [l.name, l.birthYear, l.birthMonth, l.pool, k || 0].join('|'), h = 2166136261; for (var i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619); h ^= h >>> 16; h = Math.imul(h, 0x85ebca6b); h ^= h >>> 13; h = Math.imul(h, 0xc2b2ae35); h ^= h >>> 16; return (h >>> 0) / 4294967296; }
  function rect(o, x, y, w, h, fill, radius, extra) { o.push('<rect x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" rx="' + (radius || 0) + '" fill="' + fill + '" ' + (extra || '') + '/>'); }
  function ellipse(o, x, y, rx, ry, fill, extra) { o.push('<ellipse cx="' + x + '" cy="' + y + '" rx="' + rx + '" ry="' + ry + '" fill="' + fill + '" ' + (extra || '') + '/>'); }
  function path(o, d, fill, stroke, width, extra) { o.push('<path d="' + d + '" fill="' + (fill || 'none') + '"' + (stroke ? ' stroke="' + stroke + '" stroke-width="' + (width || 1) + '" stroke-linecap="round" stroke-linejoin="round"' : '') + ' ' + (extra || '') + '/>'); }
  function svg(w, h, o, cls, label) { return '<svg class="art2d ' + cls + '" role="img" aria-label="' + esc(label) + '" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + w + ' ' + h + '" shape-rendering="geometricPrecision" preserveAspectRatio="xMidYMid meet">' + o.join('') + '</svg>'; }
  function skin(l, k) { var pool = l.pool || 'vn', colors = /^(afr|afw|afe|afs|et|so|ss|ao|ht|car)$/.test(pool) ? ['#80543f', '#97674b', '#684637'] : /^(in|pk|bd|lk|np|ar|fa|af|tr|es_la|br|ph|id|my|th|kh|la|mm|mg|pac)$/.test(pool) ? ['#bd8967', '#d6a17c', '#aa795a'] : ['#ebbf9d', '#f3d1b0', '#dfad89']; return colors[Math.floor(seed(l, 10 + (k || 0)) * colors.length)]; }
  function hair(l, age, k) { if (age >= 75) return '#d9dddf'; if (age >= 58) return '#a2a6ad'; var c = /^(vn|cn|kr|kp|jp|sg|mn|afr|afw|afe|afs)$/.test(l.pool || 'vn') ? ['#292729', '#3b2b28', '#242c33'] : ['#36292b', '#65462f', '#9b743e', '#684332']; return c[Math.floor(seed(l, 20 + (k || 0)) * c.length)]; }
  function outfit(l, age) {
    var c = l.job ? E.jobDef(l) : null, id = c && c.id, cat = c && c.cat;
    if (l.jailUntil != null && l.age < l.jailUntil) return { color: '#7d8fa1', stripes: true };
    if (age >= 6 && age < 18 && l.school) return { color: '#e7f0f1', scarf: age <= 14 };
    if (id === 'cong_an') return { color: '#496653', cap: true };
    if (id === 'quan_doi') return { color: '#526445', cap: true };
    if (cat === 'med') return { color: '#e5eef0', medical: true };
    if (cat === 'office' || cat === 'sale' || /ngan_hang/.test(id || '')) return { color: '#354c68', tie: true };
    if (id === 'bartender' || id === 'barista') return { color: '#eee4d4', apron: true };
    return { color: ['#547f7d', '#a46e6d', '#5d7192', '#a28a59', '#78658b'][Math.floor(seed(l, 33) * 5)] };
  }
  // Chân dung anime: cằm thuôn, mắt nhiều lớp, tóc chia lọn và bóng cel.
  function head(o, p, x, y, scale) {
    o.push('<g class="anime-head" transform="translate(' + x + ' ' + y + ') scale(' + scale + ')">');
    var F = p.sex === 'F' && p.age >= 3, ink = '#343044', baby = p.age < 3;
    if (F) {
      path(o, 'M-24-7 Q-29-36-4-37 Q25-38 28-9 L30 37 L21 31 L17 43 Q0 37-21 43 L-26 32 L-31 37Z', p.hair, ink, .8);
      path(o, 'M-23-7 Q-26 17-21 32 M22-7 Q27 20 22 34', null, '#d9c8d9', 1.1, 'opacity=".16"');
    }
    path(o, 'M-7 17 L-7 36 Q0 41 7 36 L7 17Z', p.skin, ink, .65);
    path(o, 'M-7 23 Q0 32 7 23 L7 29 Q0 35-7 29Z', '#a65d65', null, 0, 'opacity=".22"');
    ellipse(o, -20, 4, 4, 6, p.skin, 'stroke="' + ink + '" stroke-width=".65"'); ellipse(o, 20, 4, 4, 6, p.skin, 'stroke="' + ink + '" stroke-width=".65"');
    path(o, baby ? 'M-20-11 Q0-34 20-11 L20 10 Q18 28 0 29 Q-18 28-20 10Z' : 'M-21-12 C-18-34 18-34 21-12 L20 8 Q18 19 9 25 L0 31 L-9 25 Q-18 19-20 8Z', p.skin, ink, .8);
    path(o, 'M16-15 Q25 2 17 16 L0 31 L8 23 Q17 13 15 5Z', '#bd7f80', null, 0, 'opacity=".18"');
    path(o, 'M-13-15 Q-4-24 9-18', null, '#fff5dc', 3, 'opacity=".3"');
    [-1, 1].forEach(function (side) {
      o.push('<g class="anime-eye" transform="translate(' + side * 9.5 + ' 4) scale(' + side + ' 1)">');
      var ry = p.age >= 60 ? 3.5 : baby ? 5 : F ? 6.5 : 5.3;
      path(o, 'M-5-1 Q0-' + (ry + 3) + ' 6-1 Q4 ' + (ry + 3) + '-2 ' + ry + ' Q-5 3-5-1Z', '#fff8f0', ink, .5);
      ellipse(o, .3, .7, 3.4, ry, '#485674');
      ellipse(o, .3, 2.6, 2.8, Math.max(1, ry - 2), '#9bafb5');
      ellipse(o, .3, -.2, 1.5, Math.max(2, ry - 1), '#282a43');
      ellipse(o, -1, -1.7, 1.25, 1.7, '#ffffff'); ellipse(o, 1.9, 3, .7, .8, '#fff4d6');
      path(o, 'M-6-1 Q0-' + (ry + 3.5) + ' 6-1 L8-3 M-4 ' + (ry - 1) + ' Q1 ' + (ry + 2) + ' 5 2', null, ink, F ? 1.4 : 1.1);
      if (F) path(o, 'M5-3 L7-5 M3-4 L4-6', null, ink, .8);
      path(o, 'M-5-' + (ry + 5) + ' Q0-' + (ry + 7) + ' 5-' + (ry + 4), null, p.hair, 1.2);
      o.push('</g>');
    });
    ellipse(o, -14, 13, 4.7, 2.6, '#e88699', 'opacity=".25"'); ellipse(o, 14, 13, 4.7, 2.6, '#e88699', 'opacity=".25"');
    path(o, 'M1 10 L-1 15 L2 15', null, '#aa6d74', .65);
    path(o, p.hap < 35 ? 'M-4 22 Q0 19 4 22' : p.hap < 55 ? 'M-3 21 Q0 22 3 21' : 'M-4 20 Q0 24 5 19', null, '#975167', 1);
    path(o, 'M-2 24 L2 24', null, '#fff1df', .65, 'opacity=".6"');
    if (baby) path(o, 'M-10-23 Q-12-35-1-33 Q8-32 3-25 Q-2-31-4-25 M1-30 Q15-36 17-23', null, p.hair, 2.5);
    else {
      path(o, F ? 'M-24 4 Q-30-21-18-31 Q-6-42 13-33 Q31-29 25 3 L19-8 L16-21 Q11-8 5-5 L7-21 Q-1-8-8-4 L-5-20 Q-13-8-19-3 L-19-15Z' : 'M-23 1 L-26-13 L-23-25 L-28-29 L-15-29 L-17-36 L-4-32 L4-39 L10-33 Q29-33 25-13 L21 4 L17-11 L12-21 L12-8 L3-17 L-2-8 L-10-16 L-18 2 L-18-13Z', p.hair, ink, .8);
      path(o, F ? 'M-19-22 Q-12-32 2-32 M5-31 Q16-30 20-20 M-17-19 L-13-23 M8-25 L5-19' : 'M-18-24 L-8-28 L-3-26 M2-30 L9-28 L17-23 M-11-22 L-7-20 M13-20 L17-16', null, '#d4c1d6', 1.7, 'opacity=".24"');
      path(o, 'M-20-12 L-19-5 M21-12 L22-5', null, '#fff1da', .8, 'opacity=".28"');
    }
    if (p.age >= 60) { rect(o, -17, -2, 14, 12, 'none', 4, 'stroke="#786f8b" stroke-width=".9"'); rect(o, 3, -2, 14, 12, 'none', 4, 'stroke="#786f8b" stroke-width=".9"'); path(o, 'M-3 2 Q0 0 3 2 M-17 2 L-21 0 M17 2 L21 0', null, '#786f8b', .9); path(o, 'M-16 14 L-12 15 M12 15 L16 14 M-7 18 L-8 22 M7 18 L8 22', null, '#a67b78', .6); }
    if (p.age >= 75) path(o, 'M-7-8 Q0-10 7-8 M-6-12 Q0-14 6-12', null, '#b58f89', .65);
    if (p.cap) { path(o, 'M-25-18 Q0-40 25-18 L22-10 L-22-10Z', p.color, ink, .8); path(o, 'M-25-11 Q0-5 25-11 L20-5 L-20-5Z', '#263f42', ink, .6); ellipse(o, 0, -20, 3, 3, '#efd38a'); }
    o.push('</g>');
  }
  function person(l, age, sex, k, color) { return { age: Math.max(0, age || 0), sex: sex, skin: skin(l, k), hair: hair(l, age, k), color: color || outfit(l, age).color, hap: l.st ? l.st.hap : 65 }; }
  function avatar(l) {
    var age = l.alive === false && l.death ? l.death.age : l.age || 0, p = person(l, age, l.sex, 0), fit = outfit(l, age), o = [], id = 'portrait-' + Math.floor(seed(l, 99) * 1e9);
    o.push('<defs><linearGradient id="' + id + '" x2="1" y2="1"><stop stop-color="#526181"/><stop offset=".55" stop-color="#44415d"/><stop offset="1" stop-color="#c49294"/></linearGradient></defs>');
    rect(o, 0, 0, 160, 160, 'url(#' + id + ')', 0); ellipse(o, 126, 26, 52, 52, '#d4c79f', 'opacity=".08"'); ellipse(o, 26, 152, 62, 46, '#6c9b9c', 'opacity=".12"');
    for (var light = 0; light < 9; light++) ellipse(o, seed(l, light + 710) * 160, seed(l, light + 730) * 160, 2 + seed(l, light + 750) * 6, 2 + seed(l, light + 750) * 6, '#ffe6bd', 'opacity=".13"');
    path(o, 'M0 156 Q80 100 160 125 L160 160H0Z', '#dcc2bc', null, 0, 'opacity=".08"');
    if (age < 2) {
      path(o, 'M34 157 Q27 119 56 105 Q79 91 106 109 Q133 123 126 160Z', '#f1e3c8');
      path(o, 'M40 124 Q82 135 118 113 M48 151 Q86 155 122 132', null, '#d8c6a7', 2);
      head(o, p, 80, 65, 1.03);
    } else {
      path(o, 'M24 160 L27 130 Q33 108 62 104 L98 104 Q128 108 133 130 L137 160Z', fit.color);
      path(o, 'M28 159 L34 130 Q42 116 60 111 L65 160Z', '#1d263f', null, 0, 'opacity=".19"');
      path(o, 'M99 110 Q116 114 126 130 L130 159', null, '#fff0d5', 2.5, 'opacity=".3"');
      path(o, 'M63 105 L80 124 L97 105', null, '#fff5e8', 3, 'opacity=".65"');
      path(o, 'M38 144 L48 133 M117 142 L110 132 M69 151 L70 136', null, '#25253d', .9, 'opacity=".3"');
      if (fit.tie) path(o, 'M77 121 L83 121 L87 151 L80 158 L73 151Z', '#ca9e75');
      if (fit.apron) { path(o, 'M52 111 L60 111 L61 128 L100 128 L102 111 L110 114 L112 160 L49 160Z', '#435254'); path(o, 'M66 145 L96 145', null, '#b8c3bd', 1.4); }
      if (fit.scarf) path(o, 'M60 109 L80 124 L100 109 L88 128 L89 147 L79 141 L75 126Z', '#bc5a51');
      if (fit.medical) { path(o, 'M59 112 L59 136 Q59 147 71 147 Q82 147 82 135 L82 115 M82 135 Q84 152 101 144', null, '#6b7c89', 2.5); ellipse(o, 102, 144, 4, 4, '#8195a2'); }
      if (fit.stripes) { path(o, 'M30 136 L130 136 M26 151 L135 151', null, '#dce3e7', 5, 'opacity=".65"'); }
      p.cap = fit.cap; head(o, p, 80, age < 12 ? 68 : 61, age < 12 ? 1.02 : 1.12);
    }
    if (l.alive === false) rect(o, 0, 0, 160, 160, '#172432', 0, 'opacity=".3"');
    return svg(160, 160, o, 'avatar', 'Chân dung anime 2D của ' + l.name);
  }
  function figure(o, x, ground, p, me) {
    var scale = p.age < 2 ? 0.38 : p.age < 12 ? 0.49 : p.age < 18 ? 0.62 : 0.69;
    o.push('<g transform="translate(' + x + ' ' + ground + ') scale(' + scale + ')">');
    ellipse(o, 0, 0, 24, 5, '#142c35', 'opacity=".14"');
    if (p.age < 2) { path(o, 'M-18-11 Q-28-40 0-43 Q28-39 18-11Z', '#efe3cd'); head(o, p, 0, -55, 0.7); }
    else {
      path(o, 'M-12-42 L-12-6 M11-42 L11-6', null, '#39475b', 10);
      path(o, 'M-18-6 L-7-6 M6-6 L19-6', null, '#273b49', 6);
      path(o, 'M-19-74 Q0-85 19-74 L23-41 Q0-35-23-41Z', p.color, '#353347', .8);
      path(o, 'M-18-71 L-10-67 L-9-41 L-22-42Z', '#252c46', null, 0, 'opacity=".18"');
      path(o, 'M-7-77 L0-69 L8-77 M12-64 L16-44', null, '#fff1e4', 1.8, 'opacity=".45"');
      path(o, 'M-19-69 L-29-46 M19-69 L29-46', null, p.color, 8);
      ellipse(o, -29, -44, 4, 5, p.skin); ellipse(o, 29, -44, 4, 5, p.skin);
      head(o, p, 0, -100, 0.7);
      if (p.age >= 75) path(o, 'M33-47 L37-3 M33-47 Q41-53 42-44', null, '#987b59', 2.5);
    }
    if (me) { ellipse(o, 0, -133, 7, 7, '#e3bf78'); path(o, 'M-3-132 L0-129 L4-135', null, '#514c3d', 1.8); }
    o.push('</g>');
  }
  function houseKind(l) {
    var old = oldKind(l); if (old === 'prison' || old === 'compound') return old;
    if (l.indep && l.ownHouse && l.houseName) { if (/căn hộ|chung cư/i.test(l.houseName)) return 'cc'; if (/biệt thự|dinh thự/i.test(l.houseName)) return 'villa'; if (/nhà phố|nhà ống/i.test(l.houseName)) return 'ong'; }
    return old;
  }
  function companions(l) {
    var list = [], f = l.fam || {}, a = l.age, kind = houseKind(l);
    if (kind === 'prison' || kind === 'compound') return [Object.assign(person(l, a, l.sex, 0, '#8598aa'), { me: true })];
    if (!l.indep || a < 20 || l.flags.caring) { if (f.fAlive && !f.noDad) list.push(person(l, f.fAge + a, 'M', 'father', '#5d7991')); if (f.mAlive) list.push(person(l, f.mAge + a, 'F', 'mother', '#aa7778')); }
    if (!l.indep || a < 18) E.H.sibs(l).slice(0, 3).forEach(function (s) { list.push(person(l, Math.max(0, a - s.born), s.sex, 'sibling-' + s.n, '#7c9477')); });
    list.push(Object.assign(person(l, a, l.sex, 0), { me: true }));
    if (l.partner && l.partner.alive !== false && l.partner.status !== 'dating') list.push(person(l, l.partner.age, l.partner.sex, 'partner-' + l.partner.name, '#9380a8'));
    (l.kids || []).filter(function (c) { return c.alive && c.custody !== 'ex' && a - c.born < 25; }).slice(0, 4).forEach(function (c) { list.push(person(l, a - c.born, c.sex, 'child-' + (c.name || c.born + c.sex), '#c6a46d')); });
    return list.slice(0, 8);
  }
  function house(o, kind, night) {
    var wall = night ? '#606d91' : '#f0dec9', win = night ? '#ffd3a2' : '#99cbdc';
    function window(x, y, w, h) { w = w || 21; h = h || 28; rect(o, x - 2, y - 2, w + 4, h + 4, '#647487', 1); rect(o, x, y, w, h, win, 1); path(o, 'M' + x + ' ' + (y + h) + ' l' + w + ' -' + h + ' M' + x + ' ' + (y + h - 8) + ' l' + (w - 8) + ' -' + (h - 8), null, '#fff5e6', 2, 'opacity=".3"'); path(o, 'M' + (x + w / 2) + ' ' + y + ' V' + (y + h) + ' M' + x + ' ' + (y + h / 2) + ' h' + w, null, '#e5d8c9', 1.4); rect(o, x - 3, y + h, w + 6, 3, '#8f8490', 0); }
    if (kind === 'prison' || kind === 'compound') {
      rect(o, 36, 56, 528, 144, night ? '#3d5265' : '#9aabba', 8); rect(o, 27, 48, 546, 13, '#61798a', 4);
      for (var b = 0; b < 7; b++) { rect(o, 62 + b * 71, 84, 43, 58, '#263f53', 3); for (var bar = 0; bar < 3; bar++) path(o, 'M' + (71 + b * 71 + bar * 12) + ' 85 V141', null, '#bbc4c9', 3); }
      path(o, 'M10 197 L590 197 M20 157 L580 157', null, '#516577', 3); return;
    }
    if (kind === 'ong' || kind === 'cc') {
      rect(o, 62, kind === 'cc' ? 43 : 55, kind === 'cc' ? 154 : 100, kind === 'cc' ? 157 : 145, wall, 5);
      for (var floor = 0; floor < 3; floor++) { window(75, 66 + floor * 41, 27, 29); window(115, 66 + floor * 41, 27, 29); if (kind === 'cc') window(165, 66 + floor * 41, 28, 29); path(o, 'M65 ' + (101 + floor * 41) + ' H' + (kind === 'cc' ? 210 : 157), null, '#a89e90', 3); }
      rect(o, 57, kind === 'cc' ? 37 : 49, kind === 'cc' ? 165 : 110, 9, '#67808d', 3); rect(o, 108, 170, 30, 30, '#77614d', 2); rect(o, 145, kind === 'cc' ? 46 : 58, 17, 142, '#665c7d', 0, 'opacity=".15"'); path(o, 'M67 55 V195', null, '#fff5e4', 2, 'opacity=".45"'); return;
    }
    if (kind === 'tro') { rect(o, 30, 126, 223, 74, wall, 5); path(o, 'M25 126 L258 126 L251 113 L33 113Z', '#7c9299'); for (var room = 0; room < 3; room++) { rect(o, 47 + room * 70, 152, 29, 48, '#667f8c', 3); window(80 + room * 70, 143, 15, 20); } return; }
    var low = kind === 'tam', high = kind === 'san', long = kind === 'dai';
    rect(o, 43, high ? 133 : 132, long ? 231 : 169, high ? 47 : 68, wall, 4);
    if (high) { path(o, 'M50 179 V200 M200 179 V200 M125 180 L145 200', null, '#7c6550', 5); }
    path(o, 'M28 134 L' + (long ? 155 : 127) + ' ' + (low ? 100 : 80) + ' L' + (long ? 286 : 227) + ' 134Z', low ? '#a79772' : '#a45f50');
    path(o, 'M47 127 L' + (long ? 155 : 127) + ' ' + (low ? 102 : 86) + ' L' + (long ? 266 : 208) + ' 127', null, '#c68f73', 2);
    path(o, 'M43 135 L212 135 L212 146 L43 146Z', '#6b5471', null, 0, 'opacity=".22"');
    path(o, 'M147 139 L212 139 L212 200 L147 200Z', '#b3a0aa', null, 0, 'opacity=".2"');
    if (!low) for (var tile = 0; tile < 7; tile++) path(o, 'M' + (50 + tile * 23) + ' 128 L' + (127 + (tile - 3) * 4) + ' 90', null, '#754d61', .8, 'opacity=".55"');
    path(o, 'M54 119 H201 M75 108 H180 M97 97 H156', null, '#efb595', .75, 'opacity=".45"');
    rect(o, 112, high ? 143 : 155, 31, high ? 36 : 45, '#7b6050', 2); window(61, 147, 29, 25); window(165, 147, 29, 25);
    if (kind === 'villa') { rect(o, 209, 122, 62, 78, '#ddd9ca', 5); window(226, 137, 26, 35); path(o, 'M199 125 L240 98 L281 125Z', '#a45f50'); rect(o, 36, 192, 244, 8, '#b2ac9b', 2); }
  }
  var HOUSE_NAMES = { tile: 'nhà mái ngói', ong: 'nhà ống', cc: 'căn hộ chung cư', villa: 'biệt thự', san: 'nhà sàn', trinh: 'nhà trình tường', tam: 'nhà tạm', dai: 'nhà dài', tro: 'phòng trọ' };
  function petFigure(o, pet, x) {
    if (pet.k === 'cá cảnh' || pet.k === 'cá') { ellipse(o, x, 220, 14, 13, '#c4dad6', 'opacity=".8"'); path(o, 'M' + (x - 12) + ' 218 Q' + x + ' 214 ' + (x + 12) + ' 218', null, '#77acbf', 2); ellipse(o, x, 222, 6, 3, '#d7a15f'); return; }
    if (pet.k === 'chim') { path(o, 'M' + x + ' 231 V207 M' + (x - 13) + ' 223 H' + (x + 13), null, '#9a835f', 2); ellipse(o, x, 215, 7, 8, '#adbb76'); ellipse(o, x + 5, 208, 5, 5, '#c3ce8a'); path(o, 'M' + (x + 9) + ' 208 l4 2-4 2Z', '#c9a66c'); return; }
    if (pet.k === 'rùa') { ellipse(o, x, 226, 14, 7, '#829879'); ellipse(o, x + 16, 227, 5, 4, '#a6b18a'); return; }
    ellipse(o, x, 226, 13, 7, pet.k === 'mèo' ? '#bca58c' : '#bb976d'); ellipse(o, x + 10, 219, 6, 7, '#c7af8a');
    if (pet.k === 'mèo') path(o, 'M' + (x + 5) + ' 215 l1-7 5 5 l5-5 0 8Z', '#c7af8a');
    else if (pet.k === 'thỏ') { ellipse(o, x + 7, 209, 2, 8, '#e1d6c2'); ellipse(o, x + 13, 208, 2, 8, '#e1d6c2'); }
    else path(o, 'M' + (x + 6) + ' 215 q-5 10-7 4', null, '#92785c', 4);
    if (pet.k !== 'thỏ') path(o, 'M' + (x - 12) + ' 224 q-12-12-8-16', null, '#b99c7b', 3);
  }
  function caption(l) {
    if (l.alive === false) return 'Nơi an nghỉ của ' + l.name;
    var kind = houseKind(l), f = l.fam, who = [], a = l.age;
    if (kind === 'prison') return 'Trại giam · còn ' + Math.max(0, l.jailUntil - a) + ' năm';
    if (kind === 'compound') return 'Khu nhà bị giam giữ';
    if (!l.indep || a < 20 || l.flags.caring) { if (f.mAlive && f.fAlive && !f.noDad) who.push('bố mẹ'); else if (f.mAlive) who.push('mẹ'); else if (f.fAlive && !f.noDad) who.push('bố'); }
    if ((!l.indep || a < 18) && E.H.sibs(l).length) who.push(E.H.sibs(l).length + ' anh chị em');
    if (l.partner && l.partner.alive !== false && l.partner.status !== 'dating') who.push(E.H.partnerWord(l, l.partner));
    var kids = (l.kids || []).filter(function (c) { return c.alive && c.custody !== 'ex' && a - c.born < 25; }); if (kids.length) who.push(kids.length + ' con');
    E.H.pets(l).slice(0, 2).forEach(function (p) { who.push(p.k + ' ' + p.n); });
    var where = l.abroad ? l.abroad.name : l.cityStudent ? l.cityStudent.city : l.movedTo || l.place || 'Nơi đang sống';
    return where + ' · ' + (HOUSE_NAMES[kind] || 'nhà ở') + (who.length ? ' · cùng ' + who.join(', ') : ' · một mình');
  }
  function scene(l) {
    var o = [], kind = houseKind(l), night = l.alive === false || (l.st && l.st.hap < 40), dusk = !night && l.st && l.st.hap < 62, urban = l.urban || (l.abroad && l.abroad.perm), id = 'sky-' + Math.floor(seed(l, 99) * 1e9);
    var sky = night ? ['#222b58', '#77749a'] : dusk ? ['#7378b4', '#ffc3a5'] : ['#78b4e4', '#f4e9d8'];
    o.push('<defs><linearGradient id="' + id + '" x2="0" y2="1"><stop stop-color="' + sky[0] + '"/><stop offset="1" stop-color="' + sky[1] + '"/></linearGradient></defs>'); rect(o, 0, 0, 600, 240, 'url(#' + id + ')');
    for (var halo = 4; halo > 0; halo--) ellipse(o, 494, dusk ? 139 : 43, (night ? 18 : 23) + halo * 12, (night ? 18 : 23) + halo * 12, '#fff1cc', 'opacity=".035"');
    ellipse(o, 494, dusk ? 139 : 43, night ? 15 : 20, night ? 15 : 20, night ? '#fff0d9' : '#fff1ce');
    if (!night) { path(o, 'M470 0 L600 0 L354 222 L245 240Z', '#fff1d4', null, 0, 'opacity=".09"'); path(o, 'M505 0 L545 0 L140 240 L86 240Z', '#ffeecb', null, 0, 'opacity=".06"'); }
    if (night) for (var s = 0; s < 18; s++) ellipse(o, 20 + seed(l, s + 90) * 560, 12 + seed(l, s + 180) * 100, 1, 1, '#e5e6d6', 'opacity=".65"');
    else for (var c = 0; c < 4; c++) {
      var x = -40 + seed(l, 400 + c) * 570, y = 16 + seed(l, 500 + c) * 61;
      path(o, 'M' + x + ' ' + y + ' q10-15 27-8 q3-20 25-17 q18-16 35 5 q23-5 30 14 q15-3 23 11 q-65 10-140-5Z', dusk ? '#f4c8c9' : '#fef6ef', null, 0, 'opacity=".83"');
      path(o, 'M' + (x + 12) + ' ' + (y + 1) + ' q22-9 42-2 q22-10 42 0 q16-5 34 2 q-60 10-118 0Z', dusk ? '#c79cbb' : '#cbdbe8', null, 0, 'opacity=".44"');
    }
    if (urban) for (var b = 0; b < 9; b++) {
      var h = 37 + seed(l, 600 + b) * 85, bx = b * 74 - 13;
      rect(o, bx, 191 - h, 55, h, night ? '#414b75' : '#91aac7', 1, 'opacity=".6"');
      rect(o, bx + 40, 191 - h, 15, h, night ? '#354163' : '#8396b3', 0, 'opacity=".5"');
      path(o, 'M' + (bx + 4) + ' ' + (190 - h) + ' h45', null, '#f0d5cc', 1.2, 'opacity=".55"');
      for (var by = 0; by < 4; by++) for (var bw = 0; bw < 3; bw++) rect(o, bx + 7 + bw * 13, 199 - h + by * 17, 5, 8, night ? '#ebc3a3' : '#d6e7ec', 0, 'opacity=".5"');
    }
    else if (l.coast) { path(o, 'M0 140 Q170 131 300 143 T600 137 L600 200 H0Z', night ? '#4b628b' : '#6eb3d4'); for (var w = 0; w < 8; w++) path(o, 'M' + (w * 80) + ' 163 q17-4 35 0', null, '#e2e8dd', 1.4, 'opacity=".65"'); }
    else { path(o, 'M0 167 Q80 93 160 151 Q235 78 322 144 Q435 68 600 156 L600 205 H0Z', night ? '#4f577e' : '#8eafbb'); path(o, 'M0 182 Q150 127 294 165 Q438 130 600 174 V208 H0Z', night ? '#485f77' : '#a6bdb2'); }
    path(o, 'M0 194 Q200 185 600 197 V240 H0Z', urban ? '#9d9cab' : night ? '#455875' : '#98b28c');
    path(o, 'M0 221 Q240 209 600 226 V240 H0Z', urban ? '#c9bcb9' : night ? '#57617d' : '#d7cba7');
    path(o, 'M232 199 L194 240 H291 L286 199Z', night ? '#636781' : '#e8d5bd', null, 0, 'opacity=".75"');
    if (urban) { path(o, 'M0 222 Q300 207 600 226 M0 234 Q300 217 600 238', null, '#faf0d9', 1, 'opacity=".4"'); for (var paving = 0; paving < 10; paving++) path(o, 'M' + paving * 70 + ' 216 l-16 24', null, '#7e7d94', .7, 'opacity=".25"'); }
    else for (var grass = 0; grass < 40; grass++) { var gx = seed(l, 810 + grass) * 600, gy = 198 + seed(l, 910 + grass) * 40; path(o, 'M' + gx + ' ' + gy + ' l-2-5 m2 5 3-4', null, night ? '#879491' : '#758c70', .8, 'opacity=".5"'); }
    if (l.alive !== false) house(o, kind, night);
    else { path(o, 'M104 198 V158 Q126 133 148 158 V198Z', '#a6b1af'); path(o, 'M126 157 V181 M118 166 H134', null, '#71878b', 3); ellipse(o, 126, 201, 37, 5, '#5e7667'); ellipse(o, 158, 191, 5, 5, '#cd9798'); }
    if (kind !== 'prison' && kind !== 'compound') {
      [14, 568].forEach(function (tx) {
        path(o, 'M' + tx + ' 202 Q' + (tx + 6) + ' 157 ' + tx + ' 118', null, '#706576', 7);
        path(o, 'M' + tx + ' 165 l-13-20 M' + (tx + 1) + ' 153 l18-19', null, '#706576', 3);
        for (var leaf = 0; leaf < 19; leaf++) {
          var lx = tx - 30 + seed(l, 1200 + leaf) * 60, ly = 105 + seed(l, 1300 + leaf) * 53;
          ellipse(o, lx, ly, 11 + seed(l, 1400 + leaf) * 9, 9 + seed(l, 1500 + leaf) * 8, night ? ['#4d6476', '#5b7580', '#69838a'][leaf % 3] : ['#6b9688', '#8db39a', '#b6c69f', '#79a28f'][leaf % 4]);
          path(o, 'M' + (lx - 5) + ' ' + (ly - 4) + ' q5-3 10 0', null, night ? '#b6b5b1' : '#e2dbb0', 1, 'opacity=".25"');
        }
      });
    }
    if (l.alive !== false) {
      var people = companions(l), spacing = people.length > 6 ? 36 : 43, start = people.length === 1 ? 350 : Math.max(293, 405 - (people.length - 1) * spacing / 2);
      people.forEach(function (p, i) { figure(o, start + i * spacing, 209 + (i % 2) * 3, p, p.me); });
      if (kind !== 'prison' && kind !== 'compound') E.H.pets(l).slice(0, 2).forEach(function (pet, i) { petFigure(o, pet, 307 + i * 33); });
    }
    return svg(600, 240, o, 'scene', 'Minh họa anime 2D: ' + caption(l));
  }
  E.art = { avatar: avatar, scene: scene, caption: caption, houseKind: houseKind, companions: companions, style: '2d', theme: 'anime' };
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
/* ===== js/music.js ===== */
/* Một Đời — nhạc nền lofi chill tự sinh bằng Web Audio (không dùng file nhạc, không bản quyền).
   Piano điện (Rhodes) với hợp âm jazz 7/9, bass trầm, trống nhẹ có swing, tiếng đĩa than lạo xạo, giai điệu thưa qua delay.
   Trình duyệt chỉ cho phát âm thanh sau khi người dùng bấm, nên nhạc bắt đầu ở lần bấm đầu tiên. */
(function () {
  'use strict';
  var KEY = 'mkn.music';
  function load() { try { var v = JSON.parse(localStorage.getItem(KEY) || 'null'); return v && typeof v === 'object' ? v : null; } catch (e) { return null; } }
  function save() { try { localStorage.setItem(KEY, JSON.stringify({ on: S.want, vol: S.vol })); } catch (e) { /* bỏ qua */ } }
  var saved = load() || {};
  var S = { want: !!saved.on, vol: saved.vol == null ? 0.35 : +saved.vol, ctx: null, master: null, bus: null, delay: null, noise: null, lfo: null, timer: null, next: 0, step: 0, bar: 0, prog: 0, playing: false, listeners: [] };

  var BPM = 72, SPB = 60 / BPM, SWING = 0.6;
  // hợp âm: [bass (MIDI), các nốt hợp âm]
  var PROGS = [
    [[41, [57, 60, 64, 67]], [40, [55, 59, 62, 64]], [38, [53, 57, 60, 64]], [36, [55, 59, 60, 64]]], // Fmaj7 – Em7 – Dm9 – Cmaj7
    [[38, [53, 57, 60, 64]], [43, [53, 57, 59, 64]], [36, [52, 55, 59, 62]], [45, [55, 59, 60, 64]]], // Dm9 – G13 – Cmaj9 – Am9
    [[45, [55, 60, 64, 67]], [38, [53, 57, 60, 65]], [40, [55, 59, 62, 67]], [45, [55, 60, 64, 69]]], // Am7 – Dm7 – Em7 – Am7
    [[39, [55, 58, 62, 65]], [44, [55, 60, 63, 67]], [41, [56, 60, 63, 67]], [46, [56, 58, 62, 65]]]  // Ebmaj9 – Abmaj7 – Fm9 – Bb13
  ];
  function hz(m) { return 440 * Math.pow(2, (m - 69) / 12); }
  function rnd(a, b) { return a + Math.random() * (b - a); }

  function setup() {
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return false;
    var c = S.ctx = new AC();
    S.master = c.createGain(); S.master.gain.value = 0;
    var lp = c.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 2300; lp.Q.value = 0.4;
    var comp = c.createDynamicsCompressor(); comp.threshold.value = -20; comp.ratio.value = 3;
    S.bus = c.createGain(); S.bus.gain.value = 1;
    S.bus.connect(lp); lp.connect(comp); comp.connect(S.master); S.master.connect(c.destination);
    // delay cho giai điệu
    S.delay = c.createDelay(1.5); S.delay.delayTime.value = SPB * 0.75;
    var fb = c.createGain(); fb.gain.value = 0.32; var wet = c.createGain(); wet.gain.value = 0.3;
    S.delay.connect(fb); fb.connect(S.delay); S.delay.connect(wet); wet.connect(S.bus);
    // nhiễu trắng dùng cho trống & đĩa than
    var len = c.sampleRate * 2, buf = c.createBuffer(1, len, c.sampleRate), d = buf.getChannelData(0);
    for (var i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    S.noise = buf;
    // tiếng hiss đĩa than liên tục
    var hiss = c.createBufferSource(); hiss.buffer = buf; hiss.loop = true;
    var hb = c.createBiquadFilter(); hb.type = 'bandpass'; hb.frequency.value = 4000; hb.Q.value = 0.6;
    var hg = c.createGain(); hg.gain.value = 0.012;
    hiss.connect(hb); hb.connect(hg); hg.connect(S.master); hiss.start();
    // "băng từ chao đảo": LFO làm lệch cao độ nhẹ
    S.lfo = c.createOscillator(); S.lfo.frequency.value = 0.35; S.lfoGain = c.createGain(); S.lfoGain.gain.value = 7;
    S.lfo.connect(S.lfoGain); S.lfo.start();
    return true;
  }

  function env(g, t, a, peak, dec, sus, rel, end) {
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(peak, t + a);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0001, peak * sus), t + a + dec);
    g.gain.setValueAtTime(Math.max(0.0001, peak * sus), end);
    g.gain.exponentialRampToValueAtTime(0.0001, end + rel);
  }
  function keys(m, t, dur, vel, toDelay) {
    var c = S.ctx, f = hz(m), g = c.createGain();
    var o1 = c.createOscillator(); o1.type = 'sine'; o1.frequency.value = f;
    var o2 = c.createOscillator(); o2.type = 'triangle'; o2.frequency.value = f * 2; var g2 = c.createGain(); g2.gain.value = 0.12;
    S.lfoGain.connect(o1.detune); S.lfoGain.connect(o2.detune);
    o1.connect(g); o2.connect(g2); g2.connect(g);
    g.connect(S.bus); if (toDelay) g.connect(S.delay);
    env(g, t, 0.012, vel, 0.9, 0.45, 1.6, t + dur);
    o1.start(t); o2.start(t); o1.stop(t + dur + 1.8); o2.stop(t + dur + 1.8);
  }
  function bass(m, t, dur) {
    var c = S.ctx, o = c.createOscillator(), g = c.createGain();
    o.type = 'sine'; o.frequency.value = hz(m);
    o.connect(g); g.connect(S.bus);
    env(g, t, 0.02, 0.32, 0.3, 0.6, 0.35, t + dur);
    o.start(t); o.stop(t + dur + 0.5);
  }
  function kick(t, v) {
    var c = S.ctx, o = c.createOscillator(), g = c.createGain();
    o.frequency.setValueAtTime(115, t); o.frequency.exponentialRampToValueAtTime(42, t + 0.12);
    g.gain.setValueAtTime(0.75 * v, t); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.38);
    o.connect(g); g.connect(S.bus); o.start(t); o.stop(t + 0.4);
  }
  function noiseHit(t, type, freq, q, vol, dec) {
    var c = S.ctx, s = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
    s.buffer = S.noise; f.type = type; f.frequency.value = freq; f.Q.value = q;
    g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dec);
    s.connect(f); f.connect(g); g.connect(S.bus);
    s.start(t, Math.random() * 1.5); s.stop(t + dec + 0.02);
  }
  function snare(t, v) { noiseHit(t, 'bandpass', 1700, 0.8, 0.28 * v, 0.2); var c = S.ctx, o = c.createOscillator(), g = c.createGain(); o.type = 'triangle'; o.frequency.value = 190; g.gain.setValueAtTime(0.12 * v, t); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.1); o.connect(g); g.connect(S.bus); o.start(t); o.stop(t + 0.12); }
  function hat(t, v) { noiseHit(t, 'highpass', 7500, 0.5, 0.05 * v, 0.05); }
  function crackle(t, span) {
    var n = Math.floor(rnd(1, 5));
    for (var i = 0; i < n; i++) { var c = S.ctx, s = c.createBufferSource(), g = c.createGain(), at = t + Math.random() * span; s.buffer = S.noise; g.gain.value = rnd(0.015, 0.05); s.connect(g); g.connect(S.master); s.start(at, Math.random() * 1.9, 0.003); }
  }

  // mỗi nhịp 8 ô (móc đơn) — ô lẻ lùi lại một chút để có swing
  function stepTime(base, i) { var beat = Math.floor(i / 2), off = i % 2; return base + beat * SPB + (off ? SPB * SWING : 0); }
  function scheduleBar(t0) {
    var P = PROGS[S.prog], ch = P[S.bar % 4], hum = function () { return rnd(-0.008, 0.008); };
    var breakdown = S.bar % 16 >= 14; // hai ô nhịp nghỉ trống cho "thở"
    // hợp âm: rải nhẹ từ dưới lên
    ch[1].forEach(function (m, j) { keys(m, t0 + j * 0.018 + hum(), SPB * 3.6, 0.075 + Math.random() * 0.02, false); });
    if (Math.random() < 0.45) ch[1].slice(1).forEach(function (m, j) { keys(m, stepTime(t0, 5) + j * 0.015, SPB * 1.2, 0.05, false); });
    bass(ch[0], t0, SPB * 1.6); bass(ch[0] + (Math.random() < 0.4 ? 7 : 0), stepTime(t0, 5), SPB * 1.2);
    if (!breakdown) {
      kick(t0 + hum(), 1); kick(stepTime(t0, 5) + hum(), 0.8); if (Math.random() < 0.35) kick(stepTime(t0, 3) + hum(), 0.55);
      snare(stepTime(t0, 2) + hum(), 1); snare(stepTime(t0, 6) + hum(), 0.95);
      for (var i = 0; i < 8; i++) if (Math.random() < 0.92) hat(stepTime(t0, i) + hum(), i % 2 ? 0.6 : 1);
    }
    // giai điệu thưa, nốt trong hợp âm lên một quãng tám
    for (var b = 0; b < 4; b++) if (Math.random() < (breakdown ? 0.5 : 0.3)) { var mm = ch[1][Math.floor(Math.random() * ch[1].length)] + 12; keys(mm, stepTime(t0, b * 2 + (Math.random() < 0.5 ? 1 : 0)), SPB * 0.9, 0.045, true); }
    crackle(t0, SPB * 4);
    S.bar++;
    if (S.bar % 16 === 0) S.prog = (S.prog + 1 + Math.floor(Math.random() * (PROGS.length - 1))) % PROGS.length;
  }
  function tick() {
    if (!S.ctx) return;
    while (S.next < S.ctx.currentTime + 0.6) { scheduleBar(S.next); S.next += SPB * 4; }
  }

  function start() {
    if (!S.ctx && !setup()) return false;
    if (S.ctx.state === 'suspended') S.ctx.resume();
    if (!S.playing) {
      S.playing = true; S.next = S.ctx.currentTime + 0.15; S.bar = 0; S.prog = Math.floor(Math.random() * PROGS.length);
      tick(); S.timer = setInterval(tick, 120);
    }
    var g = S.master.gain, now = S.ctx.currentTime;
    g.cancelScheduledValues(now); g.setValueAtTime(g.value, now); g.linearRampToValueAtTime(S.vol * 0.6, now + 2.5);
    notify(); return true;
  }
  function stop() {
    if (!S.ctx || !S.playing) { S.playing = false; notify(); return; }
    var g = S.master.gain, now = S.ctx.currentTime;
    g.cancelScheduledValues(now); g.setValueAtTime(g.value, now); g.linearRampToValueAtTime(0, now + 0.8);
    S.playing = false; clearInterval(S.timer); S.timer = null;
    setTimeout(function () { if (!S.playing && S.ctx) S.ctx.suspend(); }, 900);
    notify();
  }
  function notify() { S.listeners.forEach(function (fn) { try { fn(api.state()); } catch (e) { /* bỏ qua */ } }); }

  var api = {
    supported: function () { return !!(window.AudioContext || window.webkitAudioContext); },
    toggle: function () { S.want = !S.want; save(); if (S.want) start(); else stop(); return S.want; },
    setVol: function (v) { S.vol = Math.max(0, Math.min(1, +v)); save(); if (S.ctx && S.playing) { var g = S.master.gain, now = S.ctx.currentTime; g.cancelScheduledValues(now); g.setValueAtTime(g.value, now); g.linearRampToValueAtTime(S.vol * 0.6, now + 0.2); } notify(); },
    state: function () { return { on: S.playing, want: S.want, vol: S.vol }; },
    onChange: function (fn) { S.listeners.push(fn); },
    // người chơi đã bật nhạc ở lần trước: tự phát lại ở lần bấm đầu tiên (trình duyệt chặn tự phát khi chưa tương tác)
    resumeOnGesture: function () {
      if (!S.want) return;
      var go = function () { document.removeEventListener('pointerdown', go, true); document.removeEventListener('keydown', go, true); if (S.want && !S.playing) start(); };
      document.addEventListener('pointerdown', go, true); document.addEventListener('keydown', go, true);
    }
  };
  window.G = window.G || {}; window.G.Music = api;
})();

;
/* ===== js/card.js ===== */
/* Một Đời — ảnh "thẻ cuộc đời" 1080×1350 để đăng Facebook/TikTok/Zalo: chân dung pixel, các mốc chính, văn bia,
   bản đồ đời người theo mức hạnh phúc và những khoảnh khắc đáng nhớ. Vẽ bằng canvas, không gửi dữ liệu đi đâu. */
(function () {
  'use strict';
  var W = 1080, H0 = 1350; // v6.6: khổ 4:5 (1080×1350) hoặc dọc 9:16 (1080×1920)
  var C = { bg1: '#0a1520', bg2: '#13283b', gold: '#d9b26a', gold2: '#f0cf8e', text: '#f3ede2', muted: '#9fb0c2', line: 'rgba(217,178,106,.35)', tile: 'rgba(255,255,255,.05)' };
  var FD = '"Playfair Display", Lora, "Noto Serif", "Times New Roman", serif', FB = '"Be Vietnam Pro", system-ui, sans-serif', FL = 'Lora, "Noto Serif", "Times New Roman", serif';

  function wrap(ctx, text, maxW, maxLines) {
    var words = String(text || '').split(/\s+/), lines = [], cur = '';
    words.forEach(function (w) { var t = cur ? cur + ' ' + w : w; if (ctx.measureText(t).width > maxW && cur) { lines.push(cur); cur = w; } else cur = t; });
    if (cur) lines.push(cur);
    if (maxLines && lines.length > maxLines) { lines = lines.slice(0, maxLines); var last = lines[maxLines - 1]; while (ctx.measureText(last + '…').width > maxW && last.length) last = last.slice(0, -1); lines[maxLines - 1] = last.replace(/[\s,.;:]+$/, '') + '…'; }
    return lines;
  }
  function round(ctx, x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
  function img(svg) {
    return new Promise(function (ok) {
      if (!svg) return ok(null);
      var im = new Image(); im.onload = function () { ok(im); }; im.onerror = function () { ok(null); };
      im.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
    });
  }
  function fit(ctx, text, font, size, maxW, min) { var s = size; do { ctx.font = font.replace('%', s); s -= 2; } while (ctx.measureText(text).width > maxW && s > min); }

  // sum: tóm tắt cuộc đời (E.share.summary) · avatarSvg: chân dung pixel (tùy chọn)
  function draw(sum, avatarSvg, fmt) {
    var H = fmt === 'story' ? 1920 : H0, story = fmt === 'story';
    var cv = document.createElement('canvas'); cv.width = W; cv.height = H;
    var ctx = cv.getContext('2d');
    // font web chỉ tải phần ký tự tiếng Việt khi được dùng — tải trước đúng đoạn chữ sẽ vẽ để không vỡ dấu
    var all = [sum.n, sum.y, sum.w, sum.c, sum.o, sum.jt, sum.nw, sum.rt || '', (sum.ach || []).join(' '), (sum.st || []).join(' '), (sum.mem || []).join(' '), 'THÀNH TỰU Thế hệ thứ', 'MỘT ĐỜI KHOẢNH KHẮC ĐÁNG NHỚ tuổi người con tài sản cuối đời nghề chính kỳ vọng Mất ở vì'].join(' ');
    var loads = document.fonts && document.fonts.load ? ['italic 500 29px Lora', '800 76px "Playfair Display"', '700 40px "Playfair Display"', '500 26px "Be Vietnam Pro"', '700 26px "Be Vietnam Pro"', '600 20px "Be Vietnam Pro"'].map(function (f) { return document.fonts.load(f, all).catch(function () { }); }) : [];
    var ready = Promise.all(loads).then(function () { return document.fonts && document.fonts.ready; });
    return ready.then(function () { return img(avatarSvg); }).then(function (av) {
      var g = ctx.createLinearGradient(0, 0, 0, H); g.addColorStop(0, C.bg1); g.addColorStop(1, C.bg2);
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
      // khung viền vàng
      ctx.strokeStyle = C.line; ctx.lineWidth = 2; round(ctx, 36, 36, W - 72, H - 72, 28); ctx.stroke();
      // đầu thẻ
      ctx.fillStyle = C.gold; ctx.font = '700 26px ' + FB; ctx.textAlign = 'center';
      ctx.fillText('M Ộ T   Đ Ờ I', W / 2, 100);
      // mặt trời trên đường chân trời (logo)
      ctx.strokeStyle = C.gold; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(W / 2, 150, 34, Math.PI, 0); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(W / 2 - 60, 150); ctx.lineTo(W / 2 + 60, 150); ctx.stroke();
      ctx.fillStyle = C.gold2; ctx.beginPath(); ctx.arc(W / 2 + 22, 126, 7, 0, Math.PI * 2); ctx.fill();
      var y = story ? 260 : 180;
      if (av) {
        var s = story ? 260 : 160; ctx.fillStyle = 'rgba(255,255,255,.06)'; round(ctx, W / 2 - s / 2 - 12, y, s + 24, s + 24, 20); ctx.fill();
        ctx.imageSmoothingEnabled = true; ctx.drawImage(av, W / 2 - s / 2, y + 12, s, s); y += s + (story ? 80 : 50);
      } else y += 30;
      // tên
      ctx.fillStyle = C.text; fit(ctx, sum.n, '800 %px ' + FD, 76, W - 160, 40); ctx.fillText(sum.n, W / 2, y + 40); y += 70;
      ctx.fillStyle = C.muted; ctx.font = '500 30px ' + FB;
      fit(ctx, sum.y + ' · ' + sum.w, '500 %px ' + FB, 30, W - 160, 20); ctx.fillText(sum.y + ' · ' + sum.w, W / 2, y + 20); y += 50;
      var tag = [sum.rt || '', sum.g > 1 ? 'Thế hệ thứ ' + sum.g + ' của gia đình' : ''].filter(Boolean).join(' · ');
      if (tag) { ctx.fillStyle = C.gold; fit(ctx, tag, '600 %px ' + FB, 26, W - 160, 18); ctx.fillText(tag, W / 2, y + 14); y += 44; }
      if (sum.c) { ctx.font = '500 26px ' + FB; ctx.fillStyle = C.muted; var cl = 'Mất ở tuổi ' + sum.a + ' vì ' + sum.c; fit(ctx, cl, '500 %px ' + FB, 26, W - 160, 18); ctx.fillText(cl, W / 2, y + 14); y += 44; }
      // văn bia
      ctx.fillStyle = C.gold2; ctx.font = 'italic 500 32px ' + FL;
      ctx.font = 'italic 500 29px ' + FL; wrap(ctx, sum.o, W - 200, 3).forEach(function (ln) { ctx.fillText(ln, W / 2, y + 28); y += 40; });
      y += story ? 60 : 24;
      // các ô số liệu
      var tiles = [[String(sum.a), 'tuổi' + (sum.e ? ' (kỳ vọng ' + String(sum.e).replace('.', ',') + ')' : '')], [sum.jt || '—', 'nghề chính'], [String(sum.kd || 0), 'người con'], [sum.nw || '—', 'tài sản cuối đời']];
      var tw = (W - 160 - 3 * 20) / 4;
      tiles.forEach(function (t, i) {
        var x = 80 + i * (tw + 20);
        ctx.fillStyle = C.tile; round(ctx, x, y, tw, 120, 16); ctx.fill();
        ctx.fillStyle = C.gold;
        ctx.font = '700 40px ' + FD;
        if (ctx.measureText(t[0]).width > tw - 24) { // tên nghề dài: xuống hai dòng
          ctx.font = '700 22px ' + FD; var tl = wrap(ctx, t[0], tw - 20, 2);
          tl.forEach(function (ln, j) { ctx.fillText(ln, x + tw / 2, y + (tl.length > 1 ? 40 + j * 26 : 58)); });
        } else ctx.fillText(t[0], x + tw / 2, y + 58);
        ctx.fillStyle = C.muted; fit(ctx, t[1], '500 %px ' + FB, 20, tw - 20, 14); ctx.fillText(t[1], x + tw / 2, y + 94);
      });
      y += story ? 190 : 150;
      // thành tựu của đời này (huy hiệu)
      var ach = (sum.ach || []).slice(0, story ? 4 : 3);
      if (ach.length) {
        ctx.font = '600 24px ' + FB; var pw = ach.map(function (a) { return Math.min(ctx.measureText(a).width + 40, (W - 160 - (ach.length - 1) * 14) / ach.length); }), tot = pw.reduce(function (s2, x) { return s2 + x; }, 0) + (ach.length - 1) * 14, px = (W - tot) / 2;
        ach.forEach(function (a, i) { ctx.fillStyle = 'rgba(217,178,106,.14)'; round(ctx, px, y, pw[i], 50, 25); ctx.fill(); ctx.strokeStyle = C.line; ctx.lineWidth = 1.5; round(ctx, px, y, pw[i], 50, 25); ctx.stroke(); ctx.fillStyle = C.gold2; fit(ctx, a, '600 %px ' + FB, 24, pw[i] - 24, 14); ctx.fillText(a, px + pw[i] / 2, y + 33); px += pw[i] + 14; });
        y += story ? 120 : 80;
      }
      // bản đồ đời người: mỗi ô một năm, đậm = hạnh phúc
      var m = String(sum.m || ''), per = 25, cs = story ? 30 : 28, gap = story ? 7 : 5, rows = Math.max(1, Math.ceil(m.length / per));
      var gx = (W - (per * cs + (per - 1) * gap)) / 2;
      ctx.textAlign = 'left'; ctx.fillStyle = C.muted; ctx.font = '600 20px ' + FB; ctx.fillText('MỖI Ô LÀ MỘT NĂM — ĐẬM HƠN LÀ HẠNH PHÚC HƠN', gx, y); y += 16;
      for (var i = 0; i < m.length; i++) {
        var r = Math.floor(i / per), c = i % per, h = +m[i];
        ctx.fillStyle = 'rgba(217,178,106,' + (0.12 + h / 9 * 0.88).toFixed(2) + ')';
        round(ctx, gx + c * (cs + gap), y + r * (cs + gap), cs, cs, 6); ctx.fill();
      }
      y += rows * (cs + gap) + (story ? 80 : 30);
      // khoảnh khắc đáng nhớ (ưu tiên những dòng người chơi đánh dấu ⭐)
      var moments = (sum.st && sum.st.length ? sum.st : sum.mem || []).slice(0, story ? 6 : 3);
      if (moments.length && y < H - 230) {
        ctx.fillStyle = C.gold; ctx.font = '700 22px ' + FB; ctx.fillText((sum.st && sum.st.length ? '⭐ ' : '') + 'KHOẢNH KHẮC ĐÁNG NHỚ', gx, y); y += 40;
        moments.forEach(function (x) {
          var p = String(x).split('|'), age = p.length > 1 ? p[0] + ' tuổi — ' : '', t = p.length > 1 ? p.slice(1).join('|') : p[0];
          ctx.font = (story ? '500 28px ' : '500 25px ') + FB; ctx.fillStyle = C.text;
          wrap(ctx, age + t, W - 2 * gx, story ? 3 : 2).forEach(function (ln) { if (y < H - 115) { ctx.fillText(ln, gx, y); y += story ? 40 : 34; } });
          y += story ? 18 : 8;
        });
      }
      // chân thẻ
      ctx.textAlign = 'center'; ctx.fillStyle = C.muted; ctx.font = '500 22px ' + FB;
      var host = (typeof location !== 'undefined' && location.host && !/^localhost|127\./.test(location.host)) ? location.host : 'Một Đời';
      ctx.fillText(host + ' · Bạn sẽ sống một đời như thế nào?', W / 2, H - 70);
      return cv;
    });
  }
  function fileName(sum) { return 'mot-doi-' + String(sum.n || 'cuoc-doi').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/đ/g, 'd').replace(/Đ/g, 'D').replace(/[^A-Za-z0-9]+/g, '-').replace(/^-|-$/g, '').toLowerCase() + '.png'; }
  function toBlob(cv) { return new Promise(function (ok) { cv.toBlob(function (b) { ok(b); }, 'image/png'); }); }
  function download(sum, avatarSvg, fmt) {
    return draw(sum, avatarSvg, fmt).then(toBlob).then(function (b) {
      var a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = fileName(sum);
      document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 1500);
      return true;
    });
  }
  // chia sẻ trực tiếp ảnh (điện thoại); không hỗ trợ thì tải về
  function share(sum, avatarSvg, fmt) {
    return draw(sum, avatarSvg, fmt).then(toBlob).then(function (b) {
      var f = typeof File !== 'undefined' ? new File([b], fileName(sum), { type: 'image/png' }) : null;
      if (f && navigator.canShare && navigator.canShare({ files: [f] })) return navigator.share({ files: [f], title: 'Một Đời — ' + sum.n }).then(function () { return true; }, function () { return false; });
      return download(sum, avatarSvg, fmt);
    });
  }
  window.G = window.G || {}; window.G.LifeCard = { draw: draw, download: download, share: share, fileName: fileName };
})();

;
/* ===== js/memorial-history.js ===== */
/* Completed lives are archived separately from saves that are still in progress. */
(function(G){'use strict';var MEM='mkn.memorial',LAST='mkn.lastEnd';
function save(l,stages,cohort,store,labels){if(!l||l.alive||!l.death||!l.id)return false;var rows=store.get(MEM,[]);if(!Array.isArray(rows))rows=[];var old=rows.find(function(x){return x&&x.id===l.id;});var record={id:l.id,name:l.name,sub:l.nameSub,where:labels.where,years:labels.years,age:l.death.age,cause:l.death.cause,summary:labels.summary,words:l.finalWords,refl:l.refl,yrs:l.yrs,e0sex:l.e0sex,age2:l.age,savedAt:Date.now(),fin:stages&&stages.length?stages:old&&old.fin||[]};rows=rows.filter(function(x){return x&&x.id!==l.id;});rows.push(record);if(!store.set(MEM,rows.slice(-60)))return false;l.flags=l.flags||{};l.flags.memorialSaved=true;store.set(LAST,{life:l,cohort:cohort});return true;}
function recover(store,labels){var last=store.get(LAST,null),l=last&&last.life;if(!l||l.alive||!l.death||l.flags&&(l.flags.memorialSaved||l.flags.memorialDeleted))return false;return save(l,null,last.cohort,store,labels(l));}
function removed(store,id){var last=store.get(LAST,null);if(last&&last.life&&last.life.id===id){last.life.flags=last.life.flags||{};last.life.flags.memorialDeleted=true;store.set(LAST,last);}}
G.MemorialHistory={save:save,recover:recover,removed:removed};
})(globalThis.G);

;
