/* ===== js/life91.js ===== */
/* Một Đời — v7.2.0: drama ở khắp nơi (ngẫu nhiên, tỉ lệ thấp, không phải năm nào cũng có)
   · công sở: bị cướp công, sếp đổ lỗi, tin đồn tình cảm nơi công sở, phe phái trước đợt bổ nhiệm, gửi nhầm tin nói xấu sếp vào nhóm chung,
     "con ông cháu cha" vào làm, danh sách cắt giảm, tiệc tất niên quá chén, bạn thân thành sếp mình, bị sếp quấy rối
   · hàng xóm, chung cư: hát karaoke đến nửa đêm, lấn ranh giới đất, chó thả rông, tranh cãi phí quản lý và chỗ đỗ xe
   · phòng trọ: bạn cùng phòng trốn tiền điện nước
   · mạng xã hội: bị "bóc phốt", bài đăng bất ngờ lan truyền, cãi nhau trong hội nhóm
   · trường học: nhóm bạn tẩy chay, bị nghi gian lận trong giờ thi
   · bạn bè: họp lớp so bì, quỹ du lịch của hội bạn "bốc hơi"
   · đường phố: va quẹt xe, người kia đòi tiền
   Mỗi tình huống chỉ gặp tối đa một hai lần trong đời, tỉ lệ thấp nên nhiều đời không gặp. */
(function (G) {
  'use strict';
  var U = G.U, E = G.E, H = E.H, SC = E.SC, isVN = H.isVN;
  function pick(r, a) { return U.pick(r, a); }
  function ch(r, p) { return r() < p; }
  function fx(l, o) { H.fx(l, o); }
  function mo(l, v) { return H.money(l, v); }
  function cash(l, x, why) { H.cash(l, x, why); }
  function stress(l, x) { if (l.mind) l.mind.stress = U.clamp(l.mind.stress + x, 0, 100); }
  function free(l) { return l.alive && !(l.jailUntil != null && l.age < l.jailUntil) && !(l.abroad && l.abroad.trapped) && !(l.flags.military && l.age < l.flags.military); }
  function T(id, when, p, cd, max) { E.TRIG.push({ id: id, when: function (l, a) { return free(l) && when(l, a); }, p: p, cd: cd || 5, max: max || 1 }); }
  function V(l, tr) { return isVN(l) && l.cur === 'vnd' && !(l.abroad && l.abroad.perm) ? tr : tr / 90 * l.base; }
  function office(l) { if (!l.job || l.retired || (E.isCrime && E.isCrime(l)) || l.job.fam) return false; var c = E.jobDef && E.jobDef(l); return !!c && !c.fame && c.cat !== 'farm' && c.cat !== 'biz' && !(E.isFreelanceJob && E.isFreelanceJob(l)) && (!H.isEmployee || H.isEmployee(l)); }
  function rep(l, d) { if (l.job) l.job.rep = U.clamp((l.job.rep == null ? 50 : l.job.rep) + d, 0, 100); }
  function name(l, r, sx) { return H.stranger(l, r, sx || (r() < 0.5 ? 'M' : 'F')); }
  function given(l, n) { var w = String(n).split(' '); return l.pool === 'vn' ? w[w.length - 1] : w[0]; }

  // ===================================================================
  // 1. CÔNG SỞ
  // ===================================================================
  SC('cs_cuop_cong', {
    title: 'Bị cướp công',
    prep: function (l, r) { return { n: name(l, r) }; },
    valid: office,
    text: function (l, d) { return 'Bản kế hoạch bạn thức trắng ba đêm để làm, trong buổi họp ' + d.n + ' trình bày như ý tưởng của mình. Sếp khen nức nở, không ai nhắc đến tên bạn.'; },
    opts: [
      { k: 'noi', l: 'Lên tiếng ngay trong buổi họp', ai: { w: 0.7, risk: 1 }, run: function (l, r, log, d) { if (ch(r, 0.5)) { rep(l, 8); log('Bạn bình tĩnh mở lịch sử chỉnh sửa tài liệu. Cả phòng im lặng, sếp gật đầu: "Vậy ra là của em." ' + d.n + ' đỏ mặt cúi xuống.', 'good'); fx(l, { hap: 3 }); } else { rep(l, -4); log('Bạn lên tiếng, nhưng bị cho là "tranh công, thiếu tinh thần tập thể". Không khí phòng họp đông cứng.', 'bad'); stress(l, 8); } } },
      { k: 'rieng', l: 'Gặp riêng sếp, đưa bằng chứng', ai: { w: 1.1, smart: 1 }, run: function (l, r, log, d) { rep(l, ch(r, 0.65) ? 6 : 1); log('Bạn gặp riêng sếp, đưa email và bản nháp cũ. Sếp không nói gì nhiều, nhưng từ đó giao việc quan trọng thẳng cho bạn.', 'neutral'); } },
      { k: 'nhin', l: 'Nuốt cục tức, rút kinh nghiệm', ai: { w: 0.8 }, run: function (l, r, log, d) { stress(l, 6); fx(l, { hap: -3 }); log('Bạn im lặng. Từ đó việc gì cũng gửi email có đồng gửi sếp, để lại dấu vết.', 'neutral'); } }
    ]
  });
  T('cs_cuop_cong', function (l, a) { return office(l) && a >= 22 && a <= 55; }, 0.025, 6, 1);
  SC('cs_do_loi', {
    title: 'Sếp đổ lỗi',
    valid: office,
    prep: function (l, r) { return { why: pick(r, ['một hợp đồng bị hủy', 'khách hàng lớn khiếu nại', 'số liệu báo cáo lên trên bị sai', 'dự án trễ hạn hai tháng']) }; },
    text: function (l, d) { return 'Ban giám đốc truy trách nhiệm vì ' + d.why + '. Sếp trực tiếp của bạn, người ký duyệt mọi thứ, quay sang bảo: "Phần này em phụ trách mà."'; },
    opts: [
      { k: 'chung_minh', l: 'Đưa ra email, biên bản chứng minh', ai: { w: 1, smart: 1 }, run: function (l, r, log) { if (ch(r, 0.6)) { log('Bạn đưa đủ email phê duyệt. Ban giám đốc hiểu chuyện, sếp bị khiển trách. Từ đó sếp nhìn bạn không mấy thiện cảm.', 'neutral'); rep(l, 3); stress(l, 5); } else { log('Chứng cứ chưa đủ thuyết phục, bạn vẫn bị trừ thưởng quý.', 'bad'); cash(l, -V(l, 5), 'Bị trừ thưởng vì lỗi dự án'); stress(l, 8); } } },
      { k: 'nhan', l: 'Nhận lỗi thay để giữ êm', ai: { w: 0.7 }, run: function (l, r, log) { cash(l, -V(l, 4), 'Bị trừ thưởng vì nhận lỗi thay'); rep(l, -3); log('Bạn nhận lỗi, bị trừ thưởng. Sếp vỗ vai: "Anh nhớ ơn em." Bạn không chắc câu ấy đáng giá bao nhiêu.', 'neutral'); if (ch(r, 0.3)) l.flags.bossOwes = l.age; } },
      { k: 'nghi', l: 'Nộp đơn nghỉ việc', ai: { w: 0.3, risk: 1 }, run: function (l, r, log) { log('Bạn đặt đơn nghỉ việc lên bàn. "Em không làm ở nơi mình phải gánh lỗi cho người khác."', 'neutral'); l.flags.needJob = true; if (E.quitJob) E.quitJob(l, log); else { l.lastJob = l.job; l.job = null; } fx(l, { hap: 2 }); stress(l, -4); } }
    ]
  });
  T('cs_do_loi', function (l, a) { return office(l) && a >= 23 && a <= 58; }, 0.02, 6, 1);
  SC('cs_tin_don', {
    title: 'Tin đồn ở công ty',
    prep: function (l, r) { var sx = H.partnerSex ? H.partnerSex(l, r) : (l.sex === 'M' ? 'F' : 'M'); return { n: name(l, r, sx) }; },
    valid: office,
    text: function (l, d) { return 'Chỉ vì vài lần đi ăn trưa và về muộn cùng ' + d.n + ' để kịp dự án, cả công ty xì xào hai người "có gì đó".' + (l.partner && l.partner.status !== 'dating' ? ' Tin đồn đến tai cả người nhà bạn.' : ''); },
    opts: [
      { k: 'ke', l: 'Mặc kệ, thanh giả tự thanh', ai: { w: 1 }, run: function (l, r, log, d) { log('Bạn mặc kệ. Vài tháng sau có chuyện khác để bàn, tin đồn tự tắt.', 'neutral'); stress(l, 3); } },
      { k: 'xa', l: 'Giữ khoảng cách với ' + 'người kia', ai: { w: 0.9 }, run: function (l, r, log, d) { log('Bạn chủ động ăn trưa một mình, họp thì gọi thêm người. ' + d.n + ' buồn vì mất một người đồng nghiệp hợp cạ.', 'neutral'); fx(l, { soc: -1 }); } },
      { k: 'noi_thang', l: 'Nói thẳng trong buổi họp phòng', ai: { w: 0.4, risk: 1 }, run: function (l, r, log, d) { if (ch(r, 0.5)) { log('Bạn nói thẳng: "Ai có gì thì hỏi trực tiếp." Cả phòng ngượng, tin đồn chấm dứt.', 'good'); fx(l, { hap: 2 }); } else { log('Càng thanh minh, mọi người càng tin là có chuyện. Bạn mệt mỏi suốt mấy tháng.', 'bad'); stress(l, 8); } } }
    ]
  });
  T('cs_tin_don', function (l, a) { return office(l) && a >= 22 && a <= 50; }, 0.02, 8, 1);
  SC('cs_phe_phai', {
    title: 'Chọn phe',
    prep: function (l, r) { return { a: name(l, r, 'M'), b: name(l, r, 'F') }; },
    valid: function (l) { return office(l) && (l.job.rank || 0) >= 1; },
    text: function (l, d) { return 'Trưởng phòng sắp nghỉ hưu. Hai phó phòng, anh ' + given(l, d.a) + ' và chị ' + given(l, d.b) + ', đều muốn lên thay, cả phòng chia hai phe. Cả hai đều mời bạn đi cà phê riêng.'; },
    opts: [
      { k: 'a', l: function (l, d) { return 'Theo phe anh ' + given(l, d.a); }, ai: { w: 0.7, risk: 0.8 }, run: function (l, r, log, d) { side(l, r, log, d.a); } },
      { k: 'b', l: function (l, d) { return 'Theo phe chị ' + given(l, d.b); }, ai: { w: 0.7, risk: 0.8 }, run: function (l, r, log, d) { side(l, r, log, d.b); } },
      { k: 'trung', l: 'Đứng giữa, chỉ lo làm tốt việc của mình', ai: { w: 1.1 }, run: function (l, r, log) { log('Bạn đứng giữa, ai hỏi cũng chỉ cười. Ai lên cũng không ưu ái bạn, nhưng cũng không ai làm khó bạn.', 'neutral'); } }
    ]
  });
  function side(l, r, log, n) {
    if (ch(r, 0.5)) { rep(l, 10); log(n + ' được bổ nhiệm làm trưởng phòng và nhớ ơn những người ủng hộ mình. Bạn được giao phụ trách mảng quan trọng.', 'good'); if (l.job) l.job.rankSince = Math.max(0, (l.job.rankSince || l.age) - 1); }
    else { rep(l, -8); log('Phe bạn chọn thua. Trưởng phòng mới lạnh nhạt, những việc khó cứ dồn về bạn.', 'bad'); stress(l, 10); }
  }
  T('cs_phe_phai', function (l, a) { return office(l) && (l.job.rank || 0) >= 1 && a >= 27 && a <= 55; }, 0.02, 8, 1);
  SC('cs_gui_nham', {
    title: 'Gửi nhầm tin nhắn',
    valid: office,
    text: 'Bạn định nhắn cho bạn thân một tràng than thở về sếp, nhưng bấm nhầm vào nhóm chat chung của cả phòng, có cả sếp. Dấu "đã xem" hiện lên từng người một.',
    opts: [
      { k: 'thu_hoi', l: 'Thu hồi ngay, giả vờ như không có gì', ai: { w: 1 }, run: function (l, r, log) { if (ch(r, 0.5)) log('Bạn thu hồi kịp, hình như chưa ai chụp màn hình. Bạn thở phào, tim vẫn đập thình thịch cả buổi.', 'neutral'); else { log('Thu hồi rồi nhưng có người đã chụp lại. Ảnh chụp màn hình lan khắp công ty.', 'bad'); rep(l, -8); stress(l, 10); } } },
      { k: 'xin_loi', l: 'Chủ động gặp sếp xin lỗi', ai: { w: 0.8, moral: 1 }, run: function (l, r, log) { if (ch(r, 0.6)) { log('Bạn gõ cửa phòng sếp xin lỗi. Sếp im lặng một lúc rồi bật cười: "Ít ra em nói thật. Góp ý thì cứ nói thẳng với tôi."', 'good'); rep(l, 2); } else { log('Sếp nhận lời xin lỗi, nhưng từ đó bạn không còn được mời họp những việc quan trọng.', 'bad'); rep(l, -6); } } },
      { k: 'dua', l: 'Nhắn thêm "đùa thôi mọi người ơi 😅"', ai: { w: 0.5 }, run: function (l, r, log) { log('Cả nhóm thả biểu tượng cười, sếp im lặng. Sự im lặng ấy kéo dài suốt cuộc họp tuần sau.', 'neutral'); rep(l, -3); stress(l, 5); } }
    ]
  });
  T('cs_gui_nham', function (l, a) { return office(l) && a >= 20 && a <= 55; }, 0.012, 10, 1);
  SC('cs_con_ong_chau_cha', {
    title: 'Nhân viên mới "có ô dù"',
    prep: function (l, r) { return { n: name(l, r) }; },
    valid: office,
    text: function (l, d) { return d.n + ' mới vào làm, là cháu của một vị lãnh đạo cấp trên. Việc gì khó cũng đẩy sang bạn, lỗi thì không ai dám nói. Mới nửa năm đã có tin ' + given(l, d.n) + ' sắp được đề bạt.'; },
    opts: [
      { k: 'kem', l: 'Kèm cặp tử tế, coi như đầu tư quan hệ', ai: { w: 1, soc: 1 }, run: function (l, r, log, d) { if (ch(r, 0.5)) { rep(l, 6); log(d.n + ' học được việc, sau này lên chức vẫn nhớ người đã chỉ bảo mình.', 'good'); } else { log('Bạn kèm cặp hết lòng. Một năm sau ' + d.n + ' lên làm phó phòng, nhìn bạn như người lạ.', 'bad'); fx(l, { hap: -3 }); } } },
      { k: 'tu_choi', l: 'Từ chối làm thay phần việc của người ta', ai: { w: 0.8, risk: 0.6 }, run: function (l, r, log, d) { rep(l, -3); log('Bạn từ chối khéo. Từ đó bạn bị đánh giá "thiếu hợp tác", nhưng ít ra đêm được về đúng giờ.', 'neutral'); } },
      { k: 'tim_viec', l: 'Âm thầm tìm chỗ làm mới', ai: { w: 0.5 }, run: function (l, r, log, d) { l.flags.lookJob = l.age; log('Bạn bắt đầu cập nhật hồ sơ xin việc. "Chỗ này không phải nơi để mình lớn lên."', 'neutral'); } }
    ]
  });
  T('cs_con_ong_chau_cha', function (l, a) { return office(l) && a >= 25 && a <= 55; }, 0.015, 8, 1);
  SC('cs_cat_giam', {
    title: 'Danh sách cắt giảm',
    prep: function (l, r) { return { n: name(l, r) }; },
    valid: office,
    text: function (l, d) { return 'Công ty phải cắt giảm nhân sự. Sếp gọi bạn vào, nói khẽ: "Phòng mình phải cắt một người, giữa em và ' + d.n + '. ' + given(l, d.n) + ' đang nuôi con nhỏ một mình. Em nghĩ sao?"'; },
    opts: [
      { k: 'giu', l: 'Xin được ở lại, mình cũng cần công việc', ai: { w: 1.1 }, run: function (l, r, log, d) { log('Bạn xin ở lại. ' + d.n + ' ôm thùng đồ ra về, bạn không dám nhìn theo. Nhiều đêm sau đó bạn vẫn nghĩ về chuyện ấy.', 'neutral'); stress(l, 6); fx(l, { karma: -1 }); } },
      { k: 'nhuong', l: 'Tình nguyện nghỉ, nhận trợ cấp thôi việc', ai: { w: 0.4, moral: 1.2 }, run: function (l, r, log, d) { var v = (l.income || l.base) * 0.25; cash(l, v, 'Trợ cấp thôi việc'); log('Bạn tình nguyện nghỉ, nhận ' + mo(l, v) + ' trợ cấp. ' + d.n + ' khóc khi biết chuyện: "Em sẽ không quên đâu."', 'neutral'); fx(l, { karma: 8 }); l.flags.needJob = true; if (E.quitJob) E.quitJob(l, log); else { l.lastJob = l.job; l.job = null; } } }
    ]
  });
  T('cs_cat_giam', function (l, a) { return office(l) && a >= 25 && a <= 58; }, 0.008, 10, 1);
  SC('cs_tat_nien', {
    title: 'Tiệc tất niên',
    valid: office,
    text: 'Tiệc tất niên công ty, rượu bia ê hề. Mấy anh bên kinh doanh cứ ép từng ly, "không uống là không nể anh em".',
    opts: [
      { k: 'uong', l: 'Uống tới bến cho vui', ai: { w: 0.7, risk: 1 }, run: function (l, r, log) { if (ch(r, 0.4)) { log(pick(r, ['Bạn say, cầm micro hát ba bài liền, video lan khắp nhóm chat công ty. Ba tháng sau vẫn bị nhắc lại.', 'Say quá, bạn ôm vai sếp tổng gọi "anh trai". Hôm sau đi làm muốn độn thổ.']), 'neutral'); rep(l, -2); } else { log('Uống nhiều nhưng vui, cả phòng thân nhau hơn hẳn.', 'good'); fx(l, { soc: 3 }); } fx(l, { hea: -2 }); } },
      { k: 'tu_choi', l: 'Từ chối, uống nước ngọt', ai: { w: 1, moral: 0.5 }, run: function (l, r, log) { log('Bạn cười xòa, cầm ly nước ngọt cụng với mọi người. Có người bĩu môi, nhưng sáng hôm sau chỉ mình bạn tỉnh táo đi làm.', 'neutral'); } },
      { k: 've_som', l: 'Viện cớ về sớm', ai: { w: 0.6 }, run: function (l, r, log) { log('Bạn xin về sớm vì "nhà có việc". Tiệc vẫn vui, chỉ là bạn bỏ lỡ vài câu chuyện.', 'neutral'); fx(l, { soc: -1 }); } }
    ]
  });
  T('cs_tat_nien', function (l, a) { return office(l) && isVN(l) && a >= 20 && a <= 58; }, 0.03, 6, 2);
  SC('cs_ban_thanh_sep', {
    title: 'Bạn thân thành sếp',
    prep: function (l) { var f = E.friendsOf ? E.friendsOf(l)[0] : null; return { n: f ? f.name : '' }; },
    valid: function (l) { return office(l) && !!(E.friendsOf && E.friendsOf(l).length); },
    text: function (l, d) { return 'Công ty tuyển trưởng phòng mới, người trúng tuyển lại là ' + d.n + ', bạn thân của bạn. Ngày đầu tiên, cả phòng nhìn hai người dò xét.'; },
    opts: [
      { k: 'ro_rang', l: 'Thống nhất: ở công ty là sếp, ra ngoài là bạn', ai: { w: 1.1, smart: 1 }, run: function (l, r, log, d) { log('Hai người nói chuyện thẳng thắn. Ở công ty bạn gọi ' + d.n + ' là "sếp", cuối tuần vẫn đi cà phê như cũ.', 'good'); fx(l, { soc: 2 }); } },
      { k: 'nho', l: 'Nhờ bạn ưu ái một chút', ai: { w: 0.5, risk: 0.6 }, run: function (l, r, log, d) { var f = E.friendsOf(l).filter(function (x) { return x.name === d.n; })[0]; if (ch(r, 0.5)) { rep(l, 4); log(d.n + ' giao cho bạn những dự án hay. Đồng nghiệp xì xào "cánh hẩu".', 'neutral'); } else { if (f) f.close = Math.max(0, (f.close || 60) - 20); log(d.n + ' khó xử: "Mình không thể làm thế." Tình bạn có vết rạn từ đó.', 'bad'); } } },
      { k: 'chuyen', l: 'Xin chuyển phòng cho khỏi khó xử', ai: { w: 0.5 }, run: function (l, r, log, d) { log('Bạn xin chuyển sang phòng khác. Tình bạn giữ được, công việc thì phải làm lại từ đầu với người mới.', 'neutral'); } }
    ]
  });
  T('cs_ban_thanh_sep', function (l, a) { return office(l) && a >= 28 && a <= 50 && !!(E.friendsOf && E.friendsOf(l).length); }, 0.01, 10, 1);
  SC('cs_quay_roi', {
    title: 'Sự quấy rối nơi công sở',
    valid: function (l) { return office(l) && l.age >= 18; },
    text: 'Sếp liên tục nhắn tin riêng lúc khuya, buông những lời bóng gió, có lần cố tình chạm vào người bạn trong thang máy. Bạn thấy khó chịu và sợ hãi.',
    opts: [
      { k: 'to_cao', l: 'Lưu bằng chứng, báo lên phòng nhân sự / công đoàn', ai: { w: 1, moral: 1 }, run: function (l, r, log) { if (ch(r, 0.55)) { log('Bạn lưu lại tin nhắn, gửi lên phòng nhân sự và công đoàn. Sau điều tra, người sếp bị kỷ luật và chuyển công tác. Có vài đồng nghiệp lặng lẽ cảm ơn bạn vì họ cũng từng bị như vậy.', 'good'); fx(l, { hap: 3 }); stress(l, -5); } else { log('Bạn tố cáo, nhưng công ty "xử lý nội bộ" rồi im lặng. Bạn bị cô lập, cuối cùng phải nghỉ việc. Bạn vẫn tin mình đã làm đúng.', 'bad'); stress(l, 12); l.flags.needJob = true; if (E.quitJob) E.quitJob(l, log); else { l.lastJob = l.job; l.job = null; } } H.mem(l, 'Năm bạn lên tiếng về chuyện bị quấy rối ở chỗ làm.', 4); } },
      { k: 'nghi', l: 'Lặng lẽ nghỉ việc, tìm chỗ khác', ai: { w: 0.7 }, run: function (l, r, log) { log('Bạn nộp đơn nghỉ, không nói lý do. Tối hôm ấy bạn kể cho người thân nghe, lần đầu tiên bật khóc.', 'neutral'); stress(l, 6); l.flags.needJob = true; if (E.quitJob) E.quitJob(l, log); else { l.lastJob = l.job; l.job = null; } } },
      { k: 'tu_choi', l: 'Từ chối dứt khoát, giữ khoảng cách', ai: { w: 0.8 }, run: function (l, r, log) { log('Bạn nói rõ: "Mong anh/chị dừng lại." Mọi chuyện dừng, nhưng những đánh giá cuối năm của bạn bỗng thấp hẳn.', 'neutral'); rep(l, -5); stress(l, 8); } }
    ]
  });
  T('cs_quay_roi', function (l, a) { return office(l) && a >= 20 && a <= 45; }, 0.006, 10, 1);

  // ===================================================================
  // 2. HÀNG XÓM, CHUNG CƯ, PHÒNG TRỌ
  // ===================================================================
  SC('hx_karaoke', {
    title: 'Hàng xóm hát karaoke',
    valid: function (l) { return l.indep && isVN(l) && !l.abroad; },
    text: 'Nhà bên cạnh mua dàn loa kẹo kéo, tối nào cũng hát karaoke đến gần nửa đêm. Con nhỏ khóc, người già mất ngủ, bạn sáng ra đi làm với hai mắt thâm quầng.',
    opts: [
      { k: 'sang', l: 'Sang nói chuyện nhẹ nhàng', ai: { w: 1.1, soc: 1 }, run: function (l, r, log) { if (ch(r, 0.55)) log('Bạn sang xin hàng xóm vặn nhỏ sau 10 giờ tối. Họ gãi đầu xin lỗi, còn mời bạn bữa sau sang hát cùng.', 'good'); else { log('Hàng xóm gắt: "Nhà tôi hát nhà tôi!" Hai nhà gặp nhau không chào.', 'bad'); stress(l, 5); } } },
      { k: 'bao', l: 'Báo tổ trưởng dân phố / công an phường', ai: { w: 0.7 }, run: function (l, r, log) { log('Công an phường xuống nhắc nhở, nhà bên bị phạt vì gây ồn ào sau 22 giờ. Tiếng hát tắt hẳn, nhưng ánh mắt hàng xóm thì lạnh đi.', 'neutral'); } },
      { k: 'chiu', l: 'Mua nút bịt tai, chịu đựng', ai: { w: 0.6 }, run: function (l, r, log) { log('Bạn mua nút bịt tai và tập ngủ trong tiếng "Duyên phận". Sau vài tháng, bạn thuộc lòng cả danh sách bài của nhà bên.', 'neutral'); fx(l, { hea: -1 }); stress(l, 4); } }
    ]
  });
  T('hx_karaoke', function (l, a) { return l.indep && isVN(l) && !l.abroad && a >= 20; }, 0.012, 8, 1);
  SC('hx_ranh_gioi', {
    title: 'Tranh chấp ranh giới đất',
    valid: function (l) { return l.ownHouse && !l.urban; },
    text: 'Nhà hàng xóm xây lại tường rào, lấn sang đất nhà bạn gần nửa mét. Họ khăng khăng sổ đỏ nhà họ ghi như thế.',
    opts: [
      { k: 'do_dac', l: 'Mời cán bộ địa chính đo đạc lại', h: function (l) { return 'Phí đo đạc khoảng ' + mo(l, V(l, 3)); }, ai: { w: 1, smart: 1 }, run: function (l, r, log) { cash(l, -V(l, 3), 'Phí đo đạc địa chính'); if (ch(r, 0.65)) log('Địa chính đo lại, đúng là hàng xóm lấn đất. Họ phải lùi tường, hai nhà từ đó chỉ chào nhau qua loa.', 'neutral'); else log('Đo đạc cho thấy mốc giới cũ không rõ ràng. Hai bên đành chia đôi phần tranh chấp.', 'neutral'); } },
      { k: 'nhuong', l: 'Nhường, "bán anh em xa mua láng giềng gần"', ai: { w: 0.8, moral: 0.6 }, run: function (l, r, log) { log('Bạn bỏ qua phần đất nhỏ. Hàng xóm áy náy, Tết năm ấy mang sang biếu cặp bánh chưng.', 'neutral'); fx(l, { karma: 2 }); } },
      { k: 'kien', l: 'Làm đơn ra xã, kiện đến cùng', ai: { w: 0.4, risk: 1 }, run: function (l, r, log) { cash(l, -V(l, 10), 'Chi phí khiếu nại tranh chấp đất'); log('Đơn từ qua lại hai năm trời, hòa giải ở xã rồi lên huyện. Cuối cùng bạn thắng, nhưng hai nhà thành thù.', 'neutral'); stress(l, 12); } }
    ]
  });
  T('hx_ranh_gioi', function (l, a) { return l.ownHouse && !l.urban && isVN(l) && a >= 28; }, 0.012, 10, 1);
  SC('hx_cho_tha_rong', {
    title: 'Chó thả rông',
    valid: function (l) { return l.indep; },
    text: 'Con chó to nhà cuối ngõ không rọ mõm, sáng nào cũng lao ra sủa người đi đường. Hôm qua nó cắn một đứa trẻ trong xóm.',
    opts: [
      { k: 'noi', l: 'Cùng hàng xóm sang yêu cầu xích chó', ai: { w: 1.1, soc: 1 }, run: function (l, r, log) { log('Cả xóm cùng sang. Chủ nhà làm lồng, từ đó ra ngõ không còn phải cầm gậy.', 'good'); } },
      { k: 'bao', l: 'Báo chính quyền địa phương', ai: { w: 0.8 }, run: function (l, r, log) { log('Chủ chó bị nhắc nhở và phạt vì thả rông chó không rọ mõm. Họ cạch mặt bạn, nhưng lũ trẻ trong xóm được đi chơi yên tâm hơn.', 'neutral'); } },
      { k: 'tranh', l: 'Đi đường vòng cho lành', ai: { w: 0.6 }, run: function (l, r, log) { if (ch(r, 0.3)) { cash(l, -V(l, 1.5), 'Tiêm phòng dại sau khi bị chó cắn'); log('Một buổi tối đi vội qua ngõ, bạn bị con chó đớp vào bắp chân, phải đi tiêm phòng dại năm mũi.', 'bad'); fx(l, { hea: -2 }); } else log('Bạn đi đường vòng xa thêm năm phút mỗi ngày.', 'neutral'); } }
    ]
  });
  T('hx_cho_tha_rong', function (l, a) { return l.indep && a >= 18; }, 0.006, 10, 1);
  SC('hx_chung_cu', {
    title: 'Họp cư dân chung cư',
    prep: function (l, r) { return { why: pick(r, ['phí quản lý tăng gấp đôi mà thang máy vẫn hỏng', 'quỹ bảo trì 2% bị chủ đầu tư "giữ hộ" mãi không bàn giao', 'tầng hầm thiếu chỗ đỗ xe, người đến trước chiếm cả hai ô', 'nhà tầng trên sửa nhà, thấm nước xuống trần nhà bạn']) }; },
    valid: function (l) { return l.ownHouse && l.urban; },
    text: function (l, d) { return 'Nhóm chat cư dân sôi sục vì ' + d.why + '. Tối nay có buổi họp cư dân, ai cũng muốn lên tiếng.'; },
    opts: [
      { k: 'dung_dau', l: 'Đứng ra đại diện cư dân', ai: { w: 0.6, soc: 1, amb: 1 }, run: function (l, r, log) { if (ch(r, 0.55)) { log('Bạn thay mặt cư dân làm việc với ban quản lý, có văn bản, có thời hạn xử lý. Cả tòa nhà biết mặt, gặp ở thang máy ai cũng chào.', 'good'); fx(l, { soc: 4 }); } else { log('Bạn đứng ra đại diện, rồi thành mục tiêu chỉ trích của cả hai phía. Nhóm chat cư dân thành chiến trường, bạn tắt thông báo.', 'bad'); stress(l, 8); } } },
      { k: 'ky', l: 'Ký tên chung vào đơn kiến nghị', ai: { w: 1.1 }, run: function (l, r, log) { log('Bạn ký vào đơn kiến nghị cùng hơn trăm hộ. Ba tháng sau mọi chuyện được giải quyết một nửa.', 'neutral'); } },
      { k: 'ke', l: 'Tắt thông báo nhóm, sống yên ổn', ai: { w: 0.7 }, run: function (l, r, log) { log('Bạn tắt thông báo nhóm chat cư dân. Thế giới yên tĩnh hẳn, chỉ thỉnh thoảng thang máy vẫn hỏng.', 'neutral'); } }
    ]
  });
  T('hx_chung_cu', function (l, a) { return l.ownHouse && l.urban && a >= 25; }, 0.012, 6, 2);
  SC('tro_ban_cung_phong', {
    title: 'Bạn cùng phòng trọ',
    prep: function (l, r) { return { n: name(l, r, l.sex), v: V(l, pick(r, [1.2, 2, 3])) }; },
    valid: function (l) { return !l.ownHouse && l.age >= 17 && l.age <= 30 && (l.cityStudent || l.movedTo || l.indep); },
    text: function (l, d) { return d.n + ', bạn ở ghép cùng phòng, ba tháng nay "quên" góp tiền điện nước, tổng cộng ' + mo(l, d.v) + '. Hôm nay chủ trọ đến đòi, nhìn thẳng vào bạn.'; },
    opts: [
      { k: 'tra', l: 'Trả trước, đòi sau', ai: { w: 0.8 }, run: function (l, r, log, d) { cash(l, -d.v, 'Trả thay tiền điện nước phòng trọ'); if (ch(r, 0.5)) { cash(l, d.v, 'Bạn cùng phòng trả tiền điện nước'); log(d.n + ' đi làm thêm có lương, trả đủ, còn mua trà sữa xin lỗi.', 'good'); } else log(d.n + ' dọn đi lúc nửa đêm, để lại cái quạt hỏng và khoản nợ ' + mo(l, d.v) + '.', 'bad'); } },
      { k: 'noi', l: 'Nói thẳng, chia rõ từng khoản', ai: { w: 1.1, smart: 1 }, run: function (l, r, log, d) { log('Bạn lập bảng chia tiền, dán lên cửa tủ lạnh. ' + d.n + ' ngượng, từ đó góp đúng hạn, dù hai người không còn thân như trước.', 'neutral'); } },
      { k: 'chuyen', l: 'Tìm phòng khác ở một mình', ai: { w: 0.5 }, run: function (l, r, log, d) { cash(l, -V(l, 2), 'Tiền cọc phòng trọ mới'); log('Bạn dọn ra ở một mình. Đắt hơn, chật hơn, nhưng không còn phải đếm từng số điện.', 'neutral'); } }
    ]
  });
  T('tro_ban_cung_phong', function (l, a) { return !l.ownHouse && a >= 18 && a <= 30 && (!!l.cityStudent || !!l.movedTo); }, 0.04, 4, 1);

  // ===================================================================
  // 3. MẠNG XÃ HỘI
  // ===================================================================
  SC('mxh_boc_phot', {
    title: 'Bị "bóc phốt"',
    prep: function (l, r) { return { why: pick(r, ['bán hàng online giao chậm', 'một câu bình luận cũ bị cắt ghép', 'chuyện chia tay bị kể một chiều', 'tranh cãi với shipper bị quay lén']) }; },
    valid: function (l) { return l.age >= 16; },
    text: function (l, d) { return 'Một bài "bóc phốt" về bạn chuyện ' + d.why + ' bất ngờ lên xu hướng trong hội nhóm, kèm ảnh và tên thật. Hàng trăm bình luận, có cả người quen.'; },
    opts: [
      { k: 'giai_thich', l: 'Đăng bài giải thích có bằng chứng', ai: { w: 1, smart: 1 }, run: function (l, r, log) { if (ch(r, 0.55)) { log('Bài giải thích đủ tin nhắn, hóa đơn khiến dư luận đổi chiều. Người đăng bài phải gỡ và xin lỗi.', 'good'); fx(l, { hap: 2 }); } else { log('Càng giải thích càng bị "đào" thêm. Bạn khóa trang cá nhân một thời gian.', 'bad'); stress(l, 10); fx(l, { soc: -3 }); } } },
      { k: 'im', l: 'Im lặng chờ bão qua', ai: { w: 0.9 }, run: function (l, r, log) { log('Bạn im lặng, khóa bình luận. Một tuần sau mạng xã hội đã có "phốt" mới, không ai còn nhớ bạn.', 'neutral'); stress(l, 5); } },
      { k: 'kien', l: 'Nhờ luật sư gửi yêu cầu gỡ bài vì vu khống', h: function (l) { return 'Phí luật sư khoảng ' + mo(l, V(l, 8)); }, ai: { w: 0.4, risk: 0.5 }, run: function (l, r, log) { cash(l, -V(l, 8), 'Phí luật sư yêu cầu gỡ bài vu khống'); log('Văn bản của luật sư khiến người đăng bài phải gỡ bài, đăng đính chính. Bạn tốn tiền nhưng lấy lại được danh dự.', 'neutral'); } }
    ]
  });
  T('mxh_boc_phot', function (l, a) { return a >= 16 && a <= 60; }, 0.007, 10, 1);
  E.EVENTS.push({ c: function (l, a) { return free(l) && a >= 15 && a <= 65; }, p: 0.003, cd: 10, run: function (l, a, r, log) {
    var t = pick(r, ['Bức ảnh bạn chụp bà cụ bán rau dưới mưa bỗng có hàng chục nghìn lượt chia sẻ. Có người tìm đến mua hết gánh rau của bà.', 'Một video bạn quay cảnh chú chó đợi chủ trước cổng bệnh viện lan truyền khắp mạng, báo chí xin đăng lại.', 'Bài bạn viết về mẹ được hàng nghìn người chia sẻ, nhiều người nhắn tin: "Đọc xong tôi gọi điện về cho mẹ ngay."']);
    log(t, 'good'); fx(l, { hap: 4, soc: 3 }); l.fame = (l.fame || 0) + 500; l.flags.viral = true;
  } });
  SC('mxh_hoi_nhom', {
    title: 'Cãi nhau trong hội nhóm',
    prep: function (l, r) { return { topic: pick(r, ['nên cho trẻ học thêm hay không', 'miền nào ăn ngon nhất', 'mua nhà hay thuê nhà', 'đội bóng nào đá xấu', 'đẻ thường hay đẻ mổ']) }; },
    valid: function (l) { return l.age >= 18; },
    text: function (l, d) { return 'Một bình luận của bạn về chuyện ' + d.topic + ' trong hội nhóm vài trăm nghìn thành viên bị đem ra "ném đá". Tin nhắn chửi bới đổ về hộp thư.'; },
    opts: [
      { k: 'cai', l: 'Cãi tay đôi đến cùng', ai: { w: 0.5, risk: 1 }, run: function (l, r, log) { log('Bạn cãi đến hai giờ sáng, không ai thay đổi quan điểm. Sáng ra bạn tự hỏi mình đã làm gì với buổi tối ấy.', 'neutral'); stress(l, 6); fx(l, { hea: -1 }); } },
      { k: 'roi', l: 'Rời nhóm, chặn người quấy rối', ai: { w: 1.1, smart: 1 }, run: function (l, r, log) { log('Bạn rời nhóm, chặn vài tài khoản. Bảng tin bỗng nhẹ nhàng hẳn.', 'neutral'); stress(l, -2); } }
    ]
  });
  T('mxh_hoi_nhom', function (l, a) { return a >= 18 && a <= 65; }, 0.008, 8, 1);

  // ===================================================================
  // 4. TRƯỜNG HỌC
  // ===================================================================
  SC('th_tay_chay', {
    title: 'Bị nhóm bạn tẩy chay',
    prep: function (l, r) { return { n: name(l, r, l.sex) }; },
    valid: function (l) { return !!l.school && l.age >= 10 && l.age <= 17; },
    text: function (l, d) { return 'Nhóm bạn thân trong lớp lập nhóm chat mới, không có bạn. Đầu têu là ' + d.n + ', người bạn vẫn coi là thân nhất. Giờ ra chơi, cả nhóm đi qua như không thấy bạn.'; },
    opts: [
      { k: 'hoi', l: 'Hỏi thẳng ' + 'xem mình sai ở đâu', ai: { w: 0.9, soc: 1 }, run: function (l, r, log, d) { if (ch(r, 0.5)) { log('Hóa ra chỉ là hiểu lầm vì một câu nói bị truyền sai. Hai đứa ôm nhau khóc ở cầu thang.', 'good'); fx(l, { hap: 3 }); } else { log(d.n + ' nhún vai: "Tại cậu chán thôi." Câu nói ấy đau hơn bạn tưởng.', 'bad'); fx(l, { hap: -5 }); stress(l, 8); } } },
      { k: 'ban_moi', l: 'Tìm nhóm bạn mới', ai: { w: 1 }, run: function (l, r, log) { log('Bạn ngồi cùng bàn với mấy bạn hay đọc sách ở thư viện. Họ ít nói nhưng tử tế.', 'neutral'); fx(l, { soc: 1 }); } },
      { k: 'ke', l: 'Kể với bố mẹ / cô chủ nhiệm', ai: { w: 0.6 }, run: function (l, r, log) { log('Cô chủ nhiệm khéo léo xếp lại chỗ ngồi, tổ chức hoạt động nhóm. Mọi chuyện dần dịu đi.', 'neutral'); } }
    ]
  });
  T('th_tay_chay', function (l, a) { return !!l.school && a >= 10 && a <= 17; }, 0.03, 4, 1);
  SC('th_nghi_gian_lan', {
    title: 'Bị nghi gian lận',
    valid: function (l) { return !!l.school && l.age >= 12 && l.age <= 22; },
    text: 'Giờ kiểm tra, giám thị nhặt được tờ phao dưới chân bàn bạn. Không phải của bạn, nhưng cả phòng thi quay lại nhìn.',
    opts: [
      { k: 'phan_doi', l: 'Bình tĩnh đề nghị kiểm tra chữ viết, camera', ai: { w: 1.1, smart: 1 }, run: function (l, r, log) { if (ch(r, 0.7)) log('Đối chiếu chữ viết và camera, nhà trường xác định tờ phao của bạn ngồi bàn trên. Thầy cô xin lỗi bạn trước lớp.', 'good'); else { log('Không đủ căn cứ, bài của bạn bị trừ điểm "vì nghi vấn". Bạn uất ức cả học kỳ.', 'bad'); fx(l, { hap: -4 }); stress(l, 6); } } },
      { k: 'khoc', l: 'Hoảng quá, bật khóc', ai: { w: 0.6 }, run: function (l, r, log) { log('Bạn bật khóc, không nói được gì. Cô giám thị thương tình cho làm tiếp, nhưng bài thi hôm ấy lộn xộn hẳn.', 'neutral'); fx(l, { kno: -1 }); } }
    ]
  });
  T('th_nghi_gian_lan', function (l, a) { return !!l.school && a >= 12 && a <= 22; }, 0.012, 5, 1);

  // ===================================================================
  // 5. BẠN BÈ
  // ===================================================================
  SC('bb_hop_lop', {
    title: 'Họp lớp',
    prep: function (l, r) { return { n: name(l, r) }; },
    valid: function (l) { return l.age >= 28 && l.indep; },
    text: function (l, d) { return 'Họp lớp sau mười mấy năm. ' + d.n + ' đi xe sang, đeo đồng hồ đắt tiền, hỏi từng người "giờ làm gì, lương bao nhiêu, có nhà chưa". Có bạn ngồi im cả buổi.'; },
    opts: [
      { k: 'vui', l: 'Mặc kệ, cứ vui với những người bạn cũ', ai: { w: 1.2 }, run: function (l, r, log, d) { log('Bạn ngồi cạnh mấy đứa bạn cùng bàn ngày xưa, kể chuyện thầy cô, cười chảy nước mắt. Ai giàu ai nghèo, tối nay không quan trọng.', 'good'); fx(l, { hap: 3, soc: 3 }); } },
      { k: 'so_bi', l: 'Cũng "nổ" một chút cho bằng bạn bằng bè', ai: { w: 0.4, risk: 0.6 }, run: function (l, r, log, d) { cash(l, -V(l, 3), 'Bao cả lớp đi tăng hai'); log('Bạn khoe thăng chức, còn bao cả lớp đi tăng hai. Về nhà nhìn hóa đơn, bạn thấy mình hơi trẻ con.', 'neutral'); } },
      { k: 'thoi', l: 'Lần sau không đi nữa', ai: { w: 0.5 }, run: function (l, r, log, d) { log('Bạn về sớm. Từ đó nhóm lớp nhắn rủ họp, bạn chỉ thả tim.', 'neutral'); fx(l, { soc: -1 }); } }
    ]
  });
  T('bb_hop_lop', function (l, a) { return l.indep && a >= 28 && a <= 60; }, 0.012, 8, 1);
  SC('bb_quy_du_lich', {
    title: 'Quỹ du lịch của hội bạn',
    prep: function (l, r) { return { n: name(l, r), v: V(l, pick(r, [2, 3, 5])) }; },
    valid: function (l) { return l.indep && l.age >= 20; },
    text: function (l, d) { return 'Hội bạn thân góp quỹ đi du lịch cả năm, mỗi người ' + mo(l, d.v) + '. Gần đến ngày đi, ' + d.n + ', người giữ quỹ, nói "đầu tư tạm" vào tiền ảo và mất sạch.'; },
    opts: [
      { k: 'doi', l: 'Yêu cầu trả lại đủ, có hẹn ngày', ai: { w: 1, smart: 1 }, run: function (l, r, log, d) { cash(l, -d.v, 'Góp quỹ du lịch hội bạn'); if (ch(r, 0.55)) { cash(l, d.v, 'Bạn trả lại tiền quỹ du lịch'); log(d.n + ' bán xe máy, trả dần đủ cho cả hội. Chuyến đi hoãn sang năm sau, tình bạn vẫn còn.', 'neutral'); } else { log(d.n + ' hứa mãi rồi lặn mất. Hội bạn tan rã, nhóm chat im lìm.', 'bad'); fx(l, { soc: -3, hap: -3 }); } } },
      { k: 'bo_qua', l: 'Bỏ qua, coi như mất tiền mua bài học', ai: { w: 0.7, moral: 0.5 }, run: function (l, r, log, d) { cash(l, -d.v, 'Mất tiền quỹ du lịch hội bạn'); log('Bạn bỏ qua cho ' + d.n + '. Mất ' + mo(l, d.v) + ', nhưng từ đó bạn không bao giờ góp quỹ mà không có sổ sách rõ ràng.', 'neutral'); } }
    ]
  });
  T('bb_quy_du_lich', function (l, a) { return l.indep && a >= 20 && a <= 45; }, 0.01, 10, 1);

  // ===================================================================
  // 6. ĐƯỜNG PHỐ
  // ===================================================================
  SC('dp_va_quet', {
    title: 'Va quẹt trên đường',
    prep: function (l, r) { return { v: V(l, pick(r, [1, 2, 5])), fault: r() < 0.5 }; },
    valid: function (l) { return !!l.veh && l.age >= 18; },
    text: function (l, d) { return 'Giờ tan tầm, một chiếc xe ' + (d.fault ? 'bạn lỡ va vào' : 'vượt ẩu quẹt vào xe bạn') + '. Người kia xuống xe, lớn tiếng đòi bồi thường ' + mo(l, d.v) + ', người xem tụ lại kín đường.'; },
    opts: [
      { k: 'thuong_luong', l: 'Bình tĩnh thương lượng, chụp ảnh hiện trường', ai: { w: 1.1, smart: 1 }, run: function (l, r, log, d) { if (d.fault) { cash(l, -d.v * 0.6, 'Bồi thường va quẹt xe'); log('Bạn xin lỗi, chụp ảnh, thương lượng xuống còn ' + mo(l, d.v * 0.6) + '. Hai bên bắt tay rồi đi.', 'neutral'); } else log('Bạn chỉ vào camera hành trình. Người kia im bặt, lẩm bẩm vài câu rồi phóng đi.', 'neutral'); } },
      { k: 'goi_csgt', l: 'Gọi cảnh sát giao thông', ai: { w: 0.7 }, run: function (l, r, log, d) { log('Cảnh sát giao thông đến lập biên bản, xác định lỗi rõ ràng. Mất nửa buổi chiều, nhưng không ai bắt nạt được ai.', 'neutral'); if (d.fault) cash(l, -d.v * 0.8, 'Bồi thường va quẹt theo biên bản'); } },
      { k: 'tra_cho_xong', l: 'Trả tiền cho xong chuyện', ai: { w: 0.5 }, run: function (l, r, log, d) { cash(l, -d.v, 'Trả tiền cho xong vụ va quẹt'); log('Bạn rút ví trả ' + mo(l, d.v) + ' cho xong. ' + (d.fault ? 'Coi như bài học lái xe cẩn thận.' : 'Về nhà nghĩ lại vẫn thấy ấm ức.'), 'neutral'); stress(l, 3); } }
    ]
  });
  T('dp_va_quet', function (l, a) { return !!l.veh && a >= 18 && a <= 75; }, 0.01, 6, 2);
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
/* ===== js/life92.js ===== */
/* Một Đời — v7.3.0: "sống tiếp đời con" giữ đúng gia đình của đời trước
   · nghề của bố / mẹ (chính là nhân vật đời trước) diễn ra đúng như con đường sự nghiệp đã sống: đang làm gì lúc con chào đời,
     đổi việc, thăng chức, nghỉ hưu năm nào — không còn bị thay bằng nghề ngẫu nhiên, không còn "mất việc" ngẫu nhiên
   · nghề của người bạn đời (bố / mẹ còn lại) lấy đúng nghề lúc con chào đời
   · anh chị em ruột giữ nguyên họ tên, giới tính, thứ tự; em sinh sau thì chào đời đúng năm, người đã mất ở đời trước
     thì cũng ra đi đúng tuổi */
(function (G) {
  'use strict';
  var U = G.U, E = G.E, H = E.H;
  // 1. đời trước: ghi lại con đường sự nghiệp theo từng tuổi
  function title(l) { try { return l.job ? E.jobTitle(l) : l.retired ? 'đã nghỉ hưu' : l.school ? 'đang đi học' : l.indep ? 'thất nghiệp' : ''; } catch (e) { return ''; } }
  E.HOOKS.year.unshift(function (l, r, log, a) {
    if (!l.alive) return;
    var C = l.flags.career92 || (l.flags.career92 = []), t = title(l), inc = (l.income || 0) / 12, last = C[C.length - 1];
    if (t && (!last || last.t !== t || Math.abs(last.inc - inc) > Math.max(0.5, last.inc * 0.3))) { C.push({ a: a, t: t, inc: Math.round(inc * 100) / 100, ret: !!l.retired, pen: l.retired ? Math.round((l.pensionInc || 0) / 12 * 100) / 100 : 0 }); if (C.length > 80) C.splice(1, 1); }
    (l.kids || []).forEach(function (k) { if (k.mateJob == null && (k.born === a || k.born === a - 1)) { var p = l.partner; k.mateJob = p && p.alive !== false && k.mate && p.name === k.mate.name ? (p.job || '') : ''; k.mateInc2 = p && p.inc != null ? p.inc : null; } });
  });
  function careerAt(C, age) { var e = null; for (var i = 0; i < (C || []).length; i++) if (C[i].a <= age) e = C[i]; else break; return e; }
  // 2. truyền sang đời con
  var childOpts = E.childOpts;
  E.childOpts = function (l, k) {
    var o = childOpts.apply(this, arguments), P = o.parent || (o.parent = {});
    var C = (l.flags.career92 || []).map(function (x) { return { a: x.a - k.born, t: x.t, inc: x.inc, ret: x.ret, pen: x.pen }; });
    var at0 = careerAt(C, 0);
    P.career = C; P.base = l.base; P.cur = l.cur;
    if (P.me && at0 && at0.t && at0.t !== 'đang đi học') { P.me.job = at0.t; if (at0.inc > 0) P.me.inc = at0.inc; }
    if (P.mate && k.mateJob) { P.mate.job = k.mateJob; if (k.mateInc2 != null) P.mate.inc = k.mateInc2; }
    P.sibList = (l.kids || []).filter(function (x) { return x !== k && !(x.name === k.name && x.born === k.born && x.sex === k.sex); }).map(function (x) {
      return { n: x.name, sex: x.sex, born: x.born - k.born, died: x.alive === false && x.died != null ? x.died - k.born : null, close: x.close };
    }).filter(function (s) { return s.died == null || s.died > 0; });
    return o;
  };
  var createLife = E.createLife;
  E.createLife = function (opts) {
    var l = createLife.apply(this, arguments), PA = opts && opts.parent; if (!PA || !PA.me) return l;
    var f = l.fam, side = PA.me.sex === 'F' ? 'm' : 'f', k = side === 'm' ? 'mJob' : 'fJob', ik = side === 'm' ? 'mInc' : 'fInc';
    var sc = PA.base && l.base ? l.base / PA.base : 1;
    if (PA.career && PA.career.length) {
      f[side + 'Career'] = PA.career.map(function (x) { return { a: x.a, t: x.t, inc: x.inc * sc, ret: x.ret, pen: (x.pen || 0) * sc }; });
      var e = careerAt(f[side + 'Career'], 0);
      if (e && e.t) { f[k] = e.t === 'đang đi học' ? 'sinh viên' : e.t; f[ik] = e.ret ? (e.pen || 0) : e.inc; f[side + 'Ret'] = !!e.ret; if (side === 'm') f.mInc0 = f.mInc; else f.fInc0 = f.fInc; }
    }
    // An empty roster is authoritative too: an only child must not get random siblings.
    if (Array.isArray(PA.sibList)) {
      var older = [], later = [];
      PA.sibList.forEach(function (s) { var o = { n: s.n, sex: s.sex, born: s.born, alive: true, close: U.clamp(s.close != null ? s.close : 65, 30, 95), job: 'đang đi học', wed: false, kids: 0, q: f.q, diesAt: s.died }; (s.born <= 0 ? older : later).push(o); });
      l.sibList = older; f.sibs = older.length; l.flags.knownSibs = true; l.flags.futureSibs = later;
    }
    return l;
  };
  // 3. đời con: bố / mẹ đi đúng con đường sự nghiệp đã sống; anh chị em đúng như đời trước
  E.HOOKS.year.unshift(function (l, r, log, a) {
    if (!l.alive) return;
    var f = l.fam;
    ['m', 'f'].forEach(function (s) {
      var C = f[s + 'Career'], alive = s === 'm' ? f.mAlive : f.fAlive && !f.noDad; if (!C || !alive || a < 1) return;
      var e = careerAt(C, a), k = s + 'Job', P = s === 'm' ? 'Mẹ' : 'Bố'; if (!e || !e.t) return;
      var t = e.t === 'đang đi học' ? 'sinh viên' : e.t;
      if (f[k] !== t) {
        log(e.ret ? P + ' nghỉ hưu' + (e.pen > 0 ? ', nhận lương hưu ' + H.money(l, e.pen) + '/tháng.' : '.') : t === 'thất nghiệp' ? P + ' tạm thời chưa có việc làm.' : P + ' giờ là ' + t + '.', 'neutral');
        f[k] = t; f[s + 'Ret'] = !!e.ret; f[s + 'Lost'] = t === 'thất nghiệp' ? a : null;
      }
      f[s + 'Inc'] = e.ret ? (e.pen || 0) : (e.inc || 0);
    });
    if (l.flags.knownSibs) {
      var fut = l.flags.futureSibs || [];
      for (var i = fut.length - 1; i >= 0; i--) if (fut[i].born <= a) { var s = fut.splice(i, 1)[0]; (l.sibList || (l.sibList = [])).push(s); if (s.born === a) log('Nhà có thêm em bé — bạn có ' + (s.sex === 'M' ? 'em trai' : 'em gái') + ' tên ' + s.n + '.', 'good'); }
      (l.sibList || []).forEach(function (s) {
        if (s.alive && s.diesAt != null && a >= s.diesAt) { s.alive = false; var w = H.sibCall ? H.sibCall(l, s) : s.n, sa = a - s.born; log(U.cap(w) + ' qua đời ở tuổi ' + sa + (function (c) { return /thanh thản/.test(c) ? ', ' + c : ' vì ' + c; })(H.deathCause(sa, r)) + '.', 'bad'); H.fx(l, { hap: -8 }); }
      });
    }
  });
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
/* ===== js/life93.js ===== */
/* Một Đời — v7.3.0: thành tựu mới
   · thành tựu kiểu Gen Z: Nhà có 5 nàng tiên, Lời xin lỗi của một dân chơi, Flex nhẹ cái, Đi đâu cũng là healing, Red flag di động,
     Green flag chính hiệu, Ế bền vững, Giàu ngầm, Hot hòn họt, Lên xu hướng, Drama không hồi kết, Từ bạn thân thành người thương,
     Quay xe thần sầu, Cày như trâu
   · thành tựu "fan cứng" cho nghệ sĩ các chương trình Anh trai "say hi" (mùa 1, 2), Anh trai vượt ngàn chông gai (2024, 2026),
     Tinh hà "say hi", Em xinh "say hi" — tên thành tựu là tên FC chính thức. Chỉ có những nghệ sĩ đã có tên FC được công bố,
     đối chiếu từ nguồn công khai (Wikipedia "Danh sách tên gọi người hâm mộ", báo chí, fanpage chính thức).
     Điều kiện: chọn nghệ sĩ đó làm bias / thần tượng ít nhất 3 năm */
(function (G) {
  'use strict';
  var E = G.E, H = E.H;
  function dAge(l) { return l.death ? l.death.age : l.age; }
  function nw(l) { return E.netWorth ? E.netWorth(l) / (l.base || 1) : 0; }
  function marriedNow(l) { return !!(l.partner && l.partner.status === 'married' && l.partner.alive !== false); }
  // ghi nhận vài mốc trong đời để chấm thành tựu
  E.HOOKS.year.unshift(E.achYear93 = function (l, r, log, a) {
    if (!l.alive) return;
    var F = l.flags;
    if (l.veh === 'ô tô' && a < 25) F.carYoung = true;
    if (l.partner && l.partner.reunited) F.reunited = true;
    if (l.partner && l.partner.fromFriend && l.partner.status === 'married') F.friendSpouse = true;
    if (l.partner && l.partner.status === 'married' && F.marriedSince == null) F.marriedSince = a;
    if (!l.partner || l.partner.status !== 'married') F.marriedSince = null;
    // thần tượng: đếm số năm theo từng nghệ sĩ
    var who = [l.bias && !l.bias.all ? l.bias.n : null, l.idol || null].filter(Boolean);
    if (who.length) { var Y = F.biasYrs || (F.biasYrs = {}); FANS.forEach(function (x) { if (x[2].some(function (n) { return who.some(function (w) { return w === n || w.slice(-n.length - 1) === ' ' + n; }); })) Y[x[0]] = (Y[x[0]] || 0) + 1; }); } // so khớp đúng tên: "Anh Tú" khác "Anh Tú Atus"
  });
  // [mã, tên FC, các tên nghệ sĩ trong game, tên hiển thị]
  var FANS = [
    ['fc_sundays', 'SUNDAYs', ['HIEUTHUHAI'], 'HIEUTHUHAI'],
    ['fc_flash', 'FLASH', ['Rhyder'], 'Rhyder'],
    ['fc_lion_kingdom', 'Lion Kingdom', ['Isaac'], 'Isaac'],
    ['fc_sun_sun', 'Sun Sun', ['Đức Phúc'], 'Đức Phúc'],
    ['fc_muzik', 'Muzik', ['Quang Hùng MasterD'], 'Quang Hùng MasterD'],
    ['fc_galaxy', 'FC Galaxy', ['Anh Tú Atus'], 'Anh Tú Atus'],
    ['fc_goose', 'Goose', ['HURRYKNG'], 'HURRYKNG'],
    ['fc_dopamine', 'Dopamine', ['Dương Domic'], 'Dương Domic'],
    ['fc_embes', 'Embes', ['Negav'], 'Negav'],
    ['fc_sonic', 'SONIC', ['JSOL'], 'JSOL'],
    ['fc_xa_xa', 'Xa Xa', ['Pháp Kiều'], 'Pháp Kiều'],
    ['fc_cuu_co_canh', 'Cừu Có Cánh', ['Captain Boy'], 'Captain Boy'],
    ['fc_seasea', 'SeaSea', ['Erik'], 'Erik'],
    ['fc_nhim', 'Nhím', ['Song Luân'], 'Song Luân'],
    ['fc_oil', 'Oil', ['Phạm Anh Duy'], 'Phạm Anh Duy'],
    ['fc_lover', 'Lover', ['Anh Tú'], 'Anh Tú (Voi)'],
    ['fc_love', 'Love', ['Phạm Đình Thái Ngân'], 'Phạm Đình Thái Ngân'],
    ['fc_wink', 'Wink', ['Đỗ Phú Quí'], 'Đỗ Phú Quí'],
    ['fc_smilou', 'Smilou', ['Lou Hoàng'], 'Lou Hoàng'],
    ['fc_chun_fam', 'Chun Fam', ['Quang Trung'], 'Quang Trung'],
    ['fc_citisan', 'Citisan', ['Công Dương'], 'Công Dương'],
    ['fc_ginious', 'Ginious', ['Gin Tuấn Kiệt'], 'Gin Tuấn Kiệt'],
    ['fc_lil_li', 'Lil Lì', ['Nicky'], 'Nicky'],
    ['fc_hip', 'Híp', ['Quân A.P'], 'Quân A.P'],
    ['fc_deers', 'Deers', ['Vũ Thịnh'], 'Vũ Thịnh'],
    ['fc_alo_family', 'Alo Family', ['Ali Hoàng Dương'], 'Ali Hoàng Dương'],
    ['fc_weanie', 'Weanie', ['WEAN'], 'Wean Lê'],
    ['fc_tage', 'FC Tage', ['Tage'], 'Tage'],
    ['fc_forever_mine', 'FM — Forever Mine', ['Vũ Cát Tường'], 'Vũ Cát Tường'],
    ['fc_unicong', 'UNICONG', ['CONGB'], 'CONGB'],
    ['fc_capo', 'Capo', ['Sơn.K'], 'Sơn.K'],
    ['fc_brayniacs', 'Brayniacs', ['B Ray'], 'B Ray'],
    ['fc_archer', 'Archer', ['buitruonglinh'], 'buitruonglinh'],
    ['fc_riker', 'Riker', ['Karik'], 'Karik'],
    ['fc_gillianaire', 'Gillianaire', ['GILL'], 'GILL'],
    ['fc_co_dong', 'Cổ Đông', ['Mason Nguyễn'], 'Mason Nguyễn'],
    ['fc_mumble_bee', 'Mumble Bee', ['HUSTLANG Robber'], 'Robber'],
    ['fc_2nammaste', '2Nammaste', ['Nhâm Phương Nam'], 'Nhâm Phương Nam'],
    ['fc_khu_o_chuot', 'Khu ổ chuột', ['Jaysonlei'], 'Jaysonlei'],
    ['fc_bon_bon', 'Bon Bon', ['Jey B'], 'Jey B'],
    ['fc_voi_con', 'Voi Con', ['Vương Bình'], 'Vương Bình'],
    ['fc_icon', 'ICON', ['LOHAN'], 'LOHAN'],
    ['fc_kho_bau', 'Kho Báu', ['Cody Nam Võ'], 'Cody Nam Võ'],
    ['fc_bot_ngot', 'Bột Ngọt', ['Bùi Duy Ngọc'], 'Bùi Duy Ngọc'],
    ['fc_sonata', 'SONATA', ['Đỗ Nam Sơn'], 'Đỗ Nam Sơn'],
    ['fc_lop_du', 'Lớp Du', ['Phúc Du'], 'Phúc Du'],
    ['fc_vit_con', 'Vịt Con', ['Ryn Lee'], 'Ryn Lee'],
    ['fc_to_vet', 'Tổ Vẹt', ['Rio'], 'Rio'],
    ['fc_bff', 'BFF', ['Ngô Kiến Huy'], 'Ngô Kiến Huy'],
    ['fc_ocean', 'Ocean', ['OGENUS'], 'OGENUS'],
    ['fc_andme', 'ANDME', ['Dillan Hoàng Phan'], 'Dillan Hoàng Phan'],
    ['fc_tezdy', 'Tezdy', ['TEZ'], 'TEZ'],
    ['fc_pillow', 'Pillow', ['Khôi Vũ'], 'Khôi Vũ'],
    ['fc_one', 'ONE', ['OTIS'], 'OTIS'],
    ['fc_pansun', 'PanSun', ['Hải Nam'], 'Hải Nam'],
    ['fc_dong_cam_sanh', 'Động Cam Sành - MyMuse', ['Orange'], 'Orange'],
    ['fc_euphoria', 'Euphoria', ['LyHan'], 'LyHan'],
    ['fc_saawu', 'SAAWU', ['Saabirose'], 'Saabirose'],
    ['fc_bong_den', 'Bóng đèn', ['Ánh Sáng AZA'], 'Aza Ánh Sáng'],
    ['fc_salty', 'SALTY', ['Muộii'], 'Muộii'],
    ['fc_lovely', 'Lovely', ['LyLy'], 'LyLy'],
    ['fc_chaubaus', 'Chaubaus', ['Châu Bùi'], 'Châu Bùi'],
    ['fc_myllions', 'Myllions', ['Mỹ Mỹ'], 'Mỹ Mỹ'],
    ['fc_shinner', 'Shinner', ['Quỳnh Anh Shyn'], 'Quỳnh Anh Shyn'],
    ['fc_peach_jam', 'Peach Jam', ['Đào Tử A1J'], 'Đào Tử A1J'],
    ['fc_lac_da', 'Lạc Đà', ['Han Sara'], 'Han Sara'],
    ['fc_to_co', 'Tổ Cò', ['Phương Mỹ Chi'], 'Phương Mỹ Chi'],
    ['fc_little_ly', 'Little Ly', ['Phương Ly'], 'Phương Ly'],
    ['fc_halo', 'Halo', ['Maiquinn'], 'Maiquinn'],
    ['fc_thor', 'Thor', ['Lamoon'], 'Lamoon'],
    ['fc_tien_doi', 'Tiên Đôi', ['Tiên Tiên'], 'Tiên Tiên'],
    ['fc_hippies', 'Hippies', ['Lâm Bảo Ngọc'], 'Lâm Bảo Ngọc'],
    ['fc_millie', 'Millie', ['Vũ Thảo My'], 'Vũ Thảo My'],
    ['fc_moro', 'Moro', ['Juky San'], 'Juky San'],
    ['fc_ca_vo', 'Cá Vợ', ['52Hz'], '52Hz'],
    ['fc_dau_tay_kiukiu', 'Dâu Tây kiukiu', ['Danmy'], 'Danmy'],
    ['fc_bong_hoa_nho', 'Bông hoa nhỏ', ['Bích Phương'], 'Bích Phương'],
    ['fc_bomer', 'Bomer', ['Pháo'], 'Pháo NorthSide'],
    ['fc_chit', 'Chít', ['Chi Xê'], 'Chi Xê'],
    ['fc_lahu', 'Lahu', ['Ngô Lan Hương'], 'Ngô Lan Hương'],
    ['fc_ember', 'EMBER', ['Yeolan'], 'Yeolan'],
    ['fc_vang', 'Vàng', ['Hoàng Duyên'], 'Hoàng Duyên'],
    ['fc_bao_anh', 'FC Bảo Anh', ['Bảo Anh'], 'Bảo Anh'],
    ['fc_kingdom', 'Kingdom', ['SOOBIN', 'Soobin Hoàng Sơn'], 'SOOBIN'],
    ['fc_tom_hum', 'Chảo con', ['Đăng Khôi'], 'Đăng Khôi'],
    ['fc_bbq', 'BBQ', ['BB Trần'], 'BB Trần'],
    ['fc_homie', 'Homie', ['Binz'], 'Binz'],
    ['fc_carrot', 'Carrot', ['Jun Phạm'], 'Jun Phạm'],
    ['fc_khach_iu', 'Khách iu', ['Bùi Công Nam'], 'Bùi Công Nam'],
    ['fc_zhoufam', 'Zhoufam', ['Duy Khánh'], 'Duy Khánh'],
    ['fc_toc_con', 'Tóc con', ['Phan Đình Tùng', 'Phan Đinh Tùng'], 'Phan Đình Tùng'],
    ['fc_pifam', 'Pifam', ['Tăng Phúc'], 'Tăng Phúc'],
    ['fc_ban_nhac', 'Bạn Nhạc', ['Hoàng Dũng'], 'Hoàng Dũng'],
    ['fc_ung_dung', 'Ưng Dung', ['Hà An Huy'], 'Hà An Huy'],
    ['fc_fan_thue_dalab', 'Fan Thuê của Da LAB', ['Thỏ (Da LAB)', 'Thơm (Da LAB)'], 'Thỏ và Thơm (Da LAB)']
  ];
  FANS = FANS.concat([["fc_community_1", "Flowers", ["Kay Trần"], "Kay Trần"], ["fc_community_2", "SEVENT", ["Cường Seven"], "Cường Seven"], ["fc_community_3", "Làng Văn Hóa", ["Tự Long"], "Tự Long"], ["fc_community_4", "SAO", ["S(Trong) Trọng Hiếu", "S.TRONG", "Trọng Hiếu", "S(TRONG)"], "S(Trong) Trọng Hiếu"], ["fc_community_5", "Rockin'", ["ST Sơn Thạch", "S.T Sơn Thạch", "S.T"], "ST Sơn Thạch"], ["fc_community_6", "PhanClub", ["Wren Evans"], "Wren Evans"], ["fc_community_7", "Rhymie", ["Rhymastic"], "Rhymastic"], ["fc_community_8", "Nhà Mây", ["Quốc Thiên"], "Quốc Thiên"], ["fc_community_9", "Lửa", ["Thanh Duy"], "Thanh Duy"], ["fc_community_10", "Chồng Thu Trang", ["Tiến Luật"], "Tiến Luật"], ["fc_community_11", "Fingers", ["Đinh Tiến Đạt"], "Đinh Tiến Đạt"], ["fc_community_12", "Cẩm Chướng", ["Neko Lê"], "Neko Lê"], ["fc_community_13", "Chấm", ["Liên Bỉnh Phát"], "Liên Bỉnh Phát"], ["fc_community_14", "Sunflower", ["Thiên Minh"], "Thiên Minh"], ["fc_community_15", "Clique", ["Kiên Ứng"], "Kiên Ứng"], ["fc_community_16", "Đậu con", ["Đỗ Hoàng Hiệp"], "Đỗ Hoàng Hiệp"], ["fc_community_17", "Dừa con", ["Hà Lê"], "Hà Lê"], ["fc_community_19", "Sky", ["Sơn Tùng M-TP"], "Sơn Tùng M-TP"], ["fc_community_20", "Đom Đóm", ["J97", "Jack", "Jack - J97"], "J97"], ["fc_community_21", "LASIDO", ["Nguyễn Văn Chung"], "Nguyễn Văn Chung"], ["fc_community_22", "MINTAG", ["Tùng Mint"], "Tùng Mint"], ["fc_community_23", "Partner", ["Trịnh Thăng Bình"], "Trịnh Thăng Bình"], ["fc_community_24", "Tuner", ["Hoàng Tôn"], "Hoàng Tôn"], ["fc_community_25", "Quán Trà Đá", ["Đinh Mạnh Ninh"], "Đinh Mạnh Ninh"], ["fc_community_26", "Tinh Tú", ["Vương Anh Tú"], "Vương Anh Tú"], ["fc_community_27", "Windy", ["Will"], "Will"], ["fc_community_28", "Echoes", ["Mew Amazing"], "Mew Amazing"], ["fc_community_29", "Ánh Dương", ["Hoàng Rob"], "Hoàng Rob"], ["fc_community_30", "Khủng Long Con", ["Thuận Nguyễn"], "Thuận Nguyễn"], ["fc_community_31", "Lập Cung", ["Huỳnh Lập"], "Huỳnh Lập"], ["fc_community_32", "Đồng Hương", ["Đông Hùng"], "Đông Hùng"], ["fc_community_33", "Carrot Farm", ["Toki Thành Thỏ"], "Toki Thành Thỏ"], ["fc_community_34", "Trạm Chạc Pin", ["It’s Charles", "It's Charles"], "It’s Charles"], ["fc_community_35", "Muối", ["K.O", "K.O Đỗ Hoàng Dương"], "K.O"], ["fc_community_36", "Lì Xì", ["Lê Xuân Tiền"], "Lê Xuân Tiền"], ["fc_community_37", "OMAITV", ["Osad"], "Osad"], ["fc_community_38", "Súp bơ", ["14 Casper"], "14 Casper"], ["fc_community_39", "QUANdeful", ["Hồ Đông Quan"], "Hồ Đông Quan"], ["fc_community_40", "Cục Cưng", ["Thái Lê Minh Hiếu"], "Thái Lê Minh Hiếu"], ["fc_community_41", "Ô Liu", ["Liu Grace"], "Liu Grace"], ["fc_community_42", "VANTASY", ["IVAN", "Ivan"], "IVAN"], ["fc_community_43", "Cọp Con", ["Thể Thiên"], "Thể Thiên"], ["fc_community_44", "Đàn em anh Long", ["Kim Long"], "Kim Long"], ["fc_community_45", "Hạt", ["Tuấn Hưng"], "Tuấn Hưng"], ["fc_community_46", "Sukem", ["CoolKid"], "CoolKid"], ["fc_community_47", "Hailight", ["Đặng Hồng Hải"], "Đặng Hồng Hải"]]);
  E.FAN_CLUBS = FANS;
  function scSeen(l, re) { var n = 0, s = l.flags.scN || {}; for (var k in s) if (re.test(k)) n += s[k]; return n; }
  if (!E.addAchievements) return;
  E.addAchievements([
    ['nam_nang_tien', '🧚', 'Nhà có 5 nàng tiên', 'Có từ 5 cô con gái', function (l) { return (l.kids || []).filter(function (k) { return k.sex === 'F'; }).length >= 5; }],
    ['dan_choi_hoi_loi', '🙇', 'Lời xin lỗi của một dân chơi', 'Từng đào hoa (từ 4 cuộc tình tan vỡ), rồi hối lỗi, cưới và chung thủy từ 15 năm', function (l) { return (l.exes || 0) >= 4 && marriedNow(l) && l.flags.marriedSince != null && dAge(l) - l.flags.marriedSince >= 15; }],
    ['flex_nhe', '🚗', 'Flex nhẹ cái', 'Có ô tô riêng trước tuổi 25', function (l) { return !!l.flags.carYoung; }],
    ['healing', '🧳', 'Đi đâu cũng là healing', 'Đi du lịch từ 10 nơi', function (l) { return (l.flags.places || []).length >= 10; }],
    ['red_flag', '🚩', 'Red flag di động', 'Có từ 6 cuộc tình tan vỡ', function (l) { return (l.exes || 0) >= 6; }],
    ['green_flag', '💚', 'Green flag chính hiệu', 'Chưa từng chia tay hay ly hôn, chung thủy với một người từ 40 năm', function (l) { return !(l.exes > 0) && marriedNow(l) && l.flags.marriedSince != null && dAge(l) - l.flags.marriedSince >= 40; }],
    ['e_ben_vung', '🥲', 'Ế bền vững', 'Chưa từng hẹn hò ai, sống tới 50 tuổi', function (l) { return !l.flags.everDated && !l.partner && !(l.exes > 0) && !(l.widowed > 0) && dAge(l) >= 50; }],
    ['giau_ngam', '🤫', 'Giàu ngầm', 'Sống tằn tiện mà tài sản cuối đời từ 100 lần thu nhập năm', function (l) { return l.spend === 'save' && nw(l) >= 100; }],
    ['hot_hon_hot', '🔥', 'Hot hòn họt', 'Trở thành người nổi tiếng cả nước biết mặt', function (l) { return (l.fame || 0) >= 1e6; }],
    ['len_xu_huong', '📈', 'Lên xu hướng', 'Có một bài đăng lan truyền khắp mạng xã hội', function (l) { return !!l.flags.viral; }],
    ['drama_khong_hoi_ket', '🍿', 'Drama không hồi kết', 'Gặp từ 8 drama gia đình, công sở, hàng xóm, mạng xã hội trong một đời', function (l) { return scSeen(l, /^(fd_|ps_|cs_|hx_|mxh_|th_tay|th_nghi|bb_|dp_|tro_ban)/) >= 8; }],
    ['ban_than_thanh_nguoi_thuong', '💞', 'Từ bạn thân thành người thương', 'Cưới chính người bạn thân của mình', function (l) { return !!l.flags.friendSpouse; }],
    ['quay_xe', '↩️', 'Quay xe thần sầu', 'Quay lại với người yêu cũ', function (l) { return !!l.flags.reunited; }],
    ['cay_nhu_trau', '🐃', 'Cày như trâu', 'Đi làm từ 50 năm', function (l) { return (l.workYrs || 0) >= 50; }]
  ].concat(FANS.map(function (x) {
    return [x[0], x[0] === 'fc_bong_den' ? '💡' : '🎤', x[1], 'Trở thành fan cứng của ' + x[3] + ' (thần tượng ' + x[3] + ' từ 3 năm)', function (l) { return ((l.flags.biasYrs || {})[x[0]] || 0) >= 3; }];
  })));
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
/* ===== js/life94.js ===== */
/* Một Đời — v7.4.0: ứng dụng hẹn hò theo từng nước
   Mỗi nước một bộ app phổ biến thật (tham khảo bảng xếp hạng lượt tải / người dùng của data.ai, adjoe, các bảng xếp hạng app
   hẹn hò tại Hàn Quốc, Nhật Bản, Trung Quốc):
   · Việt Nam: Tinder, Bumble, Facebook Hẹn hò, Litmatch · Hàn Quốc: Amanda, WIPPY, Glam, Tinder · Nhật Bản: Pairs, Tapple, with, Tinder
   · Trung Quốc: Tantan, Momo, Soul (không có Tinder / Facebook) · Đài Loan, Hồng Kông: Tinder, Omi, Pairs · Nga: Mamba, VK Знакомства, Badoo
   · Mỹ, Anh, Úc, Canada…: Tinder, Hinge, Bumble · châu Âu lục địa: Tinder, Hinge, Bumble, Badoo · Mỹ Latinh: Tinder, Badoo, Bumble
   · Ấn Độ: Tinder, Bumble, Aisle, QuackQuack · Trung Đông, Bắc Phi: Muzz · Indonesia, Malaysia, Thái Lan, Philippines: Tinder, Tantan, Omi, Litmatch, Bumble
   · ứng dụng cho người LGBTQ+: Blued (châu Á), Grindr (nơi khác), HER
   · người lớn tuổi: nhóm Zalo (Việt Nam), công ty mai mối kết hôn (Hàn Quốc), dịch vụ "hôn hoạt" (Nhật Bản), góc xem mắt ở công viên (Trung Quốc),
     trang mai mối hôn nhân (Ấn Độ), mai mối qua gia đình (Trung Đông), Match.com / eHarmony (Mỹ, Anh)… */
(function (G) {
  'use strict';
  var U = G.U, E = G.E, H = E.H, isVN = H.isVN;
  function here(l) { return String((l.abroad && l.abroad.perm && l.abroad.code) || l.country || (isVN(l) ? 'VN' : '')).toUpperCase(); }
  var R = {
    VN: /^VN$/, KR: /^KR$/, JP: /^JP$/, CN: /^CN$/, TWHK: /^(TW|HK|MO)$/, RU: /^(RU|BY|KZ|KG|UZ|TJ|AM|AZ)$/,
    ANGLO: /^(US|GB|CA|AU|NZ|IE)$/, EU: /^(DE|FR|NL|BE|LU|AT|CH|SE|NO|DK|FI|IS|ES|PT|IT|GR|PL|CZ|SK|HU|RO|BG|HR|SI|EE|LV|LT|UA|RS|BA|ME|MK|AL|MT|CY|MD)$/,
    LATAM: /^(BR|MX|AR|CO|CL|PE|VE|EC|BO|PY|UY|CR|PA|GT|HN|SV|NI|DO|CU|PR|JM|TT|HT)$/,
    IN: /^(IN|NP|LK|BD)$/, MENA: /^(SA|AE|QA|KW|BH|OM|YE|IR|IQ|JO|SY|LB|EG|LY|TN|DZ|MA|SD|PK|AF|TR)$/,
    SEA: /^(ID|MY|TH|PH|SG|KH|LA|MM|BN|TL)$/
  };
  function region(l) { var c = here(l); for (var k in R) if (R[k].test(c)) return k; return 'OTHER'; }
  E.datingRegion = region;
  // [mã, tên app, mô tả, độ dễ match, tỉ lệ "qua đêm", tỉ lệ lừa đảo, nghiêm túc, các vùng, điều kiện riêng]
  var Y = function (l) { return l.age <= 45; }, Y2 = function (l) { return l.age >= 20 && l.age <= 45; }, ALL = function (l) { return l.age <= 65; };
  var APPS = [
    ['tinder', 'Tinder', 'Đông người dùng nhất, quẹt nhanh — nhiều người chỉ tìm vui qua đường', 0.55, 0.35, 0.06, 0, 'VN KR JP TWHK ANGLO EU LATAM IN SEA OTHER', Y],
    ['bumble', 'Bumble', 'Con gái nhắn tin trước, ít bị làm phiền', 0.5, 0.12, 0.04, 0, 'VN ANGLO EU LATAM IN SEA', Y],
    ['hinge', 'Hinge', '"Ứng dụng sinh ra để được xóa" — hợp người muốn yêu nghiêm túc', 0.5, 0.05, 0.03, 1, 'ANGLO EU', Y2],
    ['fb', 'Facebook Hẹn hò', 'Gợi ý theo bạn chung, nhiều người ở gần', 0.45, 0.08, 0.08, 0, 'VN ANGLO LATAM OTHER', ALL],
    ['litmatch', 'Litmatch', 'Trò chuyện ẩn danh theo "linh hồn", giới trẻ dùng nhiều', 0.4, 0.1, 0.06, 0, 'VN SEA', function (l) { return l.age <= 35; }],
    ['amanda', 'Amanda', 'Hồ sơ phải được người dùng khác chấm điểm đạt mới vào được — nổi tiếng khắt khe về ngoại hình', 0.42, 0.1, 0.03, 0, 'KR', Y],
    ['wippy', 'WIPPY', 'App hẹn hò được tải nhiều nhất ở Hàn Quốc, gợi ý người ở gần', 0.5, 0.15, 0.04, 0, 'KR', Y],
    ['glam', 'Glam', 'Hồ sơ được xét duyệt, nhiều người đi làm muốn tìm người yêu nghiêm túc', 0.45, 0.06, 0.03, 1, 'KR', Y2],
    ['pairs', 'Pairs', 'App hẹn hò phổ biến nhất Nhật Bản, phần lớn người dùng tìm người yêu nghiêm túc', 0.5, 0.04, 0.03, 1, 'JP TWHK', Y2],
    ['tapple', 'Tapple', 'Chọn theo sở thích chung, hợp người dưới 30 tuổi', 0.5, 0.1, 0.03, 0, 'JP', function (l) { return l.age <= 32; }],
    ['with', 'with', 'Ghép đôi theo trắc nghiệm tính cách', 0.45, 0.05, 0.03, 1, 'JP', Y2],
    ['tantan', 'Tantan (探探)', 'Quẹt trái quẹt phải kiểu Tinder, rất phổ biến ở Trung Quốc', 0.55, 0.3, 0.07, 0, 'CN SEA', Y],
    ['momo', 'Momo (陌陌)', 'Tìm người lạ ở gần, vừa kết bạn vừa hẹn hò', 0.5, 0.3, 0.08, 0, 'CN', Y],
    ['soul', 'Soul', 'Ghép đôi theo "tâm hồn" qua trắc nghiệm, giới trẻ Trung Quốc rất chuộng', 0.45, 0.08, 0.05, 0, 'CN', function (l) { return l.age <= 35; }],
    ['omi', 'Omi', 'Ghép đôi theo sở thích, phổ biến ở Đài Loan, Malaysia, Thái Lan', 0.45, 0.12, 0.05, 0, 'TWHK SEA', Y],
    ['mamba', 'Mamba', 'Trang hẹn hò lâu đời và lớn nhất nước Nga', 0.5, 0.2, 0.07, 0, 'RU', function (l) { return l.age <= 55; }],
    ['vk', 'VK Знакомства', 'Hẹn hò ngay trong mạng xã hội VK, quen qua bạn chung', 0.45, 0.12, 0.06, 0, 'RU', ALL],
    ['badoo', 'Badoo', 'Đông người dùng ở châu Âu, Mỹ Latinh', 0.5, 0.2, 0.06, 0, 'RU EU LATAM OTHER', function (l) { return l.age <= 55; }],
    ['aisle', 'Aisle', 'App hẹn hò cho người muốn tiến tới hôn nhân ở Ấn Độ', 0.45, 0.03, 0.04, 1, 'IN', Y2],
    ['quackquack', 'QuackQuack', 'App hẹn hò của Ấn Độ, nhiều người ở các thành phố nhỏ', 0.45, 0.08, 0.06, 0, 'IN', Y],
    ['muzz', 'Muzz', 'App tìm bạn đời cho người Hồi giáo, có thể có người giám hộ cùng xem tin nhắn', 0.45, 0, 0.03, 1, 'MENA SEA', function (l) { return l.age >= 18 && l.age <= 50; }],
    ['blued', 'Blued', 'Ứng dụng hẹn hò dành cho nam đồng tính, song tính', 0.6, 0.4, 0.05, 0, 'VN CN TWHK KR JP SEA IN', function (l) { return l.sex === 'M' && l.orient !== 'straight' && l.age <= 55; }],
    ['grindr', 'Grindr', 'Ứng dụng hẹn hò dành cho nam đồng tính, song tính', 0.6, 0.4, 0.05, 0, 'ANGLO EU LATAM RU OTHER', function (l) { return l.sex === 'M' && l.orient !== 'straight' && l.age <= 55; }],
    ['her', 'HER', 'Ứng dụng dành cho nữ đồng tính, song tính', 0.5, 0.08, 0.03, 0, 'VN KR JP TWHK ANGLO EU LATAM SEA OTHER', function (l) { return l.sex === 'F' && l.orient !== 'straight' && l.age <= 55; }]
  ];
  // cách tìm bạn đời cho người lớn tuổi theo từng nơi
  var OLD = {
    VN: ['nhóm kết bạn tuổi trung niên trên Zalo, Facebook', 'Nhiều người cùng cảnh, nhưng cũng nhiều kẻ lừa tình'],
    KR: ['công ty mai mối kết hôn (như Duo)', 'Trả phí, được giới thiệu người có hồ sơ xác minh nghề nghiệp, học vấn'],
    JP: ['dịch vụ "hôn hoạt" (konkatsu) và app Omiai', 'Hẹn gặp có mục đích tiến tới hôn nhân, nhiều người tuổi trung niên'],
    CN: ['góc xem mắt ở công viên (相亲角) và mai mối qua người quen', 'Bố mẹ, họ hàng mang hồ sơ đi "chợ xem mắt" giúp'],
    TWHK: ['dịch vụ mai mối và nhóm kết bạn trên LINE, Facebook', 'Người giới thiệu xếp lịch gặp mặt'],
    RU: ['trang hẹn hò Teamo và các nhóm VK cho người trung niên', 'Nhiều người nghiêm túc, cũng có kẻ lừa tình'],
    ANGLO: ['Match.com, eHarmony', 'Trang hẹn hò lâu đời, nhiều người trung niên tìm bạn đời nghiêm túc'],
    EU: ['trang hẹn hò cho người trưởng thành (Parship, Meetic…)', 'Ghép đôi theo trắc nghiệm, nhiều người trên 40 tuổi'],
    LATAM: ['nhóm kết bạn trên Facebook, WhatsApp', 'Quen qua bạn bè, nhà thờ, câu lạc bộ khiêu vũ'],
    IN: ['trang mai mối hôn nhân (Shaadi.com, Jeevansathi)', 'Gia đình hai bên cùng xem hồ sơ, lá số'],
    MENA: ['mai mối qua gia đình, người quen', 'Gia đình hai bên gặp nhau trước, rồi mới để hai người tìm hiểu'],
    SEA: ['nhóm kết bạn trên Facebook và mai mối qua người quen', 'Nhiều người cùng cảnh, nhưng cũng có kẻ lừa tình'],
    OTHER: ['nhóm kết bạn trên Facebook, WhatsApp', 'Quen qua bạn bè, người quen giới thiệu']
  };
  function appsFor(l) { var rg = region(l); return APPS.filter(function (a) { return a[7].split(' ').indexOf(rg) >= 0; }); }
  E.datingApps = function (l) { return appsFor(l).filter(function (a) { return a[8](l); }).map(function (a) { return a[1]; }); };
  var D = E.DEC.app_hen_ho; if (!D) return;
  function open(l, r, name) { l.pending.unshift(E.DEC.app_ho_so.make(l, r, { app: name, fresh: true })); }
  D.def.text = function (l) { var o = OLD[region(l)] || OLD.OTHER; return l.age >= 45 ? 'Con cái khuyên bạn thử tìm bạn đời. Ở đây người tuổi bạn hay dùng ' + o[0] + '. Bạn chọn cách nào?' : 'Bạn tải vài ứng dụng hẹn hò phổ biến ở ' + (isVN(l) && !(l.abroad && l.abroad.perm) ? 'Việt Nam' : (l.abroad && l.abroad.perm ? l.abroad.name : l.countryName) || 'nơi bạn sống') + ' về máy. Mỗi app một kiểu người dùng:'; };
  D.def.opts = APPS.map(function (a) {
    return { k: a[0], l: a[1], h: a[2], req: function (l) { return appsFor(l).indexOf(a) >= 0 && a[8](l); }, ai: { w: a[6] ? 1 : 0.9, risk: a[4] > 0.2 ? 0.6 : 0 }, run: function (l, r, log) { open(l, r, a[1]); } };
  }).concat([
    { k: 'trung_nien', l: function (l) { return U.cap((OLD[region(l)] || OLD.OTHER)[0]); }, h: function (l) { return (OLD[region(l)] || OLD.OTHER)[1]; }, req: function (l) { return l.age >= 45; }, ai: { w: 0.9 }, run: function (l, r, log) {
      var o = OLD[region(l)] || OLD.OTHER, y = r(), scam = /lừa/.test(o[1]) ? 0.15 : 0.05;
      if (y < scam) { H.cash(l, -l.base * 0.1, 'Bị lừa tình qua mạng'); log('Quen một người qua ' + o[0] + ', được hứa hẹn đủ điều rồi bị vay tiền "lo việc gấp". Mất tiền, mất niềm tin.', 'bad'); H.fx(l, { hap: -8 }); return; }
      if (y < scam + 0.4 && E.DEC.love) { l.pending.unshift(E.DEC.love.make(l, r, { where: 'qua ' + o[0] })); return; }
      log('Thử ' + o[0] + ' một thời gian, gặp vài người nhưng chưa thấy ai hợp.', 'neutral');
    } },
    { k: 'no', l: 'Thôi, xóa app', ai: { w: 0.2 }, run: function (l, r, log) { log('Tải về rồi lại xóa, thấy không hợp với mình.', 'neutral'); } }
  ]);
  // lựa chọn "Dùng ứng dụng hẹn hò (…)" ghi đúng tên app phổ biến nơi bạn sống
  var TN = E.DEC.tim_nguoi_yeu && E.DEC.tim_nguoi_yeu.def;
  if (TN) TN.opts.forEach(function (o) { if (o.k !== 'app') return; o.l = function (l) { if (l.age >= 45) return 'Tìm bạn đời qua ' + (OLD[region(l)] || OLD.OTHER)[0]; var n = E.datingApps(l).slice(0, 2); return 'Dùng ứng dụng hẹn hò (' + (n.length ? n.join(', ') : 'Tinder') + '…)'; }; });
  // app "quẹt nhanh" dễ có người chỉ muốn gặp qua đêm
  E.HOOKUP_APP = /Tinder|Blued|Grindr|Tantan|Momo|Badoo|Mamba|WIPPY/;
  // hồ sơ "gửi quà từ nước ngoài": không còn nhắc Việt Nam khi bạn sống ở nước khác
  var hz = E.DEC.hen_online;
  if (hz && typeof hz.def.text === 'function') { var t0 = hz.def.text; hz.def.text = function (l, d) { var t = t0.apply(this, arguments); if (!(isVN(l) && !(l.abroad && l.abroad.perm)) && typeof t === 'string') t = t.replace('nữ bác sĩ Việt kiều', 'nữ bác sĩ đang làm việc ở nước ngoài').replace('nói tiếng Việt hơi lơ lớ', 'nói tiếng bản xứ hơi lơ lớ'); return t; }; }
  var hs = E.DEC.app_ho_so;
  if (hs && typeof hs.def.text === 'function') { var t1 = hs.def.text; hs.def.text = function (l, d) { var t = t1.apply(this, arguments); if (!(isVN(l) && !(l.abroad && l.abroad.perm)) && typeof t === 'string') t = t.replace('sắp về Việt Nam', 'sắp về nước').replace('nói tiếng Việt chưa sõi', 'nói tiếng bản xứ chưa sõi'); return t; }; }
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
/* ===== js/life95.js ===== */
/* Một Đời — v7.4.1: ở xa thì không còn chuyện "gặp nhau ăn cơm"
   · đã bảo lãnh bố mẹ sang nước ngoài sống cùng: không còn "gửi tiền về cho bố mẹ ở quê", "nhà bố mẹ ở quê bị dột", "ai nuôi bố mẹ",
     "bố mẹ ở một mình", Tết xa nhà một mình — Tết đón cùng bố mẹ ở xứ người
   · bạn thân nhớ nơi mình quen nhau: đang ở nước ngoài thì không hẹn bạn thân ở Việt Nam đi ăn, đi cà phê, chạy vào viện trong đêm…
     (vẫn nhắn tin, gọi video, cho vay qua chuyển khoản được); bạn mới quen ở nước ngoài thì gặp được ở nước ngoài
   · anh chị em ở quê: đang ở nước ngoài thì không "rủ cả nhà tụ họp ăn một bữa", chỉ gọi video
   · người LGBTQ+ ở nước ngoài nhận con nuôi: theo luật nước đang sống (không còn ghi "ở Việt Nam, một người đứng tên") */
(function (G) {
  'use strict';
  var U = G.U, E = G.E, H = E.H, isVN = H.isVN;
  function locOf(l) { return l.abroad ? String(l.abroad.code || l.abroad.name || 'abroad') : 'HOME'; }
  E.locOf = locOf;
  function together(l) { return !!(l.flags.parentsAbroad && l.abroad && l.abroad.perm); }
  E.parentsWithYouAbroad = together;
  function gate(id, ok) {
    var D = E.DEC[id]; if (D) { var v = D.valid; D.valid = function (l, d) { return ok(l) && (!v || v.apply(this, arguments)); }; }
    E.TRIG.forEach(function (t) { if (t.id === id) { var w = t.when; t.when = function (l, a) { return ok(l) && w.apply(this, arguments); }; } });
  }
  // 1. bố mẹ đã sang sống cùng
  ['dc_gui_tien', 'gui_bo_me', 'fd_nuoi_bo_me', 'bo_me_mot_minh', 'dc_bao_lanh', 'dc_tet', 'fd_dat_huong_hoa'].forEach(function (id) { gate(id, function (l) { return !together(l); }); });
  var BMC = E.DEC.bo_me_can;
  if (BMC && BMC.def.prep) {
    var p0 = BMC.def.prep;
    BMC.def.prep = function (l, r) { var d = p0.apply(this, arguments); for (var i = 0; i < 10 && together(l) && /quê|mái nhà|dột|xây lại/.test(d.t + ' ' + d.w); i++) d = p0.apply(this, arguments); return d; };
    var v0 = BMC.valid; BMC.valid = function (l, d) { if (together(l) && d && /quê|mái nhà|dột|xây lại/.test((d.t || '') + ' ' + (d.w || ''))) return false; return !v0 || v0.apply(this, arguments); };
  }
  E.HOOKS.year.unshift(E.abroadYear95 = function (l, r, log, a) {
    if (!l.alive) return;
    if (together(l)) { l.flags.careDone = true; if (l.fam.mAlive || l.fam.fAlive) l.flags.caring = true; }
    // bạn thân quen ở đâu thì ở đó
    var here = locOf(l);
    [l.bff].concat(l.friends || []).forEach(function (f) { if (f && !f.loc) f.loc = f.since != null && f.since >= (l.flags.abroadSince != null ? l.flags.abroadSince : 999) ? here : 'HOME'; });
    if (l.abroad && l.flags.abroadSince == null) l.flags.abroadSince = a; if (!l.abroad) l.flags.abroadSince = null;
  });
  // bạn mới quen thì ở cùng nơi với bạn lúc quen
  var BM = E.DEC.ban_than_moi;
  if (BM) { var ap = BM.apply; BM.apply = function (l) { var n = (l.friends || []).length, out = ap.apply(this, arguments); (l.friends || []).slice(n).forEach(function (f) { f.loc = locOf(l); }); return out; }; }
  // chỉ hẹn gặp trực tiếp được bạn đang ở cùng nơi
  var fo = E.friendsOf;
  if (fo) E.friendsOf = function (l) { var here = locOf(l); return fo.apply(this, arguments).filter(function (f) { return (f.loc || 'HOME') === here; }); };
  E.friendsFar = function (l) { var here = locOf(l); return [l.bff].concat(l.friends || []).filter(function (f) { return f && f.alive !== false && (f.loc || 'HOME') !== here; }); };
  // bạn thân ở Việt Nam nhập viện: đang ở nước ngoài thì không "lao vào viện trong đêm"
  var BNV = E.DEC.ban_nam_vien;
  if (BNV) BNV.def.opts.forEach(function (o) { if (o.k !== 'visit') return; var rq = o.req; o.req = function (l, d) { return (l.bff && (l.bff.loc || 'HOME') === locOf(l)) && (!rq || rq.apply(this, arguments)); }; });
  // ở xa: nhắn tin, gọi video với bạn cũ
  E.EVENTS.push({ c: function (l, a) { return !!l.abroad && a >= 18 && E.friendsFar(l).length > 0; }, p: 0.12, cd: 3, run: function (l, a, r, log) {
    var f = U.pick(r, E.friendsFar(l));
    log(U.pick(r, ['Gọi video với ' + f.name + ' ở quê nhà, hai đứa cười mãi vì lệch múi giờ: bên này đã khuya, bên kia còn đang ăn trưa.', f.name + ' nhắn tin kể chuyện ở nhà, gửi kèm ảnh quán quen ngày xưa: "Bao giờ về thì đi ăn nhé."', 'Sinh nhật ' + f.name + ', bạn chỉ kịp gửi lời chúc và một món quà qua mạng.']), 'neutral');
    f.close = Math.min(100, (f.close || 50) + 2);
  } });
  // anh chị em ở quê: đang ở nước ngoài thì không "rủ cả nhà ăn một bữa"
  var SG = E.DEC.sib_gap;
  if (SG) {
    SG.def.opts.forEach(function (o) { if (o.k === 'meal' || o.k === 'trip') { var rq = o.req; o.req = function (l, d) { return !l.abroad && (!rq || rq.apply(this, arguments)); }; } });
    if (!SG.def.opts.some(function (o) { return o.k === 'video'; })) SG.def.opts.unshift({ k: 'video', l: 'Gọi video cho cả nhà ở quê', req: function (l) { return !!l.abroad; }, run: function (l, r, log, d) { var s = l.sibList && l.sibList[d.i]; if (s) s.close = Math.min(100, s.close + 4); log('Cả nhà ở quê gọi video sang, ' + (s && H.sibCall ? H.sibCall(l, s) : 'anh chị em') + ' giơ máy cho bạn xem mâm cơm, đứa cháu mới tập nói. Bạn cười mà cay cay sống mũi.', 'neutral'); H.fx(l, { hap: 2 }); } });
  }
  // 2. con nuôi của cặp đôi đồng giới theo luật nước đang sống
  var JOINT = /^(US|CA|GB|IE|FR|DE|NL|BE|LU|ES|PT|AT|CH|DK|SE|NO|FI|IS|MT|SI|EE|GR|AU|NZ|BR|AR|UY|CO|MX|ZA|TW|AD)$/;
  var LN = E.DEC.lg_nuoi_con;
  if (LN && typeof LN.def.text === 'function') {
    LN.def.text = function (l) {
      var abroad = l.abroad && l.abroad.perm, code = String(abroad ? l.abroad.code : l.country || '').toUpperCase(), name = abroad ? l.abroad.name : (isVN(l) ? 'Việt Nam' : l.countryName);
      var law = code === 'VN' || (!abroad && isVN(l)) ? ' (ở Việt Nam, một người đứng tên nhận con nuôi)' : JOINT.test(code) ? ' (ở ' + name + ', hai người được cùng đứng tên nhận con nuôi)' : ' (ở ' + name + ', luật chưa cho cặp đôi đồng giới cùng nhận con nuôi, một người đứng tên)';
      return 'Bạn và ' + l.partner.name + ' ' + Math.max(1, l.age - l.partner.since) + ' năm sống chung, căn nhà nhỏ bắt đầu thấy vắng. Hai người bàn chuyện nhận nuôi một đứa trẻ' + law + '.';
    };
  }
  // Tết ở nước ngoài
  E.EVENTS.push({ c: function (l, a) { return isVN(l) && together(l) && a >= 18; }, p: 0.12, cd: 3, run: function (l, a, r, log) {
    log(U.pick(r, ['Tết ở ' + l.abroad.name + ', cả nhà vẫn gói bánh chưng, ' + (l.fam.mAlive ? 'mẹ' : 'bố') + ' bày mâm ngũ quả y như ở quê.', 'Giao thừa nơi xứ người, có bố mẹ bên cạnh nên căn nhà ấm hẳn.']), 'good'); H.fx(l, { hap: 3 });
  } });
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
/* ===== js/life96.js ===== */
/* Một Đời — v7.5.0 (góp ý của người chơi)
   · "sống tiếp đời con" ở tuổi hiện tại: giữ đúng nghề, bậc, thâm niên, học vấn của người con như đã hiển thị ở đời trước
     (trước đây những năm đã qua được dựng lại ngẫu nhiên nên nghề bị đổi)
   · cho biết mọi người đang ở đâu: bạn (ở quê, lên thành phố, du học, đi làm ở nước ngoài, định cư…), bố mẹ (ở cùng nhà / ở quê),
     từng người con (ở cùng bạn, đi du học, đi làm ở riêng, đã lập gia đình)
   · tự chọn trường quân đội, công an khi thi đại học: Học viện An ninh nhân dân, Học viện Cảnh sát nhân dân, Học viện Kỹ thuật Quân sự,
     Học viện Quân y, Học viện Hải quân, Học viện Biên phòng, Học viện Phòng không – Không quân, Học viện Hậu cần, các trường Sĩ quan
     Lục quân, Chính trị, Thông tin, Pháo binh, Đặc công…, Đại học Phòng cháy chữa cháy
   · lộ trình thăng quân hàm theo Luật Sĩ quan QĐND và Luật CAND: Thiếu úy → Trung úy 2 năm → Thượng úy 3 năm → Đại úy 3 năm →
     Thiếu tá, Trung tá, Thượng tá, Đại tá mỗi bậc 4 năm; muốn lên Thượng tá phải qua học viện đào tạo cán bộ cấp trung (Học viện Lục quân,
     Học viện Chính trị / Học viện Chính trị CAND), lên tướng phải qua Học viện Quốc phòng / lớp cao cấp */
(function (G) {
  'use strict';
  var U = G.U, E = G.E, H = E.H, SC = E.SC, isVN = H.isVN;
  function pick(r, a) { return U.pick(r, a); }
  function mo(l, v) { return H.money(l, v); }

  // ===================================================================
  // 1. ĐỜI CON Ở TUỔI HIỆN TẠI: GIỮ NGHỀ NHƯ ĐỜI TRƯỚC
  // ===================================================================
  var childOpts = E.childOpts;
  E.childOpts = function (l, k) {
    var o = childOpts.apply(this, arguments), h = o.parent && o.parent.heir;
    if (h && h.rec) { h.rec.jobId = k.job || null; h.rec.rank = k.rank || 0; h.rec.jyrs = k.jyrs || 0; h.rec.uniLeft = k.uniUntil ? Math.max(1, k.uniUntil - (h.at || 0)) : 0; h.rec.abroadStudy = !!k.abroadStudy; h.rec.eduExact = k.edu || 0; }
    return o;
  };
  var heirAtAge = E.heirAtAge;
  if (heirAtAge) E.heirAtAge = function (l, k, tries) {
    var best = heirAtAge.apply(this, arguments); if (!best || !best.flags.heirFF) return best;
    var rec = (E.childOpts(l, k).parent.heir || {}).rec || {}, h0 = { rs: (best.rs ^ 0x96a1) | 0 }, r = function () { return U.rand(h0); };
    best.edu = rec.eduExact || 0;
    if (rec.uniLeft > 0) { if (best.job) { best.lastJob = best.job; best.job = null; } best.school = 'uni'; best.schoolEnd = best.age + rec.uniLeft; best.indep = false; if (rec.abroadStudy) best.flags.heirAbroadStudy = true; }
    else if (rec.jobId && E.CAR[rec.jobId]) {
      best.school = null; best.schoolEnd = null; best.cityStudent = null;
      if (!best.job || E.resolveJob(best.job.id) !== rec.jobId) { best.school = null; best.schoolEnd = null; E.startJob(best, rec.jobId, r, function () { }, true); }
      if (best.job) { var c = E.CAR[rec.jobId]; best.job.rank = Math.min(rec.rank || 0, c.t.length - 1); best.job.rankTracked = best.job.rank; best.job.rankSince = best.age - Math.max(0, rec.jyrs || 0); best.job.yrs = rec.jyrs || 0; best.indep = true; }
    } else {
      best.job = null;
      if (best.age >= 18) { best.school = null; best.schoolEnd = null; best.cityStudent = null; }
      best.flags.needJob = best.age >= 18 && !best.retired;
    }
    return best;
  };

  // ===================================================================
  // 2. AI ĐANG Ở ĐÂU
  // ===================================================================
  function together(l) { return E.parentsWithYouAbroad ? E.parentsWithYouAbroad(l) : !!(l.flags.parentsAbroad && l.abroad && l.abroad.perm); }
  function homeName(l) { return isVN(l) ? (l.provLabel || (l.prov && l.prov.old) || 'quê nhà') : (l.city || l.countryName || 'quê nhà'); }
  function guardian(l) { var f = l.fam || {}; return f.mAlive && f.fAlive && !f.noDad ? 'bố mẹ' : f.mAlive ? 'mẹ' : f.fAlive && !f.noDad ? 'bố' : (E.orphanCarer && E.orphanCarer(l)) || 'người thân'; }
  E.whereNow = function (l) {
    if (l.jailUntil != null && l.age < l.jailUntil) return 'Đang thụ án trong trại giam';
    var A = l.abroad;
    if (A) {
      var n = A.name || 'nước ngoài';
      if (A.trapped) return 'Đang bị giữ ở ' + n;
      if (A.study) return 'Đang du học ở ' + n;
      if (A.perm) return 'Định cư ở ' + n + (together(l) ? ', sống cùng ' + guardian(l) : '');
      return 'Đang đi làm ở ' + n + ', gia đình ở ' + homeName(l);
    }
    if (l.flags.military && l.age < l.flags.military) return 'Đang tại ngũ trong doanh trại';
    if (l.age < 18 && !l.indep) return 'Sống cùng ' + guardian(l) + ' ở ' + homeName(l) + ' (' + (l.fam.home || 'nhà riêng') + ')';
    if (l.cityStudent) return 'Sinh viên ở trọ tại ' + (l.cityStudent.city || l.cityStudent || 'thành phố');
    if (l.school === 'police') return 'Học viên ở ký túc xá ' + ((l.flags.academy && l.flags.academy.n) || 'học viện');
    var city = l.movedTo ? 'ở ' + l.movedTo : 'ở ' + homeName(l);
    var house = l.ownHouse ? 'Sống trong ' + (l.houseName && l.houseName !== 'nhà riêng' ? l.houseName : 'nhà riêng') : E.livesWithParents && E.livesWithParents(l) ? 'Sống cùng ' + guardian(l) : l.urban || l.movedTo ? 'Thuê nhà' : 'Sống ở quê';
    return house + ' ' + city;
  };
  E.parentWhere = function (l) {
    if (E.livesWithParents && E.livesWithParents(l)) return together(l) ? 'sống cùng bạn ở ' + l.abroad.name : 'ở cùng nhà với bạn';
    if (l.abroad) return 'ở ' + homeName(l);
    if (l.movedTo || l.cityStudent) return 'ở quê ' + homeName(l);
    return 'ở gần nhà bạn';
  };
  E.kidWhere = function (l, k) {
    if (!k || k.alive === false) return '';
    var ka = l.age - k.born, here = l.abroad && l.abroad.perm ? ' ở ' + l.abroad.name : '';
    if (k.jail && ka < k.jail) return 'trong trại giam';
    if (k.custody === 'other' || k.custody === 'ex') return 'ở với ' + (l.sex === 'M' ? 'mẹ' : 'bố') + ' của bé';
    if (k.uniUntil && k.abroadStudy) return 'đang du học';
    if (ka < 18) return 'sống cùng bạn' + here;
    if (k.uniUntil) return 'ở trọ đi học đại học';
    if (k.married || (k.kids || 0) > 0) return 'đã lập gia đình, ở riêng';
    if (k.job) return ka < 28 ? 'đi làm, vẫn ở cùng bạn' + here : 'đi làm, ở riêng';
    return 'ở cùng bạn' + here;
  };

  // ===================================================================
  // 3. TRƯỜNG QUÂN ĐỘI, CÔNG AN
  // ===================================================================
  // [mã, tên trường, lực lượng, binh chủng / ngành, điểm kiến thức tối thiểu, sức khỏe tối thiểu]
  var ACAD = [
    ['hv_an_ninh', 'Học viện An ninh nhân dân', 'cong_an', 'An ninh', 62, 60],
    ['hv_canh_sat', 'Học viện Cảnh sát nhân dân', 'cong_an', 'Cảnh sát', 60, 60],
    ['dh_an_ninh', 'Trường Đại học An ninh nhân dân', 'cong_an', 'An ninh', 52, 58],
    ['dh_canh_sat', 'Trường Đại học Cảnh sát nhân dân', 'cong_an', 'Cảnh sát', 50, 58],
    ['dh_pccc', 'Trường Đại học Phòng cháy chữa cháy', 'cong_an', 'Cảnh sát PCCC và cứu nạn, cứu hộ', 50, 62],
    ['dh_kthc_cand', 'Trường Đại học Kỹ thuật – Hậu cần CAND', 'cong_an', 'Kỹ thuật – Hậu cần', 50, 55],
    ['hv_ktqs', 'Học viện Kỹ thuật Quân sự', 'quan_doi', 'Kỹ thuật', 66, 58],
    ['hv_quan_y', 'Học viện Quân y', 'quan_doi', 'Quân y', 68, 58],
    ['hv_hai_quan', 'Học viện Hải quân', 'quan_doi', 'Hải quân', 52, 65],
    ['hv_bien_phong', 'Học viện Biên phòng', 'quan_doi', 'Bộ đội Biên phòng', 52, 62],
    ['hv_pk_kq', 'Học viện Phòng không – Không quân', 'quan_doi', 'Phòng không – Không quân', 55, 65],
    ['hv_hau_can', 'Học viện Hậu cần', 'quan_doi', 'Hậu cần', 52, 58],
    ['sq_luc_quan', 'Trường Sĩ quan Lục quân 1 (Đại học Trần Quốc Tuấn)', 'quan_doi', 'Lục quân', 48, 62],
    ['sq_chinh_tri', 'Trường Sĩ quan Chính trị (Đại học Chính trị)', 'quan_doi', 'Chính trị', 50, 58],
    ['sq_thong_tin', 'Trường Sĩ quan Thông tin', 'quan_doi', 'Thông tin liên lạc', 48, 58],
    ['sq_dac_cong', 'Trường Sĩ quan Đặc công', 'quan_doi', 'Đặc công', 45, 72]
  ];
  E.ACADEMIES = ACAD;
  function acad(l) { return l.flags.academy || null; }
  SC('chon_hoc_vien', {
    title: 'Chọn trường quân đội, công an',
    text: function (l) { return 'Bạn đủ điều kiện sơ tuyển (sức khỏe, lý lịch, điểm thi). Hồ sơ được nộp vào một trường. Trường càng "hot" thì điểm chuẩn càng cao. Học 4 năm (Quân y 6 năm), ra trường được phong quân hàm Thiếu úy và phân công công tác.'; },
    opts: ACAD.map(function (x) {
      return { k: x[0], l: x[1], h: (x[2] === 'cong_an' ? 'Công an nhân dân' : 'Quân đội nhân dân') + ' · ' + x[3], req: function (l) { return (l.st.kno || 0) >= x[4] - 8 && (l.st.hea || 0) >= x[5] - 8; }, ai: { w: x[4] >= 60 ? 0.8 : 1 },
        run: function (l, r, log) {
          var hard = (x[4] - (l.st.kno || 0)) / 25 + (x[5] - (l.st.hea || 0)) / 40, p = U.clamp(0.75 - hard, 0.2, 0.95);
          if (r() < p) {
            l.flags.academy = { id: x[0], n: x[1], track: x[2], br: x[3] }; l.flags.policeTrack = x[2]; l.school = 'police'; l.schoolEnd = l.age + (x[0] === 'hv_quan_y' ? 6 : 4);
            log('Đỗ vào ' + x[1] + ', ngành ' + x[3] + '. Ngày nhập học, cả nhà tiễn bạn ra cổng trường, bộ quân phục học viên mới tinh.', 'big'); H.fx(l, { hap: 6 }); H.mem(l, 'Ngày nhập học ' + x[1] + '.', 4);
          } else {
            l.flags.academy = null; l.school = null; l.schoolEnd = null;
            log('Thiếu điểm chuẩn vào ' + x[1] + '. Bạn đành chọn hướng khác.', 'bad'); H.fx(l, { hap: -5 });
            if (E.DEC.uniFail) l.pending.unshift(E.DEC.uniFail.make(l, r));
          }
        } };
    })
  });
  E.MAJOR.chon_hoc_vien = 1;
  // tên nghề kèm binh chủng / lực lượng
  var jt = E.jobTitle;
  E.jobTitle = function (l) { var t = jt.apply(this, arguments), x = acad(l), id = l.job && E.resolveJob(l.job.id); if (x && (id === 'quan_doi' || id === 'cong_an') && x.track === id && t && t.indexOf(x.br) < 0) t += ' · ' + x.br; return t; };
  // học viện nâng cao giữa sự nghiệp
  function uni(l) { var id = l.job && E.resolveJob(l.job.id); return id === 'quan_doi' || id === 'cong_an' ? id : null; }
  var MID = { quan_doi: [['hv_luc_quan', 'Học viện Lục quân', 'đào tạo chỉ huy tham mưu cấp trung đoàn, sư đoàn'], ['hv_chinh_tri', 'Học viện Chính trị', 'đào tạo chính ủy, chính trị viên cấp trung, sư đoàn']], cong_an: [['hv_ct_cand', 'Học viện Chính trị Công an nhân dân', 'bồi dưỡng lãnh đạo, chỉ huy cấp phòng, cấp tỉnh'], ['hv_an_ninh_sdh', 'Học viện An ninh / Cảnh sát (hệ sau đại học)', 'học thạc sĩ chuyên ngành, làm cán bộ nghiệp vụ']] };
  E.HOOKS.year.unshift(function (l, r, log, a) {
    var s = l.flags.midAcadStudy;
    if (!s) return;
    if (uni(l) !== s.track || l.retired) { l.flags.midAcadStudy = null; log('Dừng khóa học ' + s.n + ' do không còn công tác trong lực lượng.', 'neutral'); return; }
    if (a < s.until || (l.jailUntil != null && a < l.jailUntil)) return;
    l.flags.midAcadStudy = null;
    l.flags.midAcad = { id: s.id, n: s.n, at: a };
    l.edu = Math.max(l.edu, 6);
    log('Sau hai năm học ' + s.n + ', bạn tốt nghiệp và trở về đơn vị.', 'good');
    H.fx(l, { kno: 4, hap: 2 }); H.mem(l, 'Ngày tốt nghiệp ' + s.n + '.', 3);
  });
  SC('hv_nang_cao', {
    title: 'Cử đi học nâng cao',
    prep: function (l) { return { u: uni(l) }; },
    valid: function (l) { return !!uni(l) && l.job.rank >= 3 && l.job.rank <= 5 && !l.flags.midAcad && !l.flags.midAcadStudy; },
    text: function (l, d) { return 'Bạn mang quân hàm ' + E.jobTitle(l) + ', được đơn vị đề xuất cử đi học 2 năm. Muốn được bổ nhiệm cấp cao hơn, gần như ai cũng phải qua lớp đào tạo này.'; },
    opts: [0, 1].map(function (i) { return { k: 'h' + i, l: function (l, d) { var m = MID[d.u || uni(l) || 'quan_doi'][i]; return 'Học ' + m[1]; }, h: function (l, d) { return MID[d.u || uni(l) || 'quan_doi'][i][2]; }, ai: { w: 1, amb: 1 }, run: function (l, r, log, d) { if (l.flags.midAcad || l.flags.midAcadStudy) return; var track = uni(l), m = MID[track][i]; l.flags.midAcadStudy = { id: m[0], n: m[1], track: track, at: l.age, until: l.age + 2 }; log('Bắt đầu khóa học hai năm tại ' + m[1] + ', ' + m[2] + '.', 'big'); } }; }).concat([
      { k: 'thoi', l: 'Xin ở lại đơn vị, chưa đi học', ai: { w: 0.3 }, run: function (l, r, log) { l.flags.midAcadNo = (l.flags.midAcadNo || 0) + 1; log('Bạn xin ở lại đơn vị. Cơ hội thăng tiến lên cấp cao vì thế mà chậm lại.', 'neutral'); } }])
  });
  E.TRIG.push({ id: 'hv_nang_cao', when: function (l, a) { return !!uni(l) && l.job.rank >= 3 && l.job.rank <= 5 && !l.flags.midAcad && !l.flags.midAcadStudy && (l.flags.midAcadNo || 0) < 2 && !(l.jailUntil != null && a < l.jailUntil); }, p: 0.35, cd: 3, max: 3 });
  SC('hv_quoc_phong', {
    title: function (l) { return uni(l) === 'cong_an' ? 'Lớp cao cấp lý luận chính trị' : 'Học viện Quốc phòng'; },
    valid: function (l) { return !!uni(l) && l.job.rank === 7 && !!l.flags.midAcad && !l.flags.topAcad; },
    text: function (l) { return uni(l) === 'cong_an' ? 'Là Đại tá, bạn được cử đi học lớp cao cấp lý luận chính trị và bồi dưỡng cán bộ lãnh đạo cấp cao — điều kiện để được xem xét phong hàm cấp tướng.' : 'Là Đại tá, bạn được cử đi học Học viện Quốc phòng — nơi đào tạo cán bộ chiến lược, chiến dịch. Đây là bậc học gần như bắt buộc trước khi được xem xét phong hàm cấp tướng.'; },
    opts: [{ k: 'di', l: 'Đi học', ai: { w: 1.2, amb: 1 }, run: function (l, r, log) { l.flags.topAcad = l.age; log(uni(l) === 'cong_an' ? 'Hoàn thành lớp cao cấp lý luận chính trị.' : 'Tốt nghiệp Học viện Quốc phòng.', 'good'); H.fx(l, { kno: 3 }); } },
      { k: 'thoi', l: 'Không đi, sắp đến tuổi nghỉ hưu', ai: { w: 0.4 }, run: function (l, r, log) { l.flags.topAcad = -1; log('Bạn nhường suất học cho người trẻ hơn.', 'neutral'); } }]
  });
  E.TRIG.push({ id: 'hv_quoc_phong', when: function (l) { return !!uni(l) && l.job.rank === 7 && !!l.flags.midAcad && !l.flags.topAcad; }, p: 0.4, cd: 2, max: 2 });
  // điều kiện thăng quân hàm: lên Thượng tá phải qua học viện cấp trung, lên tướng phải qua Học viện Quốc phòng / lớp cao cấp
  var ca = E.canAdvance;
  if (ca) E.canAdvance = function (l, c, yearEnd) {
    var ok = ca.apply(this, arguments); if (!ok || !c || (c.id !== 'quan_doi' && c.id !== 'cong_an') || !l.job) return ok;
    if (l.job.rank === 5 && !l.flags.midAcad) return false;
    if (l.job.rank === 7 && !(l.flags.topAcad > 0)) return false;
    return true;
  };
  // lộ trình thăng quân hàm
  var LAW = [2, 3, 3, 4, 4, 4, 4, 4];
  ['quan_doi', 'cong_an'].forEach(function (id) { E.CAR[id].yrs = LAW.slice(); });
  SC('lo_trinh_quan_ham', {
    title: 'Lộ trình thăng quân hàm',
    valid: function (l) { return !!uni(l); },
    text: function (l) {
      var c = E.jobDef(l), rk = l.job.rank, since = l.job.rankSince != null ? l.job.rankSince : l.age - (l.job.yrs || 0), inRank = l.age - since;
      var rows = c.t.map(function (t, i) { var mark = i < rk ? '✔ ' : i === rk ? '▶ ' : '○ '; var y = i < c.t.length - 1 ? ' → lên ' + c.t[i + 1] + ' sau tối thiểu ' + c.yrs[i] + ' năm' + (i === 5 ? ' (cần qua ' + (uni(l) === 'cong_an' ? 'Học viện Chính trị CAND' : 'Học viện Lục quân / Học viện Chính trị') + ')' : i === 7 ? ' (cần qua ' + (uni(l) === 'cong_an' ? 'lớp cao cấp' : 'Học viện Quốc phòng') + ', xét theo chức vụ)' : '') : ''; return mark + t + y; });
      var need = c.yrs[rk] || 0, left = Math.max(0, need - inRank);
      return 'Quân hàm hiện tại: ' + c.t[rk] + ' (' + inRank + ' năm ở bậc này' + (rk < c.t.length - 1 ? ', còn khoảng ' + left + ' năm nữa đủ niên hạn' : '') + ').\n' + rows.join('\n') + '\nLộ trình mô phỏng trong game: đủ thời gian chưa chắc được thăng hàm; còn cần hoàn thành nhiệm vụ, đủ sức khỏe, học nâng cao và có chức vụ phù hợp.';
    },
    opts: [{ k: 'ok', l: 'Đã hiểu', ai: { w: 1 }, run: function () { } }]
  });
  E.ACT.push({ id: 'xem_quan_ham', g: 'Công việc', l: 'Xem lộ trình thăng quân hàm', min: 18, sc: 'lo_trinh_quan_ham', avail: function (l) { return uni(l) ? true : 'Chỉ dành cho quân đội, công an'; } });
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
/* ===== js/life97.js ===== */
/* v7.6.0 — Hardcore: kinh tế khắc nghiệt và biến cố có lựa chọn, RNG theo seed. */
(function (G) {
  'use strict';
  var E = G.E, H = E.H, U = G.U, ids = [];
  function hard(l) { return l.difficulty === 'hardcore'; }
  function free(l) { return l.alive && !(l.jailUntil != null && l.age < l.jailUntil) && !(l.flags.military && l.age < l.flags.military) && !(l.abroad && l.abroad.trapped); }
  function adult(l) { return hard(l) && free(l) && l.indep && l.age >= 18; }
  function cost(l, r) { return l.base * (0.08 + r() * 0.17); }
  function pay(l, amount, why, log) { H.cash(l, -amount, why); log(why + ': ' + H.money(l, amount) + '.', 'bad'); }
  function mark(l) { l.flags.hardcoreShocks = (l.flags.hardcoreShocks || 0) + 1; }
  function register(id, def) {
    ids.push(id);
    def.opts.forEach(function (o) { var run = o.run; o.run = function (l, r, log, d) { mark(l); run(l, r, log, d); }; });
    E.SC(id, def);
  }
  register('hc_sua_gap', {
    title: 'Hỏng đúng lúc cạn tiền', valid: adult,
    prep: function (l, r) { return { amount: cost(l, r), item: U.pick(r, ['đường điện trong chỗ ở', 'đường ống nước sinh hoạt', 'thiết bị thiết yếu dùng hằng ngày']) }; },
    text: function (l, d) { return U.cap(d.item) + ' hỏng bất ngờ. Sửa dứt điểm tốn ' + H.money(l, d.amount) + ', trong khi các khoản sinh hoạt vẫn đến hạn.'; },
    opts: [
      { k: 'sua', l: 'Sửa dứt điểm', h: function (l, d) { return H.money(l, d.amount); }, ai: { w: 1, smart: 1 }, run: function (l, r, log, d) { pay(l, d.amount, 'Sửa chữa khẩn cấp', log); H.fx(l, { hap: -2 }); } },
      { k: 'tam', l: 'Khắc phục tạm, tự xoay xở', h: 'Trả 35% chi phí; mất sức và bất tiện', ai: { w: 1.3 }, run: function (l, r, log, d) { pay(l, d.amount * 0.35, 'Khắc phục tạm đồ hỏng', log); H.fx(l, { hea: -3, hap: -5 }); } }
    ]
  });
  register('hc_nha_can_tien', {
    title: 'Gia đình cần tiền gấp', valid: function (l) { return adult(l) && (l.fam.mAlive || (l.fam.fAlive && !l.fam.noDad) || l.kids.some(function (k) { return k.alive !== false; })); },
    prep: function (l, r) { return { amount: cost(l, r) * 1.3 }; },
    text: function (l, d) { return 'Gia đình có việc gấp, cần bạn góp ' + H.money(l, d.amount) + '. Quỹ dự phòng vốn đã mỏng, giúp lần này sẽ phải cắt bớt chi tiêu của mình.'; },
    opts: [
      { k: 'giup', l: 'Góp đủ phần mình', h: function (l, d) { return H.money(l, d.amount); }, ai: { w: 1, moral: 1 }, run: function (l, r, log, d) { pay(l, d.amount, 'Góp tiền giải quyết việc gia đình', log); H.fx(l, { karma: 2, hap: -2 }); } },
      { k: 'it', l: 'Chỉ giúp một phần, cùng tìm cách khác', h: 'Góp 25%; gia đình phải tiếp tục xoay xở', ai: { w: 1.2 }, run: function (l, r, log, d) { pay(l, d.amount * 0.25, 'Góp một phần cho gia đình', log); H.fx(l, { hap: -4 }); } }
    ]
  });
  register('hc_hut_thu', {
    title: 'Thu nhập hụt một khoản', valid: function (l) { return adult(l) && !!l.job && !l.retired && !E.isStableService(l); },
    prep: function (l, r) { return { amount: Math.max(l.base * 0.03, (l.income > 0 ? l.income : l.base * 0.4) * (0.1 + r() * 0.15)) }; },
    text: function (l, d) { return 'Công việc phát sinh khoản hụt thu ' + H.money(l, d.amount) + ': đơn hàng bị hủy hoặc khoản đã hẹn không thanh toán đủ. Bạn phải tìm cách bù lại.'; },
    opts: [
      { k: 'chiu', l: 'Chấp nhận hụt thu, giữ sức', h: function (l, d) { return 'Mất ' + H.money(l, d.amount); }, ai: { w: 1 }, run: function (l, r, log, d) { pay(l, d.amount, 'Khoản thu bị hụt', log); H.fx(l, { hap: -3 }); } },
      { k: 'bu', l: 'Nhận thêm việc để bù một phần', h: 'Vẫn mất 40% khoản hụt; giảm sức khỏe', ai: { w: 1, amb: 1 }, run: function (l, r, log, d) { pay(l, d.amount * 0.4, 'Hụt thu sau khi làm thêm bù đắp', log); H.fx(l, { hea: -5, hap: -3 }); } }
    ]
  });
  register('hc_lua_coc', {
    title: 'Lời mời kiếm tiền cần đặt cọc', valid: function (l) { return adult(l) && !l.retired; },
    prep: function (l, r) { return { amount: cost(l, r), scam: r() < 0.8 }; },
    text: function (l, d) { return 'Một người lạ mời làm việc với khoản tiền khá, nhưng đòi đặt cọc ' + H.money(l, d.amount) + ' trước. Họ liên tục giục bạn chuyển ngay để giữ suất.'; },
    opts: [
      { k: 'bo', l: 'Từ chối yêu cầu đặt cọc', ai: { w: 2, smart: 1 }, run: function (l, r, log) { log('Bạn từ chối chuyển tiền. Bỏ qua một lời hứa hấp dẫn, giữ được khoản dự phòng.', 'neutral'); } },
      { k: 'thu', l: 'Đánh cược chuyển tiền cọc', h: 'Có thể mất toàn bộ tiền cọc', ai: { w: 0.3, risk: 1 }, run: function (l, r, log, d) { if (d.scam) { pay(l, d.amount, 'Mất cọc vì lời mời việc giả', log); H.fx(l, { hap: -8 }); } else { var gain = d.amount * 0.2; H.cash(l, gain, 'Lãi ròng công việc ngắn hạn'); log('Công việc có thật, nhận lại cọc và lãi ròng ' + H.money(l, gain) + '.', 'good'); } } }
    ]
  });
  register('hc_hoc_gap', {
    title: 'Bài làm gặp trục trặc', valid: function (l) { return hard(l) && free(l) && l.age >= 6 && l.age <= 25 && !!l.school && l.school !== 'police'; },
    text: function () { return 'Gần ngày nộp, phần bài đã làm bị hỏng hoặc thất lạc. Thời gian còn rất ít, bạn phải chọn cách xoay xở.'; },
    opts: [
      { k: 'lam', l: 'Thức khuya làm lại', h: 'Giảm sức khỏe; vẫn giữ được tiến độ học', ai: { w: 1, amb: 1 }, run: function (l, r, log) { H.fx(l, { hea: -4, hap: -4, kno: 1 }); log('Bạn làm lại bài trong mấy đêm, nộp kịp nhưng mệt rã rời.', 'bad'); } },
      { k: 'xin', l: 'Xin gia hạn, chấp nhận bị trừ điểm', h: 'Giữ sức; giảm kiến thức và tâm trạng', ai: { w: 1 }, run: function (l, r, log) { H.fx(l, { kno: -3, hap: -3 }); log('Bạn xin thêm thời gian. Bài bị trừ điểm, nhưng bạn không phải cố đến kiệt sức.', 'neutral'); } }
    ]
  });
  register('hc_ap_luc', {
    title: 'Nhiều việc dồn cùng lúc', valid: adult,
    text: function () { return 'Chuyện cơm áo, giấy tờ và những việc chưa giải quyết dồn vào cùng một đợt. Bạn cảm thấy không có chỗ để thở.'; },
    opts: [
      { k: 'nghi', l: 'Dành thời gian nghỉ, giải quyết từng việc', h: 'Trả một khoản nhỏ để nhờ hỗ trợ', ai: { w: 1, smart: 1 }, run: function (l, r, log) { pay(l, l.base * 0.025, 'Nhờ hỗ trợ giải quyết việc tồn đọng', log); if (l.mind) l.mind.stress = Math.max(0, l.mind.stress - 6); H.fx(l, { hap: -2 }); } },
      { k: 'gong', l: 'Tự gồng gánh tất cả', h: 'Không mất tiền; giảm sức khỏe, tăng căng thẳng', ai: { w: 1 }, run: function (l, r, log) { H.fx(l, { hea: -4, hap: -5 }); if (l.mind) l.mind.stress = Math.min(100, l.mind.stress + 8); log('Bạn tự xoay xở hết, tiết kiệm được tiền nhưng mất ngủ nhiều đêm.', 'bad'); } }
    ]
  });
  E.HARDCORE_EVENTS = ids;
  E.hardcoreEvent = function (l, r, a) {
    if (!hard(l) || !free(l) || a < 6) return null;
    if (r() >= (a < 18 ? 0.35 : 0.6)) return null;
    var at = l.flags.hardcoreAt || {}, eligible = ids.filter(function (id) { return (at[id] == null || a - at[id] >= 5) && E.DEC[id].def.valid(l); });
    return eligible.length ? U.pick(r, eligible) : null;
  };
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
