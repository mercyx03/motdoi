window.MOTDOI_GAME_FILES=["assets/game-0.c3e2879cec.js","assets/game-1.4414e1f374.js","assets/game-2.bf0fa38449.js","assets/game-3.8a5710d194.js","assets/game-4.1bcd5e00de.js","assets/game-5.b73f0e9b77.js","assets/game-6.0b0d0623aa.js","assets/game-7.e568d62e30.js","assets/game-8.2701f07c19.js","assets/game-9.36ed1ff459.js","assets/game-10.831791f063.js","assets/game-11.f750e0c2f8.js","assets/game-12.f359b5a991.js","assets/game-13.9a4123692d.js","assets/game-14.5a94699891.js","assets/game-15.0bec30a1b9.js","assets/game-16.197ffc1bb1.js","assets/game-17.0398022fb2.js","assets/game-18.db03eee925.js","assets/game-19.e8ab6bcd86.js","assets/game-20.ef65882cd0.js","assets/game-21.139530036c.js","assets/game-22.bebb649d3a.js","assets/game-23.2810eec8c8.js","assets/game-24.47cdae70d7.js","assets/game-25.8e1a9915d2.js","assets/game-26.3fbc12226c.js","assets/game-27.fc5957cd36.js"];
/* Homepage first: load the game only when its controls are needed. */
(function () {
  'use strict';
  var ready=false, flight=null, next=0, pending=false;
  var files=window.MOTDOI_GAME_FILES || Array.from(document.querySelectorAll('[data-game]')).map(function(s){return s.getAttribute('src');});
  function read(key, fallback){try{return JSON.parse(localStorage.getItem(key))||fallback;}catch(e){return fallback;}}
  var theme=read('mkn.theme',null);
  if(theme)document.documentElement.dataset.theme=theme;
  var status=document.createElement('div');
  status.className='toast hidden';status.setAttribute('role','status');status.setAttribute('aria-live','polite');document.body.appendChild(status);
  function message(text){status.textContent=text;status.classList.remove('hidden');}
  function one(src){return new Promise(function(resolve,reject){
    var script=document.createElement('script'),failure=null;
    function onError(e){if(e.filename===script.src)failure=Error('Không khởi tạo được '+src);}
    window.addEventListener('error',onError);
    script.src=src;script.async=false;
    script.onload=function(){window.removeEventListener('error',onError);if(failure){reject(failure);return;}resolve();};
    script.onerror=function(){window.removeEventListener('error',onError);script.remove();reject(Error('Không tải được '+src));};
    document.head.appendChild(script);
  });}
  function load(){
    if(ready)return Promise.resolve();
    if(flight)return flight;
    message('Đang chuẩn bị trò chơi…');
    document.getElementById('setup').setAttribute('aria-busy','true');
    // Download in parallel; execute in dependency order with a task boundary per chunk.
    files.slice(next).forEach(function(src){var link=document.createElement('link');link.rel='preload';link.as='script';link.href=src;document.head.appendChild(link);});
    flight=(async function(){
      while(next<files.length){await one(files[next]);next++;await new Promise(function(r){setTimeout(r,0);});}
      if(!window.G || !window.G.App)throw Error('Trò chơi chưa khởi tạo xong.');
      ready=true;status.classList.add('hidden');document.getElementById('setup').removeAttribute('aria-busy');
      document.dispatchEvent(new Event('motdoi-ready'));
    })().catch(function(e){flight=null;document.getElementById('setup').removeAttribute('aria-busy');message('Chưa tải được trò chơi. Kiểm tra mạng rồi bấm lại để thử tiếp.');throw e;});
    return flight;
  }
  window.MotDoiBoot={load:load,isReady:function(){return ready;}};
  function start(){load().catch(function(){});}
  document.addEventListener('focusin',function(e){if(!ready&&e.target.closest('#setup'))start();});
  document.addEventListener('pointerover',function(e){if(!ready&&e.target.closest('#setup'))start();},{passive:true});
  document.addEventListener('click',function(e){
    if(ready)return;
    var el=e.target.closest('button, a, [data-go]');if(!el||el.disabled)return;
    if(el.id==='themeBtn'){
      e.preventDefault();e.stopImmediatePropagation();
      var t=document.documentElement.dataset.theme==='light'?'dark':'light';document.documentElement.dataset.theme=t;
      try{localStorage.setItem('mkn.theme',JSON.stringify(t));}catch(err){}return;
    }
    if(el.tagName==='A'){
      var href=el.getAttribute('href');
      if(href==='#tryLife'){start();return;}
      if(href!=='#recentSection')return;
    }
    if(el.dataset.go==='home')return;
    e.preventDefault();e.stopImmediatePropagation();
    if(pending)return;pending=true;
    var id=el.id,href=el.getAttribute('href');
    load().then(function(){
      pending=false;
      if(href==='#recentSection'){document.getElementById('recentSection').scrollIntoView();return;}
      var current=id?document.getElementById(id):el;
      if(current&&current.isConnected)current.click();
    }).catch(function(){pending=false;});
  },true);
  if('IntersectionObserver' in window){
    var observer=new IntersectionObserver(function(entries){if(entries.some(function(e){return e.isIntersecting;})){observer.disconnect();start();}},{rootMargin:'160px'});
    observer.observe(document.getElementById('setup'));
  }
  // Restore only an invitation here; migration and save parsing stay in the engine.
  var current=read('mkn.current',null);
  if(current&&current.life&&current.life.alive){
    var box=document.getElementById('resumeBox'),card=document.createElement('div'),label=document.createElement('b'),button=document.createElement('button');
    card.className='card resume';label.textContent='Bạn có một cuộc đời đang chơi dở';button.className='btn primary';button.id='resumeBtn';button.textContent='Tiếp tục sống';card.append(label,button);box.append(card);
  }
  if(/^#s=/.test(location.hash)||location.hash==='#tryLife'||location.hash==='#recentSection')start();
  window.addEventListener('hashchange',function(){if(/^#s=/.test(location.hash))start();});
})();
