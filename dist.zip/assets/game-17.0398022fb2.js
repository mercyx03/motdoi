/* ===== js/life73.js ===== */
/* Một Đời — v5.8.0:
   · xem tivi: phim / game / gameshow ca nhạc → chọn chương trình (gộp mọi mùa) → chọn người mình thích → từ đó mới có fanmeeting, photocard của đúng người ấy
   · trại lừa đảo Campuchia: việc làm riêng trong trại, mỗi năm có chuyện trong trại; trở về có hồn hơn
   · quan hệ chu cấp có kiểm soát: càng bị kiểm soát càng căng thẳng, kém vui
   · chi phí sinh hoạt theo mức sống gia đình; đám cưới chọn nơi tổ chức, nhẫn cưới, bố mẹ hỗ trợ theo điều kiện
   · chia tay có lý do cụ thể
   · mua điện thoại (iOS, Android, gaming), laptop, PC — dòng máy lên đời theo từng năm */
(function (G) {
  'use strict';
  var U = G.U, E = G.E, H = E.H, SC = E.SC, isVN = H.isVN;
  function fx(l, o) { H.fx(l, o); }
  function stress(l, d) { if (l.mind) l.mind.stress = U.clamp(l.mind.stress + d, 0, 100); }
  function ch(r, p) { return r() < p; }
  function yr(l) { return l.birthYear + l.age; }
  function vnd(l) { return isVN(l) && l.cur === 'vnd' && !(l.abroad && l.abroad.perm); }
  function V(l, tr) { return vnd(l) ? tr : tr / 90 * l.base; }
  function mo(l, v) { return H.money(l, v); }
  function free(l) { return l.alive && !(l.jailUntil != null && l.age < l.jailUntil) && !(l.abroad && l.abroad.trapped) && !(l.flags.military && l.age < l.flags.military); }
  function trapped(l) { return !!(l.alive && l.abroad && l.abroad.trapped); }
  function A(id, g, label, o) { var x = { id: id, g: g, l: label }; for (var k in o) x[k] = o[k]; E.ACT.push(x); }
  function vnHome(l) { return isVN(l) && !l.abroad; }
  function parentsAlive(l) { var f = l.fam || {}; return { m: !f.noMom && f.mAlive, b: !f.noDad && f.fAlive }; }

  // ===================================================================
  // 1. XEM TIVI → CHỌN THẦN TƯỢNG (Việt Nam)
  // ===================================================================
  var CD23 = ['Thu Phương', 'Mỹ Linh', 'Lệ Quyên', 'Trang Pháp', 'Diệp Lâm Anh', 'Ninh Dương Lan Ngọc', 'MLee', 'Hồng Nhung', 'Phương Vy', 'Uyên Linh', 'Lynk Lee', 'Nguyên Hà', 'Diệu Nhi', "H'Hen Niê", 'Đoan Trang', 'Thanh Ngọc', 'Tú Vi', 'Quỳnh Nga', 'Huyền Baby', 'Hà Kino', 'Hương Ly', 'Lưu Hương Giang', 'Khổng Tú Quỳnh', 'Giang Hồng Ngọc', 'Phạm Lịch', 'Thái Trinh', 'Yến Trang', 'Vân Hugo', 'Hoàng Oanh', 'Bảo Anh'];
  var CD24 = ['Minh Tuyết', 'Minh Hằng', 'Tóc Tiên', 'Bùi Lan Hương', 'Dương Hoàng Yến', 'Xuân Nghi', 'Thiều Bảo Trâm', 'Kiều Anh', 'Mie', 'MisThy', 'Phương Thanh', 'Phạm Quỳnh Anh', 'Thảo Trang', 'Ngọc Thanh Tâm', 'Tuimi', 'Ngọc Phước', 'Hoàng Yến Chibi', 'Gil Lê', 'Vũ Ngọc Anh', 'Châu Tuyết Vân', 'Maitinhvi', 'Hậu Hoàng', 'Ngọc Ánh', 'Thúy Hiền', 'Ái Phương', 'Đồng Ánh Quỳnh', 'Thu Ngọc', 'Hạnh Sino'];
  var RAP = [
    ['Rap Việt mùa 1 (2020)', 2020, ['Dế Choắt', 'GDucky', 'MCK', 'Ricky Star', 'tlinh', 'Thành Draw', 'Gonzo', 'Lăng LD', 'Wowy', 'Karik', 'Suboi', 'Binz']],
    ['Rap Việt mùa 2 (2021)', 2021, ['Seachains', 'Blacka', 'B-Wine', 'DLow', 'Hoàng Anh', "Lil' Wuyn", 'VSoul', 'Kellie', 'Rhymastic']],
    ['Rap Việt mùa 3 (2023)', 2023, ['Double2T', '24K.Right', 'Liu Grace', 'Công Hiếu', 'Pháp Kiều', 'Tez', 'Mikelodic', 'Rhyder', 'SMO', 'BigDaddy', 'B Ray', 'Thái VG', 'Andree Right Hand']],
    ['Rap Việt mùa 4 (2024)', 2024, ['Robber', 'Gill', 'MANBO', '7dnight', 'DANMY', 'CoolKid', 'Saabirose', 'Dangrangto', 'Queen B']]
  ];
  function showK(k) { return (E.SHOWS || []).filter(function (s) { return s.k === k; })[0]; }
  var FR = [
    { k: 'atsh', n: 'Anh trai "Say Hi"', s: ['atsh1', 'atsh2'] },
    { k: 'exsh', n: 'Em xinh "Say Hi"', s: ['exsh'] },
    { k: 'thsh', n: 'Tinh hà "Say Hi"', s: ['thsh'] },
    { k: 'atvncg', n: 'Anh trai vượt ngàn chông gai', s: ['atvncg24', 'atvncg26'] },
    { k: 'cd', n: 'Chị đẹp đạp gió rẽ sóng', own: [{ n: 'Chị đẹp đạp gió rẽ sóng 2023', from: 2023, b: 1985, pre: 'chị đẹp', m: CD23, cat: 'vn' }, { n: 'Chị đẹp đạp gió 2024', from: 2024, b: 1986, pre: 'chị đẹp', m: CD24, cat: 'vn' }] },
    { k: 'rap', n: 'Rap Việt', own: RAP.map(function (x) { return { n: x[0], from: x[1], b: 1998, pre: '', m: x[2], cat: 'rapvn' }; }) }
  ];
  function seasons(f) { return f.own ? f.own : f.s.map(showK).filter(Boolean).map(function (s) { return { n: s.n, from: s.from, b: s.b, pre: s.pre, m: s.m, cat: 'show', show: true }; }); }
  function open(l) { var y = yr(l); return FR.filter(function (f) { return seasons(f).some(function (s) { return y >= s.from; }); }); }
  function cast(f, l) { var seen = {}, out = []; seasons(f).filter(function (s) { return yr(l) >= s.from; }).forEach(function (s) { s.m.forEach(function (n) { if (!seen[n]) { seen[n] = 1; out.push({ n: n, s: s }); } else out.forEach(function (x) { if (x.n === n) x.s = s; }); }); }); return out; }
  E.TV_SHOWS = FR; E.tvCast = cast;
  function idolOf(m) { return m.s.pre ? E.memberName(m.s.pre, m.n) : m.n; }
  function setBias(l, r, log, f, m) {
    var was = l.idol, name = idolOf(m);
    l.bias = { n: m.n, show: m.s.n, pre: m.s.pre || '' }; l.idol = name; l.idolCat = m.s.cat; l.idolBorn = m.s.b; l.flags.idolAt = l.age; l.flags.tvBias = f.k;
    log(was && was !== name ? 'Xem ' + f.n + ' xong, bạn "chuyển nhà" sang thích ' + name + '.' : 'Xem ' + f.n + ' trên tivi, bạn "đổ" ' + name + ' ngay từ tiết mục đầu tiên. Từ nay ' + name + ' là thần tượng của bạn.', 'good');
    fx(l, { hap: 3 }); if (!was) H.mem(l, 'Năm ' + l.age + ' tuổi, lần đầu mê ' + name + ' qua chương trình ' + f.n + '.', 3);
  }
  var FILM = { kid: ['Xem phim hoạt hình Doraemon, cười lăn khi Nobita lại bị mẹ mắng.', 'Xem Thám tử lừng danh Conan, đoán hung thủ trước cả Conan.', 'Xem phim hoạt hình Tý Quậy cả buổi chiều.', 'Xem Shin cậu bé bút chì, học lỏm mấy câu nói của Shin.'], teen: ['Cày một bộ phim truyền hình giờ vàng, tối nào cũng chờ tập mới.', 'Xem một bộ phim Hàn Quốc, khóc sưng mắt ở tập cuối.', 'Xem phim chiếu rạp vừa lên mạng, bàn tán cả tuần với bạn.', 'Xem lại phim Tết của năm trước, vẫn cười như lần đầu.'] };
  SC('tv_xem', {
    title: 'Mở tivi', valid: function (l) { return vnHome(l) && free(l); },
    text: function (l) { return (l.age < 12 ? 'Học bài xong, bạn được mở tivi.' : 'Tối nay rảnh, bạn mở tivi, điện thoại.') + ' Bạn muốn xem gì?'; },
    opts: [
      { k: 'phim', l: 'Xem phim', ai: { w: 1 }, run: function (l, r, log) { log(U.pick(r, FILM[l.age < 12 ? 'kid' : 'teen']), 'good'); fx(l, { hap: 2 }); } },
      { k: 'game', l: 'Xem người ta chơi game, rồi chơi theo', ai: { w: 0.9 }, run: function (l, r, log) { if (l.talent === 'game') l.skill = Math.min(100, (l.skill || 20) + 2); log(U.pick(r, ['Xem streamer leo rank, rồi lôi điện thoại ra chơi theo đến khuya.', 'Xem giải đấu game trên mạng, hò hét như xem bóng đá.', 'Xem hướng dẫn chơi game, tập theo từng chiêu.']), 'good'); fx(l, { hap: 2 }); } },
      { k: 'show', l: 'Xem gameshow ca nhạc', h: function (l) { return open(l).map(function (f) { return f.n; }).join(', '); }, req: function (l) { return open(l).length > 0; }, ai: { w: 1.1 }, run: function (l, r) { l.pending.unshift(E.DEC.tv_show.make(l, r)); } },
      { k: 'tat', l: 'Tắt tivi, đi học bài / đi ngủ', ai: { w: 0.5 }, run: function (l, r, log) { fx(l, { kno: 1 }); log('Tắt tivi đi học bài, sáng mai còn đi học sớm.', 'neutral'); } }
    ]
  });
  SC('tv_show', {
    title: 'Xem chương trình nào?', valid: function (l) { return vnHome(l); },
    text: function (l) { return 'Đang có các chương trình âm nhạc' + (yr(l) > 2030 ? ' (chiếu lại và có mùa mới trên mạng)' : '') + '. Bạn chọn xem chương trình nào? Mỗi chương trình gộp tất cả các mùa.' + (l.idol ? ' Thần tượng hiện tại: ' + l.idol + '.' : ''); },
    opts: [0, 1, 2, 3, 4, 5].map(function (i) {
      return { k: 'f' + i, l: function (l) { var f = open(l)[i]; return f ? f.n : ''; }, h: function (l) { var f = open(l)[i]; if (!f) return ''; var ss = seasons(f).filter(function (s) { return yr(l) >= s.from; }); return ss.length + ' mùa · ' + cast(f, l).length + ' người tham gia'; }, req: function (l) { return !!open(l)[i]; }, ai: { w: 1 },
        run: function (l, r) { var f = open(l)[i]; l.pending.unshift(E.DEC.tv_bias.make(l, r, { k: f.k, p: 0 })); } };
    }).concat([{ k: 'thoi', l: 'Thôi, chuyển kênh khác', ai: { w: 0.2 }, run: function () { } }])
  });
  var PER = 10;
  function frK(k) { return FR.filter(function (f) { return f.k === k; })[0]; }
  SC('tv_bias', {
    title: function (l, d) { return frK(d.k).n; },
    prep: function (l, r, a) { var f = frK(a && a.k) || FR[0], p = (a && a.p) || 0; return { k: f.k, p: p }; },
    valid: function (l) { return vnHome(l); },
    text: function (l, d) { var f = frK(d.k), c = cast(f, l); return 'Xem ' + f.n + ', bạn thích ai nhất? (' + (d.p * PER + 1) + '–' + Math.min(c.length, d.p * PER + PER) + ' / ' + c.length + ' người, gộp các mùa)'; },
    opts: Array.apply(null, Array(PER)).map(function (_, i) {
      return { k: 'm' + i, l: function (l, d) { var m = cast(frK(d.k), l)[d.p * PER + i]; return m ? U.cap(idolOf(m)) : ''; }, h: function (l, d) { var m = cast(frK(d.k), l)[d.p * PER + i]; return m ? m.s.n : ''; }, req: function (l, d) { return !!cast(frK(d.k), l)[d.p * PER + i]; }, ai: { w: 1 },
        run: function (l, r, log, d) { var f = frK(d.k), m = cast(f, l)[d.p * PER + i]; if (m) setBias(l, r, log, f, m); } };
    }).concat([
      { k: 'more', l: 'Xem thêm những người khác ›', req: function (l, d) { return cast(frK(d.k), l).length > (d.p + 1) * PER; }, ai: { w: 0.3 }, run: function (l, r, log, d) { l.pending.unshift(E.DEC.tv_bias.make(l, r, { k: d.k, p: d.p + 1 })); } },
      { k: 'back', l: '‹ Xem lại từ đầu', req: function (l, d) { return d.p > 0; }, ai: { w: 0 }, run: function (l, r, log, d) { l.pending.unshift(E.DEC.tv_bias.make(l, r, { k: d.k, p: 0 })); } },
      { k: 'none', l: 'Chỉ xem cho vui, chưa thích ai', ai: { w: 0.5 }, run: function (l, r, log, d) { log('Xem ' + frK(d.k).n + ' cho vui, hát theo vài bài nhưng chưa "đu" ai cả.', 'neutral'); fx(l, { hap: 2 }); } }
    ])
  });
  E.TRIG.push({ id: 'tv_xem', when: function (l, a) { return vnHome(l) && free(l) && a >= 7 && a <= 17; }, p: 0.3, cd: 3, max: 4 });
  A('xem_tv', 'Giải trí', 'Mở tivi xem phim, gameshow', { min: 5, sc: 'tv_xem', avail: function (l) { return vnHome(l) ? true : 'Không áp dụng'; }, ai: { w: 0.2 } });

  // ===================================================================
  // 2. TRẠI LỪA ĐẢO CAMPUCHIA
  // ===================================================================
  function khYears(l) { return Math.max(0, l.age - (l.flags.khSince != null ? l.flags.khSince : l.age)); }
  E.khReturn = function (l, t) {
    var P = parentsAlive(l), y = khYears(l), r = H.rf(l), who;
    var dur = y >= 2 ? 'sau ' + y + ' năm' : 'sau những tháng ngày';
    if (P.m && P.b) who = U.pick(r, ['Mẹ chạy ùa ra, ôm chầm lấy bạn, khóc nấc không nói nên lời. Bố đứng phía sau, mắt đỏ hoe, chỉ lặng lẽ xoa đầu bạn như hồi bé.', 'Bố mẹ đã chờ ở cửa khẩu từ tờ mờ sáng. Vừa thấy bạn, mẹ khuỵu xuống, bố đỡ lấy cả hai mẹ con, ba người ôm nhau giữa dòng người.']);
    else if (P.m) who = 'Mẹ ôm chầm lấy bạn, sờ lên khuôn mặt gầy rộc mà khóc: "Mẹ tưởng không bao giờ gặp lại con nữa."';
    else if (P.b) who = 'Bố ôm bạn thật chặt, đôi vai người đàn ông cả đời không khóc run lên từng hồi.';
    else if (l.partner && l.partner.alive !== false) who = l.partner.name + ' đứng chờ ở cửa khẩu, nắm chặt tay bạn như sợ bạn lại biến mất.';
    else who = 'Không có người thân nào đón, nhưng cán bộ biên phòng đưa cho bạn bát cháo nóng và chiếc điện thoại để gọi về.';
    var feel = U.pick(r, ['Đêm đầu tiên ở nhà, bạn ngủ một giấc không sợ hãi. Bạn thấy mình như được sống lại.', 'Bữa cơm nhà đơn sơ mà bạn ăn trong nước mắt. Lần đầu tiên ' + dur + ' tăm tối, bạn biết mình đã thật sự thoát.', 'Nằm trên chiếc giường cũ, nghe tiếng xe ngoài ngõ, bạn tự hứa sẽ sống tiếp cho cả những người chưa về được.']);
    return t + ' Bạn đặt chân về ' + l.countryName + ' ' + dur + ' bị giam cầm, gầy rộc, tóc rối bù. ' + who + ' ' + feel;
  };
  var KH_LINES = ['Một năm nữa trôi qua sau hàng rào kẽm gai. Bạn đếm ngày bằng những vạch khắc trên chân giường.', 'Đêm nào cũng nghe tiếng la hét từ "phòng tối" cuối hành lang.', 'Bữa ăn chỉ có cơm trắng và rau luộc, ai không đủ chỉ tiêu bị cắt phần.', 'Một người cùng phòng bị bán sang công ty khác, đi không một lời từ biệt.', 'Bạn mơ thấy mình được về nhà, tỉnh dậy gối ướt đẫm.', 'Quản lý đổi kịch bản lừa mới: giả danh nhân viên ngân hàng, giả làm người yêu qua mạng, mời đầu tư tiền ảo.', 'Có người liều nhảy qua tường trốn thoát, cả trại bị siết chặt canh gác suốt mấy tháng.', 'Bảo vệ thay ca, bạn lén nhìn ra khe cửa sổ, thấy cánh đồng xa tít bên kia bức tường.'];
  function khEvt(id, title, text, opts) {
    SC(id, { title: title, tone: 'dark', valid: trapped, text: text, opts: opts });
  }
  function shock(l, log, t, d) { fx(l, { hea: -(d || 12), hap: -6 }); stress(l, 10); log(t, 'bad'); }
  khEvt('kh_chi_tieu', 'Chỉ tiêu tháng này', 'Quản lý giao chỉ tiêu: tháng này phải lừa được đủ số người, ai thiếu sẽ bị đánh và chích điện.', [
    { k: 'lam', l: 'Làm đủ chỉ tiêu để không bị đánh', ai: { w: 1.1 }, run: function (l, r, log) { fx(l, { karma: -5, hap: -5 }); stress(l, 5); log('Bạn làm đủ chỉ tiêu. Đêm về, những cái tên bị lừa cứ hiện lên trong đầu.', 'bad'); } },
    { k: 'qua_loa', l: 'Làm qua loa, cố tình để "con mồi" nghi ngờ', ai: { w: 0.9, karma: 1 }, run: function (l, r, log) { fx(l, { karma: 3 }); if (ch(r, 0.5)) shock(l, log, 'Quản lý phát hiện bạn cố tình làm hỏng việc. Bạn bị lôi ra chích điện trước mặt cả phòng.', 12); else log('Mấy người bạn "chăm" đều nghi ngờ và chặn liên lạc. Bạn bị mắng nhưng thoát trận đòn.', 'neutral'); } },
    { k: 'tu_choi', l: 'Từ chối thẳng, không lừa người khác', ai: { w: 0.4, karma: 1.5 }, run: function (l, r, log) { fx(l, { karma: 6 }); shock(l, log, 'Bạn bị đánh, bị chích điện đến ngất đi rồi nhốt vào phòng tối ba ngày. Sức khỏe sa sút hẳn.', 18); } }
  ]);
  khEvt('kh_nan_nhan', 'Một bà cụ sắp chuyển tiền', 'Người bạn đang phải "chăm" là một bà cụ ở quê, sắp chuyển toàn bộ tiền dưỡng già vì tin bạn là cán bộ ngân hàng.', [
    { k: 'canh_bao', l: 'Lén nhắn cảnh báo bà cụ', ai: { w: 1, karma: 1.5 }, run: function (l, r, log) { fx(l, { karma: 8 }); if (ch(r, 0.4)) shock(l, log, 'Tin nhắn bị phát hiện. Bạn bị nhốt vào phòng tối một tuần, chỉ được uống nước.', 15); else { fx(l, { hap: 3 }); log('Bà cụ không chuyển tiền. Bạn bị trừ phần ăn vì "để sổng khách", nhưng trong lòng nhẹ đi một chút.', 'neutral'); H.mem(l, 'Lần lén cứu một bà cụ khỏi bị lừa, giữa trại lừa đảo.', 4); } } },
    { k: 'cham', l: 'Kéo dài thời gian, viện cớ mạng lỗi', ai: { w: 0.9 }, run: function (l, r, log) { fx(l, { karma: 3 }); if (ch(r, 0.25)) shock(l, log, 'Quản lý nghi ngờ, bạn bị đánh mấy roi điện.', 6); else log('Bạn câu giờ mãi, bà cụ chưa kịp chuyển thì đã được con cháu phát hiện.', 'neutral'); } },
    { k: 'tiep', l: 'Làm theo kịch bản để được yên', ai: { w: 0.6 }, run: function (l, r, log) { fx(l, { karma: -8, hap: -8 }); stress(l, 6); log('Bà cụ chuyển hết tiền. Bạn được thưởng thêm bữa ăn, nhưng không nuốt nổi.', 'bad'); H.mem(l, 'Giọng bà cụ cảm ơn "cháu cán bộ" qua điện thoại — ám ảnh mãi.', 5); } }
  ]);
  khEvt('kh_om', 'Ốm trong trại', 'Bạn sốt cao mấy ngày, người lả đi nhưng vẫn bị bắt ngồi trước máy tính.', [
    { k: 'xin', l: 'Xin thuốc', ai: { w: 1.2 }, run: function (l, r, log) { if (ch(r, 0.5)) { fx(l, { hea: -3 }); log('Được cho mấy viên thuốc hạ sốt, bạn gượng dậy được sau vài ngày.', 'neutral'); } else { fx(l, { hea: -10 }); log('Quản lý bảo "giả bệnh", không cho thuốc. Bạn nằm co ro cả tuần.', 'bad'); } } },
    { k: 'gia_ngat', l: 'Giả vờ ngất để được đưa ra ngoài', ai: { w: 0.4, risk: 1.2 }, run: function (l, r, log) { var x = r(); if (x < 0.15 && E.khFree) { E.khFree(l, log, 'Bạn được đưa đến phòng khám bên ngoài, lựa lúc vắng người chạy thẳng đến đồn cảnh sát.'); } else if (x < 0.5) shock(l, log, 'Bị phát hiện giả vờ, bạn bị đánh đến bầm dập.', 12); else { fx(l, { hea: -5 }); log('Không ai đưa bạn đi đâu cả. Bạn chỉ được nghỉ nửa ngày.', 'neutral'); } } },
    { k: 'chiu', l: 'Cố gượng làm tiếp', ai: { w: 0.6 }, run: function (l, r, log) { fx(l, { hea: -8 }); stress(l, 4); log('Bạn cố gượng ngồi làm, mắt hoa lên, gục xuống bàn mấy lần.', 'bad'); } }
  ]);
  khEvt('kh_ban', 'Bị bán sang công ty khác', 'Bạn nghe tên mình trong danh sách bị "bán" sang một công ty khác, xa biên giới hơn.', [
    { k: 'nho_duong', l: 'Âm thầm ghi nhớ đường đi trên xe', ai: { smart: 1.3, w: 1 }, run: function (l, r, log) { l.flags.khMap = true; fx(l, { kno: 1, hap: -4 }); log('Suốt đường đi bạn nhìn qua khe cửa, ghi nhớ từng khúc quanh, từng tấm biển.', 'neutral'); } },
    { k: 'xin', l: 'Van xin được ở lại', ai: { w: 0.6 }, run: function (l, r, log) { fx(l, { hea: -6, hap: -5 }); log('Lời van xin chỉ đổi lại một trận đòn. Bạn vẫn bị đưa đi.', 'bad'); } },
    { k: 'im', l: 'Im lặng chấp nhận', ai: { w: 0.8 }, run: function (l, r, log) { fx(l, { hap: -5 }); log('Bạn bị đưa sang công ty mới, chỉ tiêu cao hơn, canh gác nghiêm hơn.', 'bad'); } }
  ]);
  khEvt('kh_dong_doi', 'Người mới vào phòng', 'Một cậu thanh niên mới bị lừa sang, đêm nào cũng khóc vì nhớ nhà.', [
    { k: 'an_ui', l: 'An ủi, chia phần ăn', ai: { w: 1.2, soc: 1 }, run: function (l, r, log) { l.flags.khAlly = true; fx(l, { soc: 3, hap: 2, karma: 3 }); log('Bạn chia nửa phần cơm, kể cho cậu ấy nghe cách sống sót. Hai người hứa sẽ cùng nhau về nhà.', 'good'); } },
    { k: 'ke_hoach', l: 'Cùng nhau bàn kế hoạch thoát ra', ai: { w: 0.8, risk: 1 }, run: function (l, r, log) { l.flags.khAlly = true; l.flags.khPlan = true; fx(l, { hap: 2 }); log('Hai người thì thầm bàn kế hoạch mỗi đêm, chia nhau theo dõi giờ đổi ca của bảo vệ.', 'neutral'); } },
    { k: 'ke', l: 'Mặc kệ, tự lo thân mình', ai: { w: 0.5 }, run: function (l, r, log) { fx(l, { hap: -1 }); log('Bạn quay mặt vào tường. Ở đây, thương người khác cũng là một gánh nặng.', 'neutral'); } }
  ]);
  khEvt('kh_co_hoi', 'Cơ hội trốn thoát', 'Đêm mưa to, trại mất điện, camera tắt. Có lẽ đây là cơ hội duy nhất trong năm.', [
    { k: 'tron', l: 'Trốn ngay đêm nay', ai: { risk: 1.3, w: 1 }, run: function (l, r, log) { var p = 0.3 + (l.flags.khMap ? 0.15 : 0) + (l.flags.khAlly ? 0.1 : 0) + (l.flags.khPlan ? 0.1 : 0); var x = r(); if (x < p && E.khFree) E.khFree(l, log, l.flags.khAlly ? 'Hai người dìu nhau trèo qua bức tường trong đêm mưa, chạy xuyên cánh đồng đến đồn cảnh sát.' : 'Bạn trèo qua bức tường trong đêm mưa, chạy xuyên cánh đồng đến đồn cảnh sát.'); else if (x < p + 0.05) { H.kill(l, 'bị đánh khi bỏ trốn khỏi trại lừa đảo ở Campuchia', log, true); l.flags.cambodia = 'Bỏ mạng khi cố trốn khỏi trại lừa đảo ở Campuchia.'; } else shock(l, log, 'Bị bắt lại ngay chân tường. Bạn bị đánh, chích điện rồi nhốt riêng nhiều ngày.', 20); } },
    { k: 'cho', l: 'Chờ dịp an toàn hơn', ai: { w: 0.8 }, run: function (l, r, log) { log('Bạn nằm im nghe tiếng mưa, tự nhủ sẽ còn cơ hội khác.', 'neutral'); fx(l, { hap: -2 }); } }
  ]);
  khEvt('kh_goi_nha', 'Ba phút gọi về nhà', 'Đủ chỉ tiêu, bạn được gọi về nhà ba phút, quản lý đứng ngay cạnh nghe.', [
    { k: 'ma', l: 'Nói lóng cho gia đình hiểu mình đang gặp nạn', ai: { smart: 1.3, w: 1 }, run: function (l, r, log) { if (ch(r, 0.35) && E.khFree) E.khFree(l, log, 'Gia đình hiểu câu nói lóng, báo ngay cho công an và đại sứ quán. Ít tuần sau, cảnh sát Campuchia ập vào trại.'); else { fx(l, { hap: 2 }); log('Mẹ ngập ngừng hỏi lại, bạn không dám nói thêm. Ít nhất cả nhà biết bạn còn sống.', 'neutral'); } } },
    { k: 'on', l: 'Nói dối là mình vẫn ổn để gia đình yên tâm', ai: { w: 0.7 }, run: function (l, r, log) { fx(l, { hap: -3 }); log('"Con vẫn ổn, công việc tốt lắm." Cúp máy, bạn quay mặt đi cho quản lý không thấy nước mắt.', 'bad'); } },
    { k: 'chuoc', l: 'Xin gia đình gom tiền chuộc', ai: { w: 0.8 }, run: function (l, r, log) { log('Bạn nói nhanh số tiền chuộc trước khi bị giật máy.', 'neutral'); if (E.DEC.kh_song) l.pending.unshift(E.DEC.kh_song.make(l, r)); } }
  ]);
  var KH_EV = ['kh_chi_tieu', 'kh_nan_nhan', 'kh_om', 'kh_ban', 'kh_dong_doi', 'kh_co_hoi', 'kh_goi_nha'];
  E.HOOKS.year.unshift(function (l, r, log, a) { // đặt đầu danh sách: độc lập với các hook khác
    if (!trapped(l)) return;
    if (l.flags.khSince == null) l.flags.khSince = a;
    var seen = l.flags.khLines || (l.flags.khLines = {}), left = KH_LINES.filter(function (t, i) { return !seen[i]; });
    if (left.length) { var t = U.pick(r, left); seen[KH_LINES.indexOf(t)] = 1; log(t, 'bad'); }
    if (l.pending.some(function (d) { return /^kh_/.test(d.id); })) return;
    var used = l.flags.khEvAt || (l.flags.khEvAt = {});
    var pool = KH_EV.filter(function (id) { return (used[id] == null || a - used[id] >= 2) && (id !== 'kh_co_hoi' || l.flags.khMap || l.flags.khAlly || a - l.flags.khSince >= 2); });
    if (!pool.length) return; var id = U.pick(r, pool); used[id] = a; l.pending.push(E.DEC[id].make(l, r));
  });
  // việc làm riêng trong trại
  function KA(id, label, text, run) {
    SC(id, { title: label, tone: 'dark', valid: trapped, text: text, opts: [{ k: 'lam', l: 'Làm', ai: { w: 1 }, run: function (l, r, log) { (l.flags.khAct || (l.flags.khAct = {}))[id] = l.age; run(l, r, log); } }, { k: 'thoi', l: 'Thôi', ai: { w: 0.1 }, run: function () { } }] });
    A(id, '🔒 Trong trại lừa đảo', label, { sc: id, trap: true, avail: function (l) { if (!trapped(l)) return 'Không áp dụng'; return (l.flags.khAct || {})[id] === l.age ? 'Đã làm việc này trong năm nay' : true; }, ai: { w: 0.2 } });
  }
  KA('kh_act_chi_tieu', 'Cắm mặt làm đủ chỉ tiêu cho qua ngày', 'Làm đủ chỉ tiêu thì không bị đánh, nhưng phải lừa thêm người khác.', function (l, r, log) { fx(l, { hap: -2, karma: -3 }); stress(l, 3); log('Bạn cắm mặt làm đủ chỉ tiêu. Được yên thân thêm một tháng.', 'neutral'); });
  KA('kh_act_cham', 'Lén làm chậm, để "con mồi" nghi ngờ', 'Cố tình để lộ sơ hở cho người bị lừa nhận ra — nếu bị phát hiện sẽ bị phạt nặng.', function (l, r, log) { fx(l, { karma: 3 }); if (ch(r, 0.35)) shock(l, log, 'Bị phát hiện, bạn bị chích điện giữa phòng.', 10); else log('Mấy người bạn "chăm" đều nhận ra trò lừa và chặn liên lạc. Bạn thở phào.', 'neutral'); });
  KA('kh_act_ban', 'Đùm bọc người cùng phòng', 'Chia nhau phần ăn, thay nhau canh cho người kia ngủ.', function (l, r, log) { l.flags.khAlly = true; fx(l, { soc: 3, hap: 1, karma: 2 }); log('Mấy người cùng phòng đùm bọc nhau, hứa ai về được trước sẽ báo tin cho gia đình người còn lại.', 'good'); });
  KA('kh_act_quan_sat', 'Âm thầm ghi nhớ giờ đổi ca, lối thoát', 'Ghi nhớ giờ đổi ca, chỗ tường thấp, hướng ra đường lớn.', function (l, r, log) { if (ch(r, 0.15)) { fx(l, { hea: -5 }); log('Bảo vệ nghi bạn lảng vảng gần cổng, bạn ăn mấy cú đá.', 'bad'); } else { l.flags.khMap = true; fx(l, { kno: 1 }); log('Bạn đã nhớ được giờ đổi ca và đoạn tường thấp nhất phía sau khu nhà.', 'neutral'); } });
  KA('kh_act_nho', 'Nghĩ về gia đình, tự nhủ phải sống để về', 'Mỗi đêm nhắm mắt nghĩ về nhà để giữ lấy hy vọng.', function (l, r, log) { fx(l, { hap: 2 }); stress(l, -4); log(U.pick(r, ['Bạn nhắm mắt nghĩ về bữa cơm ở nhà, tự nhủ: phải sống để về.', 'Bạn nhẩm lại số điện thoại của gia đình, sợ một ngày mình quên mất.', 'Bạn hát thầm bài hát ngày bé, nước mắt chảy nhưng lòng vững lại.']), 'neutral'); });
  KA('kh_act_cau_cuu', 'Tìm cách mượn điện thoại cầu cứu', 'Mượn lén điện thoại của người khác để nhắn cho gia đình, đại sứ quán.', function (l, r, log) { if (E.khPhone) E.khPhone(l, r, log); });
  KA('kh_act_tron', 'Liều mình trốn thoát', 'Trèo rào, vượt bảo vệ — có thể bị bắt lại, bị đánh, thậm chí mất mạng.', function (l, r, log) { if (E.khEscape) E.khEscape(l, r, log); });
  KA('kh_act_chuoc', 'Nhắn gia đình gom tiền chuộc', 'Xin gia đình gom tiền chuộc bạn ra.', function (l, r, log) { if (E.DEC.kh_song) l.pending.unshift(E.DEC.kh_song.make(l, r)); });

  // ===================================================================
  // 3. CHU CẤP CÓ KIỂM SOÁT: CĂNG THẲNG, KÉM VUI
  // ===================================================================
  E.HOOKS.year.unshift(function (l, r, log, a) {
    if (!E.sponsorActive || !E.sponsorActive(l) || !free(l)) return;
    var s = l.flags.sponsor, c = s.control || 35;
    stress(l, Math.round(4 + c / 10)); fx(l, { hap: -Math.round(1 + c / 20) });
    if (s.feltAt == null || a - s.feltAt >= ((s.feltN = s.feltN || 0) >= 3 ? 5 : 2)) { s.feltAt = a; s.feltN++; log(U.pick(r, c >= 60 ? ['Sống bằng tiền chu cấp của ' + s.name + ', bạn phải báo cáo từng cuộc gặp, từng tin nhắn. Bạn thấy mình như sống trong chiếc lồng mạ vàng.', 'Mỗi lần ra ngoài đều phải xin phép ' + s.name + '. Tiền thì đủ, nhưng bạn mất ngủ triền miên.'] : ['Khoản chu cấp của ' + s.name + ' giúp đỡ chật vật, nhưng bạn luôn thấy mình nợ người ấy điều gì đó.', 'Bạn bè hỏi chuyện tình cảm, bạn chỉ cười trừ. Những ràng buộc với ' + s.name + ' khiến bạn ngày càng ít nói về mình.']), 'bad'); }
  });
  var snA = E.DEC.sn_loi_moi; if (snA) { var snAp = snA.apply; snA.apply = function (l, d, k) { var r0 = snAp.apply(this, arguments); if (k === 'accept' && E.sponsorActive && E.sponsorActive(l)) stress(l, 4); return r0; }; }

  // ===================================================================
  // 4. CHI PHÍ SINH HOẠT THEO MỨC SỐNG
  // ===================================================================
  E.wealthLivingK = function (l, income) {
    var b = Math.max(1, l.base || 1), own = E.netWorth ? E.netWorth(l) : (l.money || 0), p = l.partner && l.partner.status !== 'dating' && l.partner.alive !== false ? l.partner : null;
    var R = (Math.max(0, income || 0) + (p && p.inc > 0 && isFinite(p.inc) ? p.inc * 12 : 0)) / b, W = own / b, k = 1;
    if (W >= 500 || R >= 15) k = 2.6; else if (W >= 100 || R >= 5) k = 1.8; else if (W >= 20 || R >= 2.2) k = 1.35; else if (R < 0.6 && W < 1) k = 0.8;
    if (l.spend === 'save' && k > 1) k = 1 + (k - 1) * 0.5;
    l.flags.livingK = k; return k;
  };
  E.livingLabel = function (l) { var k = l.flags.livingK || 1; return k >= 2.6 ? 'rất giàu' : k >= 1.8 ? 'giàu' : k >= 1.35 ? 'khá giả' : k < 1 ? 'eo hẹp' : 'bình thường'; };

  // ===================================================================
  // 5. ĐÁM CƯỚI: NƠI TỔ CHỨC, NHẪN CƯỚI, BỐ MẸ HỖ TRỢ
  // ===================================================================
  function support(l) { var f = l.fam || {}, P = parentsAlive(l); if (!P.m && !P.b) return 0; if (f.elite && l.flags.eliteFollow && !l.flags.eliteCut) return 1; return [0, 0, 0, 0.15, 0.35, 0.6][f.q || 0] || 0; }
  var VENUE = [
    { k: 'nho', vn: 'Đăng ký kết hôn, làm vài mâm cơm thân mật', w: 'Đăng ký kết hôn, ăn mừng nhỏ với người thân', c: 10, g: 0.5, t: 'làm vài mâm cơm thân mật' },
    { k: 'que', vn: 'Cỗ cưới tại nhà / ở quê, dựng rạp', w: 'Tiệc cưới tại nhà, sân vườn', c: 90, g: 0.9, t: 'dựng rạp làm cỗ ở nhà, cả xóm đến chung vui' },
    { k: 'nha_hang', vn: 'Tiệc cưới ở nhà hàng', w: 'Tiệc cưới ở nhà hàng, hội trường', c: 230, g: 0.8, t: 'đãi tiệc ở nhà hàng tiệc cưới' },
    { k: 'khach_san', vn: 'Tiệc cưới ở khách sạn 5 sao', w: 'Tiệc cưới ở khách sạn sang trọng', c: 900, g: 0.6, t: 'tổ chức ở sảnh tiệc khách sạn 5 sao' },
    { k: 'nuoc_ngoai', vn: 'Cưới ở nước ngoài (Bali, Phuket, Jeju…)', w: 'Cưới ở nước ngoài (destination wedding)', c: 650, g: 0.2, t: 'tổ chức lễ cưới ở nước ngoài, chỉ mời người thân và bạn bè thân thiết' },
    { k: 'sieu', vn: 'Siêu đám cưới, gia đình lo trọn gói', w: 'Đám cưới xa hoa, gia đình lo trọn gói', c: 4000, g: 0.5, t: 'tổ chức một siêu đám cưới, gia đình lo trọn gói từ hoa tươi đến ca sĩ', elite: true }
  ];
  function venueCost(l, v) { return V(l, v.c); }
  function affordable(l, v) { var c = venueCost(l, v), s = support(l); if (v.elite) return s >= 1; return v.k === 'nho' || Math.max(0, l.money) + c * (s + 0.15) + c * v.g * 0.6 >= c; }
  SC('cuoi_to_chuc', {
    title: 'Tổ chức đám cưới', prep: function (l) { return { pid: l.partner ? l.partner.name : '' }; },
    valid: function (l, d) { return !!(l.partner && l.partner.alive !== false && l.partner.status === 'dating' && (!d || !d.pid || d.pid === l.partner.name)); },
    text: function (l, d) { var s = support(l); return 'Hai gia đình bàn chuyện cưới hỏi cho bạn và ' + d.pid + '. ' + (s >= 1 ? 'Gia đình bạn muốn lo trọn gói một đám cưới thật lớn.' : s > 0 ? 'Bố mẹ sẵn sàng lo khoảng ' + Math.round(s * 100) + '% chi phí, nhà bên kia cũng góp thêm một phần.' : 'Bố mẹ không có điều kiện, chi phí chủ yếu do hai bạn tự lo, nhà bên kia góp thêm một ít.') + ' Tiền mừng cưới thường bù lại được một phần. Bạn muốn tổ chức ở đâu?'; },
    opts: VENUE.map(function (v) {
      return { k: v.k, l: function (l) { return vnd(l) ? v.vn : v.w; }, h: function (l) { return 'Khoảng ' + mo(l, venueCost(l, v)); }, req: function (l) { return affordable(l, v); }, ai: { w: v.k === 'que' || v.k === 'nha_hang' ? 1.2 : v.k === 'nho' ? 0.6 : 0.5 },
        run: function (l, r, log, d) { wedding(l, r, log, d, v); } };
    })
  });
  function wedding(l, r, log, d, v) {
    var p = l.partner; if (!p || p.name !== d.pid) return;
    var c = venueCost(l, v), s = v.elite ? 1 : support(l), pf = v.elite ? 0 : c * (0.1 + r() * 0.12), gift = c * v.g * (0.8 + r() * 0.4);
    H.cash(l, -c, 'Tổ chức đám cưới'); if (s > 0) H.cash(l, c * s, 'Bố mẹ lo đám cưới'); if (pf > 0 && v.k !== 'nho') H.cash(l, pf, 'Nhà bên kia góp đám cưới'); H.cash(l, gift, 'Tiền mừng cưới');
    p.status = 'married'; p.since = l.age; l.st.hap += 10; l.st.soc += 5;
    log((vnd(l) ? 'Tổ chức đám cưới với ' : 'Kết hôn với ') + p.name + ': ' + v.t + (s >= 1 ? ', bố mẹ lo trọn gói' : s > 0 ? ', bố mẹ lo ' + Math.round(s * 100) + '% chi phí' : '') + '.', 'big');
    H.mem(l, 'Ngày cưới ' + p.name + ' — bạn cười không ngớt.', 5);
    l.pending.unshift(E.DEC.cuoi_nhan.make(l, r));
  }
  var RING = [
    { k: 'tron', l: 'Nhẫn cưới vàng trơn 18K', c: 9 }, { k: 'kc', l: 'Nhẫn cưới đính kim cương nhỏ', c: 45 },
    { k: 'kc_lon', l: 'Nhẫn kim cương 1 carat', c: 280 }, { k: 'hieu', l: 'Nhẫn thương hiệu xa xỉ (Cartier, Tiffany…)', c: 400 },
    { k: 'gia_truyen', l: 'Dùng nhẫn gia truyền của gia đình', c: 0 }
  ];
  SC('cuoi_nhan', {
    title: 'Nhẫn cưới', valid: function (l) { return !!(l.partner && l.partner.status === 'married'); },
    text: function (l) { return 'Chọn cặp nhẫn cưới cho bạn và ' + l.partner.name + '.'; },
    opts: RING.map(function (x) { return { k: x.k, l: x.l, h: function (l) { return x.c ? 'Khoảng ' + mo(l, V(l, x.c)) : 'Không tốn tiền'; }, req: function (l) { return !x.c || l.money >= V(l, x.c); }, ai: { w: x.k === 'tron' ? 1.3 : x.k === 'kc' ? 1 : x.k === 'gia_truyen' ? 0.5 : 0.3 },
      run: function (l, r, log) { if (x.c) H.cash(l, -V(l, x.c), 'Nhẫn cưới'); l.flags.ring = x.l; log(x.k === 'gia_truyen' ? 'Hai bạn đeo cặp nhẫn gia truyền của gia đình, mẹ dặn phải giữ cho đời sau.' : 'Trao nhau ' + x.l.toLowerCase() + ' trong ngày cưới.', 'good'); } }; })
  });
  var mA = E.DEC.marry, mAp = mA.apply, mMk = mA.make;
  mA.make = function (l, r) { var d = mMk.apply(this, arguments); d.text = d.text.replace(/ Một đám cưới ở quê tốn khoảng [^.]*\./, ' Cưới to hay nhỏ, ở quê, nhà hàng, khách sạn hay ở nước ngoài — tùy điều kiện của hai gia đình.'); d.opts.forEach(function (o) { if (o.k === 'marry' && d.opts.some(function (x) { return x.k === 'small'; })) o.h = 'Chọn nơi tổ chức, nhẫn cưới'; }); return d; };
  mA.apply = function (l, d, k, r, log) { if (k === 'marry' && d.opts.some(function (o) { return o.k === 'small'; }) && l.partner) { l.pending.unshift(E.DEC.cuoi_to_chuc.make(l, r)); return; } return mAp.apply(this, arguments); };

  // ===================================================================
  // 6. CHIA TAY CÓ LÝ DO
  // ===================================================================
  E.breakupWhy = function (l, p, r) {
    var s = l.flags.sponsor, gap = Math.abs((p.age || l.age) - l.age);
    if (s && s.active && s.name === p.name) return U.pick(r, [
      { t: p.name + ' ngỏ lời muốn cưới, nhưng bạn không muốn gắn cả đời mình vào một mối quan hệ bị kiểm soát, nên chủ động nói lời chia tay.', m: 'Ngày từ chối lời cầu hôn của ' + p.name + ' để lấy lại tự do.' },
      { t: p.name + ' đòi bạn cắt đứt bạn bè, chỉ biết đến mình. Bạn quyết định trả lại khoản chu cấp và tự do cho chính mình.' },
      { t: 'Gia đình ' + p.name + ' phát hiện chuyện chu cấp và làm ầm lên, người ấy chọn rút lui.' },
      { t: p.name + ' có "người mới" trẻ hơn. Khoản chu cấp dừng lại cùng một tin nhắn chia tay ngắn ngủi.', m: 'Tin nhắn chia tay lạnh lùng của ' + p.name + '.' }
    ]);
    var L = [
      { t: 'Cãi nhau vì những chuyện nhỏ nhặt mãi thành mệt mỏi, hai người quyết định dừng lại.' },
      { t: 'Cảm giác ban đầu nhạt dần, cả hai thừa nhận đã không còn yêu như trước.' },
      { t: 'Bạn phát hiện ' + p.name + ' nhắn tin mập mờ với người khác.', m: 'Đêm phát hiện ' + p.name + ' không chung thủy.' },
      { t: 'Gia đình hai bên phản đối, không ai đủ can đảm đi tiếp.' },
      { t: p.name + ' muốn cưới ngay, còn bạn thì chưa sẵn sàng.' },
      { t: 'Bạn muốn ổn định, ' + p.name + ' lại chỉ muốn tự do, đi đây đi đó.' },
      { t: 'Ghen tuông, kiểm tra điện thoại liên tục khiến bạn thấy ngột ngạt.' },
      { t: 'Chuyện tiền bạc: ' + p.name + ' vay tiền mãi không trả, lời qua tiếng lại thành rạn nứt.' },
      { t: 'Quan điểm sống khác nhau: chuyện con cái, chỗ ở, công việc mãi không tìm được tiếng nói chung.' }
    ];
    if (l.age < 20) L.push({ t: 'Tình yêu tuổi học trò, lên lớp mới, mỗi người một hướng.' });
    if (gap >= 10) L.push({ t: 'Khoảng cách ' + gap + ' tuổi khiến hai người khó hiểu nhau trong nhiều chuyện.' });
    if (l.abroad || l.cityStudent || l.movedTo) L.push({ t: 'Yêu xa, những cuộc gọi thưa dần rồi tắt hẳn.', m: 'Cuộc gọi cuối cùng với ' + p.name + ' trước khi mối tình yêu xa khép lại.' });
    if (l.job && l.mind && l.mind.stress >= 60) L.push({ t: 'Bạn lao vào công việc, ít thời gian cho nhau, ' + p.name + ' thấy mình bị bỏ rơi.' });
    return U.pick(r, L);
  };

  // ===================================================================
  // 7. MUA ĐIỆN THOẠI, LAPTOP, PC — DÒNG MÁY THEO TỪNG NĂM
  // ===================================================================
  // Giá theo mặt bằng năm 2026 (triệu đ, máy chính hãng ở Việt Nam), mỗi năm tăng nhẹ ~2%; đời mới ra mỗi năm.
  function infl(l) { return Math.pow(1.02, Math.max(0, yr(l) - 2026)); }
  function lineup(l, kind) {
    var y = yr(l), N = y - 2008, A = y - 2024, F = y - 2025, S = y - 2000, Z = y - 2018;
    var L = {
      ios: [['iPhone ' + N + ' Pro Max', 37], ['iPhone ' + N + ' Pro', 32], F >= 1 ? ['iPhone Fold ' + F, 55] : null, ['iPhone Air ' + A, 28], ['iPhone ' + N, 23], ['iPhone ' + N + 'e', 17], ['iPhone ' + (N - 1) + ' Pro Max (đời trước)', 27], ['iPhone ' + (N - 2) + ' (đời cũ)', 13]],
      samsung: [['Galaxy S' + S + ' Ultra', 33], ['Galaxy S' + S, 22], ['Galaxy Z Fold' + Z, 45], ['Galaxy Z Flip' + Z, 26], ['Galaxy A' + (y - 1969), 10], ['Galaxy A' + (y - 1989), 7]],
      xiaomi: [['Xiaomi ' + (y - 2009) + ' Ultra', 30], ['Xiaomi ' + (y - 2009), 20], ['POCO F' + (y - 2018), 11], ['Redmi Note ' + (y - 2011) + ' Pro', 8], ['Redmi ' + (y - 2011), 4]],
      oppo: [['OPPO Find N' + (y - 2020), 45], ['OPPO Find X' + (y - 2016) + ' Pro', 26], ['OPPO Reno' + (y - 2011), 12], ['OPPO A' + (y - 2020), 5]],
      huawei: [['Huawei Mate X' + (y - 2018), 50], ['Huawei Mate ' + (y - 1945) + ' Pro', 30], ['Huawei Pura ' + (y - 1945) + ' Ultra', 33], ['Huawei nova ' + (y - 2011), 11]],
      vivo: [['vivo X' + (y - 1725) + ' Pro', 24], ['vivo V' + (y - 1990), 11], ['vivo Y' + (y - 1990 + 70), 5]],
      pixel: [['Google Pixel ' + (y - 2015) + ' Pro XL', 30], ['Google Pixel ' + (y - 2015), 22], ['Google Pixel ' + (y - 2015) + 'a', 13]],
      gaming: [['ASUS ROG Phone ' + (y - 2016), 28], ['RedMagic ' + (y - 2014) + ' Pro', 19], ['Lenovo Legion Tab Phone ' + (y - 2023), 16], ['POCO F' + (y - 2018) + ' Pro', 13]],
      lt_gaming: [['ASUS ROG Strix SCAR (' + y + ')', 95], ['MSI Raider (' + y + ')', 85], ['Lenovo Legion Pro 7 (' + y + ')', 65], ['ASUS TUF Gaming (' + y + ')', 28], ['Acer Nitro (' + y + ')', 22]],
      lt_vp: [['MacBook Pro ' + (y - 2023) + ' (chip M' + (y - 2020) + ' Pro)', 60], ['MacBook Air (chip M' + (y - 2020) + ')', 28], ['Dell XPS ' + (y - 2010), 45], ['Lenovo ThinkPad X1 Carbon Gen ' + (y - 2012), 40], ['ASUS Zenbook (' + y + ')', 22], ['HP Pavilion (' + y + ')', 16], ['Acer Aspire (' + y + ')', 12]],
      pc: [['PC gaming cao cấp (card RTX ' + (5 + Math.floor((y - 2025) / 2)) + '090)', 120], ['PC gaming tầm trung (card RTX ' + (5 + Math.floor((y - 2025) / 2)) + '070)', 45], ['PC gaming phổ thông (card RTX ' + (5 + Math.floor((y - 2025) / 2)) + '060)', 25], ['PC đồ họa, dựng phim (workstation)', 80], ['PC văn phòng', 11], ['iMac (chip M' + (y - 2020) + ')', 38]]
    };
    return (L[kind] || []).filter(Boolean).map(function (x) { return { n: x[0], c: x[1] * infl(l) }; });
  }
  E.techLineup = lineup;
  var KIND = { phone: [['ios', 'iPhone (iOS)'], ['samsung', 'Samsung'], ['xiaomi', 'Xiaomi'], ['oppo', 'OPPO'], ['huawei', 'Huawei'], ['vivo', 'vivo'], ['pixel', 'Google Pixel'], ['gaming', 'Điện thoại gaming']], laptop: [['lt_gaming', 'Laptop gaming'], ['lt_vp', 'Laptop văn phòng, học tập, MacBook']], pc: [['pc', 'Máy tính để bàn (PC)']] };
  function buyCost(l, x) { return V(l, x.c); }
  function canBuy(l, x) { return l.age < 18 && !l.indep ? true : l.money >= buyCost(l, x); }
  SC('cn_mua', {
    title: 'Mua đồ công nghệ', valid: function (l) { return free(l); },
    text: function (l) { var t = l.flags.tech || {}; return 'Năm ' + yr(l) + '. ' + (t.phone ? 'Điện thoại đang dùng: ' + t.phone.n + ' (mua năm ' + t.phone.y + '). ' : '') + (t.laptop ? 'Laptop: ' + t.laptop.n + '. ' : '') + (t.pc ? 'PC: ' + t.pc.n + '. ' : '') + 'Bạn muốn mua gì?'; },
    opts: [
      { k: 'phone_ios', l: 'Điện thoại iPhone (iOS)', ai: { w: 1 }, run: function (l, r) { l.pending.unshift(E.DEC.cn_mau.make(l, r, { kind: 'ios' })); } },
      { k: 'phone_and', l: 'Điện thoại Android', h: 'Samsung, Xiaomi, OPPO, Huawei, vivo, Google Pixel', ai: { w: 1 }, run: function (l, r) { l.pending.unshift(E.DEC.cn_hang.make(l, r)); } },
      { k: 'phone_game', l: 'Điện thoại gaming', h: 'ROG Phone, RedMagic, Legion…', ai: { w: 0.4 }, run: function (l, r) { l.pending.unshift(E.DEC.cn_mau.make(l, r, { kind: 'gaming' })); } },
      { k: 'lt_gaming', l: 'Laptop gaming', ai: { w: 0.4 }, run: function (l, r) { l.pending.unshift(E.DEC.cn_mau.make(l, r, { kind: 'lt_gaming' })); } },
      { k: 'lt_vp', l: 'Laptop văn phòng, học tập, MacBook', ai: { w: 0.6 }, run: function (l, r) { l.pending.unshift(E.DEC.cn_mau.make(l, r, { kind: 'lt_vp' })); } },
      { k: 'pc', l: 'Máy tính để bàn (PC)', h: 'Gaming, đồ họa, văn phòng, iMac', ai: { w: 0.4 }, run: function (l, r) { l.pending.unshift(E.DEC.cn_mau.make(l, r, { kind: 'pc' })); } },
      { k: 'thoi', l: 'Thôi, máy cũ vẫn dùng tốt', ai: { w: 0.5 }, run: function () { } }
    ]
  });
  SC('cn_hang', {
    title: 'Chọn hãng Android', valid: function (l) { return free(l); }, text: 'Bạn chọn hãng nào?',
    opts: KIND.phone.filter(function (x) { return x[0] !== 'ios' && x[0] !== 'gaming'; }).map(function (x) { return { k: x[0], l: x[1], h: function (l) { return lineup(l, x[0]).slice(0, 3).map(function (m) { return m.n; }).join(', ') + '…'; }, ai: { w: 1 }, run: function (l, r) { l.pending.unshift(E.DEC.cn_mau.make(l, r, { kind: x[0] })); } }; })
  });
  function slot(kind) { return /^lt_/.test(kind) ? 'laptop' : kind === 'pc' ? 'pc' : 'phone'; }
  SC('cn_mau', {
    title: function (l, d) { var all = KIND.phone.concat(KIND.laptop, KIND.pc); var x = all.filter(function (k) { return k[0] === d.kind; })[0]; return x ? x[1] + ' · đời ' + yr(l) : 'Chọn máy'; },
    prep: function (l, r, a) { return { kind: (a && a.kind) || 'ios', y: yr(l) }; },
    valid: function (l, d) { return free(l) && (!d || !d.y || d.y === yr(l)); },
    text: function (l, d) { return 'Các dòng máy đang bán năm ' + yr(l) + '. Giá chính hãng tham khảo.' + (l.age < 18 && !l.indep ? ' Bố mẹ sẽ cân nhắc ngân sách gia đình.' : ' Tiền của bạn: ' + mo(l, Math.max(0, l.money)) + '.'); },
    opts: Array.apply(null, Array(8)).map(function (_, i) {
      return { k: 'm' + i, l: function (l, d) { var m = lineup(l, d.kind)[i]; return m ? m.n : ''; }, h: function (l, d) { var m = lineup(l, d.kind)[i]; return m ? mo(l, buyCost(l, m)) : ''; }, req: function (l, d) { var m = lineup(l, d.kind)[i]; return !!m && canBuy(l, m); }, ai: { w: i >= 2 ? 1 : 0.5 },
        run: function (l, r, log, d) { var m = lineup(l, d.kind)[i]; if (m) buy(l, r, log, d.kind, m); } };
    }).concat([{ k: 'thoi', l: 'Thôi, để dành tiền', ai: { w: 0.3 }, run: function () { } }])
  });
  function buy(l, r, log, kind, m) {
    var c = buyCost(l, m), s = slot(kind), T = l.flags.tech || (l.flags.tech = {}), old = T[s];
    if (l.age < 18 && !l.indep) { var bill = E.childExpense ? E.childExpense(l, c, 'Mua ' + m.n, false) : { ok: false, note: 'Bố mẹ chưa đồng ý.' }; if (!bill.ok) { log('Xin bố mẹ mua ' + m.n + '. ' + bill.note, 'neutral'); fx(l, { hap: -2 }); return; } log('Bố mẹ mua cho bạn ' + m.n + '. ' + bill.note, 'good'); }
    else { if (l.money < c) return; H.cash(l, -c, 'Mua ' + m.n); log((old ? 'Lên đời từ ' + old.n + ' lên ' : 'Mua ') + m.n + '.', 'good'); }
    T[s] = { n: m.n, y: yr(l), c: c }; fx(l, { hap: c > l.base * 0.2 ? 5 : 3 });
    if (/gaming|ROG|RedMagic|Legion|RTX/.test(m.n) && l.talent === 'game') l.skill = Math.min(100, (l.skill || 20) + 3);
    if (s !== 'phone' && /văn phòng|MacBook|ThinkPad|XPS|Zenbook|đồ họa/.test(m.n)) fx(l, { kno: 1 });
  }
  A('mua_cong_nghe', 'Giải trí', 'Mua điện thoại, laptop, PC', { min: 10, sc: 'cn_mua', avail: function (l) { return free(l) ? true : 'Không áp dụng'; }, ai: { w: 0.15 } });
  if (E.SPEND_ACTS && E.SPEND_ACTS.indexOf('mua_cong_nghe') < 0) E.SPEND_ACTS.push('mua_cong_nghe');
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
/* ===== js/life74.js ===== */
/* Một Đời — v5.9.0:
   · con ngoài hôn nhân: có thai khi đang hẹn hò, chưa cưới — cưới chạy bầu, sinh con khi chưa cưới, làm mẹ đơn thân, nhận con và chu cấp nuôi con, hoặc chưa giữ thai
   · nhiều bạn thân hơn (từ trường lớp, giảng đường, chỗ làm, xóm), có chuyện cùng bạn thân, có thể xa cách theo năm tháng
   · có thể hẹn hò với bạn thân (đúng xu hướng tính dục, chênh lệch tuổi hợp lý)
   · định cư nước ngoài: sốc văn hóa, học tiếng bản xứ, thường trú, công nhận bằng cấp, kỳ thị, Tết xa nhà, gửi tiền về nhà, bảo lãnh bố mẹ, dạy con tiếng mẹ đẻ, cộng đồng đồng hương */
(function (G) {
  'use strict';
  var U = G.U, E = G.E, H = E.H, SC = E.SC, W = G.W, isVN = H.isVN;
  function fx(l, o) { H.fx(l, o); }
  function stress(l, d) { if (l.mind) l.mind.stress = U.clamp(l.mind.stress + d, 0, 100); }
  function ch(r, p) { return r() < p; }
  function vnd(l) { return isVN(l) && l.cur === 'vnd' && !(l.abroad && l.abroad.perm); }
  function V(l, tr) { return vnd(l) ? tr : tr / 90 * l.base; }
  function mo(l, v) { return H.money(l, v); }
  function free(l) { return l.alive && !(l.jailUntil != null && l.age < l.jailUntil) && !(l.abroad && l.abroad.trapped) && !(l.flags.military && l.age < l.flags.military); }
  function A(id, g, label, o) { var x = { id: id, g: g, l: label }; for (var k in o) x[k] = o[k]; E.ACT.push(x); }
  function T(id, when, p, cd, max) { E.TRIG.push({ id: id, when: function (l, a) { return free(l) && when(l, a); }, p: p, cd: cd || 3, max: max || 4 }); }
  function parents(l) { var f = l.fam || {}; return { m: !f.noMom && f.mAlive, b: !f.noDad && f.fAlive }; }
  function parentWord(l) { var P = parents(l); return P.m && P.b ? 'bố mẹ' : P.m ? 'mẹ' : P.b ? 'bố' : ''; }
  function pay(l, tr, why) { var x = V(l, tr); H.cash(l, -x, why); return x; }

  // ===================================================================
  // 1. CON NGOÀI HÔN NHÂN
  // ===================================================================
  function dating(l) { var p = l.partner; return !!(p && p.alive !== false && p.status === 'dating'); }
  function momAge(l) { var p = l.partner; return l.sex === 'F' ? l.age : p.age; }
  function fertile(l) { var p = l.partner; return dating(l) && p.sex !== l.sex && l.age >= 18 && p.age >= 18 && momAge(l) <= 44; }
  function birth(l, r, log, mark) {
    var n0 = l.kids.length, p = l.partner; if (!p) return null;
    if (E.RELATIONS108) E.RELATIONS108.deliver(l, p, r, log, {source:'outside'});
    else E.DEC.kid.apply(l, { id: 'kid', data: { adopt: false }, opts: [] }, 'yes', r, log);
    var k = l.kids.length > n0 ? l.kids[l.kids.length - 1] : null;
    if (k) { k.oow = true; k.otherParent = p.name; if (mark) for (var x in mark) k[x] = mark[x]; }
    return k;
  }
  function familyTalk(l, r, log) {
    var pw = parentWord(l); if (!pw) return;
    var strict = isVN(l) && !l.urban;
    log(U.pick(r, strict ? [U.cap(pw) + ' giận mấy hôm vì chuyện "chửa trước", hàng xóm xì xào. Rồi ' + pw + ' vẫn đan cho cháu chiếc áo len đầu tiên.', U.cap(pw) + ' lặng người khi nghe tin, sau cùng chỉ dặn: "Đã có con thì phải sống cho có trách nhiệm."'] : [U.cap(pw) + ' bất ngờ, trách bạn không cẩn thận, nhưng rồi vẫn háo hức chờ cháu.', U.cap(pw) + ' ôm bạn: "Chuyện đã vậy, cả nhà cùng lo."']), 'neutral');
  }
  SC('co_bau_som', {
    title: 'Tin bất ngờ', prep: function (l) { return { pid: l.partner ? l.partner.name : '', me: l.sex === 'F' }; },
    valid: function (l, d) { return fertile(l) && (!d || !d.pid || l.partner.name === d.pid); },
    text: function (l, d) { return (d.me ? 'Que thử hai vạch. Bạn đang mang thai con của ' + d.pid + ', khi hai người còn chưa cưới.' : d.pid + ' báo tin đang mang thai con của bạn, khi hai người còn chưa cưới.') + (isVN(l) && !l.urban ? ' Ở quê, chuyện "chửa trước" vẫn còn bị dị nghị.' : '') + ' Hai bạn sẽ làm gì?'; },
    opts: [
      { k: 'cuoi', l: 'Cưới chạy bầu', h: function (l) { return 'Đám cưới nhỏ, gấp · khoảng ' + mo(l, V(l, 40)); }, ai: { w: 1.2 }, run: function (l, r, log, d) {
        var p = l.partner; if (!p) return; if (l.indep) pay(l, 40, 'Đám cưới chạy bầu'); p.status = 'married'; p.since = l.age; l.st.hap += 6; log('Tổ chức đám cưới chạy bầu với ' + p.name + '. ' + (d.me ? 'Bạn mặc chiếc váy cưới rộng để che bụng bầu.' : 'Cô dâu mặc chiếc váy cưới rộng để che bụng bầu.') + ' Đám cưới gấp mà vẫn đủ đầy họ hàng.', 'big');
        familyTalk(l, r, log); var k = birth(l, r, log); if (k) k.oow = false; H.mem(l, 'Đám cưới chạy bầu với ' + p.name + '.', 4); } },
      { k: 'cung_nuoi', l: 'Sinh con, chưa cưới, cùng nhau nuôi', h: 'Con ngoài giá thú, hai bạn vẫn bên nhau', ai: { w: 0.8 }, run: function (l, r, log, d) { familyTalk(l, r, log); var k = birth(l, r, log); if (k) log('Hai bạn chưa cưới nhưng cùng nhau chăm ' + k.name + '. Giấy khai sinh vẫn ghi đủ tên cả bố lẫn mẹ.', 'neutral'); } },
      { k: 'don_than', l: function (l, d) { return d.me ? 'Một mình sinh và nuôi con' : 'Nhận con nhưng không chung sống, chu cấp nuôi con'; }, h: function (l, d) { return d.me ? 'Làm mẹ đơn thân' : 'Gửi tiền nuôi con hằng tháng đến khi con 18 tuổi'; }, ai: { w: 0.4 }, run: function (l, r, log, d) {
        var p = l.partner; if (!p) return; var name = p.name; familyTalk(l, r, log);
        var k = birth(l, r, log, d.me ? null : { custody: 'other' });
        l.partner = null; l.exes = (l.exes || 0) + 1; l.st.hap -= 6; stress(l, 8);
        if (d.me) { l.flags.singleParent = true; log(U.pick(r, [name + ' không muốn có trách nhiệm, cắt đứt liên lạc. Bạn một mình vượt cạn, một mình nuôi con.', 'Hai người chia tay trước ngày sinh. Bạn quyết định làm mẹ đơn thân, ôm con vào lòng mà tự nhủ phải mạnh mẽ.']), 'bad'); H.mem(l, 'Một mình bế con ' + (k ? k.name : '') + ' về nhà sau ngày sinh.', 6); }
        else { log('Bạn và ' + name + ' chia tay, con ở với mẹ. Bạn nhận con, ký giấy chu cấp nuôi con hằng tháng và vẫn thường đến thăm.', 'neutral'); } } },
      { k: 'chua_giu', l: 'Chưa sẵn sàng, quyết định không giữ thai', h: 'Được bác sĩ tư vấn ở cơ sở y tế uy tín', ai: { w: 0.4 }, run: function (l, r, log, d) {
        if (E.RELATIONS108) E.RELATIONS108.cancelPregnancy(l, l.partner);
        l.st.hap -= 8; stress(l, 8); log('Sau nhiều đêm suy nghĩ, hai bạn quyết định chưa giữ lại em bé. ' + (d.me ? 'Bạn' : d.pid) + ' đến cơ sở y tế uy tín, được bác sĩ tư vấn kỹ. Chuyện ấy để lại một khoảng lặng rất lâu.', 'bad'); H.mem(l, 'Quyết định khó khăn nhất năm ' + l.age + ' tuổi.', 4);
        if (ch(r, 0.3) && l.partner) { var n = l.partner.name; l.partner = null; l.exes = (l.exes || 0) + 1; log('Sau chuyện ấy, bạn và ' + n + ' dần xa nhau rồi chia tay.', 'bad'); } } }
    ]
  });
  T('co_bau_som', function (l) { return fertile(l) && l.age - l.partner.since >= 1; }, 0.035, 3, 2);
  // tiền chu cấp nuôi con khi con sống với người kia
  E.HOOKS.year.unshift(function (l, r, log, a) {
    if (!l.alive || !l.indep) return;
    (l.kids || []).forEach(function (k) {
      if (k.alive === false || k.custody !== 'other') return; var age = a - k.born; if (age < 0 || age >= 18) return;
      var x = V(l, 48); H.cash(l, -x, 'Tiền chu cấp nuôi con ' + k.name);
      if (age === 0 || age % 5 === 0) log('Gửi tiền nuôi con ' + k.name + ' (' + age + ' tuổi) cho mẹ của bé, cuối tuần đến đón con đi chơi.', 'neutral');
    });
  });

  // ===================================================================
  // 2. NHIỀU BẠN THÂN HƠN
  // ===================================================================
  function friends(l) { return (l.friends || (l.friends = [])); }
  function liveFriends(l) { return friends(l).filter(function (f) { return f.alive !== false; }); }
  function fAge(l, f) { return l.age + (f.d || 0); }
  E.friendsOf = function (l) { return [l.bff].concat(friends(l)).filter(function (f) { return f && f.alive !== false; }); };
  function where(l) { if (l.school && /^(primary|lower|upper|priv)$/.test(l.school)) return ['trường', 'Ngồi cùng bàn, cùng đi học về']; if (l.school && /^(uni|post|phd|voc|police)$/.test(l.school)) return ['giảng đường', 'Cùng nhóm làm bài tập, cùng ở trọ gần nhau']; if (l.job) return ['chỗ làm', 'Cùng ca, cùng ăn trưa, cùng than chuyện công việc']; return ['xóm', 'Hàng xóm sát vách, chiều nào cũng ngồi cà phê với nhau']; }
  SC('ban_than_moi', {
    title: 'Một người bạn mới',
    prep: function (l, r) { var s = r() < 0.6 ? l.sex : (l.sex === 'M' ? 'F' : 'M'), w = where(l); return { n: H.stranger(l, r, s), sex: s, d: U.randint(r, l.age < 18 ? -1 : -4, l.age < 18 ? 1 : 4), w: w[0], how: w[1] }; },
    valid: function (l) { return liveFriends(l).length < 4; },
    text: function (l, d) { return 'Ở ' + d.w + ', bạn ngày càng thân với ' + d.n + ' (' + (d.sex === 'M' ? 'nam' : 'nữ') + ', ' + Math.max(6, l.age + d.d) + ' tuổi). ' + d.how + '.'; },
    opts: [
      { k: 'than', l: 'Kết thân, coi nhau như bạn thân', ai: { w: 1.3, soc: 1 }, run: function (l, r, log, d) { friends(l).push({ name: d.n, sex: d.sex, d: d.d, since: l.age, close: 65, alive: true, from: d.w }); fx(l, { soc: 4, hap: 2 }); log('Từ đó ' + d.n + ' thành một người bạn thân của bạn.', 'good'); H.mem(l, 'Ngày thân với ' + d.n + ' ở ' + d.w + '.', 2); } },
      { k: 'xa', l: 'Chỉ là bạn bình thường', ai: { w: 0.5 }, run: function (l, r, log, d) { log('Bạn và ' + d.n + ' vẫn chào hỏi, nhưng không thân hơn.', 'neutral'); } }
    ]
  });
  T('ban_than_moi', function (l, a) { return a >= 8 && a <= 65 && liveFriends(l).length < 4; }, 0.12, 4, 4);
  function pickFriend(l, r, cond) { var list = E.friendsOf(l).filter(function (f) { return !cond || cond(f); }); return list.length ? U.pick(r, list) : null; }
  SC('ban_than_hen', {
    title: function (l, d) { return 'Hẹn với ' + d.n; },
    prep: function (l, r) { var f = pickFriend(l, r); return { n: f ? f.name : '' }; },
    valid: function (l, d) { return E.friendsOf(l).some(function (f) { return !d || !d.n || f.name === d.n; }) && E.friendsOf(l).length > 0; },
    text: function (l, d) { return d.n + ' nhắn tin: "Lâu rồi không gặp, cuối tuần này rảnh không?"'; },
    opts: [
      { k: 'an', l: 'Đi ăn, đi cà phê', ai: { w: 1.2 }, run: function (l, r, log, d) { var f = find(l, d.n); if (f) f.close = Math.min(100, (f.close || 50) + 6); if (l.age >= 18) H.cash(l, -V(l, 0.3), 'Đi chơi với bạn thân'); fx(l, { hap: 3, soc: 3 }); log(U.pick(r, ['Ngồi với ' + d.n + ' từ chiều đến tối, chuyện cũ chuyện mới kể mãi không hết.', 'Đi ăn với ' + d.n + ', cười đau cả bụng vì mấy chuyện ngày xưa.', d.n + ' rủ đi một quán mới mở, hai đứa chụp cả trăm tấm ảnh.']), 'good'); } },
      { k: 'tam_su', l: 'Ngồi tâm sự chuyện đời', ai: { w: 1 }, run: function (l, r, log, d) { var f = find(l, d.n); if (f) f.close = Math.min(100, (f.close || 50) + 8); stress(l, -6); fx(l, { hap: 2 }); log('Kể cho ' + d.n + ' nghe những chuyện chưa dám nói với ai. Nhẹ lòng hẳn.', 'good'); } },
      { k: 'ban', l: 'Bận, hẹn dịp khác', ai: { w: 0.5 }, run: function (l, r, log, d) { var f = find(l, d.n); if (f) f.close = Math.max(0, (f.close || 50) - 5); log('Bạn từ chối vì bận. ' + d.n + ' nhắn "ok", nghe hơi buồn.', 'neutral'); } }
    ]
  });
  function find(l, n) { return E.friendsOf(l).filter(function (f) { return f.name === n; })[0]; }
  T('ban_than_hen', function (l, a) { return a >= 10 && E.friendsOf(l).length > 0; }, 0.12, 3);
  SC('ban_than_kho', {
    title: function (l, d) { return d.n + ' gặp chuyện'; },
    prep: function (l, r) { var f = pickFriend(l, r, function (f) { return fAge(l, f) >= 18; }); return { n: f ? f.name : '', why: U.pick(r, ['vừa mất việc', 'vừa chia tay người yêu', 'có người nhà nằm viện', 'làm ăn thua lỗ']) }; },
    valid: function (l, d) { return !!(d && d.n && find(l, d.n)) || E.friendsOf(l).some(function (f) { return fAge(l, f) >= 18; }); },
    text: function (l, d) { return d.n + ' ' + d.why + ', gọi cho bạn lúc nửa đêm.'; },
    opts: [
      { k: 'o_ben', l: 'Đến ngay, ở bên an ủi', ai: { w: 1.3, karma: 1 }, run: function (l, r, log, d) { var f = find(l, d.n); if (f) f.close = Math.min(100, (f.close || 50) + 12); fx(l, { karma: 3, soc: 2 }); log('Bạn chạy đến ngay trong đêm, ngồi cạnh ' + d.n + ' đến sáng. Có những lúc chỉ cần có người ở bên.', 'good'); } },
      { k: 'cho_vay', l: 'Cho vay tiền giúp bạn qua khó khăn', req: function (l) { return l.indep && l.money >= V(l, 20); }, h: function (l) { return 'Khoảng ' + mo(l, V(l, 20)); }, ai: { w: 0.8 }, run: function (l, r, log, d) { var f = find(l, d.n); pay(l, 20, 'Cho bạn thân vay'); if (ch(r, 0.7)) { H.cash(l, V(l, 20), 'Bạn thân trả nợ'); if (f) f.close = Math.min(100, (f.close || 50) + 10); log(d.n + ' vượt qua khó khăn, vài tháng sau trả đủ tiền kèm một bữa cơm cảm ơn.', 'good'); } else { if (f) f.close = Math.max(0, (f.close || 50) - 25); log(d.n + ' hẹn mãi không trả, tình bạn bắt đầu có vết rạn.', 'bad'); } } },
      { k: 'ban', l: 'Nhắn tin hỏi han vì đang bận', ai: { w: 0.5 }, run: function (l, r, log, d) { var f = find(l, d.n); if (f) f.close = Math.max(0, (f.close || 50) - 6); log('Bạn chỉ kịp nhắn vài dòng hỏi han.', 'neutral'); } }
    ]
  });
  T('ban_than_kho', function (l, a) { return a >= 18 && E.friendsOf(l).some(function (f) { return fAge(l, f) >= 18; }); }, 0.06, 5);
  // xa cách theo năm tháng, tuổi già mất bạn
  E.HOOKS.year.unshift(function (l, r, log, a) {
    if (!l.alive || !l.friends || !l.friends.length) return;
    l.friends.forEach(function (f) {
      if (f.alive === false) return;
      if (fAge(l, f) >= 70 && r() < (fAge(l, f) - 60) / 400) { f.alive = false; f.died = a; if (E.personDied) E.personDied(l, f, a); var mate = l.partner && l.partner.name === f.name && l.partner.alive !== false; /* v7.2: bạn thân cũng là vợ / chồng */ if (mate) { log((l.partner.status === 'dating' ? 'Người yêu ' : l.partner.sex === l.sex ? 'Người bạn đời ' : l.partner.sex === 'M' ? 'Chồng ' : 'Vợ ') + f.name + ', người bạn thân từ thuở nào, qua đời ở tuổi ' + fAge(l, f) + '.', 'bad'); if (E.partnerGone) E.partnerGone(l, a); else l.partner = null; fx(l, { hap: -16 }); H.mem(l, 'Ngày mất ' + f.name + ' — vừa là bạn thân, vừa là người thương.', 7); return; } log('Người bạn thân ' + f.name + ' qua đời ở tuổi ' + fAge(l, f) + '. Bạn đứng lặng rất lâu trước di ảnh của bạn.', 'bad'); fx(l, { hap: -8 }); H.mem(l, 'Tiễn người bạn thân ' + f.name + '.', 4); return; }
      if (!f.lover) f.close = Math.max(0, (f.close || 50) - (l.movedTo || (l.abroad && l.abroad.perm) ? 3 : 1));
      if (f.close < 25 && !f.faded) { f.faded = true; log('Mỗi người một cuộc sống, bạn và ' + f.name + ' dần xa cách, chỉ còn chúc mừng sinh nhật trên mạng.', 'neutral'); }
      if (f.lover && !(l.partner && l.partner.name === f.name)) { f.lover = false; f.close = Math.min(f.close, 30); log('Chia tay rồi, bạn và ' + f.name + ' không còn thân như trước.', 'neutral'); }
    });
  });

  // ===================================================================
  // 3. HẸN HÒ VỚI BẠN THÂN
  // ===================================================================
  function okSex(l, s) { return l.orient === 'gay' ? s === l.sex : l.orient === 'bi' ? true : s !== l.sex; }
  function crushes(l) { if (l.partner || l.age < 16) return []; return E.friendsOf(l).filter(function (f) { var fa = l.age + (f.d || 0); return !f.lover && !f.taken && !f.wed && !f.married && f.status !== 'married' && (f.close || 0) >= 55 && okSex(l, f.sex) && fa >= 16 && Math.abs(f.d || 0) <= 10; }); }
  SC('yeu_ban_than', {
    title: 'Tình bạn hay tình yêu?',
    prep: function (l, r) { var c = crushes(l), f = c.length ? U.pick(r, c) : null; return { n: f ? f.name : '' }; },
    valid: function (l, d) { return crushes(l).some(function (f) { return !d || !d.n || f.name === d.n; }); },
    text: function (l, d) { var f = find(l, d.n); return 'Bạn và ' + d.n + ' thân nhau đã ' + Math.max(1, l.age - (f && f.since != null ? f.since : l.age)) + ' năm. Dạo gần đây, mỗi lần ' + d.n + ' cười, tim bạn lại lỡ một nhịp. Nói ra thì sợ mất bạn, không nói thì sợ mất người.'; },
    opts: [
      { k: 'to_tinh', l: 'Tỏ tình', ai: { w: 0.9, risk: 1 }, run: function (l, r, log, d) { var f = find(l, d.n); if (!f || !crushes(l).some(function (x) { return x.name === d.n; })) return; if (ch(r, U.clamp(0.3 + (f.close || 50) / 200, 0.3, 0.8))) becomeLovers(l, r, log, f, 'Bạn lấy hết can đảm tỏ tình. ' + f.name + ' im lặng một lúc rồi cười: "Mình cũng thích cậu từ lâu rồi."'); else { f.close = Math.max(0, (f.close || 50) - 20); fx(l, { hap: -5 }); log(f.name + ' từ chối nhẹ nhàng: "Mình chỉ coi cậu là bạn thân thôi." Hai người ngại ngùng mất một thời gian.', 'bad'); } } },
      { k: 'cho', l: 'Chờ xem người ấy có tình cảm không', ai: { w: 0.8 }, run: function (l, r, log, d) { var f = find(l, d.n); if (!f || !crushes(l).some(function (x) { return x.name === d.n; })) return; if (ch(r, 0.3)) becomeLovers(l, r, log, f, 'Một tối đi về, ' + f.name + ' bất ngờ nắm tay bạn: "Mình thích cậu." Hóa ra cả hai cùng chờ nhau.'); else log('Bạn giữ cảm xúc trong lòng, vẫn bên ' + d.n + ' như một người bạn.', 'neutral'); } },
      { k: 'giu', l: 'Giữ tình bạn, không nói ra', ai: { w: 0.7 }, run: function (l, r, log, d) { log('Bạn chọn giữ tình bạn với ' + d.n + '. Có những người, ở bên như bạn đã là đủ.', 'neutral'); } }
    ]
  });
  function becomeLovers(l, r, log, f, t) {
    if (l.partner || !f || f.wed || f.married || f.status === 'married' || f.taken) return;
    var p = { name: f.name, sex: f.sex, age: l.age + (f.d || 0), status: 'dating', since: l.age, alive: true, fromFriend: true };
    if (p.age >= 18 && H.partnerJob) H.partnerJob(l, p, r);
    l.partner = p; f.lover = true; f.close = Math.min(100, (f.close || 50) + 15);
    if (!l.flags.everDated) { l.flags.everDated = true; if (!l.flags.firstLove) l.flags.firstLove = f.name; }
    log(t + ' Bạn thân thành người yêu.', 'big'); fx(l, { hap: 10 }); H.mem(l, 'Ngày ' + f.name + ' từ bạn thân thành người yêu.', 5);
  }
  T('yeu_ban_than', function (l) { return crushes(l).length > 0; }, 0.07, 4, 3);
  A('to_tinh_ban_than', 'Tình cảm', 'Tỏ tình với bạn thân', { min: 16, sc: 'yeu_ban_than', avail: function (l) { return l.partner ? 'Đang có người yêu / bạn đời' : crushes(l).length ? true : 'Chưa có bạn thân phù hợp'; }, ai: { w: 0.05 } });
  A('hen_ban_than', 'Gia đình & bạn bè', 'Hẹn gặp bạn thân', { min: 8, sc: 'ban_than_hen', avail: function (l) { return E.friendsOf(l).length ? true : 'Chưa có bạn thân'; }, ai: { w: 0.15 } });

  // ===================================================================
  // 4. ĐỊNH CƯ NƯỚC NGOÀI
  // ===================================================================
  var LANG = { US: 'en', GB: 'en', CA: 'en', AU: 'en', NZ: 'en', IE: 'en', SG: 'en', JP: 'ja', KR: 'ko', CN: 'zh', TW: 'zh', DE: 'de', AT: 'de', CH: 'de' };
  var LNAME = { FR: 'tiếng Pháp', BE: 'tiếng Pháp', ES: 'tiếng Tây Ban Nha', MX: 'tiếng Tây Ban Nha', IT: 'tiếng Ý', PT: 'tiếng Bồ Đào Nha', BR: 'tiếng Bồ Đào Nha', NL: 'tiếng Hà Lan', SE: 'tiếng Thụy Điển', NO: 'tiếng Na Uy', DK: 'tiếng Đan Mạch', FI: 'tiếng Phần Lan', PL: 'tiếng Ba Lan', CZ: 'tiếng Séc', RU: 'tiếng Nga', TH: 'tiếng Thái', MY: 'tiếng Mã Lai', AE: 'tiếng Ả Rập', SA: 'tiếng Ả Rập', IL: 'tiếng Do Thái', TR: 'tiếng Thổ Nhĩ Kỳ' };
  E.langOf = function (code) { return LANG[code] || null; };
  var PR = { US: 'thẻ xanh', CA: 'thường trú nhân (PR)', AU: 'thường trú (PR)', NZ: 'thường trú (resident visa)', GB: 'quyền định cư vĩnh viễn (ILR)', DE: 'giấy phép định cư (Niederlassungserlaubnis)', FR: 'thẻ cư trú dài hạn', JP: 'tư cách vĩnh trú (eijū)', KR: 'thẻ thường trú F-5', TW: 'thẻ cư trú vĩnh viễn (APRC)', SG: 'thường trú nhân (PR)' };
  function settled(l) { return !!(l.alive && l.abroad && l.abroad.perm && !l.abroad.trapped && l.age >= 16 && free(l)); }
  function host(l) { var c = l.abroad.code, B = W.BY[c]; return B ? B.name : (l.abroad.name || c); }
  function homeName(l) { return l.countryName || (W.BY[l.country] && W.BY[l.country].name) || 'quê nhà'; }
  function yrsHere(l) { return Math.max(0, l.age - (l.abroad.since != null ? l.abroad.since : l.age)); }
  function langName(l) { var c = l.abroad.code; return LANG[c] ? { en: 'tiếng Anh', ja: 'tiếng Nhật', ko: 'tiếng Hàn', zh: 'tiếng Trung', de: 'tiếng Đức' }[LANG[c]] : LNAME[c] || 'tiếng bản xứ'; }
  function countryOf(l) { return l.abroad.code; }
  function compat(l) { return isVN(l) || l.country === 'VN' ? 'người Việt' : 'người đồng hương'; }
  E.HOOKS.year.unshift(function (l, r, log, a) { if (l.abroad && l.abroad.perm && l.abroad.since == null) l.abroad.since = a; });
  SC('dc_van_hoa', {
    title: function (l) { return 'Những ngày đầu ở ' + host(l); }, valid: settled,
    text: function (l) { return 'Mọi thứ ở ' + host(l) + ' đều lạ: cách chào hỏi, giờ giấc, đồ ăn, cả cách đổ rác. Nhiều đêm bạn nhớ ' + homeName(l) + ' đến không ngủ được.'; },
    opts: [
      { k: 'hoa_nhap', l: 'Chủ động làm quen người bản xứ, học cách sống ở đây', ai: { w: 1.1, soc: 1 }, run: function (l, r, log) { fx(l, { soc: 4, kno: 2, hap: 2 }); log('Bạn nhận lời mời của hàng xóm, tập nói chuyện bằng ' + langName(l) + ' dù còn vấp váp. Dần dần thấy nơi đây bớt xa lạ.', 'good'); } },
      { k: 'cong_dong', l: 'Tìm đến cộng đồng ' + 'đồng hương', ai: { w: 1 }, run: function (l, r, log) { fx(l, { soc: 3, hap: 3 }); log('Bạn tìm được hội ' + compat(l) + ' ở thành phố, cuối tuần cùng nhau nấu món quê nhà.', 'good'); } },
      { k: 'thu_minh', l: 'Thu mình, chỉ đi làm rồi về nhà', ai: { w: 0.5 }, run: function (l, r, log) { fx(l, { hap: -4 }); stress(l, 5); log('Bạn thu mình trong căn phòng nhỏ, chỉ nói chuyện với người nhà qua điện thoại.', 'bad'); } }
    ]
  });
  T('dc_van_hoa', function (l) { return settled(l) && yrsHere(l) <= 1; }, 0.7, 5, 1);
  SC('dc_hoc_tieng', {
    title: function (l) { return 'Học ' + langName(l); }, valid: settled,
    text: function (l) { return 'Thành phố có lớp ' + langName(l) + ' cho người nhập cư, học buổi tối. Biết tiếng thì dễ tìm việc, dễ thi quốc tịch hơn.'; },
    opts: [
      { k: 'hoc', l: function (l) { return 'Đăng ký lớp ' + langName(l) + ' buổi tối'; }, ai: { w: 1.2, smart: 1 }, run: function (l, r, log) { var k = LANG[countryOf(l)], F = l.flags.localLang || (l.flags.localLang = {}); F[countryOf(l)] = (F[countryOf(l)] || 0) + 1; if (k && H.langNext && H.langNext(l, k) != null) H.studyLang(l, k, r, log); else { pay(l, 3, 'Học ' + langName(l)); fx(l, { kno: 2 }); log('Sau mấy tháng học tối, bạn đã tự đi khám bệnh, làm giấy tờ bằng ' + langName(l) + ' được.', 'good'); } } },
      { k: 'app', l: 'Tự học qua ứng dụng, xem phim bản xứ', ai: { w: 0.8 }, run: function (l, r, log) { var F = l.flags.localLang || (l.flags.localLang = {}); F[countryOf(l)] = (F[countryOf(l)] || 0) + 0.5; fx(l, { kno: 1 }); log('Tối nào cũng học vài từ mới trên ứng dụng, xem phim có phụ đề ' + langName(l) + '.', 'neutral'); } },
      { k: 'khong', l: 'Bận quá, chưa học được', ai: { w: 0.4 }, run: function (l, r, log) { log('Công việc kín lịch, việc học tiếng lại để sau.', 'neutral'); } }
    ]
  });
  T('dc_hoc_tieng', function (l) { return settled(l) && ((l.flags.localLang || {})[countryOf(l)] || 0) < 3; }, 0.18, 3, 3);
  SC('dc_thuong_tru', {
    title: function (l) { return 'Xin ' + (PR[countryOf(l)] || 'thẻ thường trú'); }, valid: function (l) { return settled(l) && !(l.flags.prDone || {})[countryOf(l)]; },
    text: function (l) { return 'Bạn đã sống ở ' + host(l) + ' ' + yrsHere(l) + ' năm. Hồ sơ xin ' + (PR[countryOf(l)] || 'thẻ thường trú') + ' cần chứng minh thu nhập, lý lịch, bảo hiểm và thời gian cư trú.'; },
    opts: [
      { k: 'nop', l: 'Nộp hồ sơ', h: function (l) { return 'Lệ phí, giấy tờ khoảng ' + mo(l, l.base * 0.02); }, ai: { w: 1.2 }, run: function (l, r, log) { H.cash(l, -l.base * 0.02, 'Hồ sơ thường trú'); var P = l.flags.prDone || (l.flags.prDone = {}); if (ch(r, l.job ? 0.75 : 0.45)) { P[countryOf(l)] = l.age; fx(l, { hap: 6 }); log('Nhận thư báo được cấp ' + (PR[countryOf(l)] || 'thẻ thường trú') + '. Từ nay bạn không còn phải gia hạn visa từng năm.', 'big'); H.mem(l, 'Ngày cầm tấm ' + (PR[countryOf(l)] || 'thẻ thường trú') + ' ở ' + host(l) + '.', 4); } else { fx(l, { hap: -3 }); log('Hồ sơ bị yêu cầu bổ sung giấy tờ thu nhập, phải chờ thêm.', 'neutral'); } } },
      { k: 'chua', l: 'Chưa đủ giấy tờ, để sau', ai: { w: 0.4 }, run: function (l, r, log) { log('Bạn gom thêm giấy tờ, hẹn năm sau nộp.', 'neutral'); } }
    ]
  });
  T('dc_thuong_tru', function (l) { return settled(l) && yrsHere(l) >= 3 && !(l.flags.prDone || {})[countryOf(l)]; }, 0.35, 2, 4);
  SC('dc_bang_cap', {
    title: 'Bằng cấp ở xứ người', valid: function (l) { return settled(l) && l.edu >= 4; },
    text: function (l) { return 'Bằng cấp ở ' + homeName(l) + ' chưa được công nhận tương đương ở ' + host(l) + '. Muốn làm đúng ngành phải học chuyển đổi, thi chứng chỉ.'; },
    opts: [
      { k: 'hoc', l: 'Học chuyển đổi, thi chứng chỉ hành nghề', h: function (l) { return 'Khoảng ' + mo(l, l.base * 0.05) + ', mất một hai năm'; }, req: function (l) { return l.money >= l.base * 0.05; }, ai: { w: 1, amb: 1.2 }, run: function (l, r, log) { H.cash(l, -l.base * 0.05, 'Học chuyển đổi bằng cấp'); fx(l, { kno: 3 }); stress(l, 6); l.flags.degreeOK = true; if (l.job) l.job.rep = U.clamp((l.job.rep || 50) + 5, 0, 100); log('Vừa làm vừa học, sau hai năm bạn được công nhận bằng cấp, có thể làm đúng chuyên môn.', 'good'); } },
      { k: 'trai', l: 'Tạm làm việc trái ngành để có thu nhập', ai: { w: 0.8 }, run: function (l, r, log) { fx(l, { hap: -3 }); log('Bạn tạm gác tấm bằng, làm việc chân tay để có thu nhập trước.', 'neutral'); } }
    ]
  });
  T('dc_bang_cap', function (l) { return settled(l) && l.edu >= 4 && yrsHere(l) <= 3 && !l.flags.degreeOK; }, 0.3, 4, 1);
  SC('dc_ky_thi', {
    title: 'Một câu nói khó nghe', valid: settled,
    text: function (l) { return 'Ở ' + U.pick(H.rf(l), ['siêu thị', 'chỗ làm', 'trên xe buýt']) + ', một người buông câu "về nước mày đi" chỉ vì bạn nói giọng nước ngoài.'; },
    opts: [
      { k: 'len_tieng', l: 'Bình tĩnh lên tiếng', ai: { w: 1, karma: 1 }, run: function (l, r, log) { fx(l, { soc: 2, hap: -1 }); log('Bạn bình tĩnh đáp lại. Mấy người xung quanh lên tiếng bênh bạn, người kia lặng lẽ bỏ đi.', 'neutral'); } },
      { k: 'bao_cao', l: 'Báo với quản lý / cơ quan chức năng', ai: { w: 0.8, smart: 1 }, run: function (l, r, log) { fx(l, { hap: -1 }); log('Bạn báo sự việc. Người kia bị nhắc nhở, nơi đó dán thêm biển cấm phân biệt đối xử.', 'neutral'); } },
      { k: 'lo', l: 'Lờ đi, về nhà buồn cả tối', ai: { w: 0.6 }, run: function (l, r, log) { fx(l, { hap: -4 }); stress(l, 4); log('Bạn lờ đi, nhưng câu nói ấy cứ lởn vởn trong đầu cả tối.', 'bad'); } }
    ]
  });
  T('dc_ky_thi', function (l) { return settled(l); }, 0.05, 6, 3);
  SC('dc_tet', {
    title: function (l) { return isVN(l) || l.country === 'VN' ? 'Tết xa nhà' : 'Mùa lễ xa nhà'; }, valid: settled,
    text: function (l) { return (isVN(l) || l.country === 'VN' ? 'Ở ' + host(l) + ' không ai nghỉ Tết. Đêm giao thừa rơi vào ngày đi làm bình thường.' : 'Mùa lễ lớn ở quê nhà, còn ở ' + host(l) + ' vẫn là một ngày đi làm bình thường.') + (parentWord(l) ? ' ' + U.cap(parentWord(l)) + ' gọi điện hỏi năm nay có về không.' : ''); },
    opts: [
      { k: 'cong_dong', l: 'Đón Tết cùng cộng đồng đồng hương', ai: { w: 1.1, soc: 1 }, run: function (l, r, log) { fx(l, { hap: 4, soc: 3 }); log('Hội ' + compat(l) + ' thuê hội trường đón năm mới: gói bánh, múa lân, ai cũng mặc áo truyền thống.', 'good'); } },
      { k: 've', l: 'Mua vé về quê đón Tết', h: function (l) { return 'Vé máy bay khoảng ' + mo(l, l.base * 0.04); }, req: function (l) { return l.money >= l.base * 0.04; }, ai: { w: 0.8 }, run: function (l, r, log) { H.cash(l, -l.base * 0.04, 'Vé máy bay về quê'); fx(l, { hap: 7 }); stress(l, -5); log('Bạn bay về ' + homeName(l) + ' đúng đêm giao thừa. Bước vào nhà nghe mùi bếp quen, mắt cay xè.', 'good'); H.mem(l, 'Cái Tết về nhà sau những năm xa xứ.', 3); } },
      { k: 'video', l: 'Gọi video về nhà', ai: { w: 0.8 }, run: function (l, r, log) { fx(l, { hap: -1 }); log('Gọi video về nhà, màn hình bên kia sum vầy, bên này một mình với bát mì.', 'neutral'); } }
    ]
  });
  T('dc_tet', function (l) { return settled(l); }, 0.2, 2);
  SC('dc_gui_tien', {
    title: 'Gửi tiền về nhà', valid: function (l) { return settled(l) && !!parentWord(l) && l.indep; },
    text: function (l) { return U.cap(parentWord(l)) + ' ở ' + homeName(l) + ' đã có tuổi. Nhiều người đi xa vẫn gửi tiền về hằng tháng.'; },
    opts: [
      { k: 'deu', l: 'Gửi đều đặn mỗi tháng', h: function (l) { return 'Khoảng ' + mo(l, l.base * 0.06) + '/năm'; }, req: function (l) { return l.money >= l.base * 0.06; }, ai: { w: 1, karma: 1 }, run: function (l, r, log) { H.cash(l, -l.base * 0.06, 'Gửi tiền về cho ' + parentWord(l)); fx(l, { hap: 2, karma: 3 }); l.flags.remit = l.age; log('Tháng nào cũng gửi tiền về. ' + U.cap(parentWord(l)) + ' sửa lại mái nhà, khoe với cả xóm.', 'good'); } },
      { k: 'it', l: 'Thỉnh thoảng gửi, dịp lễ Tết', ai: { w: 0.8 }, run: function (l, r, log) { H.cash(l, -l.base * 0.015, 'Gửi tiền về nhà dịp lễ'); log('Dịp lễ Tết bạn gửi về một khoản nhỏ.', 'neutral'); } },
      { k: 'khong', l: 'Chưa đủ dư để gửi', ai: { w: 0.4 }, run: function (l, r, log) { log('Năm nay chi tiêu ở xứ người còn chật vật, chưa gửi được gì về nhà.', 'neutral'); fx(l, { hap: -1 }); } }
    ]
  });
  T('dc_gui_tien', function (l) { return settled(l) && !!parentWord(l) && l.indep; }, 0.15, 4);
  SC('dc_bao_lanh', {
    title: function (l) { return 'Bảo lãnh ' + parentWord(l) + ' sang'; }, valid: function (l) { return settled(l) && !!parentWord(l) && !l.flags.parentsAbroad && l.indep; },
    text: function (l) { return 'Bạn đã ổn định ở ' + host(l) + '. Có thể làm hồ sơ bảo lãnh ' + parentWord(l) + ' sang sống cùng, nhưng phải chứng minh thu nhập và chờ khá lâu. ' + U.cap(parentWord(l)) + ' thì sợ già rồi sang xứ lạ không quen.'; },
    opts: [
      { k: 'bao_lanh', l: 'Làm hồ sơ bảo lãnh', h: function (l) { return 'Phí hồ sơ, vé máy bay khoảng ' + mo(l, l.base * 0.08); }, req: function (l) { return l.money >= l.base * 0.08 && !!l.job; }, ai: { w: 0.8 }, run: function (l, r, log) { H.cash(l, -l.base * 0.08, 'Hồ sơ bảo lãnh ' + parentWord(l)); if (ch(r, 0.6)) { l.flags.parentsAbroad = true; l.flags.caring = true; fx(l, { hap: 8 }); log('Hồ sơ được duyệt. Ngày đón ' + parentWord(l) + ' ở sân bay, bạn ôm thật lâu. Từ nay bữa cơm ở xứ người đã có tiếng nói cười.', 'big'); H.mem(l, 'Ngày đón ' + parentWord(l) + ' sang ' + host(l) + '.', 5); } else { fx(l, { hap: -3 }); log('Hồ sơ bảo lãnh bị từ chối vì chưa đủ điều kiện thu nhập. Bạn hẹn sẽ nộp lại.', 'bad'); } } },
      { k: 've_tham', l: function (l) { return 'Để ' + parentWord(l) + ' ở quê, mỗi năm về thăm'; }, ai: { w: 1 }, run: function (l, r, log) { log('Bạn tôn trọng mong muốn ở lại quê của ' + parentWord(l) + ', hứa năm nào cũng về thăm.', 'neutral'); } }
    ]
  });
  T('dc_bao_lanh', function (l) { return settled(l) && !!parentWord(l) && !l.flags.parentsAbroad && l.indep && yrsHere(l) >= 4 && !!l.job; }, 0.15, 5, 2);
  function kidsHere(l) { return (l.kids || []).filter(function (k) { var x = l.age - k.born; return k.alive !== false && x >= 5 && x <= 15 && k.custody !== 'other'; }); }
  SC('dc_con_tieng_me_de', {
    title: 'Con quên tiếng mẹ đẻ', valid: function (l) { return settled(l) && kidsHere(l).length > 0; },
    text: function (l) { var k = kidsHere(l)[0]; return k.name + ' lớn lên ở ' + host(l) + ', nói ' + langName(l) + ' giỏi hơn tiếng ' + (isVN(l) || l.country === 'VN' ? 'Việt' : 'mẹ đẻ') + ', gọi điện cho ông bà mà nói không trôi.'; },
    opts: [
      { k: 'lop', l: 'Cho con học lớp tiếng mẹ đẻ cuối tuần', h: function (l) { return 'Khoảng ' + mo(l, l.base * 0.01) + '/năm'; }, ai: { w: 1.1 }, run: function (l, r, log) { H.cash(l, -l.base * 0.01, 'Lớp tiếng mẹ đẻ cho con'); kidsHere(l).forEach(function (k) { k.close = U.clamp((k.close || 50) + 3, 0, 100); }); log('Cuối tuần đưa con đến lớp học tiếng ' + (isVN(l) || l.country === 'VN' ? 'Việt' : 'mẹ đẻ') + ' ở chùa / hội đồng hương. Lần sau gọi điện, con chúc ông bà tròn vành rõ chữ.', 'good'); } },
      { k: 'o_nha', l: 'Quy định ở nhà chỉ nói tiếng mẹ đẻ', ai: { w: 0.9 }, run: function (l, r, log) { kidsHere(l).forEach(function (k) { k.close = U.clamp((k.close || 50) + 1, 0, 100); }); log('Cả nhà quy định: bước vào cửa là nói tiếng mẹ đẻ. Con phụng phịu nhưng dần quen.', 'neutral'); } },
      { k: 'tu_nhien', l: 'Để tự nhiên, con sống ở đây thì nói tiếng ở đây', ai: { w: 0.5 }, run: function (l, r, log) { log('Bạn để con tự nhiên. Về sau con hiểu tiếng mẹ đẻ nhưng ngại nói.', 'neutral'); } }
    ]
  });
  T('dc_con_tieng_me_de', function (l) { return settled(l) && kidsHere(l).length > 0; }, 0.15, 6, 1);
  SC('dc_hoi', {
    title: 'Cộng đồng đồng hương', valid: settled,
    text: function (l) { return 'Ở ' + host(l) + ' có hội ' + compat(l) + ': ngày lễ tụ họp, có lớp tiếng mẹ đẻ cho trẻ con, có người giúp người mới sang tìm việc, tìm nhà.'; },
    opts: [
      { k: 'tham_gia', l: 'Tham gia sinh hoạt cuối tuần', ai: { w: 1.1 }, run: function (l, r, log) { fx(l, { soc: 4, hap: 3 }); stress(l, -3); log(U.pick(r, ['Cuối tuần sinh hoạt cùng hội ' + compat(l) + ', nấu nồi phở to cho cả hội.', 'Đi chợ châu Á cùng mấy người đồng hương, mua được cả rau thơm quê nhà.', 'Hội tổ chức đêm văn nghệ, bạn lên hát một bài quê hương mà cả hội rưng rưng.']), 'good'); } },
      { k: 'giup', l: 'Giúp người mới sang tìm việc, tìm nhà', ai: { w: 0.8, karma: 1 }, run: function (l, r, log) { fx(l, { karma: 4, soc: 3 }); log('Bạn chỉ đường cho một gia đình mới sang: thuê nhà, làm giấy tờ, xin việc. Như ngày xưa có người đã giúp bạn.', 'good'); } },
      { k: 'thoi', l: 'Để dịp khác', ai: { w: 0.3 }, run: function () { } }
    ]
  });
  A('dc_cong_dong', 'Gia đình & bạn bè', 'Sinh hoạt cùng cộng đồng đồng hương', { min: 16, sc: 'dc_hoi', avail: function (l) { return settled(l) ? true : 'Không áp dụng'; }, ai: { w: 0.05 } });
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
/* ===== js/life75.js ===== */
/* Một Đời — v5.9.2:
   · xưng hô đúng giới tính / quan hệ trong các câu thoại còn viết cứng ("Chị ơi…", "Anh biết tôi là ai không?"…)
   · E.callYou(l, p): người p gọi bạn là gì (anh / chị / em) — dùng chung cho các lời thoại của người yêu, bạn đời */
(function (G) {
  'use strict';
  var U = G.U, E = G.E;
  // người yêu / bạn đời gọi bạn: khác giới thì nam là "anh", nữ là "em"; cùng giới thì theo tuổi
  E.callYou = function (l, p) {
    if (!p) return l.sex === 'F' ? 'chị' : 'anh';
    if (p.sex !== l.sex) return l.sex === 'M' ? 'anh' : 'em';
    return (p.age || l.age) <= l.age ? (l.sex === 'M' ? 'anh' : 'chị') : 'em';
  };
  // câu thoại người khác nói với bạn: đổi "anh" ↔ "chị" theo giới tính của bạn
  var FIX = [
    ['"Chị ơi, em chưa bao giờ thấy mình đẹp như thế', '"Anh ơi, em chưa bao giờ thấy mình đẹp như thế', 'M'],
    ['"Chị lo cho cả nhà này như người nhà. Không có chị,', '"Anh lo cho cả nhà này như người nhà. Không có anh,', 'M'],
    ['"Anh biết tôi là ai không?"', '"Chị biết tôi là ai không?"', 'F']
  ];
  var fl = E.famLogic;
  E.famLogic = function (l, t, isLog) {
    if (typeof t === 'string' && l) for (var i = 0; i < FIX.length; i++) if (l.sex === FIX[i][2] && t.indexOf(FIX[i][0]) >= 0) t = t.split(FIX[i][0]).join(FIX[i][1]);
    if (typeof t === 'string' && l && isLog && E.hasFamily && !E.hasFamily(l)) t = t.replace('chiều về quây quần ăn bữa xả chay', 'chiều đến thánh đường cùng bà con ăn bữa xả chay'); // không còn ai trong gia đình
    return fl ? fl.call(this, l, t, isLog) : t;
  };
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
/* ===== js/life76.js ===== */
/* Một Đời — v6.0.0:
   · sinh viên lên thành phố học: chọn chỗ ở theo điều kiện gia đình (ký túc xá, trọ ghép, trọ riêng, thuê chung cư, bố mẹ mua căn hộ, gia đình tài phiệt mua nhà phố / biệt thự); nhà ở sẵn thành phố đó thì không cần
   · làm thêm khi đi học (phục vụ, gia sư, giao hàng, bán hàng online, lễ tân ca đêm…)
   · những "cơ hội" dễ gặp khi mới lên thành phố — có cái thật, có cái là bẫy, game không nói trước
   · chuyện nghề chi tiết: khách đặt kiểu tóc mullet / side part / undercut, nail mắt mèo, latte art, cocktail, fix bug, ca cấp cứu… xưng hô đúng giới tính */
(function (G) {
  'use strict';
  var U = G.U, E = G.E, H = E.H, SC = E.SC, isVN = H.isVN;
  function fx(l, o) { H.fx(l, o); }
  function stress(l, d) { if (l.mind) l.mind.stress = U.clamp(l.mind.stress + d, 0, 100); }
  function ch(r, p) { return r() < p; }
  function vnd(l) { return isVN(l) && l.cur === 'vnd' && !(l.abroad && l.abroad.perm); }
  function V(l, tr) { return vnd(l) ? tr : tr / 90 * l.base; }
  function mo(l, v) { return H.money(l, v); }
  function free(l) { return l.alive && !(l.jailUntil != null && l.age < l.jailUntil) && !(l.abroad && l.abroad.trapped) && !(l.flags.military && l.age < l.flags.military); }
  function A(id, g, label, o) { var x = { id: id, g: g, l: label }; for (var k in o) x[k] = o[k]; E.ACT.push(x); }
  function T(id, when, p, cd, max, rep) { E.TRIG.push({ id: id, when: function (l, a) { return free(l) && when(l, a); }, p: p, cd: cd || 3, max: max || 4, rep: !!rep }); }
  function you(l) { return l.sex === 'F' ? 'chị' : 'anh'; }
  function pw(l) { var f = l.fam || {}, m = !f.noMom && f.mAlive, b = !f.noDad && f.fAlive; return m && b ? 'bố mẹ' : m ? 'mẹ' : b ? 'bố' : ''; }
  function student(l) { return !!l.school && /^(uni|voc|post|phd)$/.test(l.school); }
  function away(l) { return !!(l.cityStudent && student(l)); }

  // ===================================================================
  // 1. CHỖ Ở KHI LÊN THÀNH PHỐ HỌC
  // ===================================================================
  var HOME = [
    { k: 'ktx', l: 'Ở ký túc xá của trường', r: 0.4, q: 0, t: 'Phòng ký túc xá 8 người, giường tầng, giờ giấc nghiêm, bù lại rẻ và gần giảng đường.' },
    { k: 'ghep', l: 'Thuê trọ ghép với bạn', r: 1.6, q: 0, t: 'Căn phòng trọ 15 m² chia ba người, nóng hầm hập mùa hè, chủ trọ thu tiền điện 4 nghìn một số.' },
    { k: 'rieng', l: 'Thuê phòng trọ riêng khép kín', r: 3.5, q: 2, t: 'Phòng trọ riêng khép kín, có gác lửng, yên tĩnh để học.' },
    { k: 'studio', l: 'Thuê căn hộ dịch vụ / studio', r: 6, q: 3, t: 'Căn hộ dịch vụ đủ nội thất, có máy giặt, thang máy, bảo vệ.' },
    { k: 'thue_cc', l: 'Thuê căn hộ chung cư', r: 12, q: 4, t: 'Căn hộ chung cư hai phòng ngủ gần trường, có hồ bơi và phòng gym.' },
    { k: 'mua_cc', l: function (l) { return U.cap(pw(l) || 'gia đình') + ' mua hẳn một căn chung cư'; }, buy: 4000, q: 5, t: 'Căn hộ chung cư mua hẳn gần trường, sau này ra trường vẫn ở được.' },
    { k: 'biet_thu', l: 'Gia đình mua nhà phố / biệt thự ở thành phố', buy: 20000, elite: true, t: 'Một căn nhà phố mặt tiền, có người giúp việc, tài xế đưa đón.' }
  ];
  function rich(l) { var f = l.fam || {}; return f.elite && l.flags.eliteFollow && !l.flags.eliteCut; }
  function famPays(l, h) { var f = l.fam || {}; return rich(l) || (f.q || 0) >= 4 || !!h.buy; }
  function homeOk(l, h) { var f = l.fam || {}; if (h.elite) return rich(l); if (h.buy) return rich(l) || (f.q || 0) >= 5 && !!pw(l); return (f.q || 0) >= h.q || rich(l); }
  SC('sv_cho_o', {
    title: function (l) { return 'Ở đâu khi lên ' + (l.cityStudent ? l.cityStudent.city : 'thành phố') + ' học?'; },
    valid: function (l) { return away(l) && !l.flags.stuHome; },
    text: function (l) { var f = l.fam || {}; return 'Lên ' + l.cityStudent.city + ' nhập học, việc đầu tiên là tìm chỗ ở. ' + (rich(l) ? 'Gia đình muốn bạn ở thật thoải mái, không phải lo gì.' : (f.q || 0) >= 4 ? U.cap(pw(l) || 'gia đình') + ' sẵn sàng trả tiền nhà cho bạn.' : 'Nhà không dư dả, tiền trọ bạn phải tự cân đối từ tiền ' + (pw(l) || 'gia đình') + ' gửi và tiền làm thêm.'); },
    opts: HOME.map(function (h) {
      return { k: h.k, l: h.l, h: function (l) { return h.buy ? 'Khoảng ' + mo(l, V(l, h.buy)) + ' · gia đình chi' : 'Khoảng ' + mo(l, V(l, h.r)) + '/tháng' + (famPays(l, h) ? ' · gia đình trả' : ''); }, req: function (l) { return homeOk(l, h); }, ai: { w: h.k === 'ktx' || h.k === 'ghep' ? 1.2 : 0.8 },
        run: function (l, r, log) { l.flags.stuHome = { k: h.k, since: l.age, city: l.cityStudent.city, rent: h.r || 0, fam: famPays(l, h), buy: h.buy ? V(l, h.buy) : 0 }; log(h.t + (h.buy ? ' ' + U.cap(pw(l) || 'gia đình') + ' đứng ra mua, bạn chỉ việc dọn vào.' : famPays(l, h) ? ' Tiền nhà do ' + (pw(l) || 'gia đình') + ' trả.' : ''), h.k === 'ktx' || h.k === 'ghep' ? 'neutral' : 'good'); H.mem(l, 'Chỗ ở đầu tiên khi lên ' + l.cityStudent.city + ' học.', 2); } };
    })
  });
  T('sv_cho_o', function (l) { return away(l) && !l.flags.stuHome; }, 1, 1, 1);
  E.HOOKS.year.unshift(function (l, r, log, a) {
    var h = l.flags.stuHome; if (!h || h.done) return;
    if (!away(l)) { // ra trường / thôi học
      h.done = true;
      if (h.buy && !l.ownHouse) { l.ownHouse = true; l.houseVal = h.buy; log('Ra trường, căn nhà ' + (pw(l) || 'gia đình') + ' mua hồi đi học được sang tên cho bạn.', 'good'); }
      else if (!h.buy) log('Ra trường, bạn trả lại ' + ({ ktx: 'giường ký túc xá', ghep: 'căn phòng trọ ghép', rieng: 'phòng trọ', studio: 'căn hộ dịch vụ', thue_cc: 'căn hộ thuê' }[h.k] || 'chỗ trọ') + ' đã gắn bó suốt mấy năm.', 'neutral');
      if (l.flags.ptJob) { log('Nghỉ việc làm thêm ' + l.flags.ptJob.n + ' để bắt đầu công việc sau khi ra trường.', 'neutral'); l.flags.ptJob = null; }
      return;
    }
    if (h.buy || h.fam || h.paidAt === a) return; h.paidAt = a;
    var y = V(l, h.rent) * 12; H.cash(l, -y, 'Tiền trọ ' + h.city);
    if (l.money < 0 && !l.flags.ptJob && E.DEC.sv_lam_them) { log('Tiền trọ, tiền ăn ở ' + h.city + ' vượt quá tiền nhà gửi lên. Bạn phải tính chuyện đi làm thêm.', 'bad'); l.pending.push(E.DEC.sv_lam_them.make(l, r)); }
  });

  // ===================================================================
  // 2. LÀM THÊM KHI ĐI HỌC
  // ===================================================================
  var PT = [
    { k: 'cafe', n: 'phục vụ quán cà phê', m: 3, kno: -1, st: 3, t: 'Ca tối ở quán cà phê, bưng bê đến 11 giờ đêm mới về.' },
    { k: 'gia_su', n: 'gia sư', m: 4, kno: 1, st: 2, t: 'Dạy kèm một học sinh lớp 9 ba buổi một tuần.', req: function (l) { return l.st.kno >= 60; } },
    { k: 'ship', n: 'giao đồ ăn', m: 5, kno: -2, st: 6, hea: -2, t: 'Chạy giao đồ ăn giờ cao điểm, mưa nắng gì cũng phải đi.', req: function (l) { return !!l.veh; } },
    { k: 'online', n: 'bán hàng online', m: 2.5, kno: 0, st: 3, t: 'Nhập quần áo, phụ kiện về bán online cho bạn bè, livestream buổi tối.' },
    { k: 'le_tan', n: 'lễ tân ca đêm khách sạn', m: 4.5, kno: -1, st: 5, hea: -2, t: 'Trực lễ tân ca đêm, tranh thủ ôn bài lúc vắng khách.' },
    { k: 'sk', n: 'nhân viên sự kiện / PG, PB', m: 3, kno: -1, st: 3, t: 'Làm nhân viên sự kiện cuối tuần, đứng cả ngày phát tờ rơi, giới thiệu sản phẩm.' }
  ];
  SC('sv_lam_them', {
    title: 'Đi làm thêm', valid: function (l) { return student(l) && !l.flags.ptJob && l.age >= 17; },
    text: function (l) { return 'Bạn tính đi làm thêm ngoài giờ học' + (away(l) ? ' để đỡ tiền trọ, tiền ăn ở ' + l.cityStudent.city : '') + '. Làm nhiều thì có tiền nhưng ít thời gian học.'; },
    opts: PT.map(function (p) { return { k: p.k, l: U.cap(p.n), h: function (l) { return '~' + mo(l, V(l, p.m)) + '/tháng'; }, req: function (l) { return !p.req || p.req(l); }, ai: { w: 1 }, run: function (l, r, log) { l.flags.ptJob = { k: p.k, n: p.n, since: l.age }; log('Bắt đầu đi làm thêm: ' + p.n + '. ' + p.t, 'neutral'); } }; })
      .concat([{ k: 'khong', l: 'Không, tập trung học', ai: { w: 0.6 }, run: function (l, r, log) { log('Bạn quyết định dành hết thời gian cho việc học.', 'neutral'); } }])
  });
  T('sv_lam_them', function (l, a) { return student(l) && !l.flags.ptJob && a >= 18; }, 0.25, 2, 2);
  A('sv_lam_them', 'Công việc', 'Đi làm thêm (part-time) khi đi học', { min: 17, sc: 'sv_lam_them', avail: function (l) { return !student(l) ? 'Không áp dụng' : l.flags.ptJob ? 'Đang làm thêm: ' + l.flags.ptJob.n : true; }, ai: { w: 0.1 } });
  E.HOOKS.year.unshift(function (l, r, log, a) {
    var j = l.flags.ptJob; if (!j || !l.alive) return;
    if (!student(l)) { if (!l.flags.stuHome || l.flags.stuHome.done) { l.flags.ptJob = null; } return; }
    if (j.paidAt === a || !free(l)) return; j.paidAt = a;
    var p = PT.filter(function (x) { return x.k === j.k; })[0]; if (!p) return;
    H.cash(l, V(l, p.m) * 10, 'Làm thêm: ' + p.n); fx(l, { kno: p.kno, hea: p.hea || 0 }); stress(l, p.st);
    if (a - j.since === 1) log(U.pick(r, ['Một năm vừa học vừa làm ' + p.n + ', bạn quen dần với nhịp sống chạy hai đầu.', 'Tiền làm ' + p.n + ' đủ trả tiền trọ, còn dư chút gửi về cho ' + (pw(l) || 'gia đình') + '.', 'Có hôm làm ' + p.n + ' về muộn, sáng hôm sau ngủ gật trên giảng đường.']), 'neutral');
  });

  // ===================================================================
  // 3. NHỮNG "CƠ HỘI" Ở THÀNH PHỐ (có cái là bẫy)
  // ===================================================================
  function trapEv(id, title, text, opts, when) { SC(id, { title: title, valid: function (l) { return student(l) && l.age >= 17; }, text: text, opts: opts }); T(id, function (l) { return student(l) && l.age >= 17 && (!when || when(l)); }, 0.06, 4, 1); }
  trapEv('sv_viec_nhe', 'Việc làm tại nhà', 'Một tài khoản lạ nhắn tin tuyển cộng tác viên online: chỉ cần "làm nhiệm vụ" đặt đơn hàng trên một trang thương mại, nhận hoa hồng 10% mỗi đơn, làm lúc nào cũng được.', [
    { k: 'thu', l: 'Thử làm vài đơn xem sao', ai: { w: 0.5, risk: 1 }, run: function (l, r, log) { H.cash(l, V(l, 0.05), 'Hoa hồng đơn đầu'); var lost = V(l, ch(r, 0.5) ? 8 : 3); H.cash(l, -lost, 'Nạp tiền "làm nhiệm vụ"'); fx(l, { hap: -8 }); stress(l, 8); log('Hai đơn đầu được trả hoa hồng thật. Đến đơn thứ ba, hệ thống báo phải nạp thêm tiền mới "rút được". Nạp xong thì tài khoản kia biến mất, mất trắng ' + mo(l, lost) + '.', 'bad'); H.mem(l, 'Bài học đắt giá năm nhất đại học.', 3); } },
    { k: 'hoi', l: 'Hỏi anh chị khóa trên trước', ai: { w: 1, smart: 1.3 }, run: function (l, r, log) { fx(l, { kno: 1 }); log('Anh khóa trên nghe xong lắc đầu: "Đừng làm, mấy đứa bạn anh nạp cả chục triệu rồi đấy." Bạn chặn tài khoản kia.', 'good'); } },
    { k: 'bo', l: 'Bỏ qua, không trả lời', ai: { w: 0.9 }, run: function (l, r, log) { log('Bạn không trả lời tin nhắn lạ.', 'neutral'); } }
  ]);
  trapEv('sv_hoi_thao', 'Buổi chia sẻ khởi nghiệp', 'Một chị khóa trên rất thân thiện mời bạn đến buổi chia sẻ "tự do tài chính tuổi 20" ở một văn phòng sang trọng, có cả "diễn giả" đi xe sang.', [
    { k: 'dong', l: 'Đăng ký khóa "học viên" để được hướng dẫn', h: function (l) { return 'Khoảng ' + mo(l, V(l, 15)); }, ai: { w: 0.4, risk: 1 }, run: function (l, r, log) { H.cash(l, -V(l, 15), 'Phí "học viên" hội thảo'); fx(l, { hap: -6, soc: -3 }); log('Đóng tiền xong, bạn được giao chỉ tiêu: rủ thêm bạn bè đăng ký và mua sản phẩm thì mới "lên cấp". Cả lớp bắt đầu né bạn. Mấy tháng sau bạn bỏ, tiền không lấy lại được.', 'bad'); } },
    { k: 'nghe', l: 'Đến nghe thử rồi về', ai: { w: 1 }, run: function (l, r, log) { stress(l, 2); log('Buổi chia sẻ toàn chuyện xe sang, nghỉ dưỡng. Cuối buổi ai cũng bị mời ký hợp đồng ngay. Bạn viện cớ có việc rồi về.', 'neutral'); } },
    { k: 'tu_choi', l: 'Từ chối khéo', ai: { w: 0.8 }, run: function (l, r, log) { log('Bạn từ chối khéo vì lịch học kín.', 'neutral'); } }
  ]);
  trapEv('sv_vay', 'Vay tiền sinh viên', 'Đang thiếu tiền đóng học phí, bạn thấy quảng cáo ứng dụng "hỗ trợ tài chính sinh viên": chỉ cần căn cước và thẻ sinh viên, giải ngân trong 5 phút.', [
    { k: 'vay', l: 'Vay 5 triệu cho kịp đóng học phí', ai: { w: 0.4 }, run: function (l, r, log) { if (H.addLoan) { var n0 = (l.loans || []).length; H.addLoan(l, 'appden', V(l, 5)); var L = (l.loans || [])[n0]; if (L) L.bal *= 1.8; } else H.cash(l, V(l, 5), 'Vay qua ứng dụng'); fx(l, { hap: -5 }); stress(l, 10); log('Tiền về ngay, nhưng phí "dịch vụ", "bảo hiểm" bị trừ trước, lãi tính theo ngày. Chỉ vài tháng, khoản nợ đã gần gấp đôi. Điện thoại bắt đầu nhận những cuộc gọi đòi nợ.', 'bad'); } },
    { k: 'xin', l: 'Hỏi phòng công tác sinh viên về học bổng, hoãn đóng học phí', ai: { w: 1, smart: 1.3 }, run: function (l, r, log) { fx(l, { kno: 1 }); log('Phòng công tác sinh viên cho bạn làm đơn xin đóng học phí chậm và giới thiệu một suất học bổng khó khăn.', 'good'); } },
    { k: 'nha', l: 'Gọi điện nói thật với gia đình', ai: { w: 0.9 }, run: function (l, r, log) { log((pw(l) ? U.cap(pw(l)) : 'Người nhà') + ' thu xếp gửi tiền lên, dặn: "Thiếu thì nói, đừng vay ngoài."', 'neutral'); } }
  ], function (l) { return !l.fam || (l.fam.q || 0) <= 3; });
  trapEv('sv_tro_coc', 'Phòng trọ giá rẻ', 'Trên nhóm tìm trọ có bài đăng căn phòng đẹp, rộng, giá chỉ bằng nửa chỗ khác. Chủ nhà nói đang ở xa, chỉ cần chuyển trước tiền cọc để giữ phòng.', [
    { k: 'coc', l: 'Chuyển cọc ngay kẻo mất phòng', ai: { w: 0.4 }, run: function (l, r, log) { H.cash(l, -V(l, 3), 'Tiền cọc phòng trọ'); fx(l, { hap: -6 }); log('Chuyển cọc xong, số điện thoại kia thuê bao. Đến địa chỉ thì căn phòng đã có người ở từ lâu.', 'bad'); } },
    { k: 'xem', l: 'Hẹn đến xem tận nơi rồi mới cọc', ai: { w: 1.1, smart: 1.2 }, run: function (l, r, log) { log('Người kia cứ lấy cớ bận không cho xem phòng. Bạn thôi, tìm chỗ khác qua người quen.', 'neutral'); } }
  ], function (l) { return away(l); });
  trapEv('sv_keo', 'Kèo bóng đá', 'Bạn cùng phòng rủ góp tiền "vào kèo" trận bóng tối nay qua một trang web: "Kèo thơm, chắc thắng, mai khao cả phòng."', [
    { k: 'gop', l: 'Góp vài trăm cho vui', ai: { w: 0.5, risk: 1 }, run: function (l, r, log) { if (ch(r, 0.4)) { H.cash(l, V(l, 0.5), 'Thắng kèo'); log('Thắng thật, cả phòng đi ăn lẩu. Tuần sau bạn cùng phòng lại rủ, lần này đặt nhiều hơn…', 'neutral'); l.flags.svBet = (l.flags.svBet || 0) + 1; } else { H.cash(l, -V(l, 0.5), 'Thua kèo'); log('Thua. Bạn cùng phòng bảo "gỡ lại tuần sau là được".', 'bad'); } } },
    { k: 'khong', l: 'Không chơi, chỉ xem bóng', ai: { w: 1 }, run: function (l, r, log) { log('Bạn chỉ ngồi xem bóng cùng cả phòng.', 'neutral'); } }
  ]);
  trapEv('sv_mau_anh', 'Lời mời làm mẫu ảnh', 'Một "agency" nhắn tin khen bạn ăn ảnh, mời làm mẫu cho các nhãn hàng, cát-xê cao. Chỉ cần đóng phí chụp bộ ảnh hồ sơ ban đầu.', [
    { k: 'dong', l: 'Đóng phí chụp ảnh hồ sơ', ai: { w: 0.4 }, run: function (l, r, log) { H.cash(l, -V(l, 4), 'Phí chụp ảnh hồ sơ'); fx(l, { hap: -5 }); log('Chụp xong bộ ảnh, "agency" hẹn có job thì gọi. Mấy tháng chẳng thấy ai gọi, trang của họ đã đổi tên.', 'bad'); } },
    { k: 'kiem_tra', l: 'Hỏi tên công ty, hợp đồng rõ ràng trước', ai: { w: 1, smart: 1.2 }, run: function (l, r, log) { log('Bạn hỏi tên công ty và hợp đồng. Bên kia trả lời vòng vo rồi im lặng luôn.', 'neutral'); } },
    { k: 'bo', l: 'Không quan tâm', ai: { w: 0.7 }, run: function (l, r, log) { log('Bạn không trả lời.', 'neutral'); } }
  ]);
  trapEv('sv_tiec', 'Buổi tiệc của nhóm bạn mới', 'Nhóm bạn mới quen rủ đi bar mừng sinh nhật. Giữa buổi, một người chìa ra viên "kẹo" bảo uống vào cho vui, ai cũng thử rồi.', [
    { k: 'thu', l: 'Thử một viên cho khỏi bị nói là "quê"', ai: { w: 0.2, risk: 1.5 }, run: function (l, r, log) { fx(l, { hea: -8, hap: -4 }); stress(l, 8); if (ch(r, 0.25)) log('Đêm đó quán bị kiểm tra. Bạn bị đưa về phường lập biên bản, ' + (pw(l) || 'gia đình') + ' phải lên tận nơi bảo lãnh.', 'bad'); else log('Sáng hôm sau tỉnh dậy đầu đau như búa bổ, không nhớ nổi đêm qua đã làm gì.', 'bad'); } },
    { k: 'tu_choi', l: 'Từ chối, uống nước ngọt rồi về sớm', ai: { w: 1.2 }, run: function (l, r, log) { log('Bạn từ chối, ngồi một lúc rồi xin về sớm. Về sau bạn cũng ít đi với nhóm ấy.', 'neutral'); } }
  ], function (l) { return away(l); });

  // ===================================================================
  // 4. CHUYỆN NGHỀ CHI TIẾT
  // ===================================================================
  // mỗi nghề: cách khách / người liên quan gọi bạn, danh sách tình huống [đề bài, [kỹ thuật, độ khó 0–1], …]
  function U2(l) { return you(l); }
  var JOBS = {
    hair: { ids: ['barber', 'tho_toc'], call: U2, cases: [
      ['Một khách nam đưa ảnh trên mạng, muốn đổi kiểu tóc trước buổi phỏng vấn xin việc.', [['Side part rẽ ngôi lịch lãm', 0.3], ['Undercut gọn gàng', 0.4], ['Two-block kiểu Hàn', 0.5], ['Textured crop', 0.5]]],
      ['Cậu học sinh cấp ba muốn kiểu tóc đang hot trên TikTok để đi chơi cuối tuần.', [['Mullet', 0.6], ['Burst fade', 0.7], ['Uốn con sâu', 0.6], ['Buzz cut', 0.2]]],
      ['Một chị khách muốn làm mới mái tóc dài đã lâu không cắt.', [['Tóc layer tỉa nhẹ', 0.4], ['Bob ngang vai', 0.5], ['Uốn sóng nước', 0.6], ['Nhuộm nâu tây', 0.5], ['Mái thưa Hàn Quốc', 0.3]], 'not:barber'],
      ['Khách quen muốn tẩy tóc lên màu nổi để đi concert.', [['Nhuộm bạch kim', 0.8], ['Nhuộm xanh khói', 0.7], ['Highlight vài lọn', 0.5]]]
    ] },
    nail: { ids: ['nail'], call: U2, cases: [
      ['Cô dâu đặt bộ móng cho ngày cưới, dặn phải thật tinh tế.', [['French tip viền trắng', 0.4], ['Vẽ hoa nổi 3D', 0.7], ['Đính đá ngọc trai', 0.6]]],
      ['Hai cô bạn rủ nhau làm nail đi biển.', [['Nail mắt mèo', 0.5], ['Nail ombre chuyển màu', 0.5], ['Nail thạch trong suốt', 0.4], ['Vẽ hình trái cây', 0.6]]]
    ] },
    makeup: { ids: ['makeup', 'spa', 'stylist'], call: U2, cases: [
      ['Một cô dâu nhờ trang điểm cho lễ ăn hỏi sáng sớm.', [['Trang điểm cô dâu truyền thống', 0.5], ['Trong veo kiểu Hàn', 0.4], ['Sắc sảo kiểu Tây', 0.6]]],
      ['Nhóm học sinh lớp 12 thuê trang điểm chụp kỷ yếu.', [['Trang điểm kỷ yếu nhẹ nhàng', 0.3], ['Phong cách Douyin', 0.6], ['Trang điểm áo dài', 0.4]]]
    ] },
    cook: { ids: ['dau_bep', 'chu_quan_an', 'chu_nha_hang'], call: U2, cases: [
      ['Một đoàn khách nước ngoài đặt bàn, muốn thử món Việt "chuẩn vị".', [['Phở bò tái lăn', 0.5], ['Bún chả Hà Nội', 0.4], ['Cơm tấm sườn bì chả', 0.4], ['Bánh xèo miền Tây', 0.5]]],
      ['Khách đặt tiệc sinh nhật, muốn thực đơn kiểu Âu.', [['Bò Wellington', 0.8], ['Mì Ý sốt kem carbonara', 0.4], ['Cá hồi áp chảo sốt chanh leo', 0.5]]],
      ['Một khách khó tính trả lại món, chê nhạt.', [['Nêm lại và tự mang ra xin lỗi', 0.3], ['Làm lại món mới hoàn toàn', 0.4], ['Giải thích công thức truyền thống', 0.5]]]
    ] },
    barista: { ids: ['barista'], call: U2, cases: [
      ['Một vị khách muốn có ly cà phê đẹp để chụp ảnh.', [['Latte art trái tim', 0.3], ['Latte art thiên nga', 0.7], ['Cà phê muối', 0.3], ['Pour over V60', 0.6]]],
      ['Quán đông nghẹt giờ cao điểm, cả chục order cùng lúc.', [['Làm theo thứ tự, giữ chất lượng', 0.4], ['Pha sẵn cold brew cho nhanh', 0.3], ['Nhờ đồng nghiệp chia quầy', 0.2]]]
    ] },
    bar: { ids: ['bartender'], call: U2, cases: [
      ['Khách quen muốn thử một ly cocktail "đặc biệt".', [['Mojito', 0.3], ['Old Fashioned', 0.5], ['Margarita', 0.4], ['Cocktail sáng tạo riêng', 0.7]]],
      ['Quán tổ chức đêm biểu diễn, chủ quán muốn bạn trổ tài.', [['Flair bartending tung chai', 0.8], ['Pha cocktail lửa', 0.6], ['Tháp ly champagne', 0.5]]]
    ] },
    sew: { ids: ['tho_may', 'tk_thoi_trang'], call: U2, cases: [
      ['Một cô gái đặt may áo dài cưới trong hai tuần.', [['Áo dài gấm thêu tay', 0.8], ['Áo dài lụa trơn', 0.4], ['Áo dài cách tân', 0.6]]],
      ['Một anh khách cần bộ vest may đo cho buổi ra mắt nhà vợ.', [['Vest may đo hai khuy', 0.5], ['Vest ba mảnh có gi-lê', 0.7], ['Sửa vest có sẵn cho vừa', 0.3]]]
    ] },
    moto: { ids: ['tho_sua_xe'], call: U2, cases: [
      ['Một chiếc tay ga đề không nổ, khách cần đi làm gấp.', [['Kiểm tra bugi, ắc quy', 0.3], ['Vệ sinh kim phun xăng điện tử', 0.6], ['Làm lại nồi xe', 0.6]]],
      ['Cậu thanh niên muốn độ lại chiếc xe số.', [['Độ đèn bi cầu', 0.5], ['Thay pô cho đúng luật', 0.3], ['Sơn lại dàn áo', 0.4]]]
    ] },
    dev: { ids: ['dev', 'fl_dev', 'data', 'ky_su'], call: U2, cases: [
      ['Hai giờ chiều, hệ thống báo lỗi, khách hàng không thanh toán được.', [['Rollback bản cập nhật', 0.3], ['Đọc log, tìm đúng chỗ lỗi', 0.6], ['Hotfix thẳng lên production', 0.8]]],
      ['Sếp giao dự án mới, hạn chót một tháng.', [['Làm API cho ứng dụng di động', 0.5], ['Tối ưu cơ sở dữ liệu', 0.6], ['Chuyển hệ thống lên cloud', 0.7], ['Viết test tự động', 0.4]]]
    ] },
    design: { ids: ['thiet_ke', 'fl_thiet_ke', 'kien_truc', 'hoa_si'], call: U2, cases: [
      ['Một tiệm bánh mới mở nhờ làm nhận diện thương hiệu.', [['Thiết kế logo', 0.4], ['Bộ nhận diện thương hiệu đầy đủ', 0.7], ['Poster khai trương', 0.3]]],
      ['Khách hàng sửa đến bản thứ bảy vẫn chưa ưng.', [['Hỏi kỹ lại mong muốn, làm lại từ đầu', 0.5], ['Đưa ba phương án khác nhau', 0.4], ['Giữ quan điểm, giải thích lý do thiết kế', 0.6]]]
    ] },
    photo: { ids: ['nhiep_anh'], call: U2, cases: [
      ['Một cặp đôi đặt chụp ảnh cưới.', [['Chụp ngoại cảnh Đà Lạt', 0.5], ['Chụp concept áo dài phố cổ', 0.5], ['Chụp studio ánh sáng điện ảnh', 0.7]]],
      ['Một nhãn hàng thuê chụp ảnh sản phẩm.', [['Chụp sản phẩm nền trắng', 0.3], ['Chụp lookbook ngoài trời', 0.5], ['Quay video quảng cáo ngắn', 0.7]]]
    ] },
    tattoo: { ids: ['tho_xam'], call: U2, cases: [
      ['Một cô gái muốn xăm hình nhỏ đầu tiên trong đời.', [['Xăm mini line nhành hoa', 0.4], ['Xăm chữ viết tay', 0.5], ['Xăm hình xăm phủ sẹo', 0.7]]],
      ['Khách quen đặt hình xăm lớn kín lưng.', [['Xăm full lưng hình rồng', 0.8], ['Xăm phong cách realistic', 0.8], ['Chia làm nhiều buổi', 0.4]]]
    ] },
    teach: { ids: ['giao_vien', 'gia_su', 'giang_vien', 'gv_mam_non'], call: function (l) { return l.sex === 'F' ? 'cô' : 'thầy'; }, cases: [
      ['Lớp có một học sinh học rất chậm, sắp thi chuyển cấp.', [['Kèm riêng sau giờ học', 0.4], ['Chia nhỏ bài, giao bài vừa sức', 0.5], ['Gặp phụ huynh bàn cách học', 0.3]]],
      ['Bạn được chọn dạy tiết thao giảng cấp quận.', [['Dạy theo dự án nhóm', 0.6], ['Dùng trò chơi khởi động', 0.4], ['Dạy truyền thống, chắc chắn', 0.3]]]
    ] },
    med: { ids: ['bac_si', 'dieu_duong', 'phong_kham', 'nha_si', 'duoc_si'], call: function (l) { return 'bác sĩ'; }, cases: [
      ['Ca trực đêm, một bệnh nhân đau bụng dữ dội được đưa vào.', [['Khám kỹ, siêu âm ngay', 0.4], ['Hội chẩn với đàn anh', 0.3], ['Chuyển mổ cấp cứu', 0.7]]],
      ['Một em bé sốt cao co giật, mẹ bé hoảng loạn.', [['Hạ sốt, xử trí co giật', 0.5], ['Trấn an gia đình trước', 0.3], ['Chuyển viện nhi tuyến trên', 0.4]]]
    ] },
    gym: { ids: ['pt_gym', 'hlv_tt'], call: U2, cases: [
      ['Một khách muốn giảm 10 cân trước đám cưới ba tháng nữa.', [['Giáo án giảm mỡ kết hợp ăn uống', 0.5], ['Tập HIIT cường độ cao', 0.6], ['Tập nhẹ, bền vững', 0.3]]],
      ['Một khách vừa phẫu thuật đầu gối muốn tập lại.', [['Bài phục hồi chức năng', 0.6], ['Tập thân trên trước', 0.3], ['Nhờ chuyên viên vật lý trị liệu', 0.3]]]
    ] },
    drive: { ids: ['tx_cn', 'xe_om', 'shipper', 'tai_xe_tai'], call: U2, cases: [
      ['Khách đặt xe ra sân bay đúng giờ cao điểm, sắp lỡ chuyến bay.', [['Đi đường tắt qua ngõ nhỏ', 0.5], ['Đi đường chính, giữ an toàn', 0.3], ['Gọi trước cho khách đổi chuyến', 0.4]]],
      ['Trời mưa to, đường ngập, vẫn còn mấy đơn hàng chưa giao.', [['Đi đường vòng tránh ngập', 0.4], ['Gọi khách hẹn giao muộn', 0.2], ['Lội nước giao cho kịp', 0.6]]]
    ] },
    office: { ids: ['ke_toan', 'kiem_toan', 'van_phong', 'nhan_su', 'marketing', 'ngan_hang'], call: U2, cases: [
      ['Cuối năm, phòng chạy quyết toán, số liệu lệch mấy trăm triệu.', [['Rà lại từng chứng từ', 0.5], ['Dùng hàm đối chiếu dữ liệu', 0.4], ['Báo cáo cấp trên xin thêm thời gian', 0.2]]],
      ['Công ty ra sản phẩm mới, cần kế hoạch truyền thông gấp.', [['Chạy quảng cáo mạng xã hội', 0.4], ['Mời KOL review', 0.5], ['Tổ chức sự kiện ra mắt', 0.6]]]
    ] },
    law: { ids: ['luat_su', 'cong_chung', 'tro_giup_phap_ly'], call: function () { return 'luật sư'; }, cases: [
      ['Một bà cụ nhờ tư vấn vụ tranh chấp đất với hàng xóm.', [['Hòa giải ở phường trước', 0.3], ['Thu thập giấy tờ, khởi kiện', 0.6], ['Tư vấn miễn phí, chỉ đường thủ tục', 0.3]]],
      ['Một cặp vợ chồng đến tư vấn ly hôn, tranh chấp quyền nuôi con.', [['Khuyên hòa giải vì con', 0.4], ['Chuẩn bị chứng cứ quyền nuôi con', 0.6], ['Thỏa thuận chia tài sản', 0.5]]]
    ] },
    creator: { ids: ['streamer', 'youtuber', 'kol_live', 'fl_video', 'fl_content'], call: U2, cases: [
      ['Kênh đang chững lại, bạn cần một video "bùng nổ".', [['Thử thách 24 giờ', 0.5], ['Review đồ ăn đường phố', 0.4], ['Vlog một ngày đi làm', 0.3], ['Hợp tác với kênh khác', 0.6]]],
      ['Một nhãn hàng mời quảng cáo, sản phẩm bạn chưa dùng thử.', [['Dùng thử một tuần rồi mới nhận', 0.4], ['Nhận ngay, đọc kịch bản sẵn', 0.3], ['Từ chối vì không hợp kênh', 0.2]]]
    ] }
  };
  var BY = {}; Object.keys(JOBS).forEach(function (g) { JOBS[g].ids.forEach(function (id) { BY[id] = g; }); });
  function group(l) { return l.job && !l.retired && BY[E.resolveJob(l.job.id)]; }
  function skill(l) { var j = l.job || {}, c = E.jobDef(l); var s = Math.min(10, j.yrs || 0) * 0.04 + (j.rank || 0) * 0.06 + ((l.st.kno || 50) - 50) / 400; if (c && l.talent && c.talent && c.talent === l.talent) s += 0.1; return s; }
  E.JOB_DETAIL = JOBS;
  SC('nghe_kh', {
    title: function (l) { return 'Một ca làm đáng nhớ · ' + E.jobTitle(l); },
    prep: function (l, r) { var g = group(l); if (!g) return {}; var C = JOBS[g].cases, jid = E.resolveJob(l.job.id), S = l.flags.jobCase || (l.flags.jobCase = {}), fit = C.map(function (_, i) { return i; }).filter(function (i) { return C[i][2] !== 'not:' + jid; }), left = fit.filter(function (i) { return S[g + i] == null || l.age - S[g + i] >= 6; }); var i = left.length ? U.pick(r, left) : U.pick(r, fit); return { g: g, i: i, job: l.job.id }; },
    valid: function (l, d) { return !!group(l) && free(l) && (!d || !d.g || (group(l) === d.g && l.job.id === d.job)); },
    text: function (l, d) { return JOBS[d.g].cases[d.i][0] + ' Bạn chọn cách làm nào?'; },
    opts: [0, 1, 2, 3, 4].map(function (k) {
      return { k: 't' + k, l: function (l, d) { var x = JOBS[d.g].cases[d.i][1][k]; return x ? x[0] : ''; }, h: function (l, d) { var x = JOBS[d.g].cases[d.i][1][k]; return x ? (x[1] >= 0.7 ? 'Khó, cần tay nghề cao' : x[1] >= 0.5 ? 'Vừa sức' : 'Dễ, chắc chắn') : ''; }, req: function (l, d) { return !!JOBS[d.g].cases[d.i][1][k]; }, ai: { w: 1 },
        run: function (l, r, log, d) { work(l, r, log, d, JOBS[d.g].cases[d.i][1][k]); } };
    })
  });
  function work(l, r, log, d, x) {
    var S = l.flags.jobCase || (l.flags.jobCase = {}); S[d.g + d.i] = l.age;
    var p = U.clamp(0.75 + skill(l) - x[1] * 0.55, 0.1, 0.95), call = JOBS[d.g].call(l), name = x[0].charAt(0).toLowerCase() + x[0].slice(1);
    if (ch(r, p)) {
      if (l.job) l.job.rep = U.clamp((l.job.rep == null ? 50 : l.job.rep) + (x[1] >= 0.6 ? 4 : 2), 0, 100);
      if (x[1] >= 0.5 && l.indep) H.cash(l, V(l, 0.2 + x[1] * 0.6), 'Tiền boa / thưởng thêm');
      fx(l, { hap: 3 }); log(U.cap(name) + ': ' + U.pick(r, ['làm xong, người ta khen nức nở: "' + U.cap(call) + ' giỏi thật đấy!"', 'kết quả còn đẹp hơn mong đợi, ảnh được đăng lên mạng kèm lời cảm ơn ' + call + '.', 'mọi thứ suôn sẻ, từ đó có thêm mấy người tìm đến nhờ ' + call + '.']), 'good');
      if (x[1] >= 0.7) H.mem(l, 'Lần làm thành công ' + name + ' — một ca khó trong nghề.', 2);
    } else {
      if (l.job) l.job.rep = U.clamp((l.job.rep == null ? 50 : l.job.rep) - 3, 0, 100);
      fx(l, { hap: -3 }); stress(l, 4); log(U.cap(name) + ': ' + U.pick(r, ['tay nghề chưa tới, kết quả không như ý, bạn phải làm lại và xin lỗi.', 'có trục trặc giữa chừng, người ta không hài lòng. Bạn rút kinh nghiệm cho lần sau.', 'chưa quen kỹ thuật này nên mất gấp đôi thời gian, kết quả chỉ tạm được.']), 'bad');
    }
  }
  T('nghe_kh', function (l) { return !!group(l); }, 0.3, 2, 99, true);
  A('nghe_kh', 'Công việc', 'Nhận một ca / đơn đặc biệt trong nghề', { min: 16, sc: 'nghe_kh', avail: function (l) { return group(l) ? true : 'Không áp dụng với công việc hiện tại'; }, ai: { w: 0.1 } });
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
/* ===== js/life77.js ===== */
/* Một Đời — v6.1.0: viện phí & bảo hiểm y tế thống nhất
   · BHYT (Việt Nam): khám chữa bệnh đúng tuyến được chi trả 80%, bạn trả 20%; trẻ dưới 6 tuổi và hộ nghèo 100%; người hưởng lương hưu 95%
   · bệnh viện tư / dịch vụ theo yêu cầu: BHYT không trả phần chênh
   · trẻ chưa tự lập thì bố mẹ trả viện phí, không trừ tiền riêng của con
   · nha khoa: trám răng sâu, lấy cao răng (BHYT trả), niềng răng, bọc răng sứ (tự trả) */
(function (G) {
  'use strict';
  var U = G.U, E = G.E, H = E.H, SC = E.SC, isVN = H.isVN;
  function vnd(l) { return isVN(l) && l.cur === 'vnd' && !(l.abroad && l.abroad.perm); }
  function V(l, tr) { return vnd(l) ? tr : tr / 90 * l.base; }
  function mo(l, v) { return H.money(l, v); }
  function free(l) { return l.alive && !(l.jailUntil != null && l.age < l.jailUntil) && !(l.abroad && l.abroad.trapped) && !(l.flags.military && l.age < l.flags.military); }
  function parent(l) { var f = l.fam || {}, m = !f.noMom && f.mAlive, b = !f.noDad && f.fAlive; return m && b ? 'bố mẹ' : m ? 'mẹ' : b ? 'bố' : ''; }
  // tỉ lệ bảo hiểm chi trả
  // v7.0: đã định cư hẳn ở nước ngoài thì là bảo hiểm y tế nước sở tại, không phải BHYT Việt Nam
  function vnHome(l) { return isVN(l) && !(l.abroad && l.abroad.perm); }
  function insName(l) { return vnHome(l) ? 'BHYT' : 'bảo hiểm y tế'; }
  E.bhytShare = function (l) {
    if (!E.hasBHYT || !E.hasBHYT(l)) return 0;
    if (!vnHome(l)) return 0.8;
    if (l.age < 6 || (l.fam && l.fam.q <= 1 && !l.indep)) return 1;
    if (l.pensioned || l.age >= 80) return 0.95;
    return 0.8;
  };
  // trả viện phí: cover = 1 (đúng tuyến), 0.5 (dịch vụ: BHYT trả phần chuẩn), 0 (tư nhân / thẩm mỹ)
  E.medBill = function (l, total, why, log, cover) {
    if (!(total > 0)) return 0;
    var share = (cover == null ? 1 : cover) * E.bhytShare(l), ins = total * share, own = total - ins;
    if (!l.indep && l.age < 18) { if (log) log(U.cap(parent(l) || 'gia đình') + ' lo viện phí ' + mo(l, total) + (ins > 0 ? ' (' + insName(l) + ' chi trả ' + Math.round(share * 100) + '%, nhà trả ' + mo(l, own) + ')' : '') + '.', 'neutral'); return 0; }
    H.cash(l, -own, why);
    if (log && ins > 0) log('Viện phí ' + mo(l, total) + ': ' + insName(l) + ' chi trả ' + Math.round(share * 100) + '% (' + mo(l, ins) + '), bạn trả ' + mo(l, own) + '.', 'neutral');
    return own;
  };
  E.medNote = function (l, total, cover) { var s = (cover == null ? 1 : cover) * E.bhytShare(l); return s > 0 ? ' · ' + insName(l) + ' trả ' + Math.round(s * 100) + '%, bạn trả ~' + mo(l, total * (1 - s)) : ''; };

  // nha khoa
  var DENTAL = [
    { k: 'tram', when: function (l) { return l.age >= 6 && l.age <= 75; }, title: 'Răng sâu', text: 'Chiếc răng hàm ê buốt mỗi lần ăn đồ ngọt, soi gương thấy một lỗ đen nhỏ.', opts: [['cong', 'Trám răng ở bệnh viện theo BHYT', 0.4, 1], ['tu', 'Trám ở nha khoa tư, vật liệu tốt hơn', 0.9, 0], ['de', 'Để đó, chưa đau lắm', 0, 0]] },
    { k: 'cao', when: function (l) { return l.age >= 16; }, title: 'Lấy cao răng', text: 'Nướu hay chảy máu khi đánh răng, nha sĩ khuyên nên lấy cao răng.', opts: [['cong', 'Lấy cao răng ở bệnh viện theo BHYT', 0.25, 1], ['tu', 'Làm ở nha khoa tư, kèm đánh bóng', 0.5, 0], ['de', 'Để lần sau', 0, 0]] },
    { k: 'nieng', when: function (l) { return l.age >= 12 && l.age <= 30 && !l.flags.braces; }, title: 'Niềng răng', text: 'Răng mọc lệch, cười hay che miệng. Nha sĩ tư vấn niềng răng hai năm, BHYT không chi trả vì là chỉnh nha thẩm mỹ.', opts: [['mac_cai', 'Niềng mắc cài kim loại', 30, 0], ['trong', 'Niềng trong suốt (khay)', 70, 0], ['de', 'Thôi, để vậy cũng được', 0, 0]] },
    { k: 'su', when: function (l) { return l.age >= 25 && l.indep && !l.flags.veneers; }, title: 'Bọc răng sứ', text: 'Mấy chiếc răng ố vàng, sứt mẻ. Phòng khám quảng cáo bọc sứ "nụ cười Hollywood". BHYT không chi trả.', opts: [['vai', 'Bọc vài chiếc răng cửa', 15, 0], ['ca_ham', 'Bọc cả hàm', 80, 0], ['tay', 'Chỉ tẩy trắng nhẹ', 2, 0], ['de', 'Thôi, giữ răng thật', 0, 0]] }
  ];
  DENTAL.forEach(function (D) {
    var id = 'nha_' + D.k;
    SC(id, {
      title: D.title, valid: function (l) { return free(l) && D.when(l); }, text: D.text,
      opts: D.opts.map(function (o) {
        return { k: o[0], l: o[1], h: function (l) { return o[2] ? 'Khoảng ' + mo(l, V(l, o[2])) + E.medNote(l, V(l, o[2]), o[3]) : 'Không tốn tiền'; }, req: function (l) { return !o[2] || !l.indep || l.money >= V(l, o[2]) * (1 - o[3] * E.bhytShare(l)); }, ai: { w: o[0] === 'de' || o[0] === 'tay' ? 0.6 : o[0] === 'cong' || o[0] === 'mac_cai' || o[0] === 'vai' ? 1.1 : 0.6 },
          run: function (l, r, log) {
            if (!o[2]) { log(D.k === 'tram' ? 'Bạn để đó. Vài tháng sau chiếc răng đau nhức cả đêm.' : (typeof D.title === 'string' ? D.title + ': bạn quyết định để sau.' : 'Bạn quyết định để sau.'), 'neutral'); if (D.k === 'tram') H.fx(l, { hea: -2, hap: -2 }); return; }
            E.medBill(l, V(l, o[2]), D.title + ': ' + o[1].toLowerCase(), log, o[3]);
            if (D.k === 'nieng') { l.flags.braces = l.age; log('Bắt đầu niềng răng. Mấy tuần đầu ăn cháo, cười lộ mắc cài. Hai năm sau tháo niềng, hàm răng đều tăm tắp.', 'good'); H.fx(l, { hap: 3 }); }
            else if (D.k === 'su') { l.flags.veneers = l.age; log(o[0] === 'tay' ? 'Tẩy trắng răng xong, nụ cười sáng hơn hẳn.' : 'Bọc răng sứ xong, nụ cười trắng sáng hẳn.', 'good'); H.fx(l, { hap: 3 }); }
            else { log(D.k === 'tram' ? 'Trám xong, ăn uống không còn ê buốt.' : 'Lấy cao răng xong, nướu hết chảy máu, miệng thơm tho hẳn.', 'good'); H.fx(l, { hea: 1 }); }
          } };
      })
    });
    E.TRIG.push({ id: id, when: function (l, a) { return free(l) && D.when(l); }, p: D.k === 'nieng' ? 0.05 : D.k === 'su' ? 0.02 : 0.05, cd: 4, max: D.k === 'nieng' || D.k === 'su' ? 1 : 3 });
  });
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
/* ===== js/life78.js ===== */
/* Một Đời — v6.1.0: thưởng Tết / thưởng cuối năm theo ngành nghề
   · người làm công ăn lương: thưởng tính bằng số tháng lương, tùy ngành (ngân hàng, dầu khí, công nghệ, sản xuất, dịch vụ, khu vực nhà nước…)
   · nhân theo kết quả kinh doanh năm đó (năm khó khăn chỉ có quà Tết), uy tín và cấp bậc của bạn
   · mới vào làm trong năm thì thưởng ít; chủ cơ sở, người làm tự do, nghề phi pháp không có thưởng
   · ở nước ngoài: Nhật / Hàn thưởng hai kỳ, Philippines lương tháng 13 bắt buộc, Đức lương tháng 13, Singapore AWS… */
(function (G) {
  'use strict';
  var U = G.U, E = G.E, H = E.H, isVN = H.isVN;
  function mo(l, v) { return H.money(l, v); }
  // [từ, đến] số tháng lương thưởng cho năm bình thường
  var IND = [
    [/^(ngan_hang|ngan_hang_cao)$/, [3, 6], 'ngân hàng'],
    [/^(gian_khoan|dnnn)$/, [2.5, 5], 'doanh nghiệp năng lượng / nhà nước lớn'],
    [/^(dev|data|ky_su|ky_su_co_dien)$/, [1.5, 3.5], 'công nghệ'],
    [/^(sale_bds|sale_oto|sale_bh|sale_b2b|sale_mp|telesale)$/, [1, 4], 'kinh doanh (theo doanh số)'],
    [/^(ke_toan|kiem_toan|van_phong|nhan_su|marketing|logistics|luat_su|kien_truc|thiet_ke|ky_su_xd)$/, [1, 2.5], 'văn phòng'],
    [/^(cong_nhan|tho_may|tho_han|tho_dien|ky_thuat_vien|tho_moc|tho_mo|tai_xe_tai|thuyen_vien)$/, [1, 1.8], 'sản xuất'],
    [/^(phi_cong|tiep_vien|kskl)$/, [2, 4], 'hàng không'],
    [/^(bac_si|dieu_duong|duoc_si|nha_si|thu_y)$/, [0.8, 2], 'y tế'],
    [/^(cong_chuc|vien_chuc|can_bo_xa|thue|hai_quan|tham_phan|kiem_sat|ngoai_giao|qltt|kiem_lam|cong_an|quan_doi|giao_vien|giang_vien|gv_mam_non|nghien_cuu|dieu_tra_vien|chap_hanh_vien)$/, [0.4, 0.8], 'khu vực nhà nước'],
    [/^(phuc_vu|barista|bartender|le_tan|thu_ngan|dau_bep|bao_ve|giup_viec|hdv|tho_toc|barber|nail|spa|makeup)$/, [0.5, 1.2], 'dịch vụ'],
    [/^(phong_vien|mc_tv|bien_kich|dao_dien)$/, [1, 2], 'truyền thông']
  ];
  var WORLD = { JP: [2.5, 5, 'thưởng hai kỳ mùa hè và cuối năm'], KR: [1.5, 4, 'thưởng cuối năm'], CN: [1, 3, 'thưởng cuối năm (年终奖)'], TW: [1.5, 3, 'thưởng cuối năm'], SG: [1, 3, 'AWS lương tháng 13 và thưởng hiệu suất'], PH: [1, 1.5, 'lương tháng 13 bắt buộc'], DE: [0.8, 1.2, 'lương tháng 13 (Weihnachtsgeld)'], AT: [1.8, 2.2, 'lương tháng 13 và 14'], US: [0.2, 1, 'thưởng cuối năm'], GB: [0.2, 0.8, 'thưởng cuối năm'] };
  function indOf(id) { for (var i = 0; i < IND.length; i++) if (IND[i][0].test(id)) return IND[i]; return [null, [0.8, 1.5], 'doanh nghiệp']; }
  function eligible(l) {
    if (!l.alive || !l.job || l.retired || !l.indep || (l.jailUntil != null && l.age < l.jailUntil) || (l.abroad && l.abroad.trapped)) return false;
    if (E.isCrime && E.isCrime(l)) return false;
    if (!H.isEmployee(l) || (E.isFreelanceJob && E.isFreelanceJob(l)) || l.job.fam) return false;
    var c = E.jobDef(l); if (!c || c.fame || c.cat === 'biz' || c.owner) return false;
    return (l.income || 0) > 0;
  }
  E.tetBonusEligible = eligible;
  E.tetBonus = function (l, r) {
    var id = E.resolveJob(l.job.id), here = (l.abroad && l.abroad.perm && l.abroad.code) || l.country, vn = here === 'VN';
    var rng = vn ? indOf(id) : WORLD[here] ? [null, [WORLD[here][0], WORLD[here][1]], WORLD[here][2]] : [null, [0.5, 1.2], 'thưởng cuối năm'];
    var lo = rng[1][0], hi = rng[1][1], months = lo + r() * (hi - lo), x = r(), mood;
    if (x < 0.15) { months *= 0.15 + r() * 0.25; mood = 'bad'; } else if (x > 0.82) { months *= 1.3 + r() * 0.4; mood = 'good'; } else mood = 'normal';
    var rep = l.job.rep == null ? 50 : l.job.rep; months *= (0.8 + rep / 250) * (1 + (l.job.rank || 0) * 0.08);
    var newbie = l.job.since != null && l.age - l.job.since < 1; if (newbie) months *= 0.25;
    var monthly = (l.income || 0) / 12;
    return { months: Math.max(0, months), amount: Math.max(0, months * monthly), mood: mood, ind: rng[2], vn: vn, newbie: newbie, pub: vn && /nhà nước/.test(rng[2]) };
  };
  E.HOOKS.year.unshift(function (l, r, log, a) {
    if (!eligible(l) || l.flags.tetAt === a) return;
    l.flags.tetAt = a;
    var b = E.tetBonus(l, r), m = Math.round(b.months * 10) / 10, mStr = (m >= 1 ? m.toLocaleString('vi-VN') : m.toLocaleString('vi-VN')) + ' tháng lương';
    if (b.amount < l.base * 0.005) { log(b.vn ? 'Tết năm nay ' + (b.newbie ? 'mới vào làm nên' : 'công ty khó khăn,') + ' chỉ được nhận giỏ quà Tết và bao lì xì đầu năm.' : 'Cuối năm chỉ nhận được một phần quà nhỏ từ công ty.', 'neutral'); return; }
    H.cash(l, b.amount, b.vn ? 'Thưởng Tết' : 'Thưởng cuối năm');
    var t;
    if (b.vn) {
      if (b.pub) t = 'Cuối năm ở cơ quan nhà nước không có thưởng Tết như doanh nghiệp, chỉ có tiền thưởng theo quy định và quà Tết: khoảng ' + mStr + ' (' + mo(l, b.amount) + ').';
      else if (b.newbie) t = 'Mới vào làm chưa đủ năm, Tết này được thưởng ' + mStr + ' (' + mo(l, b.amount) + '), vẫn vui vì có tiền về quê.';
      else if (b.mood === 'good') t = U.pick(r, ['Năm nay ' + b.ind + ' làm ăn khấm khá, thưởng Tết ' + mStr + ' (' + mo(l, b.amount) + '). Cả phòng reo lên khi nhận thông báo.', 'Công ty vượt kế hoạch, thưởng Tết hẳn ' + mStr + ' (' + mo(l, b.amount) + ') kèm giỏ quà to.']);
      else if (b.mood === 'bad') t = U.pick(r, ['Năm nay công ty khó khăn, thưởng Tết chỉ ' + mStr + ' (' + mo(l, b.amount) + ') kèm hộp bánh.', 'Kinh tế ảm đạm, thưởng Tết teo tóp còn ' + mo(l, b.amount) + ', ai cũng thở dài.']);
      else t = U.pick(r, ['Thưởng Tết ' + mStr + ' (' + mo(l, b.amount) + '), vừa đủ sắm Tết và biếu bố mẹ.', 'Nhận lương tháng 13 và thưởng Tết, tổng cộng ' + mStr + ' (' + mo(l, b.amount) + ').', 'Thưởng Tết năm nay ' + mo(l, b.amount) + ' (' + mStr + '), như mọi năm.']);
    } else t = 'Cuối năm nhận ' + b.ind + ': ' + mStr + ' (' + mo(l, b.amount) + ')' + (b.mood === 'good' ? ', công ty có một năm làm ăn tốt.' : b.mood === 'bad' ? ', năm khó khăn nên ít hơn mọi năm.' : '.');
    log(t, b.mood === 'bad' ? 'neutral' : 'good'); H.fx(l, { hap: b.mood === 'good' ? 4 : b.mood === 'bad' ? -1 : 2 });
  });
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
/* ===== js/life79.js ===== */
/* Một Đời — v6.2.0: ứng dụng hẹn hò hiện 5 hồ sơ để chọn
   · mỗi lần mở app (Tinder, Bumble, Hinge, Facebook Hẹn hò, Blued, HER…) hiện 5 hồ sơ ngẫu nhiên: tên, tuổi, nghề, giới thiệu, sở thích
   · bạn chọn nhắn tin với người mình muốn, lướt thêm 5 người khác, hoặc thoát app
   · đằng sau mỗi hồ sơ có thể là người tử tế, người "đào mỏ", người rủ đầu tư, ảnh ảo hay "Việt kiều gửi quà" — hồ sơ chỉ có vài dấu hiệu, không nói thẳng */
(function (G) {
  'use strict';
  var U = G.U, E = G.E, H = E.H, SC = E.SC;
  var TYPES = [['tot', 55], ['dao_mo', 15], ['dau_tu', 10], ['catfish', 12], ['qua_tang', 8]];
  var BIO = {
    tot: ['Thích nấu ăn, cuối tuần hay chạy bộ quanh hồ.', 'Mê đọc sách, đang tìm người cùng đi cà phê sách.', 'Hướng nội, nuôi hai bé mèo, thích đi biển.', 'Đi làm giờ hành chính, tối học thêm tiếng Anh.', 'Tìm người nghiêm túc, không thích nhắn tin cho vui.', 'Hay đi phượt, chụp ảnh phong cảnh.', 'Thích nhạc acoustic, biết chơi guitar vài bài.', 'Mê xem phim, cuối tuần hay đi xem rạp một mình.'],
    dao_mo: ['Thích du lịch sang, nhà hàng đẹp, đồ hiệu. Tìm người biết chiều.', 'Ảnh check-in toàn khách sạn 5 sao. "Không thích đàn ông keo kiệt."', 'Gu: người có điều kiện, chững chạc một chút.'],
    dau_tu: ['Tự do tài chính tuổi 25 nhờ đầu tư. Thích chia sẻ cách kiếm tiền.', 'Kinh doanh online, đầu tư vàng và tiền số. Tìm người cùng chí hướng.'],
    catfish: ['Chỉ có hai ảnh, ảnh nào cũng như chụp tạp chí.', 'Người mẫu ảnh, ít khi online, thích nhắn tin hơn gọi điện.'],
    qua_tang: ['Đang làm việc ở nước ngoài, sắp về Việt Nam, tìm người chân thành.', 'Kỹ sư làm việc trên giàn khoan ngoài biển, nói tiếng Việt chưa sõi.']
  };
  var LIKE = ['cà phê', 'du lịch', 'nấu ăn', 'gym', 'đọc sách', 'chơi game', 'xem phim', 'âm nhạc', 'thú cưng', 'chụp ảnh', 'đá bóng', 'cầu lông', 'leo núi', 'karaoke'];
  function wpick(r, A) { var t = 0; A.forEach(function (x) { t += x[1]; }); var y = r() * t; for (var i = 0; i < A.length; i++) { y -= A[i][1]; if (y <= 0) return A[i][0]; } return A[0][0]; }
  function profiles(l, r) {
    var out = [];
    for (var i = 0; i < 5; i++) {
      var s = H.partnerSex(l, r), t = wpick(r, TYPES), age = Math.max(18, l.age + U.randint(r, -5, 5)), q = { age: age, sex: s };
      if (H.partnerJob) H.partnerJob(l, q, r);
      var likes = []; while (likes.length < 2) { var x = U.pick(r, LIKE); if (likes.indexOf(x) < 0) likes.push(x); }
      out.push({ n: H.stranger(l, r, s), s: s, age: age, job: t === 'catfish' ? 'người mẫu ảnh' : t === 'qua_tang' ? (s === 'M' ? 'kỹ sư dầu khí ở nước ngoài' : 'bác sĩ ở nước ngoài') : q.job || 'nhân viên văn phòng', t: t, bio: U.pick(r, BIO[t]), likes: likes, km: U.randint(r, 1, t === 'qua_tang' ? 9000 : 25) });
    }
    return out;
  }
  function card(p) { return p.n + ' · ' + p.age + ' tuổi · ' + p.job + ' · cách ' + (p.km >= 1000 ? 'rất xa' : p.km + ' km') + ' — ' + p.bio + ' Thích: ' + p.likes.join(', ') + '.'; }
  SC('app_ho_so', {
    title: function (l, d) { return d.app + ' · ' + (d.page + 1 > 1 ? 'lướt thêm' : 'gợi ý hôm nay'); },
    prep: function (l, r, a) { var s = l.flags.appSwipe; if (!s || s.app !== (a && a.app) || (a && a.fresh)) s = l.flags.appSwipe = { app: (a && a.app) || 'Tinder', page: 0, at: l.age }; s.list = profiles(l, r); return { app: s.app, page: s.page, at: l.age }; },
    valid: function (l, d) { return !l.partner && l.age >= 18 && !!l.flags.appSwipe && (!d || d.at == null || d.at === l.age); },
    text: function (l, d) { var s = l.flags.appSwipe; return 'Năm hồ sơ hiện lên trên ' + d.app + ':\n' + s.list.map(function (p, i) { return (i + 1) + '. ' + card(p); }).join('\n') + '\nBạn muốn nhắn tin với ai?'; },
    opts: [0, 1, 2, 3, 4].map(function (i) {
      return { k: 'p' + i, l: function (l) { var p = l.flags.appSwipe && l.flags.appSwipe.list[i]; return p ? 'Nhắn tin với ' + p.n + ' (' + p.age + ' tuổi, ' + p.job + ')' : ''; }, req: function (l) { return !!(l.flags.appSwipe && l.flags.appSwipe.list[i]); }, ai: { w: 1 },
        run: function (l, r, log) {
          var s = l.flags.appSwipe, p = s && s.list[i]; if (!p) return; l.flags.appSwipe = null;
          if (r() < 0.2) { log('Bạn gửi lời chào ' + p.n + ' trên ' + s.app + ', nhưng ' + (p.s === 'M' ? 'anh ấy' : 'cô ấy') + ' chỉ "seen" rồi im lặng.', 'neutral'); return; }
          if ((E.HOOKUP_APP || /Tinder|Blued/).test(s.app) && l.age <= 45 && E.DEC.qua_dem && r() < 0.2) { l.pending.unshift(E.DEC.qua_dem.make(l, r, { app: s.app, name: p.n })); return; } // app quẹt nhanh: có người chỉ muốn gặp qua đêm
          l.pending.unshift(E.DEC.hen_online.make(l, r, { app: s.app, s: p.s, n: p.n, t: p.t, age: p.age, job: p.job }));
        } };
    }).concat([
      { k: 'luot', l: 'Lướt thêm 5 hồ sơ khác', req: function (l) { return !!l.flags.appSwipe && l.flags.appSwipe.page < 2; }, ai: { w: 0.4 }, run: function (l, r) { var s = l.flags.appSwipe; s.page++; l.pending.unshift(E.DEC.app_ho_so.make(l, r, { app: s.app })); } },
      { k: 'thoat', l: 'Không thấy ai hợp, thoát app', ai: { w: 0.4 }, run: function (l, r, log) { var s = l.flags.appSwipe; l.flags.appSwipe = null; log('Lướt ' + (s ? s.app : 'app') + ' một lúc mà không thấy ai hợp, bạn tắt máy đi ngủ.', 'neutral'); } }
    ])
  });
  // mở ứng dụng hẹn hò → hiện 5 hồ sơ (giữ nhóm kết bạn trung niên theo lối cũ)
  if (E.DEC.app_hen_ho) E.DEC.app_hen_ho.def.opts.forEach(function (o) {
    if (o.k === 'no' || o.k === 'trung_nien') return;
    o.run = function (l, r, log) { l.pending.unshift(E.DEC.app_ho_so.make(l, r, { app: typeof o.l === 'function' ? o.l(l) : o.l, fresh: true })); };
  });
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
