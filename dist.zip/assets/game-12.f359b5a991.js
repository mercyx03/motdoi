/* ===== js/life44.js ===== */
/* Một Đời — v4.3 (góp ý của người chơi):
   · mất mát người thân: lần đầu tiên (dù là bố mẹ, ông bà, anh chị em…) mới là "lần đầu hiểu thế nào là mất mát"; những lần sau là nỗi đau chồng lên nỗi đau
   · sức khỏe tinh thần: bạn bè gặp khủng hoảng (hỏi thẳng, lắng nghe, đưa đến hỗ trợ), những ngày tăm tối của chính mình, nỗi đau sau mất mát — có thông tin đường dây hỗ trợ
   · định kiến nghề nghiệp: thợ xăm, shipper, người nhặt ve chai, nam điều dưỡng / giáo viên mầm non, ca sĩ, streamer, tuyển thủ esports, thợ nail, bartender, giúp việc, nông dân, công nhân…
     — một người lạ tử tế, lựa chọn của bạn trở thành ký ức và được nhắc lại về sau */
(function (G) {
  'use strict';
  var U = G.U, E = G.E, H = E.H, SC = E.SC, isVN = H.isVN;
  function fx(l, o) { H.fx(l, o); }
  function pick(r, a) { return U.pick(r, a); }
  function ch(r, p) { return r() < p; }
  function inJail(l) { return l.jailUntil != null && l.age < l.jailUntil; }
  function free(l) { return !inJail(l) && !(l.abroad && l.abroad.trapped) && !(l.flags.military && l.age < l.flags.military); }
  function T(id, when, p, cd, max) { E.TRIG.push({ id: id, when: function (l, a) { return free(l) && when(l, a); }, p: p, cd: cd || 4, max: max || 1 }); }
  function stress(l, x) { if (l.mind) l.mind.stress = U.clamp(l.mind.stress + x, 0, 100); }
  function job(l) { return l.job ? E.resolveJob(l.job.id) : null; }
  function vnHere(l) { return isVN(l) && !(l.abroad && l.abroad.perm); }
  var HOTLINE = 'Ở Việt Nam có Đường dây nóng Ngày Mai 096 306 1414 (miễn phí, tham vấn tâm lý cho người trầm cảm, khủng hoảng và người thân); khi nguy cấp gọi cấp cứu 115.';
  function hotline(l) { return vnHere(l) ? HOTLINE : 'Ở nhiều nước có đường dây hỗ trợ khủng hoảng miễn phí (findahelpline.com); khi nguy cấp gọi số cấp cứu.'; }
  E.HOTLINE = hotline;

  // ===================================================================
  // 1. MẤT MÁT NGƯỜI THÂN: LẦN ĐẦU VÀ NHỮNG LẦN SAU
  // ===================================================================
  var LOSS = /^(Ông nội|Bà nội|Ông ngoại|Bà ngoại|Bố|Mẹ|Chồng|Vợ|Người bạn đời|Anh|Chị|Em|Con) [^.]*qua đời|^Hung tin: .* qua đời/;
  var FIRST_OLD = / ?Lần đầu bạn hiểu thế nào là mất mát\./;
  var LATER = ['Lại thêm một lần tiễn biệt người thân — vết thương cũ chưa kịp lành đã có thêm vết mới.', 'Nỗi đau ngày trước chưa nguôi, giờ lại thêm một nỗi đau nữa.', 'Lại một lần đứng trước di ảnh người thân, bạn thấy mình như vừa mất thêm một phần ký ức.'];
  var MANY = ['Đã qua bao lần tiễn biệt, nhưng chưa lần nào bớt đau.', 'Mỗi người ra đi lại mang theo một phần của bạn.', 'Càng lớn càng quen với những đám tang, nhưng chẳng bao giờ quen được cảm giác mất mát.', 'Những người thương cứ lần lượt đi xa, căn nhà mỗi năm lại thêm một chỗ trống.'];
  function who(t) { var m = t.match(LOSS); return m ? m[1] || 'bff' : null; }
  E.lossText = function (l, t, k) {
    if (k !== 'bad' || typeof t !== 'string' || !LOSS.test(t) || !l || !l.flags) return t;
    var w = who(t), a = l.age; t = t.replace(FIRST_OLD, '');
    if (w === 'Con' && !/^Con [A-ZÀ-Ỹ]/.test(t)) return t;
    var F = l.flags, n = F.lossN = (F.lossN || 0) + 1;
    if (a < 4) { F.lossBaby = true; return t + ' Khi ấy bạn còn quá nhỏ để nhớ, chỉ lớn lên qua những tấm ảnh và lời kể của người lớn.'; }
    var felt = F.lossFelt = (F.lossFelt || 0) + 1, extra;
    if (felt === 1) extra = (w === 'Bố' || w === 'Mẹ') && a < 18 ? 'Mới ' + a + ' tuổi, lần đầu bạn hiểu thế nào là mất mát — một khoảng trống chẳng gì lấp được.' : 'Lần đầu bạn hiểu thế nào là mất mát.';
    else if (w === 'Con') extra = 'Không nỗi đau nào lớn bằng cảnh người đầu bạc tiễn kẻ đầu xanh.';
    else if (/^(Chồng|Vợ|Người bạn đời)$/.test(w)) extra = 'Một nửa của bạn đã đi xa — ' + (felt === 2 ? 'nỗi đau này còn lớn hơn tất cả những lần trước.' : 'bao lần tiễn biệt cũng không đau bằng lần này.');
    else if ((w === 'Bố' || w === 'Mẹ') && F.lossParent) extra = 'Giờ bạn không còn bố mẹ nữa — từ nay không còn ai để gọi "bố ơi, mẹ ơi" mỗi lần về nhà.';
    else extra = felt === 2 ? LATER[(n + a) % LATER.length] : MANY[(n + a) % MANY.length];
    if (w === 'Bố' || w === 'Mẹ') F.lossParent = true;
    F.lossAt = a; F.lossWho = w;
    return t + ' ' + extra;
  };

  // ===================================================================
  // 2. SỨC KHỎE TINH THẦN, PHÒNG CHỐNG TỰ TỬ
  // ===================================================================
  SC('ban_khung_hoang', {
    title: 'Tin nhắn lúc nửa đêm',
    prep: function (l, r) { var n = l.bff && l.bff.alive ? l.bff.name : H.stranger(l, r, pick(r, ['M', 'F'])); return { n: n, bff: !!(l.bff && l.bff.alive && n === l.bff.name) }; },
    text: function (l, d) { return 'Một đêm khuya, ' + d.n + (d.bff ? ' — người bạn thân nhất —' : ', người bạn đã lâu không liên lạc,') + ' nhắn cho bạn: "Mệt quá rồi. Chắc không ai cần mình nữa đâu." Rồi im lặng, không trả lời thêm.'; },
    opts: [
      { k: 'goi', l: 'Gọi điện ngay, hỏi thẳng xem bạn ấy có đang nghĩ đến chuyện tự tử không, rồi lắng nghe', h: 'Hỏi thẳng không làm ý nghĩ đó lớn thêm — lắng nghe và cùng tìm hỗ trợ chuyên môn', ai: { w: 1.6, soc: 1 },
        run: function (l, r, log, d) { log('Gọi ngay cho ' + d.n + ', hỏi thẳng, rồi lắng nghe đến tận gần sáng. Hôm sau hai người cùng tìm đến nơi tư vấn tâm lý. ' + hotline(l), 'good'); fx(l, { karma: 8, soc: 3 }); l.flags.savedFriend = d.n; H.mem(l, 'Đêm gọi điện cho ' + d.n + ' đến gần sáng. Mấy tháng sau ' + d.n + ' nói: "Cảm ơn mày đã gọi."', 6); } },
      { k: 'nhan', l: 'Nhắn lại: "Cố lên, ai cũng có lúc thế mà"', ai: { w: 0.7 },
        run: function (l, r, log, d) { if (ch(r, 0.5)) log(d.n + ' chỉ thả một biểu tượng cảm xúc. Mấy hôm sau bạn mới biết ' + d.n + ' đã phải vào viện vì khủng hoảng tâm lý — may mà gia đình kịp phát hiện. Bạn hiểu ra: một lời "cố lên" đôi khi là chưa đủ. ' + hotline(l), 'bad'); else log(d.n + ' trả lời "ừ, cảm ơn". Bạn hẹn cuối tuần gặp nhau, ngồi cà phê nói chuyện cả buổi.', 'neutral'); fx(l, { soc: 1 }); } },
      { k: 'nguoi_than', l: 'Gọi cho người nhà bạn ấy, rồi cùng đến tận nơi', ai: { w: 1, smart: 1 },
        run: function (l, r, log, d) { log('Gọi cho người nhà ' + d.n + ' rồi cùng chạy đến. Cả nhà ngồi bên ' + d.n + ' đến sáng, hôm sau đưa đi khám ở chuyên khoa tâm thần. ' + hotline(l), 'good'); fx(l, { karma: 6 }); H.mem(l, 'Đêm cùng gia đình ' + d.n + ' chạy đến bên bạn ấy.', 5); } }
    ]
  });
  T('ban_khung_hoang', function (l, a) { return a >= 15 && a <= 80; }, 0.012, 8, 1);
  SC('nhung_ngay_toi', {
    title: 'Những ngày tăm tối', valid: function (l) { return !!l.mind && l.mind.stress >= 60 && l.st.hap < 40; },
    text: 'Đã mấy tuần nay bạn mất ngủ, chẳng muốn ăn, chẳng muốn gặp ai. Có những đêm bạn nghĩ giá như mình biến mất thì mọi người sẽ nhẹ nhõm hơn.',
    opts: [
      { k: 'noi', l: 'Nói thật với người thân, người bạn tin tưởng', ai: { w: 1.3, soc: 1 }, run: function (l, r, log) { var w = l.partner ? l.partner.name : l.fam.mAlive ? 'mẹ' : l.fam.fAlive ? 'bố' : l.bff && l.bff.alive ? l.bff.name : 'một người bạn'; log('Lấy hết can đảm nói với ' + w + '. ' + U.cap(w) + ' không trách, chỉ ôm bạn thật lâu, rồi cùng bạn đi khám. Bạn không phải một mình.', 'good'); stress(l, -25); fx(l, { hap: 8 }); H.mem(l, 'Ngày nói thật với ' + w + ' về những ngày tăm tối.', 5); } },
      { k: 'goi', l: 'Gọi đường dây hỗ trợ tâm lý', h: function (l) { return vnHere(l) ? 'Đường dây nóng Ngày Mai 096 306 1414, miễn phí' : 'đường dây hỗ trợ khủng hoảng miễn phí'; }, ai: { w: 1, smart: 1 }, run: function (l, r, log) { log('Gọi đường dây hỗ trợ. Người ở đầu dây bên kia lắng nghe, không phán xét, chỉ cho bạn những bước nhỏ để vượt qua đêm nay và nơi khám gần nhất. ' + hotline(l), 'good'); stress(l, -18); fx(l, { hap: 5 }); } },
      { k: 'kham', l: 'Đi khám bác sĩ chuyên khoa tâm thần / tâm lý', h: function (l) { return 'Khoảng ' + H.money(l, isVN(l) && l.cur === 'vnd' ? 3 : 3 / 90 * l.base) + ' mỗi đợt'; }, ai: { w: 1, smart: 1.2 }, run: function (l, r, log) { H.cash(l, -(isVN(l) && l.cur === 'vnd' ? 3 : 3 / 90 * l.base), 'Khám, điều trị tâm lý'); log('Đi khám, được chẩn đoán trầm cảm mức độ vừa. Uống thuốc, trị liệu tâm lý vài tháng, những buổi sáng dần có nắng trở lại.', 'good'); stress(l, -30); fx(l, { hap: 10 }); l.flags.therapy = true; } },
      { k: 'giu', l: 'Giữ trong lòng, tự mình chịu đựng', ai: { w: 0.4 }, run: function (l, r, log) { log('Giữ tất cả trong lòng. Mọi thứ nặng dần lên. Đến một ngày, bạn biết mình cần được giúp đỡ — trầm cảm là bệnh, và bệnh thì cần chữa. ' + hotline(l), 'bad'); stress(l, 6); fx(l, { hap: -4, hea: -3 }); } }
    ]
  });
  T('nhung_ngay_toi', function (l, a) { return a >= 13 && !!l.mind && l.mind.stress >= 65 && l.st.hap < 35; }, 0.07, 8, 2);
  SC('sau_mat_mat', {
    title: 'Sau ngày tiễn biệt', valid: function (l) { return l.flags.lossAt != null && l.age - l.flags.lossAt <= 1; },
    text: 'Người thân mất đã mấy tháng, nhưng bạn vẫn hay vô thức gọi tên, vẫn để nguyên đồ đạc của người ấy, có những đêm khóc một mình.',
    opts: [
      { k: 'chia_se', l: function (l) { return E.hasFamily && !E.hasFamily(l) ? 'Ngồi lại với bạn bè thân, cùng kể về người đã khuất' : 'Ngồi lại với gia đình, cùng kể về người đã khuất'; }, ai: { w: 1.3, soc: 1 }, run: function (l, r, log) { log((E.hasFamily && !E.hasFamily(l) ? 'Mấy người bạn thân' : 'Cả nhà') + ' ngồi lại kể chuyện về người đã khuất, vừa khóc vừa cười. Nỗi đau vẫn còn, nhưng không còn phải mang một mình.', 'good'); stress(l, -12); fx(l, { hap: 5, soc: 2 }); } },
      { k: 'viec', l: 'Lao vào công việc cho quên', ai: { w: 0.8 }, run: function (l, r, log) { log('Lao vào làm việc từ sáng đến tối. Đến lúc dừng lại, nỗi buồn vẫn ở đó.', 'neutral'); stress(l, 6); } },
      { k: 'tu_van', l: 'Tìm đến chuyên gia tâm lý', ai: { w: 0.5, smart: 1 }, run: function (l, r, log) { H.cash(l, -(isVN(l) && l.cur === 'vnd' ? 2 : 2 / 90 * l.base), 'Tư vấn tâm lý'); log('Đi gặp chuyên gia tâm lý vài buổi, học cách sống cùng nỗi nhớ.', 'good'); stress(l, -18); fx(l, { hap: 4 }); } }
    ]
  });
  T('sau_mat_mat', function (l, a) { return a >= 12 && l.flags.lossAt != null && a - l.flags.lossAt <= 1 && (l.flags.lossFelt || 0) >= 1; }, 0.3, 6, 3);

  // ===================================================================
  // 3. ĐỊNH KIẾN NGHỀ NGHIỆP — MỘT NGƯỜI LẠ TỬ TẾ, MỘT KÝ ỨC VỀ SAU
  // ===================================================================
  var STG = [
    { k: 'xam', jobs: ['tho_xam'], title: 'Ở trạm xe buýt',
      scene: 'Bạn là thợ xăm, luôn xem mỗi hình xăm là nghệ thuật, là cách mỗi người lưu giữ câu chuyện của riêng mình. Một buổi chiều đợi xe buýt, bạn nghe một người phụ nữ nói với con: "Tránh xa mấy người xăm trổ ra con, nhìn là biết chẳng tốt đẹp gì." Bạn im lặng, kéo tay áo xuống che những hình xăm.',
      who: 'bà cụ', kind: 'Một bà cụ ngồi bên khẽ mỉm cười: "Cháu à, người ta nhìn thấy hình xăm trên da cháu, nhưng đâu thấy hết những điều trong lòng cháu. Bà gặp người chẳng có lấy một hình xăm mà lòng dạ đầy vết xấu, cũng gặp người xăm kín hai tay mà trái tim rất đỗi tử tế. Hình xăm chỉ nói lên điều cháu thích, còn cách cháu sống mới nói lên cháu là ai."',
      quote: 'Hình xăm chỉ nói lên điều cháu thích, còn cách cháu sống mới nói lên cháu là ai', end: 'Bà cụ vỗ nhẹ lên tay bạn. Chiếc xe buýt từ từ vào trạm. Lần đầu tiên trong ngày, bạn không còn muốn kéo tay áo xuống nữa.',
      fu: 'Một cô gái trẻ đến tiệm, đặt lên bàn tấm ảnh người mẹ vừa mất: "Em muốn xăm nét chữ mẹ viết, để lúc nào mẹ cũng ở bên em."', fuDo: 'Xăm thật tỉ mỉ, không lấy tiền công', fuDone: 'Bạn xăm từng nét chữ thật tỉ mỉ. Cô gái nhìn cổ tay mình rồi bật khóc: "Đúng chữ mẹ em rồi."' },
    { k: 'ship', jobs: ['shipper', 'tx_cn', 'xe_om'], title: 'Câu nói ở đầu ngõ',
      scene: 'Đang chờ khách nhận hàng, bạn nghe một người mẹ dặn con: "Không chịu học thì sau này đi giao hàng như chú kia, nắng mưa khổ cả đời." Bạn cúi xuống chỉnh lại thùng hàng, giả như không nghe thấy.',
      who: 'ông cụ', kind: 'Ông cụ ngồi uống trà đầu ngõ gọi bạn lại, rót cho chén trà: "Đừng để bụng cháu ạ. Mấy năm dịch bệnh, cả phố này sống nhờ những đứa như cháu. Nghề nào nuôi được mình bằng mồ hôi thì nghề đó đáng quý."',
      quote: 'Nghề nào nuôi được mình bằng mồ hôi thì nghề đó đáng quý', end: 'Bạn uống cạn chén trà, cảm ơn ông rồi nổ máy đi tiếp. Con đường hôm ấy bỗng như ngắn lại.',
      fu: 'Trời mưa bão, có đơn thuốc gấp cho một bà cụ sống một mình ở hẻm sâu, chẳng ai nhận.', fuDo: 'Đội mưa đi giao', fuDone: 'Bạn đội mưa mang thuốc đến. Bà cụ nắm tay bạn, dúi cho mấy cái bánh: "Có cháu bà mới qua được đêm nay."' },
    { k: 've_chai', jobs: ['ve_chai', 've_so', 'phu_ho'], title: 'Ánh mắt ngoài chợ',
      scene: 'Bạn đi ngang một quán cà phê, cậu thanh niên bàn bên bịt mũi, nói đủ to cho cả quán nghe: "Nhìn là biết nghèo vì lười." Bạn rảo bước thật nhanh.',
      who: 'cô chủ quán', kind: 'Cô chủ quán chạy theo, đưa cho bạn chai nước mát: "Em đừng nghe nó. Cô biết em, sáng nào cũng thấy em đi từ lúc trời chưa sáng. Người ta không biết mình đã cố gắng thế nào đâu, chỉ mình biết thôi."',
      quote: 'Người ta không biết mình đã cố gắng thế nào, chỉ mình biết thôi', end: 'Bạn cầm chai nước, đứng lặng một lúc. Rồi lại đi tiếp, lưng thẳng hơn một chút.',
      fu: 'Bạn nhặt được một chiếc ví có cả chục triệu đồng và giấy tờ của một người lạ.', fuDo: 'Mang ví đến tận nhà trả lại', fuDone: 'Bạn tìm đến tận nhà trả lại chiếc ví. Người ta ngỡ ngàng, còn bạn chỉ cười: "Của ai thì trả người nấy."' },
    { k: 'nam_nu', jobs: ['dieu_duong', 'gv_mam_non'], cond: function (l) { return l.sex === 'M'; }, title: '"Con trai mà làm nghề con gái"',
      scene: function (l) { return 'Đám cưới họ hàng, mấy ông chú cười cợt: "Con trai mà đi ' + (job(l) === 'gv_mam_non' ? 'trông trẻ mẫu giáo' : 'làm điều dưỡng, bưng bô cho người ta') + ', chẳng ra dáng đàn ông." Bạn cười trừ, rót thêm chén rượu.'; },
      who: 'bà nội', kind: function (l) { return 'Tối ấy bà ' + (l.fam && l.fam.mAlive ? 'nội' : 'ngoại') + ' gọi bạn vào buồng: "Ngày xưa ông cháu cũng chăm bà từng thìa cháo lúc bà ốm. Đàn ông tử tế là người biết thương người khác, chứ đâu phải ở cái nghề."'; },
      quote: 'Đàn ông tử tế là người biết thương người khác, chứ đâu phải ở cái nghề', end: 'Bạn ngồi bên bà thật lâu. Sáng hôm sau đi làm, bạn chẳng còn thấy ngại khi người ta hỏi mình làm nghề gì.',
      fu: function (l) { return job(l) === 'gv_mam_non' ? 'Một bé trong lớp mất bố, cả tuần không nói chuyện với ai, chỉ ôm khư khư con gấu bông.' : 'Một bệnh nhân già neo đơn sắp xuất viện, không có ai đón về.'; }, fuDo: 'Dành thêm thời gian ở bên', fuDone: function (l) { return job(l) === 'gv_mam_non' ? 'Bạn ngồi chơi với bé mỗi giờ ra chơi. Một tuần sau, bé ôm cổ bạn: "Con thương thầy."' : 'Bạn gọi xe, đưa ông về tận nhà, dặn hàng xóm trông giúp. Ông nắm tay bạn mãi không buông.'; } },
    { k: 'nghe_si', jobs: ['ca_si', 'dien_vien', 'vu_cong', 'rapper', 'dv_hai'], title: '"Xướng ca vô loài"',
      scene: 'Một người hàng xóm lớn tuổi nói với bố mẹ bạn: "Cho con đi hát hò, nhảy nhót làm gì, xướng ca vô loài, chẳng ra gì đâu."',
      who: 'cô giáo cũ', kind: 'Hôm sau, cô giáo dạy văn năm cấp ba nhắn cho bạn: "Cô xem clip em diễn rồi. Có những ngày cô mệt mỏi, nghe em hát lại thấy nhẹ lòng. Mang được niềm vui cho người khác là một nghề cao quý, em nhé."',
      quote: 'Mang được niềm vui cho người khác là một nghề cao quý', end: 'Bạn đọc tin nhắn mấy lần, chụp màn hình lưu lại.',
      fu: 'Bạn được mời diễn miễn phí cho các em nhỏ ở khoa ung bướu nhi.', fuDo: 'Nhận lời, diễn hết mình', fuDone: 'Bạn diễn hết mình trong căn phòng nhỏ. Một em bé đầu trọc cười khanh khách, đòi bạn diễn thêm một bài nữa.' },
    { k: 'mang', jobs: ['streamer', 'youtuber', 'kol_live', 'fl_aff'], title: '"Nghề ảo"',
      scene: 'Bữa cơm Tết, bác cả hỏi bạn làm gì. Nghe xong bác lắc đầu: "Ngồi nói trước cái điện thoại mà gọi là nghề à? Nghề ảo, mai mốt hết thời thì ăn gì?"',
      who: 'em họ', kind: 'Đứa em họ học lớp 9 kéo bạn ra sân: "Anh/chị đừng buồn. Em học được bao nhiêu thứ từ video của anh/chị. Bạn em cũng xem. Thế là thật mà."',
      quote: 'Em học được bao nhiêu thứ từ video của anh chị — thế là thật mà', end: 'Bạn xoa đầu đứa em. Tối ấy về, bạn lên ý tưởng cho video mới, hào hứng như ngày đầu.',
      fu: 'Một người xem nhắn riêng: video của bạn đã giúp họ qua những ngày khó khăn nhất.', fuDo: 'Làm một video tử tế cho những người như vậy', fuDone: 'Bạn làm một video về những ngày khó khăn và nơi có thể tìm sự giúp đỡ. Video ấy không nhiều lượt xem nhất, nhưng là video bạn tự hào nhất.' },
    { k: 'game', jobs: ['tuyen_thu_es', 'coach_es', 'caster_es', 'cay_thue'], title: '"Chơi game mà cũng gọi là nghề"',
      scene: 'Ra mắt nhà người yêu, bố người ấy hỏi nghề nghiệp. Nghe bạn nói xong, ông đặt đũa xuống: "Chơi game thì là chơi, sao gọi là nghề được?"',
      who: 'mẹ người ấy', kind: 'Lúc rửa bát, mẹ người ấy khẽ nói: "Bác thấy cháu tập luyện từ sáng đến đêm, thua thì xem lại từng ván. Nghề nào cũng vậy thôi, nghiêm túc với nó thì nó là nghề. Từ từ bác trai sẽ hiểu."',
      quote: 'Nghiêm túc với nó thì nó là nghề', end: 'Bạn cảm ơn bác, lòng nhẹ đi một nửa.',
      fu: 'Đội bạn vào chung kết, cả nhà người ấy ngồi xem trực tiếp.', fuDo: 'Thi đấu hết mình', fuDone: 'Bạn thi đấu hết mình. Tan trận, có tin nhắn từ bố người ấy: "Hay đấy. Lần sau bác đi xem trực tiếp."' },
    { k: 'nail', jobs: ['nail', 'tho_toc', 'barber', 'spa'], title: 'Lời ở tiệm',
      scene: 'Một vị khách sang trọng vừa làm móng vừa nói chuyện điện thoại: "Học hành không tới nơi thì mới đi làm nail, làm tóc thôi." Bạn vẫn cúi xuống làm, tay hơi run.',
      who: 'cô khách quen', kind: 'Cô khách quen ngồi ghế bên chờ đến lượt, nói nhỏ: "Cô làm bác sĩ ba chục năm, cô biết một đôi tay khéo phải luyện bao lâu. Ai làm người khác đẹp lên, tự tin lên, người đó làm nghề tử tế."',
      quote: 'Ai làm người khác đẹp lên, tự tin lên, người đó làm nghề tử tế', end: 'Bạn ngẩng lên cười với cô. Bộ móng hôm ấy là bộ đẹp nhất trong tuần.',
      fu: 'Một cô dâu nghèo đến tiệm, bẽn lẽn hỏi giá làm đẹp ngày cưới, đếm đi đếm lại xấp tiền ít ỏi.', fuDo: 'Làm đẹp cho cô dâu, chỉ lấy tiền vật liệu', fuDone: 'Bạn làm đẹp cho cô dâu, chỉ lấy tiền vật liệu. Hôm cưới, cô gửi ảnh: "Chị ơi, em chưa bao giờ thấy mình đẹp như thế."' },
    { k: 'bar', jobs: ['bartender', 'dj'], title: '"Làm quán bar thì hư hỏng"',
      scene: 'Hàng xóm xì xào với mẹ bạn: "Con bà đi làm đêm ở quán bar à? Môi trường đó thì kiểu gì chẳng hư."',
      who: 'mẹ', kind: function (l) { return (l.fam && l.fam.mAlive ? 'Mẹ' : 'Bố') + ' về nhà, nấu cho bạn bát mì lúc nửa đêm: "Mẹ không cần biết người ta nói gì. Mẹ biết con mẹ đi làm đêm về vẫn nhắn hỏi mẹ ngủ chưa. Thế là đủ."'; },
      quote: 'Mẹ biết con mẹ đi làm đêm về vẫn nhắn hỏi mẹ ngủ chưa. Thế là đủ', end: 'Bạn ăn hết bát mì, chẳng nói được câu nào.',
      fu: 'Một vị khách say mèm định tự lái xe về.', fuDo: 'Giữ chìa khóa, gọi xe đưa khách về', fuDone: 'Bạn giữ chìa khóa, gọi xe đưa khách về tận nhà. Hôm sau ông quay lại cảm ơn: "Tối qua cậu/cô đã cứu một gia đình đấy."' },
    { k: 'giup_viec', jobs: ['giup_viec'], title: '"Đồ ô-sin"',
      scene: 'Đứa con nhà chủ cãi nhau với bạn bè, buột miệng chỉ bạn: "Ô-sin nhà tao thì biết gì!" Bạn lặng lẽ dọn bàn ăn.',
      who: 'bà chủ nhà', kind: 'Tối ấy bà chủ nhà gọi đứa con ra xin lỗi bạn, rồi nói với bạn: "Chị lo cho cả nhà này như người nhà. Không có chị, nhà này không thành nếp được đâu."',
      quote: 'Không có chị, nhà này không thành nếp được', end: 'Đứa trẻ lí nhí xin lỗi. Bạn xoa đầu nó, bỏ qua.',
      fu: 'Đứa trẻ nhà chủ năm nào giờ đã lớn, đỗ đại học, về thăm.', fuDo: 'Nấu món nó thích nhất', fuDone: 'Bạn nấu món nó thích nhất. Nó ôm bạn: "Hồi đó con dại. Cảm ơn cô đã thương con như con ruột."' },
    { k: 'nong', jobs: ['nong'], title: '"Học không tới nơi mới về làm ruộng"',
      scene: 'Ngày họp lớp, một người bạn cũ cười: "Học xong lại về cuốc đất à? Phí cả mấy năm đi học."',
      who: 'cô bán hàng ngoài chợ', kind: 'Mấy hôm sau mang rau ra chợ, cô bán hàng quen dúi thêm tiền: "Rau nhà cháu sạch, khách cô hỏi mãi. Không có người trồng lúa, trồng rau thì ai cũng đói. Cháu cứ ngẩng đầu mà sống."',
      quote: 'Không có người trồng lúa, trồng rau thì ai cũng đói', end: 'Bạn cười, gánh rau về, thấy nắng chiều hôm ấy đẹp lạ.',
      fu: 'Mùa lũ, làng bên mất trắng, bà con kêu gọi gạo, rau cho vùng lũ.', fuDo: 'Gom gạo, rau nhà trồng gửi đi', fuDone: 'Bạn gom mấy bao gạo, mấy sọt rau nhà trồng gửi lên xe cứu trợ. Lần đầu bạn thấy những luống rau của mình nuôi được cả người dưng.' },
    { k: 'cong_nhan', jobs: ['cong_nhan', 'tho_han', 'tho_mo'], title: '"Làm công nhân thì cả đời khổ"',
      scene: 'Về quê, một người họ hàng xa so bì: "Con nhà tôi làm văn phòng, ngồi máy lạnh. Đi làm công nhân thì cả đời khổ thôi."',
      who: 'bố', kind: function (l) { return (l.fam && l.fam.fAlive ? 'Bố' : 'Mẹ') + ' rót cho bạn chén rượu, nói nhỏ: "Cái áo con mặc, cái điện thoại người ta cầm, cái gì chẳng do người như con làm ra. Bố tự hào về con."'; },
      quote: 'Cái gì người ta dùng chẳng do người như con làm ra', end: 'Bạn cạn chén rượu, mắt cay cay.',
      fu: 'Trong ca làm, một công nhân mới vào bị máy kẹp tay, cả chuyền hoảng loạn.', fuDo: 'Ngắt máy, sơ cứu, đưa đi viện', fuDone: 'Bạn ngắt máy kịp thời, sơ cứu rồi đưa người ấy đi viện. Bàn tay giữ lại được. Cả chuyền gọi bạn là "anh cả / chị cả".' }
  ];
  function stgVal(l, S, f) { return S.jobs.indexOf(job(l)) >= 0 && (!S.cond || S.cond(l)) && f(l); }
  function val(x, l) { return typeof x === 'function' ? x(l) : x; }
  E.STIGMA = STG.map(function (S) { return S.k; });
  STG.forEach(function (S) {
    var id = 'dk_' + S.k, fid = id + '_nho';
    SC(id, {
      title: S.title, valid: function (l) { return stgVal(l, S, function () { return !(l.flags.dk || {})[S.k]; }); },
      text: function (l) { return val(S.scene, l) + ' ' + val(S.kind, l); },
      opts: [
        { k: 'tam_su', l: function (l) { return 'Ngồi lại tâm sự với ' + val(S.who, l); }, ai: { w: 1.1, soc: 1 }, run: function (l, r, log) { (l.flags.dk = l.flags.dk || {})[S.k] = { c: 'tam_su', a: l.age }; log('Bạn ngồi lại kể cho ' + val(S.who, l) + ' nghe về nghề của mình, những vất vả chẳng ai thấy. ' + S.end, 'good'); stress(l, -10); fx(l, { hap: 5, soc: 2 }); H.mem(l, 'Lời ' + val(S.who, l) + ' năm ấy: "' + S.quote + '."', 5); } },
        { k: 'tu_tin', l: 'Cảm ơn, và tự tin với nghề của mình', ai: { w: 1.2 }, run: function (l, r, log) { (l.flags.dk = l.flags.dk || {})[S.k] = { c: 'tu_tin', a: l.age }; log('Bạn cảm ơn ' + val(S.who, l) + '. ' + S.end, 'good'); stress(l, -6); fx(l, { hap: 6, karma: 2 }); l.flags.jobPride = (l.flags.jobPride || 0) + 1; H.mem(l, 'Lời ' + val(S.who, l) + ' năm ấy: "' + S.quote + '."', 4); } },
        { k: 'buon', l: 'Cảm ơn, nhưng vẫn giữ nỗi buồn trong lòng', ai: { w: 0.6 }, run: function (l, r, log) { (l.flags.dk = l.flags.dk || {})[S.k] = { c: 'buon', a: l.age }; log('Bạn gật đầu cảm ơn, nhưng câu nói lúc trước cứ văng vẳng mãi. Tối về nằm nghĩ, vẫn thấy chạnh lòng.', 'neutral'); stress(l, 5); fx(l, { hap: -2 }); } }
      ]
    });
    T(id, function (l) { return stgVal(l, S, function () { return !(l.flags.dk || {})[S.k] && l.job.yrs >= 1; }); }, 0.12, 4, 1);
    SC(fid, {
      title: function (l) { return 'Nghề ' + E.jobTitle(l); }, valid: function (l) { return stgVal(l, S, function () { var x = (l.flags.dk || {})[S.k]; return !!x && !x.fu && l.age - x.a >= 2; }); },
      text: function (l) { var x = l.flags.dk[S.k]; return val(S.fu, l) + (x.c === 'buon' ? ' Bạn chợt nhớ những ánh nhìn dè bỉu năm nào, rồi lại tự hỏi: mình làm nghề này để làm gì?' : ' Bạn chợt nhớ lời ' + val(S.who, l) + ' năm nào: "' + S.quote + '."'); },
      opts: [
        { k: 'lam', l: S.fuDo, ai: { w: 1.4 }, run: function (l, r, log) { var x = l.flags.dk[S.k]; x.fu = l.age; log(val(S.fuDone, l) + (x.c === 'buon' ? ' Khoảnh khắc ấy, nỗi buồn năm nào bỗng nhẹ đi — bạn hiểu ra giá trị của nghề mình.' : ' Lời ' + val(S.who, l) + ' năm nào lại vang lên trong đầu, và bạn mỉm cười.'), 'good'); fx(l, { hap: 8, karma: 5 }); stress(l, -8); H.mem(l, U.cap(val(S.fuDone, l)), 5); } },
        { k: 'thoi', l: 'Làm theo đúng quy trình, như mọi ngày', ai: { w: 0.5 }, run: function (l, r, log) { l.flags.dk[S.k].fu = l.age; log('Bạn làm đúng phần việc của mình, như mọi ngày.', 'neutral'); } }
      ]
    });
    T(fid, function (l) { return stgVal(l, S, function () { var x = (l.flags.dk || {})[S.k]; return !!x && !x.fu && l.age - x.a >= 2; }); }, 0.2, 4, 1);
  });
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
/* ===== js/life45.js ===== */
/* Một Đời — v4.4 (góp ý của người chơi):
   · nghề tự do, tự kinh doanh không có chuyện "thăng chức" — chỉ có tay nghề, uy tín, quy mô
   · mua trả góp: kỳ hạn, lãi suất, số tiền mỗi năm / mỗi tháng, tổng phải trả ghi rõ khi chọn; mỗi năm trừ tiền góp và ghi vào nhật ký
   · xưng hô đúng giới tính, đúng vai (phù rể / phù dâu, anh / em)
   · cho con tiền: hỏi ý kiến thay vì tự động, không hỏi trùng với "con xin vốn"
   · hệ quả các mối quan hệ: ly hôn (quyền nuôi con, cấp dưỡng, con buồn), bố mẹ mất khi còn nhỏ (gà trống nuôi con, ở với ông bà),
     ngày giỗ, bố / mẹ già ở một mình, đi bước nữa; góa bụa
   · hồi tưởng cuối đời luôn có người bạn đời (còn sống hay đã mất) */
(function (G) {
  'use strict';
  var U = G.U, E = G.E, H = E.H, SC = E.SC, isVN = H.isVN;
  function fx(l, o) { H.fx(l, o); }
  function mo(l, v) { return H.money(l, v); }
  function pick(r, a) { return U.pick(r, a); }
  function ch(r, p) { return r() < p; }
  function inJail(l) { return l.jailUntil != null && l.age < l.jailUntil; }
  function free(l) { return !inJail(l) && !(l.abroad && l.abroad.trapped) && !(l.flags.military && l.age < l.flags.military); }
  function vnd(l) { return isVN(l) && l.cur === 'vnd' && !(l.abroad && l.abroad.perm); }
  function V(l, tr) { return vnd(l) ? tr : tr / 90 * l.base; }
  function T(id, when, p, cd, max) { E.TRIG.push({ id: id, when: function (l, a) { return free(l) && when(l, a); }, p: p, cd: cd || 4, max: max || 1 }); }
  function stress(l, x) { if (l.mind) l.mind.stress = U.clamp(l.mind.stress + x, 0, 100); }
  function minors(l) { return (l.kids || []).filter(function (k) { return k.alive && l.age - k.born < 18; }); }

  // ===================================================================
  // 1. XƯNG HÔ
  // ===================================================================
  // người bạn đời p nói với nhân vật l: p tự xưng là gì (me), gọi l là gì (you)
  E.xung = function (l, p) {
    p = p || l.partner || {}; var ps = p.sex || (l.sex === 'M' ? 'F' : 'M');
    if (ps !== l.sex) return ps === 'M' ? { me: 'anh', you: 'em' } : { me: 'em', you: 'anh' };
    var older = (p.age || l.age) >= l.age; return older ? { me: ps === 'M' ? 'anh' : 'chị', you: 'em' } : { me: 'em', you: l.sex === 'M' ? 'anh' : 'chị' };
  };
  E.weddingRole = function (l) { return l.sex === 'M' ? 'phù rể' : 'phù dâu'; };

  // ===================================================================
  // 2. THĂNG TIẾN: ĐÚNG VỚI ĐẶC THÙ TỪNG NGHỀ
  // ===================================================================
  var SELF = /^(fl_|hoa_si|tho_xam|nhiep_anh|makeup|stylist|mc_su_kien|dj|cay_thue|gia_su|pt_gym|nhac_si|bien_kich|dao_dien|tx_cn|ve_chai|ban_rong|ngu_dan|nong|sau_rieng|nuoi_tom|tham_tu|xe_om|streamer|youtuber|kol_live|caster_es)/;
  function kind(l, c, prev, now) {
    if (/^(chủ|giám đốc công ty|chủ tịch)/.test(now) && !/^(chủ|giám đốc|chủ tịch)/.test(prev)) return 'open';
    if (/^(chủ|giám đốc công ty|chủ tịch)/.test(prev) && c.id !== 'tai_phiet') return 'grow';
    if (c.cat === 'free' || SELF.test(c.id)) return 'self';
    if (c.cat === 'worker' || c.cat === 'beauty') return 'skill';
    return 'promo';
  }
  E.rankKind = function (l) { var c = E.CAR[E.resolveJob(l.job.id)], rk = l.job.rank; return kind(l, c, c.t[Math.max(0, rk - 1)], c.t[rk]); };
  E.rankUpText = function (l, c) {
    var rk = l.job.rank, now = E.jobTitle ? E.jobTitle(l) : c.t[rk], prev = c.t[Math.max(0, rk - 1)], k = kind(l, c, prev, c.t[rk]);
    if (c.id === 'tx_cn') return { t: 'Dành dụm mua được ô tô, chuyển sang chạy ' + now + '.', m: 'Ngày lái chiếc ô tô của mình đi đón vị khách đầu tiên.' };
    if (k === 'open') return { t: 'Tích cóp đủ vốn và kinh nghiệm, bạn mở cơ sở riêng — giờ là ' + now + '.', m: 'Ngày khai trương cơ sở của riêng mình.' };
    if (k === 'grow') return { t: 'Làm ăn phát đạt, mở rộng quy mô — giờ là ' + now + '.', m: 'Ngày cơ ngơi của bạn lớn thành ' + now + '.' };
    if (k === 'self') return { t: 'Làm tự do không có ai "thăng chức" cho mình — nhưng tay nghề, uy tín lên dần, khách tìm đến đông hơn, nhận được việc lớn hơn: giờ bạn là ' + now + '.', m: 'Năm khách hàng bắt đầu tìm đến tận nơi, gọi bạn là ' + now + '.' };
    if (k === 'skill') return { t: 'Lên tay nghề, được giao làm việc chính — giờ là ' + now + '.', m: 'Ngày trở thành ' + now + '.' };
    return { t: 'Được thăng chức: ' + now + '.', m: 'Ngày nhận quyết định bổ nhiệm ' + c.t[rk] + '.' };
  };

  // ===================================================================
  // 3. TRẢ GÓP CÓ KỲ HẠN, GHI RÕ
  // ===================================================================
  var PLAN = { car: { n: 5, rate: 0.1, who: 'ngân hàng' }, fin: { n: 2, rate: 0.3, who: 'công ty tài chính' } };
  function annuity(P, r, n) { return r > 0 ? P * r / (1 - Math.pow(1 + r, -n)) : P / n; }
  E.loanPlan = function (l, price, type, down) {
    var Pn = PLAN[type]; if (!Pn) return ''; down = down == null ? 0.3 : down;
    var Y = price * (1 - down), pay = annuity(Y, Pn.rate, Pn.n), tot = pay * Pn.n;
    return 'Trả trước ' + mo(l, price * down) + ' (' + Math.round(down * 100) + '%), vay ' + Pn.who + ' ' + mo(l, Y) + ' · lãi ' + Math.round(Pn.rate * 100) + '%/năm · góp ' + Pn.n + ' năm, mỗi năm ' + mo(l, pay) + ' (khoảng ' + mo(l, pay / 12) + '/tháng) · tổng phải trả ' + mo(l, tot) + ', tiền lãi ' + mo(l, tot - Y);
  };
  var al0 = H.addLoan;
  H.addLoan = function (l, type, amt) {
    var n0 = (l.loans || []).length, x = al0.apply(this, arguments), L = (l.loans || [])[n0];
    if (L && PLAN[type]) { var Pn = PLAN[type]; L.rate = Pn.rate; L.term = Pn.n; L.pay = annuity(L.bal, Pn.rate, Pn.n); L.veh = true; }
    return x;
  };
  E.loanWhat = function (l, L) { return L.what || (L.veh ? (l.vehName || l.veh || 'xe') : L.name); };

  // ===================================================================
  // 4. CHO CON TIỀN: HỎI Ý KIẾN, KHÔNG TRÙNG
  // ===================================================================
  E.HOOKS.year.forEach(function (h, i) { if (/giftAt/.test(h.toString()) && /mua nhà/.test(h.toString())) E.HOOKS.year[i] = function () { }; });
  function giftable(l, a) { return (l.kids || []).filter(function (k) { return k.alive && a - k.born >= 22 && !(k.gotAt != null && a - k.gotAt < 8); }); }
  SC('cho_con_tien', {
    title: 'Giúp con một khoản', valid: function (l) { return giftable(l, l.age).length > 0 && l.money > l.base * 10; },
    prep: function (l, r) { var k = pick(r, giftable(l, l.age)); return { n: k.name, w: pick(r, ['mua nhà', 'làm vốn kinh doanh', 'lo cho các cháu ăn học', 'trả nợ ngân hàng']), x: l.money * (0.12 + r() * 0.1) }; },
    text: function (l, d) { return 'Con ' + d.n + ' đang cần tiền ' + d.w + '. Bạn đang có ' + mo(l, l.money) + ' tiền tích lũy. Có giúp con không?'; },
    opts: [
      { k: 'cho', l: function (l, d) { return 'Cho con ' + mo(l, d.x) + ' — "bố mẹ còn khỏe, giúp được gì thì giúp"'; }, ai: { w: 1, soc: 0.5 }, run: function (l, r, log, d) { var k = l.kids.filter(function (c) { return c.name === d.n; })[0]; if (!k) return; var x = Math.min(d.x, Math.max(0, l.money)); H.cash(l, -x, 'Cho con ' + d.n); k.gotAt = l.age; k.askedVon = true; k.close = Math.min(100, (k.close || 50) + 8); log('Cho con ' + d.n + ' ' + mo(l, x) + ' ' + d.w + '.', 'good'); fx(l, { hap: 4, karma: 2 }); } },
      { k: 'muon', l: function (l, d) { return 'Cho con mượn ' + mo(l, d.x / 2) + ', con trả dần'; }, ai: { w: 0.8, smart: 0.6 }, run: function (l, r, log, d) { var k = l.kids.filter(function (c) { return c.name === d.n; })[0]; if (!k) return; var x = Math.min(d.x / 2, Math.max(0, l.money)); H.cash(l, -x, 'Cho con ' + d.n + ' mượn'); k.gotAt = l.age; k.askedVon = true; k.owe = (k.owe || 0) + x; log('Cho con ' + d.n + ' mượn ' + mo(l, x) + ' ' + d.w + ', hẹn trả dần.', 'neutral'); } },
      { k: 'khong', l: 'Giữ lại tiền dưỡng già', ai: { w: 0.6 }, run: function (l, r, log, d) { var k = l.kids.filter(function (c) { return c.name === d.n; })[0]; if (k) { k.gotAt = l.age; k.close = Math.max(0, (k.close || 50) - 3); } log('Bảo con tự xoay xở, giữ lại tiền dưỡng già.', 'neutral'); } }
    ]
  });
  T('cho_con_tien', function (l, a) { return a >= 52 && l.indep && l.money > l.base * 15 && giftable(l, a).length > 0; }, 0.3, 4, 3);
  if (E.DEC.con_xin_von) {
    var cv = E.DEC.con_xin_von, cvv = cv.valid, cvm = cv.make;
    cv.valid = function (l, d) { var ok = cvv.apply(this, arguments); if (!ok) return false; var k = d && d.n ? l.kids.filter(function (c) { return c.name === d.n; })[0] : null; return !(k && k.gotAt != null && l.age - k.gotAt < 8); };
    cv.make = function (l, r, a) { l.kids.forEach(function (k) { if (k.gotAt != null && l.age - k.gotAt < 8) k.askedVon = true; }); return cvm.apply(this, arguments); };
    var cva = cv.apply; cv.apply = function (l, d) { var x = cva.apply(this, arguments); var k = d.data && d.data.n ? l.kids.filter(function (c) { return c.name === d.data.n; })[0] : null; if (k) k.gotAt = l.age; return x; };
  }
  // con trả dần tiền đã mượn
  E.HOOKS.year.push(function (l, r, log, a) { (l.kids || []).forEach(function (k) { if (!(k.owe > 0) || !k.alive) return; var p = Math.min(k.owe, Math.max(l.base * 0.3, k.owe * 0.25)); if (ch(r, 0.8)) { k.owe -= p; H.cash(l, p, 'Con ' + k.name + ' trả nợ'); if (k.owe < 0.5) { k.owe = 0; log('Con ' + k.name + ' đã trả hết khoản mượn năm nào.', 'good'); } } }); });

  // ===================================================================
  // 5. HỆ QUẢ CÁC MỐI QUAN HỆ
  // ===================================================================
  SC('quyen_nuoi_con', {
    title: 'Quyền nuôi con', valid: function (l) { return minors(l).length > 0 && !!l.flags.divEx; },
    text: function (l) { var ks = minors(l); return 'Ly hôn với ' + l.flags.divEx + ', còn ' + (ks.length === 1 ? 'con ' + ks[0].name + ' mới ' + (l.age - ks[0].born) + ' tuổi' : ks.length + ' đứa con nhỏ') + '. Ai sẽ nuôi con?'; },
    opts: [
      { k: 'nuoi', l: 'Giành quyền nuôi con', h: 'Một mình nuôi con, vất vả hơn', ai: { w: 1.1 }, run: function (l, r, log) { minors(l).forEach(function (k) { k.custody = 'me'; }); l.flags.single = l.age; log('Tòa giao con cho bạn nuôi. Từ nay một mình vừa đi làm vừa đưa đón con.', 'neutral'); stress(l, 8); } },
      { k: 'ex', l: 'Để con ở với người kia, bạn cấp dưỡng hằng tháng', h: function (l) { return 'Cấp dưỡng khoảng ' + mo(l, V(l, 3)) + '/tháng mỗi con đến năm 18 tuổi'; }, ai: { w: 0.8 }, run: function (l, r, log) { minors(l).forEach(function (k) { k.custody = 'ex'; k.close = Math.max(0, (k.close || 60) - 10); }); log('Con ở với ' + l.flags.divEx + '. Bạn cấp dưỡng hằng tháng, cuối tuần đón con đi chơi.', 'neutral'); fx(l, { hap: -6 }); } },
      { k: 'chung', l: 'Thỏa thuận cùng nuôi, con đi lại hai nhà', ai: { w: 1, soc: 1 }, run: function (l, r, log) { minors(l).forEach(function (k) { k.custody = 'both'; k.close = Math.max(0, (k.close || 60) - 4); }); log('Hai người thỏa thuận cùng nuôi con: tuần này ở nhà bố, tuần sau ở nhà mẹ. Không còn là vợ chồng nhưng vẫn là bố mẹ của con.', 'neutral'); } }
    ]
  });
  SC('con_sau_ly_hon', {
    title: 'Con sau ngày bố mẹ chia tay', valid: function (l) { return minors(l).some(function (k) { return k.custody; }); },
    prep: function (l, r) { var k = pick(r, minors(l).filter(function (k) { return k.custody; })); return { n: k.name }; },
    text: function (l, d) { return 'Từ ngày bố mẹ chia tay, ' + d.n + ' ít nói hẳn, kết quả học tập đi xuống. Cô giáo nhắn: "Dạo này cháu hay ngồi một mình."'; },
    opts: [
      { k: 'noi', l: 'Ngồi xuống nói chuyện, nói rằng bố mẹ vẫn thương con', ai: { w: 1.3, soc: 1 }, run: function (l, r, log, d) { var k = l.kids.filter(function (c) { return c.name === d.n; })[0]; if (k) k.close = Math.min(100, (k.close || 50) + 8); log('Ôm con, nói rằng chuyện người lớn không phải lỗi của con, bố mẹ vẫn thương con như ngày nào. ' + d.n + ' khóc rồi ngủ thiếp đi trong lòng bạn.', 'good'); fx(l, { hap: 2 }); } },
      { k: 'cung_ex', l: 'Hẹn người cũ cùng đưa con đi chơi một buổi', ai: { w: 0.8 }, run: function (l, r, log, d) { var k = l.kids.filter(function (c) { return c.name === d.n; })[0]; if (k) { k.close = Math.min(100, (k.close || 50) + 5); k.study = Math.min(100, (k.study || 50) + 3); } log('Bố mẹ cùng đưa ' + d.n + ' đi công viên. Con cười cả buổi.', 'good'); } },
      { k: 'ban', l: 'Bận quá, để con tự quen dần', ai: { w: 0.4 }, run: function (l, r, log, d) { var k = l.kids.filter(function (c) { return c.name === d.n; })[0]; if (k) { k.close = Math.max(0, (k.close || 50) - 8); k.study = Math.max(0, (k.study || 50) - 5); } log(d.n + ' dần thu mình lại.', 'bad'); } }
    ]
  });
  T('con_sau_ly_hon', function (l, a) { return l.flags.divAt != null && a - l.flags.divAt <= 3 && minors(l).some(function (k) { return k.custody; }); }, 0.4, 4, 1);
  SC('bo_me_mot_minh', {
    title: function (l) { return (l.fam.fAlive ? 'Bố' : 'Mẹ') + ' ở một mình'; }, valid: function (l) { return (l.fam.fAlive !== l.fam.mAlive) && l.indep && !l.flags.caring; },
    text: function (l) { var p = l.fam.fAlive ? 'bố' : 'mẹ', o = l.fam.fAlive ? 'mẹ' : 'bố'; return 'Từ ngày ' + o + ' mất, ' + p + ' ở một mình trong căn nhà cũ. Hàng xóm gọi điện báo ' + p + ' ăn uống thất thường, tối nào cũng ngồi một mình trước bàn thờ.'; },
    opts: [
      { k: 'don', l: function (l) { return 'Đón ' + (l.fam.fAlive ? 'bố' : 'mẹ') + ' về ở cùng'; }, ai: { w: 1, soc: 1 }, run: function (l, r, log) { l.flags.caring = true; log('Đón ' + (l.fam.fAlive ? 'bố' : 'mẹ') + ' về ở cùng. Bữa cơm nhà mình có thêm một người, ' + (l.fam.fAlive ? 'bố' : 'mẹ') + ' vui hẳn lên.', 'good'); fx(l, { hap: 3, karma: 4 }); } },
      { k: 'tham', l: 'Thu xếp về thăm thường xuyên hơn', ai: { w: 1.1 }, run: function (l, r, log) { H.cash(l, -V(l, 4), 'Về thăm ' + (l.fam.fAlive ? 'bố' : 'mẹ')); log('Cuối tuần nào cũng về thăm, gọi video mỗi tối.', 'good'); fx(l, { karma: 2 }); } },
      { k: 'ban', l: 'Bận quá, gửi tiền nhờ người trông giúp', ai: { w: 0.5 }, run: function (l, r, log) { H.cash(l, -V(l, 30), 'Thuê người chăm ' + (l.fam.fAlive ? 'bố' : 'mẹ')); log('Gửi tiền thuê người trông nom. ' + U.cap(l.fam.fAlive ? 'bố' : 'mẹ') + ' không trách, chỉ hỏi "bao giờ con về?"', 'neutral'); fx(l, { hap: -2 }); } }
    ]
  });
  T('bo_me_mot_minh', function (l, a) { return a >= 22 && l.flags.parentLostAt != null && a - l.flags.parentLostAt <= 6 && (l.fam.fAlive !== l.fam.mAlive) && l.indep && !l.flags.caring; }, 0.2, 4, 1);
  SC('di_buoc_nua', {
    title: function (l) { return (l.fam.fAlive ? 'Bố' : 'Mẹ') + ' muốn đi bước nữa'; }, valid: function (l) { return l.fam.fAlive !== l.fam.mAlive; },
    text: function (l) { var p = l.fam.fAlive ? 'bố' : 'mẹ'; return 'Mấy năm sau ngày ' + (l.fam.fAlive ? 'mẹ' : 'bố') + ' mất, ' + p + ' ngập ngừng nói muốn tìm một người bạn già để có đôi có bạn lúc tuổi xế chiều.'; },
    opts: [
      { k: 'ung_ho', l: 'Ủng hộ', ai: { w: 1.1, soc: 1 }, run: function (l, r, log) { var p = l.fam.fAlive ? 'bố' : 'mẹ'; log('Bạn nắm tay ' + p + ': "Miễn ' + p + ' vui là con vui." Đám cưới nhỏ chỉ có người nhà.', 'good'); fx(l, { hap: 2 }); l.flags.stepParent = true; } },
      { k: 'phan_doi', l: 'Phản đối, chưa chấp nhận được', ai: { w: 0.5 }, run: function (l, r, log) { var p = l.fam.fAlive ? 'bố' : 'mẹ'; log('Bạn phản đối. ' + U.cap(p) + ' không nói gì, từ đó ít khi nhắc lại.', 'bad'); fx(l, { hap: -3 }); } }
    ]
  });
  T('di_buoc_nua', function (l, a) { return l.flags.parentLostAt != null && a - l.flags.parentLostAt >= 2 && a - l.flags.parentLostAt <= 8 && (l.fam.fAlive !== l.fam.mAlive) && ((l.fam.fAlive ? l.fam.fAge : l.fam.mAge) + a) <= 72; }, 0.12, 4, 1);
  SC('goa_bua', {
    title: 'Những ngày một mình', valid: function (l) { return l.flags.widowAt != null && !l.partner; },
    text: function (l) { return 'Từ ngày ' + (l.flags.lateSpouse || 'người ấy') + ' mất, căn nhà rộng thênh thang. Bạn vẫn quen tay dọn hai cái bát mỗi bữa cơm.'; },
    opts: [
      { k: 'con', l: 'Dọn về ở với con cháu', req: function (l) { return (l.kids || []).some(function (k) { return k.alive && l.age - k.born >= 22; }); }, ai: { w: 1 }, run: function (l, r, log) { log('Dọn về ở với con cháu. Tiếng trẻ con ríu rít làm nỗi buồn vơi đi.', 'good'); fx(l, { hap: 6 }); stress(l, -10); } },
      { k: 'ban', l: 'Đi sinh hoạt câu lạc bộ, gặp gỡ bạn bè', ai: { w: 1, soc: 1 }, run: function (l, r, log) { log('Tham gia câu lạc bộ dưỡng sinh, đi chùa / nhà thờ, gặp gỡ bạn cũ. Nỗi nhớ vẫn còn, nhưng không còn cô quạnh.', 'good'); fx(l, { hap: 5, soc: 4 }); stress(l, -8); } },
      { k: 'mot_minh', l: 'Ở một mình với những kỷ niệm', ai: { w: 0.6 }, run: function (l, r, log) { log('Ở một mình, ngày ngày lau di ảnh ' + (l.flags.lateSpouse || 'người ấy') + '.', 'neutral'); stress(l, 5); fx(l, { hap: -3 }); } }
    ]
  });
  T('goa_bua', function (l, a) { return l.flags.widowAt != null && a - l.flags.widowAt <= 2 && !l.partner; }, 0.5, 4, 1);
  // theo dõi thay đổi các mối quan hệ mỗi năm
  E.HOOKS.year.push(function (l, r, log, a) {
    if (!l.alive) return;
    var F = l.flags, P = F.relPrev || {}, f = l.fam;
    // ly hôn
    if (P.st && P.st !== 'dating' && (l.exes || 0) > (P.ex || 0) && (!l.partner || l.partner.name !== P.n)) { F.divAt = a; F.divEx = P.n; stress(l, 10); if (minors(l).length && E.DEC.quyen_nuoi_con) l.pending.push(E.DEC.quyen_nuoi_con.make(l, r)); }
    // góa
    if (P.st && P.st !== 'dating' && (l.widowed || 0) > (P.wid || 0)) { F.widowAt = a; F.lateSpouse = P.n; (F.spouses = F.spouses || []).indexOf(P.n) < 0 && F.spouses.push(P.n); stress(l, 15); }
    // bố mẹ mất
    if ((P.m && !f.mAlive) || (P.f && !f.fAlive)) {
      F.parentLostAt = a;
      if (a < 18) {
        if (!f.mAlive && !f.fAlive) { F.orphanAt = a; F.orphanCarer = pick(r, ['ông bà', 'bà nội', 'bà ngoại', 'cô ruột', 'dì ruột']); log('Mồ côi cả bố lẫn mẹ, bạn về ở với ' + F.orphanCarer + '. Từ đây phải tự lớn lên sớm hơn chúng bạn.', 'bad'); stress(l, 20); if (f.q > 1) f.q--; }
        else F.singleParent = f.fAlive ? 'bố' : 'mẹ';
      }
    }
    if (l.partner && l.partner.status !== 'dating') { F.spouses = F.spouses || []; if (F.spouses.indexOf(l.partner.name) < 0) F.spouses.push(l.partner.name); }
    F.relPrev = { n: l.partner && l.partner.name, st: l.partner && l.partner.status, ex: l.exes || 0, wid: l.widowed || 0, m: !!f.mAlive, f: !!f.fAlive };
    // cấp dưỡng nuôi con
    var pay = minors(l).filter(function (k) { return k.custody === 'ex'; }).length;
    if (pay && l.indep && !inJail(l)) H.cash(l, -V(l, 36) * pay, 'Cấp dưỡng nuôi con');
    if (F.divAt != null && a - F.divAt <= 2 && a > F.divAt) stress(l, 4);
  });
  // gà trống nuôi con / mẹ đơn thân
  E.EVENTS.push({ c: function (l, a) { return !!l.flags.singleParent && a < 18 && a - (l.flags.parentLostAt || 0) >= 1 && (l.flags.singleParent === 'bố' ? l.fam.fAlive : l.fam.mAlive); }, p: 0.35, cd: 3, run: function (l, a, r, log) {
    var p = l.flags.singleParent;
    log(p === 'bố' ? pick(r, ['Từ ngày mẹ mất, bố gà trống nuôi con: sáng nấu cơm, tối kèm bài, có hôm ngủ gục bên bàn.', 'Bố vụng về tết tóc cho bạn đi học, tóc lệch một bên mà bạn vẫn thương.', 'Họp phụ huynh, bố là ông bố duy nhất ngồi giữa các bà mẹ.']) : pick(r, ['Từ ngày bố mất, mẹ làm thêm ca đêm để nuôi con ăn học.', 'Mẹ một mình gánh vác cả nhà, có những đêm bạn thấy mẹ ngồi khóc một mình.', 'Tết đến, mẹ vẫn sắm đủ mâm cỗ, đặt thêm một đôi đũa cho bố.']), 'neutral');
    H.fx(l, { hap: -1 }); if (ch(r, 0.3)) H.fx(l, { kno: -1 });
  } });
  // ngày giỗ
  E.EVENTS.push({ c: function (l, a) { return isVN(l) && !l.abroad && a >= 12 && l.flags.parentLostAt != null && a - l.flags.parentLostAt >= 1 && (!l.fam.mAlive || !l.fam.fAlive); }, p: 0.08, cd: 6, run: function (l, a, r, log) {
    var w = !l.fam.mAlive && !l.fam.fAlive ? pick(r, ['bố', 'mẹ']) : !l.fam.mAlive ? 'mẹ' : 'bố';
    log(pick(r, ['Ngày giỗ ' + w + ', anh em họ hàng về đông đủ, thắp nén hương mà nhớ ' + w + ' quay quắt.', 'Đến ngày giỗ ' + w + ', bạn nấu lại món ' + w + ' thích nhất, đặt lên bàn thờ.', 'Giỗ ' + w + ' năm nay, bạn ngồi kể cho các con nghe về ' + w + ' ngày xưa.']), 'neutral');
  } });

  // người đang dư dả (vừa trúng số, có của ăn của để) thì không ham 'việc nhẹ lương cao'
  if (E.DEC.viec_nhe) { var vn0 = E.DEC.viec_nhe.valid; E.DEC.viec_nhe.valid = function (l) { if (l.money > l.base * 3 || (l.flags.lottoWin && l.flags.lottoWin.amt > l.base)) return false; return vn0 ? vn0.apply(this, arguments) : true; }; }

  // ===================================================================
  // 6. HỒI TƯỞNG CUỐI ĐỜI CÓ NGƯỜI BẠN ĐỜI
  // ===================================================================
  E.spousesOf = function (l) { var s = (l.flags && l.flags.spouses || []).slice(); if (l.partner && l.partner.status !== 'dating' && s.indexOf(l.partner.name) < 0) s.push(l.partner.name); return s; };
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
/* ===== js/life46.js ===== */
/* Một Đời — v4.5 (góp ý của người chơi):
   · chức vụ cao nhất / gần cao nhất (tổng giám đốc, chủ tịch, cơ trưởng…), chủ cơ sở, làm tự do không bị "sếp" ép
   · trong tù: chỉ có chuyện trong trại (3–4 chuyện mỗi năm), án tính trọn năm; không thi bằng lái, hẹn hò, mua nhà trong tù
   · buôn lậu, ma túy có đường dây, lên cấp dần, ông trùm ít bị bắt; thu nhập theo cấp
   · chủ động mở thêm chi nhánh / mở rộng quy mô khi có tiền
   · năng khiếu game chỉ là thể loại (MOBA / FPS), người chơi tự chọn game
   · chọn concert: chọn nhóm rồi chọn nghệ sĩ
   · lời kể về gia đình đúng hoàn cảnh (không con cháu, không anh chị em, cả nhà đã mất…)
   · giới hạn tuổi một số hoạt động (tập gym…) */
(function (G) {
  'use strict';
  var U = G.U, E = G.E, H = E.H, SC = E.SC, isVN = H.isVN;
  function A(id, g, label, o) { var x = { id: id, g: g, l: label }; for (var k in o) x[k] = o[k]; E.ACT.push(x); }
  function fx(l, o) { H.fx(l, o); }
  function mo(l, v) { return H.money(l, v); }
  function pick(r, a) { return U.pick(r, a); }
  function ch(r, p) { return r() < p; }
  function inJail(l) { return l.jailUntil != null && l.age < l.jailUntil; }
  function free(l) { return !inJail(l) && !(l.abroad && l.abroad.trapped) && !(l.flags.military && l.age < l.flags.military); }
  function vnd(l) { return isVN(l) && l.cur === 'vnd' && !(l.abroad && l.abroad.perm); }
  function V(l, tr) { return vnd(l) ? tr : tr / 90 * l.base; }
  function T(id, when, p, cd, max) { E.TRIG.push({ id: id, when: function (l, a) { return free(l) && when(l, a); }, p: p, cd: cd || 4, max: max || 1 }); }
  function stress(l, x) { if (l.mind) l.mind.stress = U.clamp(l.mind.stress + x, 0, 100); }
  function jid(l) { return l.job ? E.resolveJob(l.job.id) : null; }
  function parent(l) { return l.fam.mAlive ? 'mẹ' : l.fam.fAlive ? 'bố' : null; }

  // ===================================================================
  // 1. CHỨC CAO KHÔNG BỊ "SẾP" ÉP
  // ===================================================================
  var TOPT = /^(tổng giám đốc|chủ tịch|phó tổng giám đốc|giám đốc|cơ trưởng|bí thư|bộ trưởng|thứ trưởng|giám đốc bệnh viện|hiệu trưởng|viện trưởng|tổng biên tập|chánh án|trưởng khoa|bác sĩ trưởng khoa|tổng đạo diễn|giám đốc sáng tạo)/;
  function hasBoss(l) {
    if (!l.job || l.job.fam || !H.isEmployee(l)) return false;
    if (E.isFreelanceJob && E.isFreelanceJob(l)) return false; // v5.6.4: MC, makeup, tài xế ứng dụng… làm tự do, không có sếp
    var c = E.CAR[jid(l)]; if (!c) return true;
    var rk = l.job.rank || 0, n = c.t.length;
    if (n > 1 && rk >= n - 1) return false;
    if (n >= 4 && rk >= n - 2) return false;
    if (TOPT.test(c.t[Math.min(rk, n - 1)])) return false;
    return true;
  }
  E.hasBoss = hasBoss;
  ['sep_ep', 'vp_cuop_cong', 'ks_du_an', 'cn_cuu_sep', 'pc_met_moi'].forEach(function (id) { var D = E.DEC[id]; if (!D) return; var v0 = D.valid; D.valid = function (l) { return hasBoss(l) && (v0 ? v0.apply(this, arguments) : true); }; });
  if (E.DEC.nh_chi_tieu) { var nc0 = E.DEC.nh_chi_tieu.valid; E.DEC.nh_chi_tieu.valid = function (l) { return hasBoss(l) && (!nc0 || nc0.apply(this, arguments)); }; }
  E.ACT.forEach(function (a) { if (a.id === 'tang_luong') { var av = a.avail; a.avail = function (l) { var x = av ? av(l) : true; return x === true && !hasBoss(l) ? 'Không áp dụng' : x; }; } });

  // ===================================================================
  // 2. GIỚI HẠN TUỔI MỘT SỐ HOẠT ĐỘNG
  // ===================================================================
  var MAXAGE = { tap_gym: 65, da_bong_ban: 60, leo_nui: 65, phuot: 55 };
  E.ACT.forEach(function (a) { if (MAXAGE[a.id] != null && (a.max == null || a.max > MAXAGE[a.id])) a.max = MAXAGE[a.id]; });

  // ===================================================================
  // 3. TRONG TÙ
  // ===================================================================
  E.JAIL_OK = /^(tg_|trai_giam$|treat$|phau_thuat$)/;
  function PJ(id, title, text, opts, valid) { SC(id, { title: title, text: text, valid: function (l) { return inJail(l) && (!valid || valid(l)); }, opts: opts.map(function (o) { return { k: o[0], l: o[1], ai: o[2], run: o[3] }; }) }); }
  function pts(l, x) { l.flags.jailPts = (l.flags.jailPts || 0) + x; }
  PJ('tg_kham_xet', 'Khám xét buồng giam', 'Cán bộ quản giáo bất ngờ khám xét buồng giam. Có người giấu điện thoại, thuốc lá dưới chiếu, nhờ bạn cất giúp.', [
    ['tu_choi', 'Từ chối, không dính vào', { w: 1.3 }, function (l, r, log) { pts(l, 1); log('Từ chối thẳng. Đợt khám xét tìm ra đồ cấm, mấy người bị kỷ luật — bạn không liên quan.', 'good'); }],
    ['giau', 'Cất giúp cho "có nghĩa"', { risk: 1, w: 0.4 }, function (l, r, log) { if (ch(r, 0.5)) { l.jailUntil++; log('Bị phát hiện cất giấu đồ cấm, bị kỷ luật, tăng thêm án một năm.', 'bad'); } else { log('Thoát được đợt khám xét. Người kia nợ bạn một ân tình.', 'neutral'); } }]]);
  PJ('tg_sinh_nhat', 'Sinh nhật trong trại', 'Hôm nay là sinh nhật bạn. Không có bánh kem, chỉ có bữa cơm tù như mọi ngày.', [
    ['im', 'Lặng lẽ cho qua', { w: 1 }, function (l, r, log) { log('Sinh nhật trôi qua lặng lẽ. Tối nằm nhìn lên trần, nhớ những lần sinh nhật ở nhà.', 'neutral'); fx(l, { hap: -2 }); }],
    ['ban', 'Bạn cùng buồng góp bánh kẹo thăm nuôi làm "tiệc"', { w: 1, soc: 1 }, function (l, r, log) { log('Cả buồng góp mấy gói bánh, hát chúc mừng sinh nhật khe khẽ. Lần đầu bạn cười sau nhiều tháng.', 'good'); fx(l, { hap: 3, soc: 2 }); }]]);
  PJ('tg_tin_nha', 'Tin dữ từ nhà', function (l) { return 'Thư nhà báo tin ' + (parent(l) || 'người thân') + ' ốm nặng, nằm viện. Bạn không thể về.'; }, [
    ['don', 'Làm đơn xin về thăm (theo quy định đặc biệt)', { w: 1 }, function (l, r, log) { if (ch(r, 0.25)) log('Được trại xem xét cho về thăm có cán bộ dẫn giải trong một ngày. Nắm tay ' + (parent(l) || 'người thân') + ' mà không nói được câu nào.', 'neutral'); else log('Đơn không được chấp thuận. Bạn chỉ biết viết thư gửi về.', 'bad'); fx(l, { hap: -4 }); }],
    ['thu', 'Viết thư động viên', { w: 1 }, function (l, r, log) { log('Viết thư động viên, hứa sẽ cải tạo tốt để sớm về.', 'neutral'); pts(l, 1); fx(l, { hap: -3 }); }]], function (l) { return !!parent(l); });
  PJ('tg_bep', 'Tổ nhà bếp', 'Trại cần người phụ bếp cho cả phân trại: dậy từ 3 giờ sáng, nấu cơm cho hàng trăm người.', [
    ['nhan', 'Xin vào tổ bếp', { w: 1.2 }, function (l, r, log) { pts(l, 2); fx(l, { hea: -1 }); log('Vào tổ bếp, ngày nào cũng nấu mấy nồi cơm lớn. Mệt nhưng được ghi nhận chăm chỉ.', 'good'); if (!l.hobby) { l.hobby = 'nauan'; l.hobbySk = 20; } }],
    ['khong', 'Thôi, ở tổ cũ', { w: 0.6 }, function (l, r, log) { log('Ở lại tổ lao động cũ.', 'neutral'); }]]);
  PJ('tg_luat_su', 'Kháng cáo', 'Một luật sư trợ giúp pháp lý đến trại, nói hồ sơ của bạn có tình tiết giảm nhẹ chưa được xem xét.', [
    ['khang', 'Làm đơn đề nghị xem xét lại', { w: 1, smart: 1 }, function (l, r, log) { if (ch(r, 0.25) && l.jailUntil - l.age > 1) { l.jailUntil--; log('Tòa xem xét lại, giảm cho bạn một năm án.', 'good'); } else log('Đơn được tiếp nhận nhưng giữ nguyên bản án.', 'neutral'); }],
    ['thoi', 'Thôi, chấp hành án', { w: 0.6 }, function (l, r, log) { log('Chấp hành án, không kháng cáo.', 'neutral'); }]]);
  PJ('tg_tien_ban', 'Tiễn bạn tù', 'Người bạn cùng buồng thân nhất mãn hạn tù. Trước khi đi, anh ta dúi cho bạn bánh xà phòng, cái khăn mặt.', [
    ['dan', 'Dặn bạn ra ngoài sống tử tế', { w: 1.3 }, function (l, r, log) { log('Ôm nhau ở cổng buồng, dặn nhau ra ngoài sống tử tế. Tối ấy bạn nằm nhìn chỗ trống bên cạnh.', 'neutral'); fx(l, { hap: -2, karma: 2 }); }],
    ['hen', 'Hẹn ra tù sẽ tìm nhau "làm ăn"', { bad: 1 }, function (l, r, log) { l.flags.jailContact = true; log('Hẹn ra tù sẽ tìm nhau.', 'neutral'); }]]);
  PJ('tg_cai_nghien', 'Cắt cơn trong trại', 'Vào trại không có ma túy, những cơn thèm thuốc hành hạ bạn từng đêm.', [
    ['cai', 'Cắn răng cắt cơn, theo chương trình cai nghiện', { w: 1.4 }, function (l, r, log) { if (l.addict) l.addict.drugs = false; fx(l, { hea: -6, hap: -4 }); pts(l, 1); log('Những đêm vật vã qua đi. Lần đầu sau nhiều năm, người bạn sạch ma túy.', 'good'); H.mem(l, 'Những đêm cắt cơn trong trại giam.', 4); }]], function (l) { return !!(l.addict && l.addict.drugs); });
  PJ('tg_doi_bong', 'Giải bóng đá phân trại', 'Trại tổ chức giải bóng đá giữa các đội phạm nhân dịp lễ.', [
    ['da', 'Ra sân thi đấu', { w: 1.1 }, function (l, r, log) { fx(l, { hea: 2, hap: 3, soc: 2 }); log(ch(r, 0.4) ? 'Đội bạn vô địch giải, được thưởng thêm suất ăn.' : 'Thua ở bán kết, nhưng cả đội vẫn vui.', 'good'); }],
    ['co_vu', 'Ngồi cổ vũ', { w: 0.8 }, function (l, r, log) { fx(l, { hap: 1 }); log('Ngồi cổ vũ khản cổ.', 'neutral'); }]]);
  PJ('tg_nhat_ky', 'Cuốn sổ nhỏ', 'Bạn xin được một cuốn sổ và cây bút, bắt đầu viết về những năm tháng đã qua.', [
    ['viet', 'Viết thật về những sai lầm của mình', { w: 1.2 }, function (l, r, log) { stress(l, -8); fx(l, { kno: 2, karma: 2 }); log('Viết kín cuốn sổ về những sai lầm, về những người đã làm tổn thương. Viết xong thấy lòng nhẹ hơn.', 'good'); }]]);
  PJ('tg_moi_vao', 'Phạm nhân mới', 'Một cậu thanh niên mới vào trại, mặt còn non choẹt, bị mấy người cũ bắt nạt.', [
    ['bao_ve', 'Đứng ra bênh vực', { w: 1.1, karma: 1 }, function (l, r, log) { fx(l, { karma: 4, hea: -2 }); pts(l, 1); log('Đứng ra bênh cậu ta. Từ đó cậu gọi bạn là "anh / chị", hứa ra tù sẽ làm lại cuộc đời.', 'good'); }],
    ['ke', 'Mặc kệ, ai lo thân nấy', { w: 0.8 }, function (l, r, log) { log('Mặc kệ. Ở đây ai cũng lo thân mình.', 'neutral'); }]]);
  var JPOOL2 = ['tg_tham_nuoi', 'tg_dai_ca', 'tg_lao_dong', 'tg_hoc', 'tg_tron_trai', 'tg_dac_xa', 'tg_tet', 'tg_om', 'tg_ly_hon', 'tg_ban_tu', 'tg_thu_con', 'tg_tu_hoc', 'trai_giam', 'tg_kham_xet', 'tg_sinh_nhat', 'tg_tin_nha', 'tg_bep', 'tg_luat_su', 'tg_tien_ban', 'tg_cai_nghien', 'tg_doi_bong', 'tg_nhat_ky', 'tg_moi_vao'];
  E.jailYear = function (l, r, a) {
    var seen = (l.flags.jailSeen = l.flags.jailSeen || {});
    var ok = function (id) { return E.DEC[id] && E.DEC[id].valid(l, {}); };
    var pool = JPOOL2.filter(function (id) { return ok(id) && !seen[id]; });
    if (pool.length < 4) { l.flags.jailSeen = seen = {}; pool = JPOOL2.filter(ok); }
    for (var i = pool.length - 1; i > 0; i--) { var j = Math.floor(r() * (i + 1)), t = pool[i]; pool[i] = pool[j]; pool[j] = t; }
    if (l.flags.jailAt === a && pool.indexOf('tg_dai_ca') > 0) { pool.splice(pool.indexOf('tg_dai_ca'), 1); pool.unshift('tg_dai_ca'); }
    var n = 3 + (r() < 0.4 ? 1 : 0);
    return pool.slice(0, n).map(function (id) { seen[id] = 1; return [id]; });
  };
  // Án được kết thúc tại endYear, sau khi thanh năm cuối chạy đủ.

  // ===================================================================
  // 4. PHI PHÁP: ĐƯỜNG DÂY, LÊN CẤP, ÔNG TRÙM
  // ===================================================================
  function setJob(id, t, vn, yrs) { var c = E.CAR[id]; if (!c) return; c.t = t; c.vn = vn; c.yrs = yrs; }
  setJob('buon_lau', ['chân rết vận chuyển hàng lậu', 'đầu nậu đường dây buôn lậu', 'trùm đường dây buôn lậu'], [200, 650, 1800], [3, 5]);
  setJob('ma_tuy', ['bán lẻ ma túy', 'đầu nậu ma túy', 'trùm đường dây ma túy'], [30, 250, 1300], [3, 5]);
  setJob('doi_no', ['đòi nợ thuê', 'đàn em', 'đại ca'], [15, 40, 150], [3, 5]);
  setJob('lua_dao', ['lừa đảo qua mạng', 'quản lý nhóm lừa đảo', 'trùm lừa đảo'], [25, 120, 600], [3, 5]);
  // càng lên cao càng ít trực tiếp nhúng tay, có đàn em, có "ô dù" của băng nhóm — ít bị bắt hơn
  E.crimeRankK = function (l, c) { var n = c.t.length, rk = l.job.rank || 0; if (n <= 1) return 1; return rk >= n - 1 ? 0.25 : rk >= 1 ? 0.6 : 1; };
  var ru0 = E.rankUpText;
  E.rankUpText = function (l, c) {
    if (c.sec === 'crime') { var now = c.t[l.job.rank]; return { t: pick(H.rf ? H.rf(l) : Math.random, ['Được "anh lớn" tin tưởng, giao quản lý cả một mối hàng — giờ là ' + now + ', có đàn em, có người chống lưng.', 'Nắm được cả đường dây, chân rết khắp các tỉnh — giờ là ' + now + '. Tiền nhiều hơn, nhưng kẻ thù cũng nhiều hơn.']), m: 'Năm trở thành ' + now + '.' }; }
    return ru0 ? ru0.apply(this, arguments) : null;
  };
  var CRJ = ['buon_lau', 'ma_tuy', 'lua_dao', 'doi_no', 'cho_vay'];
  function crim(l) { return CRJ.indexOf(jid(l)) >= 0; }
  SC('dd_vao_duong_day', {
    title: 'Vào đường dây', valid: function (l) { return crim(l) && (l.job.rank || 0) === 0 && !l.flags.ddIn; },
    text: function (l) { return jid(l) === 'buon_lau' ? 'Một "anh lớn" ở cửa khẩu để ý bạn chạy hàng nhanh nhẹn, kín miệng, rủ vào hẳn đường dây: có xe, có kho, có người lo đầu ra.' : 'Một tay "anh lớn" muốn kéo bạn vào hẳn đường dây của hắn: có tổ chức, có người lo, chia phần đều.'; },
    opts: [
      { k: 'vao', l: 'Nhận lời, vào đường dây', ai: { bad: 1, amb: 1 }, run: function (l, r, log) { l.flags.ddIn = l.age; l.job.yrs += 1; log('Vào đường dây. Từ nay có tổ chức, có người chống lưng, tiền về đều — nhưng đã vào thì khó mà ra.', 'bad'); fx(l, { karma: -4 }); } },
      { k: 'le', l: 'Làm lẻ một mình cho chắc', ai: { w: 0.8 }, run: function (l, r, log) { log('Từ chối, vẫn làm lẻ một mình.', 'neutral'); l.flags.ddIn = -1; } },
      { k: 'bo', l: 'Sợ quá, bỏ hẳn', ai: { w: 0.5, smart: 1 }, run: function (l, r, log) { if (E.quitCrime) E.quitCrime(l, log, 'Nghe đến "đường dây" thì sợ, bỏ hẳn con đường này.'); } }
    ]
  });
  T('dd_vao_duong_day', function (l) { return crim(l) && (l.job.rank || 0) === 0 && !l.flags.ddIn && l.job.yrs >= 1; }, 0.4, 3, 1);
  SC('dd_mat_hang', {
    title: 'Lô hàng bị bắt', valid: function (l) { return crim(l); },
    prep: function (l, r) { return { x: Math.round((l.job.rank + 1) * (50 + r() * 150)) }; },
    text: function (l, d) { return 'Lực lượng chức năng chặn bắt một chuyến hàng của đường dây, thu giữ toàn bộ. Phần vốn của bạn trong chuyến ấy khoảng ' + mo(l, V(l, d.x)) + '. Tài xế đã bị bắt.'; },
    opts: [
      { k: 'im', l: 'Cắt đứt liên lạc, nằm im một thời gian', ai: { w: 1.2, smart: 1 }, run: function (l, r, log, d) { H.cash(l, -Math.min(V(l, d.x), Math.max(0, l.money)), 'Mất lô hàng'); stress(l, 15); log('Mất trắng lô hàng, thay số điện thoại, nằm im mấy tháng. Đêm nào cũng giật mình.', 'bad'); } },
      { k: 'lo', l: 'Bỏ tiền "lo" cho tài xế, giữ kín đường dây', ai: { bad: 1 }, run: function (l, r, log, d) { H.cash(l, -Math.min(V(l, d.x * 1.5), Math.max(0, l.money)), 'Mất lô hàng, lo cho đàn em'); if (ch(r, 0.35)) H.sched(l, 'bi_bat', 0, { why: 'buôn lậu', sev: 2 }); log('Bỏ tiền lo cho gia đình tài xế để hắn im lặng. Nhưng lời khai thì chẳng ai giữ được mãi.', 'bad'); } },
      { k: 'dau_thu', l: 'Ra đầu thú', ai: { w: 0.4, smart: 1 }, run: function (l, r, log) { H.jail(l, U.randint(r, 2, 4), 'buôn lậu (ra đầu thú, được giảm nhẹ)', log); if (E.quitCrime) E.quitCrime(l, log, 'Ra đầu thú, khai báo thành khẩn.'); } }
    ]
  });
  T('dd_mat_hang', function (l) { return crim(l) && /buon_lau|ma_tuy/.test(jid(l)); }, 0.15, 3, 3);
  SC('dd_tranh_dia_ban', {
    title: 'Tranh giành địa bàn', valid: function (l) { return crim(l) && (l.job.rank || 0) >= 1; },
    text: 'Một băng khác lấn sang địa bàn của bạn, cướp mối, đánh đàn em bạn nhập viện.',
    opts: [
      { k: 'danh', l: 'Cho đàn em "dằn mặt"', ai: { bad: 1.2, risk: 1 }, run: function (l, r, log) { fx(l, { karma: -8 }); if (ch(r, 0.3)) H.jail(l, U.randint(r, 3, 7), 'tổ chức gây rối, cố ý gây thương tích', log); else if (ch(r, 0.05)) H.kill(l, 'bị thanh toán trong một vụ tranh giành địa bàn', log); else log('Hai băng hỗn chiến. Giữ được địa bàn, nhưng đàn em nằm viện mấy đứa.', 'bad'); } },
      { k: 'chia', l: 'Ngồi lại chia địa bàn', ai: { w: 1, smart: 1 }, run: function (l, r, log) { log('Hai bên ngồi lại chia địa bàn. Yên được một thời gian — trong giới này, "hòa" chưa bao giờ lâu.', 'neutral'); } },
      { k: 'rut', l: 'Rút lui, rửa tay gác kiếm', ai: { w: 0.4 }, run: function (l, r, log) { if (E.quitCrime) E.quitCrime(l, log); } }
    ]
  });
  T('dd_tranh_dia_ban', function (l) { return crim(l) && (l.job.rank || 0) >= 1; }, 0.15, 4, 2);
  SC('dd_rua_tien', {
    title: 'Tiền bẩn', valid: function (l) { return crim(l) && (l.job.rank || 0) >= 1 && l.money > l.base * 3; },
    text: 'Tiền về nhiều, nhưng mua nhà, mua xe bằng tiền mặt thì dễ bị để ý. Có người gợi ý mở vài cửa hàng "bình phong".',
    opts: [
      { k: 'mo', l: 'Mở cửa hàng bình phong', ai: { bad: 1 }, run: function (l, r, log) { H.cash(l, -V(l, 300), 'Mở cửa hàng bình phong'); l.flags.front = true; log('Mở mấy cửa hàng làm bình phong. Nhìn bên ngoài, bạn là một ông chủ làm ăn đàng hoàng.', 'neutral'); fx(l, { karma: -4 }); } },
      { k: 'thoi', l: 'Cứ để tiền mặt, tiêu dè chừng', ai: { w: 1 }, run: function (l, r, log) { log('Giấu tiền mặt trong nhà, sống dè chừng.', 'neutral'); stress(l, 6); } }
    ]
  });
  T('dd_rua_tien', function (l) { return crim(l) && (l.job.rank || 0) >= 1 && l.money > l.base * 3; }, 0.12, 5, 1);

  // ===================================================================
  // 5. CHỦ ĐỘNG MỞ THÊM CHI NHÁNH / MỞ RỘNG QUY MÔ
  // ===================================================================
  function owner(l) { if (!l.job || E.isCrime(l)) return false; var c = E.CAR[jid(l)]; return !!c && /^(chủ|giám đốc công ty)/.test(c.t[l.job.rank || 0]) && (l.job.rank || 0) < c.t.length - 1; }
  function expandCost(l) { var c = E.CAR[jid(l)]; return Math.max(l.base * 2, E.monthlyEst(l, c.id, (l.job.rank || 0) + 1) * 18); }
  SC('mo_rong_tu', {
    title: 'Mở thêm chi nhánh / mở rộng quy mô',
    text: function (l) { var s = []; if (owner(l)) s.push(U.cap(E.jobTitle(l)) + ': mở rộng lên ' + E.CAR[jid(l)].t[(l.job.rank || 0) + 1] + ' cần khoảng ' + mo(l, expandCost(l))); (l.ventures || []).forEach(function (v) { s.push(U.cap(v.n) + ' (' + v.br + ' cơ sở): mở thêm một chi nhánh cần khoảng ' + mo(l, v.unit)); }); return (s.length ? s.join('. ') + '.' : 'Bạn chưa có cơ sở kinh doanh nào.') + ' Tiền mặt hiện có ' + mo(l, l.money) + '.'; },
    opts: [
      { k: 'job', l: function (l) { return owner(l) ? 'Mở rộng ' + E.jobTitle(l) : ''; }, h: function (l) { return owner(l) ? mo(l, expandCost(l)) + ' · thành công thì thu nhập tăng mạnh, thất bại thì mất một phần vốn' : ''; }, req: function (l) { return owner(l) && l.money >= expandCost(l); }, ai: { w: 1, amb: 1 }, run: function (l, r, log) { var x = expandCost(l), c = E.CAR[jid(l)]; H.cash(l, -x, 'Mở rộng kinh doanh'); if (ch(r, 0.65 + (l.st.kno - 50) / 300)) { l.job.rank++; l.job.yrs = 0; log('Bỏ ' + mo(l, x) + ' mở rộng quy mô, làm ăn thuận lợi — giờ là ' + E.jobTitle(l) + '.', 'big'); H.mem(l, 'Ngày khai trương cơ sở mới của ' + E.jobTitle(l) + '.', 4); } else { log('Mở rộng quá nhanh, cơ sở mới ế ẩm, phải đóng cửa sau một năm. Mất phần lớn số vốn bỏ ra.', 'bad'); H.cash(l, x * 0.3, 'Thanh lý cơ sở mới'); fx(l, { hap: -6 }); } } },
      { k: 'ven', l: function (l) { var v = (l.ventures || [])[0]; return v ? 'Mở thêm chi nhánh ' + v.n : ''; }, h: function (l) { var v = (l.ventures || [])[0]; return v ? mo(l, v.unit) : ''; }, req: function (l) { var v = (l.ventures || [])[0]; return !!v && v.br < 8 && l.money >= v.unit; }, ai: { w: 1 }, run: function (l, r, log) { var v = l.ventures[0]; H.cash(l, -v.unit, 'Mở chi nhánh ' + v.n); v.br++; v.cap += v.unit; log('Mở thêm một chi nhánh ' + v.n + ', giờ có ' + v.br + ' cơ sở.', 'good'); } },
      { k: 'no', l: 'Thôi, giữ quy mô hiện tại', ai: { w: 0.5 }, run: function () { } }
    ]
  });
  A('mo_rong', 'Công việc', 'Mở thêm chi nhánh / mở rộng quy mô', { min: 20, sc: 'mo_rong_tu', avail: function (l) { var v = (l.ventures || [])[0]; if (!owner(l) && !v) return 'Không áp dụng'; return (owner(l) && l.money >= expandCost(l)) || (v && v.br < 8 && l.money >= v.unit) ? true : 'Chưa đủ vốn để mở rộng'; } });
  // Mỗi cơ sở có lựa chọn riêng, không chỉ cơ sở đầu tiên trong danh sách.
  var expandOpts = E.DEC.mo_rong_tu.def.opts;
  expandOpts.splice(1, 1);
  (E.wealth.BIZ || []).forEach(function (b) {
    function venture(l) { return (l.ventures || []).filter(function (v) { return v.k === b.k; })[0]; }
    expandOpts.splice(expandOpts.length - 1, 0, {
      k: 'ven_' + b.k,
      l: function (l) { var v = venture(l); return v ? 'Mở thêm chi nhánh ' + v.n : ''; },
      h: function (l) { var v = venture(l); return v ? mo(l, v.unit) : ''; },
      req: function (l) { var v = venture(l); return !!v && v.br < 8 && l.money >= v.unit; },
      ai: { w: 1 },
      run: function (l, r, log) { var v = venture(l); if (!v || v.br >= 8 || l.money < v.unit) return; H.cash(l, -v.unit, 'Mở chi nhánh ' + v.n); v.br++; v.cap += v.unit; v.good = 0; log('Mở thêm một chi nhánh ' + v.n + ', giờ có ' + v.br + ' cơ sở.', 'good'); }
    });
  });
  E.ACT.filter(function (a) { return a.id === 'mo_rong'; })[0].avail = function (l) {
    var vs = l.ventures || [];
    if (!owner(l) && !vs.length) return 'Không áp dụng';
    return (owner(l) && l.money >= expandCost(l)) || vs.some(function (v) { return v.br < 8 && l.money >= v.unit; }) ? true : 'Chưa đủ vốn để mở rộng';
  };

  // ===================================================================
  // 6. NĂNG KHIẾU GAME: THỂ LOẠI, TỰ CHỌN GAME
  // ===================================================================
  if (E.GAMES) {
    E.GAMES.moba.pc = ['Liên Minh Huyền Thoại']; E.GAMES.moba.mobile = ['Liên Quân Mobile', 'Mobile Legends: Bang Bang', 'Liên Minh: Tốc Chiến'];
    E.GAMES.fps.pc = ['Valorant', 'Counter-Strike 2', 'Delta Force', 'Đột Kích (CrossFire)', 'Apex Legends', 'Overwatch 2']; E.GAMES.fps.mobile = ['Free Fire', 'Delta Force Mobile', 'Call of Duty Mobile'];
  }
  function gList(l) { var t = l.talentSub === 'FPS' ? 'fps' : 'moba', g = E.GAMES[t]; var L = g.pc.concat(g.mobile); if (!isVN(l)) L = L.filter(function (x) { return x !== 'Liên Quân Mobile'; }); return L; }
  E.gameList = gList;
  SC('chon_game', {
    title: 'Chọn game của mình', valid: function (l) { return l.talent === 'game' && !l.flags.gamePicked; },
    text: function (l) { return 'Bạn có năng khiếu ' + (l.talentSub === 'FPS' ? 'game bắn súng (FPS) — phản xạ nhanh, ngắm chuẩn' : 'game chiến thuật đồng đội (MOBA) — đọc trận tốt, phối hợp giỏi') + '. Bạn muốn theo game nào?'; },
    opts: [0, 1, 2, 3, 4, 5, 6, 7, 8].map(function (i) { return { k: 'g' + i, l: function (l) { return gList(l)[i] || ''; }, req: function (l) { return !!gList(l)[i]; }, ai: { w: 1 }, run: function (l, r, log) { l.game = gList(l)[i]; l.flags.gamePicked = true; log('Chọn theo ' + l.game + ' — tối nào cũng luyện thêm vài trận.', 'good'); } }; })
  });
  T('chon_game', function (l, a) { return l.talent === 'game' && !l.flags.gamePicked && a >= 8; }, 1, 1, 1);
  E.MAJOR && (E.MAJOR.chon_game = 0);

  // ===================================================================
  // 7. CHỌN CONCERT: NHÓM → NGHỆ SĨ
  // ===================================================================
  var CC = E.CONCERT_CATS;
  function A_(n, b) { return { n: n, b: b }; }
  if (CC) {
    var cast24 = CC.show.shows.filter(function (s) { return s.k === 'atvncg24'; })[0];
    if (cast24 && cast24.m.indexOf('Phan Đình Tùng') < 0) cast24.m.push('Phan Đình Tùng');
    CC.kr.n = 'Kpop Hàn Quốc';
    CC.vn.a = [A_('Sơn Tùng M-TP', 1994), A_('Jack - J97', 1997), A_('Soobin Hoàng Sơn', 1992), A_('Mỹ Tâm', 1981), A_('Hà Anh Tuấn', 1984), A_('Đen Vâu', 1989), A_('Hồ Ngọc Hà', 1984), A_('Noo Phước Thịnh', 1988), A_('Hoàng Thùy Linh', 1988), A_('Đông Nhi', 1988), A_('Tóc Tiên', 1989), A_('Vũ.', 1995), A_('Hòa Minzy', 1995), A_('AMEE', 2000), A_('MONO', 2000), A_('Văn Mai Hương', 1994), A_('Phan Mạnh Quỳnh', 1990), A_('Đàm Vĩnh Hưng', 1971), A_('Lệ Quyên', 1981), A_('Hoàng Dũng', 1995)];
    CC.kr.a = [A_('BTS', 1995), A_('BLACKPINK', 1996), A_('TWICE', 1997), A_('SEVENTEEN', 1997), A_('Stray Kids', 2000), A_('NewJeans', 2005), A_('aespa', 2001), A_('IVE', 2004), A_('(G)I-DLE', 1998), A_('LE SSERAFIM', 2002), A_('ENHYPEN', 2003), A_('TOMORROW X TOGETHER', 2001), A_('ATEEZ', 1999), A_('ITZY', 2001), A_('NCT 127', 1997), A_('EXO', 1992), A_('BIGBANG', 1988), A_('Red Velvet', 1995), A_('BABYMONSTER', 2006), A_('RIIZE', 2002), A_('IU', 1993), A_('Hwasa', 1995), A_('PSY', 1977), A_('G-Dragon', 1988)];
    CC.us.n = 'Nghệ sĩ US/UK';
    CC.us.a = [A_('Taylor Swift', 1989), A_('Ed Sheeran', 1991), A_('Coldplay', 1977), A_('Adele', 1988), A_('Bruno Mars', 1985), A_('The Weeknd', 1990), A_('Billie Eilish', 2001), A_('Ariana Grande', 1993), A_('Dua Lipa', 1995), A_('Harry Styles', 1994), A_('Olivia Rodrigo', 2003), A_('Justin Bieber', 1994), A_('Lady Gaga', 1986), A_('Beyoncé', 1981), A_('Sabrina Carpenter', 1999), A_('Post Malone', 1995), A_('Imagine Dragons', 1987), A_('Maroon 5', 1979), A_('Charlie Puth', 1991), A_('Rihanna', 1988), A_('Katy Perry', 1984), A_('Sam Smith', 1992), A_('Lana Del Rey', 1985), A_('Arctic Monkeys', 1986), A_('Shawn Mendes', 1998), A_('Selena Gomez', 1992), A_('Lewis Capaldi', 1996), A_('Chappell Roan', 1998), A_('SZA', 1989), A_('Doja Cat', 1995), A_('Calvin Harris', 1984), A_('Oasis', 1970)];
    CC.rapvn.a = [A_('RPT MCK', 1999), A_('Dangrangto', 2000), A_('B Ray', 1994), A_('Wxrdie', 1999), A_('Binz', 1988), A_('Karik', 1989), A_('Rhymastic', 1990), A_('Suboi', 1990), A_('tlinh', 2000), A_('Low G', 1998), A_('Obito', 1998), A_('Andree Right Hand', 1989), A_('16 Typh', 2000), A_('Seachains', 1995), A_('Wowy', 1988), A_('Double2T', 1998), A_('Đen Vâu', 1989)];
  }
  // Danh mục solo Việt loại toàn bộ người tham gia các show, kể cả nghệ danh khác.
  if (CC) {
    var showNames = {};
    CC.show.shows.forEach(function (s) { s.m.forEach(function (n) { showNames[n.toLowerCase()] = true; }); });
    showNames['soobin hoàng sơn'] = true;
    CC.vn.a = CC.vn.a.filter(function (a) { return !showNames[a.n.toLowerCase()]; });
  }
  var PER = 8;
  SC('concert_nghe_si', {
    title: function (l, d) { return CC[d.cat].n; },
    prep: function (l, r, a) { var all = E.artistsOf(a.cat, l).filter(function (x) { return !x.show; }); var p = a.p || 0; return { cat: a.cat, p: p, cs: all.slice(p * PER, p * PER + PER).map(function (x) { return x.n; }), more: all.length > (p + 1) * PER, all: all.map(function (x) { return x.n; }) }; },
    text: function (l, d) { return 'Chọn nghệ sĩ bạn muốn đi xem concert' + (l.idol && d.all.indexOf(l.idol) >= 0 ? ' (thần tượng của bạn: ' + l.idol + ')' : '') + ':'; },
    opts: Array.apply(null, Array(PER)).map(function (_, i) {
      return { k: 'a' + i, l: function (l, d) { return d.cs[i] || ''; }, req: function (l, d) { return !!d.cs[i]; }, ai: function (l, d) { return d && d.cs[i] === l.idol ? 3 : 1; },
        run: function (l, r, log, d) { l.pending.unshift(E.DEC.concert_di.make(l, r, { cat: d.cat, name: d.cs[i] })); } };
    }).concat([
      { k: 'them', l: 'Xem thêm nghệ sĩ khác ›', req: function (l, d) { return d.more; }, ai: { w: 0 }, run: function (l, r, log, d) { l.pending.unshift(E.DEC.concert_nghe_si.make(l, r, { cat: d.cat, p: d.p + 1 })); } },
      { k: 'thoi', l: 'Thôi, để dịp khác', ai: { w: 0.2 }, run: function () { } }
    ])
  });
  if (E.DEC.concert_chon) E.DEC.concert_chon.def.opts.forEach(function (o) {
    if (o.k === 'no') return;
    if (o.k === 'show') { o.h = function (l) { return E.artistsOf('show', l).map(function (a) { return a.n; }).join(', '); }; return; }
    o.h = ''; o.run = function (l, r) { l.pending.unshift(E.DEC.concert_nghe_si.make(l, r, { cat: o.k })); };
  });

  // ===================================================================
  // 8. LỜI KỂ VỀ GIA ĐÌNH ĐÚNG HOÀN CẢNH
  // ===================================================================
  function kidsAlive(l) { return (l.kids || []).some(function (k) { return k.alive; }); }
  function sibsAlive(l) { return H.sibs ? H.sibs(l).length > 0 : (l.fam && l.fam.sibs > 0); }
  function nobody(l) { return !kidsAlive(l) && !sibsAlive(l) && !(l.fam && (l.fam.mAlive || l.fam.fAlive)) && !(l.partner && l.partner.alive && l.partner.status !== 'dating'); }
  E.hasFamily = function (l) { return !nobody(l); };
  E.famLogic = function (l, t, isLog) {
    if (typeof t !== 'string' || !l || !l.fam || l.age < 1) return t;
    if (!/con cháu|đàn cháu|các con|các cháu|anh chị em|cả nhà|cả gia đình|sum vầy|Đám cưới|Về quê ăn Tết|Tết năm nay/i.test(t)) return t;
    if (!kidsAlive(l) && /[Cc]on cháu|đàn cháu|các con\b|các cháu/.test(t) && !/(cụ già|người ta|nhà người|của cụ|bà cụ|ông cụ)/.test(t)) {
      t = t.replace(/Con cháu tổ chức lễ mừng thọ (\d+) tuổi\./, function (x, n) { return (l.partner && l.partner.alive !== false && l.partner.status !== 'dating' ? (l.partner.sex === l.sex ? 'Bạn và người bạn đời làm mâm cơm, mời hàng xóm, bạn bè đến mừng thọ ' : 'Hai vợ chồng làm mâm cơm, mời hàng xóm, bạn bè đến mừng thọ ') : 'Hàng xóm, bạn bè đến chúc thọ ') + n + ' tuổi.'; })
        .replace('giờ chỉ vui với con cháu', 'giờ chỉ vui với vườn tược, bạn bè').replace('Ở lại gần con cháu', 'Ở lại thành phố').replace('Ở lại thành phố gần con cháu.', 'Ở lại thành phố.').replace('qua con cháu giới thiệu', 'qua bạn bè giới thiệu')
        .replace(/lì xì (cho )?con cháu/g, 'lì xì cho lũ trẻ trong xóm');
      if (/[Cc]on cháu|đàn cháu|các con\b|các cháu/.test(t)) { if (isLog && /chu cấp|ở với con cháu|về ở với|sum vầy|quây quần/.test(t)) return null; t = t.replace(/con cháu/g, 'bà con lối xóm'); }
    }
    if (!sibsAlive(l) && /(^|[^\p{L}])[Aa]nh chị em(?! họ)/u.test(t)) { if (isLog) return null; }
    if (inJail(l) && /^Đám cưới của/.test(t)) t = t.replace('Cả nhà tất bật mấy ngày liền.', 'Bạn đang ở trong trại, chỉ biết gửi lời chúc qua thư.');
    if (nobody(l)) {
      t = t.replace('Tiết Thanh minh, cả nhà đi tảo mộ ông bà.', 'Tiết Thanh minh, một mình đi tảo mộ ông bà, bố mẹ.').replace('Tết năm nay cả nhà sum họp đông đủ.', 'Tết năm nay đón một mình, thắp nén hương cho bố mẹ rồi sang chúc Tết hàng xóm.').replace('Về quê ăn Tết, gói bánh chưng cùng gia đình.', 'Về quê ăn Tết, thắp hương tưởng nhớ ông bà, bố mẹ rồi ghé chúc Tết hàng xóm.');
      if (isLog && /[Cc]ả nhà (sum họp|quây quần|sum vầy|đoàn tụ)|sum vầy/.test(t)) return null;
      // v5.6.4: không còn ai trong gia đình thì "cả nhà lên chùa", "cả nhà ăn chay"… thành chuyện của riêng bạn
      if (isLog) t = t.replace('ngày Rằm cả nhà ăn chay', 'ngày Rằm bạn ăn chay').replace('về ăn bữa cơm sum họp', 'ở lại dùng bữa với bà con trong giáo xứ').replace(/^(Cả nhà|Cả gia đình) /, 'Bạn ').replace(/([,:;—] )(cả nhà|cả gia đình) /g, '$1bạn ');
    }
    return t;
  };
  // "Chia với anh chị em" chỉ khi còn anh chị em
  ['bo_me_can', 'care', 'bo_me_om'].forEach(function (id) { var D = E.DEC[id]; if (!D || !D.def) return; D.def.opts.forEach(function (o) { if (o.k === 'share') o.req = function (l) { return sibsAlive(l); }; }); });
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
/* ===== js/life47.js ===== */
/* v4.5.1 — danh mục concert bền vững; thế giới ngầm và hậu quả kéo dài.
   Các tỷ lệ dưới đây là cân bằng trò chơi, không phải số liệu thực tế. */
(function (G) {
  'use strict';
  var E = G.E, U = G.U, H = E.H;
  function free(l) { return l.alive && l.age >= 18 && !(l.jailUntil != null && l.age < l.jailUntil) && !(l.abroad && l.abroad.trapped) && !(l.flags.military && l.age < l.flags.military); }
  function state(l) { return l.flags.underworld || (l.flags.underworld = { linked: false, heat: 0, hunted: false }); }
  function active(l) { var s = state(l); return free(l) && (s.linked || s.hunted || E.isCrime(l)); }
  function heat(l, n) { var s = state(l); s.heat = U.clamp((s.heat || 0) + n, 0, 100); }
  function cost(l, n) { return H.isVN(l) && l.cur === 'vnd' ? n : l.base * n / 90; }
  function pay(l, n, why) { H.cash(l, -Math.min(Math.max(0, l.money), cost(l, n)), why); }
  function leave(l, log) { state(l).linked = false; if (E.isCrime(l)) E.quitCrime(l, log); }
  function pursuit(l) { if (!(l.sched || []).some(function (s) { return s.id === 'uw_truy_sat'; })) H.sched(l, 'uw_truy_sat', 1); }
  function risk(l) { if (!active(l)) return 0; var s = state(l); return U.clamp(0.04 + (s.linked ? 0.06 : 0) + (s.hunted ? 0.20 : 0) + s.heat / 500 + (E.isCrime(l) ? (l.job.rank || 0) * 0.02 : 0), 0.04, 0.6); }
  function deathRisk(l, fight) { return U.clamp((fight ? 0.42 : 0.27) + (50 - l.st.hea) / 250 + (state(l).hunted ? 0.08 : 0), 0.12, 0.8); }
  E.underworldRisk = risk;
  E.underworldDeathRisk = deathRisk;
  function event(id, title, text, opts, condition) {
    E.SC(id, { title: title, text: text, valid: function (l) { return active(l) && (!condition || condition(l)); }, opts: opts });
  }
  function trigger(id, p, cd) { E.TRIG.push({ id: id, when: function (l) { return E.DEC[id].valid(l, {}); }, p: p, cd: cd || 3, rep: true }); }
  function option(k, l, run, req) { return { k: k, l: l, run: run, req: req, ai: { w: 1 } }; }

  // Giữ đủ 33 / 34 thành viên ngay trong dữ liệu chung dùng bởi mọi màn chọn.
  var cast = E.SHOWS.filter(function (s) { return s.k === 'atvncg24'; })[0];
  if (cast && cast.m.indexOf('Phan Đình Tùng') < 0) cast.m.push('Phan Đình Tùng');
  E.SC('concert_luu_tru', {
    title: 'Concert lưu trữ',
    prep: function (l, r, a) { return { name: a && typeof a.name === 'string' && a.name.trim() ? a.name : 'concert chương trình truyền hình' }; },
    text: function (l, d) { return d.name + ' đã diễn ra từ nhiều thập kỷ trước. Bạn có thể xem lại bản ghi đầy đủ; đây không phải concert trực tiếp của đội hình năm đó.'; },
    opts: [option('xem', 'Xem lại concert cùng cộng đồng người hâm mộ', function (l, r, log, d) { H.fx(l, { hap: 5 }); log('Xem lại bản ghi ' + d.name + (l.bias && l.bias.show === d.name ? ', cổ vũ phần trình diễn của ' + l.bias.n : '') + '.', 'good'); }), option('thoi', 'Để dịp khác', function () {})]
  });
  var concertMake = E.DEC.concert_di.make;
  E.DEC.concert_di.make = function (l, r, arg) {
    var d = concertMake.apply(this, arguments);
    var s = d.data.cat === 'show' && E.SHOWS.filter(function (x) { return x.n === d.data.name; })[0];
    if (s && l.birthYear + l.age - s.b > 65) return E.DEC.concert_luu_tru.make(l, r, { name: s.n });
    return d;
  };

  E.SC('uw_quan_he', {
    title: 'Làm ăn bất chính / quan hệ xã hội đen',
    valid: free,
    text: function (l) { var s = state(l); return (s.linked ? 'Bạn đang có quan hệ với một băng nhóm.' : 'Một người quen rủ bạn góp vốn vào việc làm ăn bất chính của băng nhóm.') + ' Tiền dễ đến nhưng có thể mất vốn, vướng án hoặc bị trả thù. Mức thù địch: ' + s.heat + '/100. ' + (s.hunted ? 'Bạn vẫn đang bị truy sát. ' : '') + 'Nguy cơ đánh úp ở lượt xét sự kiện năm nay: ' + Math.round(risk(l) * 100) + '%.'; },
    opts: [
      option('link', 'Nhận lời liên kết với băng nhóm', function (l, r, log) { state(l).linked = true; heat(l, 12); H.fx(l, { karma: -8 }); log('Nhận lời liên kết làm ăn với băng nhóm. Từ đây, tranh chấp của họ cũng có thể liên lụy đến bạn.', 'bad'); }, function (l) { return !state(l).linked; }),
      option('deal', 'Góp vốn một thương vụ rủi ro (chỉ một lần mỗi năm)', function (l, r, log) { var s = state(l), capital = cost(l, 200); s.dealAt = l.age; H.cash(l, -capital, 'Vốn thương vụ bất chính'); heat(l, 15); if (r() < 0.3) { log('Thương vụ đổ bể, mất toàn bộ vốn. Những người cùng góp tiền quay sang đổ lỗi cho nhau.', 'bad'); } else { var payout = capital * (1.5 + r() * 2); H.cash(l, payout, 'Thu hồi vốn và lãi thương vụ bất chính'); log('Thương vụ mang về ' + H.money(l, payout) + ' gồm cả vốn. Món tiền khiến bạn lún sâu thêm.', 'bad'); } }, function (l) { return state(l).linked && state(l).dealAt !== l.age && l.money >= cost(l, 200); }),
      option('leave', 'Cắt quan hệ, dừng làm ăn bất chính', function (l, r, log) { leave(l, log); heat(l, -10); log(state(l).hunted ? 'Đã dừng làm ăn, nhưng băng đối thủ chưa ngừng truy sát bạn.' : 'Cắt quan hệ làm ăn với băng nhóm. Những mâu thuẫn cũ vẫn có thể kéo dài.', 'neutral'); }, function (l) { return state(l).linked || E.isCrime(l); }),
      option('no', 'Đóng lại', function () {})
    ]
  });
  E.ACT.push({ id: 'uw_quan_he', g: 'Đường tối', l: 'Làm ăn bất chính / quan hệ xã hội đen', min: 18, sc: 'uw_quan_he' });

  function ambush(l, r, log, fight) {
    var s = state(l), p = deathRisk(l, fight);
    if (r() < p) { H.kill(l, fight ? 'chống trả không thành trong một vụ đánh úp của băng nhóm' : 'không chạy thoát trong một vụ đánh úp của băng nhóm', log); return; }
    s.hunted = true; s.attackedAt = l.age; heat(l, fight ? 25 : 15);
    H.fx(l, { hea: fight ? -25 : -14, hap: -15 });
    log(fight ? 'Chống trả rồi chạy thoát, may mắn sống sót nhưng bị thương nặng. Đối thủ tiếp tục truy sát bạn.' : 'Chạy thoát trong gang tấc, may mắn sống sót nhưng vẫn bị đối thủ truy sát.', 'bad');
    pursuit(l);
  }
  event('uw_can_len', 'Bị cắn lén — đánh úp', 'Một nhóm đối thủ bất ngờ chặn đường. Bạn chỉ có vài giây quyết định; cả chống trả lẫn bỏ chạy đều có nguy cơ tử vong. Sống sót cũng chưa có nghĩa là thoát khỏi việc bị truy sát.', [
    { k: 'fight', l: 'Chống trả rồi bỏ chạy', h: function (l) { return 'Nguy cơ tử vong: ' + Math.round(deathRisk(l, true) * 100) + '%'; }, ai: { w: 0.6, risk: 1 }, run: function (l, r, log) { ambush(l, r, log, true); } },
    { k: 'flee', l: 'Chạy trốn ngay', h: function (l) { return 'Nguy cơ không chạy thoát: ' + Math.round(deathRisk(l, false) * 100) + '%'; }, ai: { w: 1.4 }, run: function (l, r, log) { ambush(l, r, log, false); } }
  ]);
  trigger('uw_can_len', risk, 1);
  E.MAJOR.uw_can_len = 1;

  event('uw_truy_sat', 'Những ngày bị truy sát', 'Điện thoại nhận những lời đe dọa. Bạn không còn cảm thấy an toàn khi ra đường.', [
    option('help', 'Trình báo và xin được bảo vệ', function (l, r, log) { leave(l, log); if (r() < 0.7) { state(l).hunted = false; heat(l, -60); log('Thông tin giúp cơ quan chức năng ngăn nhóm đe dọa. Bạn thoát khỏi việc bị truy sát, nhưng vẫn phải chịu trách nhiệm nếu có hành vi phạm pháp.', 'good'); } else { log('Vụ việc đang được xác minh; mối đe dọa chưa chấm dứt.', 'bad'); pursuit(l); } }),
    option('hide', 'Tạm ngừng làm ăn, lánh nạn', function (l, r, log) { leave(l, log); pay(l, 40, 'Chi phí lánh nạn'); heat(l, -8); H.fx(l, { hap: -8 }); log('Lánh nạn một thời gian. Bạn vẫn bị truy sát, chưa thể coi như chuyện đã xong.', 'bad'); pursuit(l); }),
    option('back', 'Quay lại nhờ băng nhóm che chở', function (l, r, log) { state(l).linked = true; heat(l, 12); log('Băng nhóm nhận giúp, đổi lại bạn tiếp tục mắc nợ họ. Nguy cơ truy sát vẫn còn.', 'bad'); pursuit(l); })
  ], function (l) { return state(l).hunted; });
  E.MAJOR.uw_truy_sat = 1;

  event('uw_phan_boi', 'Người trong nhóm trở mặt', 'Người từng cùng làm ăn lấy mất phần tiền chung rồi tung tin bạn phản bội.', [
    option('loss', 'Chấp nhận mất phần tiền, không trả đũa', function (l, r, log) { pay(l, 100, 'Thiệt hại do đồng bọn phản bội'); heat(l, 8); log('Chấp nhận thiệt hại nhưng lời đồn vẫn khiến quan hệ trong nhóm rạn nứt.', 'bad'); }),
    option('clash', 'Đối chất gay gắt', function (l, r, log) { heat(l, 30); state(l).hunted = true; log('Cuộc đối chất biến thành xung đột. Người kia nhờ một băng khác truy sát bạn.', 'bad'); pursuit(l); })
  ]);
  event('uw_chia_phan', 'Tranh chấp chia phần', 'Sau một thương vụ, người cầm đầu đòi giữ phần lớn tiền lời.', [
    option('accept', 'Chấp nhận chịu thiệt lần này', function (l, r, log) { pay(l, 60, 'Bị giữ lại phần tiền'); heat(l, -3); log('Chịu thiệt để tránh xung đột. Bạn hiểu lời hứa trong nhóm chẳng có gì bảo đảm.', 'bad'); }),
    option('quit', 'Dừng hợp tác', function (l, r, log) { leave(l, log); heat(l, 10); log('Dừng hợp tác sau tranh chấp. Người cầm đầu tỏ ra không hài lòng.', 'neutral'); })
  ]);
  event('uw_tong_tien', 'Bị băng khác đe dọa', 'Một nhóm khác đòi bạn nộp tiền, nếu không sẽ gây chuyện.', [
    option('report', 'Trình báo lời đe dọa', function (l, r, log) { heat(l, 5); log('Trình báo và cung cấp các tin nhắn đe dọa. Vụ việc được tiếp nhận.', 'neutral'); }),
    option('pay', 'Chấp nhận mất tiền', function (l, r, log) { pay(l, 80, 'Thiệt hại bị đe dọa'); heat(l, 10); log('Mất tiền nhưng không có gì bảo đảm họ sẽ để bạn yên.', 'bad'); })
  ]);
  event('uw_dieu_tra', 'Đường dây bị điều tra', 'Những người từng làm ăn chung bị triệu tập. Bạn phải đối diện trách nhiệm về phần việc của mình.', [
    option('cooperate', 'Hợp tác khai báo', function (l, r, log) { var guilty = state(l).dealAt != null || E.isCrime(l); leave(l, log); if (guilty && r() < 0.6) H.jail(l, U.randint(r, 2, 5), 'tham gia đường dây làm ăn bất chính', log); else log('Hợp tác làm rõ vụ việc. Chưa có kết luận bạn phạm tội trong đợt điều tra này.', 'neutral'); }),
    option('refuse', 'Tìm luật sư, chờ kết luận điều tra', function (l, r, log) { pay(l, 50, 'Chi phí luật sư'); if ((state(l).dealAt != null || E.isCrime(l)) && r() < 0.45) { leave(l, log); H.jail(l, U.randint(r, 3, 7), 'tham gia đường dây làm ăn bất chính', log); } else log('Luật sư hỗ trợ làm việc; chưa có kết luận cuối cùng.', 'neutral'); })
  ]);
  event('uw_mat_von', 'Vốn góp biến mất', 'Người giữ tiền chung mất liên lạc. Không ai biết phần vốn đã đi đâu.', [
    option('stop', 'Chấp nhận mất vốn, dừng hợp tác', function (l, r, log) { pay(l, 120, 'Mất phần vốn góp'); leave(l, log); log('Chấp nhận thiệt hại, dừng hợp tác với nhóm.', 'bad'); }),
    option('wait', 'Tiếp tục chờ giải thích', function (l, r, log) { heat(l, 12); H.fx(l, { hap: -6 }); log('Chờ đợi trong lo lắng. Mâu thuẫn giữa những người góp vốn ngày càng lớn.', 'bad'); })
  ]);
  event('uw_gia_dinh', 'Người thân biết chuyện', 'Người thân lo sợ những mối quan hệ làm ăn của bạn sẽ kéo nguy hiểm về nhà.', [
    option('leave', 'Dừng làm ăn để bảo vệ gia đình', function (l, r, log) { leave(l, log); H.fx(l, { karma: 5 }); log('Dừng làm ăn bất chính. Người thân nhẹ lòng, dù những mối đe dọa cũ chưa chắc biến mất.', 'good'); }),
    option('keep', 'Vẫn tiếp tục', function (l, r, log) { heat(l, 10); H.fx(l, { hap: -8, soc: -5 }); log('Vẫn tiếp tục. Người thân sống trong bất an.', 'bad'); })
  ], function (l) { return l.fam.mAlive || l.fam.fAlive || (l.partner && l.partner.alive) || l.kids.some(function (k) { return k.alive; }); });
  event('uw_dan_em_gap_nan', 'Người cùng nhóm gặp nạn', 'Một người từng cùng làm ăn bị thương sau tranh chấp. Người nhà họ đến xin hỗ trợ viện phí.', [
    option('help', 'Hỗ trợ một phần viện phí', function (l, r, log) { pay(l, 30, 'Hỗ trợ viện phí'); log('Hỗ trợ viện phí. Cảnh bệnh viện khiến bạn nghĩ lại về con đường đang đi.', 'neutral'); }),
    option('no', 'Từ chối', function (l, r, log) { heat(l, 10); log('Từ chối hỗ trợ, thêm người oán trách bạn.', 'bad'); })
  ]);
  event('uw_duong_lui', 'Cơ hội làm lại', 'Một cơ sở làm ăn hợp pháp sẵn sàng cho bạn thử việc nếu bạn chấm dứt quan hệ bất chính.', [
    option('yes', 'Cắt quan hệ, tìm việc hợp pháp', function (l, r, log) { leave(l, log); heat(l, -15); l.flags.needJob = true; log('Chấm dứt làm ăn bất chính và bắt đầu tìm công việc hợp pháp. Thu nhập cũ không còn, việc bị truy sát nếu có vẫn cần giải quyết.', 'good'); }),
    option('no', 'Chưa muốn từ bỏ', function (l, r, log) { heat(l, 5); log('Bỏ qua cơ hội làm lại, tiếp tục những mối quan hệ cũ.', 'bad'); })
  ]);
  ['uw_phan_boi', 'uw_chia_phan', 'uw_tong_tien', 'uw_dieu_tra', 'uw_mat_von', 'uw_gia_dinh', 'uw_dan_em_gap_nan', 'uw_duong_lui'].forEach(function (id) { trigger(id, 0.16, 3); });
  E.HOOKS.year.push(function (l) { if (l.flags.underworld) heat(l, -2); });
  var quit = E.quitCrime;
  E.quitCrime = function (l) { state(l).linked = false; return quit.apply(this, arguments); };
  // Không dùng đồng thời hai cơ chế đánh úp độc lập, gây tăng rủi ro ngoài ý muốn.
  E.TRIG.forEach(function (t) { if (t.id === 'toi_tra_thu') t.when = function () { return false; }; });
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
/* ===== js/life48.js ===== */
/* v4.5.2 — Mùa game show trong một năm. Trò chơi, khách mời, đội và kết quả
   là diễn biến mô phỏng; không tái hiện một tập phát sóng có thật. */
(function (G) {
  'use strict';
  var E = G.E, H = E.H, U = G.U;
  var TITLES = { rm: 'Running Man Việt Nam', hai: '2 Ngày 1 Đêm' };
  var ROLES = { guest: { n:'khách mời', total:2, factor:.4 }, regular: { n:'thành viên cố định', total:6, factor:1.5 } };
  function roleName(v) { return (ROLES[v.role]||ROLES.regular).n; }
  function stages(v) { return v.compact ? [1,4] : v.role === 'guest' ? [0,1,4] : [0,1,2,3,4]; }
  function quote(fee,role) { return Math.max(0,Math.round((Number(fee)||0)*ROLES[role].factor)); }
  var LOCATIONS = ['Đà Lạt', 'Huế', 'Ninh Bình', 'Phú Yên', 'Quảng Bình', 'Cần Thơ', 'Nha Trang', 'Đà Nẵng'];
  var TASKS = {
    rm: ['Giải mật thư trong mê cung', 'Tiếp sức chuyền bóng', 'Truy tìm chiếc hộp bí mật', 'Đoán từ bằng hành động', 'Thử thách giữ thăng bằng', 'Ghép manh mối truy tìm huy hiệu', 'Vượt chướng ngại vật', 'Đối đáp phản xạ'],
    hai: ['Tiếp sức mang đặc sản', 'Đố vui về văn hóa địa phương', 'Đoán món ăn bằng gợi ý', 'Ghép bản đồ hành trình', 'Truy tìm vật phẩm trong làng', 'Phối hợp giữ bóng', 'Thử thách khéo tay', 'Ghi nhớ lời bài hát']
  };
  function year(l) { return l.birthYear + l.age; }
  function free(l) { return l.alive && !(l.jailUntil != null && l.age < l.jailUntil) && !(l.abroad && l.abroad.trapped) && !(l.flags.military && l.age < l.flags.military); }
  function musicBusy(l) { var t = l.flags.tv; return !!(t && !t.done && !t.out && !t.no); }
  function season(l) { return l.flags.variety; }
  function busy(l) { var v = season(l); return !!(v && !v.done); }
  function invite(l) { var c = l.job && E.jobDef(l); return free(l) && H.isVN(l) && l.age >= 18 && l.age <= 55 && l.st.hea >= 45 && (l.fame || 0) >= 1e5 && c && /^(show|media|creator|sport)$/.test(c.cat) && !musicBusy(l) && !busy(l) && !(season(l) && season(l).year === year(l)); }
  function shuffle(r, a) { a = a.slice(); for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(r() * (i + 1)), x = a[i]; a[i] = a[j]; a[j] = x; } return a; }
  function pick(r, a) { return U.pick(r, a); }
  function valid(l, d) { var v = season(l); return free(l) && !!v && !v.done && v.year === year(l) && l.st.hea >= 25 && stages(v).indexOf(v.stage)>=0 && (!d || d.token == null || (d.token === v.token && d.ep === v.ep && d.stage === v.stage)); }
  function guests(l, r) {
    var all = [], seen = {};
    ['vn', 'rapvn'].forEach(function (cat) { E.CONCERT_CATS[cat].a.forEach(function (a) { if (year(l) - a.b >= 18 && year(l) - a.b <= 60 && a.n !== l.name && !seen[a.n]) { seen[a.n] = 1; all.push(a.n); } }); });
    var count=season(l).role==='guest'?1:2;
    all = shuffle(r, all).slice(0, count);
    for (var tries = 0; all.length < count && tries < 50; tries++) { var n = H.stranger(l, r, r() < 0.5 ? 'M' : 'F'); if (n !== l.name && all.indexOf(n) < 0) all.push(n); }
    return all;
  }
  function episode(l, r) {
    var v = season(l), cast = v.regulars.concat(guests(l, r)).filter(function (n, i, a) { return n !== l.name && a.indexOf(n) === i; });
    for (var tries = 0; cast.length < 7 && tries < 50; tries++) { var n = H.stranger(l, r, r() < 0.5 ? 'M' : 'F'); if (n !== l.name && cast.indexOf(n) < 0) cast.push(n); }
    cast = shuffle(r, cast).slice(0, 7);
    v.team = [l.name].concat(cast.slice(0, 3)); v.opponents = cast.slice(3);
    v.guests = (v.role==='guest'?[l.name]:[]).concat(cast.filter(function (n) { return v.regulars.indexOf(n) < 0; }));
    v.location = v.routes[v.ep]; v.task = v.tasks[v.ep]; v.score = 0; v.style = 0; v.stage = v.compact ? 1 : 0; v.clues = 0;
  }
  function finish(l, log, reason) {
    var v = season(l); if (!v || v.done) return;
    v.done = true; v.reason = reason || 'completed';
    var earned = Math.round(v.fee * v.completed / v.total);
    if (!v.paid) { v.paid = true; v.earned = earned; if (earned > 0) H.cash(l, earned, 'Cát-xê ' + TITLES[v.k] + ' (' + v.completed + '/' + v.total + ' tập)'); }
    log((reason ? 'Dừng lịch quay ' : 'Hoàn tất mùa mô phỏng ') + TITLES[v.k] + ' với vai trò '+roleName(v)+': đã quay ' + v.completed + '/' + v.total + ' tập, thắng ' + v.wins + ' tập. Khán giả quan tâm thêm: '+(v.audienceGain||0)+' người theo dõi. Cát-xê thực nhận ' + H.money(l, earned) + (reason ? '. Lý do: ' + reason + '.' : '.'), reason ? 'neutral' : 'big');
    l.pending = l.pending.filter(function (d) { return d.id !== 'vr_vong'; });
  }
  function queue(l, r, log) { if (!valid(l)) { finish(l, log, 'không thể tiếp tục lịch quay'); return; } var d = E.DEC.vr_vong.make(l, r); if (season(l).manual) d.manual = true; l.pending.unshift(d); }
  function start(l, r, log, d, k, role) {
    if (!invite(l) || !ROLES[role]) { log('Không thể nhận thêm lịch quay lúc này: lịch trùng hoặc chưa đáp ứng điều kiện.', 'neutral'); return; }
    var regulars = [], tries = 0;
    while (regulars.length < (role==='guest'?6:5) && tries++ < 60) { var n = H.stranger(l, r, r() < 0.5 ? 'M' : 'F'); if (n !== l.name && regulars.indexOf(n) < 0) regulars.push(n); }
    l.flags.varietySerial = (l.flags.varietySerial || 0) + 1;
    l.flags.variety = { compact: true, k: k, token: l.flags.varietySerial, year: year(l), age: l.age, role:role, manual:!!d.manual, ep: 0, total: ROLES[role].total, completed: 0, wins: 0, fee: quote(d.fee,role), audienceGain:0, paid: false, regulars: regulars, routes: shuffle(r, LOCATIONS).slice(0, ROLES[role].total), tasks: shuffle(r, TASKS[k]).slice(0, ROLES[role].total), history: [] };
    episode(l, r);
    log('Nhận lời tham gia ' + TITLES[k] + ' làm '+roleName(season(l))+': '+season(l).total+' tập mô phỏng trong năm '+year(l) + ', dự kiến cát-xê ' + H.money(l, season(l).fee) + '. Quyết toán theo số tập thực sự hoàn thành; mỗi tập phát sóng giúp bạn được khán giả biết đến hơn.', 'big');
    queue(l, r, log);
  }
  function offerValid(l,d) { var o=l.flags.varietyOffer;return invite(l)&&!!o&&o.year===year(l)&&(!d||d.token==null||(d.token===o.token&&d.k===o.k&&d.year===o.year)); }
  function selectShow(l,r,log,d,k) {
    if(!invite(l))return;
    var token=l.flags.varietyOfferSerial=(l.flags.varietyOfferSerial||0)+1;
    l.flags.varietyOffer={k:k,fee:Math.max(0,Number(d.fee)||0),year:year(l),token:token};
    l.pending.unshift(E.DEC.vr_vai_tro.make(l,r));
  }
  E.SC('vr_vai_tro',{
    title:function(l,d){return 'Vai trò trong '+(TITLES[d.k]||'game show');},valid:offerValid,
    prep:function(l){return Object.assign({},l.flags.varietyOffer||{});},
    text:function(l,d){return 'Bạn muốn tham gia '+(TITLES[d.k]||'chương trình')+' với vai trò nào? Khách mời quay 2 tập, mỗi tập 3 chặng lựa chọn. Thành viên cố định quay 6 tập mô phỏng trong năm, mỗi tập 5 chặng và gắn bó với dàn cast lâu hơn. Cả hai đều có khách mời, chia đội ngẫu nhiên và được khán giả quan tâm sau mỗi tập hoàn thành. Chưa quay thì chưa nhận cát-xê.';},
    opts:['guest','regular'].map(function(role){return{k:role,l:role==='guest'?'Làm khách mời · 2 tập':'Làm thành viên cố định · 6 tập',h:function(l,d){return (role==='guest'?'6':'30')+' lượt lựa chọn · cát-xê trọn lịch '+H.money(l,quote(d.fee,role))+' · quyết toán theo số tập hoàn thành';},ai:{w:role==='guest'?1:.8},run:function(l,r,log,d){if(!offerValid(l,d))return;var offer=l.flags.varietyOffer;delete l.flags.varietyOffer;start(l,r,log,offer,offer.k,role);}};}).concat([{k:'no',l:'Chưa nhận lịch quay',ai:{w:.15},run:function(l){delete l.flags.varietyOffer;}}])
  });
  var roleApply=E.DEC.vr_vai_tro.apply;
  E.DEC.vr_vai_tro.apply=function(l,d){if(!offerValid(l,d.data))return;return roleApply.apply(this,arguments);};
  E.DEC.gameshow.def.valid = invite;
  E.DEC.gameshow.def.text = function () { return 'Chọn chương trình để xem hai hình thức tham gia: khách mời 2 tập hoặc thành viên cố định 6 tập mô phỏng. Màn tiếp theo hiển thị số sự kiện và cát-xê của từng vai trò. Mỗi tập hoàn thành đều giúp tăng danh tiếng, dù thắng hay thua.'; };
  E.DEC.gameshow.def.opts.forEach(function (o) { if (TITLES[o.k]) o.run = function (l, r, log, d) { selectShow(l,r,log,d,o.k); }; else if (o.k === 'no') o.l = 'Từ chối, giữ lịch hiện tại'; });
  var invitationApply = E.DEC.gameshow.apply;
  E.DEC.gameshow.apply = function(l,d){var result=invitationApply.apply(this,arguments);if(l.pending[0]&&l.pending[0].id==='vr_vai_tro'){l.pending[0].manual=!!d.manual;if(l.flags.varietyOffer)l.flags.varietyOffer.manual=!!d.manual;}return result;};
  // Màn hậu trường cũ không còn chạy độc lập hoặc cộng danh tiếng vô hạn.
  E.DEC.gameshow_dong.def.valid = function () { return false; };
  E.ACT.push({ id: 'gameshow_moi', g: 'Công việc', l: 'Xem lời mời Running Man / 2 Ngày 1 Đêm', min: 18, max: 55, sc: 'gameshow', avail: function (l) { return invite(l) ? true : 'Cần danh tiếng, nghề phù hợp, sức khỏe và lịch quay trống'; } });

  function name(v) { return [v.role==='guest'?(v.ep===0?'Ra mắt cùng dàn thành viên cố định':'Trở lại giao lưu và chia đội'):(v.ep===0?'Ra mắt dàn thành viên cố định':'Họp dàn cố định, đón khách mời và chia đội'), v.task, v.k === 'hai' ? 'Trò chơi giành bữa tối' : 'Săn manh mối bí mật', v.k === 'hai' ? 'Thử thách giành chỗ ngủ' : 'Biến số đổi đội', v.k === 'hai' ? 'Nhiệm vụ buổi sáng' : 'Cuộc đua xé bảng tên'][v.stage]; }
  function describe(l) {
    var v = season(l);
    return U.cap(roleName(v))+' · Tập ' + (v.ep + 1) + '/' + v.total + ' tại ' + v.location + ', quay trong năm ' + v.year + '. Khách mời: ' + v.guests.join(', ') + '.\nĐội bạn: ' + v.team.join(', ') + '. Đội đối thủ: ' + v.opponents.join(', ') + '.\nĐiểm tập này: ' + v.score + '. ' +
      (v.stage === 0 ? 'Dàn thành viên và diễn biến trong game là mô phỏng. Bạn muốn bắt nhịp với đội và tạo dấu ấn với khán giả như thế nào?' : v.stage === 2 && v.k === 'hai' ? 'Thắng được chọn món đặc sản; thua vẫn có suất ăn cơ bản, không bị bỏ đói.' : v.stage === 3 && v.k === 'hai' ? 'Thắng được ngủ trong nhà; đội thua ngủ lều có ê-kíp hỗ trợ.' : v.stage === 3 ? 'Bốc thăm đổi một đồng đội với đội đối thủ, giữ nguyên điểm đã kiếm. Bạn muốn phối hợp thế nào với người mới?' : v.stage === 4 && v.k === 'rm' ? 'Manh mối từ những vòng trước giúp đội bạn trong cuộc đua cuối. Xé bảng tên là trò chơi có giám sát, không phải đánh nhau ngoài đời.' : 'Kết quả phụ thuộc sức khỏe, phối hợp, cách chơi và may mắn; không phải cứ chọn liều là thắng.');
  }
  function play(l, r, log, d, how) {
    if (!valid(l, d)) return; // chặn lựa chọn cũ sau khi đã sang vòng khác
    var v = season(l), stage = v.stage, title = v.compact && v.challengeName51 ? v.challengeName51 : name(v);
    if (how === 'quit') { finish(l, log, 'chủ động xin dừng'); return; }
    if (stage === 0) { v.style = how === 'team' ? 0.1 : how === 'mind' ? 0.05 : 0; log('Tập ' + (v.ep + 1) + ' ' + TITLES[v.k] + ': gặp ' + v.guests.join(', ') + ', vào đội cùng ' + v.team.slice(1).join(', ') + '.', 'neutral'); }
    else {
      var effort = how === 'hard', mental = how === 'mind';
      var p = U.clamp(0.25 + l.st.hea / 400 + l.st.soc / 700 + (mental ? l.st.kno / 500 : 0) + v.style + (effort ? 0.12 : 0.03) + (stage === 4 ? v.clues * 0.03 : 0), 0.15, 0.88);
      var won = r() < p, points = stage === 4 ? 3 : stage === 1 ? 2 : 1;
      if (won) { v.score += points; if (v.k === 'rm' && stage === 2) v.clues++; }
      H.fx(l, { hea: effort ? -3 : -1, hap: won ? 2 : -1, soc: how === 'team' ? 1 : 0 });
      if (effort && r() < 0.08) { v.injured = true; H.fx(l, { hea: -8 }); log('Tập ' + (v.ep + 1) + ' ' + TITLES[v.k] + ': bị căng cơ nhẹ, ê-kíp y tế yêu cầu ngừng các phần vận động mạnh.', 'bad'); }
      log('Tập ' + (v.ep + 1) + ' ' + TITLES[v.k] + ' · ' + title + ': ' + (won ? 'đội bạn vượt thử thách, cộng ' + points + ' điểm.' : 'đội đối thủ nhỉnh hơn, đội bạn không có thêm điểm.') + (v.k === 'hai' && stage === 2 ? (won ? ' Được thưởng bữa đặc sản.' : ' Ăn suất cơ bản do ê-kíp chuẩn bị.') : '') + (v.k === 'hai' && stage === 3 ? (won ? ' Đội được ngủ trong nhà.' : ' Đội ngủ lều có người hỗ trợ.') : ''), won ? 'good' : 'neutral');
    }
    if (v.k === 'rm' && stage === 2) {
      var a = Math.floor(r() * (v.team.length - 1)) + 1, b = Math.floor(r() * v.opponents.length), member = v.team[a];
      v.team[a] = v.opponents[b]; v.opponents[b] = member;
      log('Tập ' + (v.ep + 1) + ' ' + TITLES[v.k] + ' · Bốc thăm đổi đội: ' + member + ' sang đội đối thủ, ' + v.team[a] + ' về đội bạn; điểm được giữ nguyên.', 'neutral');
    }
    v.history.push({ ep: v.ep, stage: stage, task: title, team: v.team.slice(), opponents: v.opponents.slice(), score: v.score });
    if (stage === 4) {
      v.completed++; var victory = v.score >= (v.role==='guest'?3:4); if (victory) v.wins++;
      var followers = v.role==='guest'?(victory?18000:6000):(victory?24000:9000);
      l.fame = (l.fame || 0) + followers; v.audienceGain=(v.audienceGain||0)+followers;
      var audience=l.flags.tvAudience||(l.flags.tvAudience={episodes:0,followers:0}); audience.episodes++;audience.followers+=followers;
      var reaction=v.role==='guest'?['Khán giả chú ý màn ra mắt của khách mời, chia sẻ đoạn bạn phối hợp cùng dàn cast.','Kết thúc lịch khách mời, khán giả bình luận mong được gặp lại bạn.'][v.ep]:['Khán giả bắt đầu nhớ tên bạn trong dàn cố định.','Những màn phối hợp với đồng đội được cắt thành clip chia sẻ.','Khán giả nhớ nét riêng và cách bạn xử lý trò chơi.','Bạn dần có nhóm khán giả theo dõi các tập mới.','Khán giả bàn luận về tình đồng đội và những lần bạn vượt thử thách.','Khép lại lịch quay, khán giả nhắc đến hành trình của bạn cùng dàn cast.'][v.ep%6];
      log(TITLES[v.k]+' · Tập '+(v.ep+1)+' · Phản hồi khán giả: '+reaction+' Thêm '+followers+' người theo dõi, kể cả khi không thắng trò chơi.','good');
      log('Kết thúc tập ' + (v.ep + 1) + ' ' + TITLES[v.k] + ': ' + (victory ? 'đội bạn thắng' : 'đội đối thủ thắng') + ', tổng ' + v.score + ' điểm. Cả ê-kíp cùng chào khán giả.', victory ? 'good' : 'neutral');
      if (v.completed >= v.total) { finish(l, log); return; }
      v.ep++; episode(l, r);
    } else { var order=stages(v);v.stage=order[order.indexOf(stage)+1]; }
    queue(l, r, log);
  }
  function opt(k, label) { return { k: k, l: label, ai: { w: k === 'quit' ? 0.05 : 1 }, req: function (l, d) { return valid(l, d) && (k !== 'hard' || (!season(l).injured && l.st.hea >= 55 && season(l).stage > 0)); }, run: function (l, r, log, d) { play(l, r, log, d, k); } }; }
  E.SC('vr_vong', {
    title: function (l) { var v = season(l); return TITLES[v.k] + ' · '+U.cap(roleName(v))+' · Tập ' + (v.ep + 1) + ' · ' + name(v); },
    valid: valid,
    prep: function (l) { var v = season(l); return { token: v.token, ep: v.ep, stage: v.stage }; },
    text: describe,
    opts: [opt('team', 'Phối hợp đồng đội, chơi vừa sức'), opt('mind', 'Quan sát, giải đố và bàn chiến thuật'), opt('hard', 'Xung phong phần vận động khó'), opt('quit', 'Xin dừng quay để giữ sức')]
  });
  E.MAJOR.vr_vong = 1;

  // Không nhận hai mùa quay chồng nhau, không tiếp tục thi đấu khi đã bị giam.
  var musicValid = E.DEC.tv_moi.valid;
  E.DEC.tv_moi.valid = function (l) { return free(l) && !busy(l) && musicValid.apply(this, arguments); };
  var musicApply = E.DEC.tv_moi.apply;
  E.DEC.tv_moi.apply = function (l, d, k, r, log) { if (k === 'nhan' && (!free(l) || busy(l) || musicBusy(l))) { log('Không nhận lời vì lịch quay hoặc tình trạng hiện tại không cho phép.', 'neutral'); return; } return musicApply.apply(this, arguments); };
  ['tv_vong', 'tv_loai', 'tv_tap_nhay'].forEach(function (id) {
    var def = E.DEC[id], before = def.valid, make = def.make, apply = def.apply;
    def.valid = function (l, d) { return free(l) && !busy(l) && musicBusy(l) && (!d || d.round == null || d.round === l.flags.tv.i) && before.apply(this, arguments); };
    def.make = function (l) { var d = make.apply(this, arguments); d.data.round = l.flags.tv.i; return d; };
    def.apply = function (l, d) { if (!def.valid(l, d.data)) return; return apply.apply(this, arguments); };
  });
  function interrupt(l, log, reason) { if (busy(l)) finish(l, log, reason); if (musicBusy(l)) { l.flags.tv.done = true; l.flags.tv.out = true; l.flags.tv.res = 'interrupted'; log('Dừng hành trình ' + l.flags.tv.s + ' vì ' + reason + '.', 'neutral'); } }
  ['jail', 'kill'].forEach(function (key) { var before = H[key]; H[key] = function (l) { var log = arguments[key === 'jail' ? 3 : 2]; if (typeof log === 'function') interrupt(l, log, key === 'jail' ? 'không thể tiếp tục lịch quay khi chấp hành án' : 'hành trình cuộc đời kết thúc'); return before.apply(this, arguments); }; });
  function varietyYear(l, r, log) { var v = season(l); if (busy(l) && (v.year !== year(l) || !free(l) || l.st.hea < 25)) finish(l, log, 'lịch quay đã hết hạn hoặc sức khỏe không cho phép'); }
  E.HOOKS.year.push(varietyYear);
  E.VARIETY = { roles:ROLES, quote:quote, titles: TITLES, tasks: TASKS, canInvite: invite, valid: valid, year: varietyYear };
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
/* ===== js/life49.js ===== */
/* v4.5.3 — thâm niên thật, bối cảnh khởi đầu và quan hệ chu cấp có điều kiện. */
(function (G) {
  'use strict';
  var E = G.E, H = E.H, U = G.U;
  function free(l) { return l.alive && l.age >= 18 && !(l.jailUntil != null && l.age < l.jailUntil) && !(l.abroad && l.abroad.trapped) && !(l.flags.military && l.age < l.flags.military); }
  E.canAdvance = function (l, c, yearEnd) {
    if (!l.job || !c || l.job.rank >= c.t.length - 1) return false;
    if (c.fame || c.skillRank != null) return true;
    var j = l.job, min = c.minAge || 15;
    if (l.age < min) return false;
    if (j.rankSince == null) {
      var h = (l.jobsHist || []).filter(function (h) { return E.resolveJob(h.id) === c.id; }).pop();
      j.rankSince = Math.max(min, h ? h.from : l.age - Math.min(j.yrs || 0, l.workYrs == null ? j.yrs || 0 : l.workYrs));
      j.rankTracked = j.rank;
    }
    if (j.rankTracked !== j.rank) { j.rankSince = l.age; j.rankTracked = j.rank; }
    return l.age - j.rankSince + (yearEnd ? 1 : 0) >= Math.max(1, (c.yrs && c.yrs[j.rank]) || 3);
  };
  // Chỉ xin xét lương một lần mỗi năm; "điểm kinh nghiệm" không thay năm công tác.
  var raise = E.DEC.tang_luong;
  raise.def.opts.forEach(function (o) { if (o.k !== 'ask') return;
    o.req = function (l) { return !!l.job && l.job.raiseAt !== l.age && l.flags.raiseAt !== l.age; };
    o.run = function (l, r, log) {
      var j = l.job, c = E.jobDef(l); if (!j || j.raiseAt === l.age || l.flags.raiseAt === l.age) return;
      j.raiseAt = l.age; l.flags.raiseAt = l.age;
      var p = 0.15 + (l.st.kno - 50) / 200 + Math.min(4, j.yrs || 0) * 0.04;
      if (!c.ladder && E.canAdvance(l, c, false) && r() < p) {
        j.rank++; j.yrs = 0; j.rankSince = l.age; j.rankTracked = j.rank;
        log('Được xét thăng chức sau thời gian công tác: ' + E.jobTitle(l) + '.', 'good'); H.fx(l, { hap: 6 });
      } else if (r() < 0.5) { H.cash(l, l.base * 0.05, 'Thưởng công việc trong năm'); log('Chưa đủ điều kiện thăng chức; được thưởng một khoản trong năm.', 'neutral'); }
      else { log('Đề xuất được ghi nhận, tiếp tục tích lũy kinh nghiệm cho kỳ xét sau.', 'neutral'); }
    };
  });
  E.ACT.forEach(function (a) { if (a.id === 'tang_luong') { var before = a.avail; a.avail = function (l) { var x = before ? before(l) : true; return x === true && l.job && (l.job.raiseAt === l.age || l.flags.raiseAt === l.age) ? 'Đã xét lương trong năm nay' : x; }; } });

  // Biến thể cố định theo nhân vật: vẽ lại giao diện không đổi câu hoặc tiêu hao RNG cuộc đời.
  E.birthContext = function (l) {
    var f = l.fam || {}, seed = 2166136261, key = [l.name, l.birthYear, l.birthMonth, l.pool].join('|');
    for (var i = 0; i < key.length; i++) seed = Math.imul(seed ^ key.charCodeAt(i), 16777619) >>> 0;
    function choose(a) { seed ^= seed << 13; seed ^= seed >>> 17; seed ^= seed << 5; return a[(seed >>> 0) % a.length]; }
    var wealth = [null,
      ['Gia đình nghèo, thu nhập chỉ vừa đủ lo bữa ăn hằng ngày', 'Nhà thiếu thốn, khoản chi nào cũng phải cân nhắc', 'Kinh tế chật vật, gia đình chưa có khoản dự phòng', 'Gia đình nghèo, chuyện học hành cần được dành dụm từ sớm'],
      ['Gia đình có thu nhập thấp, sống tiết kiệm', 'Kinh tế còn eo hẹp, phải chắt chiu từng tháng', 'Nhà không dư dả, ưu tiên các nhu cầu thiết yếu', 'Gia đình ít tiền tích lũy, khó xoay xở khi có khoản chi lớn'],
      ['Gia đình có kinh tế trung bình, cuộc sống vừa đủ', 'Thu nhập gia đình đủ trang trải sinh hoạt, không quá dư dả', 'Nhà có mức sống bình dân, các khoản lớn cần lên kế hoạch', 'Gia đình không giàu, nhưng có thể lo những nhu cầu cơ bản'],
      ['Gia đình khá giả, có điều kiện đầu tư cho việc học', 'Kinh tế gia đình tương đối dư dả, ít áp lực chi tiêu thường ngày', 'Nhà khá giả, có khoản dự phòng cho tương lai', 'Gia đình có điều kiện, việc ăn ở và học hành thuận lợi'],
      ['Gia đình giàu có, nền tảng tài chính vững vàng', 'Sinh ra trong gia đình giàu, có nhiều lựa chọn học tập', 'Nhà rất dư dả, tiền sinh hoạt ít khi là nỗi lo', 'Gia đình giàu có, có nguồn lực hỗ trợ con cái lập nghiệp']
    ];
    var q = Math.max(1, Math.min(5, Math.round(f.q || 3))), parts = [choose(wealth[q])], severe = false;
    var mom = f.mAlive !== false, dad = f.fAlive !== false && !f.noDad;
    if (!mom && !dad) { parts.push('không còn bố mẹ bên cạnh từ khi chào đời'); severe = true; }
    else {
      if (f.vice && dad) { parts.push('bố ' + (E.VICE[f.vice] || 'gặp vấn đề nghiêm trọng') + ', khiến cuộc sống trong nhà nhiều bất ổn'); severe = true; }
      if (f.noDad && mom) parts.push(choose(['mẹ một mình chăm sóc và vun vén cho con', 'lớn lên bên mẹ, thiếu sự hiện diện của bố', 'mẹ đảm đương việc chăm sóc và nuôi con']));
      else if (!dad && mom) parts.push('mẹ là người trực tiếp chăm sóc, bố đã mất');
      else if (!mom && dad) parts.push('bố chăm sóc con sau khi mẹ qua đời');
      if (!severe) {
        var adult = mom && dad ? 'bố mẹ' : mom ? 'mẹ' : 'bố';
        parts.push(choose([
          adult + ' coi trọng thành tích, kỳ vọng con học giỏi và có nghề ổn định',
          adult + ' ưu tiên sức khỏe, mong con lớn lên vui vẻ',
          adult + ' đặt nhiều quy tắc, con được chăm lo nhưng ít tự quyết',
          adult + ' khuyến khích tự lập, cho con thử sở thích riêng',
          adult + ' thường bận công việc, thời gian dành cho con còn hạn chế',
          adult + ' coi trọng nề nếp, thường nhắc con cư xử lễ phép',
          adult + ' quan tâm nhưng hay lo xa, muốn biết rõ mọi lựa chọn của con',
          adult + ' sẵn sàng lắng nghe, ít so sánh con với người khác'
        ]));
      }
      if ((dad && f.fJob === 'thất nghiệp') || (mom && f.mJob === 'thất nghiệp')) parts.push('trong nhà đang có người chưa tìm được việc');
      if (f.elite) parts.push(choose(['gia đình mong con nối nghiệp, tạo thêm áp lực lựa chọn tương lai', 'gia thế đem lại cơ hội nhưng cũng khiến con bị kỳ vọng giữ danh tiếng', 'có nền tảng nghề nghiệp từ gia đình, song con vẫn phải tìm hướng đi riêng']));
      if (f.sibs >= 4) parts.push('nhà đông anh chị em, sự quan tâm và nguồn lực phải chia sẻ');
      else if (f.sibs > 0) parts.push('có anh chị em cùng lớn lên, vừa có bạn vừa phải học cách nhường nhịn');
    }
    if (!l.urban && l.coast) parts.push(choose(['sống ở vùng ven biển, nhịp sinh hoạt gắn với thời tiết', 'môi trường lớn lên là một vùng ven biển']));
    else if (E.isVN(l) && l.region === 'MNPB' && !l.urban) parts.push('sống ở vùng núi, việc đi lại và đến trường có thể xa');
    return { label: 'Bối cảnh gia đình', severe: severe, text: parts.join('; ') + '.' };
  };

  function money(l, tr) { return H.isVN(l) && l.cur === 'vnd' && !(l.abroad && l.abroad.perm) ? tr : tr / 90 * l.base; }
  function state(l) { return l.flags.sponsor; }
  function allowance(l, s) { return s.cur && s.cur !== l.cur ? money(l, s.nominal) : s.monthly; }
  function supported(l) { var s = state(l), p = l.partner; return free(l) && !!s && s.active && !!p && p.alive !== false && p.name === s.name; }
  function canOffer(l, d) {
    if (!free(l) || l.age > 40 || (state(l) && state(l).active)) return false;
    if (d && d.expectedName !== undefined && (l.partner ? l.partner.name : '') !== d.expectedName) return false;
    return !l.partner || (l.partner.status === 'dating' && l.partner.alive !== false && l.partner.age - l.age >= 10 && l.partner.inc >= money(l, 150));
  }
  function endSupport(l, log, breakup) {
    var s = state(l); if (!s || !s.active) return;
    s.active = false;
    if (breakup && l.partner && l.partner.name === s.name) { l.partner = null; l.exes = (l.exes || 0) + 1; }
    log(breakup ? 'Chấm dứt quan hệ với ' + s.name + ', ngừng nhận chu cấp. Tiền và tài sản riêng vẫn thuộc về bạn.' : 'Ngừng nhận chu cấp, giữ công việc, bạn bè và quyền tự quyết. Nếu tiếp tục tìm hiểu nhau, hai người cần một mối quan hệ bình đẳng.', 'neutral');
  }
  function boundary(l, r, log) {
    var s = state(l);
    var x = r();
    if (x < 0.55) { s.control = Math.max(0, s.control - 15); log(s.name + ' đồng ý lùi lại, tôn trọng giới hạn bạn đặt ra, vẫn chu cấp đều đặn như cũ.', 'good'); H.fx(l, { hap: 3, soc: 2 }); }
    else if (x < 0.8) { s.control = Math.max(0, s.control - 5); log(s.name + ' không vui, giận dỗi mấy hôm, nhưng vẫn gửi khoản chu cấp như đã hứa. Bạn không phải đổi quyền riêng tư lấy tiền.', 'neutral'); H.fx(l, { hap: 1 }); }
    else { s.withheldUntil = l.age; log(s.name + ' không đồng ý và ngừng khoản chu cấp trong năm nay. Bạn vẫn có thể tự đi làm hoặc chấm dứt quan hệ.', 'bad'); H.fx(l, { hap: -3 }); }
  }
  E.SC('sn_loi_moi', {
    title: 'Một lời đề nghị chu cấp', valid: canOffer,
    prep: function (l, r) {
      var p = l.partner ? Object.assign({}, l.partner) : { age: l.age + U.randint(r, 12, 25), job: U.pick(r, ['chủ doanh nghiệp', 'nhà đầu tư', 'chủ chuỗi khách sạn']), inc: money(l, U.randint(r, 400, 1200)) };
      // Tên và giới tính phải được sinh từ cùng một lựa chọn tương thích xu hướng.
      if (!l.partner) { p.sex = H.partnerSex(l, r); p.name = H.stranger(l, r, p.sex); }
      if (!p.job) p.job = 'kinh doanh / đầu tư';
      return { p: p, expectedName: l.partner ? l.partner.name : '', monthly: Math.min(p.inc * 0.2, money(l, U.randint(r, 40, 160))) };
    },
    text: function (l, d) { return d.p.name + ', ' + d.p.age + ' tuổi, ' + d.p.job + ', ngỏ lời tìm hiểu và chu cấp khoảng ' + H.money(l, d.monthly) + '/tháng. Đổi lại, người ấy muốn biết bạn đi đâu, gặp ai và có thể gây áp lực lên công việc, cách ăn mặc, quan hệ bạn bè. Bạn có quyền từ chối hoặc rút lui sau này; nhận tiền không làm mất quyền tự quyết.'; },
    opts: [
      { k: 'accept', l: 'Nhận lời, bắt đầu mối quan hệ có chu cấp', req: canOffer, ai: { w: 0.5 }, run: function (l, r, log, d) {
        if (!canOffer(l, d)) return;
        if (!l.partner) { l.partner = { name: d.p.name, sex: d.p.sex, age: d.p.age, job: d.p.job, jobId: null, inc: d.p.inc, incKnown: true, status: 'dating', since: l.age, alive: true }; l.flags.everDated = true; if (!l.flags.firstLove) l.flags.firstLove = d.p.name; }
        l.flags.sponsor = { name: d.p.name, active: true, monthly: d.monthly, cur: l.cur, nominal: d.monthly / money(l, 1), control: 35, since: l.age };
        log('Nhận lời tìm hiểu ' + d.p.name + ' và khoản chu cấp dự kiến ' + H.money(l, d.monthly) + '/tháng. Khoản thực nhận phụ thuộc quan hệ còn tiếp tục và điều kiện trong năm.', 'big');
        H.chain(l, 'sn_kiem_soat');
      } },
      { k: 'decline', l: 'Từ chối, muốn tự chủ tài chính và tình cảm', ai: { w: 1.2 }, run: function (l, r, log) { log('Từ chối lời đề nghị, giữ tự chủ về tài chính và tình cảm.', 'neutral'); } }
    ]
  });
  function options(comply) { return [
    { k: 'comply', l: comply, ai: { w: 0.6 }, run: function (l, r, log) { var s = state(l); s.control = Math.min(100, s.control + 15); H.fx(l, { hap: -4, soc: -3 }); if (l.mind) l.mind.stress = Math.min(100, l.mind.stress + 7); log('Chấp nhận yêu cầu. Khoản tiền giúp bớt áp lực sinh hoạt, nhưng bạn ngày càng cảm thấy bị kiểm soát.', 'bad'); } },
    { k: 'boundary', l: 'Đặt ranh giới, không đổi quyền riêng tư lấy tiền', ai: { w: 1.2 }, run: boundary },
    { k: 'stop', l: 'Dừng nhận chu cấp', ai: { w: 0.8 }, run: function (l, r, log) { endSupport(l, log, false); } },
    { k: 'leave', l: 'Chấm dứt mối quan hệ', ai: { w: 0.5 }, run: function (l, r, log) { endSupport(l, log, true); } }
  ]; }
  function scene(id, title, text, opts) {
    E.SC(id, { title: title, text: text, prep: function (l) { return { name: state(l).name }; }, valid: function (l, d) { return supported(l) && (!d || !d.name || d.name === state(l).name); }, opts: opts || options('Nhượng bộ lần này') });
    var apply = E.DEC[id].apply; E.DEC[id].apply = function (l, d, k, r, log) { if (!E.DEC[id].valid(l, d.data)) return; return apply.call(this,l,d,k,r,function(t,tone){log(title+': '+t,tone);}); };
  }
  scene('sn_kiem_soat', 'Tiền bạc và quyền riêng tư', function (l) { return state(l).name + ' muốn bạn luôn báo vị trí và cho xem điện thoại. Bạn thấy mình đang phải giải thích từng cuộc gặp gỡ.'; }, options('Đồng ý báo lịch trình và cho xem điện thoại'));
  scene('sn_ban_be', 'Một cuộc hẹn bị ngăn cản', 'Người chu cấp không muốn bạn đi gặp nhóm bạn thân, viện lý do đã lo tiền cho bạn thì bạn nên ưu tiên người ấy.', options('Hủy buổi gặp bạn bè'));
  scene('sn_an_mac', 'Áp lực thay đổi hình ảnh', 'Người ấy yêu cầu bạn thay đổi quần áo và cách xuất hiện trên mạng xã hội cho vừa ý mình.', options('Làm theo yêu cầu về quần áo và mạng xã hội'));
  scene('sn_nghi_viec', 'Muốn bạn nghỉ việc', 'Người ấy nói sẽ lo sinh hoạt phí nếu bạn nghỉ việc, tránh tiếp xúc với đồng nghiệp. Nghỉ việc khiến bạn mất nguồn thu riêng.', [
    { k: 'quit', l: 'Đồng ý nghỉ việc, chấp nhận phụ thuộc hơn', req: function (l) { return !!l.job; }, ai: { w: 0.3 }, run: function (l, r, log) { l.lastJob = l.job; l.job = null; l.flags.needJob = false; state(l).control = Math.min(100, state(l).control + 25); log('Chủ động nghỉ việc theo đề nghị. Bạn vẫn có quyền tìm việc lại sau này, nhưng hiện chỉ còn trông vào khoản chu cấp.', 'bad'); H.fx(l, { hap: -4 }); } },
    { k: 'keep', l: 'Giữ công việc và thu nhập của mình', ai: { w: 1.5 }, run: boundary },
    { k: 'stop', l: 'Dừng nhận chu cấp để giữ tự chủ', ai: { w: 1 }, run: function (l, r, log) { endSupport(l, log, false); } }
  ]);
  scene('sn_gian_doan', 'Khoản chu cấp không về', 'Đến kỳ, người ấy trì hoãn khoản tiền đã hứa. Những khoản chi hằng ngày vẫn phải tự xoay xở.', [
    { k: 'talk', l: 'Hỏi rõ, chuẩn bị ngân sách tự lập', ai: { w: 1.3 }, run: function (l, r, log) { state(l).withheldUntil = l.age; log('Không tính khoản tiền chưa nhận là thu nhập. Bắt đầu dự trù chi tiêu bằng tiền đang có.', 'neutral'); } },
    { k: 'wait', l: 'Tiếp tục chờ', ai: { w: 0.7 }, run: function (l, r, log) { state(l).withheldUntil = l.age; H.fx(l, { hap: -4 }); log('Tiếp tục chờ, năm nay không có khoản chu cấp như dự kiến.', 'bad'); } },
    { k: 'stop', l: 'Ngừng phụ thuộc vào khoản tiền này', ai: { w: 1 }, run: function (l, r, log) { endSupport(l, log, false); } }
  ]);
  scene('sn_quan_he', 'Quyền quyết định của bạn', function (l) { var s = state(l); return 'Khoản chu cấp dự kiến: ' + H.money(l, allowance(l, s)) + '/tháng. Mức kiểm soát: ' + s.control + '/100. Bạn có thể đặt lại ranh giới hoặc dừng nhận tiền bất cứ lúc nào.'; }, options('Tiếp tục thỏa thuận hiện tại'));
  E.ACT.push({ id: 'sn_quan_he', g: 'Tình cảm', l: 'Quan hệ chu cấp / đặt lại ranh giới', min: 18, sc: 'sn_quan_he', avail: function (l) { return supported(l) ? true : 'Không có quan hệ chu cấp đang tiếp tục'; } });
  E.TRIG.push({ id: 'sn_loi_moi', when: canOffer, p: 0.13, cd: 4, max: 3 });
  ['sn_kiem_soat', 'sn_ban_be', 'sn_an_mac', 'sn_gian_doan', 'sn_nghi_viec'].forEach(function (id) { E.TRIG.push({ id: id, when: function (l) { return supported(l) && (id !== 'sn_nghi_viec' || !!l.job); }, p: 0.25, cd: 2, rep: true }); });
  E.MAJOR.sn_loi_moi = 1;
  function sponsorYear(l, r, log, a) {
    var s = state(l); if (!s || !s.active) return;
    if (!l.partner || l.partner.name !== s.name || l.partner.alive === false) { s.active = false; return; }
    if (!free(l) || l.partner.status !== 'dating' || s.paidAt === a) return;
    s.paidAt = a;
    if (s.withheldUntil != null && a <= s.withheldUntil) { log('Năm nay không nhận khoản chu cấp đã hứa từ ' + s.name + '.', 'neutral'); return; }
    var monthly = allowance(l, s);
    var amount = Math.min(monthly, Math.max(0, l.partner.inc || 0) * 0.2) * 12;
    H.cash(l, amount, 'Chu cấp tình cảm từ ' + s.name);
    log('Nhận chu cấp thực tế từ ' + s.name + ': ' + H.money(l, amount) + ' trong năm.', 'money');
  }
  E.HOOKS.year.push(sponsorYear);
  E.sponsorYear = sponsorYear;
  E.sponsorActive = supported;
  E.sponsorContributionAllowed = function (l) { var s = state(l); return !s || !s.active || !l.partner || l.partner.name !== s.name || s.withheldUntil == null || l.age > s.withheldUntil; };
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
