/* ===== js/util.js ===== */
/* Một Kiếp Người — tiện ích dùng chung (chạy được cả trên trình duyệt lẫn Node để test) */
(function (G) {
  'use strict';
  G.VERSION = '8.4.1';

  // RNG có seed (mulberry32). Trạng thái lưu thẳng trong object để có thể lưu/tiếp tục.
  function rand(holder) {
    var t = (holder.rs = (holder.rs + 0x6D2B79F5) | 0);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }

  var U = {
    rand: rand,
    newSeed: function () { return (Math.random() * 4294967296) | 0; },
    clamp: function (x, a, b) { return x < a ? a : x > b ? b : x; },
    pick: function (r, arr) { return arr[Math.floor(r() * arr.length)]; },
    chance: function (r, p) { return r() < p; },
    randint: function (r, a, b) { return a + Math.floor(r() * (b - a + 1)); },
    normal: function (r) {
      var u = 1 - r(), v = r();
      return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
    },
    // chọn theo trọng số: items là mảng, w(item, i) trả về trọng số
    wpick: function (r, items, w) {
      var tot = 0, i, ws = [];
      for (i = 0; i < items.length; i++) { var x = Math.max(0, w(items[i], i)); ws.push(x); tot += x; }
      if (tot <= 0) return items[Math.floor(r() * items.length)];
      var t = r() * tot;
      for (i = 0; i < items.length; i++) { t -= ws[i]; if (t < 0) return items[i]; }
      for (i = items.length - 1; i > 0 && !(ws[i] > 0); i--); // v3.0: sai số làm tròn không được chọn phải mục có trọng số 0
      return items[i];
    },
    // "a:3,b:1" -> chọn khóa theo trọng số
    wkey: function (r, spec) {
      var parts = spec.split(',').map(function (s) { var p = s.split(':'); return [p[0].trim(), p.length > 1 ? +p[1] : 1]; });
      return U.wpick(r, parts, function (p) { return p[1]; })[0];
    },
    poisson: function (r, lam) {
      var L = Math.exp(-lam), k = 0, p = 1;
      do { k++; p *= r(); } while (p > L && k < 30);
      return k - 1;
    },
    fmtNum: function (n, d) {
      return Number(n).toLocaleString('vi-VN', { maximumFractionDigits: d == null ? 0 : d, minimumFractionDigits: 0 });
    },
    esc: function (s) {
      return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
        return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
      });
    },
    cap: function (s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) : s; }
  };
  G.U = U;
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
/* ===== js/data-vn.js ===== */
/* Dữ liệu Việt Nam: 63 tỉnh thành (trước 1/7/2025), 34 tỉnh thành (sau sáp nhập), 54 dân tộc.
   Số liệu dân số làm tròn theo Niên giám Thống kê 2023 (nghìn người); tỷ lệ đô thị & chỉ số thu nhập
   tương đối (1.0 = trung bình cả nước) là ước tính từ GSO/VHLSS, chỉ dùng để mô phỏng. */
(function (G) {
  'use strict';
  // [tên tỉnh cũ, vùng, dân số (nghìn), % đô thị, chỉ số thu nhập, tỉnh mới (sau 2025), đô thị trung tâm, ven biển?]
  var RAW63 = [
    ['Hà Nội', 'DBSH', 8436, 49, 1.55, 'Hà Nội', 'Hà Nội', 0],
    ['Hà Giang', 'MNPB', 911, 16, 0.45, 'Tuyên Quang', 'thành phố Hà Giang', 0],
    ['Cao Bằng', 'MNPB', 547, 25, 0.5, 'Cao Bằng', 'thành phố Cao Bằng', 0],
    ['Bắc Kạn', 'MNPB', 327, 21, 0.55, 'Thái Nguyên', 'thành phố Bắc Kạn', 0],
    ['Tuyên Quang', 'MNPB', 805, 15, 0.65, 'Tuyên Quang', 'thành phố Tuyên Quang', 0],
    ['Lào Cai', 'MNPB', 770, 24, 0.95, 'Lào Cai', 'thành phố Lào Cai', 0],
    ['Điện Biên', 'MNPB', 640, 19, 0.45, 'Điện Biên', 'thành phố Điện Biên Phủ', 0],
    ['Lai Châu', 'MNPB', 482, 18, 0.5, 'Lai Châu', 'thành phố Lai Châu', 0],
    ['Sơn La', 'MNPB', 1300, 15, 0.55, 'Sơn La', 'thành phố Sơn La', 0],
    ['Yên Bái', 'MNPB', 846, 21, 0.6, 'Lào Cai', 'thành phố Yên Bái', 0],
    ['Hòa Bình', 'MNPB', 880, 18, 0.65, 'Phú Thọ', 'thành phố Hòa Bình', 0],
    ['Thái Nguyên', 'MNPB', 1336, 37, 1.2, 'Thái Nguyên', 'thành phố Thái Nguyên', 0],
    ['Lạng Sơn', 'MNPB', 802, 21, 0.6, 'Lạng Sơn', 'thành phố Lạng Sơn', 0],
    ['Quảng Ninh', 'DBSH', 1381, 67, 1.75, 'Quảng Ninh', 'thành phố Hạ Long', 1],
    ['Bắc Giang', 'MNPB', 1922, 23, 1.0, 'Bắc Ninh', 'thành phố Bắc Giang', 0],
    ['Phú Thọ', 'MNPB', 1516, 19, 0.75, 'Phú Thọ', 'thành phố Việt Trì', 0],
    ['Vĩnh Phúc', 'DBSH', 1213, 30, 1.25, 'Phú Thọ', 'thành phố Vĩnh Yên', 0],
    ['Bắc Ninh', 'DBSH', 1488, 33, 1.6, 'Bắc Ninh', 'thành phố Bắc Ninh', 0],
    ['Hải Dương', 'DBSH', 1957, 32, 1.05, 'Hải Phòng', 'thành phố Hải Dương', 0],
    ['Hải Phòng', 'DBSH', 2131, 46, 1.6, 'Hải Phòng', 'Hải Phòng', 1],
    ['Hưng Yên', 'DBSH', 1302, 17, 1.05, 'Hưng Yên', 'thành phố Hưng Yên', 0],
    ['Thái Bình', 'DBSH', 1880, 12, 0.8, 'Hưng Yên', 'thành phố Thái Bình', 1],
    ['Hà Nam', 'DBSH', 885, 25, 0.95, 'Ninh Bình', 'thành phố Phủ Lý', 0],
    ['Nam Định', 'DBSH', 1887, 19, 0.75, 'Ninh Bình', 'thành phố Nam Định', 1],
    ['Ninh Bình', 'DBSH', 1010, 23, 0.95, 'Ninh Bình', 'thành phố Hoa Lư', 1],
    ['Thanh Hóa', 'BTB', 3760, 19, 0.8, 'Thanh Hóa', 'thành phố Thanh Hóa', 1],
    ['Nghệ An', 'BTB', 3442, 16, 0.7, 'Nghệ An', 'thành phố Vinh', 1],
    ['Hà Tĩnh', 'BTB', 1323, 22, 0.85, 'Hà Tĩnh', 'thành phố Hà Tĩnh', 1],
    ['Quảng Bình', 'BTB', 916, 21, 0.75, 'Quảng Trị', 'thành phố Đồng Hới', 1],
    ['Quảng Trị', 'BTB', 650, 31, 0.8, 'Quảng Trị', 'thành phố Đông Hà', 1],
    ['Thừa Thiên Huế', 'BTB', 1166, 52, 0.85, 'Huế', 'Huế', 1],
    ['Đà Nẵng', 'NTB', 1245, 87, 1.35, 'Đà Nẵng', 'Đà Nẵng', 1],
    ['Quảng Nam', 'NTB', 1519, 27, 0.85, 'Đà Nẵng', 'thành phố Tam Kỳ', 1],
    ['Quảng Ngãi', 'NTB', 1248, 18, 0.95, 'Quảng Ngãi', 'thành phố Quảng Ngãi', 1],
    ['Bình Định', 'NTB', 1504, 33, 0.85, 'Gia Lai', 'thành phố Quy Nhơn', 1],
    ['Phú Yên', 'NTB', 877, 30, 0.75, 'Đắk Lắk', 'thành phố Tuy Hòa', 1],
    ['Khánh Hòa', 'NTB', 1253, 50, 1.0, 'Khánh Hòa', 'thành phố Nha Trang', 1],
    ['Ninh Thuận', 'NTB', 598, 36, 0.8, 'Khánh Hòa', 'thành phố Phan Rang – Tháp Chàm', 1],
    ['Bình Thuận', 'NTB', 1250, 39, 0.9, 'Lâm Đồng', 'thành phố Phan Thiết', 1],
    ['Kon Tum', 'TN', 580, 32, 0.65, 'Quảng Ngãi', 'thành phố Kon Tum', 0],
    ['Gia Lai', 'TN', 1590, 30, 0.75, 'Gia Lai', 'thành phố Pleiku', 0],
    ['Đắk Lắk', 'TN', 1918, 25, 0.75, 'Đắk Lắk', 'thành phố Buôn Ma Thuột', 0],
    ['Đắk Nông', 'TN', 680, 16, 0.7, 'Lâm Đồng', 'thành phố Gia Nghĩa', 0],
    ['Lâm Đồng', 'TN', 1332, 38, 0.95, 'Lâm Đồng', 'thành phố Đà Lạt', 0],
    ['Bình Phước', 'DNB', 1046, 24, 0.95, 'Đồng Nai', 'thành phố Đồng Xoài', 0],
    ['Tây Ninh', 'DNB', 1190, 31, 0.95, 'Tây Ninh', 'thành phố Tây Ninh', 0],
    ['Bình Dương', 'DNB', 2763, 84, 1.45, 'TP. Hồ Chí Minh', 'thành phố Thủ Dầu Một', 0],
    ['Đồng Nai', 'DNB', 3255, 44, 1.2, 'Đồng Nai', 'thành phố Biên Hòa', 0],
    ['Bà Rịa – Vũng Tàu', 'DNB', 1187, 51, 1.6, 'TP. Hồ Chí Minh', 'thành phố Vũng Tàu', 1],
    ['TP. Hồ Chí Minh', 'DNB', 9456, 78, 1.6, 'TP. Hồ Chí Minh', 'TP. Hồ Chí Minh', 1],
    ['Long An', 'DBSCL', 1735, 17, 1.05, 'Tây Ninh', 'thành phố Tân An', 0],
    ['Tiền Giang', 'DBSCL', 1790, 16, 0.85, 'Đồng Tháp', 'thành phố Mỹ Tho', 1],
    ['Bến Tre', 'DBSCL', 1300, 10, 0.75, 'Vĩnh Long', 'thành phố Bến Tre', 1],
    ['Trà Vinh', 'DBSCL', 1020, 18, 0.75, 'Vĩnh Long', 'thành phố Trà Vinh', 1],
    ['Vĩnh Long', 'DBSCL', 1030, 18, 0.8, 'Vĩnh Long', 'thành phố Vĩnh Long', 0],
    ['Đồng Tháp', 'DBSCL', 1600, 18, 0.75, 'Đồng Tháp', 'thành phố Cao Lãnh', 0],
    ['An Giang', 'DBSCL', 1910, 31, 0.7, 'An Giang', 'thành phố Long Xuyên', 0],
    ['Kiên Giang', 'DBSCL', 1750, 28, 0.85, 'An Giang', 'thành phố Rạch Giá', 1],
    ['Cần Thơ', 'DBSCL', 1250, 70, 1.0, 'Cần Thơ', 'Cần Thơ', 0],
    ['Hậu Giang', 'DBSCL', 730, 28, 0.75, 'Cần Thơ', 'thành phố Vị Thanh', 0],
    ['Sóc Trăng', 'DBSCL', 1200, 33, 0.7, 'Cần Thơ', 'thành phố Sóc Trăng', 1],
    ['Bạc Liêu', 'DBSCL', 920, 28, 0.8, 'Cà Mau', 'thành phố Bạc Liêu', 1],
    ['Cà Mau', 'DBSCL', 1210, 23, 0.75, 'Cà Mau', 'thành phố Cà Mau', 1]
  ];

  // 34 đơn vị sau sáp nhập 2025; cập nhật loại đơn vị đến tháng 10/2026.
  // Giữ thứ tự / ID để tương thích bản lưu cũ.
  var NEW34 = [
    ['Hà Nội', 'Thành phố'], ['Huế', 'Thành phố'], ['Hải Phòng', 'Thành phố'], ['Đà Nẵng', 'Thành phố'],
    ['TP. Hồ Chí Minh', 'Thành phố'], ['Cần Thơ', 'Thành phố'],
    ['Lai Châu', 'Tỉnh'], ['Điện Biên', 'Tỉnh'], ['Sơn La', 'Tỉnh'], ['Lạng Sơn', 'Tỉnh'], ['Quảng Ninh', 'Thành phố'],
    ['Thanh Hóa', 'Tỉnh'], ['Nghệ An', 'Tỉnh'], ['Hà Tĩnh', 'Tỉnh'], ['Cao Bằng', 'Tỉnh'],
    ['Tuyên Quang', 'Tỉnh'], ['Lào Cai', 'Tỉnh'], ['Thái Nguyên', 'Tỉnh'], ['Phú Thọ', 'Tỉnh'], ['Bắc Ninh', 'Thành phố'],
    ['Hưng Yên', 'Tỉnh'], ['Ninh Bình', 'Tỉnh'], ['Quảng Trị', 'Tỉnh'], ['Quảng Ngãi', 'Tỉnh'], ['Gia Lai', 'Tỉnh'],
    ['Khánh Hòa', 'Tỉnh'], ['Lâm Đồng', 'Tỉnh'], ['Đắk Lắk', 'Tỉnh'], ['Đồng Nai', 'Thành phố'], ['Tây Ninh', 'Tỉnh'],
    ['Vĩnh Long', 'Tỉnh'], ['Đồng Tháp', 'Tỉnh'], ['Cà Mau', 'Tỉnh'], ['An Giang', 'Tỉnh']
  ];

  var REGIONS = {
    MNPB: 'Trung du và miền núi phía Bắc', DBSH: 'Đồng bằng sông Hồng', BTB: 'Bắc Trung Bộ',
    NTB: 'Duyên hải Nam Trung Bộ', TN: 'Tây Nguyên', DNB: 'Đông Nam Bộ', DBSCL: 'Đồng bằng sông Cửu Long'
  };

  var P63 = RAW63.map(function (r, i) {
    return { id: i, name: r[0], region: r[1], pop: r[2], urban: r[3] / 100, wealth: r[4], newName: r[5], city: r[6], coast: !!r[7] };
  });
  var byName = {};
  P63.forEach(function (p) { byName[p.name] = p; });

  var P34 = NEW34.map(function (r, i) {
    var members = P63.filter(function (p) { return p.newName === r[0]; });
    var pop = members.reduce(function (s, p) { return s + p.pop; }, 0);
    return { id: i, name: r[0], kind: r[1], members: members, pop: pop };
  });

  // 54 dân tộc: [tên, dân số 2019, kiểu tên, tỉnh cư trú chính (tên tỉnh cũ), hồ sơ tôn giáo, hệ số kinh tế, nhóm nhà ở]
  var ETH_RAW = [
    ['Kinh', 82085826, 'kinh', null, 'kinh', 0, 'kinh'],
    ['Tày', 1845492, 'tay', 'Cao Bằng,Lạng Sơn,Bắc Kạn,Tuyên Quang,Hà Giang,Thái Nguyên,Lào Cai,Yên Bái,Đắk Lắk', 'trad', -0.6, 'san'],
    ['Thái', 1820950, 'thai', 'Sơn La,Điện Biên,Nghệ An,Thanh Hóa,Lai Châu,Yên Bái,Hòa Bình', 'trad', -0.8, 'san'],
    ['Mường', 1452095, 'muong', 'Hòa Bình,Thanh Hóa,Phú Thọ,Sơn La,Ninh Bình', 'trad', -0.6, 'san'],
    ['Mông', 1393547, 'hmong', 'Hà Giang,Điện Biên,Sơn La,Lào Cai,Lai Châu,Yên Bái,Cao Bằng,Nghệ An', 'hmong', -1.6, 'trinh'],
    ['Khmer', 1319652, 'khmer', 'Sóc Trăng,Trà Vinh,Kiên Giang,An Giang,Bạc Liêu,Cà Mau', 'khmer', -0.8, 'kinh'],
    ['Nùng', 1083298, 'tay', 'Lạng Sơn,Cao Bằng,Hà Giang,Bắc Giang,Thái Nguyên,Đắk Lắk', 'trad', -0.8, 'san'],
    ['Dao', 891151, 'dao', 'Hà Giang,Tuyên Quang,Lào Cai,Yên Bái,Quảng Ninh,Cao Bằng,Bắc Kạn', 'trad', -1.2, 'dat'],
    ['Hoa', 749466, 'hoa', 'TP. Hồ Chí Minh,Đồng Nai,Sóc Trăng,Kiên Giang,Bạc Liêu,Quảng Ninh', 'hoa', 0.4, 'kinh'],
    ['Gia Rai', 513930, 'tn', 'Gia Lai,Kon Tum', 'tn', -1.1, 'san'],
    ['Ê Đê', 398671, 'tn', 'Đắk Lắk,Phú Yên', 'tn', -1.0, 'dai'],
    ['Ba Na', 286910, 'tn', 'Gia Lai,Kon Tum,Bình Định', 'tn', -1.2, 'san'],
    ['Xơ Đăng', 212277, 'tn', 'Kon Tum,Quảng Nam,Quảng Ngãi', 'tn', -1.3, 'san'],
    ['Sán Chay', 201398, 'tay', 'Thái Nguyên,Tuyên Quang,Bắc Giang', 'trad', -0.8, 'san'],
    ['Cơ Ho', 200800, 'tn', 'Lâm Đồng', 'tn', -1.0, 'san'],
    ['Chăm', 178948, 'cham', 'Ninh Thuận,Bình Thuận,An Giang,TP. Hồ Chí Minh', 'cham', -0.8, 'kinh'],
    ['Sán Dìu', 183004, 'tay', 'Thái Nguyên,Vĩnh Phúc,Bắc Giang,Quảng Ninh', 'trad', -0.5, 'dat'],
    ['Hrê', 149460, 'tn', 'Quảng Ngãi', 'trad', -1.3, 'san'],
    ['Ra Glai', 146613, 'tn', 'Ninh Thuận,Khánh Hòa', 'trad', -1.4, 'san'],
    ['Mnông', 127334, 'tn', 'Đắk Nông,Đắk Lắk', 'tn', -1.3, 'san'],
    ['Xtiêng', 100752, 'tn', 'Bình Phước', 'tn', -1.1, 'san'],
    ['Bru - Vân Kiều', 94598, 'ts', 'Quảng Trị,Quảng Bình', 'trad', -1.4, 'san'],
    ['Thổ', 91430, 'muong', 'Nghệ An,Thanh Hóa', 'trad', -0.9, 'dat'],
    ['Khơ Mú', 90612, 'north', 'Nghệ An,Điện Biên,Sơn La', 'trad', -1.5, 'san'],
    ['Cơ Tu', 74173, 'ts', 'Quảng Nam,Thừa Thiên Huế', 'trad', -1.2, 'san'],
    ['Giáy', 67858, 'north', 'Lào Cai,Hà Giang,Lai Châu', 'trad', -1.0, 'dat'],
    ['Giẻ Triêng', 63322, 'tn', 'Kon Tum,Quảng Nam', 'trad', -1.3, 'san'],
    ['Tà Ôi', 52356, 'ts', 'Thừa Thiên Huế,Quảng Trị', 'trad', -1.2, 'san'],
    ['Mạ', 50322, 'tn', 'Lâm Đồng,Đắk Nông', 'tn', -1.1, 'san'],
    ['Co', 40442, 'tn', 'Quảng Ngãi,Quảng Nam', 'trad', -1.2, 'san'],
    ['Chơ Ro', 29520, 'tn', 'Đồng Nai,Bà Rịa – Vũng Tàu', 'trad', -0.8, 'san'],
    ['Xinh Mun', 29503, 'north', 'Sơn La,Điện Biên', 'trad', -1.5, 'san'],
    ['Hà Nhì', 25539, 'north', 'Lai Châu,Lào Cai,Điện Biên', 'trad', -1.4, 'trinh'],
    ['Chu Ru', 23242, 'tn', 'Lâm Đồng,Ninh Thuận', 'tn', -1.0, 'san'],
    ['Lào', 17532, 'thai', 'Điện Biên,Lai Châu,Sơn La', 'buddh', -1.0, 'san'],
    ['Kháng', 16180, 'north', 'Sơn La,Điện Biên,Lai Châu', 'trad', -1.5, 'san'],
    ['La Chí', 15126, 'north', 'Hà Giang', 'trad', -1.4, 'san'],
    ['Phù Lá', 12471, 'north', 'Lào Cai,Hà Giang,Sơn La', 'trad', -1.4, 'dat'],
    ['La Hủ', 12113, 'north', 'Lai Châu', 'trad', -1.7, 'dat'],
    ['La Ha', 10157, 'north', 'Sơn La', 'trad', -1.4, 'san'],
    ['Pà Thẻn', 8248, 'north', 'Hà Giang,Tuyên Quang', 'trad', -1.4, 'dat'],
    ['Chứt', 7513, 'ts', 'Quảng Bình', 'trad', -1.6, 'san'],
    ['Lự', 6757, 'thai', 'Lai Châu', 'buddh', -1.3, 'san'],
    ['Lô Lô', 4827, 'north', 'Hà Giang,Cao Bằng', 'trad', -1.4, 'trinh'],
    ['Mảng', 4650, 'north', 'Lai Châu', 'trad', -1.7, 'san'],
    ['Cơ Lao', 4003, 'north', 'Hà Giang', 'trad', -1.5, 'trinh'],
    ['Bố Y', 3232, 'north', 'Lào Cai,Hà Giang', 'trad', -1.3, 'dat'],
    ['Cống', 2729, 'north', 'Lai Châu,Điện Biên', 'trad', -1.6, 'san'],
    ['Ngái', 1649, 'hoa', 'Quảng Ninh,Bắc Giang', 'hoa', -0.6, 'dat'],
    ['Si La', 909, 'north', 'Lai Châu,Điện Biên', 'trad', -1.6, 'dat'],
    ['Pu Péo', 903, 'north', 'Hà Giang', 'trad', -1.4, 'trinh'],
    ['Rơ Măm', 639, 'tn', 'Kon Tum', 'trad', -1.5, 'san'],
    ['Brâu', 525, 'tn', 'Kon Tum', 'trad', -1.6, 'san'],
    ['Ơ Đu', 428, 'north', 'Nghệ An', 'trad', -1.5, 'san']
  ];

  // Tỷ lệ quay: Kinh cố định 86%, 53 dân tộc còn lại chia 14% theo dân số thực tế (Tổng điều tra 2019)
  var minorityTotal = ETH_RAW.slice(1).reduce(function (s, e) { return s + e[1]; }, 0);
  var ETH = ETH_RAW.map(function (e, i) {
    return {
      id: i, name: e[0], pop: e[1], style: e[2],
      homes: e[3] ? e[3].split(',') : null, rel: e[4], econ: e[5], house: e[6],
      share: i === 0 ? 0.86 : 0.14 * e[1] / minorityTotal
    };
  });

  // Hồ sơ tôn giáo (ước tính theo Tổng điều tra 2019 & Ban Tôn giáo Chính phủ)
  var RELIGION = {
    kinh: 'Không theo tôn giáo (thờ cúng tổ tiên):72,Phật giáo:15,Công giáo:7.5,Cao Đài:1.5,Phật giáo Hòa Hảo:1.5,Tin Lành:1',
    trad: 'Tín ngưỡng truyền thống, thờ cúng tổ tiên:85,Tin Lành:8,Công giáo:4,Phật giáo:3',
    hmong: 'Tín ngưỡng truyền thống, thờ cúng tổ tiên:68,Tin Lành:30,Công giáo:2',
    khmer: 'Phật giáo Nam tông:95,Không theo tôn giáo:5',
    hoa: 'Phật giáo & tín ngưỡng dân gian:60,Không theo tôn giáo (thờ cúng tổ tiên):30,Công giáo:6,Tin Lành:4',
    tn: 'Tin Lành:40,Tín ngưỡng truyền thống:38,Công giáo:22',
    cham: 'Bà La Môn (Chăm Bà Chăm):40,Hồi giáo Bà Ni:30,Hồi giáo (Islam):30',
    buddh: 'Phật giáo Nam tông:60,Tín ngưỡng truyền thống:40'
  };

  var HOUSE = {
    kinh: ['nhà cấp bốn', 'nhà ống', 'nhà mái bằng'], san: ['nhà sàn'], trinh: ['nhà trình tường'],
    dat: ['nhà đất mái ngói', 'nhà gỗ'], dai: ['nhà dài truyền thống']
  };

  var RURAL_DESC = {
    MNPB: ['một bản vùng cao', 'một xã miền núi', 'một thôn vùng trung du'],
    DBSH: ['một làng quê đồng bằng', 'một thôn ven đê'],
    BTB: ['một làng quê', 'một xã ven biển', 'một xã vùng bán sơn địa'],
    NTB: ['một xã ven biển', 'một làng chài', 'một xã miền núi'],
    TN: ['một buôn làng Tây Nguyên', 'một xã vùng cao nguyên', 'một thôn trồng cà phê'],
    DNB: ['một xã ven đô', 'một ấp vùng cao su', 'một xã ngoại thành'],
    DBSCL: ['một ấp vùng sông nước', 'một xã ven kênh rạch', 'một cù lao']
  };

  // Chỉ số quốc gia (ước tính 2023-2024, GSO / WB / UN WPP)
  var STATS = {
    pop: 100.3e6, births: 1.35e6, e0: 74.7, e0m: 72.2, e0f: 77.4, u5: 20, gdpPPP: 14.3, gdpNominal: 4.3,
    urban: 0.38, fertility: 1.91, avgIncomeMonth: 7.7 /* triệu đồng/tháng, lao động */, uni: 0.3
  };

  // ===== TÊN NGƯỜI VIỆT & DÂN TỘC =====
  var KINH_SUR = 'Nguyễn:38,Trần:11,Lê:9.5,Phạm:7,Hoàng:3,Huỳnh:2.1,Phan:4.5,Vũ:2,Võ:1.9,Đặng:2.1,Bùi:2,Đỗ:1.4,Hồ:1.3,Ngô:1.3,Dương:1,Lý:0.5,Đinh:0.6,Trịnh:0.5,Đoàn:0.5,Lâm:0.4,Mai:0.4,Trương:0.4,Cao:0.3,Hà:0.4,Lương:0.3,Tạ:0.2,Châu:0.2,Tô:0.2,Thái:0.2,Phùng:0.2,Lưu:0.2,Kiều:0.1,Quách:0.1,Tôn:0.1,La:0.1';
  var NAMES = {
    kinh: {
      sur: KINH_SUR,
      midM: 'Văn:3,Đức:3,Minh:4,Quang:3,Hữu:2,Thành:2,Gia:3,Anh:2,Công:1,Trung:1,Tuấn:1,Hoàng:2,Ngọc:1,Xuân:1,Đình:1,Bảo:3,Nhật:2,Khánh:1,Thanh:1,Chí:1,Duy:1,Quốc:1,Đăng:1,Phúc:1',
      midF: 'Thị:3,Ngọc:3,Thu:2,Thanh:2,Thùy:2,Bảo:3,Khánh:2,Minh:3,Phương:2,Mai:1,Hồng:1,Diệu:1,Kim:1,Hoài:1,Tuệ:1,Gia:2,Như:1,Quỳnh:1,An:1,Hà:1,Tường:1',
      M: 'An,Bảo,Bình,Cường,Dũng,Duy,Đạt,Đức,Hải,Hiếu,Hoàng,Huy,Hùng,Khang,Khoa,Khôi,Kiên,Lâm,Long,Lộc,Minh,Nam,Nghĩa,Nhân,Phát,Phong,Phúc,Quân,Quang,Sơn,Tài,Thắng,Thịnh,Tiến,Toàn,Trí,Trung,Tuấn,Tùng,Việt,Vinh,Vũ,Đăng,Hưng,Khải,Nguyên,Thiện,Tâm',
      fullM: 'Văn An,Văn Bình,Văn Cường,Văn Dũng,Văn Hải,Văn Hùng,Văn Long,Văn Nam,Văn Sơn,Văn Thắng,Văn Toàn,Văn Tuấn,Văn Hậu,Văn Đức,Văn Lâm,Văn Tài,Văn Tiến,Văn Thành,Văn Quyết,Văn Hưng,Văn Khánh,Văn Lực,Văn Phong,Văn Thanh,Đức Anh,Đức Minh,Đức Huy,Đức Thắng,Đức Trung,Đức Long,Đức Mạnh,Đức Tài,Đức Hiếu,Đức Phúc,Đức Duy,Đức Thịnh,Minh Anh,Minh Đức,Minh Hiếu,Minh Hoàng,Minh Khang,Minh Khôi,Minh Nhật,Minh Quân,Minh Tuấn,Minh Trí,Minh Hải,Minh Phúc,Minh Thành,Minh Châu,Minh Long,Quang Huy,Quang Minh,Quang Vinh,Quang Hải,Quang Dũng,Quang Trung,Quang Khải,Quang Đạt,Hữu Phước,Hữu Nghĩa,Hữu Thắng,Hữu Tài,Hữu Lộc,Hữu Trí,Hữu Đạt,Thành Đạt,Thành Long,Thành Nam,Thành Trung,Thành Công,Thành Luân,Gia Bảo,Gia Huy,Gia Khánh,Gia Hưng,Gia Phúc,Gia Khang,Gia Kiệt,Gia Minh,Anh Tuấn,Anh Dũng,Anh Khoa,Anh Quân,Anh Đức,Anh Tú,Công Minh,Công Danh,Công Thành,Công Hậu,Trung Kiên,Trung Hiếu,Trung Dũng,Trung Nghĩa,Trung Đức,Tuấn Anh,Tuấn Kiệt,Tuấn Hưng,Tuấn Khải,Hoàng Long,Hoàng Nam,Hoàng Phúc,Hoàng Anh,Hoàng Minh,Hoàng Việt,Hoàng Hải,Ngọc Hải,Ngọc Sơn,Ngọc Tú,Ngọc Quang,Xuân Trường,Xuân Bách,Xuân Hùng,Xuân Phúc,Đình Trọng,Đình Phong,Đình Khoa,Đình Tuấn,Bảo Long,Bảo Nam,Bảo Khang,Bảo Anh,Bảo Lâm,Nhật Minh,Nhật Huy,Nhật Nam,Nhật Quang,Nhật Duy,Khánh Duy,Khánh Toàn,Khánh Hưng,Khánh Nam,Thanh Tùng,Thanh Sơn,Thanh Bình,Thanh Phong,Thanh Hải,Thanh Tâm,Chí Thanh,Chí Công,Chí Bảo,Chí Hiếu,Duy Mạnh,Duy Khánh,Duy Anh,Duy Hưng,Quốc Bảo,Quốc Anh,Quốc Huy,Quốc Khánh,Quốc Việt,Quốc Trung,Đăng Khoa,Đăng Khôi,Đăng Quang,Phúc Thịnh,Phúc Lâm,Phúc An,Tiến Dũng,Tiến Đạt,Tiến Thành,Mạnh Hùng,Mạnh Cường,Mạnh Tuấn,Việt Hoàng,Việt Anh,Việt Dũng,Hải Đăng,Hải Nam,Hải Long,Thế Anh,Thế Vinh,Thế Hiển,Tấn Phát,Tấn Tài,Tấn Lộc,Phước Lộc,Phước Thiện,Trọng Nhân,Trọng Hiếu,Thiện Nhân,Nguyên Khang,Khôi Nguyên,Minh Nhân,Kim Long,Trường Giang,Sơn Tùng,Tùng Lâm',
      fullF: 'Thị Lan,Thị Hoa,Thị Hồng,Thị Hương,Thị Mai,Thị Nga,Thị Thu,Thị Hạnh,Thị Huyền,Thị Thảo,Thị Hằng,Thị Dung,Thị Loan,Thị Yến,Thị Phương,Thị Ngọc,Thị Thủy,Thị Bích,Thị Liên,Thị Nhung,Thị Trang,Thị Vân,Thị Hà,Thị Thanh,Thị Oanh,Thị Hiền,Thị Tuyết,Thị Kim,Thị Lý,Ngọc Anh,Ngọc Ánh,Ngọc Hân,Ngọc Lan,Ngọc Mai,Ngọc Trâm,Ngọc Diệp,Ngọc Hà,Ngọc Huyền,Ngọc Linh,Ngọc Bích,Ngọc Quỳnh,Thu Hà,Thu Trang,Thu Hương,Thu Thủy,Thu Phương,Thu Hằng,Thu Uyên,Thu Huyền,Thanh Hương,Thanh Hà,Thanh Tâm,Thanh Thảo,Thanh Huyền,Thanh Mai,Thanh Vân,Thanh Nhàn,Thanh Trúc,Thùy Linh,Thùy Dung,Thùy Trang,Thùy Dương,Thùy Chi,Thùy Tiên,Bảo Anh,Bảo Ngọc,Bảo Châu,Bảo Trâm,Bảo Vy,Bảo Hân,Bảo Yến,Khánh Linh,Khánh Huyền,Khánh Ly,Khánh Vy,Khánh Chi,Khánh An,Khánh Ngân,Minh Anh,Minh Thư,Minh Châu,Minh Ngọc,Minh Hằng,Minh Tâm,Minh Khuê,Minh Thùy,Minh Trang,Phương Anh,Phương Linh,Phương Thảo,Phương Uyên,Phương Nhi,Phương Ly,Phương Mai,Mai Anh,Mai Linh,Mai Phương,Mai Chi,Mai Hương,Hồng Nhung,Hồng Hạnh,Hồng Ngọc,Hồng Vân,Hồng Nhung,Diệu Linh,Diệu Thúy,Diệu Hương,Kim Ngân,Kim Chi,Kim Oanh,Kim Thoa,Kim Liên,Hoài Thương,Hoài An,Hoài Linh,Tuệ An,Tuệ Lâm,Tuệ Nhi,Gia Hân,Gia Linh,Gia Như,Như Quỳnh,Như Ý,Quỳnh Anh,Quỳnh Chi,Quỳnh Như,Quỳnh Trang,Quỳnh Hương,Hà My,Hà Phương,Hà Vy,Hà Linh,Hà Anh,Lan Anh,Lan Hương,Lan Phương,Hải Yến,Hải Anh,Hải Vân,Huyền Trang,Huyền My,Mỹ Linh,Mỹ Duyên,Mỹ Hạnh,Cẩm Tú,Cẩm Ly,Cẩm Nhung,Tường Vy,Thảo Nguyên,Thảo Vy,Thảo My,Yến Nhi,Ánh Dương,Ánh Tuyết,Bích Ngọc,Bích Phương,Bích Hằng,Thúy Hằng,Thúy Kiều,Thúy Nga,Vân Anh,Vân Khánh,Trà My,Diễm My,Diễm Quỳnh,Kiều Trang,Kiều Oanh,Tú Anh,Tú Uyên,Nhã Uyên,Nhã Phương,An Nhiên,Đan Thanh,Uyên Nhi,Ngân Hà,Xuân Mai,Xuân Quỳnh,Hồng Ánh,Ngọc Châu,Thục Anh,Thục Trinh,Bảo Trân,Phương Trinh,Thanh Trúc,Ngọc Trinh,Thu Ngân',
      F: 'Anh,Châu,Chi,Dung,Duyên,Giang,Hà,Hân,Hằng,Hạnh,Hiền,Hoa,Hồng,Hương,Huyền,Lan,Linh,Loan,Ly,Mai,My,Nga,Ngân,Ngọc,Nhi,Nhung,Oanh,Phương,Quyên,Quỳnh,Tâm,Thảo,Thư,Thủy,Trang,Trâm,Uyên,Vân,Vy,Yến,An,Tú,Khuê,Diệp,Nhiên,Ngân'
    },
    hmong: {
      sur: 'Giàng:4,Vàng:4,Lý:3,Sùng:3,Thào:3,Hờ:2,Mùa:2,Lầu:2,Vừ:2,Cứ:1,Hạng:1,Tráng:1,Sình:1',
      midM: 'A:5,Seo:2,Mí:1', midF: 'Thị:3,Mí:2,Thị Mỷ:0',
      M: 'Páo,Sính,Chứ,Dình,Pó,Lử,Sử,Chơ,Tủa,Dế,Chá,Lềnh,Sình,Nhà,Tồng,Sùng,Dủa,Phử',
      F: 'Mỷ,Dua,Pà,Dợ,Mai,Lan,Chở,Sua,Dính,Mỉ,Già,Ly,Say,Dở,Sú,Pùa'
    },
    thai: {
      sur: 'Lò:4,Lường:3,Cầm:3,Quàng:2,Hà:2,Vi:2,Tòng:2,Lù:2,Điêu:1,Lộc:1,Mè:1,Bạc:1,Khoàng:1',
      midM: 'Văn:6,Minh:1', midF: 'Thị:6,Thu:1',
      M: 'Ún,Pánh,Thoại,Xôm,Ọn,Chương,Phong,Quý,Tiến,Hoan,Thanh,Bun,Hươn,Sơn,Duy,Hải',
      F: 'Ơn,Xuân,Hoa,Mai,Lả,Phương,Ngọc,Hương,Thoa,Bích,Ánh,Nhung,Hồng,Dung,Uyên'
    },
    tay: {
      sur: 'Nông:3,Hoàng:3,Lục:2,Ma:2,Lương:2,Bế:2,Đàm:2,Triệu:2,Lăng:1,Hà:2,Lành:1,Vi:1,Dương:1,Lý:1,Lộc:1,Chu:1,Mông:1',
      midM: 'Văn:5,Đức:1,Minh:1', midF: 'Thị:5,Thu:1,Hồng:1',
      M: 'Thắng,Khánh,Toàn,Dũng,Hùng,Quyết,Sơn,Tuấn,Nam,Pẻng,Chiến,Kiên,Hải,Đạt,Long,Trường',
      F: 'Hoa,Lan,Mai,Thắm,Hằng,Huệ,Nga,Thu,Hương,Ngọc,Thảo,Phượng,Liên,Thơm,Vân'
    },
    muong: {
      sur: 'Đinh:3,Bùi:4,Quách:2,Bạch:1,Hà:2,Xa:1,Phạm:1,Hoàng:1',
      midM: 'Văn:6,Công:1', midF: 'Thị:6',
      M: 'Lưu,Thắng,Hùng,Khương,Sơn,Tâm,Hòa,Thành,Bình,Dũng,Tuấn,Long,Quân,Toản',
      F: 'Ngọc,Hồng,Huệ,Lan,Mai,Thắm,Hoa,Hương,Liên,Thu,Thanh,Nhàn,Yến,Diệp'
    },
    khmer: {
      sur: 'Thạch:4,Danh:3,Sơn:3,Kim:2,Lâm:2,Châu:1,Lý:1,Kiên:1,Trịnh:1,Mai:1',
      midM: '—:5,Văn:1', midF: 'Thị:5,—:2',
      M: 'Sa Rươne,Sóc,Phol,Rinh,Chanh Đa,Sà Phong,Ca Ri,Pô,Sóc Khiêm,Sơ Phi,Rô Ny,Thươl,Đa Ra,Sô Vanh',
      F: 'Sa Ri,Sô Phi,Pha Ly,Sóc Kha,Chanh Thy,Sô Khom,Mai,Kim Ly,Sà Ra,Thươl,Ny,Đa Ni,Sa Vy'
    },
    dao: {
      sur: 'Triệu:4,Bàn:3,Đặng:3,Lý:2,Chảo:2,Tẩn:2,Phàn:1,Chìu:1,Lò:1',
      midM: 'Văn:4,Seo:2,Kiềm:1,Tòn:1', midF: 'Thị:4,Mẩy:2,Mùi:1',
      M: 'Chàn,Phin,Quẩy,Kiềm,Tả,Sinh,Lở,Chòi,Kháo,Phú,Thanh,Hưng,Lìn,Vạn',
      F: 'Mẩy,Sử,Liều,Phây,Nhất,Dung,Hoa,Lan,Mai,Xuân,Dinh,Chiêu'
    },
    hoa: {
      sur: 'Lâm:3,Trương:3,Quách:2,Lưu:2,Tạ:2,Hứa:2,Lý:2,Mã:2,Diệp:1,Tăng:1,Châu:1,Huỳnh:2,Lư:1,Vương:1',
      midM: 'Vĩnh:2,Gia:2,Tuấn:2,Quốc:2,Kiến:1,Chấn:1,Thiên:1', midF: 'Mỹ:3,Ngọc:2,Tú:2,Bội:1,Gia:2,Uyển:1',
      M: 'Phát,Kiệt,Hào,Vinh,Cường,Huy,Lương,Hưng,Thành,Khang,Minh,Tường,Long,Phong',
      F: 'Linh,Ngân,Anh,Doanh,Trân,Quyên,Hà,Lệ,Mẫn,Như,Uyển,Dĩnh,Tuyết,Yến'
    },
    cham: {
      sur: 'Đàng:3,Thông:2,Thiên Sanh:1,Lưu:2,Quảng:2,Châu:1,Bá:1,Thuận:1,Mohamad:1,Sa:1',
      midM: 'Văn:3,—:2', midF: 'Thị:4,—:1',
      M: 'Năng,Thành,Phú,Tài,Sakaya,Inrasara,Hảo,Lộc,Hải,Ali,Ismail,Kha,Trí,Tấn',
      F: 'Ka Pal,Hồng,Mỹ,Khuê,Aisah,Fatimah,Lan,Hạnh,Nữ,Như,Nhung,Phương,Thu'
    },
    tn: { // Gia Rai, Ê Đê, Ba Na, Xơ Đăng, Cơ Ho, Mnông... (họ đứng sau, nữ có tiền tố H')
      sur: 'Ksor:3,Rơ Mah:2,Siu:2,Rah Lan:1,Kpă:2,Nay:2,Niê:3,Mlô:1,Êban:1,Byă:1,Adrơng:1,Hwing:1,Đinh:2,K\'Dăm:1,Ka:1,Y:0',
      midM: 'Y:4,A:2,—:2', midF: 'H\':6,—:1',
      M: 'Rin,Bhăm,Đen,Ngọc,Blúp,Khuê,Hiên,Thuần,Sơn,Kông,Dhiêng,Plô,Wưu,Jứ,Bơ,Tlang',
      F: 'Lan,Hen,Nhi,Bia,Ble,Mai,Uyên,Thoa,Duyên,Ngân,Nga,Huê,Djuê,Pai,Lang'
    },
    ts: { // Trường Sơn: Bru - Vân Kiều, Cơ Tu, Tà Ôi, Chứt
      sur: 'Hồ:5,A Lăng:2,Bríu:1,Zơ Râm:1,Pả:1,Kăn:1,Côn:1,Đinh:1,Arâl:1,Bh\'riu:1',
      midM: 'Văn:5,—:1', midF: 'Thị:5,—:1',
      M: 'Đức,Ka,Lơi,Phúc,Hiếu,Nhân,Tâm,Kiên,Bơn,Pao,Thoi,Viên,Bình,Khoa',
      F: 'Thoa,Nga,Hiền,Lan,Phương,Mai,Hoa,Bông,Hồng,Thu,Thảo,Linh,Trang'
    },
    north: { // các dân tộc ít người phía Bắc
      sur: 'Lò:3,Lý:3,Vàng:2,Hoàng:2,Ma:2,Lù:2,Pờ:1,Chu:1,Phàn:1,Chảo:1,Lồ:1,Vi:1,Lô:1,Sần:1,Thào:1',
      midM: 'Văn:4,A:2,Seo:1,Lao:1', midF: 'Thị:5,Mí:1',
      M: 'Chung,Sáng,Pao,Chơ,Diu,Sinh,Lả,Lù,Tà,Kim,Sơn,Hùng,Thành,Tuyên',
      F: 'Mỷ,Dâu,Mai,Hoa,Lan,Phương,Hương,Thu,Xuân,Pa,Chi,Thanh'
    }
  };

  function parseW(spec) { return spec.split(',').map(function (s) { var p = s.split(':'); return [p[0], p.length > 1 ? +p[1] : 1]; }); }
  var NAMEP = {};
  Object.keys(NAMES).forEach(function (k) {
    var n = NAMES[k];
    NAMEP[k] = { sur: parseW(n.sur), midM: parseW(n.midM), midF: parseW(n.midF), M: n.M.split(','), F: n.F.split(','), fullM: n.fullM ? n.fullM.split(',') : null, fullF: n.fullF ? n.fullF.split(',') : null };
  });

  function vnName(r, style, sex, surname) {
    var U = G.U, p = NAMEP[style] || NAMEP.kinh;
    var sur = surname || U.wpick(r, p.sur, function (x) { return x[1]; })[0];
    var fl = sex === 'F' ? p.fullF : p.fullM;
    if (fl && style === 'kinh') { // v3.5: tên đệm + tên gọi có thật, không ghép ngẫu nhiên; tránh trùng họ với tên gọi ("Hà Thu Hà")
      var nm = '';
      for (var t = 0; t < 6; t++) { nm = U.wpick(r, fl, function (x) { return /^(Văn|Thị) /.test(x) ? 0.55 : 1; }); var w = nm.split(' '); if (w[w.length - 1] !== sur && w[0] !== sur) break; }
      return { full: sur + ' ' + nm, sur: sur };
    }
    var mid = U.wpick(r, sex === 'F' ? p.midF : p.midM, function (x) { return x[1]; })[0];
    var given = U.pick(r, sex === 'F' ? p.F : p.M);
    if (mid === '—') mid = '';
    var parts;
    if (style === 'tn') {
      // Kiểu Tây Nguyên: Y Rin Niê / H'Lan Ksor (tên trước, họ sau)
      if (mid === "H'") return { full: "H'" + given + ' ' + sur, sur: sur };
      parts = [mid, given, sur];
    } else if (style === 'hmong' && mid === 'A') {
      parts = [sur, 'A', given];
    } else parts = [sur, mid, given];
    return { full: parts.filter(Boolean).join(' '), sur: sur };
  }

  G.VN = {
    P63: P63, P34: P34, byName: byName, ETH: ETH, REGIONS: REGIONS, RELIGION: RELIGION,
    HOUSE: HOUSE, RURAL_DESC: RURAL_DESC, STATS: STATS, vnName: vnName,
    ethByName: function (n) { for (var i = 0; i < ETH.length; i++) if (ETH[i].name === n) return ETH[i]; return null; }
  };
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
/* ===== js/data-world.js ===== */
/* Dữ liệu 195 quốc gia (193 thành viên LHQ + Tòa Thánh Vatican + Palestine).
   Số sinh/năm (nghìn), tuổi thọ, GDP bình quân PPP (nghìn USD), tử vong dưới 5 tuổi (‰), % đô thị:
   làm tròn theo UN World Population Prospects 2024 / World Bank WDI 2023 — chỉ dùng để mô phỏng.
   Cột "tên": bộ tên theo văn hóa (có thể trộn theo tỷ lệ, vd "en:72,es_la:24"). */
(function (G) {
  'use strict';
  var ROWS = [
    'AF|Afghanistan|1450|63|2.1|56|26|af|Kabul,Herat,Kandahar,Mazar-i-Sharif,Jalalabad,Kunduz',
    'AL|Albania|29|77|19|9|64|sq|Tirana,Durrës,Vlorë,Shkodër,Elbasan',
    'DZ|Algeria|850|76|15|22|75|ar|Algiers,Oran,Constantine,Annaba,Blida,Sétif',
    'AD|Andorra|0.6|84|70|3|88|es|Andorra la Vella,Escaldes-Engordany,Encamp',
    'AO|Angola|1350|62|7|64|68|ao|Luanda,Huambo,Lobito,Benguela,Lubango',
    'AG|Antigua và Barbuda|1.2|79|30|7|24|car|St. John\'s,All Saints,Liberta',
    'AR|Argentina|460|77|27|7|92|es_la|Buenos Aires,Córdoba,Rosario,Mendoza,La Plata,Tucumán',
    'AM|Armenia|36|76|20|10|64|hy|Yerevan,Gyumri,Vanadzor,Vagharshapat',
    'AU|Úc|295|83|65|4|86|en:88,cn:6,in:6|Sydney,Melbourne,Brisbane,Perth,Adelaide,Canberra',
    'AT|Áo|77|82|68|3|59|de|Vienna,Graz,Linz,Salzburg,Innsbruck',
    'AZ|Azerbaijan|115|74|20|17|57|az|Baku,Ganja,Sumqayit,Lankaran,Mingachevir',
    'BS|Bahamas|4|74|37|12|83|car|Nassau,Freeport,Marsh Harbour',
    'BH|Bahrain|18|80|57|7|90|ar|Manama,Riffa,Muharraq,Hamad Town',
    'BD|Bangladesh|3000|74|8.5|29|40|bd|Dhaka,Chittagong,Khulna,Rajshahi,Sylhet,Rangpur,Barisal',
    'BB|Barbados|2.5|78|19|11|31|car|Bridgetown,Speightstown,Oistins',
    'BY|Belarus|65|74|29|3|80|ru|Minsk,Gomel,Mogilev,Vitebsk,Grodno,Brest',
    'BE|Bỉ|113|82|65|4|98|nl:58,fr:42|Brussels,Antwerp,Ghent,Charleroi,Liège,Bruges',
    'BZ|Belize|7|74|12|11|46|es_la:60,car:40|Belize City,San Ignacio,Belmopan,Orange Walk',
    'BJ|Benin|450|60|4|80|49|afr|Cotonou,Porto-Novo,Parakou,Abomey-Calavi,Djougou',
    'BT|Bhutan|9|72|13|26|44|bt|Thimphu,Phuntsholing,Paro,Punakha',
    'BO|Bolivia|250|68|10|25|71|es_la|La Paz,Santa Cruz,Cochabamba,El Alto,Sucre,Oruro',
    'BA|Bosnia và Herzegovina|28|77|19|6|50|yu|Sarajevo,Banja Luka,Tuzla,Zenica,Mostar',
    'BW|Botswana|60|66|18|35|72|afs|Gaborone,Francistown,Maun,Molepolole',
    'BR|Brazil|2550|76|20|14|88|br|São Paulo,Rio de Janeiro,Brasília,Salvador,Fortaleza,Belo Horizonte,Manaus,Recife,Curitiba,Porto Alegre',
    'BN|Brunei|6|75|75|11|79|my|Bandar Seri Begawan,Kuala Belait,Seria,Tutong',
    'BG|Bulgaria|56|75|33|6|76|bg|Sofia,Plovdiv,Varna,Burgas,Ruse',
    'BF|Burkina Faso|770|60|2.6|80|32|afr|Ouagadougou,Bobo-Dioulasso,Koudougou,Banfora',
    'BI|Burundi|430|62|0.9|50|14|afe|Bujumbura,Gitega,Ngozi,Rumonge',
    'CV|Cabo Verde|9|75|9|14|67|ao|Praia,Mindelo,Santa Maria',
    'KH|Campuchia|350|70|5.5|23|26|kh|Phnôm Pênh,Siem Reap,Battambang,Sihanoukville,Kampong Cham',
    'CM|Cameroon|960|63|4.6|70|59|afr|Douala,Yaoundé,Garoua,Bamenda,Bafoussam,Maroua',
    'CA|Canada|350|82|59|5|82|en:72,fr:20,in:4,cn:4|Toronto,Montréal,Vancouver,Calgary,Ottawa,Edmonton,Winnipeg,Québec',
    'CF|Cộng hòa Trung Phi|230|57|1.1|95|43|afr|Bangui,Bimbo,Berbérati,Carnot',
    'TD|Chad|780|55|1.7|105|24|afr:60,ar:40|N\'Djamena,Moundou,Abéché,Sarh',
    'CL|Chile|175|81|31|7|88|es_la|Santiago,Valparaíso,Concepción,Antofagasta,Temuco,La Serena',
    'CN|Trung Quốc|9000|78|23|7|65|cn|Thượng Hải,Bắc Kinh,Trùng Khánh,Quảng Châu,Thâm Quyến,Thành Đô,Vũ Hán,Tây An,Hàng Châu,Nam Kinh,Thiên Tân,Côn Minh,Nam Ninh,Cáp Nhĩ Tân',
    'CO|Colombia|510|77|20|13|82|es_la|Bogotá,Medellín,Cali,Barranquilla,Cartagena,Bucaramanga',
    'KM|Comoros|28|64|3.6|50|30|ar|Moroni,Mutsamudu,Fomboni',
    'CG|Cộng hòa Congo|180|65|6.5|42|69|afr|Brazzaville,Pointe-Noire,Dolisie',
    'CD|CHDC Congo|4400|61|1.5|76|47|afr|Kinshasa,Lubumbashi,Mbuji-Mayi,Kisangani,Kananga,Goma,Bukavu',
    'CR|Costa Rica|52|80|26|8|82|es_la|San José,Alajuela,Cartago,Heredia,Limón',
    'CI|Bờ Biển Ngà|880|61|6.5|73|53|afr|Abidjan,Bouaké,Yamoussoukro,Daloa,San-Pédro,Korhogo',
    'HR|Croatia|33|78|40|4|58|yu|Zagreb,Split,Rijeka,Osijek,Zadar',
    'CU|Cuba|90|78|10|6|77|es_la|Havana,Santiago de Cuba,Camagüey,Holguín,Santa Clara',
    'CY|Síp|10|82|50|3|67|gr|Nicosia,Limassol,Larnaca,Paphos',
    'CZ|Séc|91|79|50|3|74|cz|Prague,Brno,Ostrava,Plzeň,Liberec,Olomouc',
    'DK|Đan Mạch|57|82|74|4|88|nord|Copenhagen,Aarhus,Odense,Aalborg,Esbjerg',
    'DJ|Djibouti|23|63|6.3|54|78|so|Djibouti,Ali Sabieh,Tadjourah',
    'DM|Dominica|0.9|73|15|35|71|car|Roseau,Portsmouth',
    'DO|Cộng hòa Dominica|200|74|24|33|84|es_la|Santo Domingo,Santiago de los Caballeros,La Romana,San Pedro de Macorís,Puerto Plata',
    'EC|Ecuador|270|78|14|13|65|es_la|Guayaquil,Quito,Cuenca,Santo Domingo,Machala,Manta',
    'EG|Ai Cập|2100|71|17|19|43|ar|Cairo,Alexandria,Giza,Shubra El Kheima,Port Said,Luxor,Asyut,Mansoura',
    'SV|El Salvador|100|72|11|12|75|es_la|San Salvador,Santa Ana,San Miguel,Soyapango',
    'GQ|Guinea Xích Đạo|55|61|19|76|74|afr|Malabo,Bata,Ebebiyín',
    'ER|Eritrea|105|67|1.8|38|42|et|Asmara,Keren,Massawa,Mendefera',
    'EE|Estonia|11|79|46|2|69|ee|Tallinn,Tartu,Narva,Pärnu',
    'SZ|Eswatini|28|64|11|46|24|afs|Mbabane,Manzini,Lobamba',
    'ET|Ethiopia|4100|67|3|47|23|et|Addis Ababa,Dire Dawa,Mekelle,Gondar,Hawassa,Bahir Dar,Jimma',
    'FJ|Fiji|17|68|15|27|58|pac:60,in:40|Suva,Lautoka,Nadi,Labasa',
    'FI|Phần Lan|43|82|58|2|86|fi|Helsinki,Espoo,Tampere,Vantaa,Oulu,Turku',
    'FR|Pháp|680|83|58|4|81|fr:88,ar:12|Paris,Marseille,Lyon,Toulouse,Nice,Nantes,Strasbourg,Lille,Bordeaux,Montpellier',
    'GA|Gabon|65|66|20|39|91|afr|Libreville,Port-Gentil,Franceville',
    'GM|Gambia|85|65|2.9|48|64|afr|Banjul,Serekunda,Brikama,Bakau',
    'GE|Georgia|42|74|23|9|60|ka|Tbilisi,Batumi,Kutaisi,Rustavi,Zugdidi',
    'DE|Đức|690|81|66|4|78|de:85,tr:8,ar:7|Berlin,Hamburg,Munich,Cologne,Frankfurt,Stuttgart,Düsseldorf,Leipzig,Dresden',
    'GH|Ghana|880|65|7|43|59|afw|Accra,Kumasi,Tamale,Takoradi,Cape Coast,Tema',
    'GR|Hy Lạp|71|81|37|4|80|gr|Athens,Thessaloniki,Patras,Heraklion,Larissa',
    'GD|Grenada|1.5|75|17|15|37|car|St. George\'s,Gouyave,Grenville',
    'GT|Guatemala|360|72|10|23|53|es_la|Guatemala City,Mixco,Villa Nueva,Quetzaltenango,Escuintla',
    'GN|Guinea|540|59|3|97|38|afr|Conakry,Nzérékoré,Kankan,Kindia,Labé',
    'GW|Guinea-Bissau|65|60|2.4|72|45|ao|Bissau,Bafatá,Gabú',
    'GY|Guyana|16|70|60|27|27|car:60,in:40|Georgetown,Linden,New Amsterdam',
    'HT|Haiti|260|64|3|58|59|ht|Port-au-Prince,Cap-Haïtien,Gonaïves,Les Cayes,Jacmel',
    'VA|Thành Vatican|0|84|50|3|100|it|Thành Vatican',
    'HN|Honduras|200|71|7|16|60|es_la|Tegucigalpa,San Pedro Sula,La Ceiba,Choloma',
    'HU|Hungary|85|77|42|4|73|hu|Budapest,Debrecen,Szeged,Miskolc,Pécs,Győr',
    'IS|Iceland|4.4|83|72|2|94|nord|Reykjavík,Kópavogur,Akureyri,Hafnarfjörður',
    'IN|Ấn Độ|23000|72|9.2|29|36|in|Mumbai,Delhi,Bengaluru,Kolkata,Chennai,Hyderabad,Ahmedabad,Pune,Jaipur,Lucknow,Patna,Kanpur,Indore,Bhopal',
    'ID|Indonesia|4400|71|15|21|58|id|Jakarta,Surabaya,Bandung,Medan,Semarang,Makassar,Palembang,Yogyakarta,Denpasar,Malang',
    'IR|Iran|1050|77|18|12|77|fa|Tehran,Mashhad,Isfahan,Karaj,Shiraz,Tabriz,Qom,Ahvaz',
    'IQ|Iraq|1150|72|11|24|71|ar|Baghdad,Basra,Mosul,Erbil,Najaf,Karbala,Sulaymaniyah',
    'IE|Ireland|55|83|115|3|64|en|Dublin,Cork,Limerick,Galway,Waterford',
    'IL|Israel|180|83|50|3|93|he:76,ar:24|Jerusalem,Tel Aviv,Haifa,Rishon LeZion,Petah Tikva,Beersheba,Nazareth',
    'IT|Ý|380|83|52|3|72|it|Rome,Milan,Naples,Turin,Palermo,Genoa,Bologna,Florence,Bari',
    'JM|Jamaica|30|71|11|13|57|car|Kingston,Spanish Town,Montego Bay,Portmore,May Pen',
    'JP|Nhật Bản|760|84|49|2|92|jp|Tokyo,Yokohama,Osaka,Nagoya,Sapporo,Fukuoka,Kobe,Kyoto,Sendai,Hiroshima,Kawasaki',
    'JO|Jordan|220|78|10.5|15|92|ar|Amman,Zarqa,Irbid,Aqaba,Madaba',
    'KZ|Kazakhstan|390|74|34|9|58|ca:80,ru:20|Almaty,Astana,Shymkent,Karaganda,Aktobe,Pavlodar',
    'KE|Kenya|1500|63|6|37|29|afe|Nairobi,Mombasa,Kisumu,Nakuru,Eldoret,Thika',
    'KI|Kiribati|3|67|2.4|47|57|pac|Tarawa,Betio',
    'KP|Triều Tiên|340|73|1.8|15|63|kp|Bình Nhưỡng,Hamhung,Chongjin,Nampo,Wonsan,Sinuiju',
    'KR|Hàn Quốc|230|84|56|3|81|kr|Seoul,Busan,Incheon,Daegu,Daejeon,Gwangju,Suwon,Ulsan,Changwon,Jeju',
    'KW|Kuwait|50|80|52|9|100|ar|Kuwait City,Hawalli,Al Ahmadi,Jahra',
    'KG|Kyrgyzstan|150|72|7|17|37|ca|Bishkek,Osh,Jalal-Abad,Karakol',
    'LA|Lào|160|69|9|42|38|la|Viêng Chăn,Luang Prabang,Savannakhet,Pakse,Thakhek',
    'LV|Latvia|13|76|40|3|69|lv|Riga,Daugavpils,Liepāja,Jelgava',
    'LB|Lebanon|80|78|13|8|89|ar|Beirut,Tripoli,Sidon,Tyre,Zahle',
    'LS|Lesotho|52|57|3|73|30|afs|Maseru,Teyateyaneng,Mafeteng',
    'LR|Liberia|160|62|1.8|74|53|afw|Monrovia,Gbarnga,Buchanan,Kakata',
    'LY|Libya|120|73|22|11|81|ar|Tripoli,Benghazi,Misrata,Sabha',
    'LI|Liechtenstein|0.3|83|130|2|14|de|Vaduz,Schaan,Balzers',
    'LT|Lithuania|20|77|48|3|68|lt|Vilnius,Kaunas,Klaipėda,Šiauliai',
    'LU|Luxembourg|6.5|83|140|2|92|fr:50,de:30,pt:20|Luxembourg,Esch-sur-Alzette,Differdange',
    'MG|Madagascar|900|65|1.8|66|40|mg|Antananarivo,Toamasina,Antsirabe,Fianarantsoa,Mahajanga',
    'MW|Malawi|580|65|1.7|40|18|afs|Lilongwe,Blantyre,Mzuzu,Zomba',
    'MY|Malaysia|450|76|36|8|78|my:66,cn:24,in:10|Kuala Lumpur,Johor Bahru,George Town,Ipoh,Kuching,Kota Kinabalu,Shah Alam,Malacca',
    'MV|Maldives|7|80|23|5|41|ar|Malé,Addu City,Fuvahmulah',
    'ML|Mali|1000|60|2.4|97|45|afr|Bamako,Sikasso,Ségou,Mopti,Kayes,Timbuktu',
    'MT|Malta|4.5|83|58|6|95|it|Valletta,Birkirkara,Mosta,Sliema',
    'MH|Quần đảo Marshall|1|65|6.5|30|78|pac|Majuro,Ebeye',
    'MR|Mauritania|160|65|6.5|40|57|ar|Nouakchott,Nouadhibou,Kiffa,Rosso',
    'MU|Mauritius|12|74|28|17|41|in:60,fr:40|Port Louis,Curepipe,Quatre Bornes,Vacoas',
    'MX|Mexico|1850|75|23|13|81|es_la|Mexico City,Guadalajara,Monterrey,Puebla,Tijuana,León,Ciudad Juárez,Mérida,Oaxaca',
    'FM|Micronesia|2|71|4|23|23|pac|Palikir,Weno,Kolonia',
    'MD|Moldova|30|71|16|14|43|ro|Chișinău,Bălți,Tiraspol,Cahul',
    'MC|Monaco|0.3|86|190|3|100|fr|Monaco,Monte Carlo',
    'MN|Mông Cổ|72|73|17|14|69|mn|Ulaanbaatar,Erdenet,Darkhan,Choibalsan',
    'ME|Montenegro|7|77|28|2|68|yu|Podgorica,Nikšić,Herceg Novi,Bar',
    'MA|Morocco|670|75|10|17|65|ar|Casablanca,Rabat,Fès,Marrakesh,Tangier,Agadir,Meknès',
    'MZ|Mozambique|1250|63|1.6|67|38|ao|Maputo,Matola,Nampula,Beira,Chimoio,Quelimane',
    'MM|Myanmar|900|67|5|42|32|mm|Yangon,Mandalay,Naypyidaw,Mawlamyine,Bago,Taunggyi',
    'NA|Namibia|70|65|11|39|54|afs|Windhoek,Rundu,Walvis Bay,Oshakati',
    'NR|Nauru|0.3|64|13|28|100|pac|Yaren,Denigomodu',
    'NP|Nepal|560|71|5|26|22|np|Kathmandu,Pokhara,Lalitpur,Bharatpur,Biratnagar,Birgunj',
    'NL|Hà Lan|165|82|70|4|93|nl|Amsterdam,Rotterdam,The Hague,Utrecht,Eindhoven,Groningen',
    'NZ|New Zealand|58|82|52|5|87|en:85,pac:15|Auckland,Wellington,Christchurch,Hamilton,Dunedin',
    'NI|Nicaragua|130|75|7|16|60|es_la|Managua,León,Masaya,Matagalpa,Chinandega',
    'NE|Niger|1150|63|1.7|113|17|afr|Niamey,Zinder,Maradi,Agadez,Tahoua',
    'NG|Nigeria|7500|54|6|105|54|afw|Lagos,Kano,Ibadan,Abuja,Port Harcourt,Benin City,Kaduna,Enugu,Maiduguri,Jos',
    'MK|Bắc Macedonia|18|77|23|5|59|yu:75,sq:25|Skopje,Bitola,Kumanovo,Tetovo,Ohrid',
    'NO|Na Uy|52|83|90|2|84|nord|Oslo,Bergen,Trondheim,Stavanger,Tromsø',
    'OM|Oman|90|80|40|10|88|ar|Muscat,Seeb,Salalah,Sohar,Nizwa',
    'PK|Pakistan|6900|68|6.5|61|38|pk|Karachi,Lahore,Faisalabad,Rawalpindi,Islamabad,Multan,Peshawar,Quetta,Hyderabad',
    'PW|Palau|0.2|70|20|17|82|pac|Koror,Ngerulmud',
    'PS|Palestine|130|70|6|15|77|ar|Gaza,Hebron,Nablus,Ramallah,Jenin,Khan Younis,Bethlehem',
    'PA|Panama|75|79|37|14|69|es_la|Panama City,San Miguelito,Colón,David',
    'PG|Papua New Guinea|260|66|4.5|42|13|pac|Port Moresby,Lae,Mount Hagen,Madang,Goroka',
    'PY|Paraguay|140|73|16|19|63|es_la|Asunción,Ciudad del Este,San Lorenzo,Encarnación,Luque',
    'PE|Peru|500|77|16|13|79|es_la|Lima,Arequipa,Trujillo,Chiclayo,Cusco,Piura,Iquitos',
    'PH|Philippines|2000|69|11|26|48|ph|Manila,Quezon City,Davao,Cebu,Zamboanga,Caloocan,Baguio,Iloilo',
    'PL|Ba Lan|270|78|46|4|60|pl|Warsaw,Kraków,Łódź,Wrocław,Poznań,Gdańsk,Lublin',
    'PT|Bồ Đào Nha|85|82|43|3|67|pt|Lisbon,Porto,Braga,Coimbra,Funchal,Faro',
    'QA|Qatar|25|82|120|5|99|ar:55,in:25,ph:10,pk:10|Doha,Al Rayyan,Al Wakrah,Al Khor',
    'RO|Romania|160|76|43|7|54|ro|Bucharest,Cluj-Napoca,Timișoara,Iași,Constanța,Craiova,Brașov',
    'RU|Nga|1260|73|38|5|75|ru|Moscow,Saint Petersburg,Novosibirsk,Yekaterinburg,Kazan,Nizhny Novgorod,Chelyabinsk,Samara,Vladivostok,Omsk',
    'RW|Rwanda|380|67|3|39|18|afe|Kigali,Huye,Gisenyi,Musanze,Muhanga',
    'KN|Saint Kitts và Nevis|0.6|72|30|15|31|car|Basseterre,Charlestown',
    'LC|Saint Lucia|1.9|73|20|24|19|car|Castries,Vieux Fort,Gros Islet',
    'VC|Saint Vincent và Grenadines|1.3|70|18|16|54|car|Kingstown,Georgetown,Barrouallie',
    'WS|Samoa|5|72|6.5|17|18|pac|Apia,Salelologa',
    'SM|San Marino|0.2|85|75|2|97|it|San Marino,Serravalle,Borgo Maggiore',
    'ST|São Tomé và Príncipe|6|69|6|15|76|ao|São Tomé,Santo António,Neves',
    'SA|Ả Rập Xê Út|550|78|65|7|85|ar|Riyadh,Jeddah,Mecca,Medina,Dammam,Ta\'if,Tabuk',
    'SN|Senegal|560|69|4.5|39|49|afr|Dakar,Touba,Thiès,Saint-Louis,Kaolack,Ziguinchor',
    'RS|Serbia|62|75|25|5|57|yu|Belgrade,Novi Sad,Niš,Kragujevac,Subotica',
    'SC|Seychelles|1.5|74|35|14|58|fr:60,en:40|Victoria,Anse Boileau,Beau Vallon',
    'SL|Sierra Leone|240|61|2.8|100|44|afw|Freetown,Bo,Kenema,Makeni,Koidu',
    'SG|Singapore|33|84|130|2|100|sg:74,my:14,in:12|Tampines,Jurong West,Woodlands,Bedok,Ang Mo Kio,Toa Payoh,Punggol,Yishun',
    'SK|Slovakia|52|78|40|5|54|cz|Bratislava,Košice,Prešov,Žilina,Nitra',
    'SI|Slovenia|17|82|50|2|56|yu|Ljubljana,Maribor,Celje,Kranj,Koper',
    'SB|Quần đảo Solomon|24|70|2.6|19|26|pac|Honiara,Auki,Gizo',
    'SO|Somalia|900|57|1.6|104|48|so|Mogadishu,Hargeisa,Bosaso,Kismayo,Baidoa,Galkayo',
    'ZA|Nam Phi|1150|66|15|33|69|afs:78,en:14,in:8|Johannesburg,Cape Town,Durban,Pretoria,Gqeberha,Soweto,Bloemfontein,Polokwane',
    'SS|Nam Sudan|370|57|1.5|99|21|ss|Juba,Wau,Malakal,Yei,Bor',
    'ES|Tây Ban Nha|320|84|48|3|81|es|Madrid,Barcelona,Valencia,Seville,Zaragoza,Málaga,Bilbao,Murcia',
    'LK|Sri Lanka|320|77|15|7|19|lk|Colombo,Kandy,Galle,Jaffna,Negombo,Kurunegala,Batticaloa',
    'SD|Sudan|1500|66|3.5|55|36|ar|Khartoum,Omdurman,Port Sudan,Kassala,Nyala,El Obeid',
    'SR|Suriname|10|72|18|17|66|car:45,in:35,nl:20|Paramaribo,Lelydorp,Nieuw Nickerie',
    'SE|Thụy Điển|100|83|65|2|88|nord:85,ar:15|Stockholm,Gothenburg,Malmö,Uppsala,Västerås,Örebro',
    'CH|Thụy Sĩ|80|84|85|4|74|de:63,fr:25,it:12|Zurich,Geneva,Basel,Lausanne,Bern,Lucerne,Lugano',
    'SY|Syria|500|72|3.5|22|57|ar|Damascus,Aleppo,Homs,Latakia,Hama,Deir ez-Zor',
    'TJ|Tajikistan|250|71|5|30|28|tj|Dushanbe,Khujand,Kulob,Bokhtar',
    'TZ|Tanzania|2300|67|3.5|46|37|afe|Dar es Salaam,Mwanza,Arusha,Dodoma,Mbeya,Zanzibar,Morogoro',
    'TH|Thái Lan|520|80|22|8|53|th|Bangkok,Chiang Mai,Nakhon Ratchasima,Khon Kaen,Hat Yai,Udon Thani,Pattaya,Phuket',
    'TL|Đông Timor|35|69|5|50|32|ao|Dili,Baucau,Maliana,Suai',
    'TG|Togo|280|62|2.6|62|44|afr|Lomé,Sokodé,Kara,Kpalimé,Atakpamé',
    'TO|Tonga|2.3|71|7|11|23|pac|Nuku\'alofa,Neiafu',
    'TT|Trinidad và Tobago|16|73|30|17|53|car:60,in:40|Port of Spain,Chaguanas,San Fernando,Arima',
    'TN|Tunisia|160|76|13|16|70|ar|Tunis,Sfax,Sousse,Kairouan,Bizerte',
    'TR|Thổ Nhĩ Kỳ|1050|78|40|9|77|tr|Istanbul,Ankara,İzmir,Bursa,Antalya,Adana,Konya,Gaziantep,Diyarbakır',
    'TM|Turkmenistan|130|70|17|40|53|ca|Ashgabat,Türkmenabat,Daşoguz,Mary',
    'TV|Tuvalu|0.25|65|6|21|66|pac|Funafuti',
    'UG|Uganda|1700|68|3|40|26|afe|Kampala,Gulu,Lira,Mbarara,Jinja,Mbale',
    'UA|Ukraine|200|73|15|8|70|ua|Kyiv,Kharkiv,Odesa,Dnipro,Lviv,Zaporizhzhia,Vinnytsia',
    'AE|UAE|100|80|78|6|88|ar:45,in:30,pk:15,ph:10|Dubai,Abu Dhabi,Sharjah,Al Ain,Ajman',
    'GB|Vương quốc Anh|660|82|55|4|84|en:86,in:6,pk:5,afw:3|London,Birmingham,Manchester,Glasgow,Liverpool,Leeds,Edinburgh,Bristol,Cardiff,Belfast',
    'US|Hoa Kỳ (Mỹ)|3600|79|80|6|83|en:70,es_la:24,cn:3,in:3|New York,Los Angeles,Chicago,Houston,Phoenix,Philadelphia,San Antonio,San Diego,Dallas,Seattle,Miami,Atlanta,Denver,Boston',
    'UY|Uruguay|32|78|30|6|96|es_la|Montevideo,Salto,Paysandú,Las Piedras',
    'UZ|Uzbekistan|930|72|10|14|50|ca|Tashkent,Samarkand,Namangan,Andijan,Bukhara,Fergana',
    'VU|Vanuatu|9|71|3.2|23|26|pac|Port Vila,Luganville',
    'VE|Venezuela|480|73|7|24|88|es_la|Caracas,Maracaibo,Valencia,Barquisimeto,Maracay',
    'VN|Việt Nam|1350|75|14.3|20|38|vn|Hà Nội,TP. Hồ Chí Minh',
    'YE|Yemen|1000|64|2.5|60|39|ar|Sana\'a,Aden,Taiz,Hodeidah,Ibb',
    'ZM|Zambia|720|62|3.8|57|46|afs|Lusaka,Kitwe,Ndola,Kabwe,Livingstone',
    'ZW|Zimbabwe|460|62|3.3|50|32|afs|Harare,Bulawayo,Chitungwiza,Mutare,Gweru'
  ];

  var C = ROWS.map(function (row) {
    var f = row.split('|');
    return {
      code: f[0], name: f[1], births: +f[2], e0: +f[3], gdp: +f[4], u5: +f[5], urban: +f[6] / 100,
      pool: f[7], cities: f[8].split(',')
    };
  });
  var BY = {};
  C.forEach(function (c) { BY[c.code] = c; });

  // Hôn nhân cùng giới hợp pháp (tính đến 2025)
  var SSM = 'NL,BE,ES,CA,ZA,NO,SE,PT,IS,AR,DK,BR,FR,UY,NZ,GB,LU,US,IE,CO,FI,MT,DE,AU,AT,EC,CR,CL,CH,SI,CU,MX,AD,EE,GR,LI,TH'.split(',');
  // Quan hệ cùng giới bị hình sự hóa (ước tính ILGA 2024-2025)
  var CRIM = 'AF,DZ,BD,BN,BI,BF,CM,TD,KM,EG,ER,SZ,ET,GM,GH,GD,GN,GY,ID,IR,IQ,JM,KE,KI,KW,LB,LR,LY,MW,MY,MV,ML,MR,MA,MM,NG,OM,PK,PS,PG,QA,LC,VC,WS,SA,SN,SL,SB,SO,SS,LK,SD,SY,TZ,TG,TO,TN,TM,TV,UG,AE,UZ,YE,ZM'.split(',');

  // Tôn giáo theo bộ tên văn hóa (rất giản lược)
  var REL = {
    ar: 'Hồi giáo:93,Kitô giáo:5,Không tôn giáo:2', af: 'Hồi giáo:99,Khác:1', fa: 'Hồi giáo:96,Không tôn giáo:3,Khác:1',
    pk: 'Hồi giáo:96,Hindu giáo:2,Kitô giáo:2', bd: 'Hồi giáo:90,Hindu giáo:9,Phật giáo:1', so: 'Hồi giáo:99,Khác:1',
    tr: 'Hồi giáo:85,Không tôn giáo:13,Khác:2', az: 'Hồi giáo:90,Không tôn giáo:9,Khác:1', ca: 'Hồi giáo:80,Không tôn giáo:12,Chính Thống giáo:8',
    tj: 'Hồi giáo:96,Không tôn giáo:4', my: 'Hồi giáo:98,Khác:2', id: 'Hồi giáo:86,Tin Lành:7,Công giáo:3,Hindu giáo:2,Phật giáo:1',
    in: 'Hindu giáo:79,Hồi giáo:14,Kitô giáo:2,Sikh giáo:2,Phật giáo:1,Khác:2', np: 'Hindu giáo:81,Phật giáo:9,Hồi giáo:5,Kirat:3,Kitô giáo:2',
    bt: 'Phật giáo:75,Hindu giáo:23,Khác:2', lk: 'Phật giáo:70,Hindu giáo:13,Hồi giáo:10,Kitô giáo:7',
    cn: 'Không tôn giáo:74,Tín ngưỡng dân gian:15,Phật giáo:7,Kitô giáo:3,Hồi giáo:1', sg: 'Phật giáo:40,Không tôn giáo:30,Đạo giáo:10,Kitô giáo:20',
    kr: 'Không tôn giáo:51,Tin Lành:20,Phật giáo:16,Công giáo:11,Khác:2', kp: 'Không tôn giáo:90,Tín ngưỡng truyền thống:10',
    jp: 'Thần đạo & Phật giáo:69,Không tôn giáo:28,Kitô giáo:1,Khác:2', mn: 'Phật giáo:52,Không tôn giáo:40,Hồi giáo:3,Khác:5',
    th: 'Phật giáo:93,Hồi giáo:5,Kitô giáo:2', kh: 'Phật giáo:97,Hồi giáo:2,Kitô giáo:1', la: 'Phật giáo:65,Tín ngưỡng truyền thống:31,Kitô giáo:2,Khác:2',
    mm: 'Phật giáo:88,Kitô giáo:6,Hồi giáo:4,Khác:2', ph: 'Công giáo:79,Tin Lành:10,Hồi giáo:6,Khác:5',
    he: 'Do Thái giáo:98,Khác:2', hy: 'Chính Thống giáo:95,Khác:5', ka: 'Chính Thống giáo:84,Hồi giáo:10,Khác:6',
    ru: 'Chính Thống giáo:65,Không tôn giáo:25,Hồi giáo:7,Khác:3', ua: 'Chính Thống giáo:70,Công giáo Hy Lạp:10,Không tôn giáo:16,Khác:4',
    bg: 'Chính Thống giáo:72,Hồi giáo:10,Không tôn giáo:15,Khác:3', ro: 'Chính Thống giáo:85,Công giáo:5,Tin Lành:6,Khác:4',
    gr: 'Chính Thống giáo:90,Không tôn giáo:7,Khác:3', yu: 'Chính Thống giáo:40,Công giáo:35,Hồi giáo:20,Không tôn giáo:5',
    sq: 'Hồi giáo:58,Công giáo:10,Chính Thống giáo:7,Không tôn giáo:25',
    pl: 'Công giáo:85,Không tôn giáo:12,Khác:3', it: 'Công giáo:78,Không tôn giáo:18,Khác:4', es: 'Công giáo:58,Không tôn giáo:39,Khác:3',
    pt: 'Công giáo:80,Không tôn giáo:15,Khác:5', fr: 'Công giáo:47,Không tôn giáo:40,Hồi giáo:8,Khác:5', ht: 'Công giáo:55,Tin Lành:30,Vodou & khác:15',
    de: 'Không tôn giáo:43,Công giáo:25,Tin Lành:23,Hồi giáo:6,Khác:3', nl: 'Không tôn giáo:57,Công giáo:18,Tin Lành:14,Hồi giáo:5,Khác:6',
    nord: 'Tin Lành (Luther):60,Không tôn giáo:35,Khác:5', fi: 'Tin Lành (Luther):65,Không tôn giáo:33,Khác:2',
    cz: 'Không tôn giáo:72,Công giáo:20,Khác:8', hu: 'Công giáo:50,Tin Lành:15,Không tôn giáo:30,Khác:5',
    lt: 'Công giáo:75,Không tôn giáo:15,Chính Thống giáo:5,Khác:5', lv: 'Tin Lành (Luther):30,Công giáo:20,Chính Thống giáo:20,Không tôn giáo:30', ee: 'Không tôn giáo:70,Chính Thống giáo:16,Tin Lành (Luther):10,Khác:4',
    en: 'Kitô giáo:55,Không tôn giáo:38,Khác:7', car: 'Tin Lành:65,Công giáo:20,Không tôn giáo:10,Khác:5',
    es_la: 'Công giáo:68,Tin Lành:20,Không tôn giáo:10,Khác:2', br: 'Công giáo:56,Tin Lành:27,Không tôn giáo:12,Khác:5',
    afw: 'Kitô giáo:55,Hồi giáo:40,Tín ngưỡng truyền thống:5', afr: 'Hồi giáo:50,Kitô giáo:42,Tín ngưỡng truyền thống:8',
    afe: 'Kitô giáo:82,Hồi giáo:12,Khác:6', afs: 'Kitô giáo:85,Tín ngưỡng truyền thống:10,Khác:5', et: 'Chính Thống giáo:44,Hồi giáo:34,Tin Lành:19,Khác:3',
    ss: 'Kitô giáo:60,Tín ngưỡng truyền thống:33,Hồi giáo:7', ao: 'Công giáo:55,Tin Lành:30,Khác:15', mg: 'Kitô giáo:85,Tín ngưỡng truyền thống:10,Hồi giáo:5',
    pac: 'Kitô giáo:95,Khác:5'
  };

  G.W = { C: C, BY: BY, SSM: SSM, CRIM: CRIM, REL: REL, BIRTHS_TOTAL: C.reduce(function (s, c) { return s + c.births; }, 0) };
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
/* ===== js/names.js ===== */
/* Bộ tên theo văn hóa cho chế độ Thế giới.
   order: 'sf' = họ trước tên (Đông Á, Hungary…), mặc định tên trước họ.
   fem: quy tắc đổi họ cho nữ ('slav', 'cz', 'gr'); LF = danh sách họ riêng cho nữ.
   style: 'double' (2 họ, kiểu Tây Ban Nha/Bồ Đào Nha), 'patronym' (họ = tên cha), 'bin' (bin/binti).
   Với cn/kr/jp/kp/sg mỗi mục có dạng Latin:chữ gốc(:Hán-Việt). */
(function (G) {
  'use strict';
  var P = {
    cn: { order: 'sf', native: 1,
      L: 'Wang:王:Vương,Li:李:Lý,Zhang:张:Trương,Liu:刘:Lưu,Chen:陈:Trần,Yang:杨:Dương,Huang:黄:Hoàng,Zhao:赵:Triệu,Wu:吴:Ngô,Zhou:周:Chu,Xu:徐:Từ,Sun:孙:Tôn,Ma:马:Mã,Zhu:朱:Chu,Hu:胡:Hồ,Guo:郭:Quách,He:何:Hà,Lin:林:Lâm,Gao:高:Cao,Luo:罗:La',
      M: 'Hao:浩:Hạo,Wei:伟:Vĩ,Yu:宇:Vũ,Jie:杰:Kiệt,Ming:明:Minh,Jun:俊:Tuấn,Lei:磊:Lỗi,Tao:涛:Đào,Yang:洋:Dương,Chen:晨:Thần,Haoran:浩然:Hạo Nhiên,Yuxuan:宇轩:Vũ Hiên,Junjie:俊杰:Tuấn Kiệt,Zhiqiang:志强:Chí Cường,Zixuan:子轩:Tử Hiên,Bowen:博文:Bác Văn,Jianguo:建国:Kiến Quốc,Ruichen:瑞辰:Thụy Thần',
      F: 'Xin:欣:Hân,Jing:静:Tĩnh,Li:丽:Lệ,Na:娜:Na,Ying:颖:Dĩnh,Yan:燕:Yến,Xiaoyu:晓雨:Hiểu Vũ,Zihan:梓涵:Tử Hàm,Yutong:雨彤:Vũ Đồng,Xinyi:欣怡:Hân Di,Shiyu:诗雨:Thi Vũ,Mei:美:Mỹ,Fang:芳:Phương,Lan:兰:Lan,Ruoxi:若曦:Nhược Hi,Yuxi:语汐:Ngữ Tịch,Jiayi:佳怡:Giai Di,Hui:慧:Tuệ' },
    sg: { order: 'sf', native: 1,
      L: 'Tan:陈:Trần,Lim:林:Lâm,Lee:李:Lý,Ng:黄:Hoàng,Ong:王:Vương,Wong:黄:Hoàng,Goh:吴:Ngô,Chua:蔡:Thái,Chan:曾:Tằng,Koh:许:Hứa,Teo:张:Trương,Ang:洪:Hồng,Yeo:杨:Dương,Tay:郑:Trịnh',
      M: 'Wei Ming:伟明:Vĩ Minh,Jun Jie:俊杰:Tuấn Kiệt,Zhi Hao:志豪:Chí Hào,Kai Xiang:凯翔:Khải Tường,Jia Hao:家豪:Gia Hào,Yong Sheng:永胜:Vĩnh Thắng,Wen Jie:文杰:Văn Kiệt,Rui En:睿恩:Duệ Ân',
      F: 'Hui Min:慧敏:Tuệ Mẫn,Xin Yi:欣怡:Hân Di,Jia Ying:佳颖:Giai Dĩnh,Li Ting:丽婷:Lệ Đình,Shu Fen:淑芬:Thục Phân,Wen Qi:文琪:Văn Kỳ,Yu Xuan:雨萱:Vũ Huyên,Mei Ling:美玲:Mỹ Linh' },
    kr: { order: 'sf', native: 1,
      L: 'Kim:김,Lee:이,Park:박,Choi:최,Jung:정,Kang:강,Cho:조,Yoon:윤,Jang:장,Lim:임,Han:한,Oh:오,Seo:서,Shin:신,Kwon:권,Hwang:황,Song:송',
      M: 'Min-jun:민준,Seo-jun:서준,Do-yun:도윤,Ye-jun:예준,Si-woo:시우,Ha-jun:하준,Ji-ho:지호,Joo-won:주원,Ji-hoon:지훈,Hyun-woo:현우,Jun-seo:준서,Eun-woo:은우,Dong-hyun:동현,Sung-min:성민,Tae-yang:태양,Woo-jin:우진',
      F: 'Seo-yeon:서연,Seo-yun:서윤,Ji-woo:지우,Ha-eun:하은,Min-seo:민서,Ji-yoo:지유,Yoon-seo:윤서,Chae-won:채원,Su-ah:수아,Ji-min:지민,Da-eun:다은,Ye-eun:예은,Soo-jin:수진,Hye-jin:혜진,Yu-na:유나,Ha-rin:하린' },
    kp: { order: 'sf', native: 1,
      L: 'Kim:김,Ri:리,Pak:박,Choe:최,Jong:정,Kang:강,Jo:조,Han:한,Ryu:류,Hong:홍,Ryang:량,O:오',
      M: 'Chol-min:철민,Song-il:성일,Kwang-hyok:광혁,Myong-chol:명철,Jin-hyok:진혁,Yong-su:영수,Il-nam:일남,Chung-guk:충국,Hyok-chol:혁철,Un-chol:은철',
      F: 'Kum-hui:금희,Son-hwa:선화,Un-jong:은정,Hyang-mi:향미,Ok-sun:옥순,Myong-hui:명희,Chun-hwa:춘화,Yong-ae:영애,Hye-gyong:혜경,Su-ryon:수련' },
    jp: { order: 'sf', native: 1,
      L: 'Sato:佐藤,Suzuki:鈴木,Takahashi:高橋,Tanaka:田中,Watanabe:渡辺,Ito:伊藤,Yamamoto:山本,Nakamura:中村,Kobayashi:小林,Kato:加藤,Yoshida:吉田,Yamada:山田,Sasaki:佐々木,Matsumoto:松本,Inoue:井上,Kimura:木村,Hayashi:林,Shimizu:清水',
      M: 'Haruto:陽翔,Sota:蒼太,Ren:蓮,Minato:湊,Yuto:悠斗,Riku:陸,Hinata:陽向,Sora:颯,Daiki:大輝,Takumi:拓海,Kenta:健太,Yuki:勇気,Haruki:春樹,Kaito:海斗,Itsuki:樹,Shota:翔太',
      F: 'Himari:陽葵,Mei:芽依,Tsumugi:紬,Sakura:桜,Yui:結衣,Mio:澪,Rin:凛,Aoi:葵,Hina:陽菜,Yuna:結菜,Akari:朱莉,Hana:花,Misaki:美咲,Nanami:七海,Koharu:心春,Saki:咲' },
    th: { M: 'Somchai,Somsak,Anan,Kittisak,Nattapong,Thanakorn,Prasert,Wichai,Chaiwat,Pongsakorn,Phuwadon,Thanawat,Sarawut,Apichat',
      F: 'Siriporn,Nattaya,Ploy,Kanokwan,Pimchanok,Supaporn,Wanida,Malee,Chompoo,Arunee,Duangjai,Rattana,Sasithorn,Pornthip',
      L: 'Saetang,Srisuk,Wongsawat,Chaiyaporn,Thongchai,Rattanakorn,Sukprasert,Boonmee,Kaewmanee,Phromma,Jaidee,Somboon,Charoenpol,Inthasorn' },
    kh: { order: 'sf', L: 'Sok,Chea,Kim,Heng,Chan,Meas,Keo,Pich,Sum,Ly,Nhem,Prak,Seng,Ouk,Touch',
      M: 'Dara,Sophal,Vuthy,Rithy,Sokha,Visal,Piseth,Vannak,Chantha,Kosal,Samnang,Sovann,Rotha,Pheakdey',
      F: 'Sreymom,Sophea,Chanthou,Bopha,Malis,Sreyneang,Phalla,Sokunthea,Raksmey,Channary,Kanha,Sreyleak,Davy,Leakhena' },
    la: { M: 'Somphone,Khamla,Bounmy,Souksavanh,Phonesavanh,Thongchanh,Vilay,Kongkham,Sengphet,Bouasone,Khamphet,Anousone',
      F: 'Keo,Noy,Vanida,Malaythong,Phetsamone,Chanthala,Souphaphone,Manivanh,Bouakham,Douangchanh,Sisouk,Phonevilay',
      L: 'Phommachanh,Sisavath,Vongsa,Keomany,Inthavong,Phengsavath,Saysana,Sengsouriya,Chanthavong,Douangdeuane,Xayavong,Souvannavong' },
    mm: { M: 'Aung Ko,Zaw Min,Kyaw Zin,Htet Naing,Min Thu,Thant Zin,Aung Myo,Ye Lin,Kyaw Kyaw,Soe Moe,Hein Htet,Myo Win',
      F: 'Su Su,Aye Aye,Thandar,Nilar,Hnin Wai,May Thu,Ei Mon,Khin Khin,Phyu Phyu,Thiri,Zin Mar,Yadanar',
      L: 'Aung,Min,Htun,Oo,Naing,Win,Kyaw,Zaw,Lwin,Tun', LF: 'Hlaing,Myint,Thant,Nwe,Mon,Kyi,Aye,Htwe,Phyo,San' },
    id: { M: 'Budi,Agus,Andi,Rizky,Dimas,Fajar,Hendra,Arif,Bayu,Eko,Muhammad,Aditya,Yoga,Reza,Wahyu,Ilham',
      F: 'Siti,Dewi,Putri,Ayu,Sri,Nur,Rina,Indah,Fitri,Wulan,Anisa,Dian,Ratna,Nabila,Aulia,Mega',
      L: 'Santoso,Wijaya,Saputra,Pratama,Hidayat,Kusuma,Setiawan,Nugroho,Gunawan,Susanto,Purnomo,Siregar,Simanjuntak,Hasibuan,Ramadhan,Firmansyah',
      LF: 'Lestari,Wati,Rahayu,Sari,Kurniawati,Puspita,Handayani,Wulandari,Saputri,Pratiwi,Anggraini,Permata' },
    my: { style: 'bin', M: 'Ahmad,Muhammad,Amir,Haziq,Faiz,Danial,Hafiz,Irfan,Aiman,Syafiq,Zulkifli,Hakim,Firdaus,Aqil,Rizal,Azman',
      F: 'Nur Aisyah,Siti Nurhaliza,Nurul Izzah,Aina,Aisyah,Sofea,Alya,Hannah,Damia,Farah,Nabila,Puteri,Balqis,Qistina,Zara,Hidayah',
      L: 'Abdullah,Ismail,Hassan,Ibrahim,Yusof,Rahman,Osman,Hamid,Razak,Aziz,Salleh,Ahmad,Kamal,Jamil' },
    ph: { M: 'Jose,Juan,Mark,John Paul,Christian,Jericho,Angelo,Carlo,Miguel,Rafael,Joshua,Kenneth,Ramon,Paolo,Nathaniel,Rodel',
      F: 'Maria,Angelica,Kristine,Princess,Mary Joy,Jasmine,Nicole,Andrea,Rose Ann,Camille,Kimberly,Althea,Lorna,Joy,Mae,Divina',
      L: 'Santos,Reyes,Cruz,Bautista,Ocampo,Garcia,Mendoza,Torres,Tomas,Andrada,Castillo,Flores,Villanueva,Ramos,Dela Cruz,Aquino,Navarro,Mercado' },
    in: { M: 'Aarav,Vivaan,Aditya,Arjun,Rohan,Rahul,Amit,Suresh,Ramesh,Vijay,Sanjay,Arun,Karthik,Imran,Mohammed,Rajesh,Deepak,Harpreet,Ankit,Manoj',
      F: 'Priya,Ananya,Aadhya,Diya,Pooja,Sunita,Kavita,Lakshmi,Meera,Neha,Anjali,Divya,Fatima,Shreya,Kavya,Sneha,Pallavi,Rekha,Simran,Asha',
      L: 'Sharma,Kumar,Singh,Patel,Gupta,Yadav,Reddy,Iyer,Nair,Das,Mishra,Khan,Verma,Joshi,Rao,Chauhan,Pillai,Banerjee,Mehta,Ansari,Mukherjee,Kaur' },
    pk: { M: 'Muhammad,Ali,Ahmed,Hassan,Usman,Bilal,Hamza,Imran,Faisal,Zain,Abdullah,Asad,Tariq,Saad,Waqas,Shahid',
      F: 'Ayesha,Fatima,Zainab,Hira,Sana,Maryam,Amna,Iqra,Sadia,Nimra,Mahnoor,Rabia,Saba,Kiran,Aliya,Noor',
      L: 'Khan,Ahmed,Malik,Hussain,Butt,Qureshi,Chaudhry,Shah,Iqbal,Raza,Akhtar,Siddiqui,Abbasi,Rajput,Awan,Baloch' },
    bd: { M: 'Mohammad,Abdul,Rafiq,Sabbir,Tanvir,Arif,Mahmud,Rakib,Shakil,Nayeem,Sohel,Kamal,Habib,Rashed,Sumon,Jahid',
      F: 'Fatema,Nusrat,Sharmin,Taslima,Farzana,Ayesha,Sadia,Jannat,Sumaiya,Rumana,Shirin,Nasrin,Tania,Mitu,Moushumi,Rupa',
      L: 'Hossain,Rahman,Islam,Ahmed,Uddin,Alam,Chowdhury,Sarkar,Miah,Haque,Roy,Das,Mondal,Sheikh',
      LF: 'Akter,Khatun,Begum,Sultana,Islam,Rahman,Chowdhury,Roy,Das,Parvin' },
    lk: { M: 'Kasun,Nuwan,Chamara,Dinesh,Saman,Tharindu,Ruwan,Lahiru,Asanka,Mahesh,Pradeep,Nimal,Kumar,Sivakumar',
      F: 'Nadeesha,Dilini,Chathurika,Sanduni,Ishara,Hasini,Kumari,Nirosha,Tharushi,Madhavi,Anoma,Sachini,Priyanka,Kavitha',
      L: 'Perera,Fernando,de Silva,Bandara,Jayasinghe,Rathnayake,Wickramasinghe,Gunawardena,Dissanayake,Herath,Kumara,Senanayake,Rajapaksha,Sivanathan' },
    np: { M: 'Ram,Bikash,Suman,Sagar,Prakash,Krishna,Anish,Rajesh,Dipesh,Bishal,Sanjay,Hari,Nabin,Roshan',
      F: 'Sita,Gita,Sunita,Anjali,Pooja,Sarita,Asmita,Kabita,Sabina,Rojina,Srijana,Laxmi,Sushmita,Puja',
      L: 'Shrestha,Gurung,Tamang,Thapa,Magar,Rai,Adhikari,Karki,Sharma,Poudel,Bhattarai,Khadka,Limbu,Maharjan,Basnet,Yadav' },
    bt: { M: 'Tshering,Dorji,Karma,Sonam,Pema,Kinley,Ugyen,Jigme,Ngawang,Tashi,Sangay,Namgay',
      F: 'Dechen,Choki,Pema,Sonam,Kinley,Yangchen,Tshering,Deki,Dema,Karma,Zangmo,Wangmo',
      L: 'Dorji,Wangchuk,Tenzin,Norbu,Penjor,Gyeltshen,Namgyel,Rinzin,Phuntsho', LF: 'Wangmo,Zangmo,Lhamo,Yangzom,Choden,Dema,Pelden,Yangki,Lhaden' },
    ar: { M: 'Mohammed,Ahmed,Ali,Omar,Youssef,Khalid,Hassan,Ibrahim,Abdullah,Mahmoud,Mustafa,Karim,Tariq,Salem,Hamza,Yassin,Adam,Rami,Said,Bilal',
      F: 'Fatima,Mariam,Aisha,Nour,Layla,Sara,Huda,Amira,Salma,Rania,Yasmin,Hana,Zainab,Rahma,Dina,Lina,Khadija,Malak,Jana,Hiba',
      L: 'Al-Hassan,Al-Ahmad,Haddad,Mansour,Khalil,Saleh,Nasser,Hamdan,Al-Masri,Darwish,Ibrahim,Abdallah,Al-Sayed,Othman,Farouk,Hussein,Mahmoud,Al-Rashid,Bakr,Qasim,Benali,El Amrani,Bouzid,Al-Tamimi' },
    af: { M: 'Ahmad,Mohammad,Abdul,Farid,Hamid,Wahid,Rahim,Najib,Sharif,Zabihullah,Mirwais,Habib,Jawad,Samiullah',
      F: 'Fatima,Zahra,Maryam,Mariam,Shabnam,Laila,Freshta,Malalai,Nargis,Parwana,Zarghona,Sima,Homa,Sakina',
      L: 'Ahmadzai,Karimi,Rahimi,Hakimi,Popal,Noori,Sultani,Wardak,Stanekzai,Hashimi,Amiri,Safi,Durrani,Haidari' },
    fa: { M: 'Mohammad,Ali,Hossein,Reza,Amir,Mehdi,Hamid,Arash,Kian,Dariush,Parsa,Saeed,Babak,Farhad,Hamed,Sina',
      F: 'Fatemeh,Zahra,Maryam,Narges,Sara,Leila,Shirin,Nazanin,Parisa,Mahsa,Niloufar,Roya,Yasmin,Setareh,Ziba,Elham',
      L: 'Hosseini,Mohammadi,Ahmadi,Rezaei,Moradi,Karimi,Jafari,Rahimi,Sadeghi,Hashemi,Ghorbani,Mousavi,Tehrani,Kazemi,Azizi,Rostami' },
    tj: { fem: 'slav', M: 'Firdavs,Rustam,Farrukh,Shohrukh,Jamshed,Behruz,Daler,Sino,Umed,Bakhtiyor,Siyovush,Faridun',
      F: 'Madina,Nigina,Zarina,Mehrona,Shahnoza,Firuza,Gulnora,Parvina,Malika,Sitora,Nilufar,Dilnoza',
      L: 'Rahimov,Karimov,Saidov,Nazarov,Sharipov,Davlatov,Rajabov,Kurbonov,Mirzoev,Safarov,Nabiev,Sodiqov' },
    ca: { fem: 'slav', M: 'Nurlan,Yerlan,Daniyar,Aibek,Timur,Rustam,Bekzod,Sardor,Azamat,Askar,Bakhyt,Dauren,Jasur,Islom,Murat,Serdar',
      F: 'Aigerim,Dana,Madina,Aruzhan,Gulnara,Dilnoza,Malika,Zarina,Kamila,Aizhan,Saule,Nargiza,Ainura,Gulshan,Maral,Aisuluu',
      L: 'Nurlanov,Akhmetov,Abdullaev,Karimov,Toktarov,Bekov,Sultanov,Yusupov,Rakhimov,Alimov,Ermekov,Mamytov,Usmanov,Saparov,Berdiev,Atayev' },
    az: { fem: 'slav', M: 'Ali,Elvin,Rashad,Murad,Tural,Ramil,Kamran,Farid,Orkhan,Nijat,Vugar,Emin',
      F: 'Aysel,Leyla,Gunel,Nigar,Sevinj,Aynur,Narmin,Fidan,Lala,Ulviyya,Konul,Shahla',
      L: 'Aliyev,Mammadov,Hasanov,Huseynov,Guliyev,Ismayilov,Abbasov,Rzayev,Suleymanov,Jafarov,Karimov,Valiyev' },
    tr: { M: 'Mehmet,Mustafa,Ahmet,Ali,Hüseyin,Hasan,Yusuf,Emre,Burak,Murat,Eymen,Ömer,Kerem,Can,Mert,Alparslan',
      F: 'Ayşe,Fatma,Zeynep,Elif,Emine,Hatice,Merve,Esra,Defne,Ecrin,Büşra,Selin,Asel,Nehir,Azra,Melek',
      L: 'Yılmaz,Kaya,Demir,Şahin,Çelik,Yıldız,Yıldırım,Öztürk,Aydın,Özdemir,Arslan,Doğan,Kılıç,Aslan,Çetin,Koç,Kurt,Polat' },
    ru: { fem: 'slav', M: 'Aleksandr,Dmitry,Maksim,Sergei,Andrei,Alexei,Ivan,Mikhail,Nikolai,Artyom,Kirill,Egor,Vladimir,Pavel,Roman,Timofei',
      F: 'Anastasia,Maria,Anna,Ekaterina,Olga,Elena,Tatiana,Natalia,Irina,Svetlana,Sofia,Polina,Daria,Ksenia,Yulia,Varvara',
      L: 'Ivanov,Smirnov,Kuznetsov,Popov,Vasiliev,Petrov,Sokolov,Mikhailov,Novikov,Fedorov,Morozov,Volkov,Alekseev,Lebedev,Kozlov,Pavlov,Orlov,Belov' },
    ua: { fem: 'slav', M: 'Oleksandr,Andriy,Dmytro,Serhiy,Mykola,Ivan,Taras,Bohdan,Yuriy,Vasyl,Maksym,Oleh,Artem,Volodymyr',
      F: 'Olena,Oksana,Iryna,Nataliya,Tetiana,Yulia,Kateryna,Anastasiia,Sofiia,Mariia,Viktoriia,Halyna,Solomiia,Daryna',
      L: 'Shevchenko,Kovalenko,Bondarenko,Tkachenko,Kravchenko,Melnyk,Boyko,Kovalchuk,Oliynyk,Shevchuk,Polishchuk,Lysenko,Marchenko,Rudenko,Savchenko' },
    pl: { fem: 'slav', M: 'Jan,Piotr,Krzysztof,Andrzej,Tomasz,Paweł,Michał,Marcin,Jakub,Kacper,Antoni,Szymon,Filip,Mateusz',
      F: 'Anna,Maria,Katarzyna,Małgorzata,Agnieszka,Barbara,Zofia,Zuzanna,Julia,Maja,Hanna,Oliwia,Alicja,Magdalena',
      L: 'Nowak,Kowalski,Wiśniewski,Wójcik,Kowalczyk,Kamiński,Lewandowski,Zieliński,Szymański,Woźniak,Dąbrowski,Kozłowski,Mazur,Jankowski' },
    cz: { fem: 'cz', M: 'Jiří,Jan,Petr,Josef,Pavel,Martin,Tomáš,Jakub,Lukáš,Ondřej,David,Matyáš,Marek,Michal',
      F: 'Jana,Eva,Hana,Anna,Lenka,Kateřina,Lucie,Věra,Tereza,Eliška,Adéla,Natálie,Klára,Petra',
      L: 'Novák,Svoboda,Novotný,Dvořák,Černý,Procházka,Kučera,Veselý,Horák,Němec,Pokorný,Pospíšil,Hájek,Král' },
    yu: { M: 'Marko,Nikola,Luka,Stefan,Ivan,Milan,Aleksandar,Dragan,Petar,Filip,Lazar,Nemanja,Tomislav,Amar,Emir,Luka',
      F: 'Ana,Marija,Jelena,Milica,Ivana,Sara,Mia,Tijana,Katarina,Dragana,Lejla,Amina,Petra,Maja,Nina,Lana',
      L: 'Jovanović,Petrović,Nikolić,Marković,Đorđević,Horvat,Kovačević,Babić,Marić,Hodžić,Popović,Pavlović,Knežević,Begović,Novak,Krajnc' },
    bg: { fem: 'slav', M: 'Georgi,Ivan,Dimitar,Nikolay,Hristo,Petar,Aleksandar,Todor,Stoyan,Martin,Viktor,Kaloyan',
      F: 'Maria,Ivanka,Elena,Yordanka,Desislava,Gergana,Viktoria,Nikol,Radostina,Petya,Tsvetelina,Kalina',
      L: 'Ivanov,Georgiev,Dimitrov,Petrov,Nikolov,Hristov,Stoyanov,Todorov,Iliev,Angelov,Atanasov,Kolev' },
    ro: { M: 'Andrei,Alexandru,Ion,Mihai,Gabriel,Ștefan,David,Cristian,Florin,Bogdan,Răzvan,Vasile,Lucian,Matei',
      F: 'Maria,Elena,Ioana,Andreea,Ana,Alexandra,Mihaela,Gabriela,Cristina,Daria,Sofia,Irina,Bianca,Raluca',
      L: 'Popescu,Ionescu,Popa,Pop,Constantin,Stan,Dumitru,Stoica,Gheorghe,Rusu,Munteanu,Matei,Ciobanu,Lungu,Ceban,Rotaru' },
    hu: { order: 'sf', M: 'Bence,Máté,Levente,Dominik,Dániel,László,István,Zoltán,Gábor,Péter,Ádám,Marcell,Zsolt,Attila',
      F: 'Hanna,Anna,Zsófia,Luca,Lili,Eszter,Katalin,Erzsébet,Ildikó,Réka,Boglárka,Dóra,Viktória,Nóra',
      L: 'Nagy,Kovács,Tóth,Szabó,Horváth,Varga,Kiss,Molnár,Németh,Farkas,Balogh,Papp,Takács,Juhász' },
    gr: { fem: 'gr', M: 'Georgios,Ioannis,Konstantinos,Dimitrios,Nikolaos,Panagiotis,Christos,Vasileios,Athanasios,Michail,Alexandros,Spyros,Andreas',
      F: 'Maria,Eleni,Aikaterini,Vasiliki,Sofia,Georgia,Anastasia,Dimitra,Ioanna,Konstantina,Eirini,Despina,Christina',
      L: 'Papadopoulos,Papadakis,Georgiou,Nikolaou,Dimitriou,Konstantinou,Ioannou,Vlachos,Pappas,Oikonomou,Karagiannis,Makris,Christodoulou,Antoniou' },
    de: { M: 'Lukas,Leon,Finn,Paul,Jonas,Elias,Noah,Felix,Maximilian,Thomas,Michael,Andreas,Stefan,Jürgen,Matthias,Tobias',
      F: 'Emma,Mia,Hannah,Sophia,Lea,Lena,Anna,Laura,Julia,Sabine,Petra,Katharina,Marie,Clara,Johanna,Ursula',
      L: 'Müller,Schmidt,Schneider,Fischer,Weber,Meyer,Wagner,Becker,Schulz,Hoffmann,Koch,Richter,Bauer,Klein,Wolf,Gruber,Huber,Keller,Schröder,Neumann' },
    fr: { M: 'Gabriel,Louis,Raphaël,Jules,Adam,Lucas,Léo,Hugo,Arthur,Nathan,Thomas,Nicolas,Julien,Pierre,Antoine,Mathis',
      F: 'Jade,Louise,Emma,Alice,Chloé,Léa,Manon,Camille,Inès,Sarah,Juliette,Marie,Céline,Élise,Margaux,Lina',
      L: 'Martin,Bernard,Dubois,Thomas,Robert,Richard,Petit,Durand,Leroy,Moreau,Simon,Laurent,Lefebvre,Michel,Garcia,Fontaine,Rousseau,Girard,Lambert,Bonnet' },
    ht: { M: 'Wilson,Jameson,Ricardo,Kervens,Jacky,Stanley,Frantz,Junior,Jean-Robert,Ronald,Évens,Marc,Jean-Claude,Wisly',
      F: 'Marie,Nadège,Mirlande,Rose-Marie,Fabiola,Guerline,Sophonie,Esther,Lovely,Judith,Roseline,Daphnée,Widline,Nathalie',
      L: 'Joseph,Jean,Pierre,Louis,Charles,Jean-Baptiste,Saint-Louis,Paul,Augustin,Dorvil,Etienne,Michel,Desir,Noel' },
    en: { M: 'Oliver,Jack,Noah,James,William,Henry,Liam,Ethan,Lucas,Michael,David,Daniel,Thomas,Benjamin,Samuel,Jacob,Logan,Mason,Ryan,Charlie',
      F: 'Olivia,Emma,Amelia,Charlotte,Sophia,Isla,Ava,Mia,Emily,Grace,Chloe,Sarah,Jessica,Hannah,Lily,Ella,Harper,Ruby',
      L: 'Smith,Johnson,Williams,Brown,Jones,Miller,Davis,Wilson,Taylor,Anderson,Thomas,Moore,Martin,Jackson,White,Harris,Clark,Lewis,Walker,Hall,Young,King,Wright,Evans,Roberts,Murphy,O\'Brien,Kelly,Campbell,Stewart,Thompson' },
    car: { M: 'Andre,Jamal,Shane,Kevin,Tyrone,Marlon,Dwayne,Ricardo,Kemar,Rohan,Damion,Jerome,Omari,Shamar',
      F: 'Shanice,Kerry-Ann,Tamika,Keisha,Monique,Simone,Latoya,Ashanti,Renee,Natalia,Gabrielle,Alicia,Jada,Tiana',
      L: 'Brown,Williams,Campbell,Thompson,Clarke,Reid,Grant,Henry,Bailey,Richards,Joseph,Charles,Gordon,Edwards,Francis,Scott' },
    es: { style: 'double', M: 'Hugo,Martín,Lucas,Mateo,Leo,Daniel,Alejandro,Pablo,Manuel,Álvaro,Javier,Antonio,José,David,Sergio,Jorge',
      F: 'Lucía,Sofía,Martina,María,Julia,Paula,Valeria,Emma,Daniela,Carmen,Laura,Ana,Elena,Isabel,Marta,Alba',
      L: 'García,Rodríguez,González,Fernández,López,Martínez,Sánchez,Pérez,Gómez,Martín,Jiménez,Ruiz,Hernández,Díaz,Moreno,Muñoz,Álvarez,Romero,Navarro,Torres' },
    es_la: { style: 'double', M: 'Santiago,Mateo,Sebastián,Matías,Diego,Nicolás,Alejandro,Samuel,Daniel,José,Juan,Luis,Carlos,Miguel Ángel,Emiliano,Jesús,Andrés,Gabriel',
      F: 'Sofía,Valentina,Isabella,Camila,Valeria,Mariana,Gabriela,Daniela,María José,Ximena,Luciana,Victoria,Fernanda,Guadalupe,Ana,Paola',
      L: 'García,Rodríguez,Martínez,Hernández,López,González,Pérez,Sánchez,Ramírez,Torres,Flores,Rivera,Gómez,Díaz,Cruz,Morales,Reyes,Gutiérrez,Ortiz,Castillo,Rojas,Vargas,Mendoza,Quispe,Mamani' },
    pt: { style: 'double', M: 'Francisco,João,Afonso,Tomás,Duarte,Rodrigo,Santiago,Miguel,Pedro,Diogo,Rafael,Martim,Gonçalo,Tiago',
      F: 'Maria,Leonor,Matilde,Beatriz,Carolina,Mariana,Ana,Inês,Sofia,Margarida,Joana,Rita,Catarina,Francisca',
      L: 'Silva,Santos,Ferreira,Pereira,Oliveira,Costa,Rodrigues,Martins,Jesus,Sousa,Fernandes,Gonçalves,Gomes,Lopes,Marques,Almeida,Ribeiro,Carvalho' },
    br: { style: 'double', M: 'Miguel,Arthur,Gael,Heitor,Theo,Davi,Gabriel,Bernardo,Samuel,João Pedro,Lucas,Pedro,Rafael,Matheus,Gustavo,Felipe,Bruno,Thiago',
      F: 'Helena,Alice,Laura,Maria Alice,Valentina,Heloísa,Maria Clara,Cecília,Júlia,Ana Clara,Beatriz,Larissa,Camila,Fernanda,Mariana,Gabriela',
      L: 'Silva,Santos,Oliveira,Souza,Rodrigues,Ferreira,Alves,Pereira,Lima,Gomes,Costa,Ribeiro,Martins,Carvalho,Almeida,Lopes,Soares,Fernandes,Vieira,Barbosa' },
    ao: { M: 'João,António,Manuel,José,Francisco,Domingos,Paulo,Armando,Celso,Edson,Nelson,Augusto,Joaquim,Américo',
      F: 'Maria,Ana,Joana,Teresa,Isabel,Luísa,Fátima,Esperança,Graça,Celeste,Rosa,Felismina,Josefina,Albertina',
      L: 'dos Santos,da Silva,Lourenço,Fernandes,Mendes,Gomes,Cossa,Macuácua,Sitoe,Chissano,Neto,Tavares,Lopes,Ximenes,Soares,Guterres' },
    it: { M: 'Leonardo,Francesco,Alessandro,Lorenzo,Mattia,Andrea,Gabriele,Tommaso,Riccardo,Edoardo,Giuseppe,Marco,Luca,Giovanni,Antonio,Matteo',
      F: 'Sofia,Giulia,Aurora,Alice,Ginevra,Emma,Giorgia,Beatrice,Chiara,Francesca,Martina,Anna,Elena,Sara,Valentina,Rosa',
      L: 'Rossi,Russo,Ferrari,Esposito,Bianchi,Romano,Colombo,Ricci,Marino,Greco,Bruno,Gallo,Conti,De Luca,Costa,Giordano,Mancini,Rizzo,Lombardi,Moretti,Borg,Camilleri' },
    nl: { M: 'Noah,Daan,Sem,Lucas,Levi,Finn,Liam,Milan,Jesse,Thomas,Bram,Pieter,Jan,Dirk,Wouter,Arthur',
      F: 'Emma,Julia,Mila,Tess,Sophie,Zoë,Sara,Nora,Anna,Lotte,Fleur,Eva,Lisa,Femke,Marie,Elise',
      L: 'de Jong,Jansen,de Vries,van den Berg,van Dijk,Bakker,Janssens,Visser,Smit,Meijer,de Boer,Mulder,Peeters,Maes,Willems,Claes,Bos,Vos,Hendriks' },
    nord: { M: 'Lars,Erik,Anders,Magnus,Nils,Oskar,William,Lucas,Liam,Emil,Filip,Johan,Henrik,Mikkel,Jakob,Gunnar',
      F: 'Ingrid,Astrid,Freja,Maja,Ella,Alma,Elsa,Saga,Ida,Emma,Nora,Sofie,Karin,Linnea,Sigrid,Anna',
      L: 'Hansen,Johansen,Olsen,Nielsen,Jensen,Andersson,Johansson,Karlsson,Nilsson,Eriksson,Larsson,Pedersen,Lindqvist,Berg,Bergström,Sigurðsson' },
    fi: { M: 'Juhani,Mikko,Matti,Antti,Janne,Ville,Onni,Eino,Leo,Väinö,Aleksi,Elias,Eetu,Juha',
      F: 'Aino,Helmi,Aada,Sofia,Emilia,Ella,Venla,Liisa,Maria,Anna,Johanna,Laura,Sanna,Eveliina',
      L: 'Korhonen,Virtanen,Mäkinen,Nieminen,Mäkelä,Hämäläinen,Laine,Heikkinen,Koskinen,Järvinen,Lehtonen,Saarinen,Salminen,Lahtinen' },
    lt: { M: 'Lukas,Jonas,Mantas,Tomas,Darius,Matas,Nojus,Kajus,Rokas,Paulius',
      F: 'Rūta,Ieva,Gabija,Austėja,Emilija,Lėja,Kamilė,Urtė,Agnė,Viktorija',
      L: 'Kazlauskas,Petrauskas,Jankauskas,Vaitkus,Stankevičius,Žukauskas,Butkus,Paulauskas,Urbonas,Navickas',
      LF: 'Kazlauskaitė,Petrauskienė,Jankauskaitė,Vaitkutė,Stankevičiūtė,Žukauskienė,Butkutė,Paulauskaitė,Urbonaitė,Navickienė' },
    lv: { M: 'Jānis,Andris,Mārtiņš,Kristaps,Roberts,Gustavs,Edgars,Artūrs,Emīls,Ralfs',
      F: 'Anna,Līga,Kristīne,Elīna,Laura,Sofija,Alise,Marta,Ieva,Evelīna',
      L: 'Bērziņš,Kalniņš,Ozoliņš,Liepiņš,Krūmiņš,Jansons,Vītols,Kļaviņš,Zariņš,Pētersons',
      LF: 'Bērziņa,Kalniņa,Ozoliņa,Liepiņa,Krūmiņa,Jansone,Vītola,Kļaviņa,Zariņa,Pētersone' },
    ee: { M: 'Rasmus,Mihkel,Karl,Markus,Tanel,Martin,Robin,Oliver,Kristjan,Andres',
      F: 'Mari,Kadri,Liis,Triin,Sofia,Eliise,Laura,Maria,Anna,Kertu',
      L: 'Tamm,Saar,Sepp,Mägi,Kask,Rebane,Ilves,Kukk,Lepik,Koppel' },
    he: { M: 'David,Yosef,Moshe,Ariel,Noam,Itai,Yonatan,Daniel,Eitan,Omer,Avraham,Uri,Lavi,Yehuda',
      F: 'Noa,Tamar,Maya,Yael,Shira,Avigail,Sarah,Esther,Michal,Rivka,Talia,Hila,Adi,Ayala',
      L: 'Cohen,Levi,Mizrahi,Peretz,Biton,Friedman,Avraham,Dahan,Katz,Azoulay,Ben-David,Shapiro,Goldberg,Rosenberg' },
    hy: { M: 'Davit,Narek,Aram,Tigran,Arman,Hayk,Gor,Levon,Armen,Vardan,Karen,Samvel',
      F: 'Anahit,Mariam,Ani,Lilit,Nare,Gayane,Hasmik,Siranush,Arpi,Tatev,Lusine,Nane',
      L: 'Hovhannisyan,Harutyunyan,Sargsyan,Khachatryan,Grigoryan,Petrosyan,Hakobyan,Vardanyan,Karapetyan,Gevorgyan,Avetisyan,Mkrtchyan' },
    ka: { M: 'Giorgi,Davit,Luka,Nikoloz,Levan,Irakli,Zurab,Lasha,Sandro,Giga,Tornike,Beka',
      F: 'Nino,Mariam,Ana,Tamar,Elene,Natia,Salome,Ketevan,Eka,Lika,Tekla,Sopho',
      L: 'Beridze,Kapanadze,Gelashvili,Maisuradze,Giorgadze,Lomidze,Tsiklauri,Bolkvadze,Kvaratskhelia,Nozadze,Japaridze,Abashidze' },
    sq: { M: 'Ardit,Arbër,Endri,Klevis,Erion,Besnik,Gjergj,Arben,Altin,Dritan,Noel,Amar',
      F: 'Ana,Ajla,Era,Klea,Sara,Elira,Arta,Jonida,Blerina,Dorina,Ema,Anisa',
      L: 'Hoxha,Shehu,Gashi,Krasniqi,Berisha,Leka,Kola,Dervishi,Prifti,Çela,Marku,Basha' },
    mn: { order: 'sf', M: 'Batbayar,Temuulen,Bilguun,Erdene,Ganbold,Munkh-Erdene,Tsogt,Bat-Orgil,Enkhbat,Tuguldur,Khuslen,Sukhbat',
      F: 'Anujin,Enkhjin,Nomin,Khulan,Oyun,Saraa,Solongo,Tsetseg,Uyanga,Gerel,Altantsetseg,Bolormaa',
      L: 'Bat,Ganbaatar,Dorj,Tseren,Enkhbold,Gantulga,Sukhbaatar,Baatar,Purev,Tumur,Batjargal,Ochir' },
    mg: { M: 'Andry,Hery,Fanomezana,Rivo,Mamy,Faly,Toky,Haja,Njaka,Lova,Fetra,Tsiry',
      F: 'Voahangy,Lalao,Hanta,Fara,Holy,Mialy,Nirina,Soa,Tahina,Rindra,Volana,Onja',
      L: 'Rakotomalala,Randriamampionona,Rasoanaivo,Razafindrakoto,Andrianarivo,Rakotonirina,Ramanantsoa,Randrianasolo,Rabemananjara,Ratsimbazafy' },
    afw: { M: 'Chukwuemeka,Oluwaseun,Ibrahim,Musa,Abdullahi,Emeka,Tunde,Kwame,Kofi,Yaw,Samuel,Daniel,Chinedu,Aliyu,Babatunde,Kwabena,Mohammed,Sani',
      F: 'Ngozi,Chioma,Aisha,Fatima,Funmilayo,Adaeze,Amina,Yetunde,Ama,Akosua,Abena,Blessing,Esther,Hauwa,Zainab,Efua,Halima,Precious',
      L: 'Okafor,Adeyemi,Bello,Ibrahim,Mohammed,Okonkwo,Abubakar,Mensah,Owusu,Boateng,Asante,Danjuma,Eze,Olawale,Nwosu,Yusuf,Kamara,Johnson,Koroma,Sesay,Musa,Adebayo' },
    afr: { M: 'Mamadou,Moussa,Ibrahima,Abdoulaye,Ousmane,Amadou,Jean,Serge,Kouassi,Koffi,Didier,Patrice,Christian,Souleymane,Issa,Boubacar',
      F: 'Fatoumata,Aminata,Mariam,Aïssatou,Awa,Kadiatou,Hawa,Marie,Grâce,Esther,Adjoua,Akissi,Nafissatou,Rokia,Salimata,Chantal',
      L: 'Diallo,Traoré,Coulibaly,Konaté,Keïta,Sow,Ba,Diop,Ndiaye,Kouamé,Kaboré,Ouédraogo,Mbemba,Ilunga,Tshibangu,Mukendi,Kasongo,Mahamat,Issoufou,Camara,Sylla,Fofana,Bamba,Mensah' },
    afe: { M: 'John,Joseph,Peter,Daniel,Brian,Kevin,Juma,Baraka,Emmanuel,Mwangi,Otieno,Kiprotich,Mugisha,Jean-Claude,Hakizimana,Hassani',
      F: 'Mary,Grace,Faith,Mercy,Wanjiru,Akinyi,Neema,Rehema,Amani,Aisha,Esther,Joyce,Uwase,Ishimwe,Achieng,Zawadi',
      L: 'Mwangi,Otieno,Kamau,Odhiambo,Kariuki,Ochieng,Mushi,Mollel,Kimaro,Okello,Ssempala,Mugisha,Niyonzima,Habimana,Uwimana,Nshimiyimana,Mwakyusa,Hassan,Nakato,Wekesa' },
    et: { style: 'patronym', M: 'Abebe,Tesfaye,Dawit,Yonas,Haile,Bereket,Mulugeta,Getachew,Solomon,Kebede,Biniam,Mekonnen,Tewodros,Amanuel,Girma,Alemayehu',
      F: 'Tigist,Meseret,Hiwot,Selam,Bethlehem,Mahlet,Almaz,Tsion,Hanna,Rahel,Saba,Feven,Liya,Eden,Meron,Helen' },
    so: { style: 'patronym', M: 'Mohamed,Abdi,Ahmed,Hassan,Ali,Abdirahman,Omar,Yusuf,Abdullahi,Ismail,Farah,Mahad,Hussein,Aden',
      F: 'Hodan,Fadumo,Asha,Amina,Sahra,Halima,Hibo,Ifrah,Ayan,Nimco,Ubah,Hawa,Ladan,Sagal' },
    ss: { style: 'patronym', M: 'Deng,Garang,Mayen,Akol,Majok,Machar,Kuol,Lual,Malual,Bol,Ajak,Chol,Gatluak,Kiir',
      F: 'Nyandeng,Achol,Ayen,Adut,Nyibol,Abuk,Akuol,Nyakuoth,Ajok,Aluel,Nyamal,Achan,Nyabol,Awut' },
    afs: { M: 'Thabo,Sipho,Themba,Bongani,Mandla,Tendai,Tatenda,Blessing,Kagiso,Lwazi,Mpho,Thulani,Chikondi,Mwila,Tapiwa,Kabelo',
      F: 'Nomsa,Thandiwe,Lerato,Zanele,Nandi,Palesa,Ayanda,Chipo,Rutendo,Naledi,Busisiwe,Tsitsi,Mulenga,Kefilwe,Tumelo,Precious',
      L: 'Dlamini,Nkosi,Ndlovu,Khumalo,Mokoena,Mahlangu,Zulu,Moyo,Ncube,Sibanda,Banda,Phiri,Mwale,Tembo,Molefe,Mutasa,Shikongo,Chirwa,Mbewe,Sithole' },
    pac: { M: 'Sione,Tevita,Viliami,Joseva,Ioane,Tomasi,Peni,Mikaele,Junior,John,Peter,Kaleb,Semi,Iosefa',
      F: 'Mele,Losana,Ana,Salote,Litia,Seini,Grace,Mary,Sela,Vika,Ofa,Leilani,Mere,Talia',
      L: 'Tupou,Fifita,Vea,Naivalu,Waqa,Tuilagi,Faleolo,Leota,Kila,Morea,Iamo,Toua,Kabua,Tebano,Ioane,Tamate' }
  };

  function split(s) { return s ? s.split(',') : null; }
  Object.keys(P).forEach(function (k) {
    var p = P[k];
    p.Ma = split(p.M); p.Fa = split(p.F); p.La = split(p.L); p.LFa = split(p.LF);
  });

  function femSur(rule, s) {
    if (rule === 'slav') {
      if (/(ov|ev|ёv|in|yn)$/.test(s)) return s + 'a';
      if (/skiy$/.test(s)) return s.replace(/skiy$/, 'skaya');
      if (/ski$/.test(s)) return s.replace(/ski$/, 'ska');
      if (/cki$/.test(s)) return s.replace(/cki$/, 'cka');
      if (/dzki$/.test(s)) return s.replace(/dzki$/, 'dzka');
      return s;
    }
    if (rule === 'cz') {
      if (/ý$/.test(s)) return s.replace(/ý$/, 'á');
      if (/a$/.test(s)) return s.replace(/a$/, 'ová');
      if (/ek$/.test(s)) return s.replace(/ek$/, 'ková');
      return s + 'ová';
    }
    if (rule === 'gr') {
      if (/os$/.test(s)) return s.replace(/os$/, 'ou');
      if (/is$/.test(s)) return s.replace(/is$/, 'i');
      if (/as$/.test(s)) return s.replace(/as$/, 'a');
      return s;
    }
    return s;
  }

  function parts(entry) { var a = entry.split(':'); return { lat: a[0], nat: a[1] || '', hv: a[2] || '' }; }

  // Sinh tên cho một bộ tên. surname: giữ họ (vd con theo họ cha). Trả về {full, sub, sur}
  function worldName(r, poolKey, sex, surname) {
    var U = G.U;
    if (poolKey === 'vn') {
      var vn = G.VN.vnName(r, 'kinh', sex, surname);
      return { full: vn.full, sub: '', sur: vn.sur };
    }
    var p = P[poolKey] || P.en;
    var given = U.pick(r, sex === 'F' ? p.Fa : p.Ma);
    var full, sub = '', sur;
    if (p.native) {
      var g = parts(given);
      var s = surname ? parts(surname) : parts(U.pick(r, p.La));
      sur = surname || [s.lat, s.nat, s.hv].filter(Boolean).join(':');
      full = s.lat + ' ' + g.lat;
      var nat = s.nat + (poolKey === 'jp' ? ' ' : '') + g.nat;
      sub = nat + (s.hv && g.hv ? ' · ' + s.hv + ' ' + g.hv : '');
      return { full: full, sub: sub, sur: sur };
    }
    if (p.style === 'patronym') {
      sur = surname || U.pick(r, p.Ma);
      return { full: given + ' ' + sur, sub: '', sur: sur };
    }
    if (p.style === 'bin') {
      sur = surname || U.pick(r, p.La);
      return { full: given + (sex === 'F' ? ' binti ' : ' bin ') + sur, sub: '', sur: sur };
    }
    if (p.style === 'double') {
      sur = surname || U.pick(r, p.La);
      var mother = U.pick(r, p.La);
      if (mother === sur) mother = U.pick(r, p.La);
      return { full: given + ' ' + sur + ' ' + mother, sub: '', sur: sur };
    }
    if (surname) {
      sur = surname;
      var ix = p.La.indexOf(surname);
      if (sex === 'F' && p.LFa && ix >= 0 && p.LFa[ix]) return { full: given + ' ' + p.LFa[ix], sub: '', sur: sur };
    }
    else if (sex === 'F' && p.LFa) sur = U.pick(r, p.LFa);
    else sur = U.pick(r, p.La);
    var shown = sex === 'F' && p.fem ? femSur(p.fem, sur) : sur;
    full = p.order === 'sf' ? shown + ' ' + given : given + ' ' + shown;
    return { full: full, sub: '', sur: sur };
  }

  G.NAMES = { P: P, worldName: worldName, femSur: femSur };
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
/* ===== js/currency.js ===== */
/* Tiền tệ bản địa của 195 quốc gia (tỷ giá xấp xỉ so với 1 USD, 2025).
   Nội bộ game tính theo "USD sức mua tương đương (PPP)"; khi hiển thị quy đổi:
   PPP → USD danh nghĩa (nhân mức giá tương đối theo GDP) → tiền bản địa, kèm quy đổi ra đồng Việt Nam. */
(function (G) {
  'use strict';
  var EUR = 'AT,BE,HR,CY,EE,FI,FR,DE,GR,IE,IT,LV,LT,LU,MT,NL,PT,SK,SI,ES,AD,MC,SM,VA,ME';
  var GROUPS = [
    [EUR, 'EUR', 'euro', 0.92], ['BJ,BF,CI,GW,ML,NE,SN,TG', 'XOF', 'franc CFA', 600], ['CM,CF,TD,CG,GQ,GA', 'XAF', 'franc CFA', 600],
    ['US,EC,SV,PA,TL,MH,FM,PW,ZW', 'USD', 'đô la Mỹ', 1], ['AU,KI,NR,TV', 'AUD', 'đô la Úc', 1.5], ['AG,DM,GD,KN,LC,VC', 'XCD', 'đô la Đông Caribe', 2.7],
    ['CH,LI', 'CHF', 'franc Thụy Sĩ', 0.88], ['IL,PS', 'ILS', 'shekel', 3.7]
  ];
  var ONE = 'AF:AFN:afghani:70,AL:ALL:lek:92,DZ:DZD:dinar:134,AO:AOA:kwanza:900,AR:ARS:peso:1000,AM:AMD:dram:390,AZ:AZN:manat:1.7,BS:BSD:đô la Bahamas:1,' +
    'BH:BHD:dinar:0.376,BD:BDT:taka:120,BB:BBD:đô la Barbados:2,BY:BYN:rúp Belarus:3.2,BZ:BZD:đô la Belize:2,BT:BTN:ngultrum:84,BO:BOB:boliviano:6.9,' +
    'BA:BAM:mark:1.8,BW:BWP:pula:13.5,BR:BRL:real:5.5,BN:BND:đô la Brunei:1.33,BG:BGN:lev:1.8,BI:BIF:franc Burundi:2900,CV:CVE:escudo:101,KH:KHR:riel:4050,' +
    'CA:CAD:đô la Canada:1.38,CL:CLP:peso:940,CN:CNY:nhân dân tệ:7.2,CO:COP:peso:4100,KM:KMF:franc Comoros:450,CD:CDF:franc Congo:2850,CR:CRC:colón:510,' +
    'CU:CUP:peso Cuba:24,CZ:CZK:koruna:23,DK:DKK:krone:6.9,DJ:DJF:franc Djibouti:178,DO:DOP:peso:60,EG:EGP:bảng Ai Cập:49,ER:ERN:nakfa:15,SZ:SZL:lilangeni:18,' +
    'ET:ETB:birr:120,FJ:FJD:đô la Fiji:2.25,GM:GMD:dalasi:70,GE:GEL:lari:2.7,GH:GHS:cedi:15,GT:GTQ:quetzal:7.7,GN:GNF:franc Guinea:8600,GY:GYD:đô la Guyana:209,' +
    'HT:HTG:gourde:131,HN:HNL:lempira:25,HU:HUF:forint:365,IS:ISK:króna:138,IN:INR:rupee:84,ID:IDR:rupiah:16000,IR:IRR:rial:600000,IQ:IQD:dinar:1310,' +
    'JM:JMD:đô la Jamaica:157,JP:JPY:yên:150,JO:JOD:dinar:0.71,KZ:KZT:tenge:500,KE:KES:shilling:129,KP:KPW:won Triều Tiên:900,KR:KRW:won:1380,KW:KWD:dinar:0.31,' +
    'KG:KGS:som:87,LA:LAK:kíp:21800,LB:LBP:bảng Liban:89500,LS:LSL:loti:18,LR:LRD:đô la Liberia:190,LY:LYD:dinar:4.8,MG:MGA:ariary:4600,MW:MWK:kwacha:1735,' +
    'MY:MYR:ringgit:4.4,MV:MVR:rufiyaa:15.4,MR:MRU:ouguiya:40,MU:MUR:rupee Mauritius:46,MX:MXN:peso:18.5,MD:MDL:leu:17.8,MN:MNT:tugrik:3400,MA:MAD:dirham:9.9,' +
    'MZ:MZN:metical:64,MM:MMK:kyat:2100,NA:NAD:đô la Namibia:18,NP:NPR:rupee Nepal:135,NZ:NZD:đô la New Zealand:1.65,NI:NIO:córdoba:36.8,NG:NGN:naira:1550,' +
    'MK:MKD:denar:57,NO:NOK:krone:10.8,OM:OMR:rial:0.385,PK:PKR:rupee Pakistan:280,PG:PGK:kina:3.9,PY:PYG:guaraní:7800,PE:PEN:sol:3.75,PH:PHP:peso:57,' +
    'PL:PLN:złoty:4,QA:QAR:riyal:3.64,RO:RON:leu:4.6,RU:RUB:rúp:90,RW:RWF:franc Rwanda:1350,WS:WST:tala:2.7,ST:STN:dobra:22.5,SA:SAR:riyal:3.75,RS:RSD:dinar:108,' +
    'SC:SCR:rupee Seychelles:13.8,SL:SLE:leone:22.5,SG:SGD:đô la Singapore:1.33,SB:SBD:đô la Solomon:8.4,SO:SOS:shilling:570,ZA:ZAR:rand:18,SS:SSP:bảng Nam Sudan:1300,' +
    'LK:LKR:rupee Sri Lanka:300,SD:SDG:bảng Sudan:600,SR:SRD:đô la Suriname:35,SE:SEK:krona:10.5,SY:SYP:bảng Syria:13000,TJ:TJS:somoni:10.9,TZ:TZS:shilling:2650,' +
    'TH:THB:baht:35,TO:TOP:paʻanga:2.35,TT:TTD:đô la Trinidad:6.8,TN:TND:dinar:3.1,TR:TRY:lira:34,TM:TMT:manat:3.5,UG:UGX:shilling:3700,UA:UAH:hryvnia:41,' +
    'AE:AED:dirham:3.67,GB:GBP:bảng Anh:0.78,UY:UYU:peso:40,UZ:UZS:som:12800,VU:VUV:vatu:120,VE:VES:bolívar:40,VN:VND:đồng:25400,YE:YER:rial:530,ZM:ZMW:kwacha:27';
  var CUR = {};
  GROUPS.forEach(function (g) { g[0].split(',').forEach(function (c) { CUR[c] = { code: g[1], name: g[2], rate: g[3] }; }); });
  ONE.split(',').forEach(function (s) { var p = s.split(':'); CUR[p[0]] = { code: p[1], name: p[2], rate: +p[3] }; });
  var VND = 25400;

  // mức giá so với Mỹ (PPP → danh nghĩa), xấp xỉ theo GDP bình quân PPP (nghìn USD)
  function priceLevel(gdpk) { return Math.min(1.15, Math.max(0.28, 0.22 + 0.0095 * gdpk)); }

  function units(v, d) {
    var U = G.U, a = Math.abs(v);
    if (a >= 1e9) return U.fmtNum(v / 1e9, a >= 1e11 ? 0 : 1) + ' tỷ';
    if (a >= 1e6) return U.fmtNum(v / 1e6, a >= 1e8 ? 0 : 1) + ' triệu';
    return U.fmtNum(v, d || 0);
  }
  function fmtVND(trieu) { // số đo bằng triệu đồng
    var U = G.U, neg = trieu < 0, v = Math.abs(trieu), s;
    if (!isFinite(v)) return '—';
    v = Math.round(v * 1e6) / 1e6;
    if (v >= 999.95) s = U.fmtNum(v / 1000, 2) + ' tỷ đ';
    else if (v >= .99995) s = U.fmtNum(v, 2) + ' triệu đ';
    else if (v >= .001) s = U.fmtNum(v * 1000, 1) + 'k đ';
    else s = U.fmtNum(v * 1e6, 0) + ' đ';
    return (neg && v ? '−' : '') + s;
  }
  // v: USD PPP → chuỗi tiền bản địa (+ ≈ VND nếu muốn)
  function fmtLocal(code, gdpk, v, withVnd) {
    var c = CUR[code] || CUR.US;
    var nominal = v * priceLevel(gdpk), local = nominal * c.rate, neg = v < 0;
    var s = (neg ? '−' : '') + units(Math.abs(local)) + ' ' + c.code;
    if (withVnd && c.code !== 'VND') s += ' (≈ ' + fmtVND(nominal * VND / 1e6) + ')';
    return s;
  }
  function toVND(gdpk, v) { return v * priceLevel(gdpk) * VND / 1e6; } // triệu đồng

  G.CUR = { CUR: CUR, priceLevel: priceLevel, fmtLocal: fmtLocal, fmtVND: fmtVND, toVND: toVND, VND: VND };
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
/* ===== js/world-economy.js ===== */
/* Country earnings: ILOSTAT EAR_EMTA_SEX_CUR_NB; GDP/prices: World Bank WDI. See world-economy-sources.md. */
(function(G){
'use strict';
var DATA={"retrieved":"2026-10-17","vnMonthlyMillion":9.0180922,"fallbackMedianWageToGDP":{"0":1.8182944675100932,"1":1.020090693006106,"2":0.6995344082718176,"3":0.9357141282191255},"countries":{"AF":{"usd":171.874,"wageYear":2020,"source":"ilo","gdpNominal":416.87,"gdpPPP":2236.2,"gdpYear":2024,"consumptionPLI":0.18642,"priceYear":2024,"priceSource":"gdp-proxy","iloSource":"BA:15715","status":"B"},"AL":{"usd":547.568,"wageYear":2022,"source":"ilo","gdpNominal":12998.15,"gdpPPP":28220.8,"gdpYear":2025,"consumptionPLI":0.54281,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"FA:13364","status":""},"DZ":{"usd":514.381,"wageYear":2025,"source":"estimate","gdpNominal":6051.0,"gdpPPP":18586.26,"gdpYear":2025,"consumptionPLI":0.31713,"priceYear":2025,"priceSource":"wb-consumption"},"AD":{"usd":4233.444,"wageYear":2025,"source":"estimate","gdpNominal":54291.5,"gdpPPP":79566.79,"gdpYear":2025,"consumptionPLI":0.68234,"priceYear":2025,"priceSource":"gdp-proxy"},"AO":{"usd":128.606,"wageYear":2024,"source":"ilo","gdpNominal":3129.48,"gdpPPP":10251.35,"gdpYear":2025,"consumptionPLI":0.39924,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:13951","status":""},"AG":{"usd":1051.929,"wageYear":2023,"source":"ilo","gdpNominal":24819.25,"gdpPPP":35832.48,"gdpYear":2025,"consumptionPLI":0.81166,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:16714","status":""},"AR":{"usd":811.442,"wageYear":2025,"source":"ilo","gdpNominal":14898.09,"gdpPPP":32586.63,"gdpYear":2025,"consumptionPLI":0.45718,"priceYear":2025,"priceSource":"gdp-proxy","iloSource":"BA:150","status":""},"AM":{"usd":405.291,"wageYear":2023,"source":"ilo","gdpNominal":9474.02,"gdpPPP":24754.21,"gdpYear":2025,"consumptionPLI":0.40963,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:173","status":""},"AU":{"usd":4436.17,"wageYear":2021,"source":"ilo","gdpNominal":65129.72,"gdpPPP":71934.4,"gdpYear":2025,"consumptionPLI":0.94368,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:15747","status":""},"AT":{"usd":6155.034,"wageYear":2025,"source":"ilo","gdpNominal":62930.04,"gdpPPP":76777.54,"gdpYear":2025,"consumptionPLI":0.84789,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:275","status":""},"AZ":{"usd":493.765,"wageYear":2022,"source":"ilo","gdpNominal":7410.72,"gdpPPP":26112.53,"gdpYear":2025,"consumptionPLI":0.31938,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"DA:126","status":"U"},"BS":{"usd":2943.724,"wageYear":2024,"source":"ilo","gdpNominal":39455.45,"gdpPPP":41257.77,"gdpYear":2024,"consumptionPLI":1.08963,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:17","status":""},"BH":{"usd":938.83,"wageYear":2020,"source":"ilo","gdpNominal":30596.58,"gdpPPP":70996.78,"gdpYear":2025,"consumptionPLI":0.48793,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"FA:598","status":""},"BD":{"usd":134.222,"wageYear":2024,"source":"ilo","gdpNominal":2597.34,"gdpPPP":10153.71,"gdpYear":2025,"consumptionPLI":0.28658,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:673","status":""},"BB":{"usd":2211.78,"wageYear":2025,"source":"estimate","gdpNominal":28364.82,"gdpPPP":25893.87,"gdpYear":2025,"consumptionPLI":1.09543,"priceYear":2025,"priceSource":"gdp-proxy"},"BY":{"usd":599.224,"wageYear":2025,"source":"estimate","gdpNominal":10279.25,"gdpPPP":34715.98,"gdpYear":2025,"consumptionPLI":0.27649,"priceYear":2025,"priceSource":"wb-consumption"},"BE":{"usd":7044.061,"wageYear":2025,"source":"ilo","gdpNominal":60750.27,"gdpPPP":74675.61,"gdpYear":2025,"consumptionPLI":0.87207,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:276","status":""},"BZ":{"usd":510.0,"wageYear":2020,"source":"ilo","gdpNominal":7865.48,"gdpPPP":14965.75,"gdpYear":2025,"consumptionPLI":0.54381,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:934","status":""},"BJ":{"usd":135.693,"wageYear":2022,"source":"ilo","gdpNominal":1658.27,"gdpPPP":4816.88,"gdpYear":2025,"consumptionPLI":0.33712,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:426","status":""},"BT":{"usd":322.088,"wageYear":2025,"source":"ilo","gdpNominal":4492.78,"gdpPPP":19594.0,"gdpYear":2025,"consumptionPLI":0.24154,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:625","status":""},"BO":{"usd":461.596,"wageYear":2025,"source":"ilo","gdpNominal":5147.81,"gdpPPP":12873.04,"gdpYear":2025,"consumptionPLI":0.39063,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:74","status":""},"BA":{"usd":998.729,"wageYear":2025,"source":"ilo","gdpNominal":10381.85,"gdpPPP":25814.26,"gdpYear":2025,"consumptionPLI":0.44301,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:493","status":""},"BW":{"usd":482.603,"wageYear":2024,"source":"ilo","gdpNominal":7778.12,"gdpPPP":20697.91,"gdpYear":2025,"consumptionPLI":0.39332,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BX:15710","status":""},"BR":{"usd":607.299,"wageYear":2025,"source":"ilo","gdpNominal":10713.29,"gdpPPP":23433.29,"gdpYear":2025,"consumptionPLI":0.46203,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BX:6355","status":""},"BN":{"usd":2513.534,"wageYear":2025,"source":"estimate","gdpNominal":32234.64,"gdpPPP":92429.93,"gdpYear":2025,"consumptionPLI":0.40306,"priceYear":2025,"priceSource":"wb-consumption"},"BG":{"usd":1573.153,"wageYear":2025,"source":"ilo","gdpNominal":20328.17,"gdpPPP":44451.1,"gdpYear":2025,"consumptionPLI":0.23895,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:3058","status":""},"BF":{"usd":212.17,"wageYear":2025,"source":"ilo","gdpNominal":1147.57,"gdpPPP":3071.63,"gdpYear":2025,"consumptionPLI":0.33184,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:904","status":""},"BI":{"usd":50.57,"wageYear":2020,"source":"ilo","gdpNominal":233.82,"gdpPPP":1248.05,"gdpYear":2025,"consumptionPLI":0.45687,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:7040","status":""},"CV":{"usd":492.744,"wageYear":2025,"source":"estimate","gdpNominal":5796.47,"gdpPPP":12165.3,"gdpYear":2025,"consumptionPLI":0.54136,"priceYear":2025,"priceSource":"wb-consumption"},"KH":{"usd":289.188,"wageYear":2025,"source":"ilo","gdpNominal":2872.43,"gdpPPP":8542.7,"gdpYear":2025,"consumptionPLI":0.36697,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:1321","status":""},"CM":{"usd":298.864,"wageYear":2025,"source":"estimate","gdpNominal":1972.38,"gdpPPP":5787.85,"gdpYear":2025,"consumptionPLI":0.35917,"priceYear":2025,"priceSource":"wb-consumption"},"CA":{"usd":4121.253,"wageYear":2025,"source":"ilo","gdpNominal":55697.66,"gdpPPP":66745.82,"gdpYear":2025,"consumptionPLI":0.90156,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:147","status":""},"CF":{"usd":84.268,"wageYear":2025,"source":"estimate","gdpNominal":556.13,"gdpPPP":1313.88,"gdpYear":2025,"consumptionPLI":0.4451,"priceYear":2025,"priceSource":"wb-consumption"},"TD":{"usd":205.952,"wageYear":2022,"source":"ilo","gdpNominal":1022.34,"gdpPPP":2902.74,"gdpYear":2025,"consumptionPLI":0.3828,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:15712","status":""},"CL":{"usd":1024.169,"wageYear":2024,"source":"ilo","gdpNominal":17994.59,"gdpPPP":37774.09,"gdpYear":2025,"consumptionPLI":0.51179,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:16207","status":""},"CN":{"usd":806.868,"wageYear":2022,"source":"ilo","gdpNominal":13861.97,"gdpPPP":29333.33,"gdpYear":2025,"consumptionPLI":0.48117,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"FX:216","status":""},"CO":{"usd":499.035,"wageYear":2025,"source":"ilo","gdpNominal":8561.62,"gdpPPP":22640.42,"gdpYear":2025,"consumptionPLI":0.41094,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:358","status":""},"KM":{"usd":253.285,"wageYear":2021,"source":"ilo","gdpNominal":2055.76,"gdpPPP":4238.26,"gdpYear":2025,"consumptionPLI":0.58279,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:14125","status":""},"CG":{"usd":213.771,"wageYear":2025,"source":"estimate","gdpNominal":2514.73,"gdpPPP":7248.44,"gdpYear":2025,"consumptionPLI":0.39741,"priceYear":2025,"priceSource":"wb-consumption"},"CD":{"usd":122.246,"wageYear":2025,"source":"estimate","gdpNominal":806.78,"gdpPPP":1919.82,"gdpYear":2025,"consumptionPLI":0.42023,"priceYear":2025,"priceSource":"gdp-proxy"},"CR":{"usd":1204.592,"wageYear":2025,"source":"ilo","gdpNominal":19970.1,"gdpPPP":33814.77,"gdpYear":2025,"consumptionPLI":0.62471,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:12883","status":""},"CI":{"usd":206.734,"wageYear":2022,"source":"ilo","gdpNominal":3050.1,"gdpPPP":8208.91,"gdpYear":2025,"consumptionPLI":0.39224,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:16197","status":""},"HR":{"usd":2493.623,"wageYear":2025,"source":"ilo","gdpNominal":27103.91,"gdpPPP":50946.17,"gdpYear":2025,"consumptionPLI":0.58847,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:5862","status":""},"CU":{"usd":267.774,"wageYear":null,"source":"estimate","gdpNominal":3150.0,"gdpPPP":10000,"gdpYear":null,"consumptionPLI":0.315,"priceYear":null,"priceSource":"gdp-proxy"},"CY":{"usd":3286.966,"wageYear":2025,"source":"ilo","gdpNominal":41783.09,"gdpPPP":64574.62,"gdpYear":2025,"consumptionPLI":0.66923,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:459","status":""},"CZ":{"usd":2716.419,"wageYear":2025,"source":"ilo","gdpNominal":35917.27,"gdpPPP":60487.29,"gdpYear":2025,"consumptionPLI":0.66985,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:301","status":""},"DK":{"usd":6992.079,"wageYear":2025,"source":"ilo","gdpNominal":76970.15,"gdpPPP":83218.07,"gdpYear":2025,"consumptionPLI":1.04528,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:3070","status":""},"DJ":{"usd":332.006,"wageYear":2025,"source":"estimate","gdpNominal":3905.6,"gdpPPP":8451.97,"gdpYear":2025,"consumptionPLI":0.49824,"priceYear":2025,"priceSource":"wb-consumption"},"DM":{"usd":640.601,"wageYear":2025,"source":"estimate","gdpNominal":10989.04,"gdpPPP":22713.13,"gdpYear":2025,"consumptionPLI":0.57702,"priceYear":2025,"priceSource":"wb-consumption"},"DO":{"usd":485.14,"wageYear":2025,"source":"ilo","gdpNominal":11059.21,"gdpPPP":28721.1,"gdpYear":2025,"consumptionPLI":0.38409,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:13413","status":""},"EC":{"usd":538.453,"wageYear":2025,"source":"ilo","gdpNominal":7125.28,"gdpPPP":16756.65,"gdpYear":2025,"consumptionPLI":0.44151,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:19","status":""},"EG":{"usd":109.352,"wageYear":2024,"source":"ilo","gdpNominal":3085.81,"gdpPPP":20204.01,"gdpYear":2025,"consumptionPLI":0.15686,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:582","status":"B"},"SV":{"usd":507.036,"wageYear":2025,"source":"ilo","gdpNominal":5766.73,"gdpPPP":14101.18,"gdpYear":2025,"consumptionPLI":0.46885,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BX:461","status":""},"GQ":{"usd":388.309,"wageYear":2023,"source":"ilo","gdpNominal":6615.25,"gdpPPP":16133.11,"gdpYear":2025,"consumptionPLI":0.45466,"priceYear":2024,"priceSource":"wb-consumption","iloSource":"BB:16937","status":""},"ER":{"usd":76.368,"wageYear":null,"source":"estimate","gdpNominal":504.0,"gdpPPP":1800.0,"gdpYear":null,"consumptionPLI":0.28,"priceYear":null,"priceSource":"gdp-proxy"},"EE":{"usd":3217.551,"wageYear":2025,"source":"ilo","gdpNominal":34417.63,"gdpPPP":52105.51,"gdpYear":2025,"consumptionPLI":0.75906,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:44","status":""},"SZ":{"usd":638.176,"wageYear":2025,"source":"ilo","gdpNominal":4108.25,"gdpPPP":12529.28,"gdpYear":2025,"consumptionPLI":0.32789,"priceYear":2025,"priceSource":"gdp-proxy","iloSource":"BA:1672","status":""},"ET":{"usd":95.943,"wageYear":2021,"source":"ilo","gdpNominal":932.73,"gdpPPP":3621.67,"gdpYear":2025,"consumptionPLI":0.29653,"priceYear":2024,"priceSource":"wb-consumption","iloSource":"BA:1126","status":""},"FJ":{"usd":613.724,"wageYear":2024,"source":"ilo","gdpNominal":6642.0,"gdpPPP":16337.57,"gdpYear":2025,"consumptionPLI":0.38688,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:1135","status":""},"FI":{"usd":5760.046,"wageYear":2025,"source":"ilo","gdpNominal":56148.58,"gdpPPP":65884.49,"gdpYear":2025,"consumptionPLI":0.90626,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:6210","status":""},"FR":{"usd":5023.551,"wageYear":2025,"source":"ilo","gdpNominal":48985.73,"gdpPPP":63975.35,"gdpYear":2025,"consumptionPLI":0.82771,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:3067","status":""},"GA":{"usd":481.69,"wageYear":2025,"source":"estimate","gdpNominal":8263.03,"gdpPPP":22218.34,"gdpYear":2025,"consumptionPLI":0.48262,"priceYear":2025,"priceSource":"wb-consumption"},"GM":{"usd":139.26,"wageYear":2025,"source":"estimate","gdpNominal":919.06,"gdpPPP":3705.64,"gdpYear":2025,"consumptionPLI":0.28656,"priceYear":2024,"priceSource":"wb-consumption"},"GE":{"usd":329.902,"wageYear":2023,"source":"ilo","gdpNominal":9691.53,"gdpPPP":29414.38,"gdpYear":2025,"consumptionPLI":0.39651,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:16121","status":""},"DE":{"usd":4646.541,"wageYear":2022,"source":"ilo","gdpNominal":60496.44,"gdpPPP":75406.69,"gdpYear":2025,"consumptionPLI":0.81233,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:5863","status":""},"GH":{"usd":217.291,"wageYear":2025,"source":"ilo","gdpNominal":3257.16,"gdpPPP":8610.28,"gdpYear":2025,"consumptionPLI":0.4181,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:1163","status":""},"GR":{"usd":2185.048,"wageYear":2025,"source":"ilo","gdpNominal":26948.01,"gdpPPP":45263.65,"gdpYear":2025,"consumptionPLI":0.65545,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:319","status":""},"GD":{"usd":705.765,"wageYear":2025,"source":"estimate","gdpNominal":12106.88,"gdpPPP":21345.97,"gdpYear":2025,"consumptionPLI":0.61777,"priceYear":2025,"priceSource":"wb-consumption"},"GT":{"usd":500.73,"wageYear":2025,"source":"ilo","gdpNominal":6598.18,"gdpPPP":15197.08,"gdpYear":2025,"consumptionPLI":0.44689,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:660","status":""},"GN":{"usd":284.45,"wageYear":2025,"source":"estimate","gdpNominal":1877.25,"gdpPPP":4934.65,"gdpYear":2025,"consumptionPLI":0.38042,"priceYear":2025,"priceSource":"gdp-proxy"},"GW":{"usd":140.984,"wageYear":2022,"source":"ilo","gdpNominal":1123.77,"gdpPPP":3293.1,"gdpYear":2025,"consumptionPLI":0.38639,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:15952","status":""},"GY":{"usd":654.976,"wageYear":2024,"source":"ilo","gdpNominal":32413.79,"gdpPPP":97899.01,"gdpYear":2025,"consumptionPLI":0.46909,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:1214","status":""},"HT":{"usd":229.026,"wageYear":2025,"source":"estimate","gdpNominal":2694.19,"gdpPPP":3133.72,"gdpYear":2025,"consumptionPLI":1.02225,"priceYear":2025,"priceSource":"wb-consumption"},"VA":{"usd":3993.811,"wageYear":2025,"source":"proxy:IT","gdpNominal":34750.0,"gdpPPP":50000,"gdpYear":null,"consumptionPLI":0.695,"priceYear":null,"priceSource":"gdp-proxy"},"HN":{"usd":433.407,"wageYear":2025,"source":"ilo","gdpNominal":3598.21,"gdpPPP":7871.09,"gdpYear":2025,"consumptionPLI":0.48615,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BX:504","status":""},"HU":{"usd":1290.315,"wageYear":2025,"source":"ilo","gdpNominal":25907.47,"gdpPPP":49837.6,"gdpYear":2025,"consumptionPLI":0.57921,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:3062","status":""},"IS":{"usd":6348.606,"wageYear":2020,"source":"ilo","gdpNominal":98323.48,"gdpPPP":83431.21,"gdpYear":2025,"consumptionPLI":1.29708,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:3061","status":""},"IN":{"usd":254.938,"wageYear":2025,"source":"ilo","gdpNominal":2702.48,"gdpPPP":11747.92,"gdpYear":2025,"consumptionPLI":0.22762,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:14121","status":""},"ID":{"usd":182.329,"wageYear":2023,"source":"ilo","gdpNominal":5059.63,"gdpPPP":17659.79,"gdpYear":2025,"consumptionPLI":0.30744,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:510","status":""},"IR":{"usd":333.602,"wageYear":2025,"source":"estimate","gdpNominal":3924.38,"gdpPPP":19699.22,"gdpYear":2025,"consumptionPLI":0.19922,"priceYear":2025,"priceSource":"gdp-proxy"},"IQ":{"usd":459.864,"wageYear":2025,"source":"estimate","gdpNominal":5409.68,"gdpPPP":14266.8,"gdpYear":2025,"consumptionPLI":0.41999,"priceYear":2025,"priceSource":"wb-consumption"},"IE":{"usd":5696.627,"wageYear":2025,"source":"ilo","gdpNominal":131592.46,"gdpPPP":155089.41,"gdpYear":2025,"consumptionPLI":1.02146,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:3073","status":""},"IL":{"usd":3383.074,"wageYear":2021,"source":"ilo","gdpNominal":60336.85,"gdpPPP":59716.97,"gdpYear":2025,"consumptionPLI":1.05906,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:711","status":""},"IT":{"usd":3993.811,"wageYear":2025,"source":"ilo","gdpNominal":43308.64,"gdpPPP":62802.51,"gdpYear":2025,"consumptionPLI":0.72864,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:3069","status":""},"JM":{"usd":466.527,"wageYear":2025,"source":"estimate","gdpNominal":8002.92,"gdpPPP":13291.25,"gdpYear":2025,"consumptionPLI":0.6175,"priceYear":2025,"priceSource":"wb-consumption"},"JP":{"usd":2800.801,"wageYear":2021,"source":"ilo","gdpNominal":35951.04,"gdpPPP":55421.88,"gdpYear":2025,"consumptionPLI":0.69049,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"DA:260","status":""},"JO":{"usd":494.823,"wageYear":2024,"source":"ilo","gdpNominal":5347.78,"gdpPPP":12631.63,"gdpYear":2025,"consumptionPLI":0.44829,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:682","status":""},"KZ":{"usd":673.382,"wageYear":2022,"source":"ilo","gdpNominal":14692.13,"gdpPPP":44293.48,"gdpYear":2025,"consumptionPLI":0.36634,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"FK:613","status":""},"KE":{"usd":200.861,"wageYear":2025,"source":"estimate","gdpNominal":2362.86,"gdpPPP":7015.94,"gdpYear":2025,"consumptionPLI":0.3479,"priceYear":2025,"priceSource":"wb-consumption"},"KI":{"usd":357.734,"wageYear":2023,"source":"ilo","gdpNominal":2558.67,"gdpPPP":3936.61,"gdpYear":2025,"consumptionPLI":0.62444,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:15723","status":""},"KP":{"usd":76.368,"wageYear":null,"source":"estimate","gdpNominal":504.0,"gdpPPP":1800.0,"gdpYear":null,"consumptionPLI":0.28,"priceYear":null,"priceSource":"gdp-proxy"},"KR":{"usd":3167.765,"wageYear":2022,"source":"ilo","gdpNominal":36226.97,"gdpPPP":63124.92,"gdpYear":2025,"consumptionPLI":0.61874,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"DA:224","status":""},"KW":{"usd":2519.591,"wageYear":2025,"source":"estimate","gdpNominal":32312.31,"gdpPPP":56467.73,"gdpYear":2025,"consumptionPLI":0.59776,"priceYear":2025,"priceSource":"wb-consumption"},"KG":{"usd":329.116,"wageYear":2022,"source":"ilo","gdpNominal":3080.97,"gdpPPP":9219.51,"gdpYear":2025,"consumptionPLI":0.33564,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"DA:1316","status":""},"LA":{"usd":178.408,"wageYear":2022,"source":"ilo","gdpNominal":2324.76,"gdpPPP":10383.0,"gdpYear":2025,"consumptionPLI":0.28713,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:6651","status":"B"},"LV":{"usd":2624.367,"wageYear":2025,"source":"ilo","gdpNominal":26311.97,"gdpPPP":46136.69,"gdpYear":2025,"consumptionPLI":0.62389,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:3074","status":""},"LB":{"usd":380.262,"wageYear":2024,"source":"estimate","gdpNominal":4473.27,"gdpPPP":11917.45,"gdpYear":2024,"consumptionPLI":0.6533,"priceYear":2025,"priceSource":"wb-consumption"},"LS":{"usd":136.084,"wageYear":2024,"source":"ilo","gdpNominal":1088.96,"gdpPPP":3184.12,"gdpYear":2025,"consumptionPLI":0.34843,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:13","status":""},"LR":{"usd":138.695,"wageYear":2025,"source":"estimate","gdpNominal":915.33,"gdpPPP":1981.09,"gdpYear":2025,"consumptionPLI":0.46203,"priceYear":2025,"priceSource":"gdp-proxy"},"LY":{"usd":548.199,"wageYear":2025,"source":"estimate","gdpNominal":6448.82,"gdpPPP":16521.4,"gdpYear":2025,"consumptionPLI":0.33804,"priceYear":2025,"priceSource":"wb-consumption"},"LI":{"usd":7779.875,"wageYear":2025,"source":"proxy:CH","gdpNominal":149500.0,"gdpPPP":130000,"gdpYear":null,"consumptionPLI":1.15,"priceYear":null,"priceSource":"gdp-proxy"},"LT":{"usd":2634.057,"wageYear":2025,"source":"ilo","gdpNominal":32958.67,"gdpPPP":56837.81,"gdpYear":2025,"consumptionPLI":0.62106,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:3065","status":""},"LU":{"usd":9149.658,"wageYear":2025,"source":"ilo","gdpNominal":147252.18,"gdpPPP":156542.08,"gdpYear":2025,"consumptionPLI":0.98648,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:6341","status":""},"MG":{"usd":90.803,"wageYear":2025,"source":"estimate","gdpNominal":599.27,"gdpPPP":1952.48,"gdpYear":2025,"consumptionPLI":0.29039,"priceYear":2025,"priceSource":"wb-consumption"},"MW":{"usd":101.75,"wageYear":2025,"source":"estimate","gdpNominal":671.51,"gdpPPP":1899.29,"gdpYear":2025,"consumptionPLI":0.33657,"priceYear":2023,"priceSource":"wb-consumption"},"MY":{"usd":697.755,"wageYear":2020,"source":"ilo","gdpNominal":13124.56,"gdpPPP":41497.67,"gdpYear":2025,"consumptionPLI":0.33392,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"DA:7341","status":""},"MV":{"usd":851.958,"wageYear":2025,"source":"estimate","gdpNominal":14614.72,"gdpPPP":28554.89,"gdpYear":2025,"consumptionPLI":0.62107,"priceYear":2025,"priceSource":"wb-consumption"},"ML":{"usd":175.989,"wageYear":2024,"source":"ilo","gdpNominal":1193.28,"gdpPPP":3502.76,"gdpYear":2025,"consumptionPLI":0.33243,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:219","status":""},"MT":{"usd":3946.989,"wageYear":2021,"source":"ilo","gdpNominal":47906.9,"gdpPPP":72210.34,"gdpYear":2025,"consumptionPLI":0.6897,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:342","status":"U"},"MH":{"usd":494.866,"wageYear":2025,"source":"estimate","gdpNominal":8489.06,"gdpPPP":8964.32,"gdpYear":2025,"consumptionPLI":0.94698,"priceYear":2025,"priceSource":"gdp-proxy"},"MR":{"usd":186.805,"wageYear":2025,"source":"estimate","gdpNominal":2197.51,"gdpPPP":7675.52,"gdpYear":2025,"consumptionPLI":0.33943,"priceYear":2023,"priceSource":"wb-consumption"},"MU":{"usd":699.006,"wageYear":2024,"source":"ilo","gdpNominal":12991.29,"gdpPPP":33666.64,"gdpYear":2025,"consumptionPLI":0.4371,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:82","status":""},"MX":{"usd":551.47,"wageYear":2025,"source":"ilo","gdpNominal":13889.23,"gdpPPP":25868.48,"gdpYear":2025,"consumptionPLI":0.58785,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:463","status":""},"FM":{"usd":375.224,"wageYear":2025,"source":"estimate","gdpNominal":4414.01,"gdpPPP":4604.4,"gdpYear":2025,"consumptionPLI":0.92668,"priceYear":2022,"priceSource":"wb-consumption"},"MD":{"usd":501.152,"wageYear":2025,"source":"ilo","gdpNominal":8621.72,"gdpPPP":19995.76,"gdpYear":2025,"consumptionPLI":0.50484,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:571","status":""},"MC":{"usd":5023.551,"wageYear":2025,"source":"proxy:FR","gdpNominal":218500.0,"gdpPPP":190000,"gdpYear":null,"consumptionPLI":1.15,"priceYear":null,"priceSource":"gdp-proxy"},"MN":{"usd":560.677,"wageYear":2025,"source":"ilo","gdpNominal":7108.23,"gdpPPP":20797.77,"gdpYear":2025,"consumptionPLI":0.33305,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:702","status":""},"ME":{"usd":929.799,"wageYear":2022,"source":"ilo","gdpNominal":14816.84,"gdpPPP":35422.64,"gdpYear":2025,"consumptionPLI":0.49479,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"DA:470","status":""},"MA":{"usd":397.195,"wageYear":2025,"source":"estimate","gdpNominal":4672.47,"gdpPPP":11111.71,"gdpYear":2025,"consumptionPLI":0.42348,"priceYear":2025,"priceSource":"wb-consumption"},"MZ":{"usd":212.548,"wageYear":2022,"source":"ilo","gdpNominal":626.91,"gdpPPP":1697.94,"gdpYear":2025,"consumptionPLI":0.39263,"priceYear":2024,"priceSource":"wb-consumption","iloSource":"BB:8363","status":""},"MM":{"usd":135.98,"wageYear":2020,"source":"ilo","gdpNominal":1488.88,"gdpPPP":6011.53,"gdpYear":2025,"consumptionPLI":0.24767,"priceYear":2025,"priceSource":"gdp-proxy","iloSource":"BA:7009","status":""},"NA":{"usd":414.491,"wageYear":2025,"source":"estimate","gdpNominal":4875.93,"gdpPPP":11985.72,"gdpYear":2025,"consumptionPLI":0.4125,"priceYear":2025,"priceSource":"wb-consumption"},"NR":{"usd":853.403,"wageYear":2025,"source":"estimate","gdpNominal":14639.5,"gdpPPP":14200.49,"gdpYear":2025,"consumptionPLI":1.03092,"priceYear":2025,"priceSource":"gdp-proxy"},"NP":{"usd":232.723,"wageYear":2025,"source":"estimate","gdpNominal":1535.88,"gdpPPP":6175.16,"gdpYear":2025,"consumptionPLI":0.25353,"priceYear":2025,"priceSource":"wb-consumption"},"NL":{"usd":6402.139,"wageYear":2025,"source":"ilo","gdpNominal":73683.92,"gdpPPP":87320.15,"gdpYear":2025,"consumptionPLI":0.86709,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:3060","status":""},"NZ":{"usd":3797.91,"wageYear":2022,"source":"ilo","gdpNominal":49591.04,"gdpPPP":57350.36,"gdpYear":2025,"consumptionPLI":0.88895,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"FX:118","status":""},"NI":{"usd":269.758,"wageYear":2025,"source":"estimate","gdpNominal":3173.34,"gdpPPP":9283.92,"gdpYear":2025,"consumptionPLI":0.36953,"priceYear":2025,"priceSource":"wb-consumption"},"NE":{"usd":120.365,"wageYear":2022,"source":"ilo","gdpNominal":775.35,"gdpPPP":2177.25,"gdpYear":2025,"consumptionPLI":0.34296,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:13367","status":""},"NG":{"usd":51.718,"wageYear":2024,"source":"ilo","gdpNominal":1224.25,"gdpPPP":9531.61,"gdpYear":2025,"consumptionPLI":0.20947,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BX:7338","status":""},"MK":{"usd":611.505,"wageYear":2025,"source":"estimate","gdpNominal":10489.93,"gdpPPP":28028.57,"gdpYear":2025,"consumptionPLI":0.40971,"priceYear":2025,"priceSource":"wb-consumption"},"NO":{"usd":6439.778,"wageYear":2025,"source":"ilo","gdpNominal":94594.19,"gdpPPP":104043.67,"gdpYear":2025,"consumptionPLI":0.96205,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:3054","status":""},"OM":{"usd":1162.824,"wageYear":2025,"source":"estimate","gdpNominal":19947.4,"gdpPPP":42295.18,"gdpYear":2025,"consumptionPLI":0.47299,"priceYear":2025,"priceSource":"wb-consumption"},"PK":{"usd":94.715,"wageYear":2025,"source":"ilo","gdpNominal":1595.91,"gdpPPP":6573.42,"gdpYear":2025,"consumptionPLI":0.23261,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:538","status":""},"PW":{"usd":1042.366,"wageYear":2023,"source":"ilo","gdpNominal":19532.36,"gdpPPP":23051.68,"gdpYear":2025,"consumptionPLI":0.96332,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:14046","status":""},"PS":{"usd":269.568,"wageYear":2025,"source":"estimate","gdpNominal":3171.11,"gdpPPP":4999.71,"gdpYear":2025,"consumptionPLI":0.63426,"priceYear":null,"priceSource":"gdp-proxy"},"PA":{"usd":928.568,"wageYear":2025,"source":"ilo","gdpNominal":19789.73,"gdpPPP":43902.16,"gdpYear":2025,"consumptionPLI":0.49671,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:511","status":""},"PG":{"usd":256.683,"wageYear":2025,"source":"estimate","gdpNominal":3019.53,"gdpPPP":5214.77,"gdpYear":2025,"consumptionPLI":0.66992,"priceYear":2025,"priceSource":"wb-consumption"},"PY":{"usd":428.844,"wageYear":2025,"source":"ilo","gdpNominal":7026.62,"gdpPPP":20181.42,"gdpYear":2025,"consumptionPLI":0.38097,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BX:14043","status":""},"PE":{"usd":562.932,"wageYear":2025,"source":"ilo","gdpNominal":9684.41,"gdpPPP":18816.1,"gdpYear":2025,"consumptionPLI":0.54023,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:16208","status":""},"PH":{"usd":346.726,"wageYear":2025,"source":"ilo","gdpNominal":4170.72,"gdpPPP":12576.99,"gdpYear":2025,"consumptionPLI":0.35707,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:629","status":""},"PL":{"usd":2301.914,"wageYear":2025,"source":"ilo","gdpNominal":28419.58,"gdpPPP":54262.4,"gdpYear":2025,"consumptionPLI":0.54863,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:13355","status":""},"PT":{"usd":1426.237,"wageYear":2025,"source":"ilo","gdpNominal":32081.81,"gdpPPP":53145.73,"gdpYear":2025,"consumptionPLI":0.64942,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:199","status":""},"QA":{"usd":3286.538,"wageYear":2022,"source":"ilo","gdpNominal":72524.91,"gdpPPP":128882.93,"gdpYear":2025,"consumptionPLI":0.757,"priceYear":2024,"priceSource":"wb-consumption","iloSource":"BA:696","status":""},"RO":{"usd":1722.405,"wageYear":2025,"source":"ilo","gdpNominal":22537.95,"gdpPPP":50895.08,"gdpYear":2025,"consumptionPLI":0.48776,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:439","status":""},"RU":{"usd":777.144,"wageYear":2021,"source":"ilo","gdpNominal":17546.61,"gdpPPP":49568.14,"gdpYear":2025,"consumptionPLI":0.36763,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"DA:122","status":""},"RW":{"usd":52.992,"wageYear":2024,"source":"ilo","gdpNominal":1123.74,"gdpPPP":4164.44,"gdpYear":2025,"consumptionPLI":0.26091,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:1590","status":""},"KN":{"usd":1966.795,"wageYear":2025,"source":"estimate","gdpNominal":25223.03,"gdpPPP":36777.26,"gdpYear":2025,"consumptionPLI":0.79486,"priceYear":2023,"priceSource":"wb-consumption"},"LC":{"usd":859.601,"wageYear":2025,"source":"estimate","gdpNominal":14745.82,"gdpPPP":28673.84,"gdpYear":2025,"consumptionPLI":0.59063,"priceYear":2025,"priceSource":"wb-consumption"},"VC":{"usd":732.282,"wageYear":2025,"source":"estimate","gdpNominal":12561.77,"gdpPPP":22799.4,"gdpYear":2025,"consumptionPLI":0.62152,"priceYear":2025,"priceSource":"wb-consumption"},"WS":{"usd":613.03,"wageYear":2022,"source":"ilo","gdpNominal":5872.78,"gdpPPP":9318.96,"gdpYear":2025,"consumptionPLI":0.67408,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:1794","status":"B"},"SM":{"usd":2316.6,"wageYear":2022,"source":"ilo","gdpNominal":59871.33,"gdpPPP":78810.34,"gdpYear":2023,"consumptionPLI":0.82961,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"EA:5918","status":""},"ST":{"usd":347.205,"wageYear":2025,"source":"estimate","gdpNominal":4084.4,"gdpPPP":6388.48,"gdpYear":2025,"consumptionPLI":0.67597,"priceYear":2025,"priceSource":"wb-consumption"},"SA":{"usd":1799.467,"wageYear":2022,"source":"ilo","gdpNominal":34536.66,"gdpPPP":73783.56,"gdpYear":2025,"consumptionPLI":0.49886,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:627","status":""},"SN":{"usd":278.238,"wageYear":2025,"source":"ilo","gdpNominal":1954.71,"gdpPPP":5463.22,"gdpYear":2025,"consumptionPLI":0.38925,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:13368","status":""},"RS":{"usd":1558.976,"wageYear":2025,"source":"ilo","gdpNominal":15262.05,"gdpPPP":33909.76,"gdpYear":2025,"consumptionPLI":0.50906,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:6644","status":""},"SC":{"usd":1048.989,"wageYear":2022,"source":"ilo","gdpNominal":19449.38,"gdpPPP":35854.03,"gdpYear":2025,"consumptionPLI":0.57386,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"FA:5920","status":""},"SL":{"usd":128.235,"wageYear":2025,"source":"estimate","gdpNominal":846.3,"gdpPPP":3716.89,"gdpYear":2025,"consumptionPLI":0.24857,"priceYear":2023,"priceSource":"wb-consumption"},"SG":{"usd":3483.482,"wageYear":2021,"source":"ilo","gdpNominal":98813.98,"gdpPPP":163353.99,"gdpYear":2025,"consumptionPLI":0.78306,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:5873","status":""},"SK":{"usd":2496.145,"wageYear":2025,"source":"ilo","gdpNominal":28543.67,"gdpPPP":49308.7,"gdpYear":2025,"consumptionPLI":0.63929,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:560","status":""},"SI":{"usd":3694.425,"wageYear":2025,"source":"ilo","gdpNominal":37376.22,"gdpPPP":59244.71,"gdpYear":2025,"consumptionPLI":0.66986,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:445","status":""},"SB":{"usd":177.342,"wageYear":2025,"source":"estimate","gdpNominal":2086.19,"gdpPPP":2787.62,"gdpYear":2025,"consumptionPLI":0.91845,"priceYear":2025,"priceSource":"wb-consumption"},"SO":{"usd":100.184,"wageYear":2025,"source":"estimate","gdpNominal":661.17,"gdpPPP":1642.77,"gdpYear":2025,"consumptionPLI":0.40247,"priceYear":null,"priceSource":"gdp-proxy"},"ZA":{"usd":484.853,"wageYear":2020,"source":"ilo","gdpNominal":6597.71,"gdpPPP":15905.68,"gdpYear":2025,"consumptionPLI":0.43267,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:16198","status":""},"SS":{"usd":63.64,"wageYear":null,"source":"estimate","gdpNominal":420.0,"gdpPPP":1500.0,"gdpYear":null,"consumptionPLI":0.28,"priceYear":null,"priceSource":"gdp-proxy"},"ES":{"usd":3574.138,"wageYear":2025,"source":"ilo","gdpNominal":38627.25,"gdpPPP":59867.69,"gdpYear":2025,"consumptionPLI":0.68687,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:3071","status":""},"LK":{"usd":161.67,"wageYear":2024,"source":"ilo","gdpNominal":5002.08,"gdpPPP":17065.03,"gdpYear":2025,"consumptionPLI":0.26968,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:1359","status":""},"SD":{"usd":284.182,"wageYear":2022,"source":"ilo","gdpNominal":1164.54,"gdpPPP":2192.27,"gdpYear":2025,"consumptionPLI":0.41021,"priceYear":2022,"priceSource":"wb-consumption","iloSource":"BA:1603","status":"B"},"SR":{"usd":264.081,"wageYear":2022,"source":"ilo","gdpNominal":7069.87,"gdpPPP":22652.4,"gdpYear":2025,"consumptionPLI":0.41947,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:15691","status":""},"SE":{"usd":4782.742,"wageYear":2025,"source":"ilo","gdpNominal":63133.21,"gdpPPP":72528.89,"gdpYear":2025,"consumptionPLI":0.90513,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:3063","status":""},"CH":{"usd":7779.875,"wageYear":2025,"source":"ilo","gdpNominal":114769.01,"gdpPPP":102513.35,"gdpYear":2025,"consumptionPLI":1.28169,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:253","status":""},"SY":{"usd":160.129,"wageYear":2022,"source":"estimate","gdpNominal":1056.78,"gdpPPP":4905.15,"gdpYear":2022,"consumptionPLI":0.21544,"priceYear":2022,"priceSource":"gdp-proxy"},"TJ":{"usd":248.084,"wageYear":2025,"source":"estimate","gdpNominal":1637.25,"gdpPPP":5923.47,"gdpYear":2025,"consumptionPLI":0.31925,"priceYear":2025,"priceSource":"wb-consumption"},"TZ":{"usd":211.626,"wageYear":2024,"source":"ilo","gdpNominal":1318.82,"gdpPPP":4470.95,"gdpYear":2025,"consumptionPLI":0.25308,"priceYear":2024,"priceSource":"wb-consumption","iloSource":"BA:1743","status":"B"},"TH":{"usd":507.819,"wageYear":2025,"source":"ilo","gdpNominal":8056.56,"gdpPPP":26250.07,"gdpYear":2025,"consumptionPLI":0.32255,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:741","status":""},"TL":{"usd":257.594,"wageYear":2021,"source":"ilo","gdpNominal":1340.96,"gdpPPP":4809.49,"gdpYear":2025,"consumptionPLI":0.44565,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:3050","status":""},"TG":{"usd":137.662,"wageYear":2022,"source":"ilo","gdpNominal":1383.9,"gdpPPP":4079.36,"gdpYear":2025,"consumptionPLI":0.37529,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BB:16196","status":""},"TO":{"usd":662.786,"wageYear":2023,"source":"ilo","gdpNominal":6547.19,"gdpPPP":8674.68,"gdpYear":2025,"consumptionPLI":0.77861,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:1712","status":""},"TT":{"usd":1105.688,"wageYear":2025,"source":"estimate","gdpNominal":18967.27,"gdpPPP":37121.21,"gdpYear":2025,"consumptionPLI":0.56911,"priceYear":2025,"priceSource":"wb-consumption"},"TN":{"usd":395.849,"wageYear":2025,"source":"estimate","gdpNominal":4656.64,"gdpPPP":15233.49,"gdpYear":2025,"consumptionPLI":0.32705,"priceYear":2025,"priceSource":"wb-consumption"},"TR":{"usd":1000.811,"wageYear":2025,"source":"ilo","gdpNominal":18599.44,"gdpPPP":45288.48,"gdpYear":2025,"consumptionPLI":0.44974,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:622","status":""},"TM":{"usd":555.965,"wageYear":2025,"source":"estimate","gdpNominal":6540.18,"gdpPPP":22601.55,"gdpYear":2025,"consumptionPLI":0.28937,"priceYear":null,"priceSource":"gdp-proxy"},"TV":{"usd":513.569,"wageYear":2025,"source":"estimate","gdpNominal":6041.45,"gdpPPP":6759.28,"gdpYear":2025,"consumptionPLI":0.8938,"priceYear":2025,"priceSource":"gdp-proxy"},"UG":{"usd":161.045,"wageYear":2021,"source":"ilo","gdpNominal":1206.3,"gdpPPP":3487.7,"gdpYear":2025,"consumptionPLI":0.37111,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:13047","status":""},"UA":{"usd":459.058,"wageYear":2022,"source":"ilo","gdpNominal":5865.88,"gdpPPP":18904.98,"gdpYear":2025,"consumptionPLI":0.2846,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"DA:5913","status":""},"AE":{"usd":3920.136,"wageYear":2024,"source":"estimate","gdpNominal":50273.51,"gdpPPP":79343.78,"gdpYear":2024,"consumptionPLI":0.68808,"priceYear":2025,"priceSource":"wb-consumption"},"GB":{"usd":4156.553,"wageYear":2025,"source":"ilo","gdpNominal":57601.96,"gdpPPP":64606.5,"gdpYear":2025,"consumptionPLI":0.9237,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:666","status":""},"US":{"usd":6272.925,"wageYear":2025,"source":"ilo","gdpNominal":90026.52,"gdpPPP":90026.52,"gdpYear":2025,"consumptionPLI":1.0,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:453","status":"B"},"UY":{"usd":1192.13,"wageYear":2024,"source":"ilo","gdpNominal":25215.82,"gdpPPP":38314.89,"gdpYear":2025,"consumptionPLI":0.7248,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:16753","status":""},"UZ":{"usd":351.322,"wageYear":2022,"source":"ilo","gdpNominal":3968.27,"gdpPPP":13601.29,"gdpYear":2025,"consumptionPLI":0.28406,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"EA:1769","status":""},"VU":{"usd":343.323,"wageYear":2025,"source":"estimate","gdpNominal":4038.74,"gdpPPP":4525.24,"gdpYear":2025,"consumptionPLI":1.01591,"priceYear":2025,"priceSource":"wb-consumption"},"VE":{"usd":170.483,"wageYear":null,"source":"estimate","gdpNominal":2005.5,"gdpPPP":7000,"gdpYear":null,"consumptionPLI":0.2865,"priceYear":null,"priceSource":"gdp-proxy"},"YE":{"usd":106.067,"wageYear":null,"source":"estimate","gdpNominal":700.0,"gdpPPP":2500.0,"gdpYear":null,"consumptionPLI":0.28,"priceYear":null,"priceSource":"gdp-proxy"},"ZM":{"usd":170.377,"wageYear":2024,"source":"ilo","gdpNominal":1317.88,"gdpPPP":4379.26,"gdpYear":2025,"consumptionPLI":0.33204,"priceYear":2025,"priceSource":"wb-consumption","iloSource":"BA:2212","status":""},"ZW":{"usd":256.844,"wageYear":2025,"source":"estimate","gdpNominal":3021.43,"gdpPPP":6470.42,"gdpYear":2025,"consumptionPLI":0.46696,"priceYear":2025,"priceSource":"gdp-proxy"}}};
function context(l){var code=l.abroad&&(l.abroad.perm||l.abroad.research)?l.abroad.code:l.country;return{code:code,country:G.W.BY[code],data:DATA.countries[code]};}
function factor(l){return l.urban?1.04:.83;}
function scale(l,c,monthly){var x=context(l);if(l.cur==='vnd'||!x.data)return null;
 var p=G.CUR.priceLevel(x.country?x.country.gdp:l.gdp),sector=c && c.sec === 'farm' ? .82 : c && c.sec === 'inf' ? .90 : 1;
 var premium=1;
 if(monthly>DATA.vnMonthlyMillion*1.5 && !(c&&(c.fame||c.sec==='crime'))){
  var relative=monthly/DATA.vnMonthlyMillion,ratio=x.data.usd/(DATA.vnMonthlyMillion*1e6/G.CUR.VND);
  var exponent=Math.max(.35,Math.min(.85,.85-Math.log(Math.max(1,ratio))*.17));
  premium=1.5*Math.pow(relative/1.5,exponent)/relative;
 }
 return x.data.usd/p/DATA.vnMonthlyMillion*factor(l)*sector*premium;
}
function baseFor(code,urban,gdp){var d=DATA.countries[code],c=G.W.BY[code];if(!d||!c)return null;
 var p=G.CUR.priceLevel(gdp||c.gdp),annual=d.usd*12/p;
 // Household prices determine expenses; wage bounds prevent GDP-heavy tax havens from imposing implausible household budgets.
 var raw=d.gdpPPP*.55*d.consumptionPLI/p;
 return Math.max(annual*.45,Math.min(annual*.90,raw))*(urban?1.1:.8);
}
G.WEC={data:DATA,context:context,scale:scale,baseFor:baseFor};
})(typeof window!=='undefined'?(window.G=window.G||{}):(globalThis.G=globalThis.G||{}));

;
