/* ===== js/life34.js ===== */
/* Một Đời — v3.4:
   · hẹn hò qua mạng (Tinder, Bumble, Facebook Hẹn hò…): gặp người tử tế, người "đào mỏ", lừa đầu tư, ảnh ảo, "Việt kiều gửi quà"; đủ tinh ý thì thoát
   · nhiều hoạt động hẹn hò: xem phim, tô tượng, thủy cung, nhà sách, bảo tàng, workshop, bowling…
   · rủ người lạ chơi game cùng (nam giả nữ, "đồng đội" là học sinh lớp 5…) · nghề cày thuê rank Liên Quân, Liên Minh, Tốc Chiến
   · thêm nhiều chuyện tuổi thơ; game nhớ những chuyện đã gặp ở các đời trước để chơi lại ít trùng */
(function (G) {
  'use strict';
  var U = G.U, E = G.E, H = E.H, SC = E.SC, isVN = H.isVN;
  function A(id, g, label, o) { var x = { id: id, g: g, l: label }; for (var k in o) x[k] = o[k]; E.ACT.push(x); }
  function fx(l, o) { H.fx(l, o); }
  function mo(l, v) { return H.money(l, v); }
  function pick(r, a) { return U.pick(r, a); }
  function ch(r, p) { return r() < p; }
  function free(l) { return !(l.jailUntil != null && l.age < l.jailUntil) && !(l.abroad && l.abroad.trapped) && !(l.flags.military && l.age < l.flags.military); }
  function vnd(l) { return isVN(l) && l.cur === 'vnd' && !(l.abroad && l.abroad.perm); }
  function V(l, tr) { return vnd(l) ? tr : tr / 90 * l.base; }
  function pay(l, tr, why) { var x = Math.min(V(l, tr), Math.max(0, l.money) + l.base * 0.5); H.cash(l, -x, why); return x; }
  function rng(r, a, b) { return a + (b - a) * r(); }

  // ===================================================================
  // 1. HẸN HÒ QUA MẠNG: NGƯỜI TỬ TẾ VÀ NHỮNG CÚ LỪA
  // ===================================================================
  // độ tinh ý: hiểu biết, từng trải, từng bị lừa thì cảnh giác hơn
  function savvy(l) { return U.clamp(0.15 + l.st.kno / 220 + l.st.soc / 400 + Math.min(20, l.age - 18) / 100 + (l.flags.scamOnline ? 0.25 : 0) + (l.exes || 0) * 0.03, 0.1, 0.92); }
  E.datingSavvy = savvy;
  function who(sex) { return sex === 'M' ? 'anh ấy' : 'cô ấy'; }
  var TYPES = [['tot', 46], ['dao_mo', 24], ['dau_tu', 10], ['catfish', 12], ['qua_tang', 8]];
  SC('hen_online', {
    title: function (l, d) { return 'Quen qua ' + d.app; },
    prep: function (l, r, arg) {
      var a = arg || {}, s = a.s || H.partnerSex(l, r), t = a.t;
      if (!t) { var tot = 0, ws = TYPES.map(function (x) { var w = x[1] * (x[0] === 'qua_tang' && l.age >= 40 ? 2.5 : 1) * (x[0] === 'dao_mo' && (l.money > l.base * 10 || (l.vehTier || 0) >= 2) ? 2 : 1); tot += w; return w; }), y = r() * tot; for (var i = 0; i < TYPES.length; i++) { y -= ws[i]; if (y < 0) { t = TYPES[i][0]; break; } } t = t || 'tot'; }
      return { app: a.app || 'Tinder', s: s, n: a.n || H.stranger(l, r, s), age: a.age || Math.max(18, l.age + U.randint(r, -4, 4)), t: t, job: a.job || null };
    },
    valid: function (l) { return l.age >= 18 && !l.partner; },
    text: function (l, d) {
      var w = who(d.s);
      var T = {
        tot: 'Bạn match với ' + d.n + ' (' + d.age + ' tuổi) trên ' + d.app + '. Nhắn tin mấy hôm thấy hợp: ' + w + ' kể chuyện công việc, hỏi han bạn ăn uống, rủ cuối tuần đi cà phê.',
        dao_mo: 'Bạn match với ' + d.n + ' (' + d.age + ' tuổi) trên ' + d.app + ', ảnh lung linh, nhắn tin ngọt ngào. Nhưng ' + w + ' hay hỏi bạn làm nghề gì, lương bao nhiêu, đi xe gì, và gợi ý buổi hẹn đầu ở nhà hàng hải sản sang trọng.',
        dau_tu: 'Bạn match với ' + d.n + ' (' + d.age + ' tuổi) trên ' + d.app + '. Nói chuyện rất hợp, ' + w + ' khoe đang đầu tư vàng / tiền ảo trên một sàn "của anh họ", ngày nào cũng gửi ảnh lãi, rủ bạn "nạp thử vài triệu cho vui".',
        catfish: 'Bạn match với ' + d.n + ' trên ' + d.app + ': ảnh đẹp như người mẫu, nhắn tin vui tính, nhưng lần nào rủ gọi video cũng bảo "camera hỏng", "đang ở chỗ ồn".',
        qua_tang: 'Một người tự giới thiệu là ' + (d.s === 'M' ? 'kỹ sư dầu khí người nước ngoài' : 'nữ bác sĩ Việt kiều') + ' nhắn tin làm quen qua ' + d.app + ', nói tiếng Việt hơi lơ lớ, hứa sẽ gửi quà về tặng bạn.'
      }[d.t];
      return T;
    },
    opts: [
      { k: 'gap', l: 'Hẹn gặp ở một quán cà phê bình thường', ai: { w: 1.2 }, run: function (l, r, log, d) { meet(l, r, log, d); } },
      { k: 'chieu', l: function (l, d) { return d.t === 'dau_tu' ? 'Nạp thử vài triệu vào "sàn" như lời gợi ý' : d.t === 'qua_tang' ? 'Đồng ý nhận quà' : 'Chiều theo, đi nhà hàng sang như lời gợi ý'; }, ai: { risk: 0.8, smart: -0.8, w: 0.6 }, run: function (l, r, log, d) { follow(l, r, log, d); } },
      { k: 'kiem_tra', l: 'Gọi video, tìm ảnh trên mạng, hỏi kỹ trước đã', ai: { smart: 1.2, w: 1 }, run: function (l, r, log, d) { check(l, r, log, d); } },
      { k: 'thoi', l: 'Thôi, thấy không ổn, hủy kết nối', ai: { w: 0.4 }, run: function (l, r, log, d) { log('Hủy kết nối với ' + d.n + '.', 'neutral'); } }
    ]
  });
  function scammed(l, log, amt, t) { var x = pay(l, amt, 'Bị lừa qua mạng'); l.flags.scamOnline = true; fx(l, { hap: -8 }); if (l.mind) l.mind.stress += 8; log(t + ' Mất ' + mo(l, x) + '.', 'bad'); H.mem(l, 'Lần bị lừa qua ứng dụng hẹn hò — bài học đắt giá.', 3); }
  function love(l, r, d, where) { var dec = E.DEC.love.make(l, r, { where: where }); dec.data.p.name = d.n; dec.data.p.sex = d.s; dec.data.p.age = d.age; dec.text = 'Bạn và ' + d.n + ' (' + (d.s === 'M' ? 'nam' : 'nữ') + ', ' + d.age + ' tuổi) quen nhau ' + where + '. Gặp ngoài đời còn dễ thương hơn trên mạng.'; l.pending.unshift(dec); }
  function meet(l, r, log, d) {
    var w = who(d.s);
    if (d.t === 'tot') { pay(l, 0.15, 'Cà phê hẹn hò'); love(l, r, d, 'qua ' + d.app); return; }
    if (d.t === 'dao_mo') {
      if (ch(r, savvy(l) + 0.15)) { pay(l, 0.15, 'Cà phê hẹn hò'); log('Hẹn ở quán cà phê bình thường, ' + d.n + ' tỏ ra hụt hẫng, cả buổi chỉ hỏi bạn có nhà riêng chưa, xe gì. Hôm sau ' + w + ' "hủy kết nối". Thoát một người đào mỏ.', 'good'); fx(l, { kno: 1 }); }
      else { scammed(l, log, rng(r, 3, 8), 'Đến quán, ' + d.n + ' gọi thêm cả bạn đi cùng, gọi món đắt nhất rồi "đi vệ sinh" để bạn tự thanh toán. Từ đó ' + w + ' chặn liên lạc.'); }
      return;
    }
    if (d.t === 'catfish') { pay(l, 0.15, 'Cà phê hẹn hò'); var t = pick(r, [d.n + ' ngoài đời khác ảnh đến mức bạn nhìn ba lần mới nhận ra. Hai người cười trừ, nói chuyện vẫn vui.', 'Đến nơi mới biết "' + d.n + '" là ' + (d.s === 'F' ? 'một anh chàng râu ria dùng ảnh gái xinh' : 'một bạn khác hẳn ảnh') + ' — "Xin lỗi, tại tui sợ không ai match."', 'Người đến hẹn là… em họ của chủ tài khoản, được nhờ "đi xem mặt hộ".']); log(t, 'neutral'); fx(l, { hap: -1 }); return; }
    // lừa đầu tư, "quà tặng" thường không bao giờ chịu gặp
    log(d.n + ' viện đủ lý do để không gặp mặt, chỉ muốn nói chuyện qua tin nhắn. Bạn bắt đầu thấy lạ và cắt liên lạc.', 'good'); fx(l, { kno: 1 });
  }
  function follow(l, r, log, d) {
    var w = who(d.s);
    if (d.t === 'tot') { pay(l, 1.5, 'Hẹn hò nhà hàng'); love(l, r, d, 'qua ' + d.app); return; }
    if (d.t === 'dao_mo') {
      pay(l, rng(r, 2, 5), 'Hẹn hò nhà hàng sang');
      if (ch(r, savvy(l))) { log('Buổi hẹn nhà hàng sang trọng, rồi ' + d.n + ' xin bạn mua chiếc điện thoại mới "vì máy em hỏng". Bạn chợt nhận ra mình đang bị "đào mỏ", lịch sự từ chối và chia tay.', 'neutral'); }
      else scammed(l, log, rng(r, 30, 80), 'Hết nhà hàng sang đến điện thoại mới, rồi "mẹ ' + (d.s === 'M' ? 'anh' : 'em') + ' nằm viện cần tiền gấp". Bạn chuyển khoản liền mấy lần, rồi ' + w + ' chặn số, xóa tài khoản.');
      return;
    }
    if (d.t === 'dau_tu') {
      if (ch(r, savvy(l) * 0.8)) { pay(l, 3, 'Nạp thử sàn đầu tư'); log('Nạp thử 3 triệu, rút được tiền lãi nhỏ. Khi ' + w + ' giục nạp thêm 100 triệu "để lên VIP", bạn nghi ngờ, tìm trên mạng thì thấy đúng chiêu lừa "sát heo". Mất 3 triệu, may mà dừng kịp.', 'neutral'); l.flags.scamOnline = true; }
      else scammed(l, log, Math.max(20, Math.max(0, l.money) * rng(r, 0.3, 0.7) / (vnd(l) ? 1 : l.base / 90)), 'Nạp thử thấy lãi thật, rút được tiền, bạn nạp dần cả trăm triệu. Đến khi muốn rút, sàn báo "phải đóng thuế 20%". Đóng xong thì sàn biến mất, ' + d.n + ' cũng biến mất. Đây là chiêu lừa "sát heo".');
      return;
    }
    if (d.t === 'qua_tang') {
      if (ch(r, savvy(l))) { log('Vừa đồng ý nhận quà thì có người tự xưng "nhân viên hải quan" gọi bắt đóng phí thông quan. Bạn nhận ra chiêu lừa quen thuộc, chặn hết số.', 'good'); l.flags.scamOnline = true; }
      else scammed(l, log, rng(r, 15, 60), 'Đóng "phí hải quan", rồi "phí chống rửa tiền", rồi "phí vận chuyển"… kiện quà toàn trang sức, đô la chẳng bao giờ đến.');
      return;
    }
    if (d.t === 'catfish') { pay(l, 0.5, 'Nạp thẻ điện thoại cho "người yêu mạng"'); log(d.n + ' xin bạn nạp thẻ điện thoại "vì hết tiền", rồi biến mất. Hóa ra là tài khoản ảo.', 'bad'); }
  }
  function check(l, r, log, d) {
    var w = who(d.s);
    if (d.t === 'tot') { log('Gọi video với ' + d.n + ': y như trong ảnh, nói chuyện tự nhiên. Yên tâm hẹn gặp.', 'good'); love(l, r, d, 'qua ' + d.app); return; }
    if (ch(r, savvy(l) + 0.3)) {
      var t = { dao_mo: 'Hỏi kỹ thì ' + d.n + ' từng "hẹn hò" với mấy người bạn của bạn, ai cũng bị nhờ mua quà đắt tiền. Bạn tránh xa.', dau_tu: 'Tra tên "sàn" trên mạng: đầy bài cảnh báo lừa đảo. Bạn chặn và báo cáo tài khoản.', catfish: 'Tìm ảnh trên mạng: đó là ảnh của một hot girl nước ngoài. Bạn cười rồi chặn.', qua_tang: 'Tra thử: kịch bản "gửi quà, đóng phí hải quan" giống hệt những vụ báo đài đã cảnh báo. Bạn báo cáo tài khoản.' }[d.t];
      log(t, 'good'); fx(l, { kno: 2 }); l.flags.scamOnline = true;
    } else { log(d.n + ' khéo léo vượt qua mọi câu hỏi. Bạn vẫn chưa rõ ' + w + ' là người thế nào…', 'neutral'); l.pending.unshift(E.DEC.hen_online.make(l, r, d)); }
  }
  // ứng dụng hẹn hò (bản v3.0) giờ dẫn vào chuỗi tình huống này
  if (E.DEC.app_hen_ho) E.DEC.app_hen_ho.def.opts.forEach(function (o) {
    if (o.k === 'no') return;
    var run0 = o.run;
    o.run = function (l, r, log) {
      if (o.k === 'trung_nien' || o.k === 'blued' || o.k === 'her' || ch(r, 0.25)) return run0.apply(this, arguments); // giữ các kết cục cũ (qua đêm, bị lừa…) cho đa dạng
      if (ch(r, 0.22)) { log('Quẹt mỏi tay, nhắn được vài người rồi im bặt.', 'neutral'); return; }
      l.pending.unshift(E.DEC.hen_online.make(l, r, { app: o.l }));
    };
  });

  // ===================================================================
  // 2. HOẠT ĐỘNG HẸN HÒ
  // ===================================================================
  var DATES = [
    ['phim', 'Đi xem phim ở rạp', 0.4, 'Xem phim xong hai người tranh luận về cái kết suốt đường về.', { hap: 4 }],
    ['to_tuong', 'Đi tô tượng thạch cao', 0.3, 'Ngồi tô tượng cả buổi chiều, tượng của hai đứa đều xấu nhưng chụp ảnh thì đẹp.', { hap: 5 }],
    ['thuy_cung', 'Đi thủy cung', 0.8, 'Đứng hàng giờ trước bể cá mập, ' + 'tay trong tay trong ánh sáng xanh của đường hầm thủy cung.', { hap: 6 }],
    ['nha_sach', 'Dạo nhà sách, ngồi cà phê sách', 0.3, 'Mỗi người chọn một cuốn tặng nhau, ngồi đọc ở góc quán cà phê sách đến tối.', { hap: 4, kno: 1 }],
    ['bao_tang', 'Đi bảo tàng, triển lãm', 0.15, 'Đi bảo tàng, đứng trước những hiện vật cũ nghe nhau kể chuyện lịch sử.', { hap: 3, kno: 2 }],
    ['workshop', 'Workshop làm nến thơm, làm gốm', 0.6, 'Tự tay nặn chiếc cốc gốm méo mó tặng nhau — món quà đáng giá nhất năm.', { hap: 6 }],
    ['bowling', 'Chơi bowling, game center', 0.5, 'Thua nhau mấy ván bowling, người thua phải bao trà sữa.', { hap: 5, soc: 1 }],
    ['patin', 'Trượt patin, đạp xe quanh hồ', 0.15, 'Ngã lên ngã xuống ở sân patin, cười đến đau bụng.', { hap: 5, hea: 1 }],
    ['lau', 'Đi ăn lẩu, nướng', 0.6, 'Ăn lẩu nướng bốc khói, nói chuyện trên trời dưới biển.', { hap: 4 }],
    ['cho_dem', 'Dạo chợ đêm, phố đi bộ, ăn vặt', 0.25, 'Dạo phố đi bộ, ăn hết hàng này sang hàng khác.', { hap: 4 }],
    ['picnic', 'Picnic ở công viên, ngắm hoàng hôn', 0.15, 'Trải bạt picnic, ngồi ngắm hoàng hôn đến khi đèn đường bật sáng.', { hap: 5 }],
    ['nau_an', 'Nấu ăn cùng nhau ở nhà', 0.2, 'Cùng nhau vào bếp, món ăn hơi mặn nhưng ai cũng khen ngon.', { hap: 4, soc: 1 }],
    ['karaoke', 'Đi hát karaoke hai người', 0.3, 'Hát song ca những bài tình ca cũ, giọng ai cũng lệch tông.', { hap: 4 }],
    ['mi_cay', 'Đi ăn mì cay 7 cấp độ', 0.25, 'Thách nhau ăn mì cay cấp 7, mặt đỏ như gấc, uống hết ba ly trà đá vẫn cười.', { hap: 5 }],
    ['netflix', 'Ở nhà xem Netflix, gọi đồ ăn', 0.15, 'Cuộn chăn xem phim trên Netflix, gọi gà rán về ăn, tranh nhau chọn phim mất nửa tiếng.', { hap: 4 }],
    ['ga_ran', 'Đi ăn gà rán (KFC / Jollibee)', 0.25, 'Ăn gà rán, khoai tây chiên, uống nước ngọt — đơn giản mà vui.', { hap: 3 }],
    ['dookki', 'Đi buffet tokbokki (Dookki)', 0.35, 'Tự tay nấu nồi tokbokki ở Dookki, cháy đáy nồi vẫn khen ngon.', { hap: 4 }],
    ['lau_sang', 'Đi lẩu Haidilao, được nhân viên hát mừng', 1.2, 'Đi lẩu Haidilao, nhân viên kéo mì múa ngay cạnh bàn, cả hai cười suốt bữa.', { hap: 6 }],
    ['buffet_hs', 'Đi buffet hải sản sang (Cửu Vân Long)', 0.9, 'Ăn buffet hải sản Cửu Vân Long no căng bụng, cua ghẹ tôm hùm đủ cả.', { hap: 6 }],
    ['pizza', "Ăn pizza ở Pizza 4P's", 0.8, "Ngồi Pizza 4P's, chia nhau miếng pizza phô mai burrata, nói chuyện tới khuya.", { hap: 5 }],
    ['cong_vien', 'Đi công viên giải trí, chơi tàu lượn', 0.7, 'Hét khản cổ trên tàu lượn siêu tốc, xuống tàu vẫn nắm chặt tay nhau.', { hap: 6 }]
  ];
  if (E.DEC.hen_ho) {
    var HH = E.DEC.hen_ho.def, old = HH.opts;
    var p0 = HH.prep;
    HH.prep = function (l, r, arg) { var d = p0 ? p0.apply(this, arguments) || {} : {}; var ks = DATES.map(function (x) { return x[0]; }).filter(function (k) { return vnd(l) || !/^(dookki|buffet_hs|pizza)$/.test(k); }); for (var i = ks.length - 1; i > 0; i--) { var j = Math.floor(r() * (i + 1)), t = ks[i]; ks[i] = ks[j]; ks[j] = t; } d.acts = ks.slice(0, 5); return d; };
    HH.text = function (l) { return 'Dạo này bạn và ' + l.partner.name + ' ít thời gian cho nhau. Cuối tuần này hai người đi đâu?'; };
    HH.opts = DATES.map(function (x) {
      return { k: x[0], l: x[1], h: function (l) { return x[2] ? '~' + mo(l, V(l, x[2])) : 'Không tốn tiền'; }, req: function (l, d) { return !d.acts || d.acts.indexOf(x[0]) >= 0; }, ai: { w: 1 },
        run: function (l, r, log) { var pw = l.partner ? l.partner.name : 'người ấy'; var t = (H.datePay ? H.datePay(l, r, V(l, x[2]) / l.base, 'Hẹn hò: ' + x[1].toLowerCase()) : (H.cash(l, -V(l, x[2]), 'Hẹn hò'), '')); log(x[3].replace(/^/, '') + ' (cùng ' + pw + ')' + (t || ''), 'good'); fx(l, x[4]); if (ch(r, 0.15)) H.mem(l, x[3], 2); } };
    }).concat(old.filter(function (o) { return /^(dinner|trip|talk)$/.test(o.k); }));
  }

  // ===================================================================
  // 3. RỦ NGƯỜI LẠ CHƠI GAME CÙNG
  // ===================================================================
  SC('ghep_game', {
    title: 'Rủ người lạ chơi game cùng', valid: function (l) { return l.age >= 13 && l.age <= 40; },
    prep: function (l, r) { return { g: E.ageGame ? E.ageGame(l, r) : (l.game || 'Liên Quân Mobile'), t: pick(r, ['gia_nu', 'hoc_sinh', 'toxic', 'carry', 'crush']), n: pick(r, ['"Bé Mèo 2k5"', '"Tiểu Thư Lười"', '"Sát Thủ Bóng Đêm"', '"Gấu Nhỏ"', '"Kẹo Ngọt"']) }; },
    text: function (l, d) { return 'Đăng bài tìm đồng đội chơi ' + d.g + ' trên hội nhóm, có người tên ' + d.n + ' nhắn rủ leo rank cùng, giọng trong mic nghe rất dễ thương.'; },
    opts: [
      { k: 'choi', l: 'Ghép đội leo rank cùng', ai: { w: 1.2 }, run: function (l, r, log, d) {
        var t = {
          gia_nu: 'Leo rank cùng ' + d.n + ' cả tháng, thân đến mức hẹn gặp ngoài đời. Đến nơi thì gặp… một anh trai cao mét tám, dùng phần mềm đổi giọng: "Xin lỗi bro, giả gái thì được nhường đường dễ hơn." Cả hai cười đau bụng, thành anh em chí cốt.',
          hoc_sinh: d.n + ' chơi rất hay, nói chuyện như người lớn — đến khi mic vọng ra tiếng mẹ gọi "Con ơi tắt máy đi ngủ mai còn đi học lớp 5!". Bạn đành trả em về với bài tập về nhà.',
          toxic: d.n + ' chửi cả đội từ phút thứ ba. Thua xong lại rủ chơi tiếp, rồi dần dần thành bạn thân nhất trên mạng.',
          carry: d.n + ' gánh team từ Vàng lên Kim Cương trong một tuần. Bạn nghi ngờ đây là thợ cày thuê đang "chạy đơn" bằng nick phụ.',
          crush: 'Leo rank cùng ' + d.n + ' mấy tháng, hóa ra là người học cùng trường / làm cùng tòa nhà với bạn. Gặp ngoài đời, hai người ngượng chín mặt.'
        }[d.t];
        log(t, 'good'); fx(l, { hap: 4, soc: 3 });
        if (d.t === 'crush' && !l.partner && l.age >= 16 && ch(r, 0.4)) l.pending.unshift(E.DEC.love.make(l, r, { where: 'khi cùng leo rank ' + d.g }));
        if (d.t === 'carry' && ch(r, 0.4)) l.flags.biet_cay_thue = true;
      } },
      { k: 'thoi', l: 'Thôi, chơi một mình cho chắc', ai: { w: 0.5 }, run: function (l, r, log) { log('Từ chối, chơi một mình leo rank chậm rì.', 'neutral'); } }
    ]
  });
  E.TRIG.push({ id: 'ghep_game', when: function (l, a) { return a >= 13 && a <= 35 && free(l); }, p: function (l) { return l.talent === 'game' || l.game ? 0.08 : l.sex === 'M' ? 0.03 : 0.015; }, cd: 5, max: 2 });

  // ===================================================================
  // 4. NGHỀ CÀY THUÊ RANK
  // ===================================================================
  // Liên Quân Mobile: giá thị trường tham khảo (nghìn đồng / sao). Liên Minh Huyền Thoại, Tốc Chiến: ước lượng tham khảo.
  var BOOST = {
    'Liên Quân Mobile': { unit: 'sao', tiers: [['Đồng → Vàng', 3, 0], ['Bạch Kim → Tinh Anh', 6.5, 35], ['Cao Thủ dưới 25 sao', 10, 55], ['Cao Thủ 25–50 sao', 13, 70], ['Cao Thủ trên 50 sao', 15, 80], ['Chiến Thần', 25, 90]], perDay: 22 },
    'Liên Minh Huyền Thoại': { unit: 'bậc', tiers: [['Sắt → Bạc', 35, 0], ['Vàng', 60, 35], ['Bạch Kim', 90, 55], ['Lục Bảo', 130, 70], ['Kim Cương', 250, 82], ['Cao Thủ trở lên', 400, 92]], perDay: 1.6 },
    'Liên Minh: Tốc Chiến': { unit: 'sao', tiers: [['Đồng → Vàng', 4, 0], ['Bạch Kim', 7, 35], ['Lục Bảo', 10, 55], ['Kim Cương', 15, 70], ['Cao Thủ', 25, 82], ['Đại Cao Thủ, Thách Đấu', 40, 92]], perDay: 18 }
  };
  E.BOOST = BOOST;
  function boostGame(l) { var g = l.boostGame; if (!g || !BOOST[g]) { g = /Liên Minh Huyền/.test(l.game || '') ? 'Liên Minh Huyền Thoại' : /Tốc Chiến/.test(l.game || '') ? 'Liên Minh: Tốc Chiến' : 'Liên Quân Mobile'; l.boostGame = g; } return g; }
  // thu nhập một tháng: nhận được đơn ở mức rank cao nhất mình kéo nổi, cộng thêm đơn nhỏ
  function boostMonth(l) {
    var B = BOOST[boostGame(l)], s = l.skill || 30, top = B.tiers[0];
    B.tiers.forEach(function (t) { if (s >= t[2]) top = t; });
    var per = B.perDay * (0.6 + s / 200) * (top[2] >= 80 ? 0.6 : 1); // rank càng cao càng khó leo, mỗi ngày leo được ít hơn
    var shop = l.job && l.job.rank >= 2 ? 1.8 : l.job && l.job.rank >= 1 ? 1.2 : 1; // có tiếng, có thợ phụ thì nhận nhiều đơn
    return { tier: top[0], price: top[1], unit: B.unit, perDay: per, month: top[1] * per * 26 / 1000 * shop };
  }
  E.boostMonth = boostMonth;
  E.CAR.cay_thue = { id: 'cay_thue', t: ['thợ cày thuê rank (nhận đơn lẻ)', 'thợ cày thuê có tiếng, khách quen đều', 'chủ shop cày thuê, có thợ phụ'], vn: [5, 9, 16], yrs: [2, 3], cat: 'esport', sec: 'inf', edu: 0, talent: 'game', sigma: 0.3, w: 1.2 };
  var cy0 = E.careerYear;
  E.careerYear = function (l, r, log) {
    var inc = cy0.apply(this, arguments);
    if (l.job && E.resolveJob(l.job.id) === 'cay_thue' && inc > 0) {
      var m = boostMonth(l); inc = V(l, m.month) * 12 * Math.exp(U.normal(r) * 0.2);
      l.skill = Math.min(100, (l.skill || 30) + 1.5);
      if (!l.job.boostNoted || r() < 0.15) { l.job.boostNoted = true; log('Cày thuê ' + boostGame(l) + ': nhận đơn ' + m.tier + ' giá ~' + U.fmtNum(m.price) + ' nghìn đồng/' + m.unit + ', mỗi ngày leo được khoảng ' + U.fmtNum(Math.round(m.perDay * 10) / 10) + ' ' + m.unit + ' — tháng kiếm khoảng ' + mo(l, V(l, m.month)) + '.', 'money'); }
    }
    return inc;
  };
  SC('cay_thue_su_co', {
    title: 'Chuyện nghề cày thuê', valid: function (l) { return !!l.job && E.resolveJob(l.job.id) === 'cay_thue'; },
    prep: function (l, r) { return { t: pick(r, ['khoa', 'quyt', 'bao_mat', 'don_lon']) }; },
    text: function (l, d) { return { khoa: 'Một tài khoản khách gửi cày bị nhà phát hành khóa 7 ngày vì đăng nhập bất thường. Khách đòi bồi thường.', quyt: 'Kéo xong 40 sao cho khách, khách chặn liên lạc, chưa trả tiền.', bao_mat: 'Một khách quen gửi tài khoản kèm mật khẩu ngân hàng "nhờ nạp giúp", và hỏi bạn có muốn "mượn tạm" vài skin bán không.', don_lon: 'Một streamer có tiếng thuê bạn kéo nick lên rank cao nhất trước giải đấu, trả gấp đôi giá.' }[d.t] + ' (Cày thuê vi phạm điều khoản của nhà phát hành game, luôn có rủi ro bị khóa tài khoản.)'; },
    opts: [
      { k: 'dung', l: function (l, d) { return { khoa: 'Hoàn tiền, xin lỗi khách', quyt: 'Rút kinh nghiệm: từ nay thu tiền trước 50%', bao_mat: 'Trả lại thông tin, nhắc khách đổi mật khẩu ngay', don_lon: 'Nhận đơn, làm cẩn thận' }[d.t]; }, ai: { w: 1.3 },
        run: function (l, r, log, d) { if (d.t === 'khoa') { pay(l, 0.5, 'Bồi thường khách'); if (l.job) l.job.rep = (l.job.rep || 50) + 3; log('Hoàn tiền cho khách, giữ được uy tín.', 'neutral'); } else if (d.t === 'quyt') { pay(l, 0.4, 'Bị khách quỵt'); log('Mất công mấy đêm, từ nay đòi cọc trước.', 'bad'); } else if (d.t === 'bao_mat') { H.fx(l, { karma: 4 }); log('Nhắc khách đổi mật khẩu. Khách cảm động, giới thiệu thêm cả nhóm bạn.', 'good'); } else { H.cash(l, V(l, 4), 'Đơn cày thuê lớn'); l.fame = (l.fame || 0) + 2000; log('Kéo nick lên rank cao nhất đúng hẹn, streamer khen trên sóng — đơn hàng đến dồn dập.', 'good'); } } },
      { k: 'sai', l: function (l, d) { return { khoa: 'Chối, bảo tại khách tự đăng nhập', quyt: 'Lấy lại nick, đổi mật khẩu để "giữ làm tin"', bao_mat: 'Lấy vài skin bán kiếm thêm', don_lon: 'Dùng phần mềm gian lận cho nhanh' }[d.t]; }, ai: { bad: 1.2, risk: 0.8, w: 0.5 },
        run: function (l, r, log, d) { H.fx(l, { karma: -5 }); if (d.t === 'don_lon' || d.t === 'bao_mat') { if (ch(r, 0.5)) { log('Bị phát hiện, khách tố lên các hội nhóm, mất sạch khách. Có người còn trình báo công an.', 'bad'); l.job = null; l.flags.needJob = true; } else H.cash(l, V(l, 3), 'Tiền gian lận'); } else { log('Khách lên mạng "bóc phốt", đơn hàng giảm hẳn.', 'bad'); if (l.job) l.job.rep = (l.job.rep || 50) - 10; } } }
    ]
  });
  if (E.JOBS2) E.JOBS2.cay_thue_su_co = ['cay_thue']; // được kiểm tra cùng các sự kiện nghề
  E.TRIG.push({ id: 'cay_thue_su_co', when: function (l) { return !!l.job && E.resolveJob(l.job.id) === 'cay_thue' && free(l); }, p: 0.4, cd: 2, max: 4 });
  // học sinh, sinh viên giỏi game nhận cày thuê kiếm thêm
  A('cay_thue_them', 'Công việc', 'Nhận cày thuê rank kiếm thêm', { min: 14, max: 35, sc: 'cay_them', avail: function (l) { return (l.talent === 'game' || (l.skill || 0) >= 40) && (l.game || l.talent === 'game') ? true : 'Cần chơi game giỏi'; }, ai: function (l) { return l.talent === 'game' ? 0.3 : 0; } });
  SC('cay_them', {
    title: 'Cày thuê kiếm thêm', text: function (l) { var m = boostMonth(l); return 'Hội nhóm game có nhiều người thuê cày ' + boostGame(l) + '. Với trình của bạn nhận được đơn ' + m.tier + ', giá ~' + U.fmtNum(m.price) + ' nghìn đồng/' + m.unit + '. Cày thuê vi phạm điều khoản của nhà phát hành, có thể bị khóa tài khoản, và dễ thức khuya.'; },
    opts: [
      { k: 'he', l: 'Nhận đơn cày trong kỳ nghỉ', h: function (l) { return '~' + mo(l, V(l, boostMonth(l).month * 0.4)) + ' cho một tháng làm nửa ngày'; }, ai: { w: 1 }, run: function (l, r, log) { var x = V(l, boostMonth(l).month * 0.4); if (ch(r, 0.15)) { pay(l, 0.3, 'Bồi thường khách bị khóa nick'); log('Tài khoản khách bị khóa vì đăng nhập bất thường, phải hoàn tiền.', 'bad'); return; } H.cash(l, x, 'Cày thuê kiếm thêm'); l.skill = Math.min(100, (l.skill || 30) + 2); log('Cày thuê trong kỳ nghỉ, kiếm được ' + mo(l, x) + (l.school ? '. Thức khuya nhiều nên đầu năm học hơi đuối.' : '.'), 'good'); if (l.school) fx(l, { kno: -2 }); } },
      { k: 'nghe', l: 'Làm luôn nghề cày thuê', req: function (l) { return l.age >= 18 && !l.school && !(l.job && E.resolveJob(l.job.id) === 'cay_thue'); }, ai: { w: 0.4 }, run: function (l, r, log) { E.startJob(l, 'cay_thue', r, log); } },
      { k: 'khong', l: 'Thôi, chơi game cho vui thôi', ai: { w: 0.8 }, run: function (l, r, log) { log('Chơi game để giải trí, không biến nó thành việc.', 'neutral'); } }
    ]
  });

  // ===================================================================
  // 5. NHIỀU CHUYỆN TUỔI THƠ HƠN
  // ===================================================================
  function KID(id, a0, a1, title, text, opts, when, cw) {
    SC(id, { title: title, text: text, opts: opts.map(function (o) { return { k: o[0], l: o[1], ai: o[2] || { w: 1 }, run: function (l, r, log) { var t = typeof o[3] === 'function' ? o[3](l, r) : o[3]; log(t, o[5] || 'neutral'); if (o[4]) fx(l, o[4]); } }; }) });
    E.TRIG.push({ id: id, when: function (l, a) { return a >= a0 && a <= a1 && free(l) && (!when || when(l, a)); }, p: 0.08, cd: 99, child: true, cw: cw || 1, max: 1 });
  }
  function m(l) { return l.fam.mAlive ? 'mẹ' : l.fam.fAlive && !l.fam.noDad ? 'bố' : 'bà'; }
  function b(l) { return l.fam.fAlive && !l.fam.noDad ? 'bố' : l.fam.mAlive ? 'mẹ' : 'ông'; }
  var school = function (l) { return !!l.school; };
  KID('k_mat_dien', 5, 13, 'Cả xóm mất điện', 'Tối mùa hè, cả xóm mất điện. Trong nhà nóng như lò, ngoài ngõ lũ trẻ í ới gọi nhau.', [
    ['ma', 'Ngồi nghe anh chị kể chuyện ma', { w: 1 }, 'Nghe chuyện ma dưới ánh nến, đêm đó không dám đi vệ sinh một mình.', { hap: 2 }, 'good'],
    ['ngo', 'Chạy ra ngõ chơi trốn tìm', { soc: 1 }, 'Chơi trốn tìm trong bóng tối, vui đến mức mong ngày nào cũng mất điện.', { hap: 4, soc: 2 }, 'good'],
    ['quat', 'Ngồi quạt nan cho ông bà', { w: 0.8 }, function (l) { return 'Ngồi quạt cho ' + (l.fam.sibs ? 'cả nhà' : m(l)) + ', được khen ngoan, được thưởng cốc chè đỗ đen.'; }, { karma: 2 }, 'good']]);
  KID('k_sau_rang', 5, 10, 'Chiếc răng sâu', 'Ăn kẹo nhiều quá, một chiếc răng sâu đau nhức cả đêm.', [
    ['nha_si', 'Đi nha sĩ', { w: 1.2 }, 'Ngồi trên ghế nha sĩ khóc như mưa, nhổ xong được thưởng que kem.', { hea: 2 }, 'neutral'],
    ['tron', 'Trốn, nói dối là hết đau', { w: 0.6 }, 'Giấu được ba ngày thì má sưng vù, bị lôi đi nha sĩ kèm một trận mắng.', { hea: -2, hap: -2 }, 'bad']]);
  KID('k_nuoi_tam', 7, 12, 'Hộp tằm trên bàn học', 'Cô giáo dặn cả lớp quan sát một con vật nhỏ. Bạn xin được mấy con tằm / mấy con cá bảy màu.', [
    ['cham', 'Chăm chỉ cho ăn, ghi nhật ký quan sát', { smart: 1 }, 'Ngày nào cũng ghi chép, bài thuyết trình được cô cho điểm 10.', { kno: 3, hap: 3 }, 'good'],
    ['quen', 'Mấy hôm đầu thì nhớ, sau thì quên', { w: 0.7 }, 'Quên cho ăn, mấy con tằm chết khô. Bạn buồn mất mấy ngày.', { hap: -2 }, 'neutral']], school);
  KID('k_mat_do_ban', 6, 11, 'Làm mất bút của bạn', 'Bạn mượn cây bút máy mới của bạn cùng bàn rồi làm rơi mất.', [
    ['nhan', 'Nhận lỗi, xin tiền tiết kiệm đền', { w: 1.2 }, 'Nhận lỗi và lấy tiền heo đất đền bạn. Hai đứa vẫn chơi thân.', { karma: 3 }, 'good'],
    ['giau', 'Giấu nhẹm, giả vờ không biết', { bad: 1 }, 'Giả vờ không biết. Mấy tuần sau bạn biết chuyện, giận cả học kỳ.', { karma: -3, soc: -3 }, 'bad']], school);
  KID('k_tiem_phong', 3, 6, 'Đi tiêm phòng', 'Đến lịch tiêm phòng, nhìn thấy kim tiêm là bạn muốn bỏ chạy.', [
    ['dung_cam', 'Nhắm mắt, nắm tay mẹ thật chặt', { w: 1 }, function (l) { return 'Nắm chặt tay ' + m(l) + ', tiêm xong mới khóc — được thưởng hộp sữa.'; }, { hea: 1 }, 'good'],
    ['khoc', 'Khóc ầm cả phòng tiêm', { w: 1 }, 'Khóc ầm lên, cô y tá phải dỗ mãi. Ra về được cho kẹo.', null, 'neutral']]);
  KID('k_ve_que_ngoai', 6, 12, 'Mùa hè về quê', 'Hè này được gửi về quê chơi với ông bà cả tháng.', [
    ['bat_ca', 'Theo anh em họ đi bắt cá, trèo cây', { soc: 1 }, 'Một tháng đen nhẻm vì nắng, biết bắt cá, bắt cào cào, leo cây ổi nhà hàng xóm.', { hap: 6, hea: 2 }, 'good'],
    ['nho_nha', 'Nhớ nhà, đòi về sớm', { w: 0.5 }, 'Nhớ nhà quá, khóc đòi về sớm. Về đến nhà lại thấy nhớ những buổi chiều ở quê.', { hap: -1 }, 'neutral']], function (l) { return l.urban; });
  KID('k_ban_hang', 4, 8, 'Chơi bán hàng', 'Bạn bày một "cửa hàng" bằng lá cây, sỏi đá và đồ chơi cũ trước cửa.', [
    ['ban', 'Gọi các bạn trong xóm đến mua', { soc: 1 }, 'Cả buổi chiều mua bán bằng tiền lá cây, bạn "giàu" nhất xóm.', { hap: 4, soc: 2 }, 'good'],
    ['ba', 'Mời ông bà, bố mẹ đến mua', { w: 1 }, 'Cả nhà đóng vai khách, trả tiền bằng kẹo thật.', { hap: 4 }, 'good']]);
  KID('k_xe_dap', 6, 9, 'Tập đi xe đạp', function (l) { return b(l).charAt(0).toUpperCase() + b(l).slice(1) + ' tháo bánh phụ chiếc xe đạp, bảo bạn tập đi hai bánh.'; }, [
    ['tap', 'Tập đến khi đi được', { amb: 1 }, function (l) { return 'Ngã trầy cả hai đầu gối, đến khi quay lại thì ' + b(l) + ' đã buông tay từ lúc nào. Bạn tự đi được rồi!'; }, { hap: 5, hea: 1 }, 'good'],
    ['so', 'Sợ ngã, chưa dám', { w: 0.6 }, 'Sợ ngã, đòi lắp lại bánh phụ thêm một năm.', null, 'neutral']]);
  KID('k_ngu_trua', 5, 9, 'Trốn ngủ trưa', 'Trưa hè nắng chang chang, cả nhà ngủ say, bạn rón rén định trốn ra ngoài chơi.', [
    ['tron', 'Trốn ra bắt ve sầu', { risk: 1 }, function (l, r) { return r() < 0.5 ? 'Bắt được cả lọ ve sầu, về nhà lặng lẽ như chưa có gì.' : 'Vừa mở cổng thì bị ' + m(l) + ' gọi giật lại, phải nằm úp mặt vào tường.'; }, { hap: 2 }, 'neutral'],
    ['ngu', 'Nằm im rồi ngủ quên lúc nào không biết', { w: 1 }, 'Định trốn mà ngủ quên, tỉnh dậy đã chiều.', null, 'neutral']]);
  KID('k_tro_dan_gian', 5, 10, 'Trò chơi dân gian', 'Lũ trẻ trong xóm rủ nhau chơi sau giờ học.', [
    ['rong_ran', 'Rồng rắn lên mây', { soc: 1 }, 'Chơi rồng rắn lên mây đến khi trời tối mịt mới chịu về.', { hap: 4, soc: 2 }, 'good'],
    ['o_an_quan', 'Ô ăn quan, nhảy dây', { w: 1 }, 'Thắng liền ba ván ô ăn quan, oai cả xóm.', { hap: 3, kno: 1 }, 'good'],
    ['tron_tim', 'Trốn tìm', { w: 1 }, 'Trốn kỹ đến mức cả bọn bỏ về hết, bạn ngủ quên trong đống rơm.', { hap: 2 }, 'neutral']], function (l) { return isVN(l); });
  KID('k_truyen_tranh', 8, 13, 'Truyện tranh', 'Cả lớp đang mê bộ truyện tranh Doraemon / Thám tử lừng danh Conan.', [
    ['thue', 'Góp tiền ăn sáng thuê truyện', { w: 1 }, 'Nhịn ăn sáng để thuê truyện, đọc đến mức thuộc lòng từng tập.', { hap: 4, kno: 1 }, 'good'],
    ['len', 'Đọc lén trong giờ học', { risk: 1 }, function (l, r) { return r() < 0.5 ? 'Bị cô giáo tịch thu cả chồng truyện, cuối năm mới trả.' : 'Đọc lén trót lọt cả học kỳ.'; }, { hap: 2 }, 'neutral']], school);
  KID('k_tranh_tivi', 5, 12, 'Giành điều khiển tivi', 'Đúng giờ phim hoạt hình thì anh / chị đòi xem bóng đá.', [
    ['nhuong', 'Nhường', { w: 1 }, 'Nhường anh chị, được trả công bằng gói bim bim.', { karma: 1 }, 'good'],
    ['gianh', 'Giành bằng được', { risk: 1 }, 'Giành nhau đến mức cả hai cùng bị tắt tivi đi ngủ sớm.', { hap: -1 }, 'neutral']], function (l) { return (l.sibList || []).some(function (s) { return s.alive && s.born < 0; }); });
  KID('k_mua_da', 5, 12, 'Trận mưa đá', 'Lần đầu thấy mưa đá, những viên đá trắng rơi lộp bộp trên mái tôn.', [
    ['nhat', 'Chạy ra nhặt đá bỏ vào cốc', { risk: 0.6 }, 'Chạy ra nhặt mưa đá, bị một viên rơi trúng đầu, vẫn cười toe.', { hap: 3 }, 'good'],
    ['nhin', 'Đứng trong nhà nhìn ra', { w: 1 }, 'Đứng nép bên cửa sổ, tròn mắt nhìn trời rơi đá.', { hap: 1 }, 'neutral']]);
  KID('k_bai_van_me', 8, 11, 'Bài văn tả mẹ', 'Bài văn "Tả mẹ của em" của bạn được cô chọn đọc trước lớp.', [
    ['doc', 'Đứng lên đọc', { w: 1 }, 'Đọc đến câu cuối thì cả lớp im phăng phắc, cô giáo rơm rớm nước mắt.', { kno: 2, hap: 4 }, 'good'],
    ['nguong', 'Ngượng, xin cô đọc giúp', { w: 0.7 }, 'Cô đọc giúp, bạn cúi gằm mặt, tai đỏ ửng.', { kno: 1 }, 'neutral']], function (l) { return school(l) && l.fam.mAlive && isVN(l); });
  KID('k_an_co', 5, 12, 'Ăn cỗ đám cưới', 'Hàng xóm làm đám cưới, cả nhà được mời ăn cỗ.', [
    ['an', 'Ngồi mâm trẻ con, ăn hết phần gà', { w: 1 }, 'Ngồi mâm trẻ con tranh nhau từng miếng giò, về còn được gói kẹo cưới.', { hap: 4 }, 'good'],
    ['hat', 'Lên sân khấu hát tặng cô dâu chú rể', { soc: 1.2 }, 'Lên hát một bài, cả rạp vỗ tay, được lì xì phong bao đỏ.', { hap: 5, soc: 3 }, 'good']], function (l) { return isVN(l); });
  KID('k_co_do', 9, 14, 'Sao đỏ ghi tên', 'Sáng nay quên đeo khăn quàng đỏ, đội sao đỏ đứng ngay cổng trường.', [
    ['nhan', 'Thật thà nhận bị ghi tên', { w: 1 }, 'Bị ghi tên, lớp bị trừ điểm thi đua. Từ đó bạn treo khăn quàng ngay đầu giường.', { karma: 1 }, 'neutral'],
    ['muon', 'Chạy đi mượn khăn của em lớp dưới', { risk: 0.8 }, 'Mượn được khăn của em lớp dưới, thoát nạn trong gang tấc.', { hap: 1 }, 'neutral']], function (l) { return isVN(l) && school(l) && l.flags.doi && l.age <= 14; });
  KID('k_cho_duoi', 6, 12, 'Bị chó đuổi', 'Đi học về qua ngõ, con chó nhà hàng xóm sổng xích lao ra.', [
    ['chay', 'Chạy thục mạng', { w: 1 }, 'Chạy một mạch về nhà, rơi mất một chiếc dép.', { hap: -1 }, 'neutral'],
    ['dung', 'Đứng im như bố dặn', { smart: 1 }, 'Đứng im, con chó sủa mấy tiếng rồi bỏ đi. Bạn tự hào cả tuần.', { kno: 1 }, 'good']]);
  KID('k_bau_lop_truong', 8, 14, 'Bầu lớp trưởng', 'Đầu năm học, cô cho cả lớp bầu lớp trưởng. Có bạn đề cử tên bạn.', [
    ['nhan', 'Nhận lời ứng cử', { amb: 1 }, function (l, r) { return r() < 0.5 ? 'Trúng cử lớp trưởng với đa số phiếu, oai lắm!' : 'Thua sít sao, được làm lớp phó học tập.'; }, { soc: 3 }, 'good'],
    ['tu_choi', 'Từ chối, ngại lắm', { w: 0.7 }, 'Từ chối vì ngại đứng trước lớp.', null, 'neutral']], school);
  KID('k_sach_cu', 6, 14, 'Sách cũ đầu năm học', 'Đầu năm học, nhà không đủ tiền mua sách mới.', [
    ['cu', 'Dùng sách cũ của anh chị, bọc lại thật đẹp', { w: 1 }, 'Bọc sách cũ bằng giấy báo, dán nhãn nắn nót, trông chẳng kém sách mới.', { karma: 1 }, 'neutral'],
    ['xin', 'Đăng ký mượn sách ở thư viện trường', { smart: 1 }, 'Mượn sách thư viện, từ đó mê luôn góc đọc sách của trường.', { kno: 2 }, 'good']], function (l) { return school(l) && l.fam.q <= 2; });
  KID('k_ban_chuyen_truong', 8, 14, 'Bạn thân chuyển trường', 'Bạn thân nhất báo sắp theo bố mẹ chuyển vào Nam / ra Bắc.', [
    ['thu', 'Hứa viết thư, nhắn tin mỗi tuần', { soc: 1 }, 'Hai đứa nhắn tin đều đặn, mấy năm sau vẫn giữ liên lạc.', { soc: 2 }, 'good'],
    ['khoc', 'Khóc cả buổi chia tay', { w: 1 }, 'Ôm nhau khóc ở cổng trường. Từ đó lớp học bỗng rộng thênh thang.', { hap: -4 }, 'neutral']], function (l) { return !!(l.bff && l.bff.alive) && school(l); });
  KID('k_trong_em', 8, 14, 'Trông em giúp mẹ', function (l) { return m(l).charAt(0).toUpperCase() + m(l).slice(1) + ' bận việc, nhờ bạn trông em cả buổi chiều.'; }, [
    ['trong', 'Trông em cẩn thận', { w: 1.2 }, 'Dỗ em ngủ, cho em ăn, chơi cùng em cả buổi. Được khen như người lớn.', { karma: 2, soc: 1 }, 'good'],
    ['choi', 'Để em tự chơi, mình xem điện thoại', { w: 0.6 }, 'Mải xem điện thoại, em ngã u đầu. Bị mắng một trận nhớ đời.', { hap: -3 }, 'bad']], function (l) { return (l.sibList || []).some(function (s) { return s.alive && s.born > 0 && l.age - s.born <= 5 && l.age - s.born >= 1; }); });
  KID('k_thich_mon', 12, 14, 'Thầy cô tâm huyết', 'Năm nay có thầy / cô dạy môn mới rất truyền cảm hứng.', [
    ['hoc', 'Chăm học môn đó hơn hẳn', { smart: 1 }, 'Từ ghét môn học thành mê, cuối năm được điểm cao nhất lớp môn đó.', { kno: 4, hap: 2 }, 'good'],
    ['thuong', 'Học bình thường', { w: 0.8 }, 'Học bình thường, nhưng nhớ mãi những câu chuyện thầy cô kể.', { kno: 1 }, 'neutral']], school);
  KID('k_ong_ba_ke', 5, 10, 'Ông bà kể chuyện ngày xưa', 'Tối nào ông bà cũng kể chuyện ngày xưa: chiến tranh, đói kém, những ngày đi sơ tán.', [
    ['nghe', 'Ngồi nghe say sưa', { w: 1.2 }, 'Nghe ông bà kể chuyện đến khuya, thương ông bà hơn.', { kno: 2, soc: 2 }, 'good'],
    ['ngu', 'Nghe được một lúc thì ngủ', { w: 0.8 }, 'Lần nào cũng ngủ ở đoạn hay nhất.', null, 'neutral']], function (l) { return isVN(l); });
  KID('k_om_chao', 4, 10, 'Ốm được nằm nhà', 'Bị sốt phải nghỉ học, được nằm nhà.', [
    ['chao', 'Được nấu cháo hành, đắp chăn', { w: 1 }, function (l) { return m(l).charAt(0).toUpperCase() + m(l).slice(1) + ' nấu bát cháo hành nóng hổi, ngồi bên cạnh cả buổi. Vị cháo ấy bạn nhớ mãi.'; }, { hea: 1, hap: 2 }, 'good']]);
  KID('k_nhom_hoc', 11, 14, 'Nhóm học tập', 'Mấy bạn rủ lập nhóm học cuối tuần ở nhà một bạn.', [
    ['hoc', 'Học thật', { smart: 1 }, 'Cả nhóm học chăm, kỳ thi cùng nhau lên điểm.', { kno: 3, soc: 2 }, 'good'],
    ['choi', '"Học nhóm" nhưng chủ yếu là chơi', { soc: 1 }, '"Học nhóm" mà cả buổi chơi game và ăn vặt.', { hap: 3, soc: 2 }, 'neutral']], school);
  KID('k_ngoai_khoa', 7, 12, 'Lớp ngoại khóa', 'Trường mở các lớp ngoại khóa: đàn, vẽ, võ, cờ vua.', [
    ['dan', 'Học đàn organ', { w: 1 }, 'Học đàn, cuối năm biểu diễn một bài trong lễ tổng kết.', { kno: 2, hap: 3 }, 'good'],
    ['vo', 'Học võ', { w: 1 }, 'Học võ, khỏe hẳn ra, không còn sợ bị bắt nạt.', { hea: 3 }, 'good'],
    ['co', 'Học cờ vua', { smart: 1 }, 'Học cờ vua, thắng được cả bố.', { kno: 3 }, 'good']], function (l) { return school(l) && l.fam.q >= 3; });
  KID('k_cam_trai', 12, 14, 'Cắm trại của trường', 'Trường tổ chức cắm trại ba ngày hai đêm.', [
    ['di', 'Đi cắm trại', { soc: 1 }, 'Dựng lều, đốt lửa trại, hát đến khuya. Đêm cuối cả lớp ôm nhau khóc vì sắp lên cấp ba.', { hap: 6, soc: 4 }, 'good'],
    ['o_nha', 'Ở nhà vì sợ muỗi', { w: 0.5 }, 'Ở nhà, xem ảnh các bạn đăng mà tiếc hùi hụi.', { hap: -2 }, 'neutral']], school);
  KID('k_bong_da_dem', 6, 14, 'Xem bóng đá đêm khuya', 'Đội tuyển đá trận chung kết lúc nửa đêm.', [
    ['thuc', function (l) { return 'Thức xem cùng ' + b(l); }, { w: 1 }, function (l, r) { return r() < 0.5 ? 'Đội tuyển thắng! Cả xóm đổ ra đường đi bão, bạn ngồi sau xe ' + b(l) + ' cầm cờ đỏ sao vàng.' : 'Đội tuyển thua, ' + b(l) + ' thở dài, bạn ngủ gục trên ghế.'; }, { hap: 4 }, 'good'],
    ['ngu', 'Đi ngủ sớm', { w: 0.6 }, 'Ngủ sớm, sáng ra nghe cả xóm kể lại.', null, 'neutral']], function (l) { return isVN(l) && (l.fam.fAlive || l.fam.mAlive); });
  KID('k_mon_qua_co', 7, 11, 'Ngày Nhà giáo Việt Nam', 'Ngày 20/11, cả lớp chuẩn bị quà tặng cô giáo chủ nhiệm.', [
    ['thiep', 'Tự làm thiệp tặng cô', { w: 1.2 }, 'Tự vẽ tấm thiệp tặng cô, cô giữ trên bàn làm việc cả năm.', { hap: 3, karma: 1 }, 'good'],
    ['hoa', 'Xin tiền mua hoa', { w: 1 }, 'Mua bó hoa tặng cô, đứng lắp bắp mãi mới nói được câu chúc.', { hap: 2 }, 'good']], function (l) { return isVN(l) && school(l); });

  KID('k_rung_rang', 5, 7, 'Chiếc răng sữa đầu tiên', 'Chiếc răng cửa lung lay mấy hôm, sáng nay ăn cơm thì rơi ra.', [
    ['nem', 'Ném lên mái nhà như bà dặn', { w: 1.2 }, 'Ném răng lên mái nhà, ước răng mới mọc nhanh và đều như răng chuột.', { hap: 3 }, 'good'],
    ['giu', 'Cất vào hộp làm kỷ niệm', { w: 0.8 }, 'Cất chiếc răng vào hộp diêm, cười móm mém khoe cả xóm.', { hap: 2 }, 'neutral']], function (l) { return isVN(l); });
  KID('k_hoc_boi', 6, 11, 'Học bơi mùa hè', 'Mùa hè này được cho đi học bơi.', [
    ['hoc', 'Chăm chỉ tập', { w: 1.2 }, 'Uống no nước mấy buổi đầu, đến cuối khóa đã bơi được 25 mét. Biết bơi — kỹ năng giữ mạng cả đời.', { hea: 3, hap: 3 }, 'good'],
    ['so', 'Sợ nước, khóc không chịu xuống', { w: 0.5 }, 'Sợ nước, cả khóa chỉ dám đứng ở chỗ nông.', null, 'neutral']], function (l) { return l.urban || l.fam.q >= 3; });
  KID('k_tham_quan', 7, 12, 'Chuyến tham quan của lớp', 'Lớp tổ chức đi tham quan vườn thú / bảo tàng / khu di tích.', [
    ['di', 'Đi cùng cả lớp', { soc: 1 }, 'Lần đầu thấy con voi thật, về kể cả tuần không hết chuyện. Say xe cả lượt đi.', { hap: 5, kno: 2, soc: 2 }, 'good'],
    ['o_nha', 'Ở nhà vì nhà không có tiền đóng', { w: 0.4 }, 'Không được đi, ngồi nghe các bạn kể mà chạnh lòng.', { hap: -3 }, 'neutral']], school);
  KID('k_ke_hoach_nho', 7, 12, 'Kế hoạch nhỏ', 'Liên đội phát động phong trào "Kế hoạch nhỏ" thu gom giấy vụn.', [
    ['gom', 'Đi gom giấy báo cũ khắp xóm', { amb: 1 }, 'Gom được cả bao tải giấy vụn, lớp bạn đứng nhất trường.', { karma: 2, soc: 2 }, 'good'],
    ['vo', 'Lấy luôn sách vở cũ của anh chị nộp', { risk: 0.6 }, 'Lấy nhầm cả quyển vở anh chị đang dùng, bị mắng một trận.', null, 'neutral']], function (l) { return isVN(l) && school(l); });
  KID('k_nhat_ky', 10, 14, 'Cuốn nhật ký có khóa', 'Bạn bắt đầu viết nhật ký vào một cuốn sổ có ổ khóa nhỏ.', [
    ['viet', 'Viết đều mỗi tối', { w: 1 }, 'Viết nhật ký mỗi tối, kể đủ chuyện trường lớp, bạn bè, cả những điều chưa dám nói với ai.', { hap: 2, kno: 1 }, 'good'],
    ['bi_doc', 'Giấu dưới gối', { w: 0.8 }, function (l) { return 'Một hôm thấy ổ khóa bị cạy — hóa ra ' + ((l.sibList || []).some(function (s) { return s.alive; }) ? 'anh chị em' : m(l)) + ' đọc trộm. Giận cả tuần.'; }, { hap: -2 }, 'neutral']]);
  KID('k_ga_con', 5, 10, 'Đàn gà con', 'Ông bà mua cho đàn gà con lông vàng.', [
    ['cham', 'Ngày nào cũng cho gà ăn', { w: 1 }, 'Chăm đàn gà lớn phổng phao, Tết đến được ông bà cho một con mang ra chợ bán lấy tiền mua truyện.', { karma: 1, hap: 3 }, 'good'],
    ['nhot', 'Nhốt gà vào hộp mang đi chơi', { risk: 0.8 }, 'Mang gà con đi khoe cả xóm, về thì mất một con. Khóc cả chiều.', { hap: -2 }, 'neutral']], function (l) { return !l.urban; });

  // giảm tần suất những chuyện tuổi thơ quen thuộc nhất để mỗi đời mỗi khác
  E.TRIG.forEach(function (t) { if (/^(sinh_nhat|li_xi|thu_cung|choi_le_hoi|trung_thu|vo_binh|he_nay|do_choi)$/.test(t.id) && t.child) t.cw = typeof t.cw === 'function' ? (function (f) { return function (l, a) { return f(l, a) * 0.5; }; })(t.cw) : (t.cw || 1) * 0.5; });
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
/* ===== js/life35.js ===== */
/* Một Đời — v3.5:
   · con đường năng khiếu → trường chuyên ngành → nghề: có năng khiếu thì được gợi ý trường và nghề phù hợp (VD năng khiếu ca hát:
     Học viện Âm nhạc Quốc gia Việt Nam, Nhạc viện TP. HCM, ĐH Sư phạm Nghệ thuật Trung ương, ĐH Văn hóa Nghệ thuật Quân đội, CĐ Nghệ thuật Hà Nội);
     theo năng khiếu hay chọn hướng khác đều được, nhưng luôn có đề xuất. Thi năng khiếu đỗ hay trượt tùy trình độ và sự chuẩn bị.
   · sự kiện theo bối cảnh từng ngành: ca hát (mua bài hát, tự sáng tác, thi truyền hình, clip lan truyền, bản quyền, giữ giọng), mỹ thuật,
     sân khấu – điện ảnh, thể thao, ngoại ngữ, kỹ thuật, và các nghề trước đây ít sự kiện.
   Mọi nhân vật, tình huống đều hư cấu, không ám chỉ cá nhân hay tổ chức nào. */
(function (G) {
  'use strict';
  var U = G.U, E = G.E, H = E.H, SC = E.SC, isVN = H.isVN;
  function fx(l, o) { H.fx(l, o); }
  function mo(l, v) { return H.money(l, v); }
  function pick(r, a) { return U.pick(r, a); }
  function ch(r, p) { return r() < p; }
  function free(l) { return !(l.jailUntil != null && l.age < l.jailUntil) && !(l.abroad && l.abroad.trapped) && !(l.flags.military && l.age < l.flags.military); }
  function vnd(l) { return isVN(l) && l.cur === 'vnd' && !(l.abroad && l.abroad.perm); }
  function V(l, tr) { return vnd(l) ? tr : tr / 90 * l.base; }
  function pay(l, tr, why) { var x = Math.min(V(l, tr), Math.max(0, l.money) + l.base * 0.5); H.cash(l, -x, why); return x; }
  function earn(l, tr, why) { var x = V(l, tr); H.cash(l, x, why); return x; }
  function jid(l) { return l.job ? E.resolveJob(l.job.id) : ''; }
  function rk(l) { return l.job ? l.job.rank || 0 : 0; }
  function rep(l, d) { if (l.job) l.job.rep = U.clamp((l.job.rep || 50) + d, 0, 100); }
  function stress(l, d) { if (l.mind) l.mind.stress = U.clamp(l.mind.stress + d, 0, 100); }
  function promote(l) { var c = l.job ? E.jobDef(l) : null; if (c && l.job.rank < c.t.length - 1 && (!E.canAdvance || E.canAdvance(l, c, false))) { l.job.rank++; l.job.yrs = 0; l.job.rankSince = l.age; l.job.rankTracked = l.job.rank; return true; } return false; }
  function sk(l) { return l.skill || 20; }
  function cap(s) { return U.cap(s); }

  // ===================================================================
  // 1. NGHỀ MỚI
  // ===================================================================
  function addJob(id, t, vn, yrs, o) {
    E.CAR[id] = { id: id, t: t, vn: vn, yrs: yrs, cat: o.cat || 'other', sec: o.sec || 'inf', edu: o.edu || 0, major: o.major, majors: o.majors, soft: o.soft,
      talent: o.talent, sex: o.sex, haz: o.haz, crime: o.crime, fame: o.fame, sigma: o.sigma || 0.12, fail: o.fail || 0, hidden: o.hidden, w: o.w || 1,
      rural: o.rural, coast: o.coast, vnOnly: o.vn, ladder: o.ladder, skillRank: o.skillRank, maxAge: o.maxAge, prod: o.prod, promo: o.promo, loss: o.loss, tag: o.tag };
  }
  addJob('hoa_si', ['họa sĩ tự do (vẽ tranh theo đơn)', 'họa sĩ có tranh triển lãm', 'họa sĩ có tên tuổi'], [7, 18, 60], [4, 8], { cat: 'free', sec: 'inf', edu: 0, talent: 'hội họa', sigma: 0.5, w: 0.6 });
  addJob('van_cong', ['diễn viên đoàn văn công quân đội', 'diễn viên chính đoàn văn công', 'trưởng đoàn văn công'], [9, 14, 22], [5, 10], { cat: 'uniform', sec: 'formal', edu: 4, hidden: 1, vn: 1 });

  // ===================================================================
  // 2. NĂNG KHIẾU → TRƯỜNG CHUYÊN NGÀNH → NGHỀ
  // ===================================================================
  // trường: [mã, tên, thành phố, ngành (khóa MAJORS), tên ngành, độ khó 0–1, 'uni' | 'cd', các nghề sau khi ra trường, nội dung thi năng khiếu]
  var HN = 'Hà Nội', SG = 'TP. Hồ Chí Minh';
  var TS = {
    'âm nhạc': { sug: 'ca sĩ, nhạc sĩ – producer, giáo viên âm nhạc, diễn viên đoàn văn công', sch: [
      ['hvan', 'Học viện Âm nhạc Quốc gia Việt Nam', HN, 'art', 'Thanh nhạc', 0.62, 'uni', ['ca_si', 'nhac_si', 'giang_vien'], 'thi thanh nhạc, xướng âm – thẩm âm và kiến thức âm nhạc'],
      ['nvhcm', 'Nhạc viện TP. Hồ Chí Minh', SG, 'art', 'Thanh nhạc', 0.58, 'uni', ['ca_si', 'nhac_si'], 'thi thanh nhạc, xướng âm – thẩm âm và kiến thức âm nhạc'],
      ['spnt', 'Trường Đại học Sư phạm Nghệ thuật Trung ương', HN, 'edu', 'Sư phạm Âm nhạc', 0.4, 'uni', ['giao_vien', 'ca_si', 'nhac_si'], 'thi hát, thẩm âm – tiết tấu'],
      ['vhntqd', 'Trường Đại học Văn hóa Nghệ thuật Quân đội', HN, 'art', 'Thanh nhạc', 0.5, 'uni', ['van_cong', 'ca_si'], 'thi năng khiếu và khám sức khỏe theo tiêu chuẩn quân đội'],
      ['cdnt', 'Trường Cao đẳng Nghệ thuật Hà Nội', HN, null, 'Thanh nhạc', 0.3, 'cd', ['ca_si', 'nhac_si', 'dj'], 'thi hát và thẩm âm']] },
    'hội họa': { sug: 'họa sĩ, thiết kế đồ họa, kiến trúc sư, nhà thiết kế thời trang, giáo viên mỹ thuật', sch: [
      ['mtvn', 'Trường Đại học Mỹ thuật Việt Nam', HN, 'art', 'Hội họa', 0.55, 'uni', ['hoa_si', 'thiet_ke'], 'thi vẽ hình họa (tượng) và bố cục màu'],
      ['mthcm', 'Trường Đại học Mỹ thuật TP. Hồ Chí Minh', SG, 'art', 'Hội họa', 0.52, 'uni', ['hoa_si', 'thiet_ke'], 'thi vẽ hình họa và bố cục màu'],
      ['mtcn', 'Trường Đại học Mỹ thuật Công nghiệp', HN, 'art', 'Thiết kế đồ họa', 0.5, 'uni', ['thiet_ke', 'tk_thoi_trang', 'fl_thiet_ke'], 'thi hình họa và trang trí màu'],
      ['kthn', 'Trường Đại học Kiến trúc Hà Nội', HN, 'art', 'Kiến trúc', 0.56, 'uni', ['kien_truc', 'thiet_ke'], 'thi toán, vật lý và vẽ mỹ thuật (khối V)'],
      ['spnt_mt', 'Trường Đại học Sư phạm Nghệ thuật Trung ương', HN, 'edu', 'Sư phạm Mỹ thuật', 0.38, 'uni', ['giao_vien', 'hoa_si'], 'thi vẽ hình họa và trang trí']] },
    'diễn xuất': { sug: 'diễn viên điện ảnh – truyền hình, đạo diễn, biên kịch, MC, diễn viên đoàn văn công', sch: [
      ['skda', 'Trường Đại học Sân khấu – Điện ảnh Hà Nội', HN, 'art', 'Diễn viên kịch – điện ảnh', 0.6, 'uni', ['dien_vien', 'mc_tv', 'dao_dien'], 'thi diễn tiểu phẩm, hát, múa, đọc thơ và kiểm tra hình thể'],
      ['skdahcm', 'Trường Đại học Sân khấu – Điện ảnh TP. Hồ Chí Minh', SG, 'art', 'Diễn viên kịch – điện ảnh', 0.56, 'uni', ['dien_vien', 'mc_tv'], 'thi diễn tiểu phẩm, hát, múa và kiểm tra hình thể'],
      ['skda_dd', 'Trường Đại học Sân khấu – Điện ảnh Hà Nội', HN, 'art', 'Đạo diễn – Biên kịch', 0.58, 'uni', ['dao_dien', 'bien_kich'], 'thi viết kịch bản ngắn và phỏng vấn chuyên môn'],
      ['vhntqd_dv', 'Trường Đại học Văn hóa Nghệ thuật Quân đội', HN, 'art', 'Diễn viên sân khấu', 0.48, 'uni', ['van_cong', 'dien_vien'], 'thi diễn xuất và khám sức khỏe theo tiêu chuẩn quân đội']] },
    'thể thao': { sug: 'vận động viên, huấn luyện viên, giáo viên thể dục, huấn luyện viên cá nhân (PT)', sch: [
      ['tdttbn', 'Trường Đại học Thể dục Thể thao Bắc Ninh', 'Bắc Ninh', 'edu', 'Huấn luyện thể thao', 0.4, 'uni', ['hlv_tt', 'giao_vien', 'pt_gym'], 'thi năng khiếu thể thao: bật xa, chạy, môn sở trường'],
      ['tdtthcm', 'Trường Đại học Thể dục Thể thao TP. Hồ Chí Minh', SG, 'edu', 'Huấn luyện thể thao', 0.4, 'uni', ['hlv_tt', 'giao_vien', 'pt_gym'], 'thi năng khiếu thể thao: bật xa, chạy, môn sở trường'],
      ['sptdtt', 'Trường Đại học Sư phạm Thể dục Thể thao Hà Nội', HN, 'edu', 'Giáo dục thể chất', 0.32, 'uni', ['giao_vien', 'pt_gym', 'hlv_tt'], 'thi năng khiếu thể thao']] },
    'ngoại ngữ': { sug: 'biên – phiên dịch, ngoại giao, hướng dẫn viên du lịch, tiếp viên hàng không, giáo viên ngoại ngữ', sch: [
      ['ulis', 'Trường Đại học Ngoại ngữ – ĐHQG Hà Nội', HN, 'edu', 'Ngôn ngữ Anh', 0.55, 'uni', ['fl_dich', 'giao_vien', 'hdv', 'tiep_vien'], 'xét tổ hợp có môn tiếng Anh nhân hệ số 2'],
      ['hanu', 'Trường Đại học Hà Nội', HN, 'eco', 'Ngôn ngữ & Kinh doanh quốc tế', 0.55, 'uni', ['fl_dich', 'marketing', 'logistics', 'tiep_vien'], 'xét tổ hợp có môn ngoại ngữ nhân hệ số 2'],
      ['hvng', 'Học viện Ngoại giao', HN, 'law', 'Quan hệ quốc tế', 0.68, 'uni', ['ngoai_giao', 'fl_dich', 'phong_vien'], 'xét điểm thi kết hợp chứng chỉ ngoại ngữ quốc tế'],
      ['xhnvhcm', 'Trường Đại học Khoa học Xã hội và Nhân văn TP. HCM', SG, 'edu', 'Ngôn ngữ Anh', 0.5, 'uni', ['fl_dich', 'giao_vien', 'hdv'], 'xét tổ hợp có môn tiếng Anh']] },
    'toán học': { sug: 'lập trình viên, phân tích dữ liệu, kỹ sư, nhà nghiên cứu, giáo viên toán', sch: [
      ['bk', 'Đại học Bách khoa Hà Nội', HN, 'it', 'Khoa học máy tính', 0.66, 'uni', ['dev', 'data', 'ky_su'], 'xét điểm thi toán – lý – hóa hoặc bài thi đánh giá tư duy'],
      ['khtn', 'Trường Đại học Khoa học Tự nhiên – ĐHQG TP. HCM', SG, 'it', 'Toán – Tin học', 0.56, 'uni', ['dev', 'data', 'nghien_cuu'], 'xét điểm thi khối A'],
      ['uet', 'Trường Đại học Công nghệ – ĐHQG Hà Nội', HN, 'it', 'Công nghệ thông tin', 0.62, 'uni', ['dev', 'data', 'ky_su'], 'xét điểm thi khối A, A1'],
      ['sphn', 'Trường Đại học Sư phạm Hà Nội', HN, 'edu', 'Sư phạm Toán', 0.48, 'uni', ['giao_vien', 'gia_su'], 'xét điểm thi khối A']] },
    'ăn nói': { sug: 'phóng viên – biên tập viên, MC, luật sư, truyền thông – marketing', sch: [
      ['ajc', 'Học viện Báo chí và Tuyên truyền', HN, 'law', 'Báo chí', 0.55, 'uni', ['phong_vien', 'mc_tv', 'marketing'], 'xét điểm thi khối C, D'],
      ['xhnv', 'Trường Đại học Khoa học Xã hội và Nhân văn – ĐHQG Hà Nội', HN, 'law', 'Báo chí – Truyền thông', 0.56, 'uni', ['phong_vien', 'mc_tv', 'fl_content'], 'xét điểm thi khối C, D'],
      ['luathn', 'Trường Đại học Luật Hà Nội', HN, 'law', 'Luật', 0.58, 'uni', ['luat_su', 'cong_chung', 'tham_phan'], 'xét điểm thi khối A, C, D'],
      ['luathcm', 'Trường Đại học Luật TP. Hồ Chí Minh', SG, 'law', 'Luật', 0.56, 'uni', ['luat_su', 'cong_chung', 'kiem_sat'], 'xét điểm thi khối A, C, D']] },
    'khéo tay': { sug: 'kỹ sư cơ điện, kỹ thuật viên, thợ điện – cơ khí lành nghề', sch: [
      ['bk_ck', 'Đại học Bách khoa Hà Nội', HN, 'it', 'Kỹ thuật cơ điện tử', 0.6, 'uni', ['ky_su_co_dien', 'ky_su', 'ky_thuat_vien'], 'xét điểm thi toán – lý – hóa'],
      ['spkt', 'Trường Đại học Sư phạm Kỹ thuật TP. Hồ Chí Minh', SG, 'it', 'Công nghệ kỹ thuật cơ khí', 0.45, 'uni', ['ky_su_co_dien', 'ky_thuat_vien'], 'xét điểm thi khối A'],
      ['cdn', 'Trường cao đẳng nghề (điện – cơ khí)', null, null, 'Điện công nghiệp', 0.12, 'cd', ['tho_dien', 'ky_thuat_vien', 'tho_han'], 'xét học bạ']] },
    'kinh doanh': { sug: 'marketing, kinh doanh – bán hàng, ngân hàng, xuất nhập khẩu, tự khởi nghiệp', sch: [
      ['neu', 'Trường Đại học Kinh tế Quốc dân', HN, 'eco', 'Quản trị kinh doanh', 0.6, 'uni', ['marketing', 'sale_b2b', 'ngan_hang'], 'xét điểm thi khối A, A1, D'],
      ['ftu', 'Trường Đại học Ngoại thương', HN, 'eco', 'Kinh tế đối ngoại', 0.68, 'uni', ['logistics', 'marketing', 'ngan_hang'], 'xét điểm thi khối A, A1, D'],
      ['ueh', 'Trường Đại học Kinh tế TP. Hồ Chí Minh', SG, 'eco', 'Kinh doanh quốc tế', 0.6, 'uni', ['marketing', 'logistics', 'sale_b2b'], 'xét điểm thi khối A, A1, D']] },
    'làm đẹp': { sug: 'chuyên viên trang điểm, thiết kế thời trang, stylist, kỹ thuật viên spa, mở tiệm làm đẹp', sch: [
      ['mtcn_tt', 'Trường Đại học Mỹ thuật Công nghiệp', HN, 'art', 'Thiết kế thời trang', 0.5, 'uni', ['tk_thoi_trang', 'stylist', 'makeup'], 'thi hình họa và trang trí màu'],
      ['cd_sd', 'Trường cao đẳng nghề — ngành chăm sóc sắc đẹp', null, null, 'Chăm sóc sắc đẹp', 0.12, 'cd', ['makeup', 'spa', 'nail', 'tho_toc'], 'xét học bạ']] },
    'game': { sug: 'tuyển thủ esports, streamer, lập trình – thiết kế game, cày thuê rank', sch: [
      ['fpt', 'Trường Đại học FPT', HN, 'it', 'Thiết kế mỹ thuật số (game)', 0.38, 'uni', ['dev', 'thiet_ke', 'streamer'], 'xét học bạ và phỏng vấn']] },
    'cờ': { sug: 'kỳ thủ chuyên nghiệp, huấn luyện viên cờ, giáo viên toán', sch: [] }
  };
  E.TALENT_SCHOOLS = TS;
  function tsOf(l) { return isVN(l) ? TS[l.talent] || null : null; }
  function north(l) { var o = (l.prov && l.prov.old) || ''; return l.region === 'MNPB' || l.region === 'DBSH' || /Thanh Hóa|Nghệ An|Hà Tĩnh/.test(o); }
  function homeCity(l) { var o = (l.prov && l.prov.old) || ''; return /Hà Nội/.test(o) ? HN : /Hồ Chí Minh/.test(o) ? SG : /Bắc Ninh/.test(o) ? 'Bắc Ninh' : ''; }
  function admitP(l, s) {
    var p = 0.3 + (sk(l) - 100 * s[5]) / 35 + (l.st.kno - 55) / 160 + (l.flags.tPrep || 0) * 0.14 + (l.examScore != null ? (l.examScore - 21) / 45 : 0);
    if (/vhntqd/.test(s[0]) && l.st.hea < 55) p -= 0.3;
    return U.clamp(p, 0.04, 0.95);
  }
  // gợi ý 3 trường hợp nhất: gần nhà trước, vừa sức trước
  function schoolsFor(l) {
    var T = tsOf(l); if (!T) return [];
    var nth = north(l);
    return T.sch.slice().sort(function (a, b) { var f = function (s) { return (s[2] == null ? 0 : (s[2] === SG) === !nth ? 0 : 0.25) + Math.abs(s[5] * 100 - sk(l)) / 200; }; return f(a) - f(b); }).slice(0, 3);
  }
  E.talentSchoolsFor = schoolsFor;
  function jobNames(ids) { return ids.slice(0, 3).map(function (id) { return E.CAR[id] ? E.jobLabel(id).replace(/ \(.*\)$/, '') : id; }).join(', '); }
  function pctTxt(p) { return p >= 0.75 ? 'khả năng đỗ cao' : p >= 0.45 ? 'khả năng đỗ trung bình' : p >= 0.2 ? 'khó đỗ' : 'rất khó đỗ'; }

  // 2a. định hướng ở tuổi 15–17: gợi ý trường, nghề theo năng khiếu; theo hay không là quyền của bạn
  SC('nk_dinh_huong', {
    title: 'Định hướng nghề nghiệp',
    valid: function (l) { return !!tsOf(l) && !l.flags.tDinhHuong; },
    text: function (l) {
      var T = tsOf(l), S = schoolsFor(l);
      return 'Lên cấp ba, thầy cô chủ nhiệm và bố mẹ bàn chuyện chọn hướng đi. Với năng khiếu ' + E.talentText(l) + ' (trình độ: ' + (E.talentLevel ? E.talentLevel(l).name : 'khá') + '), bạn có thể theo: ' + T.sug + '.' +
        (S.length ? ' Các trường gợi ý: ' + S.map(function (s) { return s[1] + ' (ngành ' + s[4] + ')'; }).join('; ') + '.' : ' Ngành này không cần trường chuyên — chủ yếu là luyện tập và thi đấu.') + ' Bạn cũng có thể chọn một hướng khác.';
    },
    opts: [
      { k: 'luyen', l: function (l) { return tsOf(l).sch.length ? 'Theo năng khiếu: đi luyện thi năng khiếu từ bây giờ' : 'Theo năng khiếu: luyện tập, thi đấu nghiêm túc'; }, h: function (l) { return 'Khoảng ' + mo(l, V(l, 15)) + ' tiền học thêm mỗi năm · ít thời gian cho các môn văn hóa'; }, ai: { w: 1.2, amb: 0.8 },
        run: function (l, r, log) { l.flags.tDinhHuong = 'luyen'; l.flags.tPrep = 1; l.skill = Math.min(100, sk(l) + 6); if (l.indep) pay(l, 15, 'Luyện thi năng khiếu'); else log('Bố mẹ đóng tiền cho bạn học thêm năng khiếu.', 'neutral'); log('Quyết định theo năng khiếu ' + E.talentText(l) + ': tối nào cũng luyện tập, cuối tuần đi học thầy.', 'good'); fx(l, { hap: 2, kno: -1 }); } },
      { k: 'ca_hai', l: 'Học văn hóa là chính, vẫn giữ năng khiếu để mở cả hai đường', ai: { w: 1, smart: 0.6 },
        run: function (l, r, log) { l.flags.tDinhHuong = 'ca_hai'; l.flags.tPrep = 0.5; l.skill = Math.min(100, sk(l) + 3); log('Vừa học văn hóa vừa giữ năng khiếu — mệt hơn nhưng không phải bỏ đường nào.', 'neutral'); fx(l, { kno: 2 }); stress(l, 4); } },
      { k: 'khac', l: 'Chọn hướng khác, coi năng khiếu là sở thích', ai: { w: 0.7 },
        run: function (l, r, log) { l.flags.tDinhHuong = 'khac'; log('Chọn tập trung vào các môn thi đại học thông thường, năng khiếu để dành làm niềm vui.', 'neutral'); fx(l, { kno: 3 }); } }
    ]
  });
  E.TRIG.push({ id: 'nk_dinh_huong', when: function (l, a) { return a >= 15 && a <= 17 && !!tsOf(l) && /upper|priv/.test(l.school || '') && !l.flags.tDinhHuong && free(l); }, p: 0.55, cd: 1, max: 1 });

  // 2b. ngã rẽ 18 tuổi: thêm lựa chọn thi năng khiếu vào trường chuyên ngành
  var UNI = E.DEC.uni, um0 = UNI.make, ua0 = UNI.auto, up0 = UNI.apply;
  UNI.make = function (l, r) {
    var d = um0.apply(this, arguments), S = schoolsFor(l);
    if (!S.length) return d;
    d.data.ts = S.map(function (s) { return s[0]; });
    var add = S.map(function (s) { var p = admitP(l, s); return { k: 'nk_' + s[0], l: (s[6] === 'cd' ? 'Học ' : 'Thi năng khiếu vào ') + s[1] + ' — ngành ' + s[4], h: (s[6] === 'cd' ? '2 năm · ' : '4 năm · ') + s[8] + ' · ' + pctTxt(p) + ' · ra trường có thể làm: ' + jobNames(s[7]) }; });
    var i = d.opts.findIndex(function (o) { return o.k === 'police'; }); if (i < 0) i = d.opts.findIndex(function (o) { return o.k === 'voc'; });
    Array.prototype.splice.apply(d.opts, [i < 0 ? d.opts.length : i, 0].concat(add));
    d.text += ' Thầy cô gợi ý: với năng khiếu ' + E.talentText(l) + ', bạn có thể thi vào trường chuyên ngành' + (l.flags.tDinhHuong === 'khac' ? ' — dù trước đây bạn đã chọn hướng khác, cánh cửa vẫn mở.' : '.');
    return d;
  };
  UNI.auto = function (l, d, r) {
    var k = ua0.apply(this, arguments), ts = (d.data && d.data.ts) || [];
    if (!ts.length || /^(military|xkld|abroad)$/.test(k)) return k;
    var want = 0.15 + (l.flags.tPrep || 0) * 0.45 + (sk(l) - 50) / 150 - (l.flags.tDinhHuong === 'khac' ? 0.2 : 0);
    if (!ch(r, U.clamp(want, 0, 0.9))) return k;
    var best = ts.map(function (id) { return sch(id); }).sort(function (a, b) { return admitP(l, b) - admitP(l, a); })[0];
    return 'nk_' + best[0];
  };
  function sch(id) { for (var t in TS) for (var i = 0; i < TS[t].sch.length; i++) if (TS[t].sch[i][0] === id) return TS[t].sch[i]; return null; }
  UNI.apply = function (l, d, k, r, log) {
    if (!/^nk_/.test(k)) return up0.apply(this, arguments);
    var s = sch(k.slice(3)); if (!s) return up0.call(this, l, d, 'work', r, log);
    var p = admitP(l, s);
    if (!ch(r, p)) { log('Trượt kỳ thi năng khiếu vào ' + s[1] + '. ' + pick(r, ['Phần thi năng khiếu chưa đủ điểm chuẩn.', 'Thiếu nửa điểm, về nhà khóc cả buổi.', 'Hội đồng nhận xét: "Có tố chất nhưng cần luyện thêm."']), 'bad'); fx(l, { hap: -6 }); l.pending.unshift(E.DEC.uniFail.make(l)); return; }
    var city = s[2] || (l.city || 'tỉnh nhà');
    if (l.job) { l.lastJob = l.job; var history=l.jobsHist||[];if(history.length&&history[history.length-1].to==null)history[history.length-1].to=l.age;l.job=null;l.income=0;log('Dừng công việc hiện tại để theo học chương trình chuyên ngành toàn thời gian.','neutral'); }
    l.flags.needJob = false;
    l.school = s[6] === 'cd' ? 'voc' : 'uni'; l.schoolEnd = l.age + (s[6] === 'cd' ? 2 : 4); // v3.9: cao đẳng 2 năm
    l.major = s[3]; l.majorName = s[4]; l.uniTier = s[5] >= 0.55 ? 1.2 : 1.05; l.uniCity = city;
    if (s[2] && s[2] !== homeCity(l)) l.cityStudent = { city: city, since: l.age };
    l.flags.tSchool = { id: s[0], n: s[1], mn: s[4], jobs: s[7], cd: s[6] === 'cd', at: l.age };
    if (/vhntqd/.test(s[0])) l.flags.milDone = true; // học trường quân đội được tính là đã phục vụ
    log('Đỗ ' + s[1] + ', ngành ' + s[4] + '!', 'big'); fx(l, { hap: 8 }); l.skill = Math.min(100, sk(l) + 3);
    H.mem(l, 'Ngày nhận giấy báo trúng tuyển ' + s[1] + ' — năng khiếu từ nhỏ đã thành con đường.', 5);
  };

  // 2c. ra trường: gợi ý nghề đúng chuyên ngành (vẫn có thể chọn ngành khác)
  var JDESC = { ca_si: 'bắt đầu từ hát phòng trà, đám cưới; nổi hay không còn nhờ bài hát hay và chút may mắn', nhac_si: 'làm nhạc công, phối khí, sáng tác bán bài', giang_vien: 'ở lại trường làm giảng viên', giao_vien: 'về trường phổ thông dạy học, lương ổn định',
    van_cong: 'biên chế đoàn văn công, lương ổn định, đi biểu diễn phục vụ bộ đội', dj: 'chơi nhạc ở bar, sự kiện', hoa_si: 'vẽ tranh theo đơn, triển lãm, bán tranh', thiet_ke: 'làm thiết kế đồ họa ở công ty quảng cáo', tk_thoi_trang: 'thiết kế thời trang',
    kien_truc: 'kiến trúc sư ở công ty thiết kế', fl_thiet_ke: 'nhận thiết kế tự do', dien_vien: 'đi casting, đóng vai nhỏ trước', mc_tv: 'dẫn chương trình ở đài', dao_dien: 'làm trợ lý đạo diễn', bien_kich: 'viết kịch bản phim truyền hình', hlv_tt: 'trợ lý huấn luyện viên ở đội tuyển tỉnh',
    pt_gym: 'huấn luyện viên cá nhân ở phòng gym', fl_dich: 'biên – phiên dịch', hdv: 'hướng dẫn viên du lịch', tiep_vien: 'tiếp viên hàng không', ngoai_giao: 'thi tuyển vào ngành ngoại giao', marketing: 'marketing ở công ty', logistics: 'xuất nhập khẩu', phong_vien: 'phóng viên ở tòa soạn',
    dev: 'lập trình viên', data: 'phân tích dữ liệu', ky_su: 'kỹ sư', nghien_cuu: 'nghiên cứu viên', gia_su: 'dạy thêm', luat_su: 'trợ lý luật sư', cong_chung: 'văn phòng công chứng', tham_phan: 'thi vào ngành tòa án', kiem_sat: 'thi vào ngành kiểm sát', fl_content: 'viết nội dung',
    ky_su_co_dien: 'kỹ sư cơ điện', ky_thuat_vien: 'kỹ thuật viên', tho_dien: 'thợ điện', tho_han: 'thợ hàn', sale_b2b: 'kinh doanh', ngan_hang: 'ngân hàng', stylist: 'stylist', makeup: 'trang điểm', spa: 'spa', nail: 'làm móng', tho_toc: 'làm tóc', streamer: 'streamer' };
  SC('nk_ra_truong', {
    title: 'Tốt nghiệp — làm gì với tấm bằng?',
    valid: function (l) { return !!l.flags.tSchool && !l.job; },
    prep: function (l) { var T = l.flags.tSchool; return { jobs: T.jobs.filter(function (id) { return E.CAR[id] && E.CAR[id].edu <= l.edu; }).slice(0, 3) }; },
    text: function (l) { var T = l.flags.tSchool; return 'Bạn tốt nghiệp ngành ' + T.mn + ' của ' + T.n + '. Với tấm bằng và năng khiếu của mình, hướng đi gợi ý:'; },
    opts: [0, 1, 2].map(function (i) {
      return { k: 'j' + i, l: function (l, d) { var id = d.jobs[i]; return id ? cap(E.offerLabel(l, id)) : ''; }, h: function (l, d) { return JDESC[d.jobs[i]] || ''; }, req: function (l, d) { return !!d.jobs[i]; }, ai: { w: 1.2 - i * 0.2 },
        run: function (l, r, log, d) { var id = d.jobs[i]; E.startJob(l, id, r, log); if (id === 'ca_si' || id === 'dien_vien') l.fame = Math.max(l.fame || 0, 5000); if (id === 'giang_vien') log('Được thầy cô giữ lại trường làm giảng viên.', 'good'); } };
    }).concat([{ k: 'khac', l: 'Tìm việc ở ngành khác', ai: { w: 0.4 }, run: function (l, r, log) { l.flags.needJob = true; log('Cất tấm bằng chuyên ngành, đi tìm việc ở lĩnh vực khác.', 'neutral'); l.pending.unshift(E.DEC.job.make(l, r)); } }])
  });
  E.HOOKS.year.push(function (l, r, log, a) {
    var T = l.flags.tSchool; if (!T || T.out) return;
    if (l.school) return;
    T.out = true;
    if (l.edu < (T.cd ? 4 : 5) || l.job) return; // bỏ học giữa chừng, hoặc đã đi làm
    if (l.flags.postNext != null) return; // học tiếp thạc sĩ
    l.flags.needJob = false;
    if (T.cd) log('Tốt nghiệp ' + T.n + ', ngành ' + T.mn + '.', 'good');
    l.pending.push(E.DEC.nk_ra_truong.make(l, r));
  });
  E.MAJOR && (E.MAJOR.nk_ra_truong = 1, E.MAJOR.nk_dinh_huong = 1);

  // ===================================================================
  // 3. SỰ KIỆN THEO BỐI CẢNH NGÀNH
  // ===================================================================
  var JOBS2 = E.JOBS2 || (E.JOBS2 = {});
  // o = [k, nhãn, ai, chạy, gợi ý (chuỗi hoặc hàm)]
  function J(id, jobs, rmin, rmax, p, cd, title, text, opts, extra) {
    JOBS2[id] = jobs;
    SC(id, { title: title, valid: function (l) { return jobs.indexOf(jid(l)) >= 0; }, text: text, opts: opts.map(function (o) { return { k: o[0], l: o[1], ai: o[2], run: o[3], h: o[4] || '' }; }) });
    E.TRIG.push({ id: id, when: function (l, a) { return jobs.indexOf(jid(l)) >= 0 && rk(l) >= rmin && rk(l) <= rmax && free(l) && (!extra || extra(l, a)); }, p: p, cd: cd, max: 2 });
  }
  var HON = { w: 1.3, bad: -0.5 }, BAD = { bad: 1.2, risk: 0.6, w: 0.5 }, MID = { w: 0.9 }, RISK = { risk: 1, amb: 0.8, w: 0.8 };
  function fame(l, mul, add) { l.fame = Math.max(0, (l.fame || 0) * mul + (add || 0)); }
  function trap(l, key) { (l.flags.traps = l.flags.traps || {})[key] = l.age; }
  function TR(key, p, run) { if (E.TRAPS) E.TRAPS[key] = { p: p, run: run }; }

  // ---------- ÂM NHẠC ----------
  var SINGERS = ['ca_si', 'rapper'];
  function hit(l, r, log, what, big) {
    var x = 0.6 + r() * 0.8, gain = V(l, (20 + rk(l) * 40) * (big ? 2.5 : 1) * x);
    fame(l, big ? 3 : 2, (big ? 4e5 : 1.5e5) * x);
    H.cash(l, gain, 'Show diễn nhờ bài hit');
    log(what + ' Lời mời biểu diễn kéo đến liên tục, cát-xê tăng hẳn (thu về ' + mo(l, gain) + ').', 'big');
    if (promote(l)) log('Bạn trở thành ' + E.jobTitle(l) + '.', 'good');
    H.mem(l, 'Lần đầu nghe cả khán phòng hát theo bài hát của mình.', 6); fx(l, { hap: 10 });
  }
  J('am_mua_bai', SINGERS, 0, 4, 0.3, 3, 'Một bài hát "để đời"', function (l) { return 'Ca sĩ sống bằng bài hát. Bạn cần một ca khúc mới để bật lên — nhưng bài hay thì đắt, và có bài hay rồi vẫn cần chút may mắn mới thành hit.'; }, [
    ['hit', 'Mua bài của một nhạc sĩ chuyên viết hit', RISK, function (l, r, log) { var c = [80, 120, 200, 300, 500][Math.min(4, rk(l))]; pay(l, c, 'Mua bài hát'); if (ch(r, 0.32 + sk(l) / 600)) hit(l, r, log, 'Bài hát mua của nhạc sĩ nổi tiếng thành hit, lọt top thịnh hành, được hát lại khắp mạng xã hội.', true); else { log('Bỏ ' + mo(l, V(l, c)) + ' mua bài, quay MV chỉn chu, nhưng bài ra cùng lúc với mấy ca khúc lớn — lặng lẽ chìm.', 'neutral'); fx(l, { hap: -4 }); } }, function (l) { return 'Khoảng ' + mo(l, V(l, [80, 120, 200, 300, 500][Math.min(4, rk(l))])) + ' · cơ hội thành hit cao nhất'; }],
    ['tre', 'Mua bài của một nhạc sĩ trẻ chưa có tên tuổi', MID, function (l, r, log) { pay(l, 15, 'Mua bài hát'); if (ch(r, 0.15 + sk(l) / 800)) hit(l, r, log, 'Bài hát của cậu nhạc sĩ trẻ vô danh bất ngờ "viral" — cả hai cùng nổi.', false); else log('Bài hát dễ thương nhưng chưa đủ "đinh", được vài trăm nghìn lượt nghe.', 'neutral'); }, function (l) { return 'Khoảng ' + mo(l, V(l, 15)) + ' · may rủi'; }],
    ['tu', 'Tự sáng tác', { smart: 0.8, amb: 0.6 }, function (l, r, log) { var can = l.flags.compose || sk(l) >= 60 || jid(l) === 'rapper'; if (!can && !ch(r, 0.3)) { log('Ngồi cả tháng với cây đàn mà chưa viết được bài nào ưng ý. Sáng tác khó hơn hát nhiều.', 'neutral'); fx(l, { hap: -2 }); return; } l.flags.compose = true; if (ch(r, 0.1 + sk(l) / 500)) { hit(l, r, log, 'Ca khúc tự sáng tác chạm đến người nghe — vừa nổi tiếng vừa giữ trọn tiền bản quyền.', false); l.flags.royalty = (l.flags.royalty || 0) + 10; } else log('Viết xong một bài tâm đắc. Khán giả khen chân thành, chưa thành hit — nhưng bạn đã biết mình viết được.', 'good'); fx(l, { hap: 3 }); }, 'Không tốn tiền mua bài · cần khả năng sáng tác'],
    ['cover', 'Cover lại bản hit cũ cho an toàn', { w: 0.7 }, function (l, r, log) { pay(l, 3, 'Phí xin phép bản quyền bài cover'); fame(l, 1.1, 3000); log('Xin phép tác giả, trả phí bản quyền rồi cover lại bản hit cũ — được khen, có thêm khán giả.', 'neutral'); }, 'Ít rủi ro, ít đột phá']]);
  J('am_thi_truyen_hinh', ['ca_si', 'rapper', 'nhac_si'], 0, 1, 0.22, 4, 'Cuộc thi truyền hình', function (l) { var j = jid(l); return 'Cuộc thi ' + (j === 'rapper' ? 'rap trên truyền hình' : j === 'nhac_si' ? 'sáng tác ca khúc trên truyền hình' : 'tìm kiếm giọng hát trên truyền hình') + ' mở vòng tuyển chọn. Nhiều ca sĩ nổi tiếng hiện nay bước ra từ những cuộc thi như thế này.'; }, [
    ['thi', 'Đi thi, dốc hết sức', RISK, function (l, r, log) { var x = sk(l) / 100 * 0.6 + r() * 0.6; if (x < 0.45) { log('Dừng chân ở vòng giấu mặt — không huấn luyện viên nào quay ghế. Về nhà luyện tiếp.', 'neutral'); fx(l, { hap: -4 }); } else if (x < 0.75) { fame(l, 1.6, 6e4); log('Vào được top 12, được khán giả cả nước biết mặt.', 'good'); fx(l, { hap: 5 }); } else if (x < 0.95) { fame(l, 2.2, 2e5); promote(l); log('Lọt vào đêm chung kết! Dù không giành ngôi quán quân, bạn đã có tên tuổi.', 'big'); H.mem(l, 'Đêm chung kết cuộc thi truyền hình, ánh đèn sân khấu và tiếng hò reo.', 5); } else { fame(l, 3, 5e5); promote(l); promote(l); earn(l, 300, 'Giải quán quân'); log('Giành ngôi QUÁN QUÂN! Tên bạn phủ kín mạng xã hội.', 'big'); H.mem(l, 'Khoảnh khắc được xướng tên quán quân.', 8); } }],
    ['an_toan', 'Đi thi cho biết, không áp lực', MID, function (l, r, log) { if (ch(r, 0.3)) { fame(l, 1.3, 2e4); log('Đi thi cho vui, bất ngờ vào được vòng đối đầu. Có thêm ít người hâm mộ.', 'good'); } else log('Thi vui, dừng ở vòng đầu, quen thêm nhiều bạn cùng nghề.', 'neutral'); fx(l, { soc: 3 }); }],
    ['khong', 'Không thi, tự đi đường của mình', { w: 0.6 }, function (l, r, log) { log('Không đi thi, tiếp tục hát ở phòng trà và làm nhạc riêng.', 'neutral'); }]]);
  J('am_clip_lan_truyen', ['ca_si', 'rapper', 'nhac_si', 'van_cong', 'dj'], 0, 3, 0.1, 5, 'Clip lan truyền', 'Một khán giả quay lén lúc bạn hát ở đám cưới / phòng trà rồi đăng lên mạng. Sau một đêm, clip có vài triệu lượt xem.', [
    ['tan_dung', 'Tranh thủ ra ngay bản thu âm chính thức', RISK, function (l, r, log) { pay(l, 20, 'Thu âm, quay MV nhanh'); if (ch(r, 0.5)) hit(l, r, log, 'Bản chính thức ra đúng lúc cả mạng đang tìm kiếm — thành hit.', false); else { fame(l, 1.4, 3e4); log('Bản chính thức ra hơi muộn, cơn sốt đã qua, nhưng bạn vẫn có thêm nhiều người theo dõi.', 'neutral'); } }],
    ['cam_on', 'Cảm ơn khán giả, cứ hát như bình thường', MID, function (l, r, log) { fame(l, 1.3, 2e4); log('Đăng lời cảm ơn, khách đến phòng trà đông hơn hẳn.', 'good'); }],
    ['go', 'Yêu cầu gỡ clip vì quay không xin phép', { w: 0.3 }, function (l, r, log) { log('Clip được gỡ. Bạn giữ được sự riêng tư, nhưng cơ hội cũng trôi qua.', 'neutral'); }]]);
  J('am_ban_quyen', ['ca_si', 'nhac_si', 'rapper'], 1, 4, 0.12, 5, 'Bài hát bị dùng không xin phép', 'Bạn phát hiện bài hát của mình bị nhiều quán karaoke, kênh mạng xã hội dùng để kiếm tiền mà không xin phép, không trả tiền bản quyền.', [
    ['uy_thac', 'Ủy thác cho trung tâm bảo vệ quyền tác giả âm nhạc thu hộ', HON, function (l, r, log) { l.flags.royalty = (l.flags.royalty || 0) + 6 + rk(l) * 6; log('Ủy thác quyền tác giả: từ nay mỗi năm có một khoản tiền bản quyền đều đặn.', 'good'); }],
    ['kien', 'Gửi thư yêu cầu, rồi kiện bên vi phạm lớn nhất', RISK, function (l, r, log) { pay(l, 10, 'Thuê luật sư'); if (ch(r, 0.6)) { earn(l, 60, 'Bồi thường bản quyền'); log('Tòa xử bạn thắng kiện, bên vi phạm phải bồi thường và xin lỗi công khai.', 'good'); } else log('Vụ kiện kéo dài, tốn kém, cuối cùng hòa giải với khoản tiền nhỏ.', 'neutral'); }],
    ['ke', 'Kệ, càng nhiều người hát càng nổi', { w: 0.5 }, function (l, r, log) { fame(l, 1.1, 5000); log('Bỏ qua chuyện bản quyền — nổi thêm chút nhưng mất một nguồn thu.', 'neutral'); }]]);
  J('am_giu_giong', ['ca_si', 'van_cong'], 0, 4, 0.08, 6, 'Giọng hát có vấn đề', 'Khàn tiếng kéo dài, hát nốt cao bị rè. Bác sĩ chẩn đoán hạt xơ dây thanh vì hát quá nhiều, thức khuya.', [
    ['nghi', 'Nghỉ hát vài tháng, điều trị đến nơi đến chốn', HON, function (l, r, log) { pay(l, 15, 'Điều trị dây thanh'); fx(l, { hea: 2 }); log('Hủy hết show, nghỉ ba tháng điều trị. Giọng hát hồi phục, trong như cũ.', 'good'); }, function (l) { return 'Khoảng ' + mo(l, V(l, 15)) + ' và mất mấy tháng thu nhập'; }],
    ['hat_tiep', 'Uống thuốc rồi hát tiếp, show đã nhận rồi', { risk: 1, w: 0.6 }, function (l, r, log) { earn(l, 20, 'Vẫn chạy show'); if (ch(r, 0.4)) { l.skill = Math.max(10, sk(l) - 20); fame(l, 0.6); log('Gắng hát qua mùa show, rồi một đêm mất tiếng giữa sân khấu. Giọng hát không bao giờ trở lại như xưa.', 'bad'); fx(l, { hap: -10 }); } else log('May mắn qua được mùa show, giọng vẫn ổn — lần sau không dám liều nữa.', 'neutral'); }]]);
  J('am_ban_bai', ['nhac_si'], 0, 3, 0.25, 3, 'Có người muốn mua bài hát', 'Một ca sĩ nổi tiếng nghe bản demo của bạn và muốn mua ca khúc.', [
    ['ban_dut', 'Bán đứt, lấy tiền ngay', MID, function (l, r, log) { var x = earn(l, 20 + rk(l) * 30, 'Bán bài hát'); l.flags.compose = true; log('Bán đứt ca khúc, thu về ' + mo(l, x) + '.' + (ch(r, 0.3) ? ' Mấy tháng sau bài hát thành hit — bạn vừa vui vừa tiếc.' : ''), 'good'); }],
    ['ban_quyen', 'Giữ quyền tác giả, nhận tiền bản quyền theo lượt sử dụng', { smart: 1, w: 1 }, function (l, r, log) { l.flags.compose = true; if (ch(r, 0.35)) { l.flags.royalty = (l.flags.royalty || 0) + 15 + rk(l) * 10; fame(l, 1.5, 3e4); log('Bài hát thành hit, tên bạn xuất hiện trong mọi bảng xếp hạng với vai trò tác giả. Tiền bản quyền đều đặn mỗi năm.', 'big'); promote(l); } else { l.flags.royalty = (l.flags.royalty || 0) + 3; log('Bài hát được nghe vừa phải, tiền bản quyền lai rai.', 'neutral'); } }],
    ['giu', 'Giữ lại, chờ dịp tự ra mắt', { w: 0.5 }, function (l, r, log) { log('Cất bản demo vào ổ cứng, chờ ngày tự phát hành.', 'neutral'); }]]);
  J('am_show_tet', ['ca_si', 'rapper', 'dj'], 1, 4, 0.2, 3, 'Mùa show Tết', 'Bầu show mời chạy show Tết ở các tỉnh: một đêm năm, sáu điểm diễn, cát-xê gấp đôi ngày thường — nhưng Tết không có nhà.', [
    ['chay', 'Nhận hết, chạy show xuyên Tết', { amb: 1, w: 1 }, function (l, r, log) { var x = earn(l, 30 + rk(l) * 40, 'Show Tết'); fx(l, { hea: -3, hap: -2 }); stress(l, 8); log('Giao thừa trên xe khách giữa hai điểm diễn. Thu về ' + mo(l, x) + ', mệt rã rời.', 'neutral'); }],
    ['vua', 'Nhận vừa đủ, mùng Một ở nhà với gia đình', HON, function (l, r, log) { var x = earn(l, 12 + rk(l) * 15, 'Show Tết'); fx(l, { hap: 4 }); log('Chạy vài show trước Tết, mùng Một ở nhà ăn bánh chưng với gia đình. Thu về ' + mo(l, x) + '.', 'good'); }]]);
  J('am_fan_cuong', ['ca_si', 'rapper', 'dien_vien'], 1, 4, 0.08, 6, 'Người hâm mộ quá khích', 'Một người hâm mộ theo bạn từ sân bay về tận nhà, nhắn hàng trăm tin mỗi ngày, có lần còn chờ trước cổng cả đêm.', [
    ['ranh_gioi', 'Nhẹ nhàng nhưng dứt khoát đặt ranh giới, nhờ quản lý hỗ trợ', HON, function (l, r, log) { log('Quản lý gặp riêng người hâm mộ, giải thích rõ ràng. Mọi chuyện lắng xuống.', 'good'); }],
    ['bao_cong_an', 'Trình báo công an khu vực', MID, function (l, r, log) { log('Công an phường đến làm việc, nhắc nhở người hâm mộ. Cán bộ còn dặn bạn cách giữ an toàn khi đi diễn.', 'good'); }],
    ['ke', 'Kệ, nổi tiếng thì phải chịu', { w: 0.5 }, function (l, r, log) { stress(l, 10); fx(l, { hap: -4 }); log('Sống trong cảm giác bị theo dõi, mất ngủ mấy tháng liền.', 'bad'); }]]);
  J('vc_bien_gioi', ['van_cong'], 0, 2, 0.35, 2, 'Biểu diễn phục vụ bộ đội', 'Đoàn văn công được giao đi biểu diễn phục vụ cán bộ, chiến sĩ ở đồn biên phòng vùng cao và các đảo xa.', [
    ['di', 'Xung phong đi', { w: 1.3 }, function (l, r, log) { fx(l, { hap: 6, karma: 4 }); rep(l, 8); log('Hát giữa đồn biên phòng mù sương, chiến sĩ trẻ hát theo mà rưng rưng nhớ nhà. Chuyến đi đáng nhớ nhất đời biểu diễn.', 'good'); H.mem(l, 'Đêm diễn ở đồn biên phòng, cả đơn vị cùng hát.', 5); if (ch(r, 0.3) && promote(l)) log('Được đề bạt: ' + E.jobTitle(l) + '.', 'good'); }],
    ['nhuong', 'Nhường suất cho đồng đội, ở lại tập chương trình mới', MID, function (l, r, log) { log('Ở lại dựng chương trình mới cho đoàn.', 'neutral'); fx(l, { kno: 1 }); }]]);
  J('vc_ra_ngoai', ['van_cong'], 1, 2, 0.12, 5, 'Lời mời ra ngoài', 'Một công ty giải trí mời bạn rời đoàn văn công để làm ca sĩ / diễn viên tự do: cát-xê cao hơn nhiều, nhưng không còn lương ổn định.', [
    ['o_lai', 'Ở lại đoàn, giữ con đường đã chọn', { w: 1.1 }, function (l, r, log) { log('Ở lại đoàn văn công. Lương không cao nhưng ổn định, có lương hưu.', 'neutral'); }],
    ['ra', 'Xin chuyển ra, thử sức ở thị trường giải trí', RISK, function (l, r, log) { var to = l.talent === 'diễn xuất' ? 'dien_vien' : 'ca_si'; E.startJob(l, to, r, log); l.fame = Math.max(l.fame || 0, 3e4); }]]);

  // ---------- MỸ THUẬT, THIẾT KẾ ----------
  J('mt_trien_lam', ['hoa_si'], 0, 2, 0.25, 3, 'Triển lãm cá nhân', 'Bạn đủ tranh cho một triển lãm cá nhân. Thuê phòng tranh, in catalogue, làm khai mạc tốn kha khá.', [
    ['lam', 'Làm triển lãm', RISK, function (l, r, log) { pay(l, 30, 'Tổ chức triển lãm'); var x = r() + sk(l) / 200; if (x > 1) { var g = earn(l, 80 + rk(l) * 120, 'Bán tranh'); promote(l); log('Triển lãm thành công, báo chí viết bài, bán được nhiều tranh (thu về ' + mo(l, g) + ').', 'big'); H.mem(l, 'Đêm khai mạc triển lãm cá nhân đầu tiên.', 5); } else if (x > 0.6) { earn(l, 25, 'Bán tranh'); log('Bán được vài bức, hòa vốn, được giới chuyên môn chú ý.', 'good'); } else log('Khách đến xem đông nhưng chẳng ai mua. Tranh lại chất vào góc xưởng.', 'neutral'); }, function (l) { return 'Khoảng ' + mo(l, V(l, 30)); }],
    ['nhom', 'Góp tranh vào triển lãm nhóm cho đỡ tốn', MID, function (l, r, log) { pay(l, 5, 'Góp triển lãm nhóm'); if (ch(r, 0.4)) { earn(l, 20, 'Bán tranh'); log('Một bức tranh trong triển lãm nhóm được nhà sưu tập mua.', 'good'); } else log('Triển lãm nhóm vui, quen thêm nhiều họa sĩ.', 'neutral'); }]]);
  J('mt_tranh_gia', ['hoa_si'], 0, 2, 0.1, 6, 'Đơn hàng "chép tranh"', 'Một chủ phòng tranh đặt bạn chép lại tranh của các danh họa đã mất, ký tên họ, để bán cho khách như tranh thật. Trả rất hậu.', [
    ['tu_choi', 'Từ chối: chép thì được, giả mạo chữ ký thì không', HON, function (l, r, log) { fx(l, { karma: 4 }); log('Từ chối. Bạn chỉ nhận chép tranh có ghi rõ "bản chép".', 'good'); }],
    ['nhan', 'Nhận, tiền dễ quá', BAD, function (l, r, log) { earn(l, 60, 'Chép tranh giả'); fx(l, { karma: -6 }); trap(l, 'tranh_gia'); log('Nhận đơn, ký tên danh họa lên tranh mình vẽ.', 'bad'); }]]);
  TR('tranh_gia', 0.3, function (l, r, log) { log('Vụ bán tranh giả danh họa bị phanh phui, giới mỹ thuật lên tiếng. Tên bạn bị nêu là người vẽ, không ai đặt tranh nữa, còn bị phạt hành chính.', 'bad'); pay(l, 30, 'Phạt vụ tranh giả'); fame(l, 0.3); if (l.job && E.resolveJob(l.job.id) === 'hoa_si') { l.job = null; l.flags.needJob = true; } });
  J('mt_dat_ve', ['hoa_si', 'fl_thiet_ke', 'thiet_ke'], 0, 3, 0.2, 3, 'Khách đặt vẽ', 'Một khách hàng đặt vẽ chân dung cả gia đình để treo phòng khách, yêu cầu "vẽ đẹp hơn ngoài đời một chút, nhất là bà xã".', [
    ['ve', 'Vẽ chân thực nhưng khéo léo tôn nét đẹp', { w: 1.2 }, function (l, r, log) { var x = earn(l, 8 + rk(l) * 8, 'Vẽ chân dung theo đơn'); log('Khách ưng, giới thiệu thêm ba nhà nữa (thu về ' + mo(l, x) + ').', 'good'); rep(l, 5); }],
    ['sua', 'Chiều khách sửa đi sửa lại đến lần thứ 27', MID, function (l, r, log) { var x = earn(l, 6, 'Vẽ chân dung theo đơn'); stress(l, 8); log('Sửa đến lần thứ 27, khách quay về chọn… bản đầu tiên. Thu về ' + mo(l, x) + '.', 'neutral'); }]]);
  J('mt_dau_gia', ['hoa_si'], 1, 2, 0.12, 5, 'Phiên đấu giá', 'Một bức tranh của bạn được chọn đưa vào phiên đấu giá gây quỹ từ thiện của một nhà đấu giá lớn.', [
    ['dua', 'Đồng ý góp tranh', HON, function (l, r, log) { var x = 0.5 + r(); fame(l, 1.5, 2e4); fx(l, { karma: 3 }); log(x > 1.2 ? 'Bức tranh được trả giá cao gấp ba giá khởi điểm, tiền gây quỹ xây trường cho trẻ em vùng cao. Giá tranh của bạn tăng theo.' : 'Bức tranh được bán với giá vừa phải, toàn bộ góp vào quỹ từ thiện.', 'good'); if (x > 1.2) promote(l); }],
    ['khong', 'Từ chối, tranh đó đã hứa bán cho khách', MID, function (l, r, log) { earn(l, 15, 'Bán tranh'); log('Giữ lời với khách quen.', 'neutral'); }]]);
  J('kt_thi_y_tuong', ['kien_truc'], 0, 3, 0.15, 4, 'Cuộc thi phương án kiến trúc', 'Thành phố tổ chức thi phương án thiết kế một nhà văn hóa thiếu nhi. Bạn có thể thức trắng mấy tuần để làm bài dự thi.', [
    ['thi', 'Dự thi', RISK, function (l, r, log) { stress(l, 10); if (ch(r, 0.2 + sk(l) / 400 + rk(l) * 0.05)) { earn(l, 100, 'Giải nhất phương án kiến trúc'); promote(l); fame(l, 1.5, 1e4); log('Phương án của bạn đoạt giải nhất và được chọn xây dựng!', 'big'); H.mem(l, 'Ngày công trình mình thiết kế khánh thành, lũ trẻ chạy ùa vào.', 6); } else log('Không đoạt giải, nhưng phương án được ban giám khảo khen sáng tạo.', 'neutral'); }],
    ['bo', 'Thôi, việc ở công ty đã đủ mệt', MID, function (l, r, log) { log('Tập trung vào các dự án đang có.', 'neutral'); }]]);
  J('tk_tuan_le_thoi_trang', ['tk_thoi_trang'], 0, 3, 0.15, 4, 'Tuần lễ thời trang', 'Bạn được mời trình diễn bộ sưu tập ở một tuần lễ thời trang quốc tế tổ chức tại Việt Nam. Tự lo chi phí may mẫu, người mẫu.', [
    ['dien', 'Dốc vốn làm bộ sưu tập', RISK, function (l, r, log) { pay(l, 50, 'Làm bộ sưu tập'); if (ch(r, 0.35 + sk(l) / 400)) { fame(l, 2, 3e4); promote(l); earn(l, 90, 'Đơn hàng sau show diễn'); log('Bộ sưu tập được khen, nhiều người nổi tiếng mặc thiết kế của bạn — đơn đặt may kín lịch.', 'big'); } else log('Show diễn ổn, nhưng chưa tạo được dấu ấn, chưa bán được mấy.', 'neutral'); }, function (l) { return 'Khoảng ' + mo(l, V(l, 50)); }],
    ['hen', 'Hẹn mùa sau, chuẩn bị kỹ hơn', MID, function (l, r, log) { log('Lỡ một mùa, dành thời gian hoàn thiện bộ sưu tập.', 'neutral'); }]]);
  J('np_the_nho', ['nhiep_anh'], 0, 3, 0.12, 5, 'Mất thẻ nhớ ảnh cưới', 'Sau buổi chụp ảnh cưới, bạn phát hiện thẻ nhớ bị lỗi, mất gần hết ảnh ngày cưới của khách.', [
    ['thu_that', 'Báo thật, hoàn tiền, xin chụp lại buổi ngoại cảnh miễn phí', HON, function (l, r, log) { pay(l, 8, 'Hoàn tiền cho khách'); rep(l, 3); log('Khách buồn nhưng cảm kích sự thật thà, đồng ý chụp lại ngoại cảnh. Từ đó bạn luôn dùng hai thẻ nhớ.', 'neutral'); }],
    ['giau', 'Giấu, chỉ gửi mấy tấm còn lại, bảo "chỉ có thế"', BAD, function (l, r, log) { rep(l, -15); log('Khách phát hiện, lên mạng "bóc phốt". Mất khách cả mùa cưới.', 'bad'); }]]);

  // ---------- SÂN KHẤU, ĐIỆN ẢNH, TRUYỀN HÌNH ----------
  J('dd_phim_dau_tay', ['dao_dien'], 1, 3, 0.2, 4, 'Bộ phim đầu tay', 'Bạn có cơ hội làm bộ phim điện ảnh đầu tay. Nhà sản xuất cho chọn: phim nghệ thuật đi liên hoan phim, hay phim thương mại kiếm doanh thu.', [
    ['nghe_thuat', 'Phim nghệ thuật, đi liên hoan phim', { smart: 1, w: 1 }, function (l, r, log) { if (ch(r, 0.3 + sk(l) / 500)) { fame(l, 2, 5e4); promote(l); log('Phim được chọn chiếu ở một liên hoan phim quốc tế, nhận giải của ban giám khảo!', 'big'); H.mem(l, 'Đứng trên sân khấu liên hoan phim quốc tế, cầm giải thưởng cho bộ phim đầu tay.', 7); } else log('Phim được giới phê bình khen nhưng ra rạp vắng khách.', 'neutral'); }],
    ['thuong_mai', 'Phim thương mại, hài – tình cảm', RISK, function (l, r, log) { var x = r(); if (x > 0.7) { earn(l, 300, 'Thưởng doanh thu phim'); fame(l, 2, 1e5); promote(l); log('Phim cán mốc trăm tỷ doanh thu phòng vé!', 'big'); } else if (x > 0.3) log('Phim hòa vốn, khán giả chấm điểm trung bình.', 'neutral'); else { log('Phim lỗ nặng, bị chê kịch bản yếu.', 'bad'); fx(l, { hap: -6 }); } }]]);
  J('bk_kich_ban', ['bien_kich'], 0, 3, 0.18, 4, 'Kịch bản bị sửa', 'Nhà sản xuất muốn sửa kịch bản của bạn: thêm cảnh quảng cáo sản phẩm của nhà tài trợ, đổi cái kết buồn thành cái kết có hậu.', [
    ['thuong_luong', 'Thương lượng: giữ tinh thần kịch bản, chấp nhận vài chỗ quảng cáo khéo', { w: 1.2, smart: 0.6 }, function (l, r, log) { rep(l, 5); log('Thương lượng được, phim vẫn giữ được hồn. Nhà sản xuất nhớ tên bạn cho dự án sau.', 'good'); if (ch(r, 0.3)) promote(l); }],
    ['chieu', 'Chiều theo, miễn được trả đủ tiền', MID, function (l, r, log) { earn(l, 10, 'Nhuận bút kịch bản'); log('Phim ra mắt bị chê "quảng cáo lộ liễu". Tiền thì nhận đủ.', 'neutral'); }],
    ['rut', 'Rút kịch bản', { w: 0.4 }, function (l, r, log) { log('Rút kịch bản, chờ nhà sản xuất khác tâm huyết hơn.', 'neutral'); }]]);
  J('mc_dam_cuoi', ['mc_su_kien'], 0, 2, 0.2, 3, 'Sự cố ở đám cưới', 'Đang dẫn lễ cưới thì chú rể… say, lên sân khấu hát ba bài liền không chịu xuống, nhà gái bắt đầu khó chịu.', [
    ['kheo', 'Khéo léo pha trò, mời bố mẹ hai bên lên phát biểu để "cứu" không khí', { w: 1.2 }, function (l, r, log) { rep(l, 6); earn(l, 2, 'Tiền bo đám cưới'); log('Biến sự cố thành tiết mục vui nhất buổi. Nhà trai bo thêm, giới thiệu thêm khách.', 'good'); }],
    ['ke', 'Kệ, đúng giờ thì xuống', MID, function (l, r, log) { log('Buổi lễ trôi qua hơi ngượng ngùng.', 'neutral'); }]]);
  J('mc_dan_lon', ['mc_tv'], 0, 1, 0.15, 4, 'Cơ hội dẫn chương trình lớn', 'MC chính của một chương trình truyền hình lớn bị ốm, đài gọi bạn thay gấp — chỉ có một ngày chuẩn bị.', [
    ['nhan', 'Nhận, thức trắng đêm học kịch bản', RISK, function (l, r, log) { if (ch(r, 0.5 + sk(l) / 300)) { promote(l); fame(l, 1.5, 3e4); log('Dẫn trôi chảy, khán giả khen "MC mới duyên quá". Bạn được giao dẫn chính một chương trình.', 'big'); } else log('Vấp vài chỗ, bị lên mạng chế ảnh. Ít lâu sau mọi người cũng quên.', 'neutral'); }],
    ['tu_choi', 'Từ chối, chưa đủ tự tin', { w: 0.5 }, function (l, r, log) { log('Từ chối, đồng nghiệp khác nhận và nổi lên.', 'neutral'); }]]);

  // ---------- THỂ THAO ----------
  J('hlv_hoc_tro', ['hlv_tt', 'pt_gym', 'giao_vien'], 0, 3, 0.12, 5, 'Một đứa trẻ có năng khiếu', 'Bạn phát hiện một cậu bé nhà nghèo chạy chân đất nhanh hơn mọi học sinh trong trường.', [
    ['dao_tao', 'Kèm cặp miễn phí, xin cho em vào lớp năng khiếu', HON, function (l, r, log) { fx(l, { karma: 6, hap: 4 }); if (ch(r, 0.3)) { rep(l, 10); log('Chiều nào cũng kèm em chạy trên sân đất. Em tiến bộ thần tốc, được gọi vào đội tuyển trẻ quốc gia — bạn mừng như chính mình được chọn.', 'big'); H.mem(l, 'Ngày cậu học trò chân đất được gọi vào đội tuyển trẻ quốc gia.', 5); } else log('Cậu bé được vào lớp năng khiếu của tỉnh, có cơ hội đổi đời.', 'good'); }],
    ['bo_qua', 'Khen một câu rồi thôi', MID, function (l, r, log) { log('Khen cậu bé một câu rồi quên mất.', 'neutral'); }]]);
  J('hlv_khai_tuoi', ['hlv_tt'], 0, 2, 0.1, 6, 'Lời đề nghị "khai lại tuổi"', 'Một phụ huynh nhờ bạn sửa giấy tờ, khai nhỏ tuổi cho con để thi đấu ở giải trẻ cho dễ giành huy chương.', [
    ['tu_choi', 'Từ chối: thể thao phải công bằng', HON, function (l, r, log) { fx(l, { karma: 4 }); log('Từ chối thẳng thắn, giải thích cho phụ huynh hiểu.', 'good'); }],
    ['lam', 'Giúp "một chút"', BAD, function (l, r, log) { earn(l, 10, 'Tiền cảm ơn'); fx(l, { karma: -6 }); if (ch(r, 0.5)) { log('Ban tổ chức kiểm tra giấy tờ, phát hiện gian lận tuổi. Bạn bị đình chỉ công tác huấn luyện.', 'bad'); l.job = null; l.flags.needJob = true; } else log('Trót lọt, nhưng mỗi lần nhìn đứa trẻ đứng trên bục lại thấy áy náy.', 'bad'); }]]);
  J('pt_thuoc_tang_co', ['pt_gym'], 0, 2, 0.12, 5, 'Khách hỏi "thuốc tăng cơ"', 'Một khách tập muốn có cơ bắp thật nhanh để đi thi thể hình, nhờ bạn mua hộ thuốc tăng cơ không rõ nguồn gốc.', [
    ['khuyen', 'Khuyên tập đúng cách, ăn uống khoa học', HON, function (l, r, log) { rep(l, 5); log('Lên giáo án ăn tập nghiêm túc. Khách tiến bộ chậm mà chắc, gắn bó với bạn nhiều năm.', 'good'); }],
    ['ban', 'Bán hộ, ăn chênh lệch', BAD, function (l, r, log) { earn(l, 5, 'Bán thuốc tăng cơ'); fx(l, { karma: -5 }); if (ch(r, 0.4)) { log('Khách bị tổn thương gan phải nhập viện, gia đình tìm đến phòng gym. Bạn bị cho nghỉ việc.', 'bad'); l.job = null; l.flags.needJob = true; } }]]);

  // ---------- NGOẠI NGỮ, DU LỊCH ----------
  J('nn_cabin', ['fl_dich', 'ngoai_giao'], 1, 3, 0.15, 4, 'Phiên dịch hội nghị quốc tế', 'Bạn được mời phiên dịch cabin cho một hội nghị quốc tế lớn: nói song song, không được phép sai.', [
    ['nhan', 'Nhận, chuẩn bị tài liệu thuật ngữ cả tuần', { amb: 1, w: 1.1 }, function (l, r, log) { if (ch(r, 0.45 + l.st.kno / 250)) { var x = earn(l, 25, 'Phiên dịch hội nghị'); promote(l); log('Dịch trôi chảy suốt ba ngày, trưởng đoàn bạn bè quốc tế khen ngợi (thu về ' + mo(l, x) + ').', 'big'); } else { earn(l, 15, 'Phiên dịch hội nghị'); log('Có đoạn dịch hụt vì diễn giả nói quá nhanh, đồng nghiệp ở cabin kịp đỡ. Bài học nhớ đời.', 'neutral'); } }],
    ['tu_choi', 'Từ chối, chưa đủ tự tin', { w: 0.5 }, function (l, r, log) { log('Từ chối, nhận tiếp các hợp đồng dịch viết.', 'neutral'); }]]);
  J('nn_dich_sai', ['fl_dich', 'hdv'], 0, 3, 0.1, 5, 'Phát hiện mình dịch sai', 'Bạn phát hiện bản dịch hợp đồng đã giao cho khách tuần trước có một con số bị dịch sai, có thể khiến khách thiệt hại.', [
    ['bao', 'Báo ngay cho khách, sửa miễn phí', HON, function (l, r, log) { rep(l, 6); log('Khách kịp sửa trước khi ký. Họ quý sự trung thực, giao thêm việc thường xuyên.', 'good'); }],
    ['im', 'Im lặng, chắc không ai để ý', BAD, function (l, r, log) { if (ch(r, 0.5)) { pay(l, 20, 'Bồi thường dịch sai'); rep(l, -20); log('Đối tác phát hiện sai sót, khách thiệt hại và đòi bạn bồi thường.', 'bad'); } else log('Không ai phát hiện. Nhưng bạn biết mình đã sai.', 'neutral'); }]]);
  J('hdv_mat_ho_chieu', ['hdv'], 0, 3, 0.15, 4, 'Khách mất hộ chiếu', 'Một vị khách nước ngoài trong đoàn bị móc túi mất hộ chiếu đúng hôm trước khi bay về.', [
    ['giup', 'Đưa khách đi trình báo, liên hệ đại sứ quán làm giấy tờ', HON, function (l, r, log) { rep(l, 8); fx(l, { karma: 3 }); log('Cùng khách đến công an phường trình báo — cán bộ làm xác nhận rất nhanh, rồi đến đại sứ quán làm giấy thông hành. Khách viết thư khen gửi công ty.', 'good'); }],
    ['ke', 'Bảo khách tự lo, còn phải dẫn cả đoàn', MID, function (l, r, log) { rep(l, -5); log('Khách loay hoay một mình, về nước chấm điểm tour rất thấp.', 'neutral'); }]]);
  J('tv_hanh_khach', ['tiep_vien'], 0, 3, 0.15, 4, 'Hành khách gây rối', 'Một hành khách say rượu to tiếng, đòi hút thuốc trên máy bay và đẩy đồng nghiệp của bạn.', [
    ['quy_trinh', 'Bình tĩnh xử lý theo quy trình, báo cơ trưởng', HON, function (l, r, log) { rep(l, 6); log('Xử lý đúng quy trình. Khi hạ cánh, công an cửa khẩu lên máy bay làm việc với hành khách gây rối.', 'good'); }],
    ['nhin', 'Nhịn cho xong chuyến bay', MID, function (l, r, log) { stress(l, 8); log('Nhịn suốt hai tiếng bay, về nhà mệt rã rời.', 'neutral'); }]]);

  // ---------- KỸ THUẬT, CÔNG NGHỆ ----------
  var ENG = ['ky_su', 'ky_su_co_dien', 'ky_su_xd', 'dev', 'data'];
  J('ks_du_an', ENG, 0, 3, 0.18, 4, 'Dự án gấp', 'Công ty nhận một dự án lớn, hạn chót cực gắt. Sếp đề nghị cả nhóm làm xuyên đêm, cuối tuần trong hai tháng.', [
    ['lam', 'Lao vào làm, cơ hội để chứng tỏ', { amb: 1, w: 1 }, function (l, r, log) { stress(l, 12); fx(l, { hea: -3 }); if (ch(r, 0.5)) { promote(l); log('Dự án về đích đúng hạn. Bạn được thăng chức: ' + E.jobTitle(l) + '.', 'good'); } else log('Dự án xong, thưởng một bữa liên hoan. Bạn sụt mấy cân.', 'neutral'); }],
    ['thuong_luong', 'Đề xuất chia giai đoạn, tuyển thêm người cho hợp lý', { smart: 1, w: 1 }, function (l, r, log) { if (ch(r, 0.55)) { rep(l, 6); log('Sếp đồng ý kế hoạch mới, cả nhóm làm việc bền hơn.', 'good'); } else log('Sếp gạt đi: "Khách không chờ được." Cả nhóm vẫn phải làm thêm.', 'neutral'); }]]);
  J('ks_sang_che', ['ky_su', 'ky_su_co_dien', 'nghien_cuu', 'ky_thuat_vien'], 0, 4, 0.08, 6, 'Một sáng chế nhỏ', 'Bạn cải tiến được một chi tiết máy giúp xưởng tiết kiệm cả tỷ đồng mỗi năm.', [
    ['dang_ky', 'Báo cáo công ty, đăng ký sáng kiến – sáng chế', HON, function (l, r, log) { earn(l, 30, 'Thưởng sáng kiến'); promote(l); H.mem(l, 'Tấm bằng sáng chế đầu tiên mang tên mình.', 5); log('Công ty khen thưởng, sáng kiến được đăng ký bảo hộ, tên bạn đứng tác giả.', 'good'); }],
    ['rieng', 'Giữ lại, định ra ngoài tự làm', RISK, function (l, r, log) { if (ch(r, 0.3)) { earn(l, 150, 'Bán giải pháp kỹ thuật'); log('Mở công ty nhỏ bán giải pháp, ăn nên làm ra.', 'big'); } else log('Định tự làm nhưng thiếu vốn, ý tưởng nằm trong ngăn kéo.', 'neutral'); }]]);
  J('ks_an_toan', ['ky_su_co_dien', 'ky_su_xd', 'ky_su'], 1, 4, 0.1, 6, 'Bỏ qua kiểm định?', 'Nhà thầu muốn đẩy nhanh tiến độ, đề nghị bạn ký biên bản kiểm định hệ thống điện của tòa nhà dù chưa thử tải đầy đủ.', [
    ['khong_ky', 'Không ký khi chưa kiểm tra đủ', HON, function (l, r, log) { fx(l, { karma: 4 }); rep(l, 5); log('Kiên quyết kiểm tra lại, phát hiện một tủ điện lắp sai. Có thể bạn vừa ngăn được một vụ cháy.', 'good'); }],
    ['ky', 'Ký cho kịp tiến độ', BAD, function (l, r, log) { earn(l, 10, 'Tiền "cảm ơn" của nhà thầu'); trap(l, 'kiem_dinh'); log('Ký cho xong.', 'bad'); }]]);
  TR('kiem_dinh', 0.25, function (l, r, log) { log('Tòa nhà bị chập điện gây cháy. Cơ quan điều tra xác định biên bản kiểm định có chữ ký của bạn dù chưa thử tải. Bạn bị kỷ luật, tước chứng chỉ hành nghề.', 'bad'); if (l.job) { l.job = null; l.flags.needJob = true; } pay(l, 50, 'Bồi thường'); fx(l, { hap: -10 }); });
  J('ks_khoi_nghiep', ['ky_su', 'dev', 'data'], 1, 3, 0.1, 6, 'Rủ khởi nghiệp', 'Một người bạn cũ rủ bạn nghỉ việc cùng làm startup công nghệ, góp vốn mỗi người một ít.', [
    ['lam', 'Nghỉ việc, cùng làm startup', RISK, function (l, r, log) { pay(l, 100, 'Góp vốn khởi nghiệp'); var x = r(); if (x > 0.85) { earn(l, 2000, 'Bán lại startup'); log('Startup được một tập đoàn mua lại! Bạn thành triệu phú đô la… bằng tiền Việt.', 'big'); H.mem(l, 'Ngày ký hợp đồng bán startup.', 7); } else if (x > 0.45) log('Startup sống được, lương thấp hơn trước nhưng học được rất nhiều.', 'neutral'); else { log('Hết vốn sau 18 tháng, startup đóng cửa. Quay lại đi làm thuê.', 'bad'); fx(l, { hap: -6 }); } }, function (l) { return 'Góp khoảng ' + mo(l, V(l, 100)); }],
    ['khong', 'Ở lại công ty, hỗ trợ bạn ngoài giờ', MID, function (l, r, log) { log('Giữ việc ổn định, thỉnh thoảng giúp bạn ngoài giờ.', 'neutral'); }]]);

  // ---------- NGHỀ LAO ĐỘNG TRƯỚC ĐÂY ÍT SỰ KIỆN ----------
  J('th_bao_ho', ['tho_han'], 0, 3, 0.15, 5, 'Mặt nạ hàn hỏng', 'Mặt nạ hàn bị nứt kính, chủ xưởng bảo "dùng tạm, tháng sau mua".', [
    ['mua', 'Tự bỏ tiền mua mặt nạ mới', HON, function (l, r, log) { pay(l, 0.5, 'Mua đồ bảo hộ'); log('Bỏ tiền mua mặt nạ mới — mắt là của mình.', 'good'); }],
    ['tam', 'Dùng tạm', { risk: 0.8, w: 0.7 }, function (l, r, log) { if (ch(r, 0.4)) { fx(l, { hea: -6 }); log('Bị "bỏng mắt" do tia hồ quang, đau rát cả tuần, phải nghỉ làm đi khám.', 'bad'); } else log('Dùng tạm mấy tuần, mắt mỏi nhưng chưa sao.', 'neutral'); }],
    ['kien_nghi', 'Đề nghị chủ xưởng trang bị đủ bảo hộ cho cả xưởng', { w: 1 }, function (l, r, log) { if (ch(r, 0.6)) log('Chủ xưởng mua đồ bảo hộ mới cho mọi người. Anh em cảm ơn bạn.', 'good'); else log('Chủ xưởng không vui, nhưng vẫn phải mua.', 'neutral'); }]]);
  J('tm_go_lau', ['tho_moc'], 0, 3, 0.1, 6, 'Lô gỗ không giấy tờ', 'Một khách đặt đóng bộ bàn ghế gỗ quý, tự mang gỗ đến — lô gỗ không có giấy tờ nguồn gốc.', [
    ['tu_choi', 'Từ chối, chỉ nhận gỗ có giấy tờ hợp pháp', HON, function (l, r, log) { log('Từ chối. Ít lâu sau nghe tin kiểm lâm bắt một đường dây buôn gỗ lậu.', 'good'); fx(l, { karma: 3 }); }],
    ['nhan', 'Nhận, tiền công cao', BAD, function (l, r, log) { earn(l, 15, 'Đóng đồ gỗ'); if (ch(r, 0.3)) { pay(l, 30, 'Phạt tàng trữ gỗ lậu'); log('Kiểm lâm kiểm tra xưởng, lô gỗ bị tịch thu, bạn bị phạt hành chính.', 'bad'); } }]]);
  J('tm_mo_xuong', ['tho_moc', 'tho_han', 'tho_may'], 0, 1, 0.12, 6, 'Mở xưởng riêng', 'Tay nghề đã vững, khách quen nhiều, bạn tính mở xưởng riêng.', [
    ['mo', 'Vay mượn mở xưởng nhỏ', RISK, function (l, r, log) { pay(l, 60, 'Mở xưởng'); if (ch(r, 0.55)) { promote(l); log('Xưởng nhỏ đắt hàng, thuê thêm hai thợ phụ.', 'good'); } else log('Xưởng ế mấy tháng đầu, phải làm thêm ngoài giờ để trả nợ.', 'neutral'); }],
    ['o', 'Làm thuê thêm vài năm cho chắc', MID, function (l, r, log) { log('Tiếp tục làm thuê, tích lũy thêm vốn.', 'neutral'); }]]);
  J('pv_khach_bo', ['phuc_vu', 'barista', 'bartender'], 0, 2, 0.15, 4, 'Vị khách đặc biệt', 'Một vị khách ngồi quán nhiều giờ, gọi đúng một ly trà đá, rồi trước khi về để lại tờ tiền bo lớn gấp mấy ngày lương kèm lời nhắn "Cảm ơn em đã cười với tôi hôm nay".', [
    ['cam_on', 'Cảm ơn, nhận và chia với đồng nghiệp', { w: 1.2 }, function (l, r, log) { earn(l, 0.5, 'Tiền bo'); fx(l, { hap: 6 }); log('Chia tiền bo với cả ca làm. Lời nhắn ấy bạn giữ trong ví nhiều năm.', 'good'); }],
    ['giu', 'Giữ riêng', MID, function (l, r, log) { earn(l, 1, 'Tiền bo'); fx(l, { hap: 3 }); log('Giữ riêng khoản tiền bo, mua cho mẹ cái áo mới.', 'good'); }]]);
  J('br_trat_tu', ['ban_rong'], 0, 1, 0.15, 4, 'Đội trật tự đô thị', 'Đội trật tự đô thị đi dẹp hàng rong lấn chiếm vỉa hè đúng lúc bạn đang bán.', [
    ['dep', 'Thu dọn ngay, hỏi chỗ bán hợp lệ', HON, function (l, r, log) { log('Cán bộ phường nhẹ nhàng nhắc nhở và chỉ cho bạn một điểm bán tập trung ở chợ đêm mới mở. Từ đó buôn bán ổn định hơn.', 'good'); rep(l, 4); }],
    ['chay', 'Ôm hàng bỏ chạy', { risk: 0.8, w: 0.7 }, function (l, r, log) { if (ch(r, 0.4)) { pay(l, 1, 'Mất hàng'); log('Chạy vấp ngã, hàng rơi vãi khắp đường.', 'bad'); } else log('Chạy thoát, nửa tiếng sau lại bày ra bán.', 'neutral'); }]]);
  J('vs_khach_trung', ['ve_so'], 0, 1, 0.08, 6, 'Khách trúng số', 'Một bác xe ôm mua của bạn tờ vé số, hôm sau trúng giải nhất.', [
    ['mung', 'Mừng cho bác', { w: 1 }, function (l, r, log) { if (ch(r, 0.6)) { earn(l, 20, 'Khách trúng số "lại quả"'); log('Bác tìm đến tận nơi, dúi cho bạn một phong bì "lấy hên". Cả xóm vé số kéo đến mua của bạn.', 'good'); } else log('Bác lặng lẽ đi lĩnh thưởng, không ai biết bác là ai. Nhưng người ta đồn bạn bán "vé hên", đắt hàng hẳn.', 'good'); fx(l, { hap: 4 }); }]]);
  J('vs_ve_gia', ['ve_so'], 0, 1, 0.12, 5, 'Tờ vé số "trúng"', 'Một người đàn ông lạ đưa tờ vé số "trúng giải 5 triệu", nhờ bạn đổi lấy vé mới và tiền mặt vì "đang vội".', [
    ['do', 'Kiểm tra kỹ số, đối chiếu kết quả rồi mới đổi', { smart: 1, w: 1.2 }, function (l, r, log) { log('Dò lại mới thấy con số bị cạo sửa khéo léo. Người đàn ông vội vàng bỏ đi.', 'good'); fx(l, { kno: 1 }); }],
    ['doi', 'Đổi ngay cho người ta', { w: 0.5 }, function (l, r, log) { pay(l, 3, 'Đổi vé số giả'); log('Mang lên đại lý mới biết vé bị sửa số. Mất trắng mấy ngày tiền lời.', 'bad'); fx(l, { hap: -6 }); }]]);
  J('cc_ho_so_gia', ['cong_chung'], 0, 2, 0.12, 5, 'Hồ sơ đáng ngờ', 'Hai người đến công chứng hợp đồng bán nhà. Ảnh trên căn cước của "chủ nhà" không giống người đang ngồi trước mặt lắm.', [
    ['kiem', 'Đề nghị đối chiếu thêm giấy tờ, xác minh', HON, function (l, r, log) { rep(l, 8); log('Xác minh thì phát hiện căn cước giả. Báo công an — một đường dây chiếm đoạt nhà bị triệt phá, chủ nhà thật cảm ơn bạn.', 'good'); fx(l, { karma: 4 }); }],
    ['lam', 'Công chứng luôn cho nhanh, khách đông', BAD, function (l, r, log) { trap(l, 'cong_chung_gia'); log('Công chứng xong trong mười phút.', 'neutral'); }]]);
  TR('cong_chung_gia', 0.5, function (l, r, log) { log('Chủ nhà thật khởi kiện: hợp đồng mua bán nhà do bạn công chứng dùng giấy tờ giả. Văn phòng phải bồi thường, bạn bị tạm đình chỉ hành nghề.', 'bad'); pay(l, 80, 'Bồi thường công chứng sai'); if (l.job && E.resolveJob(l.job.id) === 'cong_chung') { l.job = null; l.flags.needJob = true; } });
  J('db_cuoc_thi', ['dau_bep', 'chu_quan_an', 'chu_nha_hang'], 0, 2, 0.1, 6, 'Cuộc thi nấu ăn trên truyền hình', 'Một cuộc thi đầu bếp trên truyền hình tuyển thí sinh. Món tủ của bạn được nhiều người khen.', [
    ['thi', 'Đăng ký thi', RISK, function (l, r, log) { if (ch(r, 0.3)) { fame(l, 2, 3e4); promote(l); log('Vào chung kết cuộc thi! Quán của bạn / nhà hàng nơi bạn làm đông khách hẳn.', 'big'); } else log('Bị loại ở vòng hai vì món ăn quá mặn — run tay nêm nhầm.', 'neutral'); fx(l, { soc: 3 }); }],
    ['khong', 'Thôi, nấu cho khách là đủ', MID, function (l, r, log) { log('Ở lại bếp, ngày ngày nấu cho khách quen.', 'neutral'); }]]);
  J('mu_co_dau', ['makeup', 'tho_toc'], 0, 2, 0.15, 4, 'Mùa cưới', 'Mùa cưới, 3 giờ sáng bạn đã có mặt ở nhà cô dâu. Mẹ cô dâu muốn trang điểm "đậm cho ăn ảnh", cô dâu muốn "trong veo tự nhiên".', [
    ['dung_hoa', 'Dung hòa: lớp nền mỏng, tô đậm mắt môi vừa phải', { w: 1.2 }, function (l, r, log) { rep(l, 5); earn(l, 2, 'Trang điểm cô dâu'); log('Cả hai mẹ con đều hài lòng, ảnh cưới lên rất đẹp. Thêm năm khách đặt lịch.', 'good'); }],
    ['nghe_me', 'Nghe theo mẹ cô dâu', MID, function (l, r, log) { earn(l, 1.5, 'Trang điểm cô dâu'); log('Cô dâu nhìn gương hơi buồn, nhưng vẫn cảm ơn bạn.', 'neutral'); }]]);
  J('xam_tre_vi_thanh_nien', ['tho_xam'], 0, 2, 0.12, 5, 'Khách nhỏ tuổi', 'Một cậu học sinh trông chỉ mười lăm, mười sáu tuổi muốn xăm kín cánh tay, nói "bố mẹ em đồng ý rồi".', [
    ['tu_choi', 'Từ chối, hẹn khi đủ 18 tuổi hoặc có bố mẹ đi cùng', HON, function (l, r, log) { log('Từ chối, khuyên em suy nghĩ thêm. Vài hôm sau mẹ em đến cảm ơn bạn.', 'good'); fx(l, { karma: 3 }); }],
    ['xam', 'Xăm luôn, khách là khách', BAD, function (l, r, log) { earn(l, 3, 'Tiền xăm'); if (ch(r, 0.4)) { rep(l, -10); log('Phụ huynh tìm đến làm ầm, đăng lên mạng. Tiệm vắng khách cả tháng.', 'bad'); } }]]);
  J('spa_danh_gia', ['spa', 'nail', 'barber', 'tho_toc'], 0, 3, 0.15, 4, 'Đánh giá một sao', 'Một khách để lại đánh giá một sao kèm lời lẽ nặng nề trên mạng, dù hôm đó bạn đã làm lại miễn phí cho khách.', [
    ['tra_loi', 'Trả lời lịch sự, giải thích, mời khách quay lại', { w: 1.2 }, function (l, r, log) { rep(l, 4); log('Câu trả lời từ tốn được nhiều người khen, khách cũ vào bênh. Tiệm còn đông hơn.', 'good'); }],
    ['cai', 'Cãi tay đôi trên mạng', { risk: 0.6, w: 0.5 }, function (l, r, log) { rep(l, -8); log('Cãi qua cãi lại thành "drama", tiệm mất khách một thời gian.', 'bad'); }]]);

  // tiền bản quyền âm nhạc hằng năm
  E.HOOKS.year.push(function (l, r, log, a) { if (l.flags.royalty > 0 && l.alive) { var x = V(l, l.flags.royalty) * (0.7 + r() * 0.6); H.cash(l, x, 'Tiền bản quyền tác giả'); if (a >= 70) l.flags.royalty *= 0.9; } });

  // tên ngành học của trường chuyên ngành hiển thị đúng ("ngành Thanh nhạc")
  E.majorName = function (l) { return l.majorName || (l.major && E.MAJORS[l.major]) || ''; };
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
/* ===== js/life36.js ===== */
/* Một Đời — v3.6 (góp ý của người chơi):
   · "Chi tiêu": gom các việc tiêu tiền về một chỗ, có chi tiêu định kỳ tự động mỗi năm (du lịch 1 lần/năm, du lịch nước ngoài 1 lần/2 năm,
     khám sức khỏe định kỳ, tập gym, biếu bố mẹ, từ thiện, học thêm, đầu tư đều đặn…) — đỡ phải chọn lại mỗi năm
   · chế độ nghỉ hưu: tự chọn nghỉ hưu; đã nghỉ hưu hẳn thì không còn bị hỏi nhận việc này việc kia (muốn đi làm lại thì tự bấm)
   · chuyển chỗ ở sang thành phố khác (trong nước hoặc nơi đang định cư) */
(function (G) {
  'use strict';
  var U = G.U, E = G.E, H = E.H, SC = E.SC, isVN = H.isVN;
  function A(id, g, label, o) { var x = { id: id, g: g, l: label }; for (var k in o) x[k] = o[k]; E.ACT.push(x); }
  function fx(l, o) { H.fx(l, o); }
  function mo(l, v) { return H.money(l, v); }
  function pick(r, a) { return U.pick(r, a); }
  function ch(r, p) { return r() < p; }
  function vnd(l) { return isVN(l) && l.cur === 'vnd' && !(l.abroad && l.abroad.perm); }
  function V(l, tr) { return vnd(l) ? tr : tr / 90 * l.base; }
  function busy(l) { return (l.jailUntil != null && l.age < l.jailUntil) || (l.abroad && l.abroad.trapped) || (l.flags.military && l.age < l.flags.military); }
  function parentsAlive(l) { return l.fam.mAlive || l.fam.fAlive; }
  function resName(l) { return l.abroad && l.abroad.perm ? l.abroad.name : l.countryName || 'trong nước'; }

  // ===================================================================
  // 1. CHI TIÊU ĐỊNH KỲ
  // ===================================================================
  var DOM_VN = ['Đà Lạt', 'Nha Trang', 'Phú Quốc', 'Sa Pa', 'Hội An', 'Hạ Long', 'Quy Nhơn', 'Đà Nẵng', 'Huế', 'Côn Đảo', 'Ninh Bình', 'Mộc Châu', 'Phan Thiết', 'Hà Giang'];
  var INTL = ['Thái Lan', 'Hàn Quốc', 'Nhật Bản', 'Singapore', 'Trung Quốc', 'Đài Loan', 'Malaysia', 'Pháp', 'Úc', 'Mỹ', 'Ý', 'Thụy Sĩ', 'Indonesia (Bali)', 'Dubai'];
  function domPlace(l, r) {
    if (vnd(l)) return pick(r, DOM_VN.filter(function (p) { return p !== l.place && p !== l.city; }));
    var W = G.W, c = W && W.BY[l.abroad && l.abroad.perm ? l.abroad.code : l.country], cs = (c && c.cities) || [];
    var o = cs.filter(function (x) { return x !== l.place && x !== l.city; });
    return o.length ? pick(r, o) : 'một thị trấn ven biển';
  }
  // c: chi phí mỗi lần (triệu đồng ở VN; nước khác quy theo mức thu nhập)
  var RECUR = [
    { id: 'dl_trong', l: 'Du lịch trong nước', every: 1, c: function (l) { return V(l, 7); },
      ok: function (l) { return true; },
      run: function (l, r) { var p = domPlace(l, r); fx(l, { hap: 4, soc: 1 }); if (l.mind) l.mind.stress = Math.max(0, l.mind.stress - 6); return 'du lịch ' + p; } },
    { id: 'dl_ngoai', l: 'Du lịch nước ngoài', every: 2, c: function (l) { return V(l, 35); },
      ok: function (l) { return l.age >= 16 ? true : 'Từ 16 tuổi'; },
      run: function (l, r) { var home = l.abroad && l.abroad.perm ? l.abroad.name : 'Việt Nam'; var p = pick(r, INTL.filter(function (x) { return x !== home && x !== l.countryName; })); H.visit(l, p.replace(/ \(.*\)$/, '')); fx(l, { hap: 7, soc: 2, kno: 1 }); if (l.mind) l.mind.stress = Math.max(0, l.mind.stress - 8); return 'du lịch ' + p; } },
    { id: 'kham_dk', l: 'Khám sức khỏe định kỳ', every: 1, c: function (l) { return V(l, l.money > l.base * 8 ? 6 : 2.5); },
      ok: function (l) { return true; },
      run: function (l, r) { l.flags.checkupUntil = l.age + 2; fx(l, { hea: 2 }); if (l.ill && !l.ill.treated && !l.ill.early) { l.ill.early = true; l.ill.mult = 1 + (l.ill.m - 1) * 0.3; l.ill.cure = Math.min(0.95, (l.ill.base || l.ill.cure || 0.3) * 2); return 'khám sức khỏe định kỳ (phát hiện sớm ' + l.ill.n + ', điều trị kịp thời)'; } return 'khám sức khỏe định kỳ'; } },
    { id: 'gym', l: 'Tập gym / thể thao đều đặn', every: 1, per: 'cả năm', c: function (l) { return V(l, 6); },
      ok: function (l) { return true; },
      run: function (l) { l.flags.exercise = true; fx(l, { hea: 2, hap: 1 }); if (l.mind) l.mind.stress = Math.max(0, l.mind.stress - 4); return 'tập gym đều đặn'; } },
    { id: 'bieu', l: 'Biếu bố mẹ hằng tháng', every: 1, per: 'cả năm', c: function (l) { return V(l, 24); },
      ok: function (l) { return parentsAlive(l) ? true : 'Bố mẹ đã khuất'; },
      run: function (l) { fx(l, { karma: 2, hap: 1 }); l.flags.caredParents = true; return 'biếu ' + (l.fam.mAlive && l.fam.fAlive ? 'bố mẹ' : l.fam.mAlive ? 'mẹ' : 'bố') + ' mỗi tháng'; } },
    { id: 'tu_thien', l: 'Làm từ thiện', every: 1, c: function (l) { return V(l, 4); },
      ok: function (l) { return true; },
      run: function (l) { fx(l, { karma: 3, hap: 1 }); return 'làm từ thiện'; } },
    { id: 'hoc', l: 'Học một khóa kỹ năng / ngoại ngữ', every: 1, c: function (l) { return V(l, 8); },
      ok: function (l) { return true; },
      run: function (l) { fx(l, { kno: 2 }); return 'học thêm một khóa kỹ năng'; } },
    { id: 'dau_tu', l: 'Đầu tư đều đặn vào quỹ chỉ số (10% thu nhập)', every: 1, c: function (l) { return Math.max(V(l, 5), (l.income || 0) * 0.1); },
      ok: function (l) { return (l.income || 0) > 0 ? true : 'Cần có thu nhập'; },
      run: function (l, r, cost) { var s = vnd(l) ? 'E1VFVN30' : 'SPY'; l.port = l.port || {}; var h = l.port[s] || (l.port[s] = { v: 0, basis: 0 }); h.v += cost; h.basis += cost; return 'mua thêm chứng chỉ quỹ ' + (s === 'SPY' ? 'S&P 500' : 'VN30'); }, invest: true }
  ];
  E.RECUR = RECUR;
  function recurOf(id) { return RECUR.filter(function (x) { return x.id === id; })[0]; }
  function canRecur(l) { return l.alive && l.age >= 16 && (l.indep || l.age >= 18) ? true : 'Từ khi tự lập (16–18 tuổi)'; }
  // danh sách cho giao diện
  E.recurList = function (l) {
    var R = l.recur || {}, base = canRecur(l);
    return RECUR.map(function (x) { var ok = base === true ? x.ok(l) : base; return { id: x.id, l: x.l, every: x.every, per: x.per || (x.every === 1 ? 'mỗi năm' : x.every + ' năm/lần'), cost: mo(l, x.c(l)), on: !!R[x.id], ok: ok }; });
  };
  E.recurToggle = function (l, id) {
    var x = recurOf(id); if (!x) return false;
    l.recur = l.recur || {};
    if (l.recur[id]) { delete l.recur[id]; return false; }
    if (canRecur(l) !== true || x.ok(l) !== true) return false;
    l.recur[id] = true; return true;
  };
  // mỗi năm: tự chi các khoản định kỳ đã bật; không đủ tiền thì tạm bỏ qua năm đó
  E.HOOKS.year.push(function (l, r, log, a) {
    var R = l.recur; if (!R || !l.alive) return;
    if (busy(l)) return;
    var done = [], skip = [], tot = 0, at = l.recurAt || (l.recurAt = {});
    RECUR.forEach(function (x) {
      if (!R[x.id]) return;
      if (x.ok(l) !== true) { delete R[x.id]; return; }
      if (at[x.id] != null && a - at[x.id] < x.every) return;
      var cost = x.c(l);
      if (l.money - cost < (x.invest ? l.base * 0.5 : 0)) { skip.push(x.l.toLowerCase()); return; }
      H.cash(l, -cost, U.cap(x.l));
      tot += cost; at[x.id] = a;
      done.push(x.run(l, r, cost));
    });
    if (done.length) log('Chi tiêu định kỳ: ' + done.join(', ') + ' (chi ' + mo(l, tot) + ').', 'money');
    if (skip.length) log('Năm nay không đủ tiền nên tạm bỏ: ' + skip.join(', ') + '.', 'neutral');
  });

  // ===================================================================
  // 2. NGHỈ HƯU
  // ===================================================================
  function canRetire(l) { return !!l.job && l.age >= (l.sex === 'F' ? 50 : 55) && !E.isCrime(l); }
  function pensionHint(l) {
    if (!vnd(l)) return 'Hưởng lương hưu theo chế độ của ' + resName(l);
    var y = l.si ? Math.round(l.si.yrs) : 0;
    return y >= 15 ? 'Đã đóng BHXH ' + y + ' năm — đủ điều kiện nhận lương hưu hằng tháng' : 'Mới đóng BHXH ' + y + ' năm — chưa đủ 15 năm nên chưa có lương hưu, sống bằng tiền tích lũy';
  }
  function retireNow(l, log) { l.job.retireNow = true; l.flags.retChosen = true; l.flags.fullRetire = true; log('Làm đơn xin nghỉ hưu, chuẩn bị bàn giao công việc.', 'neutral'); }
  if (E.DEC.nghi_viec) E.DEC.nghi_viec.def.opts.splice(1, 0, { k: 'huu', l: 'Nghỉ hưu luôn, không đi làm nữa', h: pensionHint, req: canRetire, ai: { w: 0.3 }, run: function (l, r, log) { retireNow(l, log); } });
  SC('nghi_huu_chon', {
    title: 'Nghỉ hưu?', valid: canRetire,
    text: function (l) { return 'Bạn ' + l.age + ' tuổi, đang làm ' + E.jobTitle(l) + '. ' + pensionHint(l) + '. Nghỉ hưu rồi sẽ không còn bị hỏi nhận việc này việc kia; muốn đi làm lại thì tự vào "Tìm việc".'; },
    opts: [
      { k: 'huu', l: 'Nghỉ hưu, an hưởng tuổi già', ai: { w: 1 }, run: function (l, r, log) { retireNow(l, log); } },
      { k: 'no', l: 'Làm thêm vài năm nữa', ai: { w: 1 }, run: function (l, r, log) { log('Còn khỏe thì còn làm.', 'neutral'); } }
    ]
  });
  A('nghi_huu', 'Công việc', 'Nghỉ hưu', { min: 50, sc: 'nghi_huu_chon', avail: function (l) { return canRetire(l) ? true : !l.job ? 'Chưa có việc' : 'Từ ' + (l.sex === 'F' ? 50 : 55) + ' tuổi'; } });
  // nghỉ hưu (tự chọn hay đến tuổi) thì mặc định nghỉ hẳn; đi làm lại thì thôi
  E.HOOKS.year.push(function (l) { if (l.retired) { if (l.flags.fullRetire == null) l.flags.fullRetire = true; } else if (l.flags.fullRetire) l.flags.fullRetire = null; });
  if (E.DEC.sau_huu) { var sv = E.DEC.sau_huu.def.valid; E.DEC.sau_huu.def.valid = function (l, d) { return !l.flags.retChosen && (!sv || sv(l, d)); }; }
  // tự đi tìm việc sau khi nghỉ hưu = đi làm lại
  var ja0 = E.DEC.job.apply;
  E.DEC.job.apply = function (l, d, k, r, log) {
    var was = l.retired;
    var x = ja0.apply(this, arguments);
    if (was && k !== 'none' && l.job) { l.retired = false; l.flags.fullRetire = null; l.flags.afterRet = Math.max(l.flags.afterRet || 0, l.age + 5); log('Thôi nghỉ hưu, đi làm lại cho vui, cho khỏe.', 'neutral'); }
    return x;
  };
  E.ACT.forEach(function (a) {
    if (a.id === 'tim_viec') { var l0 = a.l; a.l = function (l) { return l.retired ? 'Đi làm lại (đang nghỉ hưu)' : typeof l0 === 'function' ? l0(l) : l0; }; }
  });

  // ===================================================================
  // 3. CHUYỂN CHỖ Ở
  // ===================================================================
  function cities(l) {
    if (vnd(l)) return ['Hà Nội', 'TP. Hồ Chí Minh', 'Đà Nẵng', 'Hải Phòng', 'Cần Thơ', 'Nha Trang', 'Đà Lạt'].filter(function (c) { return c !== l.movedTo && c !== l.city && c !== (l.prov && l.prov.n); });
    var W = G.W, c = W && W.BY[l.abroad && l.abroad.perm ? l.abroad.code : l.country];
    return ((c && c.cities) || []).filter(function (x) { return x !== l.place && x !== l.city; }).slice(0, 5);
  }
  SC('chuyen_noi_o', {
    title: 'Chuyển chỗ ở',
    valid: function (l) { return l.indep && !l.ownHouse; },
    prep: function (l) { return { cs: cities(l).slice(0, 4) }; },
    text: function (l) { return 'Bạn đang thuê nhà ở ' + (l.place || l.city || 'nơi ở hiện tại') + '. Chuyển đến thành phố khác thì phải thu xếp đồ đạc, đặt cọc nhà mới (khoảng ' + mo(l, V(l, 15)) + '); công việc' + (l.job && H.isEmployee(l) ? ' hiện tại có thể phải xin chuyển hoặc tìm việc mới' : ' và các mối quan hệ cũng phải làm lại từ đầu') + '.'; },
    opts: [0, 1, 2, 3].map(function (i) {
      return { k: 'c' + i, l: function (l, d) { return d.cs[i] ? 'Chuyển đến ' + d.cs[i] : ''; }, req: function (l, d) { return !!d.cs[i]; }, ai: { w: 0.5 },
        run: function (l, r, log, d) {
          var to = d.cs[i]; H.cash(l, -V(l, 15), 'Chuyển nhà, đặt cọc nhà mới');
          if (vnd(l)) H.moveToCity(l, to); else { l.place = to; l.city = to; l.urban = true; }
          l.cityStudent = null;
          if (l.job && H.isEmployee(l) && ch(r, 0.5)) { log('Chuyển đến ' + to + '. Công ty không có chi nhánh ở đó, bạn phải nghỉ việc để tìm việc mới.', 'neutral'); l.job = null; l.flags.needJob = true; }
          else log('Chuyển đến sống ở ' + to + ' — một khởi đầu mới.', 'good');
          fx(l, { hap: 2, soc: -4 }); H.mem(l, 'Ngày kéo vali đến ' + to + ', thuê căn phòng đầu tiên.', 2);
        } };
    }).concat([{ k: 'no', l: 'Thôi, ở lại chỗ cũ', ai: { w: 1 }, run: function (l, r, log) { log('Ở lại chỗ cũ, quen nơi quen chốn.', 'neutral'); } }])
  });
  A('chuyen_noi_o', 'Tiền bạc', 'Chuyển chỗ ở sang thành phố khác', { min: 18, sc: 'chuyen_noi_o', avail: function (l) { return !l.indep ? 'Khi đã tự lập' : l.ownHouse ? 'Đang có nhà riêng — bán / đổi nhà trước' : l.abroad && !l.abroad.perm ? 'Đang ở nước ngoài theo hợp đồng' : cities(l).length ? true : 'Không có nơi nào khác'; } });

  // các việc tiêu tiền gom vào mục "Chi tiêu" (giao diện)
  E.SPEND_ACTS = ['dau_tu', 'ban_dau_tu_moi', 'tim_viec', 'mua_nha', 'doi_nha', 'chuyen_noi_o', 'mua_xe', 'du_lich', 'dau_tu_lon', 'quan_ly_dau_tu', 'khoi_nghiep', 'mua_bao_hiem', 'gui_bo_me', 'tu_thien', 'kham', 'chi_tieu', 'vay_tien', 'tra_no', 'ban_tai_san', 've_so'];
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
