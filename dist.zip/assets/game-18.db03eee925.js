/* ===== js/life80.js ===== */
/* Một Đời — v6.3.0:
   · quay lại với người yêu cũ / vợ cũ / chồng cũ (có con chung thì dễ gặp lại hơn)
   · người giàu có thể chủ động chu cấp cho người yêu, hoặc tìm một mối quan hệ mình là người chu cấp
   · tiến độ thăng chức: số năm còn thiếu, cơ hội mỗi năm và lý do; khi được thăng chức nhật ký ghi rõ vì sao */
(function (G) {
  'use strict';
  var U = G.U, E = G.E, H = E.H, SC = E.SC, isVN = H.isVN;
  function fx(l, o) { H.fx(l, o); }
  function stress(l, d) { if (l.mind) l.mind.stress = U.clamp(l.mind.stress + d, 0, 100); }
  function vnd(l) { return isVN(l) && l.cur === 'vnd' && !(l.abroad && l.abroad.perm); }
  function V(l, tr) { return vnd(l) ? tr : tr / 90 * l.base; }
  function mo(l, v) { return H.money(l, v); }
  function free(l) { return l.alive && !(l.jailUntil != null && l.age < l.jailUntil) && !(l.abroad && l.abroad.trapped) && !(l.flags.military && l.age < l.flags.military); }
  function A(id, g, label, o) { var x = { id: id, g: g, l: label }; for (var k in o) x[k] = o[k]; E.ACT.push(x); }
  function T(id, when, p, cd, max) { E.TRIG.push({ id: id, when: function (l, a) { return free(l) && when(l, a); }, p: p, cd: cd || 4, max: max || 3 }); }

  // ===================================================================
  // 1. NGƯỜI CŨ: ghi nhớ và có thể quay lại
  // ===================================================================
  function exes(l) { return l.flags.exList || (l.flags.exList = []); }
  function exWord(l, x) { return x.married ? (x.sex === l.sex ? 'người bạn đời cũ' : x.sex === 'M' ? 'chồng cũ' : 'vợ cũ') : 'người yêu cũ'; }
  function sharedKids(l, x) { return (l.kids || []).filter(function (k) { return k.alive !== false && (k.otherParent === x.name || (x.since != null && k.born >= x.since && k.born <= (x.until != null ? x.until : l.age) && !k.adopted)); }); }
  E.HOOKS.year.unshift(function (l, r, log, a) {
    if (!l.alive) return;
    var p = l.partner, prev = l.flags.lastP;
    if (prev && (!p || p.name !== prev.name)) {
      var widowed = p && p.name === prev.name && p.alive === false;
      if (!widowed && !prev.dead && !(E.isDeadPartner && E.isDeadPartner(l, prev))) { /* v7.2: người đã mất không thành "người cũ" */ var L = exes(l); if (!L.some(function (x) { return x.name === prev.name; })) L.push({ name: prev.name, sex: prev.sex, d: prev.d, married: prev.married, since: prev.since, until: a, inc: prev.inc, job: prev.job }); if (L.length > 6) L.shift(); }
    }
    l.flags.lastP = p && p.alive !== false ? { name: p.name, sex: p.sex, d: (p.age || a) - a, married: p.status === 'married', since: p.since, inc: p.inc, job: p.job } : null;
    if (p && p.alive === false && prev) prev.dead = true;
  });
  function candidates(l) { if (l.partner || l.age < 18) return []; return exes(l).filter(function (x) { return !x.closed && !x.dead && !(E.isDeadPartner && E.isDeadPartner(l, x)) && l.age - (x.until || l.age) >= 1 && l.age + (x.d || 0) <= 85; }); }
  SC('quay_lai_cu', {
    title: function (l, d) { return 'Gặp lại ' + d.word; },
    prep: function (l, r) { var C = candidates(l); C.sort(function (a, b) { return sharedKids(l, b).length - sharedKids(l, a).length; }); var x = C.length ? (sharedKids(l, C[0]).length && r() < 0.7 ? C[0] : U.pick(r, C)) : null; return x ? { n: x.name, word: exWord(l, x), kids: sharedKids(l, x).map(function (k) { return k.name; }) } : {}; },
    valid: function (l, d) { return candidates(l).some(function (x) { return !d || !d.n || x.name === d.n; }); },
    text: function (l, d) { var x = exes(l).filter(function (e) { return e.name === d.n; })[0], y = x ? l.age - x.until : 0; return (d.kids.length ? 'Mỗi lần đưa đón con (' + d.kids.join(', ') + '), bạn lại gặp ' + d.n + ' — ' + d.word + '. ' : 'Sau ' + y + ' năm, ' + d.n + ' — ' + d.word + ' — bất ngờ nhắn tin hỏi thăm. ') + 'Hai người nói chuyện lâu hơn mọi lần, những chuyện cũ tưởng đã quên lại hiện về.'; },
    opts: [
      { k: 'quay_lai', l: 'Cho nhau thêm một cơ hội', ai: { w: 0.8 }, run: function (l, r, log, d) {
        var x = exes(l).filter(function (e) { return e.name === d.n; })[0]; if (!x || l.partner) return;
        var p = 0.45 + (d.kids.length ? 0.2 : 0) - (l.age - x.until > 10 ? 0.15 : 0);
        if (r() < p) { var np = { name: x.name, sex: x.sex, age: l.age + (x.d || 0), status: 'dating', since: l.age, alive: true, inc: x.inc, job: x.job, reunited: true }; if (H.partnerJob && !np.job) H.partnerJob(l, np, r); l.partner = np; x.closed = true; fx(l, { hap: 8 }); log('Bạn và ' + x.name + ' quyết định quay lại với nhau. ' + (d.kids.length ? 'Các con vui nhất nhà khi thấy bố mẹ lại đi chung.' : 'Lần này cả hai đều trưởng thành hơn.') + (x.married ? ' Hai người tính chuyện tái hôn khi mọi thứ ổn định.' : ''), 'big'); H.mem(l, 'Ngày quay lại với ' + x.name + '.', 4); }
        else { x.closed = true; fx(l, { hap: -3 }); log('Gặp lại vài lần, bạn và ' + x.name + ' nhận ra mọi thứ đã khác. Hai người chúc nhau bình yên.', 'neutral'); }
      } },
      { k: 'ban', l: function (l, d) { return d.kids.length ? 'Chỉ làm bạn, cùng nhau chăm con' : 'Chỉ làm bạn, hỏi thăm nhau'; }, ai: { w: 1 }, run: function (l, r, log, d) { (l.kids || []).forEach(function (k) { if (d.kids.indexOf(k.name) >= 0) k.close = U.clamp((k.close || 50) + 4, 0, 100); }); fx(l, { hap: 2 }); log(d.kids.length ? 'Bạn và ' + d.n + ' giữ quan hệ bạn bè, cùng đi họp phụ huynh, cùng tổ chức sinh nhật cho con.' : 'Bạn và ' + d.n + ' thỉnh thoảng hỏi thăm nhau như những người bạn cũ.', 'neutral'); } },
      { k: 'khep', l: 'Khép lại quá khứ', ai: { w: 0.7 }, run: function (l, r, log, d) { var x = exes(l).filter(function (e) { return e.name === d.n; })[0]; if (x) x.closed = true; log('Bạn cảm ơn ' + d.n + ' vì những ngày đã qua, rồi khép lại câu chuyện cũ.', 'neutral'); } }
    ]
  });
  T('quay_lai_cu', function (l) { return candidates(l).length > 0; }, 0.08, 4, 3);
  A('lien_lac_nguoi_cu', 'Tình cảm', 'Liên lạc lại với người cũ', { min: 18, sc: 'quay_lai_cu', avail: function (l) { return l.partner ? 'Đang có người yêu / bạn đời' : candidates(l).length ? true : 'Chưa có người cũ để liên lạc'; }, ai: { w: 0.02 } });

  // ===================================================================
  // 2. NGƯỜI GIÀU CHỦ ĐỘNG CHU CẤP
  // ===================================================================
  function rich(l) { return l.indep && l.age >= 25 && (l.money >= l.base * 40 || (l.income || 0) >= l.base * 4); }
  function giving(l) { var g = l.flags.giveSup; return g && l.partner && l.partner.name === g.name && l.partner.alive !== false ? g : null; }
  var LEVEL = [['it', 'Gửi một khoản nhỏ mỗi tháng', 10], ['vua', 'Lo tiền nhà, tiền sinh hoạt', 30], ['nhieu', 'Bao trọn chi tiêu, quà cáp', 80]];
  function startGive(l, log, k) { var x = LEVEL.filter(function (y) { return y[0] === k; })[0]; l.flags.giveSup = { name: l.partner.name, monthly: V(l, x[2]), since: l.age }; l.partner.close = U.clamp((l.partner.close || 60) + 6, 0, 100); log('Bạn bắt đầu chu cấp cho ' + l.partner.name + ' khoảng ' + mo(l, V(l, x[2])) + '/tháng.', 'neutral'); }
  SC('chu_cap_nguoi_yeu', {
    title: 'Chu cấp cho người yêu', valid: function (l) { return rich(l) && !!l.partner && l.partner.alive !== false && !giving(l); },
    text: function (l) { var p = l.partner; return p.name + ' thu nhập ' + (p.inc ? 'khoảng ' + mo(l, p.inc) + '/tháng' : 'không nhiều') + ', còn bạn dư dả. Bạn muốn chủ động lo cho người ấy?'; },
    opts: LEVEL.map(function (x) { return { k: x[0], l: x[1], h: function (l) { return 'Khoảng ' + mo(l, V(l, x[2])) + '/tháng'; }, ai: { w: x[0] === 'vua' ? 1 : 0.6 }, run: function (l, r, log) { startGive(l, log, x[0]); } }; })
      .concat([{ k: 'khong', l: 'Không, mỗi người tự lo tài chính', ai: { w: 1 }, run: function (l, r, log) { log('Hai người vẫn tự lo tài chính riêng, thỉnh thoảng bạn mời đi ăn, tặng quà.', 'neutral'); } }])
  });
  SC('tim_nguoi_cham_lo', {
    title: 'Một mối quan hệ do bạn chu cấp', valid: function (l) { return rich(l) && !l.partner && l.age >= 30; },
    prep: function (l, r) { var s = H.partnerSex(l, r); return { n: H.stranger(l, r, s), s: s, age: Math.max(20, l.age - U.randint(r, 6, 18)) }; },
    text: function (l, d) { return 'Qua một buổi tiệc, bạn quen ' + d.n + ' (' + d.age + ' tuổi), đang chật vật với tiền thuê nhà. Bạn bè nói người như bạn chỉ cần "lo cho người ta" là có người bên cạnh.'; },
    opts: [
      { k: 'cham_lo', l: 'Tìm hiểu và chủ động lo chi tiêu cho người ấy', h: function (l) { return 'Khoảng ' + mo(l, V(l, 30)) + '/tháng'; }, ai: { w: 0.5 }, run: function (l, r, log, d) { l.partner = { name: d.n, sex: d.s, age: d.age, status: 'dating', since: l.age, alive: true, sponsored: true }; if (H.partnerJob) H.partnerJob(l, l.partner, r); l.flags.everDated = true; startGive(l, log, 'vua'); fx(l, { hap: 4 }); } },
      { k: 'ban', l: 'Chỉ làm bạn, giúp người ấy tìm việc', ai: { w: 1, karma: 1 }, run: function (l, r, log, d) { fx(l, { karma: 3 }); log('Bạn giới thiệu cho ' + d.n + ' một công việc ổn định, không ràng buộc gì.', 'good'); } },
      { k: 'khong', l: 'Không, muốn tình cảm thật lòng', ai: { w: 1 }, run: function (l, r, log) { log('Bạn muốn một mối quan hệ không dính đến tiền bạc.', 'neutral'); } }
    ]
  });
  T('chu_cap_nguoi_yeu', function (l) { return rich(l) && !!l.partner && l.partner.status === 'dating' && !giving(l) && (l.partner.inc || 0) * 12 < (l.income || 0) / 3; }, 0.12, 5, 2);
  T('tim_nguoi_cham_lo', function (l) { return rich(l) && !l.partner && l.age >= 30 && l.age <= 65; }, 0.04, 6, 2);
  A('chu_cap', 'Tình cảm', 'Chu cấp cho người yêu / bạn đời', { min: 25, sc: 'chu_cap_nguoi_yeu', avail: function (l) { return !rich(l) ? 'Cần dư dả tài chính' : !l.partner ? 'Chưa có người yêu / bạn đời' : giving(l) ? 'Đang chu cấp ' + mo(l, giving(l).monthly) + '/tháng' : true; }, ai: { w: 0.02 } });
  SC('chu_cap_dung', {
    title: 'Khoản chu cấp', valid: function (l) { return !!giving(l); },
    text: function (l) { var g = giving(l); return 'Bạn đang chu cấp cho ' + g.name + ' khoảng ' + mo(l, g.monthly) + '/tháng.'; },
    opts: [{ k: 'giu', l: 'Tiếp tục như cũ', ai: { w: 1 }, run: function () { } }, { k: 'dung', l: 'Dừng chu cấp, mỗi người tự lo', ai: { w: 0.3 }, run: function (l, r, log) { var g = giving(l); l.flags.giveSup = null; log('Bạn nói chuyện thẳng thắn với ' + g.name + ' và dừng khoản chu cấp.', 'neutral'); if (r() < 0.3 && l.partner) { var n = l.partner.name; l.partner = null; l.exes = (l.exes || 0) + 1; log(n + ' không chấp nhận, hai người chia tay.', 'bad'); } } }]
  });
  A('chu_cap_dung', 'Tình cảm', 'Xem / dừng khoản chu cấp', { min: 25, sc: 'chu_cap_dung', avail: function (l) { return giving(l) ? true : 'Không áp dụng'; }, ai: { w: 0.01 } });
  E.HOOKS.year.unshift(function (l, r, log, a) {
    var g = giving(l); if (!g) { if (l.flags.giveSup && !(l.partner && l.partner.name === l.flags.giveSup.name)) l.flags.giveSup = null; return; }
    if (g.paidAt === a || !free(l)) return; g.paidAt = a;
    var y = g.monthly * 12;
    if (!rich(l) || l.money < y) { l.flags.giveSup = null; log('Tài chính không còn dư dả như trước, bạn nói thật với ' + g.name + ' và dừng khoản chu cấp.', 'neutral'); if (r() < 0.4 && l.partner) { var nn = l.partner.name; l.partner = null; l.exes = (l.exes || 0) + 1; log(nn + ' không chấp nhận, hai người chia tay.', 'bad'); } return; }
    H.cash(l, -y, 'Chu cấp cho ' + g.name); g.base0 = g.base0 || g.monthly;
    var x = r();
    if (x < 0.1 && g.monthly < g.base0 * 2) { g.monthly = Math.min(g.base0 * 2, g.monthly * 1.4); stress(l, 4); log(g.name + ' bắt đầu đòi hỏi nhiều hơn: túi hiệu, chuyến du lịch, căn hộ riêng. Khoản chu cấp tăng lên ' + mo(l, g.monthly) + '/tháng.', 'neutral'); }
    else if (x < 0.15 && l.partner) { var n = l.partner.name; l.partner = null; l.flags.giveSup = null; l.exes = (l.exes || 0) + 1; fx(l, { hap: -8 }); log('Bạn phát hiện ' + n + ' vừa nhận tiền của bạn vừa qua lại với người khác. Hai người chia tay.', 'bad'); H.mem(l, 'Ngày nhận ra ' + n + ' chỉ yêu tiền của mình.', 3); }
    else if (a - g.since === 1) log('Một năm lo cho ' + g.name + ' (' + mo(l, y) + '). Người ấy chăm sóc bạn chu đáo, nhưng đôi lúc bạn tự hỏi đâu là tình cảm thật.', 'neutral');
  });

  // ===================================================================
  // 3. TIẾN ĐỘ THĂNG CHỨC
  // ===================================================================
  E.promoProgress = function (l) {
    if (!l.job || l.retired) return null;
    var c = E.jobDef(l); if (!c || c.fame || c.skillRank != null || !c.t || c.t.length < 2) return null;
    if (E.isFreelanceJob && E.isFreelanceJob(l)) return null;
    var rk = l.job.rank || 0; if (rk >= c.t.length - 1) return { top: true, title: c.t[rk] };
    var need = (c.yrs && c.yrs[rk]) || 3, done = Math.min(need, l.job.yrs || 0), focus = l.focus;
    var pp = c.ladder ? (rk >= 7 ? 0.04 + (l.st.kno - 70) / 300 : 0.85 - (l.karma < -20 ? 0.4 : 0)) : (c.promo || 0.2) + (l.st.kno - 50) / 250 + (focus === 'work' ? 0.12 : focus === 'balance' ? 0.06 : 0) + (((l.tr && l.tr.amb) || 50) - 50) / 300 + (l.talent === 'ăn nói' ? 0.04 : 0) - rk * 0.06;
    var why = [];
    why.push(done >= need ? 'đã đủ ' + need + ' năm ở vị trí hiện tại' : 'cần thêm ' + (need - done) + ' năm ở vị trí hiện tại (' + done + '/' + need + ')');
    if (!c.ladder) {
      why.push((l.st.kno >= 70 ? 'kiến thức tốt (+)' : l.st.kno < 45 ? 'kiến thức còn yếu (−)' : 'kiến thức trung bình'));
      why.push(focus === 'work' ? 'đang tập trung công việc (+)' : focus === 'balance' ? 'đang cân bằng (+ ít)' : 'chưa tập trung công việc — chọn trọng tâm "Công việc" để tăng cơ hội');
      if (rk >= 2) why.push('chức càng cao càng khó lên (−)');
    } else if (l.karma < -20) why.push('kỷ luật, tác phong chưa tốt (−)');
    return { next: c.t[rk + 1], need: need, done: done, pct: Math.round(done / need * 100), chance: done >= need ? U.clamp(pp, 0.02, 0.95) : 0, why: why, ladder: !!c.ladder };
  };
  E.HOOKS.year.unshift(function (l, r, log, a) { // đầu danh sách: độc lập với các hook khác
    if (!l.job) { l.flags.rankSeen = null; return; }
    var S = l.flags.rankSeen, id = E.resolveJob(l.job.id), rk = l.job.rank || 0;
    if (S && S.id === id && rk > S.rk && !l.job.fam) { var c = E.jobDef(l); if (c && !c.fame && c.skillRank == null) { var why = []; why.push('đủ ' + (S.need || 3) + ' năm kinh nghiệm ở vị trí cũ'); if (l.st.kno >= 70) why.push('kiến thức vững'); if (l.focus === 'work') why.push('tập trung cho công việc'); if ((l.job.rep || 50) >= 65) why.push('uy tín tốt trong nghề'); log('Lý do được thăng chức: ' + why.join(', ') + '.', 'neutral'); } }
    var cc = E.jobDef(l); l.flags.rankSeen = { id: id, rk: rk, need: cc && cc.yrs ? cc.yrs[rk] || 3 : 3 };
  });
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
/* ===== js/life81.js ===== */
/* Một Đời — v6.4.0: những cuộc đời không màu hồng
   · một phần nhỏ các cuộc đời (nhiều hơn ở nhà nghèo, vùng quê) gặp "vận đen": rớt trường năng khiếu, bỏ học đi làm công nhân,
     xin việc mãi không được, lên thành phố lập nghiệp, tăng ca triền miên, ngoài 35 bị cho nghỉ, bị nợ lương, tai nạn lao động,
     vay nợ chữa bệnh cho người thân, về già không lương hưu…
   · không báo trước là "vận đen" — chỉ là những chuyện khó khăn đến thường hơn; mỗi chuyện chỉ gặp một, hai lần trong đời */
(function (G) {
  'use strict';
  var U = G.U, E = G.E, H = E.H, SC = E.SC, isVN = H.isVN;
  function fx(l, o) { H.fx(l, o); }
  function stress(l, d) { if (l.mind) l.mind.stress = U.clamp(l.mind.stress + d, 0, 100); }
  function ch(r, p) { return r() < p; }
  function vnd(l) { return isVN(l) && l.cur === 'vnd' && !(l.abroad && l.abroad.perm); }
  function V(l, tr) { return vnd(l) ? tr : tr / 90 * l.base; }
  function mo(l, v) { return H.money(l, v); }
  function free(l) { return l.alive && !(l.jailUntil != null && l.age < l.jailUntil) && !(l.abroad && l.abroad.trapped) && !(l.flags.military && l.age < l.flags.military); }
  function pw(l) { var f = l.fam || {}, m = !f.noMom && f.mAlive, b = !f.noDad && f.fAlive; return m && b ? 'bố mẹ' : m ? 'mẹ' : b ? 'bố' : ''; }
  function jid(l) { return l.job ? E.resolveJob(l.job.id) : ''; }
  function worker(l) { return /^(cong_nhan|phu_ho|tho_may|tho_han|tho_dien|tho_moc|tho_mo|tho_sua_xe|bao_ve|giup_viec|phuc_vu)$/.test(jid(l)); }
  function poor(l) { return l.indep ? (l.income || 0) < l.base * 1.1 && l.money < l.base * 2 : (l.fam && l.fam.q <= 2); }
  function hard(l) { return l.flags.hardLot === true; }
  function P(base, k) { return function (l) { return base * (hard(l) ? (k || 4) : 1); }; }
  function T(id, when, p, cd, max) { E.TRIG.push({ id: id, when: function (l, a) { return free(l) && isVN(l) && when(l, a); }, p: p, cd: cd || 4, max: max || 1 }); }
  function city(l, r) { return U.pick(r, ['Đà Nẵng', 'TP. Hồ Chí Minh', 'Bình Dương', 'Hà Nội', 'Bắc Ninh']); }
  function moveTo(l, c) { l.urban = true; l.movedTo = c; l.place = c; l.city = c; }
  function work(l, r, log, id) { if (E.startJob) E.startJob(l, id, r, log); }

  // ai sẽ gặp "vận đen": nhà càng nghèo, ở quê càng dễ gặp (người chơi không được báo)
  E.HOOKS.year.unshift(function (l, r, log, a) {
    if (l.flags.hardLot != null || a < 10 || !isVN(l)) return;
    var f = l.fam || {}; if (f.elite) { l.flags.hardLot = false; return; }
    var p = [0.3, 0.3, 0.2, 0.1, 0.05, 0.02][f.q || 3] * (l.urban ? 0.8 : 1.3);
    l.flags.hardLot = r() < p;
  });

  // 1. Trường năng khiếu
  SC('vd_nang_khieu', {
    title: 'Trường năng khiếu của tỉnh', valid: function (l) { return !!l.school && l.age >= 13 && l.age <= 16 && !l.flags.vdNk; },
    text: function (l) { return 'Thầy thể dục giới thiệu bạn thi vào trường năng khiếu thể thao của tỉnh: ở nội trú, tập luyện cả ngày, học văn hóa buổi tối. ' + (l.fam && l.fam.q <= 2 ? 'Nhà nghèo, ' + (pw(l) || 'gia đình') + ' mong bạn có một con đường khác ruộng đồng.' : U.cap(pw(l) || 'gia đình') + ' còn đắn đo.'); },
    opts: [
      { k: 'di', l: 'Vào trường năng khiếu, theo đuổi thể thao', ai: { w: 0.8, amb: 1.2 }, run: function (l, r, log) { l.flags.vdNk = l.age; log('Bạn khăn gói vào trường năng khiếu của tỉnh, sáng tập chiều tập, tối học văn hóa.', 'neutral'); H.sched(l, 'vd_nang_khieu_kq', 2); } },
      { k: 'o', l: 'Ở lại học văn hóa như bình thường', ai: { w: 1 }, run: function (l, r, log) { l.flags.vdNk = -1; log('Bạn ở lại trường cũ, học văn hóa như các bạn.', 'neutral'); } }
    ]
  });
  T('vd_nang_khieu', function (l, a) { return a >= 13 && a <= 15 && !!l.school && !l.flags.vdNk && (l.talent === 'thể thao' || (l.st.hea >= 80 && !l.urban)); }, P(0.12, 2), 3, 1);
  SC('vd_nang_khieu_kq', {
    title: 'Sau hai năm ở trường năng khiếu', valid: function (l) { return l.flags.vdNk > 0 && l.alive; },
    prep: function (l, r) { var win = r() < (hard(l) ? 0.12 : 0.35) + (l.talent === 'thể thao' ? 0.15 : 0); l.flags.vdNkOk = win; return { win: win }; },
    text: function (l, d) { return d.win ? 'Bạn được giữ lại đội tuyển trẻ của tỉnh, có trợ cấp tập luyện.' : U.pick(H.rf(l), ['Chấn thương dây chằng đầu gối, bạn không được giữ lại đội. Hai năm học văn hóa buổi tối, kiến thức hổng một mảng lớn.', 'Đợt sàng lọc cuối năm, bạn không lọt vào danh sách giữ lại. Rời trường năng khiếu, chương trình văn hóa đã bỏ quá xa.']) + (d.win ? '' : ' Giờ tính sao?'); },
    opts: [
      { k: 'tiep', l: 'Tiếp tục tập luyện ở đội tuyển', req: function (l, d) { return d.win; }, ai: { w: 1 }, run: function (l, r, log) { if (l.talent === 'thể thao') l.skill = Math.min(100, (l.skill || 30) + 10); fx(l, { hap: 6, hea: 2 }); log('Bạn được giữ lại đội tuyển trẻ, ngày ngày tập luyện chờ cơ hội thi đấu.', 'good'); } },
      { k: 'cong_nhan', l: 'Nghỉ học, đi làm công nhân luôn', req: function (l, d) { return !d.win; }, ai: { w: 1.2 }, run: function (l, r, log) { l.school = null; l.schoolEnd = null; l.edu = Math.max(l.edu || 0, 2); l.indep = true; work(l, r, log, 'cong_nhan'); fx(l, { hap: -6 }); log('Bạn bỏ học, theo người quen vào khu công nghiệp làm công nhân. Năm ấy bạn mới ' + l.age + ' tuổi.', 'bad'); H.mem(l, 'Ngày rời trường năng khiếu, cất đôi giày tập vào gầm giường.', 4); } },
      { k: 'hoc_lai', l: 'Xin học lại bổ túc văn hóa', req: function (l, d) { return !d.win; }, ai: { w: 0.8, smart: 1.2 }, run: function (l, r, log) { l.school = 'upper'; l.schoolEnd = l.age + 2; fx(l, { kno: 2, hap: -2 }); log('Bạn xin học bổ túc văn hóa, học cùng lớp với những bạn nhỏ hơn mình hai tuổi.', 'neutral'); } },
      { k: 'phu', l: 'Về nhà phụ ' + 'gia đình làm ruộng', req: function (l, d) { return !d.win; }, ai: { w: 0.6 }, run: function (l, r, log) { l.school = null; l.schoolEnd = null; l.edu = Math.max(l.edu || 0, 2); work(l, r, log, 'phu_giup'); fx(l, { hap: -5 }); log('Bạn về quê phụ gia đình làm ruộng, chiều chiều nhìn bạn bè đạp xe đi học.', 'bad'); } }
    ]
  });

  // 2. Xin việc mãi không được
  SC('vd_xin_viec', {
    title: 'Xin việc mãi không được', valid: function (l) { return !l.job && !l.school && l.age >= 18 && l.age <= 35 && !l.retired; },
    text: function (l) { return 'Mấy tháng nay bạn nộp hồ sơ khắp nơi ở ' + (l.urban ? 'thành phố' : 'huyện') + ', chỗ thì chê không có bằng cấp, chỗ thì bảo "khi nào cần sẽ gọi". Tiền trong túi cạn dần.'; },
    opts: [
      { k: 'ra_tp', l: 'Khăn gói lên thành phố lập nghiệp', req: function (l) { return !l.urban || !l.movedTo; }, h: function (l) { return 'Tiền xe, tiền trọ tháng đầu khoảng ' + mo(l, V(l, 4)); }, ai: { w: 1.1, amb: 1.2 }, run: function (l, r, log) { var c = city(l, r); H.cash(l, -V(l, 4), 'Lên ' + c + ' lập nghiệp'); moveTo(l, c); l.indep = true; if (r() < 0.65) { var j = U.pick(r, ['cong_nhan', 'phuc_vu', 'shipper', 'bao_ve']); work(l, r, log, j); log('Bạn bắt xe khách lên ' + c + ', thuê phòng trọ 12 m², mấy tuần sau xin được việc ' + (E.jobTitle && l.job ? E.jobTitle(l) : 'làm thuê') + '.', 'neutral'); } else { fx(l, { hap: -6 }); stress(l, 8); log('Bạn lên ' + c + ' lập nghiệp, nhưng mấy tháng vẫn chưa xin được việc ổn định, sống nhờ những ca làm thời vụ.', 'bad'); } H.mem(l, 'Chuyến xe khách đêm lên ' + c + ' với một ba lô quần áo.', 3); } },
      { k: 'kcn', l: 'Vào khu công nghiệp làm công nhân', ai: { w: 1 }, run: function (l, r, log) { l.indep = true; work(l, r, log, 'cong_nhan'); log('Bạn xin vào làm công nhân ở khu công nghiệp, lương cơ bản cộng tăng ca.', 'neutral'); } },
      { k: 'xkld', l: 'Đăng ký đi xuất khẩu lao động', req: function () { return !!E.DEC.xkld; }, ai: { w: 0.6, risk: 1 }, run: function (l, r) { l.pending.unshift(E.DEC.xkld.make(l, r, true)); } },
      { k: 'cho', l: 'Ở nhà chờ thêm', ai: { w: 0.4 }, run: function (l, r, log) { fx(l, { hap: -4 }); stress(l, 5); log('Bạn ở nhà chờ, ngày ngày lướt mạng tìm việc, nghe hàng xóm hỏi "bao giờ đi làm?"', 'bad'); } }
    ]
  });
  T('vd_xin_viec', function (l, a) { return !l.job && !l.school && a >= 18 && a <= 35 && !l.retired && (l.edu || 0) <= 3; }, P(0.15, 2.5), 3, 2);

  // 3. Đời công nhân
  SC('vd_tang_ca', {
    title: 'Tăng ca mùa cao điểm', valid: worker,
    text: 'Tháng cao điểm đơn hàng, xưởng tăng ca đến 10 giờ đêm, cả tháng không có ngày nghỉ. Lương cơ bản không đủ sống, ai cũng trông vào tiền tăng ca.',
    opts: [
      { k: 'het', l: 'Tăng ca hết mức', h: function (l) { return 'Thêm ~' + mo(l, V(l, 4)) + '/tháng, rất mệt'; }, ai: { w: 1, amb: 1 }, run: function (l, r, log) { H.cash(l, V(l, 12), 'Tiền tăng ca'); fx(l, { hea: -4, hap: -2 }); stress(l, 8); log(U.pick(r, ['Ba tháng tăng ca liên tục, về phòng trọ là ngủ gục, gầy rộc đi mấy cân.', 'Tăng ca đến khuya, sáng 6 giờ lại vào ca, tay chân lúc nào cũng rã rời.']), 'neutral'); } },
      { k: 'vua', l: 'Tăng ca vừa sức', ai: { w: 1.1 }, run: function (l, r, log) { H.cash(l, V(l, 5), 'Tiền tăng ca'); fx(l, { hea: -1 }); log('Bạn tăng ca vừa phải, cuối tuần vẫn giữ một ngày nghỉ.', 'neutral'); } },
      { k: 'khong', l: 'Không tăng ca, giữ sức khỏe', ai: { w: 0.5 }, run: function (l, r, log) { if (l.job) l.job.rep = U.clamp((l.job.rep || 50) - 3, 0, 100); log('Bạn không tăng ca. Tổ trưởng không vui, tháng đó lương chỉ đủ tiền trọ và tiền ăn.', 'neutral'); } }
    ]
  });
  T('vd_tang_ca', worker, P(0.12, 2), 3, 2);
  SC('vd_qua_35', {
    title: 'Ngoài 35 tuổi', valid: function (l) { return jid(l) === 'cong_nhan' && l.age >= 35; },
    text: 'Nhà máy cắt giảm, ưu tiên giữ công nhân trẻ. Bạn đã ngoài 35, tên nằm trong danh sách cho nghỉ. Đi xin việc ở xưởng khác, chỗ nào cũng tuyển dưới 35 tuổi.',
    opts: [
      { k: 'xe_om', l: 'Chạy xe ôm công nghệ', req: function (l) { return !!l.veh; }, ai: { w: 1 }, run: function (l, r, log) { work(l, r, log, 'tx_cn'); log('Bạn đăng ký chạy xe công nghệ, nắng mưa ngoài đường từ sáng đến tối.', 'neutral'); fx(l, { hap: -3 }); } },
      { k: 'ban', l: 'Bán hàng rong, buôn bán nhỏ', ai: { w: 0.9 }, run: function (l, r, log) { work(l, r, log, 'ban_rong'); log('Bạn mua chiếc xe đẩy cũ, sáng bán xôi, chiều bán nước mía.', 'neutral'); fx(l, { hap: -3 }); } },
      { k: 've_que', l: 'Về quê làm ruộng', ai: { w: 0.7 }, run: function (l, r, log) { l.urban = false; l.movedTo = null; work(l, r, log, 'nong'); log('Bạn khăn gói về quê sau bao năm ở trọ, ra đồng làm ruộng như ' + (pw(l) || 'người trong làng') + '.', 'neutral'); } },
      { k: 'tim', l: 'Tìm xưởng nhỏ khác chịu nhận', ai: { w: 0.8 }, run: function (l, r, log) { if (r() < 0.5) { work(l, r, log, 'cong_nhan'); if (l.job) l.job.rank = 0; log('Một xưởng nhỏ chịu nhận bạn, lương thấp hơn chỗ cũ, không có bảo hiểm.', 'neutral'); } else { l.job = null; l.flags.needJob = true; fx(l, { hap: -6 }); stress(l, 8); log('Hỏi khắp các xưởng, chỗ nào cũng lắc đầu. Bạn ở nhà, sống bằng chút tiền trợ cấp thất nghiệp.', 'bad'); } } }
    ]
  });
  T('vd_qua_35', function (l, a) { return jid(l) === 'cong_nhan' && a >= 35 && a <= 50; }, P(0.08, 3), 5, 1);
  E.DEC.vd_qua_35 && (function () { var ap = E.DEC.vd_qua_35.apply; E.DEC.vd_qua_35.apply = function (l) { if (jid(l) === 'cong_nhan') { l.lastJob = l.job; l.job = null; } return ap.apply(this, arguments); }; })();
  SC('vd_no_luong', {
    title: 'Chủ xưởng bỏ trốn', valid: worker,
    text: 'Sáng đi làm, cổng xưởng khóa chặt. Chủ xưởng ôm tiền bỏ trốn, nợ cả trăm công nhân hai tháng lương.',
    opts: [
      { k: 'kien_nghi', l: 'Cùng anh chị em công nhân làm đơn lên cơ quan lao động', ai: { w: 1.1 }, run: function (l, r, log) { if (r() < 0.4) { H.cash(l, V(l, 6), 'Truy lĩnh một phần tiền lương'); log('Mấy tháng sau, cơ quan chức năng phát mại máy móc, mỗi người được trả lại một phần tiền lương.', 'neutral'); } else { fx(l, { hap: -6 }); log('Đơn từ gửi đi khắp nơi, chủ xưởng vẫn chưa tìm thấy. Hai tháng lương coi như mất.', 'bad'); } l.job = null; l.flags.needJob = true; } },
      { k: 'tim', l: 'Đi tìm việc mới ngay', ai: { w: 0.9 }, run: function (l, r, log) { l.job = null; l.flags.needJob = true; fx(l, { hap: -5 }); log('Bạn chấp nhận mất hai tháng lương, sáng hôm sau đã đi xin việc ở xưởng khác.', 'bad'); } }
    ]
  });
  T('vd_no_luong', worker, P(0.03, 4), 6, 1);
  SC('vd_tai_nan_ld', {
    title: 'Tai nạn lao động', valid: worker,
    text: function (l) { return jid(l) === 'phu_ho' ? 'Giàn giáo bị sập, bạn ngã từ tầng hai xuống.' : 'Máy dập bị kẹt, bạn đưa tay vào gỡ thì máy chạy lại.'; },
    opts: [
      { k: 'vien', l: 'Đi viện, đòi chủ bồi thường theo luật', ai: { w: 1.1 }, run: function (l, r, log) { fx(l, { hea: -12, hap: -6 }); if (E.medBill) E.medBill(l, V(l, 25), 'Điều trị tai nạn lao động', log, 1); if (r() < 0.6) { H.cash(l, V(l, 20), 'Bồi thường tai nạn lao động'); log('Chủ xưởng chịu bồi thường theo luật sau nhiều lần đôi co.', 'neutral'); } else log('Chủ xưởng chỉ hỗ trợ vài triệu rồi lảng tránh, bạn không có hợp đồng nên khó đòi.', 'bad'); H.mem(l, 'Vết sẹo từ tai nạn ở xưởng năm ' + l.age + ' tuổi.', 4); } },
      { k: 'nhan', l: 'Nhận vài triệu "hỗ trợ" rồi thôi', ai: { w: 0.7 }, run: function (l, r, log) { fx(l, { hea: -14, hap: -8 }); H.cash(l, V(l, 5), 'Hỗ trợ tai nạn'); log('Bạn nhận vài triệu "hỗ trợ", tự lo phần còn lại. Bàn tay về sau cầm nắm không còn khéo như trước.', 'bad'); } }
    ]
  });
  T('vd_tai_nan_ld', worker, P(0.025, 3), 8, 1);
  SC('vd_benh_nghe', {
    title: 'Bệnh nghề nghiệp', valid: function (l) { return worker(l) && (l.job.yrs || 0) >= 8; },
    text: 'Bao năm hít bụi vải, bụi gỗ trong xưởng, bạn ho kéo dài mấy tháng không dứt. Bác sĩ nghi bệnh phổi nghề nghiệp.',
    opts: [
      { k: 'kham', l: 'Đi khám, xin đổi sang khâu ít bụi', ai: { w: 1.1 }, run: function (l, r, log) { if (E.medBill) E.medBill(l, V(l, 3), 'Khám bệnh nghề nghiệp', log, 1); fx(l, { hea: -3 }); log('Bạn được chẩn đoán viêm phổi do bụi, xin đổi sang khâu đóng gói.', 'neutral'); } },
      { k: 'chiu', l: 'Uống thuốc, làm tiếp vì cần tiền', ai: { w: 0.8 }, run: function (l, r, log) { fx(l, { hea: -8 }); log('Bạn uống thuốc rồi đi làm tiếp. Cơn ho cứ kéo dài, đêm nào cũng trằn trọc.', 'bad'); } }
    ]
  });
  T('vd_benh_nghe', function (l) { return worker(l) && (l.job.yrs || 0) >= 8; }, P(0.03, 3), 8, 1);

  // 4. Nợ nần vì người thân
  SC('vd_vay_chua_benh', {
    title: function (l) { return U.cap(pw(l) || 'người thân') + ' ốm nặng'; }, valid: function (l) { return !!pw(l) && l.indep && l.age >= 20; },
    text: function (l) { return U.cap(pw(l)) + ' nhập viện, bác sĩ nói phải mổ gấp, chi phí ngoài bảo hiểm khoảng ' + mo(l, V(l, 60)) + '. Tiền tiết kiệm của bạn không đủ.'; },
    opts: [
      { k: 'ho_hang', l: 'Vay họ hàng, anh em', ai: { w: 1.1 }, run: function (l, r, log) { if (H.addLoan) H.addLoan(l, 'family', V(l, 60)); H.cash(l, -V(l, 60), 'Viện phí cho ' + pw(l)); fx(l, { hap: -4 }); log('Bạn đi vay khắp họ hàng, mỗi nhà một ít, đủ tiền cho ' + pw(l) + ' lên bàn mổ.', 'neutral'); } },
      { k: 'nong', l: 'Vay nóng cho kịp', ai: { w: 0.5, risk: 1 }, run: function (l, r, log) { if (H.addLoan) H.addLoan(l, 'nong', V(l, 60)); H.cash(l, -V(l, 60), 'Viện phí cho ' + pw(l)); fx(l, { hap: -6 }); stress(l, 10); log('Không kịp xoay xở, bạn vay nóng. Ca mổ thành công, nhưng khoản nợ lãi ngày bắt đầu lớn dần.', 'bad'); } },
      { k: 'ban', l: 'Bán xe, bán đồ đạc có giá trị', req: function (l) { return !!l.veh; }, ai: { w: 0.8 }, run: function (l, r, log) { var v = l.vehVal || V(l, 15); l.veh = null; l.vehName = null; l.vehK = null; l.vehVal = 0; H.cash(l, v - V(l, 60), 'Bán xe lo viện phí'); fx(l, { hap: -5 }); log('Bạn bán chiếc xe, gom góp thêm để lo viện phí cho ' + pw(l) + '. Từ đó đi làm bằng xe buýt.', 'neutral'); } },
      { k: 'khong', l: 'Đưa ' + 'về điều trị ở bệnh viện tuyến dưới cho rẻ', ai: { w: 0.4 }, run: function (l, r, log) { fx(l, { hap: -8 }); log('Không đủ tiền, gia đình đưa ' + pw(l) + ' về bệnh viện tuyến dưới điều trị. Cả nhà chỉ biết cầu mong.', 'bad'); } }
    ]
  });
  T('vd_vay_chua_benh', function (l) { return !!pw(l) && l.indep && l.age >= 20 && poor(l); }, P(0.04, 3), 8, 1);
  SC('vd_hoc_phi_con', {
    title: 'Tiền học của con', valid: function (l) { return l.indep && (l.kids || []).some(function (k) { var x = l.age - k.born; return k.alive !== false && x >= 11 && x <= 17 && k.custody !== 'other'; }); },
    text: 'Đầu năm học, tiền học, tiền sách, tiền học thêm của con dồn vào một lúc. Lương tháng này đã hết từ giữa tháng.',
    opts: [
      { k: 'ca_dem', l: 'Nhận thêm việc ca đêm', ai: { w: 1 }, run: function (l, r, log) { H.cash(l, V(l, 8), 'Làm thêm ca đêm'); fx(l, { hea: -4 }); stress(l, 6); log('Bạn nhận thêm việc ca đêm, ngủ mỗi ngày bốn tiếng, đủ tiền cho con đi học.', 'neutral'); } },
      { k: 'vay', l: 'Vay mượn cho con đi học', ai: { w: 0.8 }, run: function (l, r, log) { if (H.addLoan) H.addLoan(l, 'family', V(l, 10)); log('Bạn vay người quen đóng học phí cho con, tự nhủ năm sau sẽ trả.', 'neutral'); } },
      { k: 'nghi', l: 'Cho con nghỉ học thêm, chỉ học trên lớp', ai: { w: 0.7 }, run: function (l, r, log) { log('Bạn cho con nghỉ học thêm. Con buồn mấy hôm, rồi tự học ở nhà.', 'neutral'); fx(l, { hap: -2 }); } }
    ]
  });
  T('vd_hoc_phi_con', function (l) { return l.indep && poor(l) && (l.kids || []).some(function (k) { var x = l.age - k.born; return k.alive !== false && x >= 11 && x <= 17; }); }, P(0.08, 2), 4, 2);

  // 5. Ở trọ thành phố
  SC('vd_tro', {
    title: 'Phòng trọ', valid: function (l) { return l.urban && !l.ownHouse && l.indep; },
    prep: function (l, r) { return { k: r() < 0.5 ? 'gia' : 'chay' }; },
    text: function (l, d) { return d.k === 'gia' ? 'Chủ trọ báo tăng giá phòng thêm 30%, ai không ở được thì cuối tháng dọn đi.' : 'Nửa đêm, dãy trọ bên cạnh chập điện bốc cháy. Bạn chỉ kịp ôm chiếc điện thoại chạy ra ngoài.'; },
    opts: [
      { k: 'chiu', l: function (l, d) { return d.k === 'gia' ? 'Chịu giá mới, cắt bớt chi tiêu' : 'Tá túc nhà người quen, sắm lại đồ đạc'; }, ai: { w: 1 }, run: function (l, r, log, d) { if (d.k === 'gia') { H.cash(l, -V(l, 10), 'Tiền trọ tăng'); log('Bạn chịu giá mới, bớt ăn sáng, bớt đi chơi.', 'neutral'); } else { H.cash(l, -V(l, 8), 'Sắm lại đồ đạc sau vụ cháy'); fx(l, { hap: -6 }); log('Đồ đạc cháy rụi. Bạn ở nhờ nhà người quen mấy tuần rồi sắm lại từ đầu.', 'bad'); H.mem(l, 'Đêm dãy trọ bốc cháy.', 3); } } },
      { k: 'don', l: 'Dọn ra trọ xa hơn, rẻ hơn', ai: { w: 0.9 }, run: function (l, r, log, d) { stress(l, 4); log('Bạn dọn ra một phòng trọ xa trung tâm, mỗi ngày đi làm thêm gần một tiếng.', 'neutral'); } }
    ]
  });
  T('vd_tro', function (l) { return l.urban && !l.ownHouse && l.indep && poor(l); }, P(0.06, 2.5), 5, 2);

  // 6. Bị lừa, bị quỵt
  SC('vd_co_xkld', {
    title: 'Môi giới đi làm nước ngoài', valid: function (l) { return l.age >= 19 && l.age <= 38 && !l.abroad && poor(l); },
    text: 'Một "cò" giới thiệu đơn hàng đi làm ở nước ngoài lương cao, chỉ cần đóng trước phí môi giới, làm hồ sơ trong ba tháng.',
    opts: [
      { k: 'dong', l: 'Vay tiền đóng phí cho kịp đơn hàng', ai: { w: 0.4, risk: 1 }, run: function (l, r, log) { if (H.addLoan) H.addLoan(l, 'family', V(l, 80)); H.cash(l, -V(l, 80), 'Phí môi giới đi làm nước ngoài'); fx(l, { hap: -10 }); stress(l, 12); log('Đóng tiền xong, hẹn mãi không thấy lịch bay. Đến văn phòng thì đã đóng cửa. Khoản vay 80 triệu vẫn còn đó.', 'bad'); H.mem(l, 'Năm bị lừa mất tiền môi giới đi làm nước ngoài.', 4); } },
      { k: 'kiem_tra', l: 'Kiểm tra công ty có giấy phép hay không trước', ai: { w: 1, smart: 1.2 }, run: function (l, r, log) { log('Tra cứu mới biết công ty kia không có giấy phép đưa người đi làm việc ở nước ngoài. Bạn không đóng đồng nào.', 'good'); } },
      { k: 'thoi', l: 'Thôi, không đi', ai: { w: 0.7 }, run: function (l, r, log) { log('Bạn từ chối, ở lại tìm việc trong nước.', 'neutral'); } }
    ]
  });
  T('vd_co_xkld', function (l, a) { return a >= 19 && a <= 38 && !l.abroad && poor(l); }, P(0.03, 3), 8, 1);

  // 7. Nông nghiệp, buôn bán nhỏ thất bát
  SC('vd_mat_mua', {
    title: 'Mất mùa', valid: function (l) { return /^(nong|sau_rieng|nuoi_tom|phu_giup)$/.test(jid(l)) && l.indep; },
    text: 'Năm nay hạn mặn, cả vụ gần như mất trắng. Tiền phân bón, giống mua chịu từ đầu vụ vẫn còn nợ đại lý.',
    opts: [
      { k: 'vay', l: 'Vay tiếp làm vụ sau', ai: { w: 1 }, run: function (l, r, log) { if (H.addLoan) H.addLoan(l, 'bank', V(l, 30)); fx(l, { hap: -4 }); log('Bạn vay ngân hàng chính sách làm vụ sau, mong trời thương.', 'neutral'); } },
      { k: 'lam_thue', l: 'Đi làm thuê thêm trả nợ', ai: { w: 0.9 }, run: function (l, r, log) { H.cash(l, V(l, 8), 'Làm thuê thêm'); fx(l, { hea: -3 }); log('Ngoài ruộng nhà, bạn đi làm thuê cho các vườn khác lấy tiền trả nợ đại lý.', 'neutral'); } },
      { k: 'ban_dat', l: 'Bán bớt một sào ruộng trả nợ', ai: { w: 0.5 }, run: function (l, r, log) { H.cash(l, V(l, 40), 'Bán bớt ruộng'); fx(l, { hap: -6 }); log('Bạn bán bớt một sào ruộng trả hết nợ. Ruộng nhà mỗi năm một ít đi.', 'bad'); } }
    ]
  });
  T('vd_mat_mua', function (l) { return /^(nong|sau_rieng|nuoi_tom|phu_giup)$/.test(jid(l)) && l.indep; }, P(0.06, 3), 5, 2);

  // 8. Về già không lương hưu
  SC('vd_gia_ngheo', {
    title: 'Tuổi già không lương hưu', valid: function (l) { return l.age >= 62 && !l.pensioned && l.money < l.base * 3; },
    text: 'Không có lương hưu, tiền dành dụm cũng cạn. Tuổi đã cao nhưng bạn vẫn phải tính chuyện kiếm sống.',
    opts: [
      { k: 've_chai', l: 'Đi nhặt ve chai, bán vé số', ai: { w: 0.9 }, run: function (l, r, log) { work(l, r, log, U.pick(r, ['ve_chai', 've_so'])); fx(l, { hea: -3, hap: -3 }); log('Sáng nào bạn cũng dậy sớm đi nhặt ve chai, bán vé số, mỗi ngày kiếm vài chục nghìn.', 'bad'); } },
      { k: 'con', l: 'Nhờ con cái phụ giúp', req: function (l) { return (l.kids || []).some(function (k) { return k.alive !== false && l.age - k.born >= 22; }); }, ai: { w: 1.1 }, run: function (l, r, log) { H.cash(l, V(l, 15), 'Con cái phụ giúp'); log('Các con mỗi tháng gửi về một ít. Con cũng chật vật, nên bạn chi tiêu dè sẻn từng đồng.', 'neutral'); } },
      { k: 'tro_cap', l: 'Làm hồ sơ xin trợ cấp xã hội', ai: { w: 1 }, run: function (l, r, log) { H.cash(l, V(l, 6), 'Trợ cấp xã hội'); log('Bạn làm hồ sơ xin trợ cấp, mỗi tháng nhận một khoản nhỏ, đủ tiền gạo.', 'neutral'); } }
    ]
  });
  T('vd_gia_ngheo', function (l) { return isVN(l) && l.age >= 62 && !l.pensioned && l.money < l.base * 3; }, P(0.15, 2), 6, 2);

  // 9. Tết không về
  SC('vd_tet_khong_ve', {
    title: 'Tết này không về', valid: function (l) { return !!l.movedTo && !!pw(l) && poor(l); },
    text: function (l) { return 'Cuối năm, tiền thưởng chẳng được bao nhiêu, vé xe Tết lại tăng gấp đôi. ' + U.cap(pw(l)) + ' gọi điện hỏi Tết có về không.'; },
    opts: [
      { k: 've', l: 'Vẫn về, Tết là phải về', ai: { w: 1 }, run: function (l, r, log) { H.cash(l, -V(l, 3), 'Vé xe về quê ăn Tết'); fx(l, { hap: 5 }); log('Bạn chắt bóp đủ tiền vé, chen chúc trên chuyến xe đêm về quê ăn Tết.', 'good'); } },
      { k: 'o_lai', l: 'Ở lại, nhận trực Tết lấy lương gấp ba', ai: { w: 0.8 }, run: function (l, r, log) { H.cash(l, V(l, 3), 'Trực Tết'); fx(l, { hap: -5 }); log('Bạn ở lại trực Tết. Đêm giao thừa ngồi một mình trong phòng trọ, gọi video về nhà.', 'bad'); H.mem(l, 'Cái Tết một mình ở phòng trọ.', 3); } }
    ]
  });
  T('vd_tet_khong_ve', function (l) { return !!l.movedTo && !!pw(l) && poor(l); }, P(0.06, 3), 4, 2);

  // 10. những khoản chi bất ngờ dồn dập với người đang khó khăn
  var SHOCK = [
    ['Chiếc xe máy cũ hỏng giữa đường, sửa hết', 3], ['Trong họ liên tiếp có đám cưới, đám giỗ, tiền mừng tiền phúng hết', 4], ['Bị mất trộm chiếc điện thoại trên xe buýt, phải mua chiếc khác hết', 4],
    ['Mưa bão làm dột mái nhà, sửa lại hết', 6], ['Người nhà ốm vặt liên miên, tiền thuốc men hết', 3], ['Bị phạt nguội vì vượt đèn đỏ, nộp phạt hết', 2],
    ['Tiền điện mùa nóng tăng vọt, cộng tiền nước, tiền rác hết', 2], ['Cho người quen vay rồi người ấy biệt tăm, mất', 5], ['Tủ lạnh, máy giặt cũ hỏng cùng tháng, sửa hết', 3],
    ['Đóng tiền xây nhà văn hóa, quỹ khuyến học của thôn hết', 1], ['Đi khám răng đau nhức, nhổ và trám hết', 1.5], ['Bị lừa mua phải lô hàng kém chất lượng khi buôn thêm, lỗ', 4]
  ];
  E.HOOKS.year.unshift(function (l, r, log, a) {
    if (!hard(l) || !l.indep || !l.alive || !free(l) || !isVN(l) || !poor(l) || r() >= 0.5) return;
    var S = l.flags.vdShock || (l.flags.vdShock = {}), left = SHOCK.filter(function (x, i) { return S[i] == null || a - S[i] >= 15; });
    if (!left.length) return; var x = U.pick(r, left); S[SHOCK.indexOf(x)] = a;
    var amt = V(l, x[1] * (1.2 + r() * 0.8)); H.cash(l, -amt, 'Chi phí bất ngờ'); log(x[0] + ' ' + mo(l, amt) + '.', 'bad'); stress(l, 3);
  });
  // người gặp vận đen hay kẹt ở việc lương thấp, chậm được tăng lương
  var cy = E.careerYear;
  if (cy) E.careerYear = function (l) { var inc = cy.apply(this, arguments); if (hard(l) && isVN(l) && typeof inc === 'number' && inc > 0 && (worker(l) || /^(tx_cn|xe_om|shipper|ban_rong|ve_chai|ve_so|nong|phu_giup)$/.test(jid(l)))) inc *= 0.85; return inc; };
  E.vanDen = hard;
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
/* ===== js/life82.js ===== */
/* Một Đời — v6.4.0: ôn thi chuyên & đội tuyển theo đúng từng môn
   · mỗi môn một cách ôn: Toán (chuyên đề hình, bất đẳng thức, đề 150 phút), Tiếng Anh (nghe, từ vựng học thuật, viết luận),
     Ngữ văn (đọc tác phẩm, nghị luận xã hội), Tin học (thuật toán, chấm bài trực tuyến)… và lò luyện thi tốn tiền
   · lúc làm bài cũng theo dạng đề của từng môn
   · thi vào THPT chuyên: có bước ôn thi theo môn đã chọn rồi mới vào phòng thi */
(function (G) {
  'use strict';
  var U = G.U, E = G.E, H = E.H;
  function vnd(l) { return H.isVN(l) && l.cur === 'vnd' && !(l.abroad && l.abroad.perm); }
  function V(l, tr) { return vnd(l) ? tr : tr / 90 * l.base; }
  function mo(l, v) { return H.money(l, v); }
  // [ôn đều, luyện chuyên sâu, học nhóm, lò luyện thi] · [làm chắc, ưu tiên bài khó, kiểm tra] · dạng đề thi chuyên
  var SUB = {
    math: { prep: ['Ôn lại chuyên đề số học, đại số mỗi tối', 'Luyện chuyên đề hình học phẳng và bất đẳng thức', 'Học nhóm, trao đổi lời giải với bạn đội tuyển', 'Vào lò luyện chuyên Toán của thầy nổi tiếng'], exam: ['Làm chắc các câu đại số, phương trình', 'Dồn sức cho bài hình và bất đẳng thức cuối đề', 'Chia thời gian, soát lại từng bước biến đổi'], form: 'Đề chuyên Toán 150 phút, 5 bài: phương trình, số học, hình học phẳng, bất đẳng thức, tổ hợp.' },
    physics: { prep: ['Ôn chắc lý thuyết, hiểu bản chất hiện tượng', 'Luyện bài tập cơ học, điện học nâng cao', 'Làm thí nghiệm, học nhóm giải bài khó', 'Vào lò luyện chuyên Lý'], exam: ['Làm chắc phần cơ học, nhiệt học', 'Dồn sức cho bài điện học, quang học khó', 'Kiểm tra đơn vị, kết quả từng câu'], form: 'Đề chuyên Lý 150 phút: cơ học, nhiệt học, điện học, quang học, có câu thực nghiệm.' },
    chem: { prep: ['Học thuộc chuỗi phản ứng, cân bằng phương trình', 'Luyện bài toán hóa vô cơ, hữu cơ nâng cao', 'Học nhóm, làm thí nghiệm thực hành', 'Vào lò luyện chuyên Hóa'], exam: ['Làm chắc câu viết phương trình, nhận biết chất', 'Dồn sức cho bài toán hóa tính lượng chất', 'Soát lại hệ số cân bằng, đơn vị'], form: 'Đề chuyên Hóa 150 phút: chuỗi phản ứng, nhận biết, bài toán vô cơ và hữu cơ.' },
    bio: { prep: ['Vẽ sơ đồ tư duy di truyền, tế bào', 'Luyện bài tập di truyền, phả hệ, xác suất', 'Học nhóm, giải thích cho nhau từng cơ chế', 'Vào lò luyện chuyên Sinh'], exam: ['Làm chắc câu lý thuyết cơ chế', 'Dồn sức cho bài tập di truyền khó', 'Kiểm tra lại tỉ lệ kiểu gen, kiểu hình'], form: 'Đề chuyên Sinh 150 phút: tế bào, di truyền, phả hệ, sinh thái.' },
    it: { prep: ['Ôn lại cấu trúc dữ liệu, cú pháp ngôn ngữ', 'Cày thuật toán trên VNOI, Codeforces mỗi tối', 'Học nhóm, thi lập trình thử với bạn', 'Vào lớp luyện lập trình thi chuyên'], exam: ['Làm chắc subtask nhỏ của cả ba bài', 'Dồn sức giải trọn bài quy hoạch động khó', 'Tự sinh test, kiểm tra tràn số, thời gian chạy'], form: 'Đề chuyên Tin 150 phút: 3 bài lập trình chấm tự động, có subtask.' },
    lit: { prep: ['Đọc nhiều tác phẩm, ghi chép dẫn chứng', 'Mỗi ngày viết một bài nghị luận xã hội', 'Nhờ cô chấm, sửa từng đoạn văn', 'Vào lớp luyện chuyên Văn'], exam: ['Viết chắc bài nghị luận xã hội', 'Dồn sức cho bài nghị luận văn học, đào sâu lý luận', 'Lập dàn ý kỹ, phân bổ thời gian hai câu'], form: 'Đề chuyên Văn 150 phút: một câu nghị luận xã hội, một câu nghị luận văn học có lý luận.' },
    english: { prep: ['Nghe podcast, xem phim tiếng Anh không phụ đề', 'Học từ vựng học thuật, cụm từ cố định, viết lại câu', 'Luyện nói, viết essay với bạn rồi nhờ chữa', 'Vào lò luyện chuyên Anh'], exam: ['Làm chắc ngữ âm, từ vựng, ngữ pháp', 'Dồn sức cho đọc hiểu khó và bài viết luận', 'Chia thời gian, soát lỗi chính tả, ngữ pháp'], form: 'Đề chuyên Anh 150 phút: nghe hiểu, ngữ âm, từ vựng ngữ pháp, đọc hiểu, viết lại câu, viết luận.' },
    history: { prep: ['Lập bảng niên biểu các sự kiện', 'Luyện câu hỏi nhận định, so sánh, đánh giá', 'Học nhóm, kể lại sự kiện bằng sơ đồ', 'Vào lớp luyện chuyên Sử'], exam: ['Làm chắc câu trình bày sự kiện, mốc thời gian', 'Dồn sức cho câu nhận định, đánh giá', 'Kiểm tra mốc năm, tên nhân vật'], form: 'Đề chuyên Sử 150 phút: trình bày sự kiện, so sánh, nhận định lịch sử Việt Nam và thế giới.' },
    geo: { prep: ['Học thuộc Atlat Địa lý Việt Nam', 'Luyện vẽ và nhận xét biểu đồ, bảng số liệu', 'Học nhóm, phân tích số liệu kinh tế vùng', 'Vào lớp luyện chuyên Địa'], exam: ['Làm chắc câu khai thác Atlat', 'Dồn sức cho câu vẽ, nhận xét biểu đồ', 'Kiểm tra số liệu, đơn vị, chú giải'], form: 'Đề chuyên Địa 150 phút: khai thác Atlat, vẽ và nhận xét biểu đồ, địa lý tự nhiên và kinh tế vùng.' }
  };
  var NAME = { math: 'Toán', physics: 'Vật lý', chem: 'Hóa học', bio: 'Sinh học', it: 'Tin học', lit: 'Ngữ văn', english: 'Tiếng Anh', history: 'Lịch sử', geo: 'Địa lý' };
  E.SUBJECT_PREP = SUB;
  function st(l) { return l.flags.study54 || {}; }
  // 1. ôn đội tuyển & làm bài thi theo từng môn
  var C = E.DEC.study_contest54;
  if (C) {
    var cMake = C.make, cApply = C.apply;
    C.make = function (l) {
      var d = cMake.apply(this, arguments), s = st(l), S = SUB[s.subject]; if (!S) return d;
      if (s.stage === 'train') {
        var map = { steady: S.prep[0], intense: S.prep[1], group: S.prep[2] };
        d.opts.forEach(function (o) { if (map[o.k]) o.l = map[o.k]; if (o.k === 'intense') o.h = 'Tiến bộ nhanh hơn, dễ căng thẳng'; });
        var stop = d.opts.filter(function (o) { return o.k === 'stop'; })[0], rest = d.opts.filter(function (o) { return o.k !== 'stop'; });
        rest.push({ k: 'lo', l: S.prep[3], h: 'Khoảng ' + mo(l, V(l, 4)) + ' cả đợt · luyện đề sát dạng thi nhất' });
        d.opts = stop ? rest.concat([stop]) : rest;
        d.text = 'Ôn đội tuyển ' + NAME[s.subject] + '. Dạng bài thường gặp: ' + S.form.split(': ')[1] + ' Bạn ôn thế nào?';
      } else {
        var em = { careful: S.exam[0], hard: S.exam[1], check: S.exam[2] };
        d.opts.forEach(function (o) { if (em[o.k]) o.l = em[o.k]; });
      }
      return d;
    };
    C.apply = function (l, d, k, r, log) {
      if (k === 'lo') {
        var s = st(l); if (!(s.stage === 'train')) return;
        if (!l.indep && E.childExpense) { var b = E.childExpense(l, V(l, 4), 'Lò luyện thi ' + NAME[s.subject], false); log(b.note, 'neutral'); if (!b.ok) return cApply.call(this, l, d, 'intense', r, log); } else H.cash(l, -V(l, 4), 'Lò luyện thi ' + NAME[s.subject]);
        var x = cApply.call(this, l, d, 'intense', r, log); s.prep = (s.prep || 0) + 2; return x;
      }
      return cApply.apply(this, arguments);
    };
  }
  // 2. thi vào THPT chuyên: ôn theo môn trước khi thi
  var SP = E.DEC.study_special54;
  if (SP) {
    var spApply = SP.apply;
    SP.apply = function (l, d, k, r, log) {
      if (k === 'regular' || !SUB[k] || (l.flags.chuyenOn && l.flags.chuyenOn.done)) { if (l.flags.chuyenOn) l.flags.chuyenOn = null; return spApply.apply(this, arguments); }
      if (!this.valid(l, d.data)) return;
      l.flags.chuyenOn = { k: k, d: d, at: l.age };
      l.pending.unshift(E.DEC.chuyen_on.make(l, r));
    };
  }
  var PREP = [[7, 2, 0, 0], [9, 3, 8, 0], [7, 2, -2, 0], [10, 2, 4, 4]];
  E.SC('chuyen_on', {
    title: function (l) { var c = l.flags.chuyenOn; return 'Ôn thi chuyên ' + (c ? NAME[c.k] : ''); },
    valid: function (l) { var c = l.flags.chuyenOn; return !!c && c.at === l.age && !c.done; },
    text: function (l) { var c = l.flags.chuyenOn; return SUB[c.k].form + ' Còn ba tháng nữa là thi. Bạn ôn thế nào?'; },
    opts: [0, 1, 2, 3].map(function (i) {
      return { k: 'o' + i, l: function (l) { var c = l.flags.chuyenOn; return c ? SUB[c.k].prep[i] : ''; }, h: function (l) { return i === 3 ? 'Khoảng ' + mo(l, V(l, 4)) + ' · luyện đề sát dạng thi nhất' : i === 1 ? 'Tiến bộ nhanh, dễ căng thẳng' : ''; }, ai: { w: i === 0 ? 1.1 : 1 },
        run: function (l, r, log) {
          var c = l.flags.chuyenOn; if (!c || c.done) return; var v = PREP[i];
          if (i === 3) { if (!l.indep && E.childExpense) { var b = E.childExpense(l, V(l, 4), 'Lò luyện thi chuyên ' + NAME[c.k], false); log(b.note, 'neutral'); if (!b.ok) v = PREP[0]; } else H.cash(l, -V(l, 4), 'Lò luyện thi chuyên ' + NAME[c.k]); }
          H.fx(l, { kno: v[1] }); if (l.mind) l.mind.stress = U.clamp(l.mind.stress + v[2], 0, 100);
          log('Ôn thi chuyên ' + NAME[c.k] + ': ' + SUB[c.k].prep[i].charAt(0).toLowerCase() + SUB[c.k].prep[i].slice(1) + '.', 'neutral');
          c.done = true; var bonus = v[0] - 6; l.st.kno += bonus; try { E.DEC.study_special54.apply(l, c.d, c.k, r, log); } finally { l.st.kno -= bonus; l.flags.chuyenOn = null; }
        } };
    })
  });
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
/* ===== js/life83.js ===== */
/* Một Đời — v6.5.0
   · thêm nhiều chuyện tuổi thơ đa dạng, mỗi chuyện có nhiều cách mở đầu / kết quả ngẫu nhiên
   · khi bạn mất: từng người con phản ứng theo đúng con người của mình (đứa con hư hỏng nghẹn ngào nhận ra bố / mẹ đã hy sinh thế nào,
     đứa con thành đạt, đứa con ở xa, đứa con còn nhỏ, đứa con đang thụ án…)
   · sống tiếp đời con: chọn bắt đầu từ lúc chào đời (bố / mẹ ra đi đúng tuổi, để lại đúng phần thừa kế)
     hoặc tiếp tục ngay ở tuổi hiện tại của con và nhận thừa kế */
(function (G) {
  'use strict';
  var U = G.U, E = G.E, H = E.H, SC = E.SC;
  function vnd(l) { return H.isVN(l) && l.cur === 'vnd' && !(l.abroad && l.abroad.perm); }
  function V(l, tr) { return vnd(l) ? tr : tr / 90 * l.base; }
  function pick(r, a) { return U.pick(r, a); }
  function ch(r, p) { return r() < p; }
  function free(l) { return !(l.jailUntil != null && l.age < l.jailUntil) && !(l.abroad && l.abroad.trapped); }
  function m(l) { return l.fam.mAlive ? 'mẹ' : l.fam.fAlive && !l.fam.noDad ? 'bố' : 'bà'; }
  function b(l) { return l.fam.fAlive && !l.fam.noDad ? 'bố' : l.fam.mAlive ? 'mẹ' : 'ông'; }
  function cap(s) { return s.charAt(0).toUpperCase() + s.slice(1); }
  function both(l) { return l.fam.mAlive && l.fam.fAlive && !l.fam.noDad; }
  function vn(l) { return H.isVN(l) && l.mode === 'vn'; }
  function rural(l) { return !l.urban; }
  function school(l) { return !!l.school; }
  function txt(t, l, r) { if (typeof t === 'function') t = t(l, r); if (Array.isArray(t)) t = pick(r, t); return t; }

  // ===================================================================
  // 1. CHUYỆN TUỔI THƠ — mỗi chuyện chỉ gặp một lần, mở đầu ngẫu nhiên, kết quả ngẫu nhiên
  //    lựa chọn: { k, l, ai, req, h, cost, out: [[xác suất, lời kể, chỉ số, sắc thái], …], fail }
  // ===================================================================
  function KID(id, a0, a1, title, texts, opts, when, cw) {
    if (!Array.isArray(texts)) texts = [texts];
    SC(id, {
      title: title,
      prep: function (l, r) { return { v: Math.floor(r() * texts.length) }; },
      text: function (l, d) { var t = texts[(d && d.v) || 0] || texts[0]; return typeof t === 'function' ? t(l) : t; },
      opts: opts.map(function (o) {
        return { k: o.k, l: o.l, h: o.h || '', req: o.req, ai: o.ai || { w: 1 }, run: function (l, r, log, d) {
          if (o.cost) { var c = V(l, o.cost), bill = !l.indep && E.childExpense ? E.childExpense(l, c, o.why || title, false) : null;
            if (bill) { if (!bill.ok) { log(txt(o.fail || 'Nhà chưa có điều kiện cho khoản này.', l, r), 'neutral'); return; } log(bill.note, 'neutral'); }
            else if (l.money >= c) H.cash(l, -c, o.why || title); else { log(txt(o.fail || 'Chưa đủ tiền cho khoản này.', l, r), 'neutral'); return; } }
          var x = r(), acc = 0, out = o.out[o.out.length - 1];
          for (var i = 0; i < o.out.length; i++) { acc += o.out[i][0]; if (x < acc) { out = o.out[i]; break; } }
          log(txt(out[1], l, r), out[3] || 'neutral'); if (out[2]) H.fx(l, out[2]);
          if (out[4]) out[4](l, r, log, d);
        } };
      })
    });
    E.TRIG.push({ id: id, when: function (l, a) { return a >= a0 && a <= a1 && free(l) && (!when || when(l, a)); }, p: 0.08, cd: 99, child: true, cw: cw || 1, max: 1 });
  }
  function mem(t, w) { return function (l) { H.mem(l, t, w || 2); }; }
  function stress(n) { return function (l) { if (l.mind) l.mind.stress = U.clamp((l.mind.stress || 0) + n, 0, 100); }; }

  KID('k6_lac_cho', 3, 6, 'Lạc mất mẹ', [
    function (l) { return 'Theo ' + m(l) + ' đi chợ, mải nhìn sạp đồ chơi, quay lại thì không thấy ' + m(l) + ' đâu.'; },
    function (l) { return 'Đi siêu thị cùng ' + m(l) + ', bạn mải ngắm tủ kem rồi lạc lúc nào không hay.'; },
    function (l) { return 'Hội chợ đông nghịt người. Bàn tay đang nắm bỗng tuột mất, xung quanh toàn người lạ.'; }], [
    { k: 'dung', l: 'Đứng yên tại chỗ, khóc to gọi mẹ', out: [[1, function (l) { return cap(m(l)) + ' hớt hải quay lại, ôm chầm lấy bạn. Cả hai cùng khóc.'; }, { hap: -1 }, 'neutral']] },
    { k: 'nho', l: 'Nhờ cô bán hàng / chú bảo vệ giúp', ai: { smart: 1, w: 1.2 }, out: [[1, function (l) { return 'Cô bán hàng gọi loa, mấy phút sau ' + m(l) + ' chạy tới. Ai cũng khen bạn khôn.'; }, { kno: 1, soc: 1 }, 'good']] },
    { k: 'chay', l: 'Chạy đi tìm khắp nơi', ai: { risk: 1 }, out: [[0.5, 'Chạy lung tung càng lạc xa hơn, mãi tới chiều mới có người tốt bụng dắt về nhà.', { hap: -3 }, 'bad', stress(4)], [0.5, function (l) { return 'May sao chạy ra đúng cổng thì gặp ' + m(l) + ' đang cuống cuồng tìm.'; }, null, 'neutral']] }]);

  KID('k6_ve_tuong', 3, 6, 'Bức tranh trên tường', ['Nhà vừa quét vôi trắng tinh, bạn cầm bút sáp vẽ kín một mảng tường.', 'Bạn lấy son của mẹ vẽ một con mèo thật to lên cửa tủ.'], [
    { k: 'khoe', l: 'Hớn hở khoe với bố mẹ', out: [[0.5, 'Bố mẹ dở khóc dở cười, rồi chụp ảnh "tác phẩm" làm kỷ niệm. Bức ảnh ấy được giữ mấy chục năm.', { hap: 3 }, 'good', mem('Bức tranh bút sáp đầu tiên trên tường nhà.', 2)], [0.5, 'Bị mắng một trận, phải cầm giẻ lau cả buổi chiều.', { hap: -2 }, 'bad']] },
    { k: 'giau', l: 'Kéo ghế che lại', out: [[1, 'Mấy tháng sau dọn nhà mới lộ ra, cả nhà cười lăn.', { hap: 2 }, 'neutral']] }]);

  KID('k6_karaoke', 5, 10, 'Ca sĩ nhí đám cưới', ['Đám cưới chị họ, chú MC mời "ca sĩ nhí" của gia đình lên hát một bài.', 'Liên hoan cuối năm của cơ quan bố mẹ, mọi người giục bạn lên hát.'], [
    { k: 'hat', l: 'Mạnh dạn cầm micro', ai: { soc: 1 }, out: [[0.6, 'Hát lạc tông nhưng cả hội trường vỗ tay rần rần, còn được dúi mấy phong bao lì xì.', { hap: 3, soc: 2 }, 'good'], [0.4, function (l) { return 'Đứng trên sân khấu thì quên sạch lời, chạy tót xuống trốn sau lưng ' + m(l) + '.'; }, { hap: -1 }, 'neutral']] },
    { k: 'tron', l: 'Lắc đầu, nấp sau lưng mẹ', out: [[1, 'Nấp kỹ, chỉ dám ngồi ăn hết đĩa nem rán.', null, 'neutral']] }]);

  KID('k6_ca_vang', 5, 10, 'Chú cá vàng nổi bụng', 'Sáng ra, chú cá vàng trong bể nổi lên mặt nước, không bơi nữa.', [
    { k: 'chon', l: 'Chôn cá dưới gốc cây, cắm một que kem làm bia', ai: { w: 1.2 }, out: [[1, 'Bạn chôn cá dưới gốc cây, cắm que kem làm bia. Lần đầu tiên hiểu thế nào là mất đi.', { hap: -2, karma: 1 }, 'neutral', mem('Chôn chú cá vàng dưới gốc cây, lần đầu hiểu thế nào là mất đi.', 2)]] },
    { k: 'hoi', l: 'Hỏi bố mẹ vì sao cá chết', ai: { smart: 1 }, out: [[1, 'Bố mẹ giải thích về nước bẩn, cho ăn quá nhiều. Bạn hứa lần sau sẽ chăm kỹ hơn.', { kno: 2 }, 'neutral']] },
    { k: 'khoc', l: 'Khóc cả ngày', out: [[1, 'Khóc cả ngày, tối được bố dắt đi mua hai con cá mới.', { hap: -1 }, 'neutral']] }], function (l) { return l.fam.q >= 2; });

  KID('k6_quy_lop', 8, 12, 'Tiền quỹ lớp', 'Cô giao bạn giữ tiền quỹ lớp. Một hôm đếm lại, thiếu mất một ít.', [
    { k: 'bao', l: 'Báo thật với cô', ai: { moral: 1, w: 1.2 }, out: [[0.7, 'Cô không trách, cả lớp kiểm lại thì ra một bạn ghi sổ nhầm. Cô càng tin bạn.', { karma: 3, soc: 1 }, 'good'], [0.3, 'Không tìm ra chỗ thiếu, cô bảo cả lớp góp thêm. Bạn được khen vì trung thực.', { karma: 3 }, 'good']] },
    { k: 'bu', l: 'Lặng lẽ đập heo đất bù vào', out: [[1, 'Đập heo đất bù vào. Không ai biết, nhưng bạn thấy mình đã làm đúng.', { karma: 2, hap: -1 }, 'neutral']] },
    { k: 'giau', l: 'Im lặng, mong không ai phát hiện', ai: { bad: 1 }, out: [[0.5, 'Cuối kỳ thiếu tiền, cả lớp xì xào. Bạn mất chức thủ quỹ.', { soc: -3, karma: -2 }, 'bad'], [0.5, 'Không ai để ý, nhưng bạn áy náy suốt cả năm.', { hap: -2 }, 'neutral']] }], school);

  KID('k6_nghi_oan', 8, 13, 'Bị nghi oan', ['Bạn cùng bàn mất tiền ăn sáng, có đứa chỉ tay về phía bạn.', 'Chiếc máy tính cầm tay của lớp trưởng biến mất, mấy đứa nhìn bạn đầy nghi ngờ.'], [
    { k: 'hoi', l: 'Bình tĩnh nhờ cô tìm hiểu rõ', ai: { smart: 1, w: 1.2 }, out: [[1, 'Mọi chuyện sáng tỏ: món đồ rơi ở ngăn bàn khác. Bạn kia đỏ mặt xin lỗi.', { soc: 2 }, 'good']] },
    { k: 'cai', l: 'Cãi nhau tay đôi', ai: { risk: 1 }, out: [[1, 'Hai đứa cãi nhau to, bị mời phụ huynh. Hôm sau tìm thấy đồ, chẳng ai xin lỗi ai.', { soc: -2, hap: -2 }, 'bad']] },
    { k: 've', l: 'Về kể với bố mẹ', out: [[1, function (l) { return cap(b(l)) + ' lên trường nói chuyện với cô. Cô xin lỗi vì đã để bạn bị nghi oan.'; }, { hap: 1 }, 'neutral']] }], school);

  KID('k6_ban_dac_biet', 7, 12, 'Người bạn đặc biệt', ['Lớp có bạn mới đi chân tập tễnh, mấy đứa nghịch ngợm hay nhại dáng đi.', 'Bạn mới chuyển đến nói lắp, mỗi lần đứng lên trả bài là cả lớp cười ồ.'], [
    { k: 'ben', l: 'Ngồi cạnh, rủ bạn ấy chơi cùng', ai: { moral: 1, w: 1.2 }, out: [[1, 'Bạn trở thành người bạn đầu tiên của bạn ấy ở lớp. Nhiều năm sau hai đứa vẫn thân.', { karma: 5, soc: 2 }, 'good', mem('Ngồi cạnh người bạn bị cả lớp trêu chọc.', 3)]] },
    { k: 'bao', l: 'Báo cô chuyện bạn bị trêu', out: [[1, 'Cô nói chuyện với cả lớp, chuyện trêu chọc thưa dần.', { karma: 3 }, 'good']] },
    { k: 'theo', l: 'Cười theo cho hợp nhóm', ai: { bad: 1, w: 0.6 }, out: [[1, 'Cười theo cho hợp nhóm. Tối về nghĩ lại, bạn thấy xấu hổ.', { karma: -3 }, 'bad']] }], school);

  KID('k6_thieu_nhi', 4, 10, 'Tết Thiếu nhi 1/6', 'Mùng 1 tháng 6, nhà văn hóa tổ chức vui Tết Thiếu nhi, có phát quà và trò chơi dân gian.', [
    { k: 'choi', l: 'Chơi kéo co, bịt mắt bắt dê, nhận quà', out: [[1, function (l, r) { return 'Chơi hết trò này đến trò khác, cuối buổi ' + pick(r, ['được một hộp bút màu', 'được túi kẹo và quyển truyện tranh', 'được quả bóng bay hình con vật', 'được một chiếc cặp sách mới']) + '.'; }, { hap: 3, soc: 1 }, 'good']] },
    { k: 'mua', l: 'Lên múa hát văn nghệ', ai: { soc: 1 }, out: [[1, 'Lên múa bài "Bắc kim thang", lóng ngóng mà cả xóm vỗ tay.', { hap: 2, soc: 3 }, 'good']] },
    { k: 'nha', l: 'Ở nhà xem hoạt hình', out: [[1, 'Ở nhà xem hoạt hình cả buổi, chiều nghe bạn kể mà tiếc.', { hap: 1 }, 'neutral']] }], vn);

  KID('k6_hoc_dan', 6, 12, 'Tiếng đàn nhà bên', ['Chiều nào nhà hàng xóm cũng vang tiếng piano, bạn đứng nép cửa nghe mãi.', 'Ở trung tâm văn hóa có lớp organ, guitar thiếu nhi chiêu sinh.'], [
    { k: 'hoc', l: 'Xin bố mẹ cho đi học đàn', cost: 3, why: 'Học phí lớp đàn', h: function (l) { return 'Khoảng ' + H.money(l, V(l, 3)) + ' một khóa'; }, fail: 'Bố mẹ nói khéo nhà chưa có điều kiện. Bạn tự tập trên cây đàn đồ chơi.', out: [[1, 'Mỗi tuần hai buổi học đàn. Cuối năm bạn đàn trọn vẹn một bản nhạc trước cả nhà.', { hap: 3, kno: 2 }, 'good', function (l, r) { if (!l.talent && r() < 0.25) l.talent = 'âm nhạc'; if (l.talent === 'âm nhạc') l.skill = Math.min(100, (l.skill || 20) + 4); }]] },
    { k: 'tu', l: 'Tự học qua video trên mạng', out: [[1, 'Mày mò tự học qua video, gảy được vài hợp âm, đủ để hát cho cả nhà nghe.', { hap: 2, kno: 1 }, 'good']] },
    { k: 'thoi', l: 'Thôi, thích nghe hơn chơi', out: [[1, 'Bạn thích ngồi nghe hơn. Tiếng đàn chiều ấy thành ký ức êm đềm.', { hap: 1 }, 'neutral']] }]);

  KID('k6_vo', 7, 12, 'Lớp võ mùa hè', [function (l) { return 'Câu lạc bộ ' + (vn(l) ? 'Vovinam' : 'Taekwondo') + ' ở nhà văn hóa chiêu sinh lớp hè.'; }, 'Câu lạc bộ Karate ở trường mở lớp hè, các anh chị mặc võ phục trông thật oai.'], [
    { k: 'hoc', l: 'Đăng ký học võ', cost: 1.5, why: 'Học phí lớp võ', h: function (l) { return 'Khoảng ' + H.money(l, V(l, 1.5)) + ' cả hè'; }, fail: 'Nhà chưa có tiền, bạn đứng ngoài cửa sổ xem các anh chị tập.', out: [[0.7, 'Cả mùa hè tập võ, lên được đai mới, người rắn rỏi hẳn.', { hea: 3, hap: 2 }, 'good'], [0.3, 'Tập được nửa khóa thì bong gân cổ chân, nhưng vẫn quyết tập tiếp đến buổi cuối.', { hea: 1, hap: 1 }, 'neutral']] },
    { k: 'khong', l: 'Ở nhà chơi', out: [[1, 'Mùa hè trôi qua bên tivi và mấy trò chơi quen.', null, 'neutral']] }]);

  KID('k6_nga_cay', 5, 11, 'Cú ngã', ['Trèo cây ổi nhà hàng xóm hái quả, cành gãy, bạn ngã sõng soài.', 'Đạp xe thả dốc, phanh không ăn, bạn ngã lăn ra đường.', 'Chơi đuổi bắt trên cầu thang, bạn trượt chân ngã đập tay xuống bậc.'], [
    { k: 'ke', l: 'Khóc, kể ngay với bố mẹ', ai: { w: 1.3 }, out: [[0.55, function (l) { return 'Bó bột tay một tháng, ' + (l.school ? 'cả lớp' : 'cả nhà') + ' thi nhau ký tên, vẽ hình lên lớp bột trắng.'; }, { hea: -4, hap: -1 }, 'neutral'], [0.45, 'Chỉ trầy xước, bác sĩ sát trùng rồi cho về. Từ đó bạn trèo cẩn thận hơn.', { hea: -1 }, 'neutral']] },
    { k: 'giau', l: 'Giấu bố mẹ vì sợ bị mắng', ai: { w: 0.6 }, out: [[0.6, 'Tay sưng vù mới bị phát hiện. Bác sĩ bảo đến muộn thêm chút nữa là xương liền lệch.', { hea: -6, hap: -2 }, 'bad'], [0.4, 'Đau mấy hôm rồi cũng đỡ. Vết sẹo nhỏ ở đầu gối theo bạn mãi.', { hea: -2 }, 'neutral']] }]);

  KID('k6_ruou_gio', 11, 14, 'Chén rượu ngày giỗ', [function (l) { return 'Ngày giỗ ông, mấy chú bác rót rượu mời: “' + (l.sex === 'M' ? 'Lớn rồi, làm một chén cho ra dáng đàn ông!' : 'Con gái cũng làm một chén cho vui!') + '”'; }, 'Tất niên ở nhà bác cả, cả mâm giục bạn "nâng ly" với người lớn.'], [
    { k: 'tu_choi', l: 'Lễ phép từ chối, xin uống nước ngọt', ai: { smart: 1, w: 1.3 }, out: [[1, 'Từ chối khéo, bác cười xòa xoa đầu bạn.', { karma: 1 }, 'good']] },
    { k: 'thu', l: 'Uống thử một chén', out: [[1, 'Chén rượu cay xè, mặt đỏ gay, cả buổi chiều nằm li bì.', { hea: -2, hap: -1 }, 'neutral']] },
    { k: 'nhieu', l: 'Uống liền mấy chén cho oai', ai: { risk: 1, w: 0.5 }, out: [[1, function (l) { return 'Uống mấy chén liền, nôn thốc nôn tháo, bị ' + m(l) + ' mắng cho một trận.'; }, { hea: -4 }, 'bad']] }], vn);

  KID('k6_vape', 12, 14, 'Thuốc lá điện tử', ['Mấy đứa bạn lén rủ thử thuốc lá điện tử mùi trái cây sau giờ học: “Thơm lắm, không sao đâu”.', 'Đứa bạn khoe "pod" mới mua trên mạng, rủ cả nhóm hút thử trong nhà vệ sinh.'], [
    { k: 'tu_choi', l: 'Từ chối, bỏ về', ai: { smart: 1, w: 1.3 }, out: [[1, 'Bạn lắc đầu bỏ về. Ít lâu sau trường phát hiện, cả nhóm kia bị kỷ luật.', { karma: 2, hea: 1 }, 'good']] },
    { k: 'thu', l: 'Thử một hơi', out: [[1, 'Thử một hơi, ho sặc sụa, chóng mặt. Bạn không đụng vào nữa.', { hea: -1 }, 'neutral']] },
    { k: 'mua', l: 'Thử rồi mua luôn một cây', ai: { risk: 1, w: 0.4 }, out: [[1, 'Lén mua một cây, hút giấu trong nhà vệ sinh. Mấy tháng sau bị phát hiện, cả nhà sốc.', { hea: -4, karma: -2, hap: -2 }, 'bad', stress(5)]] }], school);

  KID('k6_phim_ma', 9, 13, 'Bộ phim kinh dị', ['Anh họ rủ xem phim ma lúc nửa đêm, tắt hết đèn cho "có không khí".', 'Ngủ lại nhà bạn, cả bọn rủ nhau xem phim kinh dị trên điện thoại.'], [
    { k: 'xem', l: 'Xem đến hết, trùm chăn kín đầu', ai: { risk: 1 }, out: [[1, 'Xem hết phim, cả tuần không dám tắt đèn đi ngủ.', { hap: 1 }, 'neutral']] },
    { k: 'tat', l: 'Xem nửa chừng rồi xin tắt', out: [[1, 'Xem nửa chừng thì sợ quá, cả bọn chuyển sang xem hoạt hình. Ai cũng thở phào.', { hap: 1 }, 'neutral']] },
    { k: 'ngu', l: 'Đi ngủ trước', out: [[1, 'Đi ngủ trước, sáng ra nghe kể lại mà vẫn sởn gai ốc.', null, 'neutral']] }]);

  KID('k6_bai_tho', 9, 13, 'Báo tường ngày Nhà giáo', [function (l) { return 'Lớp làm báo tường chào mừng ngày Nhà giáo' + (vn(l) ? ' 20/11' : '') + ', cô giao bạn viết một bài thơ.'; }], [
    { k: 'viet', l: 'Thức khuya viết bài thơ về cô', ai: { w: 1.2 }, out: [[0.6, 'Bài thơ được đọc trước toàn trường. Cô giáo rưng rưng.', { kno: 2, hap: 3 }, 'good', mem('Bài thơ tặng cô được đọc trước toàn trường.', 2)], [0.4, 'Vần chưa chuẩn nhưng cô vẫn dán bài thơ vào giữa tờ báo.', { hap: 1 }, 'good']] },
    { k: 've', l: 'Xin vẽ tranh thay vì viết', out: [[1, 'Bức tranh bó hoa tặng cô được dán ngay trang đầu tờ báo tường.', { hap: 2 }, 'good']] },
    { k: 'chep', l: 'Chép một bài thơ trên mạng', ai: { bad: 1, w: 0.5 }, out: [[0.5, 'Cô nhận ra bài thơ chép mạng, nhẹ nhàng nhắc bạn trước lớp. Bạn xấu hổ đỏ mặt.', { karma: -2, hap: -2 }, 'bad'], [0.5, 'Không ai phát hiện, nhưng lời khen nghe chẳng vui.', { karma: -1 }, 'neutral']] }], school);

  KID('k6_nguoi_la', 10, 14, 'Người lạ trên mạng', ['Một tài khoản lạ kết bạn, khen bạn dễ thương, hỏi tên trường, địa chỉ nhà rồi rủ gặp mặt.', 'Một "anh / chị" trong nhóm game hứa tặng quà, chỉ cần gửi ảnh và nói nhà ở đâu.'], [
    { k: 'ke', l: 'Kể ngay với bố mẹ', ai: { smart: 1, w: 1.4 }, out: [[1, 'Bố mẹ chặn tài khoản và báo cho nhà trường. Hóa ra kẻ đó từng dụ dỗ nhiều bạn nhỏ khác.', { karma: 2, kno: 1 }, 'good']] },
    { k: 'chan', l: 'Tự chặn, không trả lời', out: [[1, 'Bạn chặn ngay. Một bài học nhớ đời về an toàn trên mạng.', { kno: 1 }, 'good']] },
    { k: 'gap', l: 'Đồng ý gặp ở quán trà sữa', ai: { risk: 1, w: 0.3 }, out: [[1, 'Đến điểm hẹn, bạn thấy một người đàn ông lạ lớn tuổi đang đợi. Bạn sợ hãi bỏ chạy về nhà, kể hết với gia đình.', { hap: -4 }, 'bad', stress(8)]] }]);

  KID('k6_lua_game', 10, 14, 'Kim cương miễn phí', 'Có người nhắn tin hứa tặng trang phục hiếm, kim cương miễn phí, chỉ cần gửi mật khẩu tài khoản game.', [
    { k: 'khong', l: 'Không gửi, báo cáo tài khoản đó', ai: { smart: 1, w: 1.2 }, out: [[1, 'Bạn báo cáo tài khoản lừa đảo. Mấy hôm sau thấy cả trường đồn có đứa mất nick vì tin lời nó.', { kno: 1 }, 'good']] },
    { k: 'gui', l: 'Gửi thử xem sao', ai: { risk: 1, w: 0.5 }, out: [[1, 'Gửi mật khẩu xong, tài khoản cày mấy năm bay mất. Bạn khóc cả đêm.', { hap: -4 }, 'bad']] },
    { k: 'hoi', l: 'Hỏi anh chị / bố mẹ trước', out: [[1, 'Anh chị bảo đó là trò lừa đảo. Bạn thoát nạn.', { kno: 1 }, 'good']] }]);

  KID('k6_hat_dau', 5, 9, 'Hạt đậu nảy mầm', 'Cô giáo phát mỗi bạn vài hạt đậu xanh, về gieo vào cốc bông gòn rồi quan sát.', [
    { k: 'cham', l: 'Tưới nước, đặt cạnh cửa sổ mỗi ngày', ai: { smart: 1, w: 1.2 }, out: [[1, 'Mầm đậu vươn cao từng ngày, bạn đo và ghi lại mỗi sáng. Cô cho bạn lên kể trước lớp.', { kno: 2, hap: 2 }, 'good']] },
    { k: 'vuon', l: 'Đem ra vườn trồng cùng ông bà', req: rural, out: [[1, 'Cây đậu leo giàn, cuối mùa ông bà nấu cho bữa chè đậu xanh từ chính tay bạn trồng.', { hap: 3, karma: 1 }, 'good']] },
    { k: 'quen', l: 'Để đó rồi quên', out: [[1, 'Cốc đậu khô héo, bạn tiếc rẻ mãi.', { hap: -1 }, 'neutral']] }], school);

  KID('k6_ngap', 6, 12, 'Nước ngập đường', ['Mưa lớn mấy ngày liền, nước ngập ngang đầu gối, đường tới trường thành sông.', 'Triều cường dâng, cả con ngõ ngập nước, cá từ ao tràn cả ra đường.'], [
    { k: 'loi', l: 'Xắn quần lội nước đi học', out: [[1, 'Lội nước tới trường, ướt hết sách vở nhưng không nghỉ buổi nào.', { kno: 1, hea: -1 }, 'neutral']] },
    { k: 'ca', l: 'Rủ bạn đi bắt cá', ai: { risk: 1 }, out: [[0.8, 'Mấy đứa hò nhau bắt được cả xô cá, bữa tối có nồi cá kho.', { hap: 4, soc: 1 }, 'good'], [0.2, 'Mải bắt cá, bạn trượt chân xuống rãnh sâu, may có người kéo lên. Về bị mắng một trận nhớ đời.', { hea: -2, hap: -2 }, 'bad']] },
    { k: 'don', l: 'Ở nhà phụ kê đồ lên cao', ai: { moral: 1 }, out: [[1, 'Phụ bố mẹ kê đồ lên cao. Nhà không hư hại gì nhiều.', { karma: 2 }, 'good']] }], function (l) { return vn(l) || rural(l); });

  KID('k6_dieu', 6, 12, 'Cánh diều mùa hè', 'Gió nam thổi lồng lộng trên đê, lũ trẻ trong xóm thi nhau thả diều.', [
    { k: 'lam', l: 'Tự vót tre làm diều sáo', ai: { smart: 1 }, out: [[0.7, 'Diều tự làm bay cao, tiếng sáo vi vu cả buổi chiều.', { hap: 4, kno: 1 }, 'good', mem('Cánh diều sáo tự làm bay cao trên đê.', 2)], [0.3, 'Diều nặng quá, mới lên đã cắm đầu xuống ruộng. Cả bọn cười lăn.', { hap: 2 }, 'neutral']] },
    { k: 'mua', l: 'Xin tiền mua diều nilon', out: [[1, 'Diều nilon bay ngon lành, cả chiều chạy theo gió trên đê.', { hap: 2 }, 'good']] },
    { k: 'xem', l: 'Ngồi xem các anh chị thả', out: [[1, 'Ngồi xem trên đê, ngắm hoàng hôn đỏ rực.', { hap: 1 }, 'neutral']] }], rural);

  KID('k6_cau_ca', 7, 13, 'Buổi đi câu', [function (l) { return cap(b(l)) + ' rủ bạn đi câu cá ở hồ đầu làng từ sáng sớm.'; }, function (l) { return 'Cuối tuần, ' + b(l) + ' chở bạn ra bờ sông, mang theo hai cần câu và gói xôi.'; }], [
    { k: 'di', l: 'Dậy sớm đi câu', ai: { w: 1.3 }, out: [[0.45, function (l) { return 'Câu được con cá to nhất đời, ' + b(l) + ' khen mãi với hàng xóm.'; }, { hap: 4 }, 'good'], [0.55, function (l) { return 'Cả buổi chẳng được con nào, nhưng hai ' + (b(l) === 'bố' ? 'bố con' : 'ông cháu') + ' nói chuyện với nhau nhiều hơn cả năm cộng lại.'; }, { hap: 3 }, 'good', mem('Buổi sáng ngồi câu cá bên bờ sông, chẳng được con nào mà vui.', 3)]] },
    { k: 'ngu', l: 'Ngủ nướng', out: [[1, 'Ngủ nướng. Mãi sau này lớn lên, bạn tiếc vì đã không đi.', null, 'neutral']] }], function (l) { return b(l) !== 'mẹ'; });

  KID('k6_de', 8, 12, 'Bắt dế chọi', 'Mùa hè, lũ trẻ trong xóm rủ nhau ra bờ ruộng đổ nước bắt dế chọi.', [
    { k: 'bat', l: 'Đi bắt dế', ai: { risk: 1 }, out: [[0.6, 'Bắt được con dế than "chiến tướng", thắng liền mấy trận.', { hap: 4, soc: 2 }, 'good'], [0.4, 'Đổ nước cả buổi chỉ được con dế nhỏ xíu, thua ngay trận đầu.', { hap: 1 }, 'neutral']] },
    { k: 'nuoi', l: 'Bắt về nuôi, không cho chọi', out: [[1, 'Nuôi dế trong hộp diêm, đêm nào cũng nghe nó gáy.', { hap: 2, karma: 1 }, 'good']] },
    { k: 'khong', l: 'Ở nhà', out: [[1, 'Ở nhà nghe tụi bạn kể chuyện "chiến tướng" mà nóng ruột.', null, 'neutral']] }], rural, function (l) { return l.sex === 'M' ? 1.2 : 0.6; });

  KID('k6_the_bai', 9, 13, 'Cơn sốt thẻ bài', 'Cả lớp mê sưu tập thẻ bài nhân vật; ai có thẻ hiếm là được cả lớp vây quanh.', [
    { k: 'mua', l: 'Dồn tiền ăn sáng mua thẻ', ai: { risk: 1 }, out: [[0.4, 'Nhịn ăn sáng mấy tuần, bóc được một thẻ hiếm, vui cả tháng.', { hap: 3, hea: -1 }, 'good'], [0.6, 'Nhịn ăn sáng mấy tuần mà toàn thẻ trùng. Bạn thấy tiếc tiền ghê.', { hea: -1, hap: -1 }, 'neutral']] },
    { k: 'doi', l: 'Đổi thẻ với bạn', ai: { soc: 1 }, out: [[1, 'Giờ ra chơi nào cũng ngồi đổi thẻ, quen thêm cả bạn lớp bên.', { soc: 2, hap: 1 }, 'good']] },
    { k: 'khong', l: 'Không theo phong trào', out: [[1, 'Không theo, ba tháng sau phong trào cũng tàn.', null, 'neutral']] }], school);

  KID('k6_gian_ban', 8, 13, 'Giận bạn thân', 'Đứa bạn thân dạo này toàn chơi với nhóm khác, để bạn ngồi một mình giờ ra chơi.', [
    { k: 'noi', l: 'Thẳng thắn nói chuyện', ai: { soc: 1, w: 1.2 }, out: [[0.75, 'Hóa ra bạn ấy tưởng bạn giận mình. Hai đứa làm lành, thân hơn trước.', { soc: 3, hap: 2 }, 'good'], [0.25, 'Bạn ấy bảo muốn chơi với nhóm mới. Bạn buồn, nhưng học được cách buông.', { hap: -2 }, 'neutral']] },
    { k: 'moi', l: 'Kết thêm bạn mới', out: [[1, 'Bạn chủ động bắt chuyện với mấy bạn bàn dưới, giờ ra chơi lại rộn ràng.', { soc: 2 }, 'good']] },
    { k: 'gian', l: 'Giận dỗi, nghỉ chơi luôn', out: [[1, 'Nghỉ chơi cả năm học. Lớn lên nghĩ lại mới thấy tiếc.', { hap: -3, soc: -1 }, 'bad']] }], school);

  KID('k6_cai_nhau', 6, 13, 'Tiếng cãi vã sau cánh cửa', ['Đêm khuya, bạn nghe bố mẹ cãi nhau to tiếng chuyện tiền nong.', 'Bữa cơm bỗng im bặt, rồi bố mẹ lớn tiếng với nhau, bát đũa va loảng xoảng.'], [
    { k: 'chan', l: 'Trùm chăn, ôm gối khóc', out: [[1, 'Bạn trùm chăn khóc thút thít. Sáng hôm sau bố mẹ vẫn cố tỏ ra bình thường.', { hap: -4 }, 'bad', stress(6)]] },
    { k: 'xin', l: 'Chạy ra xin bố mẹ đừng cãi nhau', out: [[0.6, 'Bố mẹ khựng lại, ôm lấy bạn. Tối đó cả nhà ngồi nói chuyện lại với nhau.', { hap: 1 }, 'good'], [0.4, 'Bố mẹ bảo bạn vào phòng. Cảm giác bất lực theo bạn rất lâu.', { hap: -3 }, 'bad', stress(5)]] },
    { k: 'thu', l: 'Viết lá thư nhỏ đặt lên bàn', ai: { w: 1.2 }, out: [[1, 'Lá thư nguệch ngoạc “Con thương bố mẹ” khiến cả hai lặng đi. Từ đó bố mẹ cố nói chuyện nhỏ nhẹ hơn.', { hap: 2 }, 'good', mem('Lá thư nhỏ “Con thương bố mẹ” đặt trên bàn.', 3)]] }], both);

  KID('k6_ba_vien', 8, 14, 'Bà nằm viện', ['Bà ngoại ốm nặng phải nằm viện mấy tuần.', 'Ông nội bị ngã, phải mổ và nằm viện.'], [
    { k: 'tham', l: 'Xin theo bố mẹ vào viện thăm', ai: { moral: 1, w: 1.3 }, out: [[1, 'Bạn ngồi bóp chân, kể chuyện ở trường. Người già cười móm mém: “Cháu ông bà lớn thật rồi”.', { karma: 3, hap: 1 }, 'good', mem('Ngồi bóp chân cho ông bà trong viện.', 3)]] },
    { k: 'thiep', l: 'Làm tấm thiệp chúc mau khỏe', out: [[1, 'Tấm thiệp vẽ nguệch ngoạc được dựng cạnh giường bệnh suốt mấy tuần.', { karma: 2 }, 'good']] },
    { k: 'hoc', l: 'Ở nhà học bài', out: [[1, 'Ở nhà học bài. Ít lâu sau người già khỏe lại, về nhà.', null, 'neutral']] }]);

  KID('k6_em_ho', 6, 12, 'Em họ về ở cùng', 'Bố mẹ của em họ đi làm ăn xa, gửi em ở nhà bạn một thời gian.', [
    { k: 'nhuong', l: 'Nhường đồ chơi, chỉ em học bài', ai: { moral: 1, w: 1.2 }, out: [[1, 'Em họ quấn bạn như hình với bóng. Ngày em về, cả hai đứa khóc.', { karma: 3, soc: 1 }, 'good']] },
    { k: 'kho_chiu', l: 'Khó chịu vì phải chia phòng', out: [[1, 'Hai đứa tranh nhau cái quạt, cãi nhau suốt. Mãi sau mới quen.', { hap: -2 }, 'neutral']] }]);

  KID('k6_doi_tuyen', 9, 13, 'Đội tuyển của trường', [function () { return 'Thầy thể dục chọn bạn vào đội bóng đá của trường đi thi giải cấp huyện.'; }, function () { return 'Cô chọn bạn vào đội cầu lông / điền kinh của trường dự hội khỏe Phù Đổng.'; }], [
    { k: 'tap', l: 'Tập luyện hết mình', ai: { w: 1.2 }, out: [[0.45, 'Đội giành huy chương, bạn được tuyên dương dưới cờ.', { hea: 3, hap: 4, soc: 2 }, 'good', mem('Đứng trên bục nhận huy chương cùng đội tuyển của trường.', 3)], [0.55, 'Đội dừng bước ở bán kết, nhưng bạn khỏe hẳn lên, quen thêm nhiều bạn.', { hea: 3, hap: 1, soc: 1 }, 'neutral']] },
    { k: 'thoi', l: 'Từ chối để tập trung học', ai: { smart: 1 }, out: [[1, 'Bạn từ chối để tập trung học. Điểm cuối kỳ khá lên.', { kno: 1 }, 'neutral']] }], school);

  KID('k6_banh_chung', 5, 12, 'Gói bánh chưng', 'Chiều 28 Tết, cả nhà quây quần bên mâm lá dong gói bánh chưng.', [
    { k: 'goi', l: 'Xin gói một chiếc bánh nhỏ của riêng mình', out: [[1, 'Chiếc bánh méo xẹo nhưng là chiếc bánh ngon nhất Tết năm ấy.', { hap: 4 }, 'good', mem('Chiếc bánh chưng méo xẹo tự tay gói ngày Tết.', 3)]] },
    { k: 'trong', l: 'Thức trông nồi bánh', out: [[1, 'Ngồi bên bếp lửa nghe người lớn kể chuyện ngày xưa, ngủ gục lúc nào không hay.', { hap: 3 }, 'good']] },
    { k: 'choi', l: 'Chạy đi chơi với bạn', out: [[1, 'Chạy đi chơi pháo que với bạn, về đến nhà thì bánh đã vớt xong.', { hap: 1 }, 'neutral']] }], vn);

  KID('k6_quyen_gop', 7, 12, 'Ủng hộ vùng lũ', [function (l) { return 'Trường phát động quyên góp ủng hộ các bạn nhỏ ' + (vn(l) ? 'miền Trung' : 'vùng thiên tai') + ' vừa bị lũ cuốn trôi nhà cửa.'; }], [
    { k: 'dap', l: 'Đập heo đất ủng hộ hết', ai: { moral: 1, w: 1.2 }, out: [[1, 'Đập heo đất, đếm từng đồng xu đem lên trường. Cô giáo xoa đầu bạn mãi.', { karma: 5, hap: 2 }, 'good', mem('Đập heo đất ủng hộ các bạn vùng lũ.', 2)]] },
    { k: 'nua', l: 'Ủng hộ một nửa', out: [[1, 'Góp một nửa số tiền để dành, nửa còn lại để mua sách.', { karma: 3 }, 'good']] },
    { k: 'do', l: 'Gom sách vở, quần áo cũ gửi đi', out: [[1, 'Gom cả thùng sách vở, quần áo gửi đi, kèm một lá thư hỏi thăm.', { karma: 3, hap: 1 }, 'good']] }], school);

  KID('k6_day_thi', 11, 14, 'Tuổi dậy thì', [function (l) { return l.sex === 'M' ? 'Giọng bạn vỡ ra ồm ồm, mặt lấm tấm mụn, cả lớp trêu là "vịt đực".' : 'Lần đầu tiên "đến tháng", bạn hoảng hốt không biết phải làm sao.'; }], [
    { k: 'hoi', l: 'Hỏi bố mẹ', ai: { w: 1.2 }, out: [[1, function (l) { var p = l.sex === 'F' ? (l.fam.mAlive ? 'mẹ' : m(l)) : (l.fam.fAlive && !l.fam.noDad ? 'bố' : m(l)); return cap(p) + ' ân cần giải thích, chuẩn bị đồ dùng cho bạn. Bạn thấy nhẹ lòng hẳn.'; }, { hap: 2, kno: 1 }, 'good']] },
    { k: 'mang', l: 'Tự tìm hiểu trên mạng', out: [[1, 'Đọc được nhiều thông tin đúng có, sai có, nhưng cũng hiểu cơ thể mình hơn.', { kno: 1 }, 'neutral']] },
    { k: 'giau', l: 'Xấu hổ, giấu kín', out: [[1, 'Giấu kín mấy tháng, lo lắng một mình.', { hap: -2 }, 'neutral', stress(4)]] }]);

  KID('k6_cho_phien', 5, 10, 'Món đồ chơi ở chợ', [function (l) { return 'Theo ' + m(l) + ' đi chợ phiên, bạn nhìn thấy món đồ chơi mơ ước.'; }, function (l) { return 'Đi siêu thị với ' + m(l) + ', bạn đứng mãi trước kệ đồ chơi.'; }], [
    { k: 'doi', l: 'Ăn vạ đòi mua bằng được', ai: { risk: 1 }, out: [[0.5, function (l) { return cap(m(l)) + ' chiều, mua cho. Về nhà chơi được ba hôm thì chán.'; }, { hap: 1 }, 'neutral'], [0.5, function (l) { return cap(m(l)) + ' không mua, kéo về. Bạn hờn cả buổi.'; }, { hap: -2 }, 'neutral']] },
    { k: 'xach', l: 'Phụ mẹ xách đồ', ai: { moral: 1 }, out: [[1, function (l) { return 'Xách giỏ rau cho ' + m(l) + ', được thưởng cây kẹo bông.'; }, { karma: 2, hap: 2 }, 'good']] },
    { k: 'de_danh', l: 'Hỏi giá rồi về tự để dành tiền', ai: { smart: 1 }, out: [[1, 'Ba tháng nhịn quà vặt, bạn tự mua được món đồ chơi ấy. Cảm giác thật khác.', { hap: 3, kno: 1 }, 'good']] }]);

  KID('k6_ngu_rieng', 6, 10, 'Đêm đầu ngủ một mình', 'Bố mẹ dọn cho bạn một góc ngủ riêng. Đêm đầu tiên, bóng tối như có ai đang nhìn.', [
    { k: 'den', l: 'Xin bật đèn ngủ', out: [[1, 'Có ánh đèn vàng, bạn ngủ ngon lành.', { hap: 1 }, 'neutral']] },
    { k: 'chay', l: 'Ôm gối chạy sang phòng bố mẹ', out: [[1, 'Ngủ ké bố mẹ thêm một tuần nữa mới quen.', { hap: 2 }, 'neutral']] },
    { k: 'gan', l: 'Tự nhủ mình đã lớn', ai: { w: 1.1 }, out: [[1, 'Đếm cừu đến ba trăm thì ngủ thiếp. Sáng ra thấy mình lớn hẳn.', { hap: 1, soc: 1 }, 'good']] }], function (l) { return l.fam.q >= 3 || l.urban; });

  KID('k6_xe_buyt', 10, 14, 'Lần đầu tự đi xe buýt', 'Bố mẹ bận, lần đầu tiên bạn phải tự đi xe buýt tới lớp học thêm.', [
    { k: 'di', l: 'Tự đi', ai: { w: 1.2 }, out: [[0.65, 'Tự đi trót lọt, thấy mình như người lớn.', { soc: 2, hap: 2, kno: 1 }, 'good'], [0.35, function (l) { return 'Ngồi quá bến, phải gọi điện nhờ ' + m(l) + ' đón. Lần sau thì thuộc đường.'; }, { hap: -1 }, 'neutral']] },
    { k: 'nho', l: 'Nhờ hàng xóm chở đi', out: [[1, 'Nhờ bác hàng xóm chở đi, dọc đường được nghe kể đủ chuyện.', null, 'neutral']] }], function (l) { return l.urban; });

  KID('k6_can_thi', 8, 13, 'Nhìn bảng không rõ', 'Dạo này bạn phải nheo mắt mới đọc được chữ trên bảng.', [
    { k: 'kham', l: 'Nói với bố mẹ để đi khám mắt', ai: { smart: 1, w: 1.3 }, out: [[1, 'Bác sĩ bảo bạn bị cận, phải đeo kính. Đeo kính vào, cả thế giới bỗng rõ nét.', { kno: 1, hap: 1 }, 'neutral', function (l) { l.flags.glasses = true; if (!l.indep && E.childExpense) E.childExpense(l, V(l, 0.8), 'Cắt kính cận', true); }]] },
    { k: 'giau', l: 'Giấu, cứ ngồi nheo mắt', out: [[1, 'Cứ nheo mắt mãi, độ cận tăng nhanh. Cuối năm vẫn phải đi cắt kính, dày hơn hẳn.', { hea: -2, kno: -1 }, 'bad', function (l) { l.flags.glasses = true; }]] }], school);

  KID('k6_phu_quan', 11, 14, 'Phụ quán nước', 'Cô hàng xóm mở quán nước, nhờ bạn phụ dọn bàn cuối tuần, trả ít tiền công.', [
    { k: 'me', l: 'Đi làm, đưa tiền công cho mẹ', ai: { moral: 1, w: 1.2 }, out: [[1, function (l) { return 'Mấy đồng tiền công đưa cả cho ' + m(l) + '. ' + cap(m(l)) + ' cầm tiền mà rơm rớm nước mắt.'; }, { karma: 3, hap: 1 }, 'good', mem('Lần đầu đưa tiền công tự kiếm cho gia đình.', 3)]] },
    { k: 'sach', l: 'Đi làm, để dành mua sách', out: [[1, 'Để dành tiền công mua được bộ sách mơ ước.', { kno: 1, hap: 2 }, 'good']] },
    { k: 'hoc', l: 'Ở nhà học bài', out: [[1, 'Ở nhà học bài, cuối tuần vẫn ghé quán phụ cô vài việc lặt vặt.', { kno: 1 }, 'neutral']] }], function (l) { return l.fam.q <= 2; });

  KID('k6_diem_kem', 8, 13, 'Con điểm đỏ', 'Bài kiểm tra bị điểm 3 đỏ chót, cô yêu cầu bố mẹ ký vào.', [
    { k: 'that', l: 'Đưa bố mẹ ký, hứa sẽ cố gắng', ai: { moral: 1, w: 1.2 }, out: [[0.6, function (l) { return cap(b(l)) + ' thở dài nhưng ngồi kèm bạn học mỗi tối. Bài sau được 8 điểm.'; }, { kno: 3 }, 'good'], [0.4, 'Bị mắng một trận, nhưng nhẹ người vì đã nói thật.', { hap: -1, karma: 1 }, 'neutral']] },
    { k: 'sua', l: 'Sửa số 3 thành số 8', ai: { bad: 1, w: 0.5 }, out: [[0.5, 'Cô phát hiện chữ số bị sửa, mời phụ huynh lên trường. Đó là lần đầu bạn thấy bố mẹ thất vọng đến vậy.', { karma: -3, hap: -4 }, 'bad'], [0.5, 'Thoát được lần này, nhưng thấp thỏm cả học kỳ.', { karma: -2 }, 'neutral']] },
    { k: 'gia', l: 'Tự giả chữ ký', ai: { bad: 1, w: 0.4 }, out: [[1, 'Chữ ký nguệch ngoạc bị cô nhận ra ngay. Bạn bị viết bản kiểm điểm.', { karma: -2, hap: -2 }, 'bad']] }], school);

  KID('k6_bao', 6, 13, 'Đêm bão', 'Đài báo cơn bão lớn sắp đổ bộ. Cả nhà hối hả chằng chống nhà cửa.', [
    { k: 'phu', l: 'Phụ bố mẹ chằng mái, kê đồ', ai: { moral: 1, w: 1.2 }, out: [[0.7, 'Cả nhà thức trắng đêm bão. Sáng ra mái tôn bay mất một góc nhưng mọi người đều an toàn.', { karma: 2 }, 'neutral', mem('Đêm bão cả nhà cùng giữ mái nhà.', 3)], [0.3, 'Bão đi qua nhẹ hơn dự báo. Cả xóm sang nhà nhau phụ dọn cây đổ.', { karma: 2, soc: 1 }, 'good']] },
    { k: 'nep', l: 'Ôm em nép trong góc nhà', out: [[1, 'Gió rít suốt đêm, bạn ôm chặt em, thì thầm hát cho em đỡ sợ.', { hap: -2 }, 'neutral', stress(3)]] }], vn);

  KID('k6_casting', 7, 13, 'Tuyển diễn viên nhí', 'Một công ty quảng cáo tuyển diễn viên nhí, phụ huynh trong nhóm lớp rủ nhau cho con đi thử vai.', [
    { k: 'di', l: 'Đi thử vai', ai: { soc: 1 }, out: [[0.25, 'Bạn được chọn đóng quảng cáo sữa, mặt lên tivi cả tháng. Họ hàng gọi điện chúc mừng rối rít.', { hap: 5, soc: 3 }, 'good', function (l, r) { if (!l.talent && r() < 0.4) l.talent = 'diễn xuất'; H.mem(l, 'Lần đầu thấy mặt mình trên tivi.', 3); }], [0.75, 'Không được chọn, nhưng được biết hậu trường quay phim trông thế nào.', { hap: 1 }, 'neutral']] },
    { k: 'khong', l: 'Không đi', out: [[1, 'Không đi. Mấy tuần sau thấy bạn cùng lớp trên tivi, hơi chạnh lòng.', null, 'neutral']] }], function (l) { return l.urban; });

  KID('k6_nhuong_ghe', 8, 13, 'Chiếc ghế trên xe', 'Trên chuyến xe khách về quê, một bà cụ đứng chênh vênh vì hết ghế.', [
    { k: 'nhuong', l: 'Đứng dậy nhường ghế', ai: { moral: 1, w: 1.3 }, out: [[1, 'Bà cụ cảm ơn, dúi cho bạn quả cam. Cả xe nhìn bạn trìu mến.', { karma: 3, hap: 1 }, 'good']] },
    { k: 'ngu', l: 'Giả vờ ngủ', ai: { bad: 1, w: 0.5 }, out: [[1, 'Nhắm mắt giả vờ ngủ, nhưng cả đường cứ thấy ngượng.', { karma: -2 }, 'neutral']] }]);

  KID('k6_can_ban', 8, 13, 'Trước cổng trường', 'Mấy anh lớp trên chặn đường, đòi tiền một bạn nhỏ lớp dưới.', [
    { k: 'goi', l: 'Chạy đi gọi bác bảo vệ', ai: { smart: 1, w: 1.3 }, out: [[1, 'Bác bảo vệ ra kịp, nhóm kia bỏ chạy. Bạn nhỏ cảm ơn rối rít.', { karma: 3 }, 'good']] },
    { k: 'can', l: 'Lao vào can', ai: { risk: 1 }, out: [[0.5, 'Nhóm kia chột dạ bỏ đi. Từ đó bạn nhỏ lớp dưới coi bạn như anh chị ruột.', { karma: 4, soc: 2 }, 'good'], [0.5, 'Bị xô ngã trầy cả tay, nhưng bạn nhỏ thoát được.', { hea: -2, karma: 4 }, 'neutral']] },
    { k: 'qua', l: 'Lặng lẽ đi qua', ai: { w: 0.6 }, out: [[1, 'Lặng lẽ đi qua. Ánh mắt hoảng sợ của bạn nhỏ ám ảnh bạn mấy hôm.', { karma: -2 }, 'neutral']] }], school);

  KID('k6_thu_tuong_lai', 10, 14, 'Lá thư gửi tương lai', 'Cô chủ nhiệm cho cả lớp viết thư gửi chính mình của 20 năm sau, niêm phong cất đi.', [
    { k: 'mo', l: 'Viết về ước mơ của mình', out: [[1, 'Bạn viết kín hai trang giấy về ước mơ, gấp lại thật cẩn thận.', { hap: 2, kno: 1 }, 'good', function (l) { l.flags.k6Thu = { at: l.age + 20, k: 'mo' }; }]] },
    { k: 'bo_me', l: 'Viết về bố mẹ', out: [[1, 'Bạn viết về bố mẹ, về những điều chưa bao giờ dám nói.', { hap: 2, karma: 1 }, 'good', function (l) { l.flags.k6Thu = { at: l.age + 20, k: 'bo_me' }; }]] },
    { k: 'qua_loa', l: 'Viết qua loa vài dòng', out: [[1, 'Viết vội vài dòng rồi nộp, chẳng nghĩ ngợi gì.', null, 'neutral', function (l) { l.flags.k6Thu = { at: l.age + 20, k: 'qua_loa' }; }]] }], school);

  KID('k6_ve_que', 6, 12, 'Mùa hè ở quê', [function (l) { return 'Hè này bố mẹ gửi bạn về quê ở với ông bà cả tháng.'; }], [
    { k: 'tam_ao', l: 'Theo bọn trẻ trong làng đi chăn trâu, tắm mưa', ai: { soc: 1 }, out: [[1, 'Chăn trâu, tắm mưa, nướng khoai trên đồng. Đen nhẻm mà vui chưa từng thấy.', { hap: 4, hea: 2, soc: 2 }, 'good', mem('Mùa hè đen nhẻm ở quê cùng ông bà.', 3)]] },
    { k: 'nho_nha', l: 'Nhớ nhà, đòi về sớm', out: [[1, 'Khóc nhè đòi về, được một tuần thì bố mẹ lên đón.', { hap: -1 }, 'neutral']] }], function (l) { return l.urban; });

  // thư gửi tương lai: 20 năm sau mở ra đọc
  E.HOOKS.year.unshift(function (l, r, log, a) {
    var t = l.flags && l.flags.k6Thu; if (!t || a !== t.at || !l.alive) return;
    l.flags.k6Thu = null;
    var job = l.job ? E.jobTitle(l) : null;
    log(t.k === 'mo' ? 'Nhà trường gửi lại lá thư bạn viết năm ' + (l.birthYear + a - 20) + '. Ước mơ năm ấy ' + (job ? 'khác xa công việc ' + job + ' bây giờ, nhưng' : 'giờ đã khác, nhưng') + ' đọc lại vẫn thấy mắt cay cay.'
      : t.k === 'bo_me' ? 'Nhà trường gửi lại lá thư năm lớp ' + Math.max(5, t.at - 26) + '. Đọc những dòng viết về bố mẹ' + (!l.fam.mAlive && !l.fam.fAlive ? ' khi cả hai đã không còn, bạn bật khóc.' : ', bạn gọi điện về nhà ngay trong tối ấy.')
      : 'Nhận lại lá thư viết vội năm nào, chỉ vài dòng nguệch ngoạc. Bạn bật cười, rồi thấy tiếc vì đã không viết nhiều hơn.', 'neutral');
    H.mem(l, 'Mở lá thư mình viết từ 20 năm trước.', 3);
  });

  // ===================================================================
  // 2. KHI BẠN RA ĐI: CÁC CON PHẢN ỨNG THEO ĐÚNG CON NGƯỜI CỦA MÌNH
  // ===================================================================
  function hashStr(s) { var h = 2166136261; for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h | 0; }
  function rngFor(l, salt) { var h = { rs: (l.rs ^ hashStr(salt)) | 0 }; return function () { return U.rand(h); }; }
  var BAD = /^(cờ bạc|ma túy|đua xe|game|bỏ học)$/;
  function kidType(l, k) {
    var ka = l.death.age - k.born;
    if (k.jail && ka < k.jail) return 'jail';
    if (ka < 12) return 'little';
    if (ka < 18) return 'teen';
    if (BAD.test(k.vice || '') || k.owe > 0 || k.askedVon && k.close < 40) return 'spoiled';
    if (k.close < 35) return 'distant';
    if (k.abroadStudy || k.abroad) return 'far';
    if (k.edu >= 5 && k.job && k.close >= 45) return 'success';
    if (k.close >= 75) return 'devoted';
    return 'ordinary';
  }
  function sacrifices(l, k) {
    var s = [], P = l.sex === 'M' ? 'bố' : 'mẹ', ka = l.death.age - k.born;
    if (k.vice === 'cờ bạc' || k.owe > 0) s.push('những lần ' + P + ' lặng lẽ gom tiền trả nợ thay mình mà không một lời trách móc');
    if (k.vice === 'ma túy' || k.vice === 'đua xe') s.push('những đêm ' + P + ' thức trắng đi tìm mình khắp các ngõ ngách');
    if (k.vice === 'bỏ học' || k.vice === 'game') s.push('những lần ' + P + ' năn nỉ thầy cô cho mình đi học lại');
    if (k.gotAt != null || k.askedVon) s.push('số tiền ' + P + ' đưa mình làm vốn, ' + P + ' bảo là tiền để dành, thật ra là tiền dưỡng già');
    if (k.uniUntil || k.tuition || k.edu >= 5) s.push('những năm ' + P + ' bớt ăn bớt mặc để đóng học phí cho mình');
    if (l.flags.hardLot === true || E.netWorth(l) < l.base * 3) s.push('những năm nhà túng thiếu, ' + P + ' nhường mình bát cơm đầy, còn mình chỉ ăn rau');
    if (l.workYrs > 30) s.push(l.workYrs + ' năm ' + P + ' đi làm không nghỉ, đôi tay chai sạn');
    s.push('những lần ' + P + ' đứng đợi ngoài cổng trường dưới mưa');
    s.push('chiếc áo cũ ' + P + ' mặc suốt mười năm để dành tiền mua cho mình đôi giày mới');
    if (ka >= 30) s.push('những cuộc gọi của ' + P + ' mà mình bấm từ chối vì "đang bận"');
    return s;
  }
  function reaction(l, k, i, share, will) {
    var r = rngFor(l, 'kid:' + i + ':' + k.name), t = kidType(l, k), P = l.sex === 'M' ? 'bố' : 'mẹ', n = k.name;
    var sac0 = sacrifices(l, k), warm = t === 'spoiled' || t === 'distant' ? sac0 : sac0.filter(function (x) { return !/từ chối|trả nợ|tìm mình|năn nỉ/.test(x); }), sac = warm.length ? warm : sac0, s1 = pick(r, sac), s2 = pick(r, sac.filter(function (x) { return x !== s1; }).concat([s1]));
    var got = share > 0 ? ' Phần di sản ' + H.money(l, share) + ' ' + P + ' để lại, ' + n : '';
    var noteLine = will && will.note ? ' Đọc đến dòng ' + P + ' viết trong di chúc, ' + n + ' gục đầu xuống bàn.' : '';
    var lines = {
      spoiled: [
        n + ' về đến nhà khi ' + P + ' đã nằm yên trong quan tài. Đứng lặng thật lâu trước di ảnh, ' + n + ' bỗng quỵ xuống, nghẹn ngào như đứa trẻ. Đến lúc ấy mới nhớ lại ' + s1 + ', và ' + s2 + '.' + noteLine,
        'Dọn đồ của ' + P + ', ' + n + ' tìm thấy cuốn sổ cũ ghi từng khoản tiền ' + P + ' đã lo cho mình, trang cuối chỉ một dòng: “Chỉ mong con nên người.” ' + n + ' ôm cuốn sổ khóc không thành tiếng, lần đầu tiên hiểu mình đã làm ' + P + ' khổ đến nhường nào.',
        n + ' — đứa con khiến ' + P + ' bạc tóc nhiều nhất — quỳ suốt đêm bên linh cữu. “' + cap(P) + ' ơi, con biết lỗi rồi… sao ' + P + ' không đợi con thêm chút nữa?” Không ai trả lời. Chỉ có ngọn nến lặng lẽ cháy.'],
      distant: [
        n + ' nhận tin giữa một cuộc họp. Nhiều năm rồi hai ' + (P === 'bố' ? 'bố con' : 'mẹ con') + ' ít nói chuyện với nhau. Trên đường về, ' + n + ' mở lại tin nhắn cuối cùng ' + P + ' gửi, chưa từng trả lời: “Con có khỏe không?”',
        n + ' về muộn, đứng ở cuối hàng người đưa tang như một người khách. Đến khi nắp quan tài đóng lại, ' + n + ' mới bật khóc — vì những lời xin lỗi, những lời cảm ơn, giờ không còn ai để nói.',
        'Những năm cuối, ' + n + ' luôn hẹn “để dịp khác con về”. Dịp khác đã không bao giờ đến. ' + n + ' ngồi một mình trong căn phòng cũ của ' + P + ', nhìn tấm ảnh hai ' + (P === 'bố' ? 'bố con' : 'mẹ con') + ' chụp năm nào, nước mắt cứ thế rơi.'],
      far: [
        n + ' đang ở xa, bay suốt đêm mà vẫn không kịp nhìn mặt ' + P + ' lần cuối. Ngồi trong khoang máy bay tối om, ' + n + ' nhớ lại ngày ' + P + ' tiễn mình ra sân bay, dúi vội phong bì tiền vào tay rồi quay đi giấu nước mắt.',
        'Cuộc gọi video cuối cùng, ' + P + ' bảo “Con cứ lo việc của con, ' + P + ' khỏe mà.” ' + n + ' về đến nơi thì chỉ còn kịp thắp nén nhang. Người con xa xứ ôm lấy bức di ảnh, khóc như chưa từng được khóc.'],
      success: [
        n + ' đứng lên đọc điếu văn, giọng run run: “Mọi thứ con có hôm nay đều bắt đầu từ ' + s1 + '.” Cả hội trường lặng đi. ' + n + ' không đọc hết được, gập tờ giấy lại và khóc.',
        'Người ta khen ' + n + ' thành đạt, nhưng ' + n + ' chỉ nhớ ' + s1 + '. Ngày đưa ' + P + ' về nơi an nghỉ, ' + n + ' tự tay bê di ảnh suốt quãng đường dài.'],
      devoted: [
        n + ' ở bên ' + P + ' đến hơi thở cuối cùng, nắm bàn tay gầy guộc cho tới khi nó lạnh dần. Đêm ấy ' + n + ' không khóc thành tiếng, chỉ ngồi lặng bên giường, khẽ kéo lại tấm chăn như sợ ' + P + ' lạnh.',
        n + ' lo trọn hậu sự, việc gì cũng tự tay làm. Đến lúc mọi người về hết, ' + n + ' mới ngồi xuống bậc thềm, nhìn đôi dép ' + P + ' vẫn để ở cửa, rồi bật khóc nức nở.'],
      ordinary: [
        n + ' khóc nấc khi nghe tin. Cả đêm thức canh linh cữu, ' + n + ' kể cho các cháu nghe về ' + s1 + '.',
        n + ' lặng lẽ xếp lại quần áo của ' + P + ', mỗi chiếc áo gợi lại một kỷ niệm. Đến chiếc áo len ' + P + ' hay mặc mùa đông, ' + n + ' áp mặt vào, như vẫn còn hơi ấm.'],
      little: [
        n + ' mới ' + (l.death.age - k.born) + ' tuổi, chưa hiểu hết chuyện gì đang xảy ra. Bé cứ hỏi mãi: “Bao giờ ' + P + ' dậy?”, rồi ôm chiếc gối của ' + P + ' ngủ thiếp đi.',
        'Đứa con nhỏ ' + n + ' đứng nép bên chân người lớn, mặc bộ áo tang rộng thùng thình. Mấy năm sau, mỗi lần nhớ ' + P + ', bé lại lấy tấm ảnh ra hôn lên đó.'],
      teen: [
        n + ' đang tuổi mới lớn, vẫn còn giận ' + P + ' vì một trận cãi nhau tuần trước. Giờ thì chẳng còn ai để làm lành. ' + n + ' khóa trái cửa phòng, khóc suốt đêm.',
        n + ' cố tỏ ra mạnh mẽ, không rơi một giọt nước mắt trong đám tang. Chỉ đến khi mở tủ thấy hộp cơm ' + P + ' chuẩn bị sẵn cho mình, ' + n + ' mới òa lên.'],
      jail: [
        n + ' đang thụ án, được trại giam cho phép về chịu tang có cán bộ đi kèm. Quỳ trước linh cữu, ' + n + ' nghẹn ngào: “Con bất hiếu… con chưa kịp làm lại cuộc đời cho ' + P + ' xem.”',
        'Tin dữ đến trại giam qua lá thư của người nhà. Đêm ấy, ' + n + ' ngồi lặng trong phòng giam, nhớ lại lần cuối ' + P + ' vào thăm, cách tấm kính vẫn cố mỉm cười. ' + n + ' tự hứa sẽ sống tử tế khi ra tù, vì ' + P + '.']
    };
    var line = pick(r, lines[t] || lines.ordinary);
    if (share > 0 && t === 'spoiled') line += got + ' không dám tiêu một đồng, gửi tiết kiệm và tự hứa sẽ làm lại cuộc đời.';
    else if (share > 0 && t === 'success') line += got + ' trích ra một phần làm học bổng mang tên ' + P + '.';
    else if (share === 0 && will && will.plan !== 'personal' && t === 'spoiled') line += ' Trong di chúc, ' + P + ' không để lại tài sản cho ' + n + ', chỉ một lời nhắn. ' + n + ' không oán trách — vì biết ' + P + ' đã cho mình quá nhiều khi còn sống.';
    var GP = P === 'bố' ? 'ông' : 'bà';
    if (k.married && k.kids > 0 && t !== 'little' && t !== 'teen' && l.death.age - k.born < 50 && r() < 0.5) line += [' Đứa con nhỏ của ' + n + ' kéo áo hỏi: “Sao ' + GP + ' ngủ mãi thế?”', ' Bên cạnh, con của ' + n + ' lí nhí: “Con chưa kịp khoe ' + GP + ' giấy khen.”', ' ' + n + ' ôm con vào lòng, dặn: “Sau này con nhớ thương ' + GP + ' nhé, ' + GP + ' thương con nhất nhà.”'][i % 3];
    return line;
  }
  function spouseLine(l) {
    var p = l.partner; if (!p || p.alive === false || p.status === 'dating') return null;
    var r = rngFor(l, 'spouse'), y = l.death.age >= 60 ? 'mấy chục năm' : 'bao năm';
    return pick(r, [
      p.name + ' ngồi lặng bên giường, tay vẫn nắm tay ' + l.name + ' rất lâu sau khi bác sĩ đã lắc đầu. “' + y + ' rồi, sao mình đi trước?”',
      p.name + ' lặng lẽ pha hai tách trà như mọi buổi sáng, rồi chợt nhớ chỉ còn một người. Tách trà thứ hai nguội dần trên bàn.',
      'Sau đám tang, ' + p.name + ' vẫn để nguyên chiếc gối của ' + l.name + ' bên cạnh, mỗi đêm khẽ nói vài câu như người kia vẫn còn nghe.']);
  }
  var fin = E.finale;
  E.finale = function (l) {
    var st = fin.apply(this, arguments);
    if (!l.death || l.death.age < 18) return st;
    var live = (l.kids || []).map(function (k, i) { return { k: k, i: i }; }).filter(function (x) { return x.k.alive !== false; });
    var W = E.WILL70, will = l.flags.will70 || null, lines = [];
    var sp = spouseLine(l); if (sp) lines.push(sp);
    live.forEach(function (x) { var share = W && W.forKid ? W.forKid(l, x.i) : 0; lines.push(reaction(l, x.k, x.i, share, will)); });
    if ((l.grand || 0) > 0 && live.length) lines.push('Các cháu xếp hàng thắp nhang. Đứa lớn nhất đọc bài văn viết về ' + (l.sex === 'M' ? 'ông' : 'bà') + ', cả nhà ai cũng khóc.');
    if (!lines.length) {
      var fr = E.friendsOf ? E.friendsOf(l) : [];
      lines.push(fr.length ? 'Không con cái, không người bạn đời bên cạnh. ' + fr.map(function (f) { return f.name; }).slice(0, 2).join(' và ') + ' lo hậu sự chu đáo như người nhà, đứng lại thật lâu sau khi mọi người đã về.' : 'Đám tang vắng vẻ, chỉ có vài người hàng xóm và chính quyền địa phương lo hậu sự. Một bó hoa trắng không đề tên được ai đó đặt lại bên mộ.');
    }
    st.push({ h: live.length ? 'Khi các con hay tin' : 'Ngày tiễn biệt', x: live.length ? 'Mỗi người con khóc theo một cách, nhớ về ' + (l.sex === 'M' ? 'bố' : 'mẹ') + ' theo một cách:' : '', list: lines });
    return st;
  };
  E.kidGrief = { type: kidType, reaction: reaction };

  // ===================================================================
  // 3. SỐNG TIẾP ĐỜI CON — từ lúc chào đời hoặc ngay ở tuổi hiện tại, nhận thừa kế
  // ===================================================================
  function ctx(l) { return l.abroad && l.abroad.perm ? l.abroad.code : l.country; }
  function kidAgeAtEnd(l, k) { return (l.death ? l.death.age : l.age) - (k.born || 0); }
  E.heirShare = function (l, k) { var i = l.kids.indexOf(k); if (i < 0 || !E.WILL70 || !E.WILL70.estate) return 0; return E.WILL70.forKid(l, i); };
  var childOpts = E.childOpts;
  E.childOpts = function (l, k) {
    var o = childOpts.apply(this, arguments), i = l.kids.indexOf(k), w = l.flags.will70;
    var p = l.partner, mateKeep = !!(p && p.alive !== false && p.status !== 'dating' && k.mate && p.name === k.mate.name);
    o.parent.heir = { side: l.sex === 'F' ? 'm' : 'f', mateKeep: mateKeep, at: Math.max(0, kidAgeAtEnd(l, k)), age: l.death ? l.death.age : l.age, cause: l.death ? l.death.cause : '', name: l.name, sex: l.sex,
      amt: l.death ? Math.max(0, E.heirShare(l, k)) : 0, debt: l.death && E.netWorth(l) < 0, base: l.base, cur: l.cur, ctx: ctx(l), note: w && w.note ? String(w.note).slice(0, 400) : '', idx: i,
      rec: { edu: k.edu || 0, married: !!k.married, job: !!k.job, kids: k.kids || 0, vice: k.vice || null } };
    return o;
  };
  var createLife = E.createLife;
  E.createLife = function (opts) {
    var life = createLife.apply(this, arguments), h = opts && opts.parent && opts.parent.heir;
    if (h && h.at > 0) {
      var keep = {}; keep[h.side] = h.at; if (h.mateKeep) keep[h.side === 'm' ? 'f' : 'm'] = h.at;
      life.flags.heirKeep = keep;
      var amt = h.amt > 0 ? (h.cur === life.cur && h.ctx === ctx(life) ? h.amt : h.amt / h.base * life.base) : 0;
      life.flags.heirOf = { at: h.at, side: h.side, name: h.name, sex: h.sex, age: h.age, cause: h.cause, amt: amt, debt: h.debt, note: h.note };
    }
    return life;
  };
  E.HOOKS.year.unshift(function (l, r, log, a) {
    var h = l.flags.heirOf, f = l.fam;
    if (l.flags.heirTrust > 0 && a >= 18) { var t = l.flags.heirTrust; l.flags.heirTrust = 0; H.cash(l, t, 'Nhận phần thừa kế được giữ hộ'); log('Tròn 18 tuổi, bạn nhận lại phần thừa kế ' + H.money(l, t) + ' mà ' + (h && h.sex === 'M' ? 'bố' : 'mẹ') + ' để lại, người giám hộ đã giữ hộ bấy lâu.', 'good'); }
    if (!h || h.done || a !== h.at) return;
    h.done = true; if (l.flags.heirKeep) l.flags.heirKeep = null;
    var P = h.sex === 'M' ? 'Bố' : 'Mẹ', p = P.toLowerCase();
    if (f[h.side + 'Alive']) {
      f[h.side + 'Alive'] = false;
      log(P + ' ' + h.name + ' qua đời ở tuổi ' + h.age + (h.cause ? (/thanh thản/.test(h.cause) ? ', ' + h.cause : ' vì ' + h.cause) : '') + '.', 'bad');
      l.st.hap -= 14; H.mem(l, 'Ngày ' + p + ' ' + h.name + ' ra đi.', 7);
      if (!f.mAlive && !f.fAlive) l.flags.caring = false;
    }
    if (h.note) log('Trong di chúc, ' + p + ' để lại lời nhắn: “' + h.note + '”', 'big');
    if (h.amt > 0) {
      if (a >= 18) { H.cash(l, h.amt, 'Thừa kế từ ' + p + ' ' + h.name); log('Theo di chúc / pháp luật, bạn được hưởng ' + H.money(l, h.amt) + ' từ di sản của ' + p + '.', 'good'); }
      else { l.flags.heirTrust = (l.flags.heirTrust || 0) + h.amt; log('Phần thừa kế ' + H.money(l, h.amt) + ' của bạn được người giám hộ giữ hộ đến khi bạn tròn 18 tuổi.', 'neutral'); }
    } else if (h.debt) log(P + ' để lại khoản nợ, nhưng theo luật người thừa kế chỉ trả nợ trong phạm vi di sản được hưởng, nên bạn không phải gánh thêm.', 'neutral');
  });
  // tiếp tục ngay ở tuổi hiện tại của con: dựng lại những năm đã qua (máy tự chọn), chọn bản giống hồ sơ của con nhất
  function ffTo(life, at) {
    var guard = 0;
    while (life.alive && life.age < at && guard++ < 130) {
      E.beginYear(life, { auto: true }); var g = 0;
      while (life.pending.length && life.alive && g++ < 64) E.resolve(life, E.autoKey(life));
      if (life.alive) E.finishYear(life); g = 0;
      while (life.pending.length && life.alive && g++ < 64) E.resolve(life, E.autoKey(life));
      E.endYear(life);
    }
    return life.alive && life.age === at;
  }
  function score(life, rec) {
    var sc = -Math.abs((life.edu || 0) - rec.edu) * 2;
    var wed = !!(life.partner && life.partner.status !== 'dating' && life.partner.alive !== false);
    if (wed === rec.married) sc += 2;
    if (!!life.job === rec.job) sc += 1;
    sc -= Math.abs((life.kids || []).length - rec.kids) * 0.7;
    if (rec.vice === 'bỏ học' && life.edu <= 2) sc += 1;
    if (life.jailUntil != null && life.age < life.jailUntil) sc -= 3;
    return sc;
  }
  E.heirAtAge = function (l, k, tries) {
    var o = E.childOpts(l, k), h = o.parent.heir, at = h.at, best = null, bs = -1e9, n = tries || 6;
    if (at <= 0) return E.createLife(o);
    var t0 = Date.now();
    for (var i = 0; i < n; i++) {
      var life = E.createLife(Object.assign({}, o, { seed: (l.rs ^ hashStr(k.name + ':' + i) ^ (i * 7919)) | 0 }));
      if (!ffTo(life, at)) continue;
      var s = score(life, h.rec); if (s > bs) { bs = s; best = life; }
      if (bs >= 3 || (best && Date.now() - t0 > 2500)) break;
    }
    if (!best) return null;
    best.pending = [];
    best.flags.heirFF = { from: h.name, at: at };
    best.log.push({ a: at, y: best.birthYear + at, t: 'Bạn tiếp tục cuộc đời của ' + best.name + ' ở tuổi ' + at + ', năm ' + (l.sex === 'M' ? 'bố' : 'mẹ') + ' ' + h.name + ' ra đi.', k: 'big' });
    return best;
  };
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
