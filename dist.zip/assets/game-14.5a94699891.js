/* ===== js/life58.js ===== */
/* v4.8.0 — mua / bán theo số lượng và bảng giá thị trường có nguồn, thời điểm. */
(function (G) {
  'use strict';
  var E = G.E, H = E.H, U = G.U, C = G.CUR;
  var SEED = G.MARKET_SEED, latest = copy(SEED);
  var GOLD = ['SJC', 'NHAN', 'PNJ'], VN = ['E1VFVN30', 'VCB', 'FPT', 'VNM', 'HPG', 'MWG', 'GAS'], US = ['SPY', 'AAPL', 'MSFT', 'NVDA', 'KO', 'TM'];
  function copy(x) { return JSON.parse(JSON.stringify(x)); }
  function positive(x) { return typeof x === 'number' && isFinite(x) && x > 0; }
  function goodQuote(q, symbol) {
    var s = SEED.quotes[symbol];
    return !!s && q && q.symbol === symbol && q.kind === s.kind && q.currency === s.currency && positive(q.bid) && positive(q.ask) && q.ask >= q.bid && q.ask < 1e12 && isFinite(Date.parse(q.asOf));
  }
  function goodFx(x) { return x && positive(x.usdVnd) && x.usdVnd > 1000 && x.usdVnd < 1e6 && isFinite(Date.parse(x.asOf)); }
  function book(l) {
    if (!l.marketBook) l.marketBook = { positions: {}, quotes: copy(latest.quotes), fx: copy(latest.fx), serial: 0, revision: 0 };
    return l.marketBook;
  }
  function quote(l, symbol) { return l.marketBook && l.marketBook.quotes[symbol] || latest.quotes[symbol]; }
  function fx(l) { return l.marketBook && l.marketBook.fx || latest.fx; }
  function convert(l, amount, currency) {
    if (l.cur === 'vnd') return currency === 'VND' ? amount / 1e6 : amount * fx(l).usdVnd / 1e6;
    return (currency === 'VND' ? amount / fx(l).usdVnd : amount) / C.priceLevel(l.gdp);
  }
  function native(l, amount, currency) {
    var usd = l.cur === 'vnd' ? amount * 1e6 / fx(l).usdVnd : amount * C.priceLevel(l.gdp);
    return currency === 'USD' ? usd : usd * fx(l).usdVnd;
  }
  function value(l) {
    var p = l.marketBook && l.marketBook.positions || {};
    return Object.keys(p).reduce(function (sum, symbol) { var q = quote(l, symbol); return sum + (q && positive(p[symbol].qty) ? convert(l, p[symbol].qty * q.bid, q.currency) : 0); }, 0);
  }
  function sync(l, data) {
    var b = book(l), changed = false, simulated = b.simAt != null;
    Object.keys(SEED.quotes).forEach(function (symbol) {
      var q = data && data.quotes && data.quotes[symbol], old = b.quotes[symbol];
      if (!goodQuote(q, symbol)) return;
      var clean = Object.assign({}, SEED.quotes[symbol], { bid: q.bid, ask: q.ask, asOf: q.asOf });
      if (Date.parse(q.asOf) >= Date.parse(latest.quotes[symbol].asOf)) latest.quotes[symbol] = copy(clean);
      // Sau khi mô phỏng bắt đầu, lấy giá thật chỉ để tham khảo / làm mốc cho đời mới.
      if (simulated || Date.parse(q.asOf) < Date.parse(old.asOf)) return;
      if (q.bid !== old.bid || q.ask !== old.ask || q.asOf !== old.asOf) { b.quotes[symbol] = clean; changed = true; }
    });
    if (goodFx(data && data.fx)) {
      var cleanFx = Object.assign({}, SEED.fx, { usdVnd: data.fx.usdVnd, asOf: data.fx.asOf });
      if (Date.parse(data.fx.asOf) >= Date.parse(latest.fx.asOf)) latest.fx = copy(cleanFx);
      if (!simulated && Date.parse(data.fx.asOf) >= Date.parse(b.fx.asOf) && (b.fx.usdVnd !== data.fx.usdVnd || b.fx.asOf !== data.fx.asOf)) { b.fx = cleanFx; changed = true; }
    }
    if (changed) b.revision++;
    return changed;
  }
  function stamp(q) {
    return q.simYear != null ? 'Giá mô phỏng năm ' + q.simYear + ' (' + (q.change >= 0 ? '+' : '') + U.fmtNum(q.change * 100, 1) + '% trong năm); mốc ngoài đời: ' + time(q.asOf) : 'Mốc giá ngoài đời: ' + time(q.asOf);
  }
  function simulateYear(l, ignored, log) {
    var b = l.marketBook;
    if (!b || !l.alive || b.simAt === l.age) return;
    if (b.marketRs == null) b.marketRs = ((l.rs || 0) ^ 0x6a09e667) | 0;
    var holder = { rs: b.marketRs }, r = function () { return U.rand(holder); };
    var gold = U.clamp(.02 + U.normal(r) * .12, -.30, .40);
    var vn = .04 + U.normal(r) * .15, us = .04 + U.normal(r) * .13;
    var shock = r(); if (shock < .06) { vn -= .25; us -= .22; } else if (shock > .94) { vn += .25; us += .22; }
    var parts = [];
    Object.keys(b.quotes).forEach(function (symbol) {
      var q = b.quotes[symbol], isGold = q.kind === 'gold', etf = symbol === 'E1VFVN30' || symbol === 'SPY';
      var growth = isGold ? gold : U.clamp((VN.indexOf(symbol) >= 0 ? vn : us) + U.normal(r) * (etf ? .04 : symbol === 'NVDA' ? .30 : .16), etf ? -.35 : -.65, etf ? .45 : .90);
      var digits = q.currency === 'VND' ? 1 : 100, floor = q.currency === 'VND' ? 1 : .01, oldBid = q.bid;
      q.bid = Math.max(floor, Math.min(9e11, Math.round(q.bid * (1 + growth) * digits) / digits));
      q.ask = Math.max(q.bid, Math.min(9e11, Math.round(q.ask * (1 + growth) * digits) / digits));
      q.simYear = l.birthYear + l.age; q.change = q.bid / oldBid - 1;
      if (b.positions[symbol] && b.positions[symbol].qty > 0) parts.push(symbol + ' ' + (q.change >= 0 ? '+' : '') + U.fmtNum(q.change * 100, 1) + '%');
    });
    b.marketRs = holder.rs; b.simAt = l.age; b.revision++;
    if (parts.length && log) log('Giá đầu tư mô phỏng năm ' + (l.birthYear + l.age) + ': ' + parts.join(' · ') + '. Số lượng giữ nguyên; giá trị danh mục theo giá bán được: ' + H.money(l, value(l)) + '.', 'money');
  }
  E.HOOKS.year.push(simulateYear);
  function free(l) { return l.alive && l.age >= 18 && l.indep && !(l.jailUntil != null && l.age < l.jailUntil) && !(l.flags.military && l.age < l.flags.military) && !(l.abroad && l.abroad.trapped); }
  function qty(raw, symbol, unit) {
    if (!/^\d+(?:[.,]\d+)?$/.test(String(raw))) return NaN;
    var x = Number(String(raw).replace(',', '.')) * (unit === 'luong' ? 10 : 1), gold = GOLD.indexOf(symbol) >= 0;
    if (!positive(x) || x > 1e9 || Math.abs(x * (gold ? 10 : 1) - Math.round(x * (gold ? 10 : 1))) > 1e-7) return NaN;
    return gold ? Math.round(x * 10) / 10 : x;
  }
  function max(l, symbol, side) {
    var b = book(l), q = quote(l, symbol), step = q.kind === 'gold' ? 10 : 1;
    if (side === 'sell') return b.positions[symbol] ? b.positions[symbol].qty : 0;
    var affordable = Math.floor((Math.max(0, l.money) / convert(l, q.ask, q.currency) + 1e-10) * step) / step;
    var safe = Math.floor(Number.MAX_SAFE_INTEGER / (q.currency === 'VND' ? 1 : 100) / q.ask * step) / step;
    return Math.max(0, Math.min(1e9, affordable, safe));
  }
  function signature(l) { return [l.age, l.cur, l.gdp, l.abroad && l.abroad.code || '', l.country].join('|'); }
  function valid(l, d) { var b = l.marketBook; return free(l) && !!b && d && goodQuote(quote(l, d.symbol), d.symbol) && d.at === signature(l) && d.token === b.serial && d.revision === b.revision && !d.done; }
  function evaluate(l, d) {
    if (!valid(l, d)) return { ok: false, message: 'Hoàn cảnh hoặc bảng giá đã đổi. Mở lại giao dịch để xem giá mới.' };
    var q = quote(l, d.symbol), n = qty(d.quantity, d.symbol, d.unit), price = d.side === 'sell' ? q.bid : q.ask;
    if (!isFinite(n)) return { ok: false, message: q.kind === 'gold' ? 'Nhập số dương, theo bước 0,1 chỉ hoặc 0,01 lượng.' : 'Nhập số cổ phiếu nguyên dương.' };
    if (n > max(l, d.symbol, d.side) + 1e-8) return { ok: false, message: d.side === 'sell' ? 'Số lượng bán vượt số đang giữ.' : 'Tiền mặt không đủ cho số lượng này.' };
    var total = Math.round(price * n * (q.currency === 'VND' ? 1 : 100)) / (q.currency === 'VND' ? 1 : 100);
    if (!Number.isSafeInteger(Math.round(total * (q.currency === 'VND' ? 1 : 100)))) return { ok: false, message: 'Tổng tiền quá lớn để tính chính xác; hãy chia giao dịch nhỏ hơn.' };
    var cash = convert(l, total, q.currency);
    if (!isFinite(cash) || d.side !== 'sell' && cash > l.money + 1e-10) return { ok: false, message: 'Tiền mặt không đủ sau khi làm tròn tổng tiền.' };
    var h = l.marketBook.positions[d.symbol], avg = d.side === 'sell' && h && h.qty > 0 ? h.basis / h.qty : null;
    return { ok: true, qty: n, total: total, cash: cash, price: price, average: avg, difference: avg == null ? null : price - avg, percent: avg > 0 ? (price / avg - 1) * 100 : null, profit: avg == null ? null : total - avg * n }; 
  }
  function fmt(x, currency) { return U.fmtNum(x, currency === 'VND' ? 0 : 2) + ' ' + currency; }
  function time(s) { var d = new Date(s); return isNaN(d.getTime()) ? s : d.toLocaleString('vi-VN', { timeZone: 'Asia/Ho_Chi_Minh', hour12: false }); }
  function comparison(l, d, e) {
    e = e || evaluate(l, d); if (!e.ok || d.side !== 'sell') return '';
    var q = quote(l, d.symbol), movement = e.difference > 1e-8 ? 'tăng' : e.difference < -1e-8 ? 'giảm' : 'không đổi';
    var rate = e.percent == null ? 'không tính % vì giá vốn bằng 0' : (e.percent >= 0 ? '+' : '') + U.fmtNum(e.percent, 2) + '%';
    return 'So với giá mua bình quân: ' + fmt(e.average, q.currency) + '/' + q.unit + ' → giá bán được hiện tại ' + fmt(e.price, q.currency) + '/' + q.unit + '. Chênh lệch ' + movement + ' ' + fmt(Math.abs(e.difference), q.currency) + '/' + q.unit + ' (' + rate + '). ' +
      (e.profit >= 0 ? 'Lãi' : 'Lỗ') + ' dự kiến khi bán ' + U.fmtNum(e.qty, q.kind === 'gold' ? 1 : 0) + ' ' + q.unit + ': ' + fmt(Math.abs(e.profit), q.currency) + '. ' +
      (q.kind === 'gold' ? 'So sánh giá bạn mua với giá cửa hàng mua lại; đã phản ánh chênh lệch mua–bán vàng. ' : '') + 'Mua nhiều lần dùng giá vốn bình quân; chưa trừ phí / thuế thực tế.';
  }
  function summary(l, d) {
    var e = evaluate(l, d), q = quote(l, d.symbol);
    if (!e.ok) return e.message;
    return (d.side === 'sell' ? 'Bạn nhận: ' : 'Bạn trả: ') + fmt(e.total, q.currency) + ' · ' + H.money(l, e.cash) + '. ' + U.fmtNum(e.qty, q.kind === 'gold' ? 1 : 0) + ' ' + q.unit + ' × ' + fmt(e.price, q.currency) + (d.side === 'sell' ? '\n' + comparison(l, d, e) : '');
  }
  function execute(l, d, log) {
    var e = evaluate(l, d); if (!e.ok) { if (log) log(e.message, 'neutral'); return false; }
    var b = book(l), q = quote(l, d.symbol), h = b.positions[d.symbol] || { qty: 0, basis: 0 }, sell = d.side === 'sell';
    if (sell) {
      var removed = h.basis * e.qty / h.qty;
      h.qty = Math.max(0, Math.round((h.qty - e.qty) * 10) / 10); h.basis = Math.max(0, h.basis - removed);
      H.cash(l, e.cash, 'Bán ' + e.qty + ' ' + q.unit + ' ' + q.name);
      if (h.qty > 0) b.positions[d.symbol] = h; else delete b.positions[d.symbol];
      if (log) log('Bán ' + e.qty + ' ' + q.unit + ' ' + q.name + ', nhận ' + fmt(e.total, q.currency) + '; ' + (e.total >= removed ? 'lãi ' : 'lỗ ') + fmt(Math.abs(e.total - removed), q.currency) + ' theo giá vốn. ' + comparison(l, d, e) + ' ' + stamp(q) + '.', e.total >= removed ? 'good' : 'bad');
    } else {
      h.qty = Math.round((h.qty + e.qty) * 10) / 10; h.basis += e.total; b.positions[d.symbol] = h;
      H.cash(l, -e.cash, 'Mua ' + e.qty + ' ' + q.unit + ' ' + q.name);
      if (log) log('Tự trả ' + fmt(e.total, q.currency) + ' mua ' + e.qty + ' ' + q.unit + ' ' + q.name + ', đơn giá ' + fmt(q.ask, q.currency) + '/' + q.unit + '. ' + stamp(q) + '.', 'neutral');
    }
    d.done = true; b.serial++; return true;
  }
  function queue(l, r, id, arg) { l.pending.unshift(E.DEC[id].make(l, r, arg)); }
  function legacy(l) {
    var rows = [];
    function add(symbol, holder, valueKey, basisHolder, basisKey) {
      var v = holder && holder[valueKey], q = quote(l, symbol); if (!positive(v)) return;
      var step = q.kind === 'gold' ? 10 : 1, n = Math.floor((v / convert(l, q.bid, q.currency) + 1e-10) * step) / step;
      if (n > 0) rows.push({ symbol: symbol, holder: holder, valueKey: valueKey, basisHolder: basisHolder, basisKey: basisKey, qty: n, value: v });
    }
    add('NHAN', l.assets, 'gold', l.basis, 'gold');
    VN.concat(US).forEach(function (symbol) { var p = l.port && l.port[symbol]; add(symbol, p, 'v', p, 'basis'); });
    return rows;
  }
  E.SC('market_convert', { title: 'Quy đổi khoản cũ sang số lượng',
    prep: function (l) { var b = book(l); return { at: signature(l), token: b.serial, revision: b.revision }; },
    valid: function (l, d) { var b = l.marketBook; return free(l) && legacy(l).length > 0 && (!d || !d.at || b && d.at === signature(l) && d.token === b.serial && d.revision === b.revision); },
    text: function (l) { return 'Bản cũ chỉ lưu giá trị, chưa biết số lượng gốc. Bạn có thể quy đổi theo giá bán được đang hiển thị: ' + legacy(l).map(function (x) { var q = quote(l, x.symbol); return q.name + ' → ' + x.qty + ' ' + q.unit + ' (' + stamp(q) + ')'; }).join(' · ') + '. Tổng giá trị tài sản được giữ nguyên; phần nhỏ chưa đủ một đơn vị giao dịch vẫn ở khoản cũ. Đây là quy đổi kế toán tại thời điểm này, không tái tạo số lượng hay tỷ giá mua trong quá khứ.'; },
    opts: [{ k: 'convert', l: 'Quy đổi theo bảng giá này · không thu phí', run: function (l, r, log, d) {
      if (!E.DEC.market_convert.valid(l, d)) return;
      var b = book(l);
      legacy(l).forEach(function (x) {
        var q = quote(l, x.symbol), used = Math.min(x.value, convert(l, x.qty * q.bid, q.currency)), fraction = used / x.value;
        var basis = x.basisHolder && x.basisHolder[x.basisKey] != null ? x.basisHolder[x.basisKey] : x.value, h = b.positions[x.symbol] || { qty: 0, basis: 0 };
        h.qty = Math.round((h.qty + x.qty) * 10) / 10; h.basis += native(l, basis * fraction, q.currency); b.positions[x.symbol] = h;
        x.holder[x.valueKey] = Math.max(0, x.value - used); if (x.basisHolder) x.basisHolder[x.basisKey] = Math.max(0, basis * (1 - fraction));
        log('Quy đổi khoản cũ ' + q.name + ' thành ' + x.qty + ' ' + q.unit + ' theo giá đang lưu; giữ nguyên tổng giá trị, không thay đổi tiền mặt.', 'neutral');
      });
      b.serial++;
    } }, { k: 'no', l: 'Giữ khoản cũ, chưa quy đổi', run: function () {} }]
  });
  var close = { k: 'no', l: 'Đóng lại, không giao dịch', ai: { w: .4 }, run: function () {} };
  function items(kind) { return kind === 'gold' ? GOLD : VN.concat(US); }
  function list(id, title, kind, side) {
    E.SC(id, { title: title, valid: free, text: function (l) {
      book(l); return 'Giá ngoài đời làm mốc ban đầu; sau đó giá tăng / giảm ngẫu nhiên theo từng năm trong game, không phải dự báo thị trường thật. Chọn mã rồi nhập số lượng. Vàng: 1 lượng = 10 chỉ. Cổ phiếu dùng giá phiên gần nhất được nguồn công bố; chưa tính phí môi giới và thuế giao dịch. Tiền mặt: ' + H.money(l, l.money) + '.';
    }, opts: items(kind).map(function (symbol) { return {
      k: symbol, l: function (l) { var q = quote(l, symbol); return (side === 'sell' ? 'Bán ' : 'Mua ') + q.name + ' (' + symbol + ')'; },
      h: function (l) { var q = quote(l, symbol), h = book(l).positions[symbol]; return (side === 'sell' ? 'Bạn bán: ' + fmt(q.bid, q.currency) : 'Bạn mua: ' + fmt(q.ask, q.currency)) + '/' + q.unit + (h ? ' · giữ ' + h.qty + ' ' + q.unit : '') + ' · ' + q.source + ' · ' + stamp(q); },
      req: function (l) { return side === 'sell' ? max(l, symbol, side) > 0 : kind === 'gold' || (l.cur === 'vnd' ? VN : US).indexOf(symbol) >= 0; },
      run: function (l, r) { queue(l, r, 'market_trade', { symbol: symbol, side: side }); }
    }; }).concat([close]) });
  }
  list('market_gold', 'Mua vàng theo số lượng', 'gold', 'buy');
  list('co_phieu', 'Mua cổ phiếu theo số lượng', 'stock', 'buy');
  list('market_sell_gold', 'Bán vàng theo số lượng', 'gold', 'sell');
  list('market_sell_stock', 'Bán cổ phiếu theo số lượng', 'stock', 'sell');
  E.SC('market_trade', { title: function (l, d) { var q = quote(l, d.symbol); return (d.side === 'sell' ? 'Bán ' : 'Mua ') + (q ? q.name : 'tài sản'); }, valid: valid,
    prep: function (l, r, arg) {
      if (!arg || !SEED.quotes[arg.symbol]) return {};
      var b = book(l), q = quote(l, arg.symbol), side = arg.side === 'sell' ? 'sell' : 'buy';
      b.serial++; var defaultQty = Math.min(max(l, arg.symbol, side), q.kind === 'gold' ? 1 : 100);
      return { symbol: arg.symbol, side: side, quantity: String(arg.quantity || defaultQty || 1), unit: arg.unit === 'luong' && q.kind === 'gold' ? 'luong' : 'base', at: signature(l), revision: b.revision, token: b.serial };
    }, text: function (l, d) {
      var q = quote(l, d.symbol); if (!q) return 'Chưa có mã tài sản hợp lệ.';
      return 'Bạn mua: ' + fmt(q.ask, q.currency) + '/' + q.unit + ' · Bạn bán: ' + fmt(q.bid, q.currency) + '/' + q.unit + '.\nNguồn: ' + q.source + ' · ' + stamp(q) + ' (giờ Việt Nam cho mốc ngoài đời).\nĐang giữ: ' + max(l, d.symbol, 'sell') + ' ' + q.unit + '. Tiền mặt: ' + H.money(l, l.money) + '. Tỷ giá quy đổi: 1 USD = ' + fmt(fx(l).usdVnd, 'VND') + ' (' + time(fx(l).asOf) + ').\nNhập số lượng rồi xác nhận; giao dịch không tính phí môi giới / thuế thực tế.';
    }, opts: [{ k: 'confirm', l: 'Xác nhận số lượng đang nhập', run: function (l, r, log, d) { execute(l, d, log); } }, close]
  });
  E.SC('market_menu', { title: 'Vàng và cổ phiếu · thị trường mô phỏng', valid: free,
    text: function (l) { return 'Giá vàng và cổ phiếu sẽ tăng / giảm ngẫu nhiên sau mỗi năm trong game; vàng thường biến động nhẹ hơn cổ phiếu. Danh mục theo số lượng: ' + H.money(l, value(l)) + ' (định giá theo giá bán được, không tính hai lần vào tiền mặt). Chọn mua hoặc bán; mỗi mã ghi nguồn và thời điểm riêng. Khoản đầu tư của bản cũ vẫn giữ nguyên trong mục bán khoản cũ vì chưa từng lưu số lượng gốc.'; },
    opts: [{ k: 'gold', l: 'Mua vàng · nhập chỉ hoặc lượng', run: function (l, r) { queue(l, r, 'market_gold'); } }, { k: 'stock', l: 'Mua cổ phiếu / quỹ · nhập số lượng', run: function (l, r) { queue(l, r, 'co_phieu'); } },
      { k: 'sell_gold', l: 'Bán một phần hoặc toàn bộ vàng', req: function (l) { return GOLD.some(function (s) { return max(l, s, 'sell') > 0; }); }, run: function (l, r) { queue(l, r, 'market_sell_gold'); } },
      { k: 'sell_stock', l: 'Bán một phần hoặc toàn bộ cổ phiếu', req: function (l) { return VN.concat(US).some(function (s) { return max(l, s, 'sell') > 0; }); }, run: function (l, r) { queue(l, r, 'market_sell_stock'); } },
      { k: 'convert', l: 'Xem quy đổi khoản vàng / cổ phiếu cũ sang số lượng', req: function (l) { return legacy(l).length > 0; }, run: function (l, r) { queue(l, r, 'market_convert'); } }, close]
  });
  if (E.DEC.dau_tu) E.DEC.dau_tu.def.opts.forEach(function (o) { if (o.k === 'gold') { o.l = 'Mua vàng · chọn loại và số lượng'; o.h = 'Bảng giá mua / bán có nguồn và thời điểm'; o.run = function (l, r) { queue(l, r, 'market_gold'); }; } });
  ['ban_tai_san', 'ban_dt_moi'].forEach(function (id) {
    var D = E.DEC[id], before = D.valid;
    D.valid = function (l, d) { return before(l, d) || free(l) && value(l) > 0; };
    D.def.opts.unshift({ k: 'market', l: 'Vàng / cổ phiếu theo số lượng · chọn phần muốn bán', req: function (l) { return free(l) && value(l) > 0; }, run: function (l, r) { queue(l, r, 'market_menu'); } });
    D.def.opts.forEach(function (o) { if (/^(gold|stock|port)$/.test(o.k)) { var label = o.l; o.l = function (l, d) { return (typeof label === 'function' ? label(l, d) : label) + ' (khoản mô phỏng cũ)'; }; } });
  });
  E.ACT.push({ id: 'market_menu', g: 'Tiền bạc', l: 'Vàng / cổ phiếu · bảng giá & số lượng', min: 18, sc: 'market_menu', avail: function (l) { return free(l) ? true : 'Cần đủ 18 tuổi, tự lập và được tự do giao dịch'; }, ai: { w: .1 } });
  var net = E.netWorth, total = E.assetTotal, profile = E.profile;
  E.netWorth = function (l) { return net(l) + value(l); };
  E.assetTotal = function (l) { return total(l) + value(l); };
  if (profile) E.profile = function (l) { var p = profile(l); Object.keys(l.marketBook && l.marketBook.positions || {}).forEach(function (s) { var q = quote(l, s), h = l.marketBook.positions[s]; p.assets.push([q.name + ' · ' + h.qty + ' ' + q.unit, convert(l, h.qty * q.bid, q.currency)]); }); p.net = E.netWorth(l); return p; };
  async function refresh(l, fetcher, current) {
    var response = await (fetcher || fetch)('/api/market', { cache: 'no-store', signal: typeof AbortSignal !== 'undefined' ? AbortSignal.timeout(12000) : undefined });
    if (!response.ok || !(response.headers.get('content-type') || '').includes('application/json')) throw Error('Chưa lấy được bảng giá mới. Đang giữ giá có thời điểm đã ghi.');
    var data = await response.json();
    if (!data.quotes || !Object.keys(data.quotes).some(function (s) { return goodQuote(data.quotes[s], s); })) throw Error('Nguồn chưa trả bảng giá hợp lệ.');
    if (current && !current()) return 'Đã đóng bảng giao dịch; chưa áp dụng giá mới.';
    sync(l, data); if (l.marketBook.simAt != null) return 'Đã kiểm tra mốc ngoài đời để tham khảo; giá mô phỏng trong cuộc đời này được giữ, không đặt lại.'; return data.errors && data.errors.length ? 'Một số nguồn chưa cập nhật được; các mã đó giữ thời điểm cũ.' : 'Đã kiểm tra bảng giá mới nhất từ nguồn.';
  }
  // Giá chạy mô phỏng riêng; số lượng / giá vốn không bị nhân lợi suất của danh mục cũ.
  E.MARKET = { book: book, quote: quote, value: value, sync: sync, refresh: refresh, qty: qty, max: max, valid: valid, evaluate: evaluate, execute: execute, summary: summary, free: free, convert: convert, native: native, fmt: fmt, symbols: GOLD.concat(VN, US), simulateYear: simulateYear, stamp: stamp, comparison: comparison };
})(G);

;
/* ===== js/life59.js ===== */
/* v4.9.0 — nghề phi pháp và mạng tội phạm theo nơi đang sống.
   Không tái hiện tổ chức thật; xác suất / thu nhập / mức án là cân bằng game. */
(function(G){
'use strict';var E=G.E,H=E.H,U=G.U,W=G.W;
var JOBS={doi_no:'cưỡng đoạt tài sản / đòi nợ bằng đe dọa',cho_vay:'tín dụng đen kèm cưỡng ép',lua_dao:'lừa đảo chiếm đoạt tài sản qua mạng',trom:'trộm cắp tài sản',ma_tuy:'mua bán trái phép chất gây nghiện',buon_lau:'buôn lậu hàng hóa',nha_cai:'tổ chức cá cược trái phép'};
var PROFILES=[
 ['jp','JP','Nhật Bản',['nhóm Yakuza','băng nhóm tội phạm'],['Lời mời từ một nhóm Yakuza','Một mối liên hệ rủ bạn gắn với nhóm Yakuza. Gia nhập không phải chuyện tự động và không thay thế điều kiện vào nghề.'],['Mối quan hệ trong nhóm','Một thành viên đòi bạn chứng minh sự trung thành, trong khi tranh chấp nội bộ ngày càng căng.']],
 ['it','IT','Ý',['nhóm kiểu Mafia','mạng tội phạm xuyên biên giới'],['Quan hệ kiểu gia tộc','Nhóm kiểu Mafia muốn biến quan hệ cá nhân thành nghĩa vụ lâu dài. Bạn không phải người thân của họ.'],['Chỗ trống quyền lực','Một người điều hành bị điều tra. Nhiều bên đòi phần ảnh hưởng, không ai có vị trí được bảo đảm.']],
 ['ru','RU','Nga',['mạng tội phạm kiểu Mafia','băng nhóm địa phương'],['Tranh chấp giữa các đầu mối','Hai người trong mạng tội phạm tại Nga bất đồng về khoản tiền bị thiếu.'],['Lời hứa chống lưng','Một đầu mối hứa sẽ bảo vệ bạn nếu tiếp tục dính líu. Lời hứa đó không làm bạn miễn bị bắt hoặc phản bội.']],
 ['us','US','Mỹ',['nhóm kiểu Mafia','băng nhóm địa phương'],['Một đầu mối mới','Một người trong mạng tội phạm ở Mỹ đòi mở rộng quan hệ, nhưng bạn chưa biết trách nhiệm đi kèm.'],['Đồng phạm bị triệu tập','Một người liên quan bị cơ quan điều tra triệu tập. Bạn chưa biết họ sẽ khai những gì.']],
 ['mx','MX','Mexico',['nhóm kiểu cartel','mạng tội phạm địa phương'],['Áp lực từ nhóm kiểu cartel','Nhóm kiểu cartel yêu cầu các thành viên chịu thêm rủi ro, trong khi phần thu nhập không minh bạch.'],['Mâu thuẫn về người đứng đầu','Hai người tự nhận quyền điều hành cùng gây sức ép với bạn; việc đứng về bên nào cũng có hậu quả.']],
 ['co','CO','Colombia',['nhóm kiểu cartel','mạng tội phạm'],['Quan hệ cũ quay lại','Một người từng liên quan đến nhóm kiểu cartel muốn kéo bạn sâu hơn vào việc bất chính.'],['Khoản tiền đang tranh chấp','Một khoản chia phần bị nhiều bên đòi nhận, làm mối liên hệ trong nhóm rạn nứt.']],
 ['br','BR','Brazil',['băng nhóm tội phạm','mạng tội phạm'],['Người mới và người cũ','Nhóm có người mới gia nhập, người cũ lo bị mất ảnh hưởng.'],['Người quen muốn rời nhóm','Một thành viên nói muốn rút lui, nhưng người điều hành chưa chịu chấp nhận.']],
 ['uk','GB,IE','Anh / Ireland',['mạng tội phạm có tổ chức','băng nhóm địa phương'],['Đầu mối bị bắt giữ','Một đầu mối trong mạng tội phạm ở nơi bạn sống bị bắt giữ; chưa có kết quả điều tra cuối cùng.'],['Xung đột lợi ích','Những người có liên quan tranh cãi về khoản tiền và trách nhiệm pháp lý.']],
 ['eu','FR,DE,ES,PT,NL,BE,CH,AT,SE,NO,FI,DK,PL,GR,CZ,RO,BG,HU,HR,SK,SI,EE,LV,LT','châu Âu',['mạng tội phạm xuyên biên giới','nhóm kiểu Mafia'],['Liên hệ xuyên biên giới','Mạng ở nước bạn đang sống có quan hệ bên ngoài. Điều này không tự cho bạn quyền hoạt động hay miễn trách nhiệm tại nước khác.'],['Một vụ điều tra phối hợp','Nhóm nghe tin một số đầu mối đang bị nhiều cơ quan điều tra theo dõi. Không ai biết kết quả cuối cùng.']],
 ['ca','CA','Canada',['mạng tội phạm có tổ chức','băng nhóm địa phương'],['Lời hứa chia lợi nhuận','Một đầu mối hứa chia thêm tiền nhưng không chịu làm rõ trách nhiệm.'],['Người liên quan đổi lời','Một người quen trong nhóm phủ nhận thỏa thuận cũ, khiến tranh chấp tăng lên.']],
 ['pac','AU,NZ','Úc / New Zealand',['mạng tội phạm có tổ chức','băng nhóm địa phương'],['Tranh chấp trong mạng lưới','Một tranh chấp về phần tiền làm những người liên quan quay sang gây sức ép với nhau.'],['Một cơ hội làm lại','Bạn nghe về một cơ hội tìm việc hợp pháp, nhưng nhóm muốn bạn tiếp tục liên quan.']],
 ['sea','TH,KH,LA,MM,MY,SG,ID,PH,BN,TL','Đông Nam Á',['mạng tội phạm xuyên biên giới','băng nhóm địa phương'],['Lời mời hợp tác đáng ngờ','Một người trong mạng muốn bạn tham gia việc mới mà không nói rõ hậu quả. Người đang bị ép trong trại lừa đảo không được coi là tự nguyện gia nhập.'],['Người liên quan muốn cầu cứu','Một người trong mối liên hệ nói họ bị đe dọa và muốn tìm hỗ trợ an toàn.']],
 ['asia','CN,KR,MN,IN,PK,BD,LK,NP,BT','châu Á',['mạng tội phạm có tổ chức','băng nhóm địa phương'],['Mâu thuẫn giữa các mối liên hệ','Một khoản tiền và lời hứa không khớp khiến những người liên quan tranh cãi.'],['Danh tiếng giả tạo','Người điều hành muốn bạn tin rằng họ không thể bị điều tra. Bạn không có bằng chứng cho lời khẳng định đó.']],
 ['other','','quốc gia đang sống',['mạng tội phạm có tổ chức','băng nhóm địa phương'],['Một liên hệ có tổ chức','Một người rủ bạn gắn với mạng tội phạm ở nơi đang sống. Bạn có quyền từ chối.'],['Quan hệ cũ trở thành gánh nặng','Những nghĩa vụ không rõ ràng bắt đầu khiến bạn mất thời gian và lo ngại về trách nhiệm.']]
];
var CASES=[],BY={};PROFILES.forEach(function(p){p[1].split(',').filter(Boolean).forEach(function(code){BY[code]=p;});[p[4],p[5]].forEach(function(c,i){CASES.push({id:'network_'+p[0]+'_'+i,profile:p[0],joined:true,title:c[0],text:c[1]});});});
var ROWS=`
doi_no|Đòi một khoản không rõ ràng|Người bị đe dọa nói rằng khoản nợ bị ghi sai. Bạn không có căn cứ để coi lời đe dọa là hợp pháp.
doi_no|Người bị hại tìm hỗ trợ|Một người bị nhóm gây sức ép đã tìm hỗ trợ pháp lý. Những việc đã làm vẫn có thể bị xem xét.
doi_no|Mâu thuẫn về tiền chia|Người liên quan đòi phần tiền vượt thỏa thuận cũ, làm phát sinh tranh chấp.
doi_no|Hậu quả của đe dọa|Bạn nhận ra việc đe dọa gây tổn hại thật, còn người giao việc cố đẩy trách nhiệm sang bạn.
cho_vay|Khoản thu bị tranh cãi|Người vay phản đối các khoản thu và hành vi cưỡng ép. Không thể coi mọi khoản cho vay hợp pháp là tín dụng đen.
cho_vay|Một lời tố cáo|Một người bị đe dọa gửi thông tin cho cơ quan chức năng, bạn phải đối mặt khả năng bị điều tra.
cho_vay|Người cùng nhóm giấu tiền|Số tiền được chia không khớp lời hứa; người giữ tiền không giải thích rõ.
cho_vay|Muốn chấm dứt cưỡng ép|Bạn cân nhắc ngừng những hành vi đe dọa, nhưng các mối liên hệ cũ vẫn gây sức ép.
lua_dao|Người bị hại lên tiếng|Người bị lừa chia sẻ câu chuyện và đề nghị cơ quan chức năng tiếp nhận thông tin.
lua_dao|Đồng phạm bị bắt|Một người có liên quan bị bắt; bạn chưa biết phạm vi điều tra tới đâu.
lua_dao|Khoản chia bị giữ lại|Người hứa trả tiền liên tục trì hoãn, trong khi trách nhiệm của bạn không biến mất.
lua_dao|Nhận ra tổn hại|Bạn nghe hoàn cảnh của một người bị chiếm đoạt tiền. Đây không còn là những con số vô danh.
trom|Tài sản bị nhận diện|Một món tài sản liên quan tới vụ trộm được người sở hữu nhận diện. Bạn có nguy cơ phải chịu trách nhiệm.
trom|Người quen muốn rút|Một người từng liên quan nói không muốn tiếp tục, khiến bạn phải nhìn lại lựa chọn của mình.
trom|Tranh chấp khoản tiền|Một người đòi phần tiền mà bạn không chấp nhận; cả hai đều có những việc không muốn nhắc lại.
trom|Dấu vết từ vụ cũ|Bạn được biết một vụ trộm trước đây vẫn đang được xem xét, không tự biến mất vì thời gian trôi qua.
ma_tuy|Người liên quan gặp nạn|Một người trong các mối liên hệ của bạn gặp vấn đề sức khỏe nghiêm trọng. Hoạt động trái phép gây hậu quả ngoài tiền bạc.
ma_tuy|Lời hứa thu nhập cao|Một người muốn bạn nhận thêm trách nhiệm để đổi lấy tiền, nhưng không thể bảo đảm an toàn.
ma_tuy|Mối liên hệ bị điều tra|Một người liên quan bị cơ quan chức năng điều tra. Chức vụ cao không tạo miễn trừ.
ma_tuy|Khoản tiền thiếu hụt|Khoản chia phần không như lời hứa, người có liên quan quay sang đổ trách nhiệm cho nhau.
buon_lau|Hàng bị thu giữ|Một phần tài sản liên quan bị lực lượng chức năng thu giữ. Bạn chưa biết kết luận xử lý.
buon_lau|Đối tác biến mất|Một người từng hứa chia lợi nhuận ngừng liên lạc, khiến bạn có nguy cơ mất khoản đã góp.
buon_lau|Người liên quan bị triệu tập|Một đầu mối bị triệu tập làm việc; không có chức vụ nào bảo đảm được miễn trách nhiệm.
buon_lau|Một cơ hội rút lui|Một người quen nói muốn dừng việc trái phép và tìm công việc hợp pháp.
nha_cai|Tranh chấp tiền cược|Một người tham gia cá cược trái phép đòi tiền, tranh chấp lan sang các mối liên hệ khác.
nha_cai|Người chơi lâm vào cảnh nợ|Bạn biết việc tổ chức cá cược trái phép đang gây tổn hại cho người tham gia.
nha_cai|Người cùng nhóm sai hẹn|Một người giữ khoản tiền không chịu làm rõ phần chia, khiến áp lực tăng lên.
nha_cai|Hoạt động bị xem xét|Bạn nghe rằng hoạt động cá cược không phép có thể bị cơ quan chức năng điều tra. Casino hoặc cá cược có phép không tự động bị coi là nghề này.
`.trim().split('\n');ROWS.forEach(function(line,i){var x=line.split('|');CASES.push({id:'job_'+i,job:x[0],title:x[1],text:x[2]});});
[
 ['Cơ hội rời việc bất chính','Có người giới thiệu cách tìm việc hợp pháp. Chưa có lời hứa chắc chắn được tuyển.'],
 ['Sức ép từ người liên quan','Một người trong mối liên hệ đòi bạn chịu thêm trách nhiệm về việc trước đây.'],
 ['Tin đồn trong băng nhóm','Trong nhóm rộ lên tin có người khai báo với cảnh sát. Ai cũng nghi ngờ nhau.'],
 ['Giữ lại một đường lui','Bạn cân nhắc dừng việc trái phép trước khi gây thêm tổn hại.'],
 ['Khoản vốn có thể mất','Một người quen rủ bạn góp tiền vào vụ làm ăn mới nhưng chưa nói rõ cách chia lợi nhuận.'],
 ['Gia đình cần câu trả lời','Một người thân còn sống muốn biết vì sao bạn luôn lo lắng, nhưng bạn chưa biết nên nói thế nào.',true],
 ['Đối diện chuyện cũ','Một chuyện trước đây có thể bị xem xét trở lại; rời nghề không tự xóa trách nhiệm.'],
 ['Người quen muốn làm lại','Một người liên quan nói họ cần hỗ trợ để tìm cuộc sống hợp pháp, không muốn nghe thêm lời hứa kiếm tiền nhanh.']
].forEach(function(x,i){CASES.push({id:'common_'+i,title:x[0],text:x[1],family:x[2]});});
function current(l){return l.abroad&&l.abroad.code||l.country;}
function foreign(l){return current(l)!=='VN'&&!!W.BY[current(l)];}
function free(l){return l.alive&&l.age>=18&&!(l.jailUntil!=null&&l.age<l.jailUntil)&&!(l.flags.military&&l.age<l.flags.military)&&!(l.abroad&&l.abroad.trapped);}
function job(l){return l.job&&JOBS[E.resolveJob(l.job.id)]?E.resolveJob(l.job.id):null;}
function profile(l){return BY[current(l)]||PROFILES[PROFILES.length-1];}
function state(l){
 var s=l.flags.worldCrime||(l.flags.worldCrime={groups:{},seen:{},serial:0,count:0}),code=current(l);
 if(s.current!==code){var old=s.groups[s.current];if(old)old.joined=false;s.current=code;s.serial++;var u=l.flags.underworld;if(u&&u.worldOrigin&&u.worldOrigin!==code)u.linked=false;}
 if(!s.groups[code])s.groups[code]={joined:false,choice:0,trust:30};return s;
}
function group(l){var s=state(l);return s.groups[current(l)];}
function label(l){var p=profile(l),g=group(l);return p[3][g.choice||0];}
function hasFamily(l){return !!(l.fam&&(l.fam.mAlive||l.fam.fAlive))||!!(l.partner&&l.partner.alive!==false)||(l.kids||[]).some(function(k){return k.alive===true;})||(l.sibList||[]).some(function(k){return k.alive===true;});}
function under(l){return l.flags.underworld||(l.flags.underworld={linked:false,heat:0,hunted:false});}
function heat(l,n){var u=under(l);u.heat=U.clamp((u.heat||0)+n,0,100);}
function jobKey(l){return[l.job&&l.job.id,l.job&&l.job.rank,l.job&&l.job.since,l.job&&l.job.rankSince,l.flags.worldCareerSerial||0].join('|');}
function context(l){var s=state(l);return{code:current(l),at:l.age,job:jobKey(l),token:++s.serial};}
function validContext(l,d){return foreign(l)&&free(l)&&d&&d.code===current(l)&&d.at===l.age&&d.job===jobKey(l)&&d.token===state(l).serial;}
function leave(l,log){group(l).joined=false;under(l).linked=false;if(job(l))E.quitCrime(l,log,'Chấm dứt công việc trái phép, bắt đầu tìm việc hợp pháp.');heat(l,-8);if(under(l).hunted)log('Đã rời việc bất chính nhưng mối đe dọa cũ vẫn cần được giải quyết.','neutral');}
function pool(l){if(!foreign(l)||!free(l))return[];var s=state(l),g=group(l);if(!job(l)&&!g.joined||s.at===l.age&&s.count>=2)return[];var p=profile(l);return CASES.filter(function(c){var seen=s.seen[c.id];return(!c.job||c.job===job(l))&&(!c.profile||c.profile===p[0])&&(!c.joined||g.joined)&&(!c.family||hasFamily(l))&&(seen==null||l.age-seen>=5);});}
function eventValid(l,d){return d&&d.caseId?validContext(l,d)&&pool(l).some(function(c){return c.id===d.caseId;}):pool(l).length>0;}
function caseFor(d){return CASES.filter(function(c){return c.id===d.caseId;})[0];}
function mark(l,d){var s=state(l);if(s.at!==l.age){s.at=l.age;s.count=0;}s.count++;s.seen[d.caseId]=l.age;s.serial++;}
function capital(l){return Math.max(0,l.base)*.08;}
function arrest(l){if(!(l.sched||[]).some(function(s){return s.id==='bi_bat';})&&!(l.jailUntil!=null&&l.age<l.jailUntil))H.sched(l,'bi_bat',0,{why:'tham gia hoạt động trái phép trong mạng tội phạm',sev:2});}
function outcome(l,r,log,d,k){if(!eventValid(l,d))return;var c=caseFor(d);if(k==='risk'&&l.money<capital(l))return;mark(l,d);
 var where=W.BY[current(l)].name+' · '+c.title+': ';
 if(k==='risk'){var amt=capital(l);H.cash(l,-amt,'Vốn việc làm bất chính');heat(l,12);H.fx(l,{karma:-3});if(r()<.45){var payout=amt*1.8;H.cash(l,payout,'Thu hồi vốn và khoản chia bất chính');log(where+'bạn tiếp tục dính líu, tự góp '+H.money(l,amt)+', nhận lại '+H.money(l,payout)+' gồm vốn. Rủi ro pháp lý và trả thù vẫn còn.','bad');}else{log(where+'việc đổ bể, mất '+H.money(l,amt)+' đã góp; các mối liên hệ quay sang trách móc.','bad');if(r()<.18+(under(l).heat||0)/1000)arrest(l);} }
 else if(k==='leave'){leave(l,log);log(where+'bạn quyết định rời việc bất chính, tìm đường làm lại.','good');}
 else if(k==='legal'){heat(l,-4);H.fx(l,{karma:2});log(where+'bạn dừng phần việc và nhờ luật sư tư vấn.','neutral');}
 else{heat(l,2);if(l.mind)l.mind.stress=U.clamp(l.mind.stress+2,0,100);log(where+'bạn chưa quyết định, sức ép từ những việc đã liên quan vẫn còn.','neutral');}
}
E.SC('wc_su_kien',{title:function(l,d){var c=caseFor(d);return c?c.title:'Chuyện trong thế giới ngầm';},valid:eventValid,prep:function(l,r){var p=pool(l);if(!p.length)return{};var c=U.pick(r,p),d=context(l);d.caseId=c.id;return d;},text:function(l,d){var c=caseFor(d);return c?W.BY[current(l)].name+' · '+(group(l).joined?label(l):'các mối liên hệ bất chính')+'. '+c.text:'';},opts:[
 {k:'legal',l:'Tạm dừng, nhờ luật sư tư vấn',ai:{w:1.2},run:function(l,r,log,d){outcome(l,r,log,d,'legal');}},
 {k:'risk',l:function(l){return'Tiếp tục dính líu · tự góp '+H.money(l,capital(l));},req:function(l){return l.money>=capital(l);},ai:{bad:1,risk:1},run:function(l,r,log,d){outcome(l,r,log,d,'risk');}},
 {k:'leave',l:'Rời nhóm, tìm việc khác',ai:{w:.8},run:function(l,r,log,d){outcome(l,r,log,d,'leave');}},
 {k:'later',l:'Chờ thêm tin tức',run:function(l,r,log,d){outcome(l,r,log,d,'later');}}
]});
E.SC('wc_to_chuc',{title:'Chọn mối liên hệ trong thế giới ngầm',valid:function(l,d){return foreign(l)&&free(l)&&(!d||!d.code||validContext(l,d));},prep:context,text:function(l){return W.BY[current(l)].name+' · Có người muốn kéo bạn vào nhóm. Bạn nhận lời hay từ chối?' ;},opts:[0,1].map(function(i){return{k:'g'+i,l:function(l){return'Nhận lời liên hệ với '+profile(l)[3][i];},run:function(l,r,log,d){if(!validContext(l,d))return;var g=group(l);g.joined=true;g.choice=i;var u=under(l);u.linked=true;u.worldOrigin=current(l);heat(l,8);state(l).serial++;log('Nhận lời liên hệ với '+label(l)+' tại '+W.BY[current(l)].name+'.','bad');}};}).concat([{k:'no',l:'Từ chối, không gia nhập',run:function(){}}])});
E.SC('wc_nghe',{title:'Nghề phi pháp tại nơi đang sống',valid:function(l,d){return foreign(l)&&free(l)&&(!d||!d.code||validContext(l,d));},prep:context,text:function(l){return W.BY[current(l)].name+' · Chọn hoạt động trái phép, không phải nghề hợp pháp cùng lĩnh vực. Những khoản vay, casino hay dịch vụ hợp pháp không thuộc các lựa chọn này. Mỗi nghề có sự kiện riêng; bắt đầu từ bậc thấp, không tự gia nhập tổ chức.';},opts:Object.keys(JOBS).map(function(id){return{k:id,l:JOBS[id],req:function(l){return job(l)!==id&&(id!=='cho_vay'||l.money>l.base);},run:function(l,r,log,d){if(!validContext(l,d))return;E.startJob(l,id,r,log);}};}).concat([{k:'no',l:'Không tham gia',run:function(){}}])});
E.SC('wc_menu',{title:'Thế giới ngầm tại nơi đang sống',prep:context,valid:function(l,d){return foreign(l)&&free(l)&&(!d||!d.code||validContext(l,d));},text:function(l){return W.BY[current(l)].name+' · '+(group(l).joined?'Đang liên hệ với '+label(l):'Chưa gia nhập tổ chức địa phương')+'. '+(under(l).hunted?'Mối đe dọa truy sát cũ vẫn còn. ':'')+'Bạn muốn làm gì tiếp?' ;},opts:[
 {k:'group',l:'Xem lời mời từ tổ chức địa phương',req:function(l){return !group(l).joined;},run:function(l,r){l.pending.unshift(E.DEC.wc_to_chuc.make(l,r));}},
 {k:'job',l:'Xem các nghề phi pháp tại nơi đang sống',run:function(l,r){l.pending.unshift(E.DEC.wc_nghe.make(l,r));}},
 {k:'event',l:'Giải quyết chuyện trong nghề / tổ chức',req:function(l){return pool(l).length>0;},run:function(l,r){l.pending.unshift(E.DEC.wc_su_kien.make(l,r));}},
 {k:'leave',l:'Chấm dứt quan hệ và công việc bất chính',req:function(l){return group(l).joined||!!job(l);},run:function(l,r,log){leave(l,log);}},
 {k:'no',l:'Đóng lại',run:function(){}}
]});
['wc_menu','wc_nghe','wc_to_chuc','wc_su_kien'].forEach(function(id){var D=E.DEC[id],ap=D.apply;D.apply=function(l,d){if(!D.valid(l,d.data))return;return ap.apply(this,arguments);};});
// Tái dùng lối vào cũ; các nút và bản lưu Việt Nam vẫn tiếp tục cơ chế cũ.
['kiem_tien_ban','uw_quan_he'].forEach(function(id){var old=E.DEC[id],mk=old.make,ap=old.apply,v=old.valid;old.make=function(l,r,a){return foreign(l)?E.DEC[id==='kiem_tien_ban'?'wc_nghe':'wc_menu'].make(l,r,a):mk.call(this,l,r,a);};old.apply=function(l,d){return foreign(l)?E.DEC[id==='kiem_tien_ban'?'wc_nghe':'wc_menu'].apply.apply(this,arguments):ap.apply(this,arguments);};old.valid=function(l,d){return foreign(l)?free(l):v(l,d);};});
var invitation=E.DEC.ru_re,im=invitation.make,iv=invitation.valid,ia=invitation.apply;
invitation.make=function(l,r,a){var d=im.call(this,l,r,a);if(foreign(l)){d.data.wc=context(l);d.text='Tại '+W.BY[current(l)].name+', một người quen rủ bạn tham gia '+JOBS[d.data.id]+'. Đây là lời mời hoạt động trái phép, không phải tuyển dụng hợp pháp. Nhận lời không tự gia nhập '+profile(l)[3][0]+'.';d.opts.forEach(function(o){if(o.k==='report')o.l='Cung cấp thông tin cho cảnh sát';});}return d;};
invitation.valid=function(l,d){return foreign(l)?free(l)&&!job(l)&&(!d||!d.wc||validContext(l,d.wc)):iv(l,d);};
invitation.apply=function(l,d,k,r,log){if(!foreign(l))return ia.apply(this,arguments);if(!invitation.valid(l,d.data)||d.data.worldUsed)return;d.data.worldUsed=true;state(l).serial++;if(k==='join'){if(l.job)l.lastJob=l.job;E.startJob(l,d.data.id,r,log);}else if(k==='report'){H.fx(l,{karma:3});log('Cung cấp thông tin cho cảnh sát tại '+W.BY[current(l)].name+'. Thông tin cần được xác minh; chưa có kết quả điều tra hoặc kết luận về tổ chức.','good');}else log('Từ chối lời mời tham gia hoạt động trái phép.','good');};
var mem=H.mem;H.mem=function(l,t){if(foreign(l)&&job(l)&&/^Ngày bạn bước chân vào con đường /.test(t)){var args=Array.prototype.slice.call(arguments);args[1]='Ngày bước chân vào hoạt động '+JOBS[job(l)]+'.';return mem.apply(this,args);}return mem.apply(this,arguments);};
// Các cảnh đường dây cũ mang bối cảnh Việt Nam được thay bằng bộ mới ở nước ngoài.
Object.keys(E.DEC).filter(function(id){return /^dd_/.test(id)||/^uw_(phan_boi|chia_phan|tong_tien|dieu_tra|mat_von|gia_dinh|dan_em_gap_nan|duong_lui)$/.test(id);}).forEach(function(id){var d=E.DEC[id],v=d.valid;d.valid=function(l,data){return !foreign(l)&&v(l,data);};E.TRIG.filter(function(t){return t.id===id;}).forEach(function(t){var before=t.when;t.when=function(l,a){return !foreign(l)&&before(l,a);};});});
var title=E.jobTitle;E.jobTitle=function(l){var base=title(l);if(!foreign(l)||!job(l))return base;return JOBS[job(l)]+' · bậc '+((l.job.rank||0)+1)+(group(l).joined?' · '+label(l):' · '+W.BY[current(l)].name);};
var start=E.startJob;E.startJob=function(l,id,r,log,quiet){var resolved=E.resolveJob(id);if(foreign(l)&&JOBS[resolved]&&!free(l))return false;var before=l.job;if(foreign(l)&&JOBS[resolved]&&l.abroad&&l.abroad.study){l.abroad=Object.assign({},l.abroad,{study:false,studyEnded:true});}var result=start(l,id,r,function(t,k){if(foreign(l)&&job(l)&&/^Bắt đầu công việc mới:/.test(t))t='Bắt đầu công việc mới: '+E.jobTitle(l)+'.';if(log)log(t,k);},quiet);if(foreign(l)&&JOBS[resolved]&&l.job!==before){l.flags.worldCareerSerial=(l.flags.worldCareerSerial||0)+1;state(l).serial++;}return result;};
var quit=E.quitCrime;E.quitCrime=function(l){if(l.flags.worldCrime){Object.keys(l.flags.worldCrime.groups).forEach(function(code){l.flags.worldCrime.groups[code].joined=false;});l.flags.worldCrime.serial++;}return quit.apply(this,arguments);};
var rankText=E.rankUpText;E.rankUpText=function(l,c){if(foreign(l)&&job(l))return{t:'Bạn được giao vị trí cao hơn trong hoạt động '+JOBS[job(l)]+'. Thu nhập theo bậc mới nhưng nguy cơ điều tra, phản bội vẫn còn.',m:'Một bước lún sâu hơn vào công việc trái phép.'};return rankText?rankText.apply(this,arguments):null;};
E.ACT.push({id:'wc_menu',g:'Đường tối',l:'Tổ chức / nghề phi pháp nơi đang sống',min:18,sc:'wc_menu',avail:function(l){return foreign(l)&&free(l)?true:'Mục này dành cho nhân vật đủ 18 tuổi đang ở nước ngoài và được tự do';},ai:{w:.08}});
E.TRIG.push({id:'wc_su_kien',when:function(l){return pool(l).length>0;},p:.6,cd:1,rep:true});
E.WORLD_CRIME={jobs:JOBS,cases:CASES,profiles:PROFILES,current:current,profile:profile,group:group,pool:pool,context:context,valid:eventValid,state:state,free:free};
})(G);

;
/* ===== js/life60.js ===== */
/* v4.10.0 — Xưởng phim: hồ sơ diễn viên và dự án đều là mô phỏng hư cấu.
   Ngân sách hãng không đi qua ví người chơi; chỉ cát-xê / vốn cá nhân được ghi sổ. */
(function (G) {
  'use strict';
  var E=G.E,H=E.H,U=G.U;
  if(!E.CONCERT_CATS.kr.a.some(function(a){return a.n==='T-ara';}))E.CONCERT_CATS.kr.a.push({n:'T-ara',b:1989});
  if(E.IDOLS.world.indexOf('T-ara')<0)E.IDOLS.world.push('T-ara');E.IDOL_BORN['T-ara']=1989;
  if(E.TALENTS.indexOf('đạo diễn')<0)E.TALENTS.push('đạo diễn');
  E.CAR.dao_dien.talent='đạo diễn';
  E.TALENT_SCHOOLS['đạo diễn']={sug:'trợ lý đạo diễn → đạo diễn điện ảnh, truyền hình, phim ngắn và nội dung số',sch:[
    ['dd_hn','Trường Đại học Sân khấu – Điện ảnh Hà Nội','Hà Nội','art','Đạo diễn điện ảnh',.58,'uni',['dao_dien','bien_kich'],'thi năng khiếu tư duy hình ảnh, kể chuyện và phân tích phim (mô phỏng)'],
    ['dd_hcm','Trường Đại học Sân khấu – Điện ảnh TP. Hồ Chí Minh','TP. Hồ Chí Minh','art','Đạo diễn điện ảnh – truyền hình',.56,'uni',['dao_dien','bien_kich'],'thi phân tích phim, kể chuyện bằng hình ảnh (mô phỏng)'],
    ['dd_tv','Trường Đại học Sân khấu – Điện ảnh Hà Nội','Hà Nội','art','Đạo diễn truyền hình',.54,'uni',['dao_dien'],'thi năng khiếu và tư duy kể chuyện truyền hình (mô phỏng)']
  ]};
  var uni=E.DEC.uni,um=uni.make,ua=uni.apply;
  uni.make=function(l){var d=um.apply(this,arguments);if(l.talent==='đạo diễn'&&H.isVN(l))d.text+=' Bạn có năng khiếu đạo diễn: có thể chọn một trong các trường / ngành đạo diễn bên dưới. Đỗ mới bắt đầu khóa học 4 năm, tốt nghiệp rồi làm trợ lý trước. Cách thi và xác suất trong game được giản lược, không phải quy chế tuyển sinh thật.';return d;};
  uni.apply=function(l,d,k){if(/^nk_dd_/.test(k)&&(!free(l)||l.age<18||l.edu<3||l.talent!=='đạo diễn'||!H.isVN(l)||!d.opts.some(function(o){return o.k===k;})||l.school))return;return ua.apply(this,arguments);};
  function filmStudent(l){return !!(l.school==='uni'&&l.major==='art'&&l.flags.tSchool&&!l.flags.tSchool.out&&/^(dd_|skda_dd)/.test(l.flags.tSchool.id));}
  // Không đưa sinh viên đạo diễn đi thực tập kiến trúc chỉ vì cùng nhóm ngành art.
  var intern=E.DEC.thuc_tap.def,ip=intern.prep;intern.prep=function(l,r){return filmStudent(l)?{p:[U.pick(r,['một đoàn phim truyền hình','xưởng phim thực nghiệm','ê-kíp phim ngắn độc lập']),'dao_dien']}:ip.apply(this,arguments);};
  var thesis=E.DEC.bao_ve_tn.def,tt=thesis.title,tx=thesis.text;
  thesis.title=function(l){return filmStudent(l)?'Bảo vệ đồ án phim tốt nghiệp':tt(l);};
  thesis.text=function(l){return filmStudent(l)?'Năm cuối ngành '+l.flags.tSchool.mn+' tại '+l.flags.tSchool.n+': trình bày phim bài tập, ý đồ đạo diễn, hồ sơ sản xuất và trả lời hội đồng. Vẫn phải đạt yêu cầu mới tốt nghiệp; chưa được cấp bằng ngay khi nhập học.':tx(l);};
  var FORMATS={tv:{n:'Phim truyền hình',budget:1800,fee:100,reach:250000},cinema:{n:'Phim điện ảnh',budget:6000,fee:250,reach:600000},web:{n:'Phim web drama',budget:450,fee:40,reach:100000},short:{n:'Phim ngắn',budget:45,fee:6,reach:12000}};
  var GENRES={drama:'Chính kịch',romance:'Tình cảm',action:'Hành động',horror:'Kinh dị',comedy:'Hài',mystery:'Trinh thám',fantasy:'Kỳ ảo',family:'Gia đình',scifi:'Khoa học viễn tưởng',history:'Lịch sử'};
  var STAGES=['format','medium','source','genre','fund','cast1','cast2','script','board','prep','shoot1','shoot2','incident','edit','sound','release'];
  var TITLES=['Chọn định dạng phim','Người đóng hay hoạt hình?','Câu chuyện và quyền chuyển thể','Chọn thể loại phim','Ký hợp đồng sản xuất','Casting vai chính','Casting vai đối trọng','Phòng kịch bản','Mini game: sắp xếp storyboard','Tiền kỳ và lịch sản xuất','Ngày sản xuất thứ nhất','Mini game: bắt lỗi liên tục','Biến cố trong đoàn','Hậu kỳ: dựng phim','Âm thanh và bản nhạc','Phát hành và gặp khán giả'];
  var STRENGTHS=['biểu cảm tinh tế','đài từ rõ','phối hợp bạn diễn tốt','ứng biến nhanh','diễn bằng ánh mắt','kỷ luật trường quay'];
  var WEAKNESSES=['khó giữ nhịp cảnh dài','cần luyện giọng','dễ căng thẳng trước ống kính','chưa quen kỹ xảo','cần tập cảnh hành động','cần thêm thời gian nhập vai'];
  var INCIDENTS=[
    ['Mưa lớn trùng lịch ngoại cảnh.','Chuyển sang cảnh nội, giữ ngày nghỉ','Cố quay giữa mưa nguy hiểm'],
    ['Diễn viên mất giọng, lịch thu thoại bị chậm.','Dời cảnh thoại, cho diễn viên nghỉ','Ép quay đủ cảnh bất chấp sức khỏe'],
    ['Một cảnh bị rò rỉ lên mạng trước lịch quảng bá.','Khoanh vùng bản dựng, công bố thông tin phù hợp','Đổ lỗi công khai khi chưa xác minh'],
    ['Đạo cụ giao sai màu, không khớp cảnh đã quay.','Sửa đạo cụ và chụp ảnh đối chiếu','Bỏ qua vì nghĩ khán giả không để ý'],
    ['Đoàn tranh luận vì lịch làm việc quá dày.','Điều chỉnh lịch, giới hạn giờ làm','Tiếp tục ép đoàn tăng ca'],
    ['Khán giả thử nghiệm chưa hiểu động cơ nhân vật.','Dựng lại điểm nhìn và thêm cảnh nối đã có','Giữ nguyên mọi thứ mặc phản hồi']
  ];
  function year(l){return l.birthYear+l.age;}
  function location(l){return (l.abroad&&l.abroad.code)||l.country;}
  function free(l){return l.alive&&l.age>=18&&!(l.jailUntil!=null&&l.age<l.jailUntil)&&!(l.flags.military&&l.age<l.flags.military)&&!(l.abroad&&l.abroad.trapped);}
  function showBusy(l){var f=l.flags;return !!((f.tv&&!f.tv.done&&!f.tv.out&&!f.tv.no)||(f.variety&&!f.variety.done));}
  function project(l){return l.flags.film;}
  function busy(l){return !!(project(l)&&!project(l).done);}
  function director(l){return !!(l.job&&E.resolveJob(l.job.id)==='dao_dien'&&!l.school&&!l.retired&&l.edu>=5);}
  function jobKey(l){var j=l.job;return j?[j.id,j.since,j.rankSince,j.rank].join(':'):'';}
  function canStart(l){return free(l)&&director(l)&&l.st.hea>=35&&!showBusy(l)&&!busy(l)&&(!project(l)||project(l).year!==year(l));}
  function value(l,n){return n/90*l.base;}
  function context(l){return {year:year(l),country:location(l),cur:l.cur,job:jobKey(l)};}
  function same(l,d){return d&&d.year===year(l)&&d.country===location(l)&&d.cur===l.cur&&d.job===jobKey(l);}
  function valid(l,d){var p=project(l);return free(l)&&director(l)&&l.st.hea>=25&&!showBusy(l)&&!!p&&!p.done&&same(l,p)&&(!d||(d.token===p.token&&d.stage===p.stage));}
  function role(l){return project(l).medium==='animation'?'diễn viên lồng tiếng':'diễn viên';}
  function format(p){return FORMATS[p.format];}
  function candidate(l,r,i){var age=U.randint(r,18,62),vn=location(l)==='VN',co=G.W.BY[location(l)],province=vn?U.pick(r,G.VN.P63).name:co?U.pick(r,co.cities)+' · '+co.name:(l.abroad&&l.abroad.name)||l.countryName;
    return {id:project(l).token+':'+i,name:H.stranger(l,r,r()<.5?'M':'F'),born:year(l)-age,home:province,acting:U.randint(r,35,95),voice:U.randint(r,35,95),reliable:U.randint(r,45,95),genre:U.pick(r,Object.keys(GENRES)),strength:U.pick(r,STRENGTHS),weakness:U.pick(r,WEAKNESSES)};
  }
  function casting(l,r){var p=project(l);p.candidates=[];for(var i=0;i<6;i++){var a=candidate(l,r,i);if(p.candidates.some(function(x){return x.name===a.name;}))a.name+=' '+(i+1);p.candidates.push(a);}p.cast=[];}
  function actorText(l,a){var p=project(l);return a.name+' · '+(year(l)-a.born)+' tuổi · Quê: '+a.home+' · Diễn xuất '+a.acting+'/100 · Giọng '+a.voice+'/100 · Kỷ luật '+a.reliable+'/100 · Sở trường '+GENRES[a.genre]+'. Mạnh: '+a.strength+'. Yếu: '+a.weakness+'.'+(p.medium==='animation'?' Casting giọng, không đánh giá ngoại hình.':'');}
  function cancel(l,log,why){var p=project(l);if(!p||p.done)return;p.done=true;p.status='cancelled';p.reason=why||'tự dừng dự án';log('Dừng dự án '+p.name+': '+p.reason+'.'+(p.funding==='self'?' Vốn đã chi không tự hoàn lại.':' Hãng chịu ngân sách sản xuất; chưa phát hành nên bạn chưa nhận cát-xê hoàn tất.'),'neutral');l.pending=l.pending.filter(function(d){return d.id!=='film_step';});}
  function queue(l,r,log){if(!valid(l)){cancel(l,log,'lịch / nghề / nơi ở / sức khỏe không còn phù hợp');return;}l.pending.unshift(E.DEC.film_step.make(l,r));}
  function start(l,r,log){if(!canStart(l))return;var token=l.flags.filmSerial=(l.flags.filmSerial||0)+1;
    l.flags.film=Object.assign(context(l),{token:token,stage:0,done:false,status:'development',name:U.pick(r,['Mùa gió trở lại','Phía bên kia cửa','Chuyến xe cuối ngày','Một lời chưa nói','Ánh sáng cuối phố','Ngày mai bắt đầu'])+' #'+token,quality:40,trust:50,history:[],incident:U.randint(r,0,INCIDENTS.length-1)});
    queue(l,r,log);
  }
  function o(k,l,h){return{k:k,l:l,h:h||''};}
  function choices(l){var p=project(l),s=STAGES[p.stage],a=[];
    if(s==='format')Object.keys(FORMATS).forEach(function(k){if(k==='short'||(l.job.rank||0)>=1)a.push(o(k,FORMATS[k].n,k==='tv'?'Một mùa ngắn mô phỏng trong năm':k==='cinema'?'Phát hành rạp':k==='web'?'Phát hành theo tập trên mạng':'Dự án đầu tay / liên hoan phim'));});
    if(s==='medium')a=[o('live','Phim người đóng (live action)'),o('animation','Phim hoạt hình','Chọn họa sĩ / animator theo ê-kíp; casting diễn viên lồng tiếng')];
    if(s==='source')a=[o('original','Kịch bản gốc do ê-kíp sáng tác'),o('adapt','Chuyển thể tác phẩm được cấp phép','Phí quyền chuyển thể nằm trong ngân sách; người đóng = live action chuyển thể'),o('public','Chuyển thể tác phẩm thuộc phạm vi công cộng','Kiểm tra quyền với từng bản dịch / hình ảnh, không mặc định mọi bản chuyển thể đều miễn phí')];
    if(s==='genre')Object.keys(GENRES).forEach(function(k){a.push(o(k,GENRES[k]));});
    if(s==='fund'){var b=value(l,format(p).budget)*(p.medium==='animation'?1.2:1),fee=value(l,format(p).fee);a=[o('studio','Nhận dự án do hãng đầu tư','Hãng thanh toán '+H.money(l,b)+' cho cả ê-kíp, không cộng vào ví bạn. Cát-xê sau phát hành '+H.money(l,fee)+'; không hưởng toàn bộ doanh thu.')];if(l.money>=b)a.push(o('self','Tự đầu tư '+H.money(l,b),'Trừ một lần toàn bộ ngân sách, gồm diễn viên, bản quyền, hậu kỳ, quảng bá. Thu hồi từ doanh thu ròng mô phỏng; có thể lỗ.'));}
    if(s==='cast1'||s==='cast2')p.candidates.filter(function(x){return p.cast.indexOf(x.id)<0;}).forEach(function(x){a.push(o(x.id,x.name,actorText(l,x)));});
    if(s==='script')a=[o('workshop','Đọc bàn, sửa động cơ nhân vật','Tăng chất lượng, tăng sự phối hợp'),o('improv','Cho diễn viên ứng tác có kiểm soát','Hợp phim hài / tình cảm hơn'),o('rush','Giữ bản đầu, dành thời gian cho hình ảnh','Tiết kiệm thời gian nhưng kịch bản có thể yếu')];
    if(s==='board')a=p.board.options.map(function(x,i){return o('b'+i,x);});
    if(s==='prep')a=[o('safe','Khảo sát bối cảnh, tập trước, phương án an toàn','Hoạt hình: animatic, thử rig và lịch render; người đóng: tập diễn / điều phối trường quay'),o('visual','Ưu tiên thiết kế hình ảnh và kỹ xảo','Hợp hoạt hình / kỳ ảo / khoa học viễn tưởng'),o('rush','Rút ngắn tiền kỳ để bắt đầu sớm')];
    if(s==='shoot1')a=[o('coach','Hướng dẫn tâm lý, cho diễn viên tập thử'),o('technical','Chốt nhịp chuyển động / máy quay trước','Hợp hoạt hình hoặc phim hành động'),o('many','Lặp nhiều lần đến khi đạt','Có thể mệt ê-kíp, không phát sinh khoản thu ngoài hợp đồng')];
    if(s==='shoot2')a=p.continuity.options.map(function(x,i){return o('c'+i,x);});
    if(s==='incident'){var inc=INCIDENTS[p.incident];a=[o('care',p.medium==='animation'?'Điều chỉnh lịch thu / dựng, bảo vệ ê-kíp':inc[1]),o('risk',p.medium==='animation'?'Ép ê-kíp làm xuyên đêm để kịp hạn':inc[2]),o('rewrite','Đổi cách kể để dùng cảnh / bản thu đã đạt')];}
    if(s==='edit')a=[o('story','Dựng theo mạch cảm xúc và nguyên nhân – kết quả'),o('pace','Dựng nhanh, tăng tiết tấu','Hợp hành động / kinh dị'),o('test','Chiếu thử, sửa theo phản hồi có chọn lọc')];
    if(s==='sound')a=[o('mix','Thu bổ sung, hòa âm và dùng nhạc được cấp phép'),o('minimal','Thiết kế âm thanh tối giản','Hợp chính kịch / trinh thám'),o('library','Dùng thư viện nhạc có giấy phép phù hợp')];
    if(s==='release')a=[o('target','Phát hành đúng tệp khán giả','Có kiểm tra quyền, phân loại độ tuổi và nghiệm thu trước khi công chiếu'),o('festival',p.format==='tv'?'Ra mắt với nhà đài, giao lưu khán giả':p.format==='web'?'Công chiếu trực tuyến, giao lưu ê-kíp':'Gửi liên hoan phim rồi phát hành','Ưu tiên uy tín và đánh giá, doanh thu thường chậm / thấp hơn'),o('viral','Trailer và chiến dịch truyền thông rộng','Độ phủ cao hơn, không đảm bảo phim thành công')];
    a.push(o('quit','Dừng dự án',p.funding==='self'?'Vốn đã chi không tự hoàn lại':'Không nhận cát-xê hoàn tất'));return a;
  }
  function setupGames(p,r){var boards=[['Một người nhặt được vé tàu, quyết định lên đường, rồi gặp lại người bạn cũ.','Nhặt vé → Quyết định đi → Gặp bạn',['Gặp bạn → Nhặt vé → Quyết định đi','Quyết định đi → Gặp bạn → Nhặt vé']],['Nhân vật nghe chuông, mở cửa, rồi nhận thư.','Nghe chuông → Mở cửa → Nhận thư',['Nhận thư → Nghe chuông → Mở cửa','Mở cửa → Nhận thư → Nghe chuông']],['Nhân vật thấy khói, báo động, rồi mọi người sơ tán.','Thấy khói → Báo động → Sơ tán',['Sơ tán → Báo động → Thấy khói','Báo động → Sơ tán → Thấy khói']]],b=U.pick(r,boards),ci=U.randint(r,0,2),opts=b[2].slice();opts.splice(ci,0,b[1]);p.board={text:b[0],options:opts,correct:ci};
    var cont=U.pick(r,[['Cảnh trước: cốc ở tay trái, cửa đóng, áo xanh. Cảnh nối: cốc tay phải, cửa đóng, áo xanh.','Đổi cốc về tay trái',['Đổi màu áo','Mở cửa']],['Cảnh trước: đồng hồ 8 giờ, trời sáng, nhân vật đeo kính. Cảnh nối: đồng hồ 8 giờ, trời sáng, không có kính.','Khôi phục chiếc kính',['Đổi sang trời tối','Đổi đồng hồ thành 10 giờ']],['Cảnh trước: túi trên vai phải, điện thoại màu đỏ. Cảnh nối: túi vai phải, điện thoại màu đen.','Sửa màu điện thoại về đỏ',['Đổi vai đeo túi','Đổi màu nền']]]),cc=U.randint(r,0,2),co=cont[2].slice();co.splice(cc,0,cont[1]);p.continuity={text:cont[0],options:co,correct:cc};
  }
  function description(l){var p=project(l),s=STAGES[p.stage];return 'Dự án hư cấu: '+p.name+' · Năm '+p.year+' · Chặng '+(p.stage+1)+'/'+STAGES.length+'. '+(p.format?format(p).n+' · ':'')+(p.medium?(p.medium==='animation'?'Hoạt hình':'Người đóng')+' · ':'')+(p.source?(p.source==='adapt'?'Chuyển thể có phép':p.source==='public'?'Chuyển thể phạm vi công cộng':'Kịch bản gốc')+' · ':'')+(p.genre?GENRES[p.genre]+'. ':'')+
    (s==='format'?((l.job.rank||0)<1?'Bạn đang là trợ lý đạo diễn: được hướng dẫn làm phim ngắn đầu tay; phim dài mở khi lên bậc đạo diễn.':'Bạn đã có thể dẫn dắt dự án dài. Một dự án / năm.'):
    s==='fund'?'Các con số ngân sách / cát-xê là cân bằng game, không phải báo giá ngành phim. Chọn ai chịu vốn; không thu thêm lẻ tẻ về sau.':
    s==='cast1'||s==='cast2'?'Chọn '+role(l)+' cho '+(s==='cast1'?'vai chính':'vai đối trọng')+'. Vai nhân vật đều là người trưởng thành. Hồ sơ hư cấu, tuổi tính đúng năm hiện tại; cát-xê trong gói sản xuất, không trừ hai lần.':
    s==='board'?p.board.text+' Chọn thứ tự nguyên nhân → hành động → kết quả.':
    s==='shoot2'?p.continuity.text+' Tìm chi tiết cần sửa để nối cảnh khớp nhau.':
    s==='shoot1'?(p.medium==='animation'?'Thu thoại và diễn hoạt cảnh đầu.':'Buổi quay đầu tiên, diễn viên chưa bắt được nhịp cảm xúc.'):
    s==='incident'?(p.medium==='animation'?'Tiến độ thu thoại và render không đồng bộ, ê-kíp đề nghị sắp xếp lại lịch.':INCIDENTS[p.incident][0]):
    s==='release'?'Bản phim đã hoàn tất. Chọn cách đưa phim đến khán giả; chất lượng, diễn viên, thể loại, truyền thông và may mắn cùng ảnh hưởng kết quả.':
    s==='sound'?'Phải xác nhận quyền âm nhạc; mọi lựa chọn dưới đây đều dùng nhạc được phép.':
    s==='prep'?'Chốt lịch trong năm, phương án dự phòng và ê-kíp phù hợp với hình thức phim.':
    s==='script'?'Bản kịch bản cần thống nhất trước ngày sản xuất.':
    s==='edit'?'Dựng hình, kiểm tra nhịp kể và phản hồi buổi chiếu thử.':'Mỗi lựa chọn định hình tác phẩm.');}
  function release(l,r,log,k){var p=project(l),q=U.clamp(p.quality+(r()-.5)*16,0,100),response=U.clamp(q*.65+p.trust*.2+r()*25,0,100),f=format(p),factor=k==='festival'?.75:k==='viral'?1.15:1,reach=Math.round(f.reach*(.25+response/50)*factor),payout;
    p.score=Math.round(q);p.audience=reach;p.reception=response>=75?'được đón nhận nồng nhiệt':response>=50?'phản hồi khá, còn ý kiến trái chiều':'phản hồi yếu';p.status='released';p.done=true;
    // Doanh thu ròng của dự án không phải doanh thu bán vé gộp; hãng sở hữu vốn.
    p.netReceipts=p.budget*U.clamp((response-20)/45+(r()-.5)*.6,.1,2.6)*(k==='festival'?.75:1);
    payout=p.funding==='self'?p.netReceipts:p.fee;
    p.paid=true;p.payout=payout;if(payout>0)H.cash(l,payout,p.funding==='self'?'Thu hồi ròng phim '+p.name:'Cát-xê đạo diễn phim '+p.name);
    p.profit=p.funding==='self'?payout-p.budget:payout;
    var followers=Math.round(reach*(.015+response/2000));l.fame=(l.fame||0)+followers;if(l.job)l.job.rep=U.clamp((l.job.rep||50)+(q>=65?5:-3),0,100);
    log('Phát hành '+p.name+' ('+f.n+', '+GENRES[p.genre]+'): chất lượng '+p.score+'/100, '+p.reception+', khoảng '+reach.toLocaleString('vi-VN')+' lượt khán giả mô phỏng. '+(p.funding==='self'?'Vốn tự góp '+H.money(l,p.budget)+', thu hồi ròng '+H.money(l,payout)+', '+(p.profit>=0?'lãi ':'lỗ ')+H.money(l,Math.abs(p.profit))+'.':'Hãng thu doanh thu; bạn nhận cát-xê '+H.money(l,payout)+'.')+' Thêm '+followers.toLocaleString('vi-VN')+' người quan tâm. Không tự thăng chức sau một phim.',q>=65?'big':'neutral');
    H.mem(l,'Phát hành bộ phim '+p.name+' do mình đạo diễn, được khán giả đón xem.',4);
  }
  function play(l,d,k,r,log){if(!valid(l,d))return;var p=project(l),os=choices(l);if(!os.some(function(x){return x.k===k;}))return;if(k==='quit'){cancel(l,log);return;}var s=STAGES[p.stage],delta=0;
    if(s==='format')p.format=k;
    else if(s==='medium')p.medium=k;
    else if(s==='source')p.source=k;
    else if(s==='genre')p.genre=k;
    else if(s==='fund'){p.budget=value(l,format(p).budget)*(p.medium==='animation'?1.2:1);p.fee=value(l,format(p).fee);p.funding=k;p.status='production';if(k==='self')H.cash(l,-p.budget,'Vốn tự đầu tư phim '+p.name);log((k==='self'?'Bạn tự góp ':'Hãng chi trả ')+H.money(l,p.budget)+' ngân sách trọn gói; gồm bản quyền, tuyển vai, ê-kíp, hậu kỳ và quảng bá.','neutral');casting(l,r);setupGames(p,r);}
    else if(s==='cast1'||s==='cast2'){var a=p.candidates.filter(function(x){return x.id===k;})[0];p.cast.push(k);delta=((p.medium==='animation'?a.voice:a.acting)-50)/8+(a.genre===p.genre?3:0);p.trust+=(a.reliable-60)/10;log('Ký '+role(l)+' '+a.name+' ('+(year(l)-a.born)+' tuổi, quê '+a.home+') cho '+(s==='cast1'?'vai chính':'vai đối trọng')+'. Cát-xê nằm trong ngân sách.','good');}
    else if(s==='board'||s==='shoot2'){var game=s==='board'?p.board:p.continuity,correct=Number(k.slice(1))===game.correct;delta=correct?7:-3;p[s==='board'?'boardWon':'continuityWon']=correct;log((correct?'Chính xác! ':'Chưa đúng. ')+(s==='board'?'Thứ tự phù hợp: ':'Chi tiết cần sửa: ')+game.options[game.correct]+'.',correct?'good':'neutral');}
    else if(s==='script')delta=k==='workshop'?5:k==='improv'?(/comedy|romance/.test(p.genre)?6:2):-2;
    else if(s==='prep')delta=k==='safe'?5:k==='visual'?(p.medium==='animation'||/fantasy|scifi/.test(p.genre)?7:3):-3;
    else if(s==='shoot1'){delta=k==='coach'?5:k==='technical'?(p.medium==='animation'||p.genre==='action'?6:2):1;if(k==='many')p.trust-=6;}
    else if(s==='incident'){delta=k==='care'?4:k==='rewrite'?2:-6;p.trust+=k==='risk'?-12:5;}
    else if(s==='edit')delta=k==='test'?6:k==='pace'?(/action|horror/.test(p.genre)?6:1):5;
    else if(s==='sound')delta=k==='mix'?5:k==='minimal'?(/drama|mystery/.test(p.genre)?6:2):3;
    if(/^(script|prep|shoot1|incident|edit|sound)$/.test(s)){var chosen=os.filter(function(x){return x.k===k;})[0];log(p.name+' · '+TITLES[p.stage]+': '+chosen.l+'. '+(delta>=4?'Ê-kíp có thêm một phần phim đạt yêu cầu.':delta<0?'Lựa chọn làm chất lượng hoặc tinh thần ê-kíp giảm.':'Kết quả vừa phải, còn điểm cần cải thiện.'),delta<0?'neutral':'good');}
    p.quality=U.clamp(p.quality+delta,0,100);p.trust=U.clamp(p.trust,0,100);p.history.push({stage:s,choice:k,delta:delta});
    if(s==='release'){release(l,r,log,k);return;}p.stage++;queue(l,r,log);
  }
  E.DEC.film_step={make:function(l){var p=project(l);return{id:'film_step',title:TITLES[p.stage],text:description(l),opts:choices(l),data:{token:p.token,stage:p.stage},major:true};},valid:valid,auto:function(l,d,r){var os=d.opts.filter(function(x){return x.k!=='quit';});return U.pick(r,os.length?os:d.opts).k;},apply:function(l,d,k,r,log){play(l,d.data,k,r,log);}};
  E.SC('film_menu',{title:'Xưởng phim của bạn',prep:context,valid:function(l,d){return free(l)&&director(l)&&(!d||!d.year||same(l,d));},text:function(l){var p=project(l);return 'Đạo diễn bắt đầu từ trợ lý, không nhận phim dài ngay bậc đầu. Mỗi năm làm một dự án. Không nhận đồng thời lịch show. '+(p?'Dự án gần nhất: '+p.name+' · '+(p.done?(p.status==='released'?'đã phát hành · '+p.score+'/100':'đã dừng'):'đang làm · '+TITLES[p.stage])+'. ':'')+'Chọn dự án và diễn viên, giải storyboard / lỗi nối cảnh, sản xuất, hậu kỳ rồi phát hành.';},opts:[
    {k:'new',l:'Khởi tạo dự án phim trong năm',req:canStart,run:start},
    {k:'resume',l:'Tiếp tục dự án đang làm',req:function(l){return valid(l);},run:queue},
    {k:'stop',l:'Dừng dự án hiện tại',req:busy,run:function(l,r,log){cancel(l,log);}},
    {k:'no',l:'Đóng xưởng phim',run:function(){}}
  ]});
  var ma=E.DEC.film_menu.apply;E.DEC.film_menu.apply=function(l,d){if(!E.DEC.film_menu.valid(l,d.data))return;return ma.apply(this,arguments);};
  E.ACT.push({id:'film_menu',g:'Công việc',l:'Đạo diễn: dự án phim / tuyển diễn viên',min:18,sc:'film_menu',avail:function(l){return free(l)&&director(l)?true:'Cần tốt nghiệp đại học phù hợp, đang làm nghề đạo diễn / trợ lý đạo diễn và được tự do';},ai:{w:.3}});
  E.TRIG.push({id:'film_menu',when:canStart,p:.65,cd:1,rep:true});
  // Chặn lịch show chồng với dự án phim, cả ở nút và lúc áp lựa chọn.
  ['gameshow','vr_vai_tro','tv_moi'].forEach(function(id){var D=E.DEC[id];if(!D)return;var v=D.valid,a=D.apply;D.valid=function(l){return !busy(l)&&v.apply(this,arguments);};D.apply=function(l){if(busy(l))return;return a.apply(this,arguments);};});
  E.ACT.filter(function(a){return a.id==='gameshow_moi';}).forEach(function(a){var av=a.avail;a.avail=function(l){return busy(l)?'Đang có lịch sản xuất phim':av(l);};});
  ['jail','kill'].forEach(function(key){var fn=H[key];H[key]=function(l){var log=arguments[key==='jail'?3:2];if(busy(l)&&typeof log==='function')cancel(l,log,key==='jail'?'phải chấp hành án':'hành trình cuộc đời kết thúc');return fn.apply(this,arguments);};});
  function filmYear(l,r,log){if(busy(l)&&!valid(l))cancel(l,log,'dự án quá năm hoặc điều kiện sản xuất đã thay đổi');}
  E.HOOKS.year.push(filmYear);
  var profile=E.profile;E.profile=function(l){var P=profile.apply(this,arguments),p=project(l);if(p&&P.jobInfo)P.jobInfo.push('Phim '+p.name+': '+(p.done?(p.status==='released'?'đã phát hành, '+p.score+'/100':'đã dừng'):TITLES[p.stage]));return P;};
  E.FILM={formats:FORMATS,genres:GENRES,stages:STAGES,incidents:INCIDENTS,project:project,canStart:canStart,valid:valid,start:start,choices:choices,cancel:cancel,actorText:actorText,busy:busy,year:filmYear};
})(G);

;
/* ===== js/life61.js ===== */
/* V5.0 — chi tiêu dịch vụ và sổ nuôi xe. Giá tài sản / thuế / phạt không nhân theo lối sống. */
(function(G){
  'use strict';
  var E=G.E,H=E.H,U=G.U,scope=null;
  function unit(l,n){return l.cur==='vnd'?n:n/90*l.base;}
  function factor(l){if(l.spend==='save')return .82;if(l.spend!=='lavish')return 1;
    var own=Math.max(0,E.netWorth?E.netWorth(l):l.money||0,Number(l.income)||0),f=l.fam||{},family=(!l.indep?((f.mAlive?f.mInc||0:0)+(f.fAlive&&!f.noDad?f.fInc||0:0))*12:0),ratio=Math.max(own,family)/Math.max(1,l.base);
    return ratio>=1000?5:ratio>=100?4:ratio>=20?3:ratio>=5?2:1.5;
  }
  function price(l,n){return Math.round(unit(l,n)*factor(l)*1e6)/1e6;}
  function active(l){return scope&&scope.l===l?scope:null;}
  function scoped(l,fn,previewOnly){var before=scope,c={l:l,factor:factor(l),own:0,family:0,preview:!!previewOnly};scope=c;try{fn();}finally{scope=before;}return c;}
  var cash=H.cash;H.cash=function(l,v,why){var c=active(l);if(c&&v<0){if(!/phạt|bồi thường|viện phí|thuốc|bảo hiểm|vay|trả nợ/i.test(why||''))v*=c.factor;c.own-=v;}return cash(l,v,why);};
  var child=E.childExpense;E.childExpense=function(l,amount,why,forced){var c=active(l);if(!c)return child.apply(this,arguments);var before=scope;scope=null;var result;try{result=child(l,amount*c.factor,why,forced);}finally{scope=before;}if(result.ok){if(l.age<18&&!l.indep&&(l.fam.mAlive||(l.fam.fAlive&&!l.fam.noDad)))c.family+=amount*c.factor;else c.own+=amount*c.factor;}return result;};
  function preview(l,d,k,apply,offset){var c=JSON.parse(JSON.stringify(l,function(key,v){return key==='log'&&Array.isArray(v)?v.slice(-20):v;}));c.pending=[];if(offset)c.rs=(c.rs+offset)|0;return scoped(c,function(){apply(c,JSON.parse(JSON.stringify(d)),k,function(){return U.rand(c);},function(){});},true);}
  var ids=['hen_ho','hen_ho_moi','sinh_nhat','concert','concert_di','fanmeeting','karaoke','di_nhau','phuot','leo_nui','tap_gym','xem_bong_da','di_an','tra_sua'];
  // Các dịch vụ giải trí hiện có, trừ game/skin có bảng giá cố định và vé số/đầu tư.
  E.ACT.forEach(function(a){if(a.g==='Giải trí'&&!/game|skin|du_lich|xem_phim/.test(a.id)&&ids.indexOf(a.sc||a.id)<0)ids.push(a.sc||a.id);});
  ids.forEach(function(id){var D=E.DEC[id];if(!D)return;var make=D.make,apply=D.apply;
    D.make=function(l){if(active(l)&&active(l).preview)return make.apply(this,arguments);var d=make.apply(this,arguments),f=factor(l);if(f===1)return d;d.data._service50={factor:f,cur:l.cur,age:l.age};d.text+=' Chi tiêu '+(l.spend==='lavish'?'thoải mái: dịch vụ / chỗ ngồi / trải nghiệm cao cấp':'tiết kiệm')+' ×'+f+' giá thường.';
      d.opts.forEach(function(o){var q=[0,7919,15838].map(function(n){return preview(l,d,o.k,apply,n);}),lo=Math.min.apply(null,q.map(function(x){return x.own;})),hi=Math.max.apply(null,q.map(function(x){return x.own;})),family=Math.max.apply(null,q.map(function(x){return x.family;}));if(hi>0||family>0)o.h='Bạn dự kiến trả '+H.money(l,lo)+(hi>lo+1e-6?' – '+H.money(l,hi):'')+(family>0?' · gia đình trả '+H.money(l,family):'')+' (đã áp dụng mức dịch vụ).';});return d;};
    D.apply=function(l,d,k,r,log){if(D.valid&&!D.valid(l,d.data))return;var qd=d.data&&d.data._service50;if(qd&&(qd.factor!==factor(l)||qd.cur!==l.cur||qd.age!==l.age)){log('Mức dịch vụ hoặc thời điểm đã đổi, hãy mở lại hoạt động để xem giá mới; chưa thu tiền.','neutral');return;}var q=preview(l,d,k,apply,0);if(q.own>Math.max(0,l.money)+1e-8){log('Chưa đủ tiền cho mức dịch vụ đã chọn; hoạt động chưa diễn ra. Có thể đổi về chi tiêu bình thường / tiết kiệm.','neutral');return;}return scoped(l,function(){apply(l,d,k,r,log);});};
  });
  // Cho phép chọn nếp chi tiêu từ nhỏ; không mặc định con nhà giàu phải tiêu sang.
  E.ACT.filter(function(a){return a.id==='chi_tieu';}).forEach(function(a){a.min=6;a.avail=function(){return true;};});
  E.DEC.chi_tieu.def.text=function(l){return 'Hiện chi tiêu '+({save:'tằn tiện',normal:'bình thường',lavish:'thoải mái'}[l.spend]||'bình thường')+'. Bình thường giữ giá gói thường kể cả khi giàu. Thoải mái chọn dịch vụ tốt hơn ×1,5–5 theo tài chính của bạn, hoặc thu nhập gia đình khi chưa tự lập. Sinh hoạt hằng năm và các hoạt động dịch vụ áp dụng mức này; giá tài sản, skin game, học phí, thuế và tiền phạt giữ nguyên.';};
  E.DEC.chi_tieu.def.opts.forEach(function(o){if(o.k==='lavish')o.h='Dịch vụ cao cấp tăng theo tài chính; không tự chuyển chỉ vì giàu';if(o.k==='normal')o.h='Giá gói thường, không tăng theo tài sản';});
  function inactive(l){return !l.alive||(l.jailUntil!=null&&l.age<l.jailUntil)||(l.flags.military&&l.age<l.flags.military)||(l.abroad&&l.abroad.trapped);}
  function annual(l){var own=!!l.veh,R=l.rentVeh,car=l.veh==='ô tô',bike=l.veh==='xe máy',cycle=l.veh==='xe đạp',off=inactive(l),ev=/^(vf3|vf5|vf7|vf8|evo|feliz|theon|yadea)$/.test(l.vehK||'')||/điện/i.test(l.vehName||''),tier=l.vehTier||0;
    var v={fuel:0,maintenance:0,insurance:0,parking:0,road:0,rent:0,total:0,ev:ev,vehicle:l.vehName||l.veh||'Không có xe riêng',year:l.birthYear+l.age,cur:l.cur};
    var age=Math.max(0,l.age-(l.vehBoughtAt==null?l.age:l.vehBoughtAt)),wear=1+Math.min(.6,age*.03);
    if(own){if(!off){var fw=car?(l.age<18?0:ev?.13:tier>=4?.95:tier===3?.6:tier===2?.5:.36):bike?(l.age<16?0:ev?.025:l.vehK==='z900'?.25:l.vehSeg==='ga'?.09:.07):0;v.fuel=unit(l,fw*52)*(l.age>=70?.5:1)*(R?.25:1);}
      var extra=car||bike?Math.max(0,l.vehUp||({suv:.02,lux:.12,sport:.4,super:1.2}[l.vehK]||0))*l.base:0;
      v.maintenance=unit(l,car?(ev?4:6):bike?(ev?.5:.8):cycle?.3:0)*wear+extra;
      v.insurance=car?unit(l,.5)+Math.max(0,l.vehVal||0)*.01:bike?unit(l,.1):0;
      v.parking=unit(l,car?(l.urban?14:2):bike?(l.urban?1.2:.2):0)*(off?.25:1);v.road=car?unit(l,1.56):0;
    }else if(!R&&!off)v.fuel=unit(l,l.urban?5.2:2.6); // phương tiện công cộng, không gọi là xăng xe riêng
    if(R&&!off){v.rent=Math.max(0,R.fee||0)*12;v.fuel+=Math.max(0,R.fuel||0)*12;v.vehicle+=(own?' + ':'')+'xe thuê '+R.n;}
    ['fuel','maintenance','insurance','parking','road','rent'].forEach(function(k){v.total+=v[k];});return v;
  }
  E.vehicleAnnual=annual;E.travelCost=function(l){return annual(l).total;};E.fuelWeek=function(l){return annual(l).fuel/52;};
  function remaining(l){var p=l.partner;if(!p||p.alive===false||!(p.inc>0)||!isFinite(p.inc)||p.age<18)return 0;var a=p.leisureSpending,h=p.heritageSpending,spent=(a&&a.at===l.age&&a.cur===l.cur?a.spent:0)+(h&&h.at===l.age&&h.cur===l.cur?h.spent:0);return Math.max(0,p.inc*12*.1-spent);}
  function share(k){return k==='split'?.5:k==='partner'?0:1;}
  function canPay(l,total,k){if(!(total>=0&&isFinite(total))||['self','split','partner'].indexOf(k)<0)return false;var self=total*share(k),other=total-self;return Math.max(0,l.money)+1e-8>=self&&(!other||(l.partner&&l.partner.alive!==false&&remaining(l)+1e-8>=other));}
  function pay(l,total,k,why){if(!canPay(l,total,k))return false;var self=total*share(k),other=total-self;if(self)H.cash(l,-self,why);if(other){var p=l.partner,a=p.leisureSpending;if(!a||a.at!==l.age||a.cur!==l.cur)a=p.leisureSpending={at:l.age,cur:l.cur,spent:0};a.spent+=other;var yr=l.yr||(l.yr={items:[]});(yr.partnerExpenses||(yr.partnerExpenses=[])).push({t:why,v:other,payer:p.name});}return{self:self,partner:other};}
  E.HOOKS.year.push(function(l,r,log){var y=l.birthYear+l.age;if(l.flags.vehicleYear===y)return;l.flags.vehicleYear=y;
    if(l.veh&&l.vehBoughtAt==null)l.vehBoughtAt=l.age;
    if(l.veh&&(!l.fin||!l.fin.vehicle)){var v=annual(l),result;if(l.age>=18){H.cash(l,-v.total,'Chi phí xe khi chưa tự lập');result={ok:true,note:'Bạn chịu '+H.money(l,v.total)+' chi phí xe từ tiền riêng, kể cả khi còn đang học / mới tự lập.'};}else result=E.childExpense(l,v.total,'Xăng / sạc và bảo dưỡng xe của bạn',true);if(result.ok){l.flags.familyVehicleBill={year:y,total:v.total,note:result.note};log('Chi phí xe năm '+y+': '+H.money(l,v.total)+'. '+result.note,'money');}}
    else if(l.indep&&l.fin&&l.fin.vehicle&&l.fin.vehicle.total>0){var b=l.fin.vehicle;log('Nuôi xe / đi lại năm '+y+': xăng, sạc / vé công cộng '+H.money(l,b.fuel)+'; bảo dưỡng '+H.money(l,b.maintenance)+'; bảo hiểm '+H.money(l,b.insurance)+'; gửi xe '+H.money(l,b.parking)+'; phí đường bộ '+H.money(l,b.road)+(b.rent?'; thuê xe '+H.money(l,b.rent):'')+'. Tổng '+H.money(l,b.total)+' đã nằm trong chi phí đi lại, không trừ lần nữa.','money');}
  });
  E.lifestyleFactor=factor;E.activityPrice=price;E.LIFESTYLE={factor:factor,unit:unit,price:price,scoped:scoped,ids:ids,annual:annual};
  E.LEISURE_BILL={remaining:remaining,share:share,can:canPay,pay:pay};
  H.datePay=function(l,r,cost,why){var c=active(l),total=cost*l.base*(c?c.factor:1),p=l.partner;if(!p){H.cash(l,-cost*l.base,why);return'';}var ways=['self','split','partner'].filter(function(k){return canPay(l,total,k);});if(!ways.length){H.cash(l,-cost*l.base,why);return' Bạn chưa đủ ngân sách cho buổi hẹn.';}
    var richer=p.inc>0&&l.income>0&&p.inc*12>l.income*1.5,k=l.sex==='F'&&p.sex==='M'?(r()<.8?'partner':r()<.6?'split':'self'):l.sex==='M'&&p.sex==='F'?(r()<(richer?.45:.15)?'partner':r()<.15?'split':'self'):(richer&&r()<.5?'partner':'split');
    if(ways.indexOf(k)<0)k=ways.indexOf('split')>=0?'split':ways[0];var old=scope,bill;scope=null;try{bill=pay(l,total,k,why);}finally{scope=old;}if(c)c.own+=bill.self;return' Bạn trả '+H.money(l,bill.self)+', '+p.name+' trả '+H.money(l,bill.partner)+' từ ngân sách riêng.';};
})(G);

;
/* ===== js/leisure-data.js ===== */
/* V5.0 — địa danh / ẩm thực thật, giá gói là ước tính cân bằng game (triệu VND/người).
   Châu Á gồm điểm đến quốc gia và ba vùng lãnh thổ có lịch trình riêng; không đổi dữ liệu 195 nước. */
(function(G){
  'use strict';
  var rows=[
    'TH|asia|Thái Lan|9|5|Hoàng cung Bangkok|cố đô Ayutthaya|pad Thai~xôi xoài|đi thuyền trên sông Chao Phraya|học nấu món Thái',
    'SG|asia|Singapore|14|4|Gardens by the Bay|Merlion Park|cơm gà Hải Nam~bánh kaya|xem ánh sáng Supertree|khám phá văn hóa hawker',
    'MY|asia|Malaysia|10|5|tháp đôi Petronas|phố cổ George Town|nasi lemak~roti canai|ngắm nghệ thuật đường phố Penang|dạo chợ đêm',
    'LA|asia|Lào|8|4|Luang Prabang|thác Kuang Si|xôi Lào~tam mak hoong|đạp xe quanh phố cổ|thăm xưởng dệt',
    'KH|asia|Campuchia|8|4|Angkor Wat|Biển Hồ Tonlé Sap|amok cá~bánh num krok|ngắm bình minh Angkor|xem múa Apsara',
    'JP|asia|Nhật Bản|30|6|Asakusa ở Tokyo|Fushimi Inari ở Kyoto|sushi~ramen|trải nghiệm trà đạo|đi tàu và khám phá phố sách',
    'KR|asia|Hàn Quốc|20|5|Gyeongbokgung|đảo Jeju|bibimbap~tteokbokki|mặc hanbok chụp ảnh|học làm kimchi',
    'CN|asia|Trung Quốc|22|6|Vạn Lý Trường Thành|Tử Cấm Thành|vịt quay Bắc Kinh~dim sum|xem biểu diễn nghệ thuật truyền thống|thưởng trà',
    'TW|asia|Đài Loan|16|5|Taipei 101|phố cổ Cửu Phần|mì bò~bánh dứa|đi chợ đêm|trải nghiệm làm bánh dứa',
    'HK|asia|Hong Kong|18|4|Victoria Peak|cảng Victoria|dim sum~bánh trứng|đi phà ngắm cảng|khám phá khu phố điện ảnh',
    'MO|asia|Macau|18|4|tàn tích Nhà thờ Thánh Phaolô|quảng trường Senado|bánh trứng kiểu Bồ~bánh hạnh nhân|đi bộ khu di sản|tham gia lớp làm bánh',
    'ID|asia|Indonesia|17|5|ruộng bậc thang Ubud|đền Borobudur|nasi goreng~gado-gado|học batik|xem múa truyền thống Bali',
    'PH|asia|Philippines|17|5|Chocolate Hills|vịnh El Nido|adobo~halo-halo|đi thuyền ngắm đảo|nghe nhạc tại quảng trường',
    'BN|asia|Brunei|14|4|thánh đường Omar Ali Saifuddien|Kampong Ayer|ambuyat~kuih|tham quan làng nổi|đi thuyền trên sông',
    'TL|asia|Timor-Leste|25|5|Cristo Rei ở Dili|đảo Atauro|ikan sabuko~cà phê Timor|khám phá làng chài|học về nghề dệt tais',
    'MM|asia|Myanmar|16|5|quần thể đền Bagan|hồ Inle|mohinga~salad lá trà|thăm xưởng thủ công|đi thuyền ngắm làng ven hồ',
    'IN|asia|Ấn Độ|23|6|Taj Mahal|Hawa Mahal ở Jaipur|biryani~dosa|học làm gia vị|tham quan chợ thủ công',
    'NP|asia|Nepal|25|6|quảng trường Durbar Kathmandu|hồ Phewa ở Pokhara|momo~dal bhat|đi bộ ngắm núi theo sức khỏe|học nấu momo',
    'BT|asia|Bhutan|46|5|tu viện Paro Taktsang|Punakha Dzong|ema datshi~bánh khapse|xem dệt vải truyền thống|dạo thung lũng',
    'BD|asia|Bangladesh|23|5|pháo đài Lalbagh|rừng ngập mặn Sundarbans|kacchi biryani~pitha|đi thuyền có hướng dẫn|xem nghề dệt jamdani',
    'LK|asia|Sri Lanka|27|6|pháo đài Sigiriya|phố cổ Galle|hoppers~kottu|tham quan đồi chè|đi tàu ngắm cảnh',
    'MV|asia|Maldives|44|5|bờ biển đảo Maafushi|thánh đường Hukuru Miskiy ở Malé|mas huni~garudhiya|đi thuyền ngắm hoàng hôn|ngắm san hô có hướng dẫn',
    'PK|asia|Pakistan|29|6|Badshahi Mosque ở Lahore|thung lũng Hunza|biryani~chapli kebab|khám phá phố cổ Lahore|thưởng trà và nghe nhạc địa phương',
    'AF|asia|Afghanistan|34|5|thung lũng Bamiyan|Band-e Amir|kabuli pulao~bolani|tìm hiểu nghề dệt thảm|tham quan di sản có hướng dẫn',
    'MN|asia|Mông Cổ|32|6|tu viện Gandan|sa mạc Gobi|buuz~khuushuur|trải nghiệm lều ger|xem biểu diễn nhạc cụ morin khuur',
    'KZ|asia|Kazakhstan|32|6|hẻm núi Charyn|Almaty|beshbarmak~baursak|ngắm núi bằng tuyến phù hợp thể lực|khám phá chợ địa phương',
    'KG|asia|Kyrgyzstan|32|6|hồ Issyk-Kul|vườn quốc gia Ala-Archa|lagman~bánh boorsok|thăm xưởng làm nỉ|dạo hồ có hướng dẫn',
    'UZ|asia|Uzbekistan|32|6|quảng trường Registan|phố cổ Bukhara|plov~samsa|thăm xưởng gốm|khám phá Con đường Tơ lụa',
    'TJ|asia|Tajikistan|34|6|hồ Iskanderkul|Dushanbe|qurutob~oshi palav|thăm chợ thủ công|dạo hồ ngắm núi',
    'TM|asia|Turkmenistan|38|5|di tích Merv|Ashgabat|dograma~plov|tìm hiểu thảm Turkmen|tham quan bảo tàng',
    'IR|asia|Iran|33|6|Persepolis|quảng trường Naqsh-e Jahan|tahdig~fesenjan|thăm xưởng gốm|tìm hiểu nghệ thuật Ba Tư',
    'IQ|asia|Iraq|34|5|di tích Babylon|Bảo tàng Iraq ở Baghdad|masgouf~dolma|khám phá di sản Lưỡng Hà|thăm chợ truyền thống',
    'IL|asia|Israel|42|5|thành cổ Jerusalem|Biển Chết|falafel~hummus|tham quan bảo tàng|tìm hiểu lịch sử địa phương',
    'PS|asia|Palestine|38|5|Nhà thờ Giáng Sinh ở Bethlehem|di tích Jericho|musakhan~knafeh|thăm xưởng chạm gỗ ô liu|tìm hiểu nghề thêu tatreez',
    'JO|asia|Jordan|40|6|Petra|Wadi Rum|mansaf~falafel|ngắm sao có hướng dẫn|thăm xưởng thủ công',
    'LB|asia|Lebanon|36|5|di tích Baalbek|phố cổ Byblos|tabbouleh~manoushe|dạo phố di sản|học làm bánh truyền thống',
    'SY|asia|Syria|36|5|thành cổ Damascus|di tích Palmyra|kibbeh~muhammara|tìm hiểu nghề khảm|tham quan lịch sử có hướng dẫn',
    'YE|asia|Yemen|39|5|phố cổ Sana’a|đô thị Shibam|saltah~bint al-sahn|tìm hiểu kiến trúc nhà tháp|khám phá nghề thủ công',
    'SA|asia|Ả Rập Xê Út|40|5|AlUla|phố cổ Al-Balad ở Jeddah|kabsa~mutabbaq|tham quan di sản|ngắm sa mạc có hướng dẫn',
    'AE|asia|Các Tiểu vương quốc Ả Rập Thống nhất|32|5|Burj Khalifa|thánh đường Sheikh Zayed|machboos~luqaimat|du thuyền ngắm đường chân trời|thăm khu phố Al Fahidi',
    'QA|asia|Qatar|35|5|Bảo tàng Nghệ thuật Hồi giáo|Souq Waqif|machboos~luqaimat|đi thuyền dhow|tìm hiểu nghề săn ngọc trai',
    'BH|asia|Bahrain|34|5|pháo đài Bahrain|Bab Al Bahrain|machboos~halwa|khám phá di sản ngọc trai|tham quan chợ thủ công',
    'KW|asia|Kuwait|35|5|Kuwait Towers|Souq Al-Mubarakiya|machboos~gers ogaily|thăm bảo tàng hàng hải|dạo bờ vịnh',
    'OM|asia|Oman|37|5|thánh đường Sultan Qaboos|Mutrah Souq|shuwa~halwa Oman|đi thuyền ngắm vịnh|thăm làng nghề bạc',
    'TR|asia|Thổ Nhĩ Kỳ|39|6|Hagia Sophia|Cappadocia|kebab~baklava|khám phá xưởng gốm|ngắm thung lũng từ điểm quan sát',
    'AM|asia|Armenia|35|6|tu viện Geghard|đền Garni|lavash~ghapama|trải nghiệm làm bánh lavash|tìm hiểu điêu khắc đá',
    'AZ|asia|Azerbaijan|35|6|thành cổ Baku|nghệ thuật đá Gobustan|plov~qutab|tham quan bảo tàng thảm|thưởng trà địa phương',
    'GE|asia|Georgia|35|6|phố cổ Tbilisi|Mtskheta|khachapuri~khinkali|học nặn khinkali|nghe hợp xướng truyền thống',
    'KP|asia|Triều Tiên|39|5|quảng trường Kim Il Sung|khu di tích Kaesong|naengmyeon~kimchi|tham quan theo lịch trình được xác nhận|tìm hiểu bảo tàng lịch sử',
    'CY|asia|Síp|40|5|di tích Paphos|Kourion|halloumi~souvla|tham quan xưởng thủ công|dạo phố di sản',
    'VN|asia|Việt Nam|12|5|vịnh Hạ Long|phố cổ Hội An|phở~bánh mì|thăm làng nghề|đi thuyền ngắm cảnh',
    'FR|europe|Pháp|68|8|tháp Eiffel|bảo tàng Louvre|croissant~crêpe|dạo bờ sông Seine|thăm xưởng làm bánh',
    'IT|europe|Ý|68|8|đấu trường Colosseum|kênh đào Venice|pizza~gelato|học làm pasta|dạo khu phố di sản',
    'DE|europe|Đức|65|8|cổng Brandenburg|lâu đài Neuschwanstein|pretzel~bánh Black Forest|tham quan bảo tàng kỹ thuật|khám phá chợ truyền thống',
    'GB|europe|Vương quốc Anh|75|8|tháp đồng hồ Elizabeth|lâu đài Edinburgh|fish and chips~scone|thưởng trà chiều|thăm bảo tàng',
    'CH|europe|Thụy Sĩ|85|8|Jungfraujoch|hồ Lucerne|fondue~chocolate|đi tàu ngắm Alps|thăm xưởng chocolate',
    'ES|europe|Tây Ban Nha|65|8|Sagrada Família|cung điện Alhambra|paella~churros|xem flamenco|đi chợ thực phẩm',
    'PT|europe|Bồ Đào Nha|65|8|tháp Belém|thành phố Porto|pastel de nata~caldo verde|khám phá gạch azulejo|ngắm phố từ xe điện',
    'NL|europe|Hà Lan|67|8|kênh đào Amsterdam|cối xay Kinderdijk|stroopwafel~poffertjes|đi thuyền trên kênh|thăm xưởng làm guốc',
    'BE|europe|Bỉ|64|8|Grand-Place Brussels|phố cổ Bruges|waffle~chocolate|thăm xưởng chocolate|khám phá truyện tranh',
    'AT|europe|Áo|68|8|cung điện Schönbrunn|phố cổ Salzburg|schnitzel~Sachertorte|nghe hòa nhạc cổ điển|tham quan bảo tàng âm nhạc',
    'CZ|europe|Séc|60|8|cầu Charles|lâu đài Prague|koláče~svíčková|thăm xưởng pha lê|dạo quảng trường cổ',
    'HU|europe|Hungary|60|8|tòa nhà Quốc hội Budapest|Fisherman’s Bastion|goulash~lángos|đi thuyền sông Danube|nghe nhạc dân gian',
    'PL|europe|Ba Lan|60|8|phố cổ Kraków|lâu đài Wawel|pierogi~bánh pączki|học làm pierogi|thăm bảo tàng lịch sử',
    'GR|europe|Hy Lạp|65|8|Acropolis|đảo Santorini|souvlaki~salad Hy Lạp|dạo làng ven biển|tham quan di sản Hy Lạp cổ',
    'NO|europe|Na Uy|85|8|Geirangerfjord|khu Bryggen ở Bergen|cá hồi~bánh vafler|đi thuyền ngắm fjord|tham quan làng ven biển',
    'SE|europe|Thụy Điển|78|8|Gamla Stan Stockholm|bảo tàng Vasa|köttbullar~kanelbulle|trải nghiệm fika|dạo khu phố cổ',
    'FI|europe|Phần Lan|80|8|quảng trường Senate Helsinki|pháo đài Suomenlinna|súp cá hồi~karjalanpiirakka|khám phá thiết kế Bắc Âu|đi phà ngắm đảo',
    'DK|europe|Đan Mạch|80|8|Nyhavn|lâu đài Rosenborg|smørrebrød~bánh Danish|dạo bờ cảng|thăm bảo tàng thiết kế',
    'IS|europe|Iceland|95|9|thác Gullfoss|vườn quốc gia Þingvellir|skyr~súp địa phương|khám phá cảnh quan núi lửa|ngắm thiên nhiên theo thời tiết',
    'IE|europe|Ireland|75|8|Cliffs of Moher|Trinity College Dublin|Irish stew~soda bread|nghe nhạc truyền thống|tham quan thư viện',
    'HR|europe|Croatia|65|8|phố cổ Dubrovnik|hồ Plitvice|peka~fritule|dạo thành cổ|đi bộ theo tuyến hồ dễ đi',
    'RO|europe|Romania|59|8|lâu đài Bran|phố cổ Brașov|sarmale~papanași|thăm làng nghề|tìm hiểu kiến trúc Transylvania',
    'RU|europe|Nga|65|8|quảng trường Đỏ|bảo tàng Hermitage|pelmeni~blini|đi metro ngắm kiến trúc|thăm bảo tàng nghệ thuật',
    'US|americas|Hoa Kỳ|95|10|Tượng Nữ thần Tự do|Grand Canyon|burger~New York cheesecake|thăm bảo tàng và khu phố điện ảnh|ngắm thiên nhiên theo tuyến phù hợp sức khỏe',
    'CA|americas|Canada|90|10|thác Niagara|vườn quốc gia Banff|poutine~bánh maple|đi thuyền ngắm hồ|khám phá phố cổ Québec',
    'MX|americas|Mexico|90|10|Chichén Itzá|Teotihuacán|taco~tamales|thăm xưởng thủ công|nghe mariachi',
    'BR|americas|Brazil|110|10|tượng Chúa Cứu Thế ở Rio|thác Iguaçu|feijoada~pão de queijo|xem biểu diễn samba|dạo bãi biển có hướng dẫn',
    'AR|americas|Argentina|110|10|La Boca ở Buenos Aires|sông băng Perito Moreno|empanada~alfajor|xem tango|thăm khu phố nghệ thuật',
    'PE|americas|Peru|115|10|Machu Picchu|phố cổ Cusco|ceviche~causa|tìm hiểu nghề dệt Andes|tham quan di sản Inca có hướng dẫn',
    'CL|americas|Chile|110|10|sa mạc Atacama|Valparaíso|empanada~pastel de choclo|ngắm sao|khám phá tranh tường',
    'CO|americas|Colombia|100|10|phố cổ Cartagena|vùng cà phê Colombia|arepa~ajiaco|tham quan trang trại cà phê|xem nghệ thuật đường phố',
    'CU|americas|Cuba|100|10|phố cổ Havana|thung lũng Viñales|ropa vieja~moros y cristianos|nghe nhạc son|thăm xưởng thủ công',
    'CR|americas|Costa Rica|105|10|núi lửa Arenal|rừng mây Monteverde|gallo pinto~casado|ngắm động vật cùng hướng dẫn viên|đi bộ trên tuyến dễ',
    'PA|americas|Panama|100|10|kênh đào Panama|Casco Viejo|sancocho~hojaldre|tìm hiểu lịch sử kênh đào|dạo phố di sản',
    'DO|americas|Cộng hòa Dominica|105|10|khu thuộc địa Santo Domingo|bãi biển Punta Cana|la bandera~mangú|nghe merengue|tìm hiểu nghệ thuật địa phương',
    'AU|oceania|Úc|65|8|nhà hát Opera Sydney|Great Barrier Reef|meat pie~lamington|đi thuyền ngắm cảng|tham quan thiên nhiên có hướng dẫn',
    'NZ|oceania|New Zealand|75|8|Milford Sound|Hobbiton|pavlova~bánh địa phương|đi thuyền ngắm fjord|trải nghiệm văn hóa Māori có hướng dẫn',
    'FJ|oceania|Fiji|80|8|đảo Viti Levu|bãi biển quần đảo Mamanuca|kokoda~bánh dừa|thăm làng địa phương|đi thuyền ngắm đảo',
    'EG|africa|Ai Cập|65|8|kim tự tháp Giza|đền Karnak|koshari~falafel Ai Cập|đi thuyền sông Nile|tìm hiểu chữ tượng hình',
    'MA|africa|Morocco|70|8|phố cổ Fès|quảng trường Jemaa el-Fnaa|tagine~couscous|thăm xưởng gốm|khám phá chợ thủ công',
    'ZA|africa|Nam Phi|75|8|Table Mountain|vườn quốc gia Kruger|bobotie~bunny chow|safari với hướng dẫn viên|ngắm cảnh Cape Town',
    'KE|africa|Kenya|80|8|Masai Mara|vườn quốc gia Nairobi|ugali~irio|safari có hướng dẫn|tìm hiểu nghề thủ công',
    'TZ|africa|Tanzania|85|8|Serengeti|phố đá Zanzibar|pilau~mchuzi|ngắm động vật cùng hướng dẫn viên|tìm hiểu lịch sử giao thương',
    'TN|africa|Tunisia|65|8|di tích Carthage|Sidi Bou Said|couscous~brik|khám phá kiến trúc phố cổ|thăm xưởng gốm'
  ];
  G.TRAVEL50_DATA=rows.map(function(row){var a=row.split('|');return{code:a[0],region:a[1],name:a[2],base:+a[3],days:+a[4],places:[a[5],a[6]],foods:a[7].split('~'),activities:[a[8],a[9]]};});
  // Tuổi dưới đây là ngưỡng thận trọng dùng riêng trong game, không phải nhãn kiểm duyệt chính thức.
  var films=[
    ['anime','Demon Slayer: Mugen Train',2020,16,'action'],['anime','Demon Slayer: Infinity Castle',2025,16,'action'],
    ['anime','SPY x FAMILY CODE: White',2023,12,'comedy'],['anime',"My Hero Academia: You’re Next",2024,13,'action'],
    ['anime','My Hero Academia: Heroes Rising',2019,13,'action'],['anime','My Hero Academia: World Heroes’ Mission',2021,13,'action'],
    ['anime','Your Name.',2016,12,'romance'],['anime','Weathering with You',2019,12,'romance'],['anime','Suzume',2022,12,'fantasy'],
    ['anime','Spirited Away',2001,8,'fantasy'],['anime','Howl’s Moving Castle',2004,8,'fantasy'],['anime','My Neighbor Totoro',1988,6,'family'],
    ['anime','Kiki’s Delivery Service',1989,6,'family'],['anime','Ponyo',2008,6,'family'],['anime','Princess Mononoke',1997,13,'fantasy'],
    ['anime','The Boy and the Heron',2023,13,'fantasy'],['anime','A Silent Voice',2016,13,'drama'],['anime','The First Slam Dunk',2022,12,'sport'],
    ['anime','One Piece Film: Red',2022,13,'action'],['anime','One Piece: Stampede',2019,13,'action'],['anime','Jujutsu Kaisen 0',2021,16,'action'],
    ['anime','Haikyu!! The Dumpster Battle',2024,10,'sport'],['anime','Stand by Me Doraemon',2014,6,'family'],['anime','Stand by Me Doraemon 2',2020,6,'family'],
    ['anime','Detective Conan: The Million-dollar Pentagram',2024,12,'mystery'],['anime','Dragon Ball Super: Broly',2018,12,'action'],
    ['china','Na Tra: Ma Đồng Giáng Thế',2019,12,'fantasy'],['china','Na Tra 2: Ma Đồng Náo Hải',2025,12,'fantasy'],
    ['china','Tây Du Ký: Đại Thánh Trở Về',2015,10,'fantasy'],['china','Khương Tử Nha',2020,12,'fantasy'],
    ['china','Bạch Xà: Duyên Khởi',2019,16,'romance'],['china','Thanh Xà: Kiếp Khởi',2021,16,'fantasy'],
    ['china','Trường An Tam Vạn Lý',2023,10,'history'],['china','Thâm Hải',2023,13,'drama'],
    ['china','Hùng Sư Thiếu Niên',2021,8,'drama'],['china','Đại Ngư Hải Đường',2016,12,'fantasy'],
    ['disney','Frozen',2013,6,'family'],['disney','Frozen II',2019,6,'family'],['disney','Zootopia',2016,6,'comedy'],
    ['disney','Zootopia 2',2025,6,'comedy'],['disney','Moana',2016,6,'adventure'],['disney','Moana 2',2024,6,'adventure'],
    ['disney','Encanto',2021,6,'family'],['disney','Tangled',2010,6,'romance'],['disney','Big Hero 6',2014,6,'action'],
    ['disney','The Lion King (hoạt hình 1994)',1994,6,'family'],['disney','Beauty and the Beast (hoạt hình 1991)',1991,6,'romance'],
    ['disney','Wreck-It Ralph',2012,6,'comedy'],['disney','Ralph Breaks the Internet',2018,6,'comedy'],
    ['disney','Coco (Disney/Pixar)',2017,6,'family'],['disney','Inside Out (Disney/Pixar)',2015,6,'family'],
    ['disney','Inside Out 2 (Disney/Pixar)',2024,6,'family'],['disney','Toy Story (Disney/Pixar)',1995,6,'family'],
    ['disney','Toy Story 3 (Disney/Pixar)',2010,6,'family'],['disney','Finding Nemo (Disney/Pixar)',2003,6,'adventure'],
    ['disney','WALL-E (Disney/Pixar)',2008,6,'romance'],['disney','Up (Disney/Pixar)',2009,6,'adventure'],['disney','Soul (Disney/Pixar)',2020,8,'drama']
  ];
  G.CINEMA50_DATA=films.map(function(a,i){return{id:'classic'+i,group:a[0],name:a[1],year:a[2],min:a[3],genre:a[4],classic:true};});
})(G);

;
/* ===== js/life62.js ===== */
/* V5.0 — chuyến đi có đặt gói, chọn địa danh / ẩm thực / hoạt động và chuyện dọc đường. */
(function(G){
  'use strict';
  var E=G.E,H=E.H,U=G.U,DATA=G.TRAVEL50_DATA,B=E.LEISURE_BILL;
  var REGIONS={asia:'Châu Á',europe:'Châu Âu',americas:'Châu Mỹ',africa:'Châu Phi',oceania:'Châu Đại Dương'};
  var INCIDENTS=[['Mưa đến đúng buổi tham quan.','Đổi sang bảo tàng / hoạt động trong nhà','Giữ lịch ngoài trời nếu thời tiết cho phép'],['Chuyến tàu / xe nội địa đổi giờ.','Nhờ đơn vị tổ chức đổi lịch trong gói','Bỏ một điểm, dành thời gian nghỉ'],['Một điểm đến đông hơn dự kiến.','Đi vào khung giờ khác và tôn trọng hàng chờ','Khám phá khu phố gần đó thay thế'],['Cách gọi món khác với điều bạn hình dung.','Hỏi nguyên liệu và đổi món phù hợp','Chọn món quen, vẫn thử món mới ở bữa sau'],['Bạn mệt sau những ngày đi liên tục.','Dành nửa ngày nghỉ, chọn tuyến nhẹ','Rút gọn hành trình, ưu tiên điểm yêu thích'],['Bạn được giới thiệu một làng nghề ít xuất hiện trên ảnh quảng cáo.','Tham quan cùng hướng dẫn viên và hỏi về nghề','Giữ lịch chính, tìm hiểu qua bảo tàng']];
  function current(l){return l.abroad&&l.abroad.code||l.country;}
  function pid(l){if(!l.partner)return'';if(E.HOMETOWN)E.HOMETOWN.partner(l,l.partner);return l.partner.heritageId||[l.partner.name,l.partner.since,l.partner.age].join(':');}
  function couple(l){return !!(l.partner&&l.partner.alive!==false&&l.age>=18&&l.partner.age>=18);}
  function free(l){var f=l.flags;return l.alive&&l.age>=16&&!(l.jailUntil!=null&&l.age<l.jailUntil)&&!(f.military&&l.age<f.military)&&!(l.abroad&&l.abroad.trapped)&&!(E.FILM&&E.FILM.busy(l))&&!(f.variety&&!f.variety.done)&&!(f.tv&&!f.tv.done&&!f.tv.out&&!f.tv.no);}
  function ledger(l){var s=l.flags.travel50||(l.flags.travel50={serial:0,at:l.age,count:0,seen:{},history:[]});if(s.at!==l.age){s.at=l.age;s.count=0;}return s;}
  function state(l){return l.flags.trip50;}
  function fresh(l){return free(l)&&ledger(l).count<3;}
  function valid(l,d){var s=state(l);if(!free(l))return false;if(!d||d.token==null)return fresh(l);return !!s&&!s.done&&d.token===s.token&&d.stage===s.stage&&s.age===l.age&&s.source===current(l)&&s.cur===l.cur&&(s.paid||s.factor===E.lifestyleFactor(l))&&(!s.withPartner||couple(l)&&s.pid===pid(l));}
  function option(k,n,h){return{k:k,l:n,h:h||''};}
  function dest(l){var s=state(l);return s.local||DATA.filter(function(p){return p.code===s.code;})[0];}
  function unit(l,n){return E.LIFESTYLE.unit(l,n);}
  function quote(l,s){s=s||state(l);var p=s.local||DATA.filter(function(p){return p.code===s.code;})[0];if(!p)return null;
    // Vé và giấy tờ giữ nguyên; phần lưu trú / ăn / trải nghiệm tăng theo mức dịch vụ.
    var flight=p.region==='domestic'?p.base*.3:p.region==='asia'?p.base*.42:p.base*.5,visa=p.region==='domestic'?0:p.base*.06,land=p.base-flight-visa;
    var per=flight+visa+land*s.factor;if(p.region==='asia')per=Math.min(50,per);var ratio=land>0?(per-flight-visa)/land:1,people=s.withPartner?2:1;
    return{flight:unit(l,flight)*people,visa:unit(l,visa)*people,stay:unit(l,land*.5*ratio)*people,food:unit(l,land*.25*ratio)*people,activities:unit(l,land*.25*ratio)*people,per:unit(l,per),vndPer:per,people:people,total:unit(l,per)*people,days:p.days};
  }
  function snapshot(l){var s=state(l);return{token:s.token,stage:s.stage};}
  function queue(l){if(valid(l,snapshot(l)))l.pending.unshift(E.DEC.travel50_step.make(l));}
  function init(l,r){if(!fresh(l))return null;var s=state(l);if(s&&!s.done&&s.age===l.age&&s.source===current(l)&&s.cur===l.cur&&(s.paid||s.factor===E.lifestyleFactor(l))&&(!s.withPartner||couple(l)&&s.pid===pid(l)))return s;
    if(s&&!s.done){s.done=true;s.interrupted=true;}var book=ledger(l);s=l.flags.trip50={token:++book.serial,age:l.age,source:current(l),cur:l.cur,factor:E.lifestyleFactor(l),stage:'root',page:0,done:false,paid:false,incident:U.randint(r,0,INCIDENTS.length-1),choices:[]};return s;
  }
  function list(l){var s=state(l);return DATA.filter(function(p){return p.region===s.region&&p.code!==s.source;});}
  function options(l){var s=state(l),a=[],p=dest(l),q=quote(l,s);
    if(s.stage==='root'){a.push(option('near','Du lịch trong nước','Chuyến ngắn khoảng 3 ngày, tự chọn mức chi tiêu'));if(l.age>=18)Object.keys(REGIONS).forEach(function(k){a.push(option(k,REGIONS[k],k==='asia'?'Gói khoảng 8–50 triệu đ/người từ Việt Nam; giá hiển thị đã theo nếp chi tiêu':'Gói đường dài đắt hơn châu Á; xem từng điểm đến để biết giá'));});}
    if(s.stage==='country'){var all=list(l);all.slice(s.page*10,s.page*10+10).forEach(function(p){var cost=quote(l,Object.assign({},s,{code:p.code,withPartner:false}));a.push(option(p.code,p.name,p.days+' ngày · '+H.money(l,cost.per)+'/người · '+p.places.join(' / ')));});if((s.page+1)*10<all.length)a.push(option('next','Xem điểm đến tiếp theo ›'));if(s.page>0)a.push(option('prev','‹ Trang trước'));a.push(option('back','Chọn châu lục khác'));}
    if(s.stage==='party'){a.push(option('solo','Đi một mình',H.money(l,q.per)+'/người'));if(couple(l))a.push(option('couple','Rủ '+l.partner.name+' cùng đi','Hai người · '+H.money(l,q.per*2)));}
    if(s.stage==='book'){['self','split','partner'].forEach(function(k){if(k!=='self'&&!s.withPartner)return;if(B.can(l,q.total,k))a.push(option(k,k==='self'?'Bạn thanh toán và đặt gói':k==='split'?'Hai người chia đôi':'Người ấy đồng ý mời cả chuyến','Bạn trả '+H.money(l,q.total*B.share(k))+(s.withPartner?' · '+l.partner.name+' trả '+H.money(l,q.total*(1-B.share(k))):'')));});}
    if(s.stage==='place')p.places.forEach(function(n,i){a.push(option('p'+i,'Khám phá '+n));});
    if(s.stage==='food'){a=[option('local','Thử đặc sản địa phương',food(l,p,s.withPartner)),option('veg','Chọn món chay địa phương, hỏi nguyên liệu'),option('familiar','Chọn món quen để hợp khẩu vị')];}
    if(s.stage==='activity')p.activities.forEach(function(n,i){a.push(option('a'+i,n));});
    if(s.stage==='incident'){var x=INCIDENTS[s.incident];a=[option('adapt',x[1]),option('rest',x[2])];}
    a.push(option('cancel',s.paid?'Kết thúc hành trình sớm':'Để dịp khác',s.paid?'Dịch vụ đã sử dụng / đặt không tự hoàn tiền':'Chưa đặt gói thì chưa thu tiền'));return a;
  }
  function food(l,p,withPartner){if(withPartner&&E.HOMETOWN)return E.HOMETOWN.meal(l,p);if(l.allergy&&!/bụi|phấn hoa|penicillin/.test(l.allergy))return'món địa phương đã kiểm tra thành phần, tránh '+l.allergy;if(l.flags.vegetarian||/Hồi giáo|Hindu|Ấn Độ giáo/.test(l.religion||''))return'món địa phương phù hợp ăn chay / kiêng kỵ, xác nhận nguyên liệu trước khi gọi';return p.foods.join(' và ');}
  function text(l){var s=state(l),p=dest(l),q=quote(l,s);if(s.stage==='root')return 'Bạn muốn đi đâu? Mỗi năm có thể sắp xếp tối đa 3 chuyến.';
    if(s.stage==='country')return 'Điểm đến '+REGIONS[s.region]+' · trang '+(s.page+1)+'. Giá gói tính cho một người.';
    return p.name+' · '+p.days+' ngày · '+(s.withPartner?'cùng '+l.partner.name:'một người')+'. '+
      (s.stage==='party'?'Bạn muốn đi một mình hay rủ người yêu / bạn đời?':s.stage==='book'?'Tổng '+H.money(l,q.total)+' cho '+q.people+' người. Gồm vé khứ hồi / di chuyển '+H.money(l,q.flight)+', giấy tờ '+H.money(l,q.visa)+', lưu trú '+H.money(l,q.stay)+', ăn uống '+H.money(l,q.food)+', vé tham quan / hoạt động '+H.money(l,q.activities)+'. Thu một lần sau khi xác nhận, không tự đổi nơi định cư / tiền tệ.':s.stage==='place'?'Bạn muốn dành thời gian khám phá địa danh nào?':s.stage==='food'?'Bữa ăn trong gói: chọn theo khẩu vị và kiêng kỵ; không ép ăn món không phù hợp.':s.stage==='activity'?'Chọn trải nghiệm trong lịch trình, ưu tiên tuyến vừa sức; đã gồm trong ngân sách.':INCIDENTS[s.incident][0]+' Đơn vị tổ chức hỗ trợ trong ngân sách đã đặt, không tự thu thêm.');}
  function finish(l,log,early){var s=state(l);if(!s||s.done)return;s.done=true;s.early=!!early;if(!s.paid)return;var p=dest(l);H.visit(l,p.name);H.fx(l,{hap:early?1:6,kno:early?0:2,soc:s.withPartner?2:0});if(s.withPartner&&l.partner&&pid(l)===s.pid)l.partner.close=U.clamp((l.partner.close||60)+(early?0:3),0,100);
    var story=(early?'Kết thúc sớm chuyến ':'Hoàn thành chuyến ')+p.name+(s.withPartner?' cùng '+l.partner.name:'')+': '+s.choices.join('; ')+'. '+(s.payer?'Bạn trả '+H.money(l,s.payer.self)+(s.payer.partner?', người ấy trả '+H.money(l,s.payer.partner):''):'')+'.';log(story,'good');H.mem(l,story,3);var book=ledger(l);book.history.push({age:l.age,code:p.code,name:p.name,total:s.quote.total,cur:s.cur,withPartner:s.withPartner,early:!!early,choices:s.choices.slice()});if(book.history.length>30)book.history.shift();}
  function apply(l,d,k,r,log){if(!d.data||d.data.token==null||!valid(l,d.data))return;var s=state(l);if(!options(l).some(function(o){return o.k===k;}))return;
    if(k==='cancel'){finish(l,log,true);return;}if(s.stage==='root'){if(k==='near'){var home=DATA.filter(function(p){return p.code===current(l);})[0],co=G.W.BY[current(l)],name=current(l)==='VN'&&E.nearTrip?E.nearTrip(l,r):home?U.pick(r,home.places):co?U.pick(r,co.cities):'khu vực gần nơi đang sống';s.local={code:'domestic',name:name,region:'domestic',base:3,days:3,places:[name,'không gian văn hóa địa phương tại '+name],foods:['món đặc sản địa phương'],activities:['thăm làng nghề phù hợp lịch trình','dạo cảnh đẹp, chụp ảnh kỷ niệm']};s.code='domestic';s.stage='party';}else{s.region=k;s.page=0;s.stage='country';}}
    else if(s.stage==='country'){if(k==='next')s.page++;else if(k==='prev')s.page--;else if(k==='back')s.stage='root';else{s.code=k;s.stage='party';}}
    else if(s.stage==='party'){s.withPartner=k==='couple';s.pid=s.withPartner?pid(l):'';s.stage='book';}
    else if(s.stage==='book'){var q=quote(l,s),bill=B.pay(l,q.total,k,'Gói du lịch '+dest(l).name);if(!bill)return;s.paid=true;s.payer=bill;s.quote=q;s.stage='place';ledger(l).count++;log('Đặt gói '+dest(l).name+' cho '+q.people+' người, tổng '+H.money(l,q.total)+'. Bạn thanh toán '+H.money(l,bill.self)+(bill.partner?', '+l.partner.name+' thanh toán '+H.money(l,bill.partner)+' từ ngân sách riêng':'')+'. Đã gồm lưu trú, ăn, vé, hoạt động và giấy tờ.','neutral');}
    else if(s.stage==='place'){s.choices.push('tham quan '+dest(l).places[+k.slice(1)]);s.stage='food';}
    else if(s.stage==='food'){s.choices.push(k==='local'?'thưởng thức '+food(l,dest(l),s.withPartner):k==='veg'?'chọn món chay địa phương đã kiểm tra nguyên liệu':'chọn món quen hợp khẩu vị');s.stage='activity';}
    else if(s.stage==='activity'){s.choices.push(dest(l).activities[+k.slice(1)]);s.stage='incident';}
    else if(s.stage==='incident'){s.choices.push(INCIDENTS[s.incident][k==='adapt'?1:2]);finish(l,log,false);return;}queue(l);
  }
  E.DEC.travel50_step={make:function(l){return{id:'travel50_step',title:state(l).stage==='root'?'Lên kế hoạch du lịch':state(l).stage==='country'?'Chọn quốc gia / điểm đến':dest(l).name+' · '+({party:'Bạn đồng hành',book:'Xác nhận gói',place:'Danh lam thắng cảnh',food:'Ẩm thực',activity:'Trải nghiệm',incident:'Chuyện dọc đường'}[state(l).stage]),text:text(l),opts:options(l),data:snapshot(l)};},valid:valid,auto:function(l,d,r){var a=d.opts.filter(function(o){return o.k!=='next'&&o.k!=='prev'&&o.k!=='back'&&o.k!=='cancel';});return a.length?U.pick(r,a).k:'cancel';},apply:apply};
  E.DEC.du_lich={make:function(l,r){if(!init(l,r))return{id:'du_lich',title:'Chưa thể khởi hành',text:'Cần đủ tuổi, lịch trống và còn lượt hành trình trong năm.',opts:[option('cancel','Để dịp khác')],data:{}};return E.DEC.travel50_step.make(l);},valid:valid,auto:E.DEC.travel50_step.auto,apply:apply};
  E.ACT.filter(function(a){return a.id==='du_lich';}).forEach(function(a){a.avail=function(l){return fresh(l)?true:'Cần đủ 16 tuổi (nước ngoài từ 18), được tự do, lịch quay trống; tối đa 3 hành trình/năm';};});
  // Ngẫu nhiên chỉ mời chọn lịch trình, không tự trừ tiền / tự gán người đã mất đi cùng.
  E.EVENTS.forEach(function(ev){if(/abroadTrip/.test(ev.run.toString())){ev.travel50=true;ev.run=function(l,a,r,log){if(fresh(l)&&!l.pending.some(function(d){return d.id==='travel50_step';})){log(U.pick(r,['Bạn muốn dành ít ngày khám phá một vùng đất khác. Chọn gói trước rồi mới thanh toán.','Lâu rồi chưa đi đâu xa, bạn bắt đầu tìm hiểu một chuyến du lịch.','Đồng nghiệp khoe ảnh chuyến đi, bạn cũng muốn xách ba lô lên đường một chuyến.','Kỳ nghỉ sắp tới, bạn mở bản đồ tính chuyện đi chơi xa.','Bạn bè rủ lên kế hoạch cho một chuyến đi, xem gói trước rồi mới quyết.','Mệt mỏi sau một năm làm việc, bạn muốn đổi gió vài ngày.']),'neutral');l.pending.push(E.DEC.du_lich.make(l,r));}};}});
  E.TRAVEL50={data:DATA,regions:REGIONS,incidents:INCIDENTS,current:current,valid:valid,free:free,quote:quote,options:options,ledger:ledger,state:state,init:init};
})(G);

;
/* ===== js/life63.js ===== */
/* V5.0 — chọn phim và quà theo gu người ấy, giá và người thanh toán rõ ràng. */
(function(G){
  'use strict';
  var E=G.E,H=E.H,U=G.U,B=E.LEISURE_BILL,FILMS=G.CINEMA50_DATA;
  var GENRES={comedy:'Phim hài',animation:'Phim hoạt hình',horror:'Phim kinh dị',romance:'Phim tình cảm',action:'Phim hành động',drama:'Phim chính kịch',mystery:'Phim trinh thám',adventure:'Phim phiêu lưu',fantasy:'Phim kỳ ảo',sport:'Phim thể thao',history:'Phim lịch sử'};
  var ANIMATION={anime:'Anime Nhật Bản',china:'Hoạt hình Trung Quốc',disney:'Hoạt hình Disney / Pixar'};
  var GIFTS={flowers:{n:'Hoa',items:[['Một bó hoa nhỏ',0.15],['Bó hồng đỏ 99 bông',1.5],['Bó tulip Hà Lan',0.9],['Bó hướng dương rực rỡ',0.35],['Bó hoa baby trắng',0.3],['Hoa hồng bất tử trong hộp kính',1.2],['Bó hoa sáp thơm (không héo)',0.25],['Bó hoa len tự móc',0.2],['Hộp hoa kèm thiệp ghi âm lời nhắn',.6],['Bó hoa tiền mệnh giá nhỏ',0.8],['Bó hoa gấu bông kèm kẹo',0.5],['Giỏ hoa mẫu đơn cao cấp',2.5]]},jewelry:{n:'Trang sức',items:[['Vòng tay bạc đơn giản',0.8],['Nhẫn đôi bạc khắc tên',1.2],['Dây chuyền bạc đính đá trang trí',2.5],['Bông tai ngọc trai',2,'F'],['Lắc tay vàng 18K',7],['Bộ trang sức thiết kế',8],['Đồng hồ cơ dây da',6,'M']]},cosmetics:{n:'Mỹ phẩm',items:[['Bộ chăm sóc cơ bản đúng nhu cầu',.5],['Son Hoa Biết hộp khắc hoa',.45,'F'],['Bộ trang điểm Hoa Biết phiên bản giới hạn',1.6,'F'],['Bảng phấn mắt Judydoll / Perfect Diary',.4,'F'],['Son kem 3CE / Romand đúng màu người ấy thích',.35,'F'],['Thỏi son Dior / MAC',1.1,'F'],['Bộ dưỡng da Laneige / Innisfree',.9],['Bộ mỹ phẩm phù hợp da',1.5],['Bộ chăm sóc da cho nam',.8,'M'],['Bộ quà mỹ phẩm cao cấp',4]]},fashion:{n:'Thời trang / nước hoa',items:[['Khăn len quàng cổ',0.3],['Áo hoodie đôi',0.8],['Chai nước hoa người ấy hay dùng',3],['Nước hoa nữ Chanel / Dior / YSL',3.5,'F'],['Nước hoa nam Bleu de Chanel / Dior Sauvage',3.5,'M'],['Nước hoa mini chiết, bộ nhiều mùi',0.6],['Ví da khắc tên',1.2,'M'],['Thắt lưng da thương hiệu',2.5,'M'],['Cà vạt lụa và kẹp cà vạt',0.9,'M'],['Áo sơ mi may đo',1.5,'M'],['Túi xách thời trang',3,'F'],['Váy đầm dự tiệc',2,'F'],['Giày sneaker bản giới hạn',5],['Túi hàng hiệu',45,'F']]},teddy:{n:'Gấu bông',items:[['Gấu bông nhỏ',0.2],['Gấu bông cỡ vừa',0.6],['Gấu bông nhân vật hoạt hình người ấy thích',0.9],['Gấu bông khổng lồ 1m8',1.8],['Gấu bông thiết kế',1.5]]},handmade:{n:'Quà handmade',items:[['Thiệp từ vật liệu sẵn có',0],['Album ảnh tự làm',0.15],['Lọ 365 ngôi sao giấy tự gấp',0.05],['Hộp 100 lá thư tay',0.05],['Video kỷ niệm tự dựng',0],['Khăn len tự đan',0.2],['Đồ đan / đồ thủ công tự làm',0.35]]},food:{n:'Đồ ăn ngọt',items:[['Hộp socola tự làm',0.3],['Bánh kem tự tay trang trí',0.35],['Hộp socola nhập khẩu',0.8],['Giỏ trái cây nhập khẩu',1.2],['Bánh macaron Pháp',0.5]]},tech:{n:'Đồ công nghệ',items:[['Loa bluetooth mini',1],['Máy ảnh chụp lấy liền (instax)',2.5],['Tai nghe không dây',3],['Bàn phím cơ custom',2.5],['Chuột và lót chuột gaming',1.2],['Tay cầm chơi game',1.5],['Đồng hồ thông minh',6],['Máy chơi game cầm tay',9],['Máy chơi game console',13]]},experience:{n:'Trải nghiệm',items:[['Lớp làm gốm cho hai người',0.8],['Voucher spa thư giãn',1.5],['Vé xem concert nghệ sĩ người ấy thích',2.5],['Bữa tối nhà hàng bất ngờ',2],['Chuyến đi nghỉ cuối tuần',6]]},books:{n:'Sách / đồ sở thích',items:[['Cuốn sách người ấy muốn đọc',0.18],['Bộ sách hoặc dụng cụ sở thích',0.6],['Mô hình Gundam lắp ráp (HG / MG)',0.9],['Mô hình Gundam cao cấp (PG)',6],['Bộ Lego Technic / Star Wars',3],['Bộ Lego hoa / nhà cổ tích',1.8],['Mô hình xe tỉ lệ 1:18',1.5],['Figure nhân vật anime',1.2],['Ấn bản sưu tầm / đồ thủ công đặt riêng',1.8]]},sport:{n:'Đồ thể thao',items:[['Áo đấu đội bóng người ấy cổ vũ',0.9],['Giày đá bóng',2],['Vợt cầu lông / pickleball',1.5],['Thảm và đồ tập yoga',0.8],['Vé xem trận đấu bóng đá',1.2],['Gói tập gym ba tháng',2]]}};
  var NAMED={comedy:['Ngày Cả Phố Đổi Vai','Chuyến Xe Toàn Tiếng Cười','Nhà Có Hai Đám Cưới'],horror:['Tiếng Gõ Sau Nửa Đêm','Căn Phòng Cuối Hành Lang','Đêm Không Có Bóng'],romance:['Hẹn Nhau Sau Cơn Mưa','Bức Thư Chưa Gửi','Mùa Hạ Của Hai Người'],action:['Đường Đua Cuối Cùng','Mật Lệnh Bình Minh','Chuyến Tàu Giải Cứu'],drama:['Phía Sau Khung Cửa','Những Người Ở Lại','Một Ngày Bình Thường'],mystery:['Dấu Vết Trên Tờ Vé','Nhân Chứng Thứ Tư','Mật Mã Thị Trấn'],adventure:['Bản Đồ Bên Kia Núi','Hành Trình Qua Đại Dương','Những Người Tìm Đường'],fantasy:['Người Giữ Ngọn Sao','Thành Phố Trên Mây','Cánh Cửa Mùa Đông'],sport:['Đường Chạy Cuối Mùa','Trận Đấu Ngày Mai','Những Người Không Bỏ Cuộc'],history:['Một Mùa Trong Thành Cổ','Người Thợ Giữ Sử','Dấu Chân Qua Thế Kỷ']};
  function current(l){return l.abroad&&l.abroad.code||l.country;}
  function free(l){return l.alive&&l.age>=6&&!(l.jailUntil!=null&&l.age<l.jailUntil)&&!(l.flags.military&&l.age<l.flags.military)&&!(l.abroad&&l.abroad.trapped);}
  function partner(l){return !!(l.partner&&l.partner.alive!==false&&l.age>=16&&l.partner.age>=16);}
  function pid(l){if(!l.partner)return'';if(E.HOMETOWN)E.HOMETOWN.partner(l,l.partner);return l.partner.heritageId||l.partner.name+':'+l.partner.since;}
  function hash(s){var n=2166136261;for(var i=0;i<s.length;i++)n=Math.imul(n^s.charCodeAt(i),16777619);return n|0;}
  function prefs(l){if(!partner(l))return null;var p=l.partner;if(p.datePrefs50)return p.datePrefs50;var seed={rs:hash(pid(l)+':tastes50')},r=function(){return U.rand(seed);},movies=Object.keys(GENRES).filter(function(k){return k!=='animation';}).concat(Object.keys(ANIMATION)),gifts=Object.keys(GIFTS),like=U.pick(r,movies),bad=U.pick(r,movies.filter(function(x){return x!==like;})),gift=U.pick(r,gifts),notGift=U.pick(r,gifts.filter(function(x){return x!==gift;}));return p.datePrefs50={like:like,dislike:bad,gift:gift,notGift:notGift,horrorSensitive:r()<.35,known:false};}
  function state(l){return l.flags.dateSession50;}
  function valid(l,d){var s=state(l);if(!free(l))return false;if(!d||d.token==null)return true;return !!s&&!s.done&&s.token===d.token&&s.stage===d.stage&&s.age===l.age&&s.cur===l.cur&&s.country===current(l)&&s.factor===E.lifestyleFactor(l)&&(!s.withPartner||partner(l)&&s.pid===pid(l));}
  function opt(k,n,h){return{k:k,l:n,h:h||''};}
  function init(l,kind,date){if(!free(l)||(kind==='gift'||date)&&!partner(l))return null;var serial=l.flags.dateSerial50=(l.flags.dateSerial50||0)+1,s=l.flags.dateSession50={token:serial,kind:kind,stage:kind==='gift'?'giftGroup':date?'genre':'party',age:l.age,cur:l.cur,country:current(l),factor:E.lifestyleFactor(l),withPartner:!!date||kind==='gift',pid:date||kind==='gift'?pid(l):'',page:0,done:false};if(s.withPartner)prefs(l);return s;}
  function age(l){var s=state(l);return s.withPartner?Math.min(l.age,l.partner.age):l.age;}
  function catalogue(l){var s=state(l),g=s.group;if(ANIMATION[g])return FILMS.filter(function(f){return f.group===g&&f.year<=l.birthYear+l.age&&f.min<=age(l);});return (NAMED[g]||[]).map(function(n,i){return{id:g+i,group:g,name:n,year:l.birthYear+l.age,min:g==='horror'?18:/action|romance|mystery|drama/.test(g)?13:6,genre:g,classic:false};}).filter(function(f){return f.min<=age(l);});}
  function quote(l){var s=state(l);if(s.kind==='gift'){var item=GIFTS[s.giftGroup].items[s.giftIndex],base=item[1]*(s.approach==='brand'?1.5:1);return E.activityPrice(l,base);}var people=s.withPartner?2:s.party==='family'?2:1;return E.activityPrice(l,.22*people);}
  function familyCan(l,total){if(l.age>=18||l.indep||!l.fam||!(l.fam.mAlive||l.fam.fAlive&&!l.fam.noDad))return false;var clone=JSON.parse(JSON.stringify(l));return E.childExpense(clone,total,'Vé phim',false).ok;}
  function prefsText(l){var p=prefs(l);return p&&p.known?' Gu người ấy: thích '+(GENRES[p.like]||ANIMATION[p.like])+', ít thích '+(GENRES[p.dislike]||ANIMATION[p.dislike])+', thích quà '+GIFTS[p.gift].n.toLowerCase()+', không chuộng '+GIFTS[p.notGift].n.toLowerCase()+(p.horrorSensitive?'; dễ khó chịu với phim kinh dị':'')+'.':'';}
  function choices(l){var s=state(l),a=[];
    if(s.stage==='party'){if(l.age>=12){a.push(opt('solo','Đi một mình'));a.push(opt('friends','Đi cùng bạn bè','Bạn chỉ trả vé / đồ ăn của mình; bạn bè tự trả phần của họ'));}if(l.age<18&&(l.fam.mAlive||l.fam.fAlive&&!l.fam.noDad))a.push(opt('family','Đi cùng người thân','Hai vé, chỉ khởi hành khi người lớn thu xếp được chi phí'));if(partner(l))a.push(opt('date','Rủ '+l.partner.name+' đi cùng'));}
    if(s.stage==='genre')Object.keys(GENRES).forEach(function(k){if(k==='animation'||k!=='horror'&&age(l)>=13||['comedy','adventure','fantasy','sport','history'].indexOf(k)>=0||k==='horror'&&age(l)>=18)a.push(opt(k,GENRES[k]));});
    if(s.stage==='animation')Object.keys(ANIMATION).forEach(function(k){a.push(opt(k,ANIMATION[k]));});
    if(s.stage==='film'){var all=catalogue(l);all.slice(s.page*8,s.page*8+8).forEach(function(f){a.push(opt(f.id,f.name,(f.classic?'Suất tuyển chọn / chiếu lại mô phỏng · '+f.year:'Phim hư cấu mới trong năm')+' · ngưỡng tuổi trong game '+f.min+'+ · '+(GENRES[f.genre]||f.genre)));});if((s.page+1)*8<all.length)a.push(opt('next','Xem thêm phim ›'));if(s.page>0)a.push(opt('prev','‹ Trang trước'));a.push(opt('back','Chọn lại thể loại'));}
    if(s.stage==='giftGroup')Object.keys(GIFTS).forEach(function(k){a.push(opt(k,GIFTS[k].n));});
    if(s.stage==='giftItem')GIFTS[s.giftGroup].items.forEach(function(x,i){if(x[2]&&l.partner&&l.partner.sex!==x[2])return;a.push(opt('g'+i,x[0],E.H.money(l,E.activityPrice(l,x[1]))+' · giá đã theo nếp chi tiêu'));});
    if(s.stage==='approach')a=s.kind==='gift'?[opt('care','Hỏi nhu cầu / kích cỡ, kèm lời nhắn riêng','Không ép người ấy nhận món không thích; quà hợp gu quan trọng hơn giá'),opt('surprise','Tạo bất ngờ, chọn theo ý mình'),opt('brand','Chọn gói / thương hiệu đắt hơn','Giá ×1,5; không bảo đảm người ấy thích')]:[opt('care','Trao đổi trước về nội dung, tôn trọng cảm giác người ấy'),opt('talk','Cùng thảo luận sau phim'),opt('ignore','Cứ xem phim mình thích, không hỏi người ấy')];
    if(s.stage==='bill'){var q=quote(l);if(B.can(l,q,'self'))a.push(opt('self','Bạn thanh toán '+H.money(l,q)));if(s.kind==='movie'&&s.withPartner){if(B.can(l,q,'split'))a.push(opt('split','Chia đôi · mỗi người '+H.money(l,q/2)));if(B.can(l,q,'partner'))a.push(opt('partner',l.partner.name+' đồng ý trả '+H.money(l,q),'Trừ trong ngân sách riêng có thật, không trừ phần góp sinh hoạt'));}if(s.kind==='movie'&&familyCan(l,q))a.push(opt('family','Gia đình thanh toán '+H.money(l,q),'Ghi rõ ai trả từ ngân sách gia đình, không trừ tiền tiết kiệm của bạn'));}
    if(s.withPartner&&!prefs(l).known&&s.stage!=='bill')a.push(opt('ask','Hỏi gu phim và quà người ấy thích','Không tốn tiền'));
    a.push(opt('cancel',s.kind==='movie'?'Để dịp khác / xem hợp pháp ở nhà':'Chưa tặng quà'));return a;
  }
  function description(l){var s=state(l);return(s.kind==='gift'?'Chọn quà cho '+l.partner.name:'Đi xem phim'+(s.withPartner?' cùng '+l.partner.name:''))+'. '+(s.stage==='bill'?'Tổng phải trả '+H.money(l,quote(l))+'. Đã gồm '+(s.kind==='gift'?'vật liệu / món quà và gói đã chọn':'vé và phần đồ ăn trong gói')+'. Chưa xác nhận thì chưa trừ tiền.':s.kind==='movie'?'Bạn muốn xem thể loại nào?':'Bạn muốn chọn món quà gì?')+prefsText(l);}
  function queue(l){var s=state(l);if(valid(l,{token:s.token,stage:s.stage}))l.pending.unshift(E.DEC.date50_step.make(l));}
  function outcome(l,r,log,bill){var s=state(l),delta=0,p=l.partner,pref=s.withPartner?prefs(l):null,name=s.kind==='gift'?GIFTS[s.giftGroup].items[s.giftIndex][0]:s.film.name,key=s.kind==='gift'?'gift:'+s.giftGroup:'film:'+s.film.id;
    if(pref){var taste=s.kind==='gift'?s.giftGroup:s.film.group,genre=s.kind==='movie'?s.film.genre:null;delta=s.kind==='gift'?(taste===pref.gift?5:taste===pref.notGift?-3:2):(taste===pref.like||genre===pref.like?5:taste===pref.dislike||genre===pref.dislike?-4:2);
      if(s.kind==='movie'&&s.film.genre==='horror'&&pref.horrorSensitive)delta=-5;
      if(s.approach==='care')delta+=2;else if(s.approach==='ignore')delta-=3;else if(s.approach==='talk')delta+=1;
      if(s.kind==='gift'&&s.giftGroup==='cosmetics'&&p.allergy)delta=s.approach==='care'?1:-5;
      var history=p.dateEffects50;if(!history||history.age!==l.age)history=p.dateEffects50={age:l.age,count:0,seen:{}};if(delta>0){if(history.seen[key]||history.count>=6)delta=0;else history.count++;}history.seen[key]=true;p.close=U.clamp((p.close==null?60:p.close)+delta,0,100);
    }
    H.fx(l,{hap:delta<0?-2:delta===0&&s.withPartner?1:4,soc:s.withPartner&&delta>0?1:0});s.done=true;s.paid=true;s.bill=bill;s.delta=delta;
    log((s.kind==='gift'?'Tặng ':'Xem ')+name+(s.withPartner?(s.kind==='gift'?' cho ':' cùng ')+p.name:' với '+(s.party==='family'?'người thân':s.party==='friends'?'bạn bè':'chính mình'))+'. '+(s.withPartner?(delta>0?'Người ấy thấy được quan tâm, tình cảm +'+delta:delta<0?'Trải nghiệm không hợp gu / cách quan tâm, tình cảm '+delta:'Đã chia sẻ trải nghiệm nhưng không cộng thêm tình cảm từ việc lặp lại')+'. ':'')+'Bạn trả '+H.money(l,bill.self||0)+(bill.partner?', người ấy trả '+H.money(l,bill.partner):'')+(bill.family?' · '+String(bill.family).replace(/[.s]+$/,''):'')+'.',''+(delta<0?'neutral':'good'));
    var history=l.flags.dateHistory50||(l.flags.dateHistory50=[]);history.push({age:l.age,kind:s.kind,pid:s.pid,name:name,total:s.total,cur:s.cur,delta:delta,bill:bill});if(history.length>50)history.shift();
    if(s.withPartner&&delta>=5)H.mem(l,(s.kind==='gift'?'Món quà ':'Buổi xem phim ')+name+' cùng '+p.name+'.',3);
  }
  function apply(l,d,k,r,log){if(!d.data||d.data.token==null||!valid(l,d.data))return;var s=state(l);if(!choices(l).some(function(o){return o.k===k;}))return;if(k==='cancel'){s.done=true;log('Để dịp khác, chưa phát sinh chi phí.','neutral');return;}if(k==='ask'){prefs(l).known=true;queue(l);return;}
    if(s.stage==='party'){s.party=k;s.withPartner=k==='date';s.pid=s.withPartner?pid(l):'';if(s.withPartner)prefs(l);s.stage='genre';}
    else if(s.stage==='genre'){s.group=k;s.stage=k==='animation'?'animation':'film';s.page=0;}
    else if(s.stage==='animation'){s.group=k;s.stage='film';s.page=0;}
    else if(s.stage==='film'){if(k==='next')s.page++;else if(k==='prev')s.page--;else if(k==='back')s.stage='genre';else{s.film=catalogue(l).filter(function(f){return f.id===k;})[0];s.stage=s.withPartner?'approach':'bill';}}
    else if(s.stage==='giftGroup'){s.giftGroup=k;s.stage='giftItem';}
    else if(s.stage==='giftItem'){s.giftIndex=+k.slice(1);s.stage='approach';}
    else if(s.stage==='approach'){s.approach=k;s.stage='bill';}
    else if(s.stage==='bill'){var total=quote(l),bill;if(k==='family'){var result=E.childExpense(l,total,'Vé xem phim '+s.film.name,false);if(!result.ok){log(result.note,'neutral');return;}bill={self:0,partner:0,family:result.note};}else bill=B.pay(l,total,k,s.kind==='gift'?'Quà cho '+l.partner.name:'Vé xem phim '+s.film.name);if(!bill)return;s.total=total;outcome(l,r,log,bill);return;}queue(l);
  }
  E.DEC.date50_step={make:function(l){var s=state(l);return{id:'date50_step',title:s.kind==='gift'?'Quà tặng người ấy':s.stage==='animation'?'Chọn dòng phim hoạt hình':'Chọn phim và buổi xem',text:description(l),opts:choices(l),data:{token:s.token,stage:s.stage}};},valid:valid,auto:function(l,d,r){var a=d.opts.filter(function(o){return !/^(ask|next|prev|back|cancel)$/.test(o.k);});return a.length?U.pick(r,a).k:'cancel';},apply:apply};
  E.DEC.xem_phim={make:function(l){var s=init(l,'movie',false);return s?E.DEC.date50_step.make(l):{id:'xem_phim',title:'Chưa thể đi xem phim',text:'Hiện tại chưa thể ra rạp.',opts:[opt('cancel','Đóng')],data:{}};},valid:free,auto:E.DEC.date50_step.auto,apply:apply};
  E.SC('gift50',{title:'Tặng quà người yêu / bạn đời',valid:function(l){return free(l)&&partner(l);},text:'Chọn món quà hợp nhu cầu của người ấy.',opts:[{k:'choose',l:'Chọn loại quà',run:function(l){init(l,'gift',true);queue(l);}},{k:'no',l:'Để dịp khác',run:function(){}}]});
  E.ACT.push({id:'gift50',g:'Tình cảm',l:'Chọn quà tặng người yêu / bạn đời',min:16,sc:'gift50',avail:function(l){return free(l)&&partner(l)?true:'Cần người yêu / bạn đời còn sống, cả hai từ 16 tuổi, được tự do';},ai:{w:.2}});
  E.DEC.hen_ho.def.opts.push({k:'cinema50',l:'Đi xem phim: chọn thể loại và tác phẩm',req:function(l){return free(l)&&partner(l);},run:function(l){init(l,'movie',true);queue(l);}},{k:'gift50',l:'Chọn quà theo gu người ấy',req:function(l){return free(l)&&partner(l);},run:function(l){init(l,'gift',true);queue(l);}});
  E.DEC.hen_ho.def.opts.forEach(function(o){if(o.k==='phim'){o.h='Chọn phim, trao đổi nội dung rồi xác nhận giá ở bước sau';o.run=function(l){if(init(l,'movie',true))queue(l);};}});
  E.ACT.filter(function(a){return a.id==='xem_phim';}).forEach(function(a){a.avail=function(l){return free(l)?true:'Chưa thể ra rạp trong hoàn cảnh hiện tại';};});
  var dateValid=E.DEC.hen_ho.valid;E.DEC.hen_ho.valid=function(l){return free(l)&&partner(l)&&dateValid.apply(this,arguments);};
  E.DATE50={genres:GENRES,animation:ANIMATION,gifts:GIFTS,films:FILMS,free:free,partner:partner,prefs:prefs,init:init,state:state,valid:valid,catalogue:catalogue,choices:choices,quote:quote};
})(G);

;
