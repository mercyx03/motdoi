/* ===== js/life102.js ===== */
/* Một Đời — v8.4.0
   · Khối thi năng khiếu có trường thật: H00 (Văn – Hình họa – Bố cục màu), V00 (Toán – Lý – Vẽ mỹ thuật), S00 (Văn + năng khiếu sân khấu – điện ảnh),
     N00 (Văn + năng khiếu âm nhạc). Danh sách nguyện vọng có các trường Mỹ thuật, Kiến trúc, Sân khấu – Điện ảnh, Âm nhạc, Nghệ thuật;
     mỗi trường ghi rõ khối xét tuyển, trường hợp khối được đưa lên đầu, trường nghệ thuật có thêm vòng thi năng khiếu (thang 10).
   · Học bổ túc văn hóa (giáo dục thường xuyên) cho người nghỉ học sớm: vừa đi làm vừa học buổi tối, xong THPT thì thi tốt nghiệp,
     rồi có thể thi đại học, học đại học vừa làm vừa học, hoặc xin việc đòi hỏi bằng cấp cao hơn.
   Điểm chuẩn, điểm năng khiếu trong game là mô phỏng. */
(function (G) {
  'use strict';
  var E = G.E, H = E.H, U = G.U, SC = E.SC, isVN = H.isVN;
  var EDU54 = E.EDUCATION54, WISH = E.DEC.study_wishes54;
  function fx(l, o) { H.fx(l, o); }
  function vnd(l) { return isVN(l) && l.cur === 'vnd' && !(l.abroad && l.abroad.perm); }
  function V(l, tr) { return vnd(l) ? tr : tr / 90 * l.base; }
  function mo(l, v) { return H.money(l, v); }
  function free(l) { return l.alive && !(l.jailUntil != null && l.age < l.jailUntil) && !(l.flags.military && l.age < l.flags.military) && !(l.abroad && l.abroad.trapped); }
  function stress(l, d) { if (l.mind) l.mind.stress = U.clamp(l.mind.stress + d, 0, 100); }
  function sc(n) { return U.fmtNum(n, 2).replace(/,?0+$/, ''); }

  // ===================================================================
  // 1. KHỐI THI NĂNG KHIẾU
  // ===================================================================
  var NK_BLOCKS = { H00: 1, V00: 1, S00: 1, N00: 1 };
  E.KHOI.H00 = { n: 'Văn – Hình họa – Bố cục màu', m: ['art', 'edu'] };
  E.KHOI.V00 = { n: 'Toán – Lý – Vẽ mỹ thuật (kiến trúc)', m: ['art'] };
  E.KHOI.S00 = { n: 'Văn – Năng khiếu sân khấu, điện ảnh', m: ['art'] };
  E.KHOI.N00 = { n: 'Văn – Năng khiếu âm nhạc', m: ['art', 'edu'] };
  var KHOI_FOR_TALENT = { 'hội họa': 'H00', 'diễn xuất': 'S00', 'âm nhạc': 'N00' };
  // thêm các khối mới vào tình huống "Chọn khối thi" (tình huống được tạo trước khi có các khối này)
  var CK = E.DEC.chon_khoi;
  if (CK && CK.def) {
    CK.def.opts = CK.def.opts.filter(function (o) { return o.k !== 'H00'; });
    [['H00', 'Hợp ngành Hội họa, Thiết kế đồ họa – thời trang, Kiến trúc, Sư phạm mỹ thuật · thi vẽ năng khiếu', 'hội họa', 0.6],
      ['V00', 'Hợp ngành Kiến trúc, Quy hoạch, Thiết kế nội thất · thi Toán, Lý và Vẽ mỹ thuật', 'hội họa', 0.5],
      ['S00', 'Hợp ngành Diễn viên kịch – điện ảnh, Đạo diễn · thi diễn xuất, hát – múa, hình thể', 'diễn xuất', 0.3],
      ['N00', 'Hợp ngành Thanh nhạc, Nhạc cụ, Sư phạm âm nhạc · thi hát, xướng âm – thẩm âm', 'âm nhạc', 0.3]].forEach(function (x) {
      var k = x[0], K = E.KHOI[k];
      CK.def.opts.push({ k: k, l: 'Khối ' + k + ' (' + K.n + ')', h: x[1],
        ai: function (l) { return (l.talent === x[2] ? 6 : 1) * x[3]; },
        run: function (l, r, log) { l.khoi = k; l.flags.nkPrep = 1; log('Chọn khối ' + k + ' (' + K.n + '). Ngoài giờ học văn hóa, bạn đi học thêm năng khiếu ' + (k === 'S00' ? 'diễn xuất, hát – múa' : k === 'N00' ? 'thanh nhạc, xướng âm' : 'vẽ hình họa, bố cục màu') + ' để thi vào trường chuyên ngành.', 'neutral'); } });
    });
  }

  // ===================================================================
  // 2. TRƯỜNG NGHỆ THUẬT TRONG DANH SÁCH NGUYỆN VỌNG & XÉT THEO KHỐI
  // ===================================================================
  var SCHOOLS = EDU54.schools;
  // [mã, tên, miền, thành phố, mốc điểm văn hóa, ngành, khối xét, nội dung thi năng khiếu, tên ngành, nghề sau khi ra trường, năng khiếu phù hợp, điểm năng khiếu tối thiểu]
  [['mtvn', 'Trường Đại học Mỹ thuật Việt Nam', 'Bắc', 'Hà Nội', 17, ['art'], ['H00'], 'Hình họa (vẽ tượng) và Bố cục màu', 'Hội họa', ['hoa_si', 'thiet_ke', 'giao_vien'], 'hội họa', 5],
    ['mtcn', 'Trường Đại học Mỹ thuật Công nghiệp', 'Bắc', 'Hà Nội', 19, ['art'], ['H00'], 'Hình họa và Trang trí màu', 'Thiết kế đồ họa – thời trang', ['thiet_ke', 'tk_thoi_trang', 'fl_thiet_ke'], 'hội họa', 5.5],
    ['hau', 'Trường Đại học Kiến trúc Hà Nội', 'Bắc', 'Hà Nội', 21, ['art'], ['V00', 'H00'], 'Vẽ mỹ thuật (vẽ tượng)', 'Kiến trúc', ['kien_truc', 'thiet_ke'], 'hội họa', 5],
    ['skda', 'Trường Đại học Sân khấu – Điện ảnh Hà Nội', 'Bắc', 'Hà Nội', 15, ['art'], ['S00'], 'Diễn tiểu phẩm, hát – múa, đọc thơ và kiểm tra hình thể', 'Diễn viên kịch – điện ảnh', ['dien_vien', 'mc_tv', 'dao_dien'], 'diễn xuất', 6],
    ['hvan', 'Học viện Âm nhạc Quốc gia Việt Nam', 'Bắc', 'Hà Nội', 15, ['art'], ['N00'], 'Thanh nhạc, xướng âm – thẩm âm', 'Thanh nhạc', ['ca_si', 'nhac_si', 'giang_vien'], 'âm nhạc', 6.5],
    ['spnttw', 'Trường Đại học Sư phạm Nghệ thuật Trung ương', 'Bắc', 'Hà Nội', 16, ['edu', 'art'], ['H00', 'N00'], 'Vẽ hình họa – trang trí (mỹ thuật) hoặc hát – thẩm âm (âm nhạc)', 'Sư phạm Mỹ thuật – Âm nhạc', ['giao_vien', 'hoa_si', 'ca_si'], null, 5],
    ['hufa', 'Trường Đại học Nghệ thuật – Đại học Huế', 'Trung', 'Huế', 16, ['art'], ['H00'], 'Hình họa và Bố cục màu', 'Hội họa – Thiết kế', ['hoa_si', 'thiet_ke', 'fl_thiet_ke'], 'hội họa', 5],
    ['dau', 'Trường Đại học Kiến trúc Đà Nẵng', 'Trung', 'Đà Nẵng', 17, ['art'], ['V00', 'H00'], 'Vẽ mỹ thuật', 'Kiến trúc', ['kien_truc', 'thiet_ke'], 'hội họa', 5],
    ['hcmufa', 'Trường Đại học Mỹ thuật TP. Hồ Chí Minh', 'Nam', 'TP. Hồ Chí Minh', 17, ['art'], ['H00'], 'Hình họa và Bố cục màu', 'Hội họa', ['hoa_si', 'thiet_ke', 'giao_vien'], 'hội họa', 5],
    ['uah', 'Trường Đại học Kiến trúc TP. Hồ Chí Minh', 'Nam', 'TP. Hồ Chí Minh', 21, ['art'], ['V00', 'H00'], 'Vẽ mỹ thuật (vẽ tượng)', 'Kiến trúc', ['kien_truc', 'thiet_ke'], 'hội họa', 5],
    ['skdahcm', 'Trường Đại học Sân khấu – Điện ảnh TP. Hồ Chí Minh', 'Nam', 'TP. Hồ Chí Minh', 15, ['art'], ['S00'], 'Diễn tiểu phẩm, hát – múa và kiểm tra hình thể', 'Diễn viên kịch – điện ảnh', ['dien_vien', 'mc_tv'], 'diễn xuất', 6],
    ['nvhcm', 'Nhạc viện TP. Hồ Chí Minh', 'Nam', 'TP. Hồ Chí Minh', 15, ['art'], ['N00'], 'Thanh nhạc, xướng âm – thẩm âm', 'Thanh nhạc', ['ca_si', 'nhac_si'], 'âm nhạc', 6.5]
  ].forEach(function (x) {
    if (SCHOOLS.some(function (s) { return s.id === x[0]; })) return;
    SCHOOLS.push({ id: x[0], name: x[1], region: x[2], city: x[3], score: x[4], majors: x[5], blocks: x[6], nk: x[7], mn: x[8], jobs: x[9], talent: x[10], nkPass: x[11] });
  });
  // khối xét tuyển của các trường thường: theo ngành
  var BLOCKS = { it: ['A00', 'A01'], eco: ['A00', 'A01', 'D01'], med: ['B00'], edu: ['A00', 'B00', 'C00', 'D01'], law: ['A00', 'C00', 'D01'], art: ['H00'] };
  function school(id) { return SCHOOLS.filter(function (s) { return s.id === id; })[0]; }
  function blocksOf(u, m) {
    if (u.blocks) return u.blocks;
    var out = [];
    (m ? [m] : u.majors).forEach(function (x) { (BLOCKS[x] || []).forEach(function (b) { if (out.indexOf(b) < 0) out.push(b); }); });
    return out;
  }
  // chưa chọn khối (đời lưu cũ, học ở nước ngoài về…) thì không chặn hồ sơ
  function fits(l, u, m) { return !l.khoi || blocksOf(u, m).indexOf(l.khoi) >= 0; }
  function nkLabel(u) { return 'Thi năng khiếu: ' + u.nk + ' · cần ≥' + sc(u.nkPass) + '/10'; }
  function ct(x) { var u = school(x.school); return u ? u.name + ' · ' + (u.mn || E.MAJORS[x.major]) : ''; }
  // điểm thi năng khiếu (thang 10): ôn khối năng khiếu, luyện thi và năng khiếu thật quyết định
  function nkScore(l, u, r) {
    var match = u.talent ? l.talent === u.talent : /hội họa|âm nhạc/.test(l.talent || '');
    var s = (/S00|N00/.test(u.blocks.join()) ? 2.8 : 3.4) + (l.khoi && u.blocks.indexOf(l.khoi) >= 0 ? 0.8 : 0) + (l.flags.nkPrep ? 0.8 : 0) +
      (l.flags.tPrep || 0) * 0.8 + Math.max(0, l.flags.luyenThi || 0) * 0.3 + (match ? U.clamp(((l.skill || 20) - 30) / 18, 0, 3.5) : 0) + U.normal(r) * 0.9;
    return Math.round(U.clamp(s, 0, 10) * 4) / 4;
  }
  E.ARTS84 = { blocksOf: blocksOf, fits: fits, nkScore: nkScore, school: school };

  // hiển thị: trường hợp khối của bạn lên đầu, ghi rõ khối xét tuyển; trường nghệ thuật ghi nội dung thi năng khiếu
  var wm = WISH.make, wa = WISH.apply, wauto = WISH.auto;
  WISH.make = function (l) {
    var d = wm.apply(this, arguments), s = EDU54.state(l), K = l.khoi && E.KHOI[l.khoi];
    if (s.selected) {
      var u = school(s.selected);
      if (u) d.opts.forEach(function (o) {
        if (o.k.indexOf('major_') !== 0) return;
        var m = o.k.slice(6);
        if (u.nk) { o.l = u.mn + (u.majors.length > 1 && m === 'edu' ? ' (hệ sư phạm)' : ''); o.h = 'Mốc văn hóa mô phỏng ' + u.score + '/30 · ' + nkLabel(u); }
        o.h += ' · xét khối ' + blocksOf(u, m).join(', ') + (l.khoi ? fits(l, u, m) ? ' · ✓ hợp khối ' + l.khoi : ' · ✗ không xét khối ' + l.khoi + ' của bạn' : '');
      });
    } else if (s.region) {
      d.opts.forEach(function (o) {
        if (o.k.indexOf('school_') !== 0) return;
        var u = school(o.k.slice(7)); if (!u) return;
        o.h = u.city + ' · xét khối ' + blocksOf(u).join(', ') + (u.nk ? ' · có thi năng khiếu' : '') + (l.khoi ? fits(l, u) ? ' · ✓ hợp khối ' + l.khoi : '' : '');
        o._fit = !l.khoi ? 0 : fits(l, u) ? 2 : 0;
      });
      var back = d.opts.filter(function (o) { return o.k.indexOf('school_') !== 0; }), list = d.opts.filter(function (o) { return o.k.indexOf('school_') === 0; });
      list.sort(function (a, b) { return (b._fit || 0) - (a._fit || 0); });
      list.forEach(function (o) { delete o._fit; });
      d.opts = list.concat(back);
    } else {
      d.opts.forEach(function (o) { if (o.k.indexOf('remove_') === 0) { var x = s.wishes[+o.k.slice(7)]; if (x) o.l = 'Bỏ NV' + (+o.k.slice(7) + 1) + ': ' + ct(x); } });
    }
    var list2 = s.wishes.length ? s.wishes.map(function (x, i) { return 'NV' + (i + 1) + ': ' + ct(x); }).join('; ') : 'Chưa có nguyện vọng';
    d.text = list2 + '. ' + (K ? 'Bạn thi khối ' + l.khoi + ' (' + K.n + ') — chỉ trường xét khối này mới nhận hồ sơ' + (NK_BLOCKS[l.khoi] ? ', trường nghệ thuật có thêm vòng thi năng khiếu' : '') + '. ' : '') +
      'Chọn tối đa 5 trường/ngành theo thứ tự yêu thích. Xét nguyện vọng đầu tiên đủ điểm; điểm trong game là mô phỏng.';
    return d;
  };
  // máy tự chọn: chỉ chọn trường hợp khối
  WISH.auto = function (l, d, r) {
    var s = EDU54.state(l);
    if (s.region && !s.selected && l.khoi) {
      var fit = d.opts.filter(function (o) { var u = o.k.indexOf('school_') === 0 && school(o.k.slice(7)); return u && fits(l, u); });
      if (fit.length) {
        var score = Number.isFinite(l.examScore) ? l.examScore : 20;
        var ok = fit.filter(function (o) { return school(o.k.slice(7)).score <= score; });
        return (ok[0] || fit[fit.length - 1]).k;
      }
      return 'back';
    }
    if (s.selected && l.khoi) {
      var u = school(s.selected), m = u && u.majors.filter(function (x) { return fits(l, u, x); })[0];
      if (m) return 'major_' + m;
    }
    if (!s.selected && !s.region && !s.wishes.length && l.khoi && NK_BLOCKS[l.khoi]) {
      var regs = ['Bắc', 'Trung', 'Nam'].filter(function (g) { return SCHOOLS.some(function (u) { return u.region === g && fits(l, u); }); });
      if (regs.length) return 'region_' + U.pick(r, regs);
    }
    return wauto.apply(this, arguments);
  };
  // nộp hồ sơ: chỉ xét nguyện vọng hợp khối; trường nghệ thuật thi thêm năng khiếu
  WISH.apply = function (l, d, k, r, log) {
    if (k !== 'submit') return wa.apply(this, arguments);
    var s = EDU54.state(l);
    if (!WISH.valid(l, d.data) || !d.opts.some(function (o) { return o.k === k; }) || !s.wishes.length) return;
    s.submitted = true; s.kind = null;
    if (!Number.isFinite(l.examScore)) l.examScore = E.rollExamScore(l, r);
    log('Điểm xét tuyển: ' + U.fmtNum(l.examScore, 2) + '/30' + (l.khoi ? ' (khối ' + l.khoi + ')' : '') + '.', 'neutral');
    var found = null, nkDone = {};
    for (var i = 0; i < s.wishes.length && !found; i++) {
      var x = s.wishes[i], u = school(x.school); if (!u) continue;
      if (!fits(l, u, x.major)) { log('NV' + (i + 1) + ' (' + u.name + ') không xét khối ' + l.khoi + ' — hồ sơ không hợp lệ.', 'neutral'); continue; }
      if (u.nk) {
        var t = nkDone[u.id] != null ? nkDone[u.id] : (nkDone[u.id] = nkScore(l, u, r));
        var cult = l.examScore >= u.score;
        log('Thi năng khiếu tại ' + u.name + ' (' + u.nk + '): ' + sc(t) + '/10' + (t >= u.nkPass ? ' — đạt.' : ' — chưa đạt.') + (t >= u.nkPass && !cult ? ' Nhưng điểm văn hóa chưa đủ mốc ' + u.score + '.' : ''), t >= u.nkPass ? 'good' : 'neutral');
        if (t >= u.nkPass && cult) found = x;
      } else if (l.examScore >= EDU54.threshold(u, x.major) || EDU54.direct(l, x.major)) found = x;
    }
    if (!found) { log('Chưa đạt các nguyện vọng đã nộp. Bạn có thể ôn thi lại, học nghề hoặc đi làm.', 'neutral'); l.pending.unshift(E.DEC.uniFail.make(l, r)); return; }
    var a = school(found.school);
    s.admitted = { school: found.school, major: found.major, age: l.age };
    l.uniName = a.name; l.uniCity = a.city; l.uniTier = a.nk ? (a.score >= 19 ? 1.15 : 1.08) : a.score >= 25 ? 1.15 : 1; l.cityStudent = { city: a.city, since: l.age };
    E.DEC.major.apply(l, E.DEC.major.make(l), found.major, r, log);
    if (a.nk) {
      l.majorName = a.mn;
      // ra trường được gợi ý nghề đúng chuyên ngành (dùng chung luồng của các trường năng khiếu)
      l.flags.tSchool = { id: a.id, n: a.name, mn: a.mn, jobs: a.jobs.slice(), cd: false, at: l.age };
      if (a.talent && l.talent === a.talent) l.skill = Math.min(100, (l.skill || 20) + 3);
    }
    log('Trúng tuyển NV' + (s.wishes.indexOf(found) + 1) + ': ' + ct(found) + (!a.nk && EDU54.direct(l, found.major) ? ' · xét thành tích học sinh giỏi.' : '.'), 'big');
    H.mem(l, 'Nhập học ' + ct(found) + '.', 4);
  };

  // ===================================================================
  // 3. HỌC BỔ TÚC VĂN HÓA (GIÁO DỤC THƯỜNG XUYÊN) — vừa làm vừa học buổi tối
  // ===================================================================
  function gdtxOk(l) {
    if (!free(l)) return 'Không áp dụng lúc này';
    if (l.edu >= 3) return 'Đã có bằng tốt nghiệp phổ thông';
    if (l.school) return 'Đang đi học';
    if (l.flags.gdtx) return 'Đang học bổ túc';
    if (l.flags.hsFail && l.edu === 2 && l.age < 21) return 'Có thể đăng ký thi lại tốt nghiệp THPT';
    return true;
  }
  function fee(l) { return V(l, isVN(l) ? 4 : 8); }
  function startGdtx(l, lvl, years, log, note) {
    l.flags.gdtx = { from: l.edu, lvl: lvl, until: l.age + years, start: l.age, fee: fee(l) };
    log(note, 'good'); fx(l, { hap: 3 }); stress(l, 4);
    H.mem(l, 'Năm ' + l.age + ' tuổi, bạn cắp sách đi học lại lớp buổi tối.', 4);
  }
  SC('bo_tuc', {
    title: function (l) { return isVN(l) ? 'Học bổ túc văn hóa' : 'Học lại phổ thông (lớp buổi tối)'; },
    valid: function (l) { return gdtxOk(l) === true; },
    text: function (l) {
      return 'Bạn mới học hết ' + E.EDU[l.edu] + '. ' + (isVN(l) ? 'Trung tâm giáo dục thường xuyên gần nhà mở lớp bổ túc buổi tối cho người đi làm' : 'Trường cộng đồng gần nhà mở lớp phổ thông buổi tối cho người lớn') +
        ' — học phí khoảng ' + mo(l, fee(l)) + '/năm, ban ngày vẫn đi làm bình thường. Có bằng tốt nghiệp phổ thông, bạn sẽ thi được đại học, học nghề bậc cao và ứng tuyển nhiều việc lương tốt hơn.';
    },
    opts: [
      { k: 'thcs', l: 'Học bổ túc THCS (lớp 6–9) buổi tối', h: '2 năm · xong thì học tiếp THPT', req: function (l) { return l.edu < 2; }, ai: { w: 0.6, smart: 0.6 },
        run: function (l, r, log) { startGdtx(l, 2, 2, log, 'Đăng ký học bổ túc THCS buổi tối. Ngồi học cùng lớp toàn những người đi làm như mình.'); } },
      { k: 'lien', l: 'Học liền bổ túc THCS và THPT', h: '5 năm · ra bằng tốt nghiệp THPT', req: function (l) { return l.edu < 2; }, ai: { w: 0.8, amb: 1 },
        run: function (l, r, log) { startGdtx(l, 3, 5, log, 'Đăng ký học bổ túc từ lớp 6 đến lớp 12 buổi tối — con đường dài nhưng bạn quyết tâm.'); } },
      { k: 'thpt', l: 'Học bổ túc THPT (lớp 10–12) buổi tối', h: '3 năm · thi tốt nghiệp THPT như học sinh chính quy', req: function (l) { return l.edu === 2; }, ai: { w: 1, amb: 1 },
        run: function (l, r, log) { startGdtx(l, 3, 3, log, 'Đăng ký học bổ túc THPT buổi tối. Ba năm nữa sẽ thi tốt nghiệp cùng các em học sinh.'); } },
      { k: 'no', l: 'Thôi, đi làm kiếm tiền đã', ai: { w: 1.2 }, run: function (l, r, log) { l.flags.gdtxNo = l.age; log('Gác lại chuyện học, tập trung đi làm.', 'neutral'); } }
    ]
  });
  E.ACT.push({ id: 'bo_tuc', g: 'Học tập', l: 'Học bổ túc văn hóa', min: 16, max: 60, sc: 'bo_tuc',
    avail: function (l) { return gdtxOk(l); }, ai: function (l) { return l.edu < 3 && l.age >= 18 && l.age <= 35 && l.money > 0 ? 0.08 : 0; } });
  // người nghỉ học sớm, đã đi làm: thỉnh thoảng có người gợi ý đi học lại
  E.TRIG.push({ id: 'bo_tuc', when: function (l, a) { return a >= 17 && a <= 40 && l.edu < 3 && gdtxOk(l) === true && (!!l.job || l.indep) && (l.flags.gdtxNo == null || a - l.flags.gdtxNo >= 6); }, p: 0.07, cd: 5, max: 3 });

  // mỗi năm: đóng học phí, học buổi tối; đến hạn thì nhận bằng
  E.HOOKS.year.push(gdtxYear);
  function gdtxYear(l, r, log, a) {
    var g = l.flags.gdtx; if (!g || !l.alive) return;
    if (!free(l) || (l.abroad && !l.abroad.perm)) { log('Hoàn cảnh thay đổi, bạn đành bỏ dở lớp bổ túc.', 'bad'); delete l.flags.gdtx; return; }
    if (l.indep) H.cash(l, -g.fee, 'Học phí bổ túc văn hóa');
    fx(l, { kno: 3, hea: l.job ? -1 : 0 }); stress(l, l.job ? 3 : 1);
    if (a < g.until - 1 && l.mind && l.mind.stress > 88 && r() < 0.3) { log('Vừa làm vừa học kiệt sức quá, bạn xin bảo lưu, nghỉ lớp bổ túc.', 'bad'); delete l.flags.gdtx; return; }
    // học liền: hết 2 năm đầu thì có bằng THCS
    if (g.lvl === 3 && l.edu < 2 && a >= g.until - 3) { l.edu = 2; log('Hoàn thành chương trình bổ túc THCS, học tiếp lên THPT buổi tối.', 'good'); }
    if (a + 1 < g.until) return;
    delete l.flags.gdtx;
    if (g.lvl === 2) {
      l.edu = Math.max(l.edu, 2); log('Nhận bằng tốt nghiệp THCS hệ bổ túc.', 'good'); fx(l, { hap: 4 });
      if (l.job) l.flags.upgradeJob = true;
      return;
    }
    // THPT: thi tốt nghiệp như học sinh chính quy (điểm thi, trượt thì được thi lại)
    l.edu = Math.max(l.edu, 3);
    log('Học xong chương trình bổ túc THPT sau ' + (a + 1 - g.start) + ' năm vừa làm vừa học.', 'good');
    log(isVN(l) ? 'Tốt nghiệp THPT.' : 'Tốt nghiệp trung học phổ thông.', 'good');
    l.flags.gdtxGrad = a;
    E.HOOKS.gradUpper.forEach(function (fn) { fn(l, r, log); });
    if (l.edu < 3) return; // trượt tốt nghiệp: đã hẹn thi lại
    H.mem(l, 'Ngày cầm tấm bằng tốt nghiệp THPT hệ bổ túc, ở tuổi ' + (a + 1) + '.', 5); fx(l, { hap: 8 });
    l.pending.push(E.DEC.bo_tuc_xong.make(l, r));
  }
  // sau khi có bằng THPT: học tiếp hay đổi việc
  SC('bo_tuc_xong', {
    title: 'Có bằng tốt nghiệp phổ thông rồi — tiếp theo?',
    valid: function (l) { return l.edu >= 3 && !l.school && free(l); },
    text: function (l) { return 'Tấm bằng tốt nghiệp THPT mở ra những cánh cửa trước đây đóng lại với bạn' + (l.job ? ' — đang làm ' + E.jobTitle(l) + '.' : '.'); },
    opts: [
      { k: 'dh', l: 'Đăng ký thi đại học chính quy', h: 'Học toàn thời gian, phải nghỉ việc nếu đỗ', req: function (l) { return !!(EDU54.applicant && EDU54.applicant(l)); }, ai: { w: 0.5, amb: 1 },
        run: function (l, r, log) { log('Quyết định đăng ký thi đại học như các bạn trẻ.', 'neutral'); EDU54.open(l, r); } },
      { k: 'tai_chuc', l: 'Học đại học vừa làm vừa học (buổi tối, cuối tuần)', h: function (l) { return '4 năm · giữ được việc làm · khoảng ' + mo(l, V(l, 15)) + '/năm'; }, ai: { w: 0.8, smart: 0.6 },
        run: function (l, r, log) { H.cash(l, -V(l, 15), 'Học phí đại học vừa làm vừa học'); H.sched(l, 'xong_van_bang', 4); log('Đăng ký học đại học hệ vừa làm vừa học — thêm bốn năm đi về muộn.', 'neutral'); stress(l, 5); } },
      { k: 'nghe', l: 'Học cao đẳng nghề để có tay nghề vững', h: '2 năm · nghỉ việc đi học', ai: { w: 0.5 },
        run: function (l, r, log) { if (l.job) { l.lastJob = l.job; l.job = null; l.income = 0; } l.school = 'voc'; l.schoolEnd = l.age + 2; l.flags.needJob = false; log('Nghỉ việc, vào học cao đẳng nghề.', 'neutral'); } },
      { k: 'viec', l: 'Đi tìm việc tốt hơn với tấm bằng mới', ai: { w: 1 },
        run: function (l, r, log) { l.flags.upgradeJob = true; if (!l.job) l.flags.needJob = true; log('Cập nhật hồ sơ xin việc: đã có bằng tốt nghiệp THPT.', 'good'); } }
    ]
  });
  if (E.MAJOR) { E.MAJOR.bo_tuc = 1; E.MAJOR.bo_tuc_xong = 1; }
  E.GDTX84 = { ok: gdtxOk, fee: fee, yearHook: gdtxYear };
})(G);

;
/* ===== js/life103.js ===== */
/* Một Đời — v8.4.0: thừa kế tài sản hiện vật.
   Trước đây khi qua đời, di sản (nhà, đất, cơ sở kinh doanh…) bị quy hết ra tiền mặt. Giờ phân chia giống ngoài đời:
   · nhà đang ở, nhà / đất cho thuê, lô đất, cơ sở kinh doanh được sang tên cho người thừa kế, phần còn lại nhận bằng tiền;
   · nhà đang ở ưu tiên để lại cho vợ / chồng còn sống (người còn ở trong nhà); cơ sở kinh doanh giao cho người con đã trưởng thành;
   · ai nhận tài sản lớn hơn phần mình được hưởng thì bù tiền chênh lệch cho những người khác; nợ lớn hơn thì phải bán bớt tài sản;
   · "sống tiếp đời con": người con nhận đúng căn nhà, cửa hàng… của bố / mẹ (chưa đủ 18 tuổi thì người giám hộ giữ hộ).
   Giá trị phần hưởng của mỗi người không đổi so với trước — chỉ khác ở chỗ nhận bằng tài sản thay vì toàn tiền mặt. */
(function (G) {
  'use strict';
  var E = G.E, H = E.H, U = G.U;
  function mo(l, v) { return H.money(l, v); }
  function homeDebt(l) { return (l.mortgage || 0) + (l.loans || []).filter(function (x) { return x.type === 'home'; }).reduce(function (s, x) { return s + (x.bal || 0); }, 0); }
  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  function kidAge(l, i) { var k = l.kids[i], at = l.death ? l.death.age : l.age; return k ? at - (k.born || 0) : 0; }

  // các tài sản có thể sang tên (giá trị theo tiền của đời đang xét)
  function itemsOf(l) {
    var a = [];
    // giá trị thật của căn nhà; nợ vay mua nhà đã nằm trong phần nợ chung của di sản (trả từ di sản trước khi chia)
    if (l.ownHouse && (l.houseVal || 0) > 0) a.push({ t: 'home', n: l.houseName || 'căn nhà đang ở', v: l.houseVal, debt: homeDebt(l), k: l.houseK || null, tier: l.houseTier || null });
    (l.props || []).forEach(function (p, i) { if ((p.v || 0) > 0) a.push({ t: 'prop', n: p.n, v: p.v, i: i, data: clone(p) }); });
    (l.ventures || []).forEach(function (x, i) { if ((x.cap || 0) > 0) a.push({ t: 'venture', n: x.n + (x.br > 1 ? ' (' + x.br + ' cơ sở)' : ''), v: x.cap, i: i, data: clone(x) }); });
    if (l.assets && l.assets.land > 0.5) a.push({ t: 'land', n: 'lô đất', v: l.assets.land });
    return a.filter(function (x) { return x.v > 0.5; });
  }
  // những người nhận (gộp phần theo di chúc và theo pháp luật)
  function heirsOf(l) {
    var W = E.WILL70; if (!W || !W.estate) return { net: 0, list: [] };
    var s = W.estate(l), m = {};
    s.list.concat(s.law).forEach(function (x) {
      var key = x.kid != null ? 'k' + x.kid : x.spouse ? 'p' : x.society ? 's' : 'o:' + x.name;
      if (!m[key]) m[key] = { key: key, name: x.name, kid: x.kid, spouse: !!x.spouse, society: !!x.society, amount: 0, items: [], cash: 0 };
      m[key].amount += x.amount;
    });
    return { net: s.net, list: Object.keys(m).map(function (k) { return m[k]; }).filter(function (x) { return x.amount > 0.5; }) };
  }
  // phân chia: ai nhận tài sản nào, bao nhiêu tiền mặt
  function allocate(l) {
    var hs = heirsOf(l), list = hs.list, items = itemsOf(l), sold = [];
    if (!list.length || hs.net <= 0.5) return { net: hs.net, list: list, sold: items, items: items };
    // nợ lớn: tổng tài sản sang tên không được vượt quá di sản ròng — bán bớt tài sản nhỏ trước
    items.sort(function (a, b) { return b.v - a.v; });
    var total = items.reduce(function (s, x) { return s + x.v; }, 0);
    while (items.length && total > hs.net + 1e-6) { var x = items.pop(); sold.push(x); total -= x.v; }
    var people = list.filter(function (p) { return !p.society; }); // quỹ xã hội nhận tiền
    function left(p) { return p.amount - p.items.reduce(function (s, x) { return s + x.v; }, 0); }
    function give(p, x) { p.items.push(x); x.to = p.key; }
    items.forEach(function (x) {
      var cands = people.slice();
      if (x.t === 'home') { var sp = people.filter(function (p) { return p.spouse; })[0]; if (sp) cands = [sp]; }
      if (x.t === 'venture') { var adults = people.filter(function (p) { return p.kid != null && kidAge(l, p.kid) >= 18; }); if (adults.length) cands = adults; }
      if (!cands.length) { sold.push(x); return; }
      cands.sort(function (a, b) { return left(b) - left(a); });
      var p = cands[0];
      // nhận được nếu phần còn lại đủ ít nhất 70% giá trị (phần thiếu tự bù tiền cho người khác); nhà cho vợ / chồng luôn giữ lại
      if (left(p) >= x.v * 0.7 || (x.t === 'home' && p.spouse && left(p) >= x.v * 0.4)) give(p, x); else sold.push(x);
    });
    list.forEach(function (p) { p.cash = left(p); });
    return { net: hs.net, list: list, sold: sold, items: items };
  }
  E.ESTATE84 = { items: itemsOf, allocate: allocate };

  function itemLine(l, x) { return (x.t === 'home' ? 'nhà đang ở: ' : x.t === 'venture' ? 'cơ sở kinh doanh: ' : x.t === 'land' ? '' : 'nhà cho thuê: ') + x.n + ' (' + mo(l, x.v) + (x.t === 'home' && x.debt > 0.5 ? ', khoản vay mua nhà được trả từ di sản' : '') + ')'; }
  // khúc cuối đời: ghi rõ ai nhận nhà, đất, cửa hàng nào
  var fin = E.finale;
  E.finale = function (l) {
    var st = fin.apply(this, arguments);
    if (l.alive || !l.death || l.death.age < 18) return st;
    var A = allocate(l), withItems = A.list.filter(function (p) { return p.items.length; });
    if (!withItems.length && !A.sold.length) return st;
    var lines = A.list.map(function (p) {
      var parts = p.items.map(function (x) { return itemLine(l, x); });
      if (p.cash > 0.5) parts.push(mo(l, p.cash) + ' tiền mặt');
      else if (p.cash < -0.5) parts.push('bù ' + mo(l, -p.cash) + ' chênh lệch cho những người thừa kế khác');
      return p.name + ' nhận ' + (parts.length ? parts.join(' · ') : mo(l, p.amount)) + '.';
    });
    if (A.sold.length && A.net > 0.5) lines.push('Bán ' + A.sold.map(function (x) { return x.n; }).join(', ') + ' để ' + (A.items.length ? 'chia tiền cho đủ phần' : 'trả nợ và chia bằng tiền') + '.');
    st.push({ h: 'Phân chia tài sản', x: 'Nhà cửa, đất đai, cơ sở kinh doanh được sang tên cho người thừa kế; phần còn lại chia bằng tiền.', list: lines });
    return st;
  };

  // "sống tiếp đời con": người con nhận đúng tài sản được chia
  var childOpts = E.childOpts;
  E.childOpts = function (l, k) {
    var o = childOpts.apply(this, arguments), h = o.parent && o.parent.heir;
    if (!h || !l.death) return o;
    var A = allocate(l), p = A.list.filter(function (x) { return x.kid === h.idx; })[0];
    if (!p || !p.items.length) return o;
    h.items = p.items.map(function (x) { return { t: x.t, n: x.n, v: x.v, k: x.k || null, tier: x.tier || null, data: x.data || null }; });
    h.amt = Math.max(0, p.cash); h.pay = Math.max(0, -p.cash);
    h.place = l.movedTo || l.city || l.place || '';
    return o;
  };
  var createLife = E.createLife;
  E.createLife = function (opts) {
    var life = createLife.apply(this, arguments), h = opts && opts.parent && opts.parent.heir, f = life.flags.heirOf;
    if (h && f && h.items && h.items.length) {
      var scale = h.cur === life.cur && h.ctx === (life.abroad && life.abroad.perm ? life.abroad.code : life.country) ? 1 : life.base / h.base;
      f.items = h.items.map(function (x) { var y = clone(x); y.v *= scale; if (y.data) { ['v', 'basis', 'cap', 'unit', 'R'].forEach(function (k) { if (typeof y.data[k] === 'number') y.data[k] *= scale; }); } return y; });
      f.pay = (h.pay || 0) * scale; f.place = h.place;
    }
    return life;
  };
  function P(f) { return f && f.sex === 'M' ? 'bố' : 'mẹ'; }
  function receive(l, f, items, log, a) {
    items.forEach(function (x) {
      if (x.t === 'home') {
        if (!l.ownHouse) {
          l.ownHouse = true; l.houseVal = x.v; l.houseName = x.n; if (x.k) l.houseK = x.k; if (x.tier) l.houseTier = x.tier; l.flags.ownedHome = true;
          log('Bạn được thừa kế ' + x.n + (f.place ? ' ở ' + f.place : '') + ' của ' + P(f) + ', trị giá ' + mo(l, x.v) + '. Từ nay bạn có nhà riêng.', 'big');
          H.mem(l, 'Ngày nhận chìa khóa ' + x.n + ' ' + P(f) + ' để lại — căn nhà đầy kỷ niệm.', 5);
        } else if (x.v > (l.houseVal || 0) * 1.2 && !(l.abroad && l.abroad.perm)) {
          // nhà được thừa kế rộng / giá trị hơn hẳn: dọn về ở, cho thuê căn đang ở
          var old = { n: l.houseName || 'căn nhà cũ', v: l.houseVal || 0 };
          if (old.v > 0.5) (l.props = l.props || []).push({ k: 'apt', n: old.n + ' (cho thuê)', v: old.v, basis: old.v, y: 0.04, since: a, empty: 0 });
          l.houseVal = x.v; l.houseName = x.n; if (x.k) l.houseK = x.k; if (x.tier) l.houseTier = x.tier;
          log('Bạn dọn về ở ' + x.n + ' ' + P(f) + ' để lại (' + mo(l, x.v) + '), còn ' + old.n + ' đem cho thuê.', 'big');
          H.mem(l, 'Ngày dọn về ' + x.n + ' của ' + P(f) + ' — mọi góc nhà vẫn còn hơi ấm ngày xưa.', 5);
        } else {
          (l.props = l.props || []).push({ k: 'apt', n: x.n + ' ' + P(f) + ' để lại', v: x.v, basis: x.v, y: 0.04, since: a, empty: 0 });
          log('Bạn đã có nhà riêng, nên ' + x.n + ' ' + P(f) + ' để lại (' + mo(l, x.v) + ') được cho thuê, có thêm tiền thuê nhà hằng tháng.', 'good');
        }
      } else if (x.t === 'prop' && x.data) {
        var p = x.data; p.since = a; p.basis = p.v; p.empty = 0; (l.props = l.props || []).push(p);
        log('Bạn được thừa kế ' + p.n + ' đang cho thuê (' + mo(l, p.v) + ').', 'good');
      } else if (x.t === 'venture' && x.data) {
        var v = x.data, same = (l.ventures || []).filter(function (y) { return y.k === v.k; })[0];
        v.yrs = 0; v.bad = 0; v.good = 0;
        if (same) { same.br = (same.br || 1) + (v.br || 1); same.cap += v.cap; log('Bạn tiếp quản ' + v.n + ' của ' + P(f) + ', gộp vào cơ sở cùng ngành của mình (' + mo(l, v.cap) + ').', 'big'); }
        else { (l.ventures = l.ventures || []).push(v); log('Bạn tiếp quản ' + v.n + (v.br > 1 ? ' (' + v.br + ' cơ sở)' : '') + ' — cơ ngơi ' + P(f) + ' gây dựng, trị giá ' + mo(l, v.cap) + '.', 'big'); }
        H.mem(l, 'Ngày đầu tiên ngồi vào bàn làm việc của ' + P(f) + ' ở ' + v.n + '.', 5);
      } else if (x.t === 'land') {
        E.migrateExt && E.migrateExt(l);
        l.assets.land = (l.assets.land || 0) + x.v; l.basis.land = (l.basis.land || 0) + x.v;
        log('Bạn được thừa kế lô đất của ' + P(f) + ' (' + mo(l, x.v) + ').', 'good');
      }
    });
  }
  // nhận tài sản đúng năm bố / mẹ ra đi (chạy sau phần tiền mặt của bản cũ); chưa đủ 18 tuổi thì người giám hộ giữ hộ
  E.HOOKS.year.push(function (l, r, log, a) {
    var f = l.flags.heirOf;
    if (l.flags.heirItemsTrust && a >= 18) { var t = l.flags.heirItemsTrust; l.flags.heirItemsTrust = null; log('Tròn 18 tuổi, người giám hộ bàn giao lại tài sản ' + P(t.f) + ' để lại cho bạn.', 'good'); receive(l, t.f, t.items, log, a); }
    if (!f || !f.items || f.itemsDone || a < f.at) return;
    f.itemsDone = true;
    if (f.pay > 0.5) { H.cash(l, -f.pay, 'Bù chênh lệch thừa kế cho người thân'); log('Phần tài sản bạn nhận lớn hơn suất được hưởng, nên bạn bù ' + mo(l, f.pay) + ' cho những người thừa kế khác.', 'neutral'); }
    if (a >= 18) receive(l, f, f.items, log, a);
    else { l.flags.heirItemsTrust = { f: { sex: f.sex, name: f.name }, items: f.items }; log('Bạn chưa đủ 18 tuổi, nên ' + f.items.map(function (x) { return x.n; }).join(', ') + ' do người giám hộ đứng tên giữ hộ đến khi bạn trưởng thành.', 'neutral'); }
  });
})(G);

;
/* ===== js/life104.js ===== */
/* Real-world storm losses and married-partner name customization. */
(function(G){'use strict';var E=G.E,H=E.H;
function real(l){return l&&['vn','world'].includes(l.mode);}
function cropJob(job){return /làm ruộng|làm nương|trồng rẫy|trồng cây|nông dân|làm nông|chủ trang trại|ruộng bậc thang/.test(job||'');}
E.stormFarmExposure=function(l){if(!real(l)||l.urban)return false;var job=l.job&&E.jobDef(l),self=l.job&&E.resolveJob(l.job.id)==='nong'||job&&cropJob(job.n||job.title);if(self)return true;var f=l.fam||{};return !l.indep&&(f.fAlive&&!f.noDad&&cropJob(f.fJob)||f.mAlive&&cropJob(f.mJob));};
function stormPay(l,rate,reason,log){var amount=l.base*rate;if(l.age<18&&!l.indep&&E.childExpense){var payment=E.childExpense(l,amount,reason,true);log(payment.note,payment.ok?'neutral':'bad');return;}H.cash(l,-amount,reason);}
var storm=E.DEC.bao_lu.def;
storm.opts.find(function(o){return o.k==='fix';}).run=function(l,r,log){stormPay(l,.02,'Chằng chống nhà cửa',log);if(r()<.7)log('Nhà cửa đã được chằng chống, sau bão chỉ cần dọn dẹp và sửa vài chỗ hư hại nhẹ.','neutral');else{stormPay(l,l.ownHouse?.05:.02,'Sửa chữa sau bão',log);log(l.urban?'Mưa tạt và gió mạnh làm hỏng cửa, nước ngấm vào một số đồ đạc. Gia đình phải dọn dẹp và sửa lại.':'Một phần mái nhà bị hư dù đã chằng chống. Gia đình dọn đồ vào chỗ khô rồi sửa lại mái.','bad');H.fx(l,{hap:-4});}};
storm.opts.find(function(o){return o.k==='evac';}).run=function(l,r,log){if(r()>=.5){log('Sơ tán an toàn một đêm. Khi được phép trở về, nhà và đồ đạc vẫn còn nguyên.','neutral');return;}var farm=E.stormFarmExposure(l);stormPay(l,farm?.15:l.ownHouse?.03:.01,farm?'Thiệt hại mùa vụ sau bão':'Dọn dẹp, sửa chữa đồ đạc sau bão',log);var text=farm?'Bạn sơ tán an toàn. Khi trở về, nước đã ngập phần ruộng đang canh tác, một phần hoa màu bị mất; gia đình phải thu dọn và chuẩn bị lại vụ sau.':l.urban?'Bạn sơ tán an toàn. Khi trở về, nước đã tràn vào khu nhà, một số đồ đạc bị ngấm nước. Gia đình dọn bùn, hong khô đồ dùng và sửa phần hư hại.':'Bạn sơ tán an toàn. Khi trở về, sân và nền nhà còn bùn, một số đồ đạc bị ướt. Gia đình cùng dọn dẹp và sửa chữa phần bị hỏng.';log(text,'bad');H.fx(l,{hap:-8});H.mem(l,farm?'Ngày trở về thấy vụ mùa bị ngập sau bão.':'Ngày trở về dọn dẹp nhà cửa sau bão.',4);};
E.canRenameSpouse=function(l){var p=l&&l.partner;return !!(real(l)&&l.alive&&l.age>=18&&p&&p.alive!==false&&p.age>=18&&p.status==='married'&&E.FAMILY53.free(l));};
E.renameSpouse=function(l,value,expected,at,logger){if(!E.canRenameSpouse(l)||l.partner!==expected||l.age!==at)return{ok:false,message:'Chỉ có thể đổi tên vợ/chồng hiện tại sau khi đã kết hôn.'};if(typeof value!=='string')return{ok:false,message:'Tên không hợp lệ.'};value=value.normalize('NFC').trim().replace(/\s+/g,' ');if(!value||value.length>60||!/^\p{L}[\p{L}\p{M} .’'\-]*$/u.test(value))return{ok:false,message:'Tên cần dài 1–60 ký tự, dùng chữ và khoảng trắng.'};var p=l.partner,old=p.name;if(old===value)return{ok:true,message:'Tên được giữ nguyên.'};if(E.HOMETOWN)E.HOMETOWN.partner(l,p);if(!p.nameBeforeCustomization)p.nameBeforeCustomization=old;p.name=value;
if(p.fromFriend)[l.bff].concat(l.friends||[]).filter(Boolean).forEach(function(f){if(f.name===old&&f.sex===p.sex&&(f===l.bff||f.lover))f.name=value;});
function update(data){if(!data||typeof data!=='object')return;Object.keys(data).forEach(function(k){if(['name','n','partnerName','spouseName'].includes(k)&&data[k]===old)data[k]=value;else if(data[k]&&typeof data[k]==='object')update(data[k]);});}
function targeted(data){return data&&(data.type==='partner'||data.type==='spouse'||p.family100&&data.uid===p.family100.uid||p.heritageId&&data.pid===p.heritageId||data.partnerName===old||data.spouseName===old);}
(l.pending||[]).forEach(function(d){if(targeted(d.data))update(d.data);});(l.sched||[]).forEach(function(d){if(targeted(d.arg))update(d.arg);});
if(logger)logger('Bạn đổi tên '+(p.sex==='M'?'chồng':'vợ')+' từ '+old+' thành '+value+'.','neutral');return{ok:true,message:'Đã lưu tên vợ/chồng.'};};
})(globalThis.G);

;
/* ===== js/life105.js ===== */
/* Active music careers and net earnings after operating costs. */
(function(G){'use strict';var E=G.E,H=E.H,U=G.U,ids=['ca_si','rapper','nhac_si'];
function real(l){return l&&['vn','world'].includes(l.mode);}
function job(l){return l.job&&E.resolveJob(l.job.id);}
function free(l){return real(l)&&l.alive&&l.indep&&l.age>=18&&!l.retired&&E.FAMILY53.free(l)&&!(l.abroad&&l.abroad.study);}
function music(l){return free(l)&&ids.includes(job(l));}
function state(l){var s=l.flags.music105;if(!s||s.at!==l.age)s=l.flags.music105={at:l.age,used:{},units:0,done:0};return s;}
function peek(l){return l.flags.music105&&l.flags.music105.at===l.age?l.flags.music105:{used:{},units:0,done:0};}
function available(l,key,units){return music(l)&&!peek(l).used[key]&&peek(l).units+(units||1)<=5;}
function snap(l){return{at:l.age,job:job(l),base:l.base,done:false};}
function valid(l,d){return music(l)&&(!d||d.at==null||!d.done&&d.at===l.age&&d.job===job(l)&&d.base===l.base);}
function charge(l,d,key,units,rate,log){if(!valid(l,d)||!available(l,key,units)||l.money<l.base*rate)return false;d.done=true;var s=state(l);s.used[key]=true;s.units+=units;s.done++;if(rate)H.cash(l,-l.base*rate,'Chi phí '+key);return true;}
function fame(l,n){l.fame=Math.min(5e7,Math.max(50,(l.fame||0)+Math.round(n)));}
function pay(l,x,why){var amount=l.base*x*(l.difficulty==='hardcore'?.18:1);H.cash(l,amount,'Thực nhận · '+why);return amount/l.base;}
function skill(l,n){l.skill=U.clamp((l.skill||20)+n,0,100);}
function audience(l){return U.clamp(Math.log10(Math.max(50,l.fame||50))/7,0,1);}
function add(key,label,title,text,options,units){var id='music105_'+key;E.SC(id,{title:title,prep:snap,valid:function(l,d){return valid(l,d)&&available(l,key,units);},text:function(l){return text+'\nQuỹ thời gian âm nhạc còn '+(5-peek(l).units)+'/5 phần trong năm. Khoản thu công bố là sau chi phí; có thể không có thu nhập.';},opts:options.concat([{k:'cancel',l:'Để dịp khác',ai:{w:.2},run:function(l,r,log,d){if(valid(l,d))d.done=true;}}])});E.ACT.push({id:id,g:'Âm nhạc & sự nghiệp',l:label,min:18,sc:id,avail:function(l){if(!music(l))return 'Không áp dụng';return available(l,key,units)?true:peek(l).used[key]?'Đã làm việc này năm nay':'Đã dùng hết quỹ thời gian âm nhạc năm nay';}});}
function option(k,label,rate,run){return{k:k,l:label,h:function(l){return 'Chuẩn bị '+H.money(l,l.base*rate);},req:function(l){return l.money>=l.base*rate;},ai:{w:1},run:run};}
add('show','Tìm show, gửi demo và nhận lịch diễn','Tự tìm sân khấu','Bạn chủ động gửi demo cho bầu show, hỏi lịch phòng trà và cân nhắc cát-xê. Ngoài giọng hát, bên tổ chức còn xem lượng khán giả và khả năng làm việc đúng giờ.',[
 option('local','Gửi demo cho phòng trà, đám cưới · ít rủi ro',.008,function(l,r,log,d){if(!charge(l,d,'show',1,.008,log))return;if(r()<U.clamp(.25+(l.skill||20)*.004,.25,.7)){pay(l,.025+audience(l)*.025,'Cát-xê show nhỏ sau đi lại, tập dượt');fame(l,80+(l.skill||20)*3);log('Bạn chốt được một số buổi diễn nhỏ. Sau tiền đi lại và tập dượt, cát-xê còn lại không nhiều nhưng bạn có thêm người nghe và lời giới thiệu.','good');}else log('Các sân khấu bạn liên hệ đã kín lịch hoặc chưa chọn demo. Bạn mất công chuẩn bị, chưa có cát-xê.','neutral');}),
 option('big','Ứng tuyển festival, sân khấu lớn',.025,function(l,r,log,d){if(!charge(l,d,'show',1,.025,log))return;if(r()<U.clamp(.05+(l.skill||20)*.003+audience(l)*.18,.08,.5)){pay(l,.08+audience(l)*.09,'Cát-xê sân khấu lớn sau chi phí');fame(l,800+audience(l)*1800);H.fx(l,{hea:-2});log('Bạn được chọn biểu diễn sau vòng duyệt. Lịch tập dày và chi phí ê-kíp lấy đi một phần cát-xê; đổi lại, khán giả mới bắt đầu tìm nghe nhạc của bạn.','good');}else log('Đơn vị tổ chức chọn nghệ sĩ khác. Tiền quay demo và đi thử sân khấu không được hoàn lại.','bad');})]);
add('live','Livestream Instagram giao lưu với fan','Instagram Live cùng người nghe','Bạn có thể tự mở buổi hát, giới thiệu ca khúc và trả lời người nghe. Lượt xem không đồng nghĩa với tiền; quà tặng và doanh thu còn phụ thuộc khán giả quay lại.',[
 option('simple','Hát mộc, dùng thiết bị đang có',.005,function(l,r,log,d){if(!charge(l,d,'live',1,.005,log))return;var x=r();if(x<.55){fame(l,80+audience(l)*500);pay(l,.003+audience(l)*.018,'Quà tặng livestream sau phí nền tảng');log('Buổi hát có một nhóm khán giả ở lại đến cuối. Bạn nhận ít quà tặng, chủ yếu có thêm người nghe quen.','good');}else log('Buổi hát ít người xem, chưa thu hút thêm fan, không có quà tặng đáng kể. Bạn ghi lại lỗi âm thanh để sửa cho lần sau.','neutral');}),
 option('studio','Thuê âm thanh, lên chương trình có khách mời',.025,function(l,r,log,d){if(!charge(l,d,'live',1,.025,log))return;var success=r()<.25+audience(l)*.3;if(success){pay(l,.02+audience(l)*.05,'Doanh thu livestream sau phí nền tảng');fame(l,400+audience(l)*1400);log('Khách mời giữ được nhịp trò chuyện, vài đoạn hát được chia sẻ. Sau tiền thuê thiết bị, buổi phát chưa chắc lãi nhiều.','good');}else log('Lịch khách mời thay đổi, lượng xem thấp hơn dự tính. Khoản thuê âm thanh khiến buổi phát bị lỗ.','bad');})]);
add('training','Học hát, luyện thanh và biểu diễn','Đầu tư vào giọng hát','Bạn nghe lại phần thu live và chọn điểm cần sửa. Luyện tập giúp tiến bộ đều nhưng không bảo đảm nổi tiếng hay có show ngay.',[
 option('group','Học nhóm, luyện thanh có hướng dẫn',.025,function(l,r,log,d){if(!charge(l,d,'training',1,.025,log))return;skill(l,2+r()*2);log('Bạn tập hơi thở, cao độ và cách giữ giọng qua nhiều buổi. Bản thu cuối khóa chắc hơn trước; tay nghề tăng, chưa có khoản thu mới.','good');}),
 option('coach','Học riêng với huấn luyện viên thanh nhạc',.07,function(l,r,log,d){if(!charge(l,d,'training',1,.07,log))return;skill(l,4+r()*2);H.fx(l,{hea:-1});log('Huấn luyện viên sửa cách lấy hơi và chọn tông phù hợp. Lịch tập nghiêm túc giúp bạn cải thiện kỹ năng, nhưng học phí phải trả từ tiền đang có.','good');})]);
function release(l,r,log,d,album){var cost=album===true?1.2:album==='ep'?.4:.12;if(!charge(l,d,'release',2,cost,log))return;var chance=U.clamp(.08+(l.skill||20)*.003+audience(l)*.15,.1,.55),draw=r(),gross=draw<chance?cost*(1.15+r()*.65):draw<chance+.25?cost*(.65+r()*.35):cost*(.1+r()*.4);var received=pay(l,gross,album==='ep'?'Doanh thu EP / mini album sau phân phối':album?'Doanh thu album lớn sau phân phối':'Doanh thu single sau phân phối');if(draw<chance){fame(l,(album==='ep'?1200:album?2500:500)*(1+audience(l)));log((album==='ep'?'EP / mini album':album?'Album lớn':'Single')+(received>cost?' được người nghe đón nhận, thu về nhỉnh hơn vốn sản xuất. Một lần thành công chưa phải nguồn lời chắc chắn.':' được người nghe đón nhận, nhưng khoản thực nhận sau hao hụt vẫn chưa bù đủ vốn sản xuất.'),received>cost?'good':'neutral');}else{fame(l,album?250:60);log((album==='ep'?'EP / mini album':album?'Album lớn':'Single')+' chưa thu hồi đủ vốn. Bạn vẫn giữ sản phẩm trong hồ sơ nghề nghiệp, nhưng số lượt nghe hiện tại không bù được tiền thu âm, bản quyền và quảng bá.','bad');}}
add('release','Ra single hoặc đầu tư album','Phát hành sản phẩm của mình','Bạn chọn bài, trả tiền phối khí, thu âm và quyền sử dụng nhạc. Đây là khoản đầu tư có thể lỗ; mỗi năm chỉ làm một đợt phát hành, dùng hai phần quỹ thời gian.',[
 option('single','Ra single · vốn nhỏ hơn',.12,function(l,r,log,d){release(l,r,log,d,false);}),option('ep','EP / mini album · một nhóm ca khúc',.4,function(l,r,log,d){release(l,r,log,d,'ep');}),option('album','Album lớn · đầu tư toàn bộ dự án',1.2,function(l,r,log,d){release(l,r,log,d,true);})],2);
add('contest','Đăng ký casting, thi âm nhạc','Tìm cơ hội qua vòng tuyển chọn','Bạn chọn cuộc thi hoặc buổi casting công khai, gửi tiết mục và dành thời gian tập. Được đi tiếp phụ thuộc tay nghề, độ phù hợp và cả may mắn.',[
 option('try','Nộp hồ sơ, thi tuyển minh bạch',.02,function(l,r,log,d){if(!charge(l,d,'contest',1,.02,log))return;if(r()<U.clamp(.08+(l.skill||20)*.004,.1,.48)){fame(l,1000+(l.skill||20)*15);skill(l,2);log('Bạn qua vòng tuyển, được biểu diễn trước khán giả mới và nhận góp ý từ ban chuyên môn. Chưa có tiền thưởng hoặc hợp đồng được bảo đảm.','good');}else{skill(l,1);log('Bạn dừng ở vòng tuyển. Nhận xét của giám khảo giúp bạn biết cần sửa điều gì, nhưng phí chuẩn bị không lấy lại được.','neutral');}})]);
add('collab','Tìm người hợp tác sáng tác, biểu diễn','Gõ cửa một sự hợp tác','Bạn gửi bản thu cho nhạc sĩ và đồng nghiệp, nói rõ cách chia quyền lợi. Người được mời có thể từ chối nếu hai bên chưa hợp phong cách.',[
 option('meet','Làm demo chung, thống nhất quyền lợi',.035,function(l,r,log,d){if(!charge(l,d,'collab',1,.035,log))return;if(r()<.4){fame(l,300+audience(l)*700);skill(l,2);log('Một đồng nghiệp nhận lời cùng làm demo. Hai bên thống nhất phần việc và quyền sử dụng; bạn có thêm kinh nghiệm, chưa phát sinh doanh thu.','good');}else log('Các bên chưa tìm được hướng chung. Bạn dừng ở bản demo, chấp nhận chi phí thử nghiệm thay vì ký một hợp tác vội.','neutral');})]);
// The old random album event shares the same budget and cannot be farmed twice.
var album=E.DEC.album.def;album.prep=snap;album.valid=function(l,d){return valid(l,d)&&available(l,'release',2);};album.text='Bạn có thể ra single hoặc album. Cần có đủ vốn; doanh thu có thể không bù được chi phí. Dự án dùng hai phần quỹ thời gian âm nhạc năm nay.';album.opts=[option('ep','EP / mini album',.4,function(l,r,log,d){release(l,r,log,d,'ep');}),option('go','Đầu tư album lớn',1.2,function(l,r,log,d){release(l,r,log,d,true);}),option('single','Ra single',.12,function(l,r,log,d){release(l,r,log,d,false);}),{k:'later',l:'Chưa phát hành, giữ tiền cho việc khác',run:function(l,r,log,d){if(valid(l,d))d.done=true;}}];
// Fan count uses the existing fame value, shared with titles and career events.
E.showbizFans=function(l){var c=l.job&&E.CAR[job(l)];return !!(real(l)&&c&&(c.cat==='show'||c.cat==='creator'));};
function brandEligible(l){return free(l)&&E.showbizFans(l);}
function brandReady(l,d){return brandEligible(l)&&(!d||d.at==null||!d.done&&d.at===l.age&&d.job===job(l)&&d.base===l.base);}
function deal(l,r,log,d,kind){if(!brandReady(l,d))return;var fee=kind==='pitch'?.012:0;if(l.money<l.base*fee)return;d.done=true;if(fee)H.cash(l,-l.base*fee,'Chuẩn bị hồ sơ hợp tác nhãn hàng');if(kind==='pitch'&&r()>U.clamp(.1+audience(l)*.45,.1,.55)){log('Nhãn hàng chưa chọn hồ sơ của bạn. Họ ưu tiên tệp khách khác; chi phí chuẩn bị và quay thử không được hoàn.','neutral');return;}if(r()<.18){H.fx(l,{hea:-1});log('Chiến dịch bị hoãn trước ngày ký chính thức. Bạn giữ quyền không đăng nội dung, nhưng chưa nhận được cát-xê.','neutral');return;}var earned=.025+audience(l)*.13;pay(l,earned,'Hợp tác nhãn hàng sau chi phí sản xuất');fame(l,120+audience(l)*600);log('Bạn kiểm tra nhãn hàng, ký rõ nội dung, công khai đây là hợp tác quảng cáo rồi hoàn thành đúng thỏa thuận. Khoản thực nhận đã trừ chi phí quay và sản xuất; hợp đồng chỉ có hiệu lực cho chiến dịch này.','good');}
E.SC('brand105_pitch',{title:'Chủ động đề xuất hợp tác nhãn hàng',prep:snap,valid:brandReady,text:'Bạn chọn nhãn hàng hợp với hình ảnh và người hâm mộ, chuẩn bị hồ sơ kênh cùng một ý tưởng quảng cáo. Fan đông giúp có cơ hội, không bảo đảm được chọn hay có tiền ngay.',opts:[option('pitch','Gửi hồ sơ và ý tưởng hợp tác',.012,function(l,r,log,d){deal(l,r,log,d,'pitch');}),{k:'cancel',l:'Chưa gửi hồ sơ',run:function(l,r,log,d){if(brandReady(l,d))d.done=true;}}]});
E.ACT.push({id:'brand105_pitch',g:'Showbiz & người hâm mộ',l:'Chủ động tìm nhãn hàng hợp tác',min:18,sc:'brand105_pitch',avail:function(l){return brandEligible(l)?true:'Không áp dụng';}});
E.SC('brand105_offer',{title:'Nhãn hàng chủ động liên hệ',prep:snap,valid:brandReady,text:'Một nhãn hàng muốn mời bạn tham gia chiến dịch mới vì phù hợp tệp khán giả. Bạn có thể kiểm tra sản phẩm, điều khoản và quyền sử dụng hình ảnh trước khi nhận. Đây chưa phải tiền chắc chắn được trả.',opts:[{k:'review',l:'Tìm hiểu sản phẩm, thương lượng rồi mới nhận',run:function(l,r,log,d){deal(l,r,log,d,'offer');}},{k:'decline',l:'Từ chối vì chưa phù hợp',run:function(l,r,log,d){if(brandReady(l,d)){d.done=true;log('Bạn từ chối lịch sự, giữ hình ảnh và thời gian cho công việc khác.','neutral');}}}]});
E.TRIG.push({id:'brand105_offer',when:function(l){return brandEligible(l)&&(l.fame||0)>=2000;},p:function(l){return Math.min(.25,.025+audience(l)*.2);},cd:2,max:12});
E.SC('show105_ig',{title:'Instagram Live cùng người hâm mộ',prep:snap,valid:function(l,d){return brandReady(l,d)&&!ids.includes(job(l));},text:'Bạn mở Instagram Live để giao lưu, kể về công việc và trả lời câu hỏi của fan. Nội dung và cách tương tác ảnh hưởng lượng người ở lại; đây không phải hợp đồng quảng cáo hay khoản thu được bảo đảm.',opts:[option('live','Chuẩn bị âm thanh, lên lịch và giao lưu',.008,function(l,r,log,d){if(!brandReady(l,d)||ids.includes(job(l))||l.money<l.base*.008)return;d.done=true;H.cash(l,-l.base*.008,'Chuẩn bị Instagram Live');if(r()<.65){var gain=80+audience(l)*900;fame(l,gain);log('Buổi Instagram Live giữ được người xem. Một số khán giả chia sẻ lại nội dung và trở thành fan mới; bạn chưa nhận thêm cát-xê.','good');}else log('Khung giờ chưa phù hợp, ít người ở lại xem. Bạn kết thúc buổi giao lưu, chưa thu hút thêm fan.','neutral');}),{k:'cancel',l:'Hẹn buổi khác',run:function(l,r,log,d){if(brandReady(l,d))d.done=true;}}]});
E.ACT.push({id:'show105_ig',g:'Showbiz & người hâm mộ',l:'Livestream Instagram giao lưu với fan',min:18,sc:'show105_ig',avail:function(l){return brandEligible(l)&&!ids.includes(job(l))?true:'Không áp dụng';}});

// Other jobs also gain explicit training and extra-work choices.
['study','extra'].forEach(function(type){var id='work105_'+type,price=type==='study'?.03:.008;function eligible(l){return free(l)&&!!l.job&&!ids.includes(job(l));}E.SC(id,{title:type==='study'?'Tự đầu tư vào nghề':'Tìm việc thêm ngoài giờ',prep:snap,valid:function(l,d){return eligible(l)&&(!d||d.at==null||!d.done&&d.at===l.age&&d.job===job(l)&&d.base===l.base);},text:type==='study'?'Bạn chọn một khóa ngắn hạn đúng chuyên môn, kiểm tra nội dung rồi mới trả học phí. Học thêm không đồng nghĩa chắc chắn được tăng lương.':'Bạn hỏi mối quen và gửi hồ sơ cho một việc ngắn hạn phù hợp kỹ năng. Có thể không được chọn; nếu nhận việc, bạn phải dành thời gian nghỉ để hoàn thành.',opts:[option('go',type==='study'?'Học chuyên môn và làm bài thực hành':'Gửi hồ sơ, nhận việc phù hợp',price,function(l,r,log,d){if(!eligible(l)||!d||d.done||d.at!==l.age||d.job!==job(l)||d.base!==l.base||l.money<l.base*price)return;d.done=true;H.cash(l,-l.base*price,type==='study'?'Khóa học chuyên môn':'Chuẩn bị hồ sơ việc thêm');if(type==='study'){skill(l,2);H.fx(l,{kno:3});log('Bạn hoàn thành khóa học và bài thực hành. Kiến thức, tay nghề tiến bộ; mức lương hiện tại vẫn phụ thuộc vị trí và cơ hội tuyển dụng.','good');}else if(r()<.35+(l.skill||20)*.002){pay(l,.025+r()*.04,'Tiền việc thêm sau chi phí');H.fx(l,{hea:-3,hap:-1});log('Bạn được nhận việc, hoàn thành đúng hẹn và nhận phần tiền còn lại sau chi phí. Những buổi tối làm thêm khiến bạn thiếu thời gian nghỉ.','good');}else log('Chưa tìm được việc phù hợp. Bạn mất một ít chi phí chuẩn bị, chưa có khoản thu thêm.','neutral');}),{k:'cancel',l:'Chưa làm lúc này',run:function(l,r,log,d){if(d)d.done=true;}}]});E.ACT.push({id:id,g:'Công việc',l:type==='study'?'Học thêm chuyên môn nghề đang làm':'Tìm việc thêm phù hợp kỹ năng',min:18,sc:id,avail:function(l){return eligible(l)?true:'Không áp dụng';}});});
function rate(l,id,gross){var c=E.CAR[id];if(!c)return 0;if(ids.includes(id)){var s=l.flags.music105,active=s&&(s.at===l.age||s.at===l.age-1)&&s.done>0;return active?.38:.58;}if(c.cat==='show'||c.cat==='creator')return .25;if(['biz','free','farm'].includes(c.cat))return .12+Math.min(.13,Math.max(0,gross/l.base-2)*.015);return 0;}
var annual=E.careerYear;E.careerYear=function(l,r,log,focus){var id=job(l),gross=annual.apply(this,arguments);if(!real(l)||!id||!(gross>0)||l.abroad&&l.abroad.study)return gross;var fee=gross*rate(l,id,gross),net=gross-fee;if(fee){l.flags.netEarnings105={at:l.age,gross:gross,cost:fee,net:net};log('Thu nhập nghề nghiệp sau chi phí: '+H.money(l,net)+'/năm; chi phí sản xuất, vận hành và tìm khách '+H.money(l,fee)+'.','money');}return net;};
var estimate=E.monthlyEst;E.monthlyEst=function(l,id,rank){var result=estimate.apply(this,arguments),resolved=E.resolveJob(id);return result*(1-rate(l,resolved,result*12));};
E.MUSIC105={available:available,remaining:function(l){return 5-peek(l).units;},music:music,ids:ids,rate:rate};
})(globalThis.G);

;
/* ===== js/life106.js ===== */
/* Adult postgraduate choices and voluntary civic pathways. */
(function(G){'use strict';var E=G.E,H=E.H,U=G.U;
function free(l){return l&&l.alive&&['vn','world'].includes(l.mode)&&E.FAMILY53.free(l)&&!(l.flags.military&&l.age<l.flags.military)&&!(l.abroad&&l.abroad.study&&!(l.flags.pg106&&l.flags.pg106.abroad&&!l.flags.pg106.done&&l.flags.study107));}
function eligible(l,lv){return free(l)&&l.age>=22&&!l.school&&!l.flags.researchStudy&&l.edu>=lv-1&&l.edu<lv;}
function stamp(l){return {at:l.age,done:false};}
function live(l,d){return d&&!d.done&&d.at===l.age;}
function next(l,id,r,arg){var d=E.DEC[id].make(l,r,arg);d.manual=true;l.pending.push(d);}
var fields={it:'Công nghệ thông tin',eco:'Kinh tế và quản trị',med:'Khoa học sức khỏe',edu:'Giáo dục học',law:'Luật và quản lý công',art:'Nghệ thuật học'};
// Enrollment never silently moves a life; travel is arranged around the simulated schedule.
var schools={it:['Đại học Bách khoa Hà Nội','Trường Đại học Công nghệ, ĐHQG Hà Nội'],eco:['Đại học Kinh tế Quốc dân','Đại học Kinh tế TP. Hồ Chí Minh'],med:['Trường Đại học Y Hà Nội','Đại học Y Dược TP. Hồ Chí Minh'],edu:['Trường Đại học Sư phạm Hà Nội','Trường Đại học Sư phạm TP. Hồ Chí Minh'],law:['Trường Đại học Luật Hà Nội','Trường Đại học Luật TP. Hồ Chí Minh'],art:['Trường Đại học Văn hóa Hà Nội','Trường Đại học Mỹ thuật Việt Nam']};
function schoolName(l,k,i){return H.isVN(l)?schools[k][i]:['Đại học công lập','Đại học nghiên cứu'][i]+' tại '+((G.W.BY[l.abroad?l.abroad.code:l.country]||{}).name||l.country);}
function title(lv){return lv===6?'thạc sĩ':'tiến sĩ';}
[6,7].forEach(function(lv){var id='pg106_'+lv;
 E.SC(id,{title:'Chọn ngành học '+title(lv),prep:stamp,valid:function(l){return eligible(l,lv);},text:'Bạn có thể quay lại giảng đường khi đã đi làm, kể cả sau tuổi 30. Chọn hướng học trước, rồi xem trường, học phí và lịch học. Chưa có khoản tiền nào bị trừ ở bước này.',opts:Object.keys(fields).map(function(k){return {k:k,l:fields[k],run:function(l,r,log,d){if(!eligible(l,lv)||!live(l,d))return;d.done=true;next(l,id+'_school',r,{at:l.age,lv:lv,field:k,done:false});}};}).concat([{k:'cancel',l:'Để lúc khác',run:function(l,r,log,d){if(d)d.done=true;}}])});
 E.SC(id+'_school',{title:'Chọn trường và xác nhận nhập học',valid:function(l,d){return eligible(l,lv)&&live(l,d)&&!!fields[d.field];},text:function(l,d){return 'Ngành '+fields[d.field]+'. Chương trình trong game mô phỏng lịch học theo đợt, ngoài giờ để giữ công việc hiện tại; bạn tự thu xếp việc đi lại. Đây là lựa chọn trong mô phỏng, không phải danh mục tuyển sinh của trường. Học phí toàn khóa trả khi nhập học; sinh hoạt phí vẫn cần tự lo. '+(lv===7?'Nghiên cứu sinh nhận khoản trợ giảng theo cơ chế học bổng của game. ':'')+'Cần bảo vệ thành công mới nhận bằng.';},opts:[0,1].map(function(i){return {k:String(i),l:function(l,d){return schoolName(l,d.field,i);},h:function(l){return (lv===6?2:4)+' năm · học phí toàn khóa '+H.money(l,l.base*(lv===6?[.8,1.2][i]:[1.8,2.6][i]));},req:function(l,d){return eligible(l,lv)&&live(l,d)&&!!fields[d.field]&&l.money>=l.base*(lv===6?[.8,1.2][i]:[1.8,2.6][i]);},run:function(l,r,log,d){if(!eligible(l,lv)||!live(l,d)||!fields[d.field])return;var cost=l.base*(lv===6?[.8,1.2][i]:[1.8,2.6][i]);if(l.money<cost)return;d.done=true;H.cash(l,-cost,'Học phí toàn khóa '+title(lv));l.flags.pg106={lv:lv,field:d.field,name:schoolName(l,d.field,i),started:l.age,end:l.age+(lv===6?2:4),residence:l.abroad?l.abroad.code:l.country,done:false};l.school=lv===6?'post':'phd';l.schoolEnd=l.flags.pg106.end;delete l.flags.postNext;log('Bạn nhập học '+title(lv)+' ngành '+fields[d.field]+' tại '+l.flags.pg106.name+'. Lịch học ngoài giờ giúp bạn giữ công việc; phía trước còn luận văn và buổi bảo vệ.','big');}};}).concat([{k:'cancel',l:'Chưa nhập học, giữ tiền cho việc khác',run:function(l,r,log,d){if(d)d.done=true;}}])});
 E.ACT.push({id:id,g:'Học tập',l:'Chủ động đăng ký học '+title(lv),min:22,sc:id,avail:function(l){return eligible(l,lv)?true:l.school?'Đang theo học một chương trình':l.edu<lv-1?'Cần bằng '+(lv===6?'đại học':'thạc sĩ'):'Chưa phù hợp';}});
});
var grad=E.gradFail;
E.gradFail=function(l,r,log,a){var s=l.flags.pg106;if(s&&!s.done&&l.school===(s.lv===6?'post':'phd')){if(!l.pending.some(function(d){return d.id==='pg106_defense';}))next(l,'pg106_defense',r,{started:s.started,lv:s.lv,done:false});return true;}return grad?grad.apply(this,arguments):false;};
E.SC('pg106_defense',{title:'Buổi bảo vệ sau những năm đi học',valid:function(l,d){var s=l.flags.pg106;return free(l)&&s&&!s.done&&d&&s.started===d.started&&s.lv===d.lv&&l.age+1>=s.end;},text:function(l){var s=l.flags.pg106;return 'Bạn mang công trình '+fields[s.field]+' đến hội đồng của '+s.name+'. Những tháng đọc tài liệu và sửa bản thảo được đặt lên bàn. Nếu chưa đạt, bạn có thể sửa chữa và bảo vệ lại năm sau.';},opts:[{k:'defend',l:'Trình bày nghiên cứu và trả lời phản biện',run:function(l,r,log,d){if(!E.DEC.pg106_defense.valid(l,d)||d.done)return;d.done=true;var s=l.flags.pg106;if(r()<U.clamp(.55+l.st.kno/250,.55,.95)){l.edu=Math.max(l.edu,s.lv);l.school=null;l.schoolEnd=null;s.done=true;s.finished=l.age;(l.flags.postgradDegrees||(l.flags.postgradDegrees=[])).push({level:s.lv,field:s.field,school:s.name,age:l.age});H.fx(l,{hap:5,kno:4});H.mem(l,'Nhận bằng '+title(s.lv)+' tại '+s.name+'.',5);log('Bảo vệ thành công. Bạn nhận bằng '+title(s.lv)+' ngành '+fields[s.field]+' tại '+s.name+'. Công việc và nơi ở vẫn do bạn lựa chọn.','big');}else{s.end=l.age+2;l.schoolEnd=s.end;log('Hội đồng yêu cầu làm rõ phương pháp và sửa bản thảo. Bạn chưa nhận bằng, hẹn bảo vệ lại năm sau.','neutral');}}},{k:'delay',l:'Xin thêm một năm hoàn thiện công trình',run:function(l,r,log,d){if(!E.DEC.pg106_defense.valid(l,d)||d.done)return;d.done=true;l.flags.pg106.end=l.age+2;l.schoolEnd=l.age+2;log('Bạn xin lùi bảo vệ để hoàn thiện công trình thêm một năm.','neutral');}}]});
// A master's defense no longer enrolls a character into a doctorate automatically.
E.DEC.nc_bao_ve.def.opts.forEach(function(o){var run=o.run;o.run=function(l,r,log,d){var count=l.sched.length;run.apply(this,arguments);if(d&&d.lv===6&&l.edu>=6){l.sched=l.sched.filter(function(x,i){return i<count||x.id!=='nc_bao_ve'||!x.arg||x.arg.lv!==7;});log('Bạn có thể chủ động đăng ký tiến sĩ trong mục Học tập khi sẵn sàng.','neutral');}};});
// Keep old invitations useful, but send acceptance through the same subject/school choices.
['post','phd'].forEach(function(id){var D=E.DEC[id],apply=D.apply;D.apply=function(l,d,k,r,log){var lv=id==='post'?6:7;if(k==='yes'&&eligible(l,lv)){next(l,'pg106_'+lv,r);return;}if(k==='yes')return;return apply.apply(this,arguments);};});

function civic(l){return free(l)&&H.isVN(l)&&!l.abroad&&l.age>=16;}
function state(l){return l.flags.civic106||(l.flags.civic106={});}
function peek(l){return l.flags.civic106||{};}
var paths=[
 {id:'youth',name:'Đoàn Thanh niên',min:16,max:30,flag:'doanVien',text:'Bạn đến cơ sở Đoàn tại nơi cư trú, tìm hiểu hoạt động và đăng ký rèn luyện. Bạn dành thời gian cho sinh hoạt, hỗ trợ thanh thiếu niên và việc chung ở khu phố.',qual:function(l){return l.age<=30&&!l.flags.doanVien;},success:function(l,r,log){l.flags.doanVien=true;log('Sau thời gian tham gia hoạt động và được xem xét, bạn được kết nạp Đoàn. Bạn nhận lịch sinh hoạt và nhiệm vụ tại địa phương.','good');}},
 {id:'party',name:'Phấn đấu gia nhập Đảng',min:18,text:'Bạn gửi nguyện vọng tới tổ chức tại nơi làm việc hoặc cư trú. Học lớp bồi dưỡng, tham gia công việc chung và được giới thiệu là các bước đầu; nộp đơn chưa đồng nghĩa được kết nạp.',qual:function(l){return !l.flags.dangVien;},success:function(l,r,log){var s=state(l);if(!s.partyPrep){s.partyPrep=l.age;log('Bạn bắt đầu quá trình bồi dưỡng, rèn luyện và được theo dõi tại cơ sở. Năm sau có thể tiếp tục xin xem xét hồ sơ kết nạp.','neutral');}else if(l.age>s.partyPrep&&r()<.45+l.st.soc/300){l.flags.dangVien=true;log('Sau quá trình rèn luyện và xem xét hồ sơ, bạn được kết nạp Đảng. Tư cách đảng viên không tự động đem lại chức vụ hoặc tăng lương.','big');}else log('Hồ sơ chưa được thông qua. Bạn tiếp tục rèn luyện và hoàn thiện các yêu cầu tại cơ sở.','neutral');}},
 {id:'front',name:'Tham gia hoạt động Mặt trận Tổ quốc',min:18,text:'Bạn đăng ký hỗ trợ các hoạt động tại khu dân cư: lắng nghe kiến nghị, vận động tương trợ và kết nối các gia đình khó khăn. Đây là hoạt động cộng đồng, chưa phải một chức danh lãnh đạo.',qual:function(){return true;},success:function(l,r,log){state(l).front=true;H.fx(l,{soc:2,karma:1});log('Bạn tham gia nhóm hỗ trợ hoạt động Mặt trận tại khu dân cư. Qua những buổi gặp dân và việc thiện nguyện, bạn hiểu thêm những vấn đề của địa phương.','good');}},
 {id:'council',name:'Đăng ký ứng cử Hội đồng nhân dân',min:21,text:'Bạn chuẩn bị hồ sơ, chương trình hành động và tham gia các bước giới thiệu, hiệp thương, tiếp xúc cử tri trong mô phỏng. Kết quả phụ thuộc uy tín và lá phiếu; có thể không trúng cử.',qual:function(l){return !(l.flags.daiBieu&&l.flags.daiBieu.until>l.age);},success:function(l,r,log){if(r()<U.clamp(.15+l.st.soc/250+(l.karma||0)/500,.1,.65)){l.flags.daiBieu={qh:false,at:l.age,until:l.age+5};log('Bạn qua các vòng giới thiệu và trúng cử đại biểu HĐND nhiệm kỳ 5 năm. Bạn giữ công việc hiện tại, dành thêm thời gian tiếp xúc cử tri.','big');}else log('Bạn chưa trúng cử HĐND lần này. Những kiến nghị đã thu thập vẫn được chuyển tới địa phương, nhưng bạn chưa có chức danh đại biểu.','neutral');}},
 {id:'committee',name:'Ứng tuyển công việc tại Ủy ban nhân dân',min:22,text:'Bạn đọc thông báo tuyển dụng, chuẩn bị hồ sơ và ôn thi nghiệp vụ. Nếu trúng tuyển và nhận việc, bạn sẽ rời công việc hiện tại để làm chuyên viên; các vị trí lãnh đạo còn cần quá trình công tác riêng.',qual:function(l){return l.edu>=5&&(!l.job||E.resolveJob(l.job.id)!=='hanh_chinh_cong');},success:function(l,r,log){if(r()<U.clamp(.15+l.st.kno/250,.15,.6)){E.startJob(l,'hanh_chinh_cong',r,log,true);log('Bạn trúng tuyển và nhận công việc chuyên viên UBND. Công việc cũ kết thúc; bạn bắt đầu từ vị trí chuyên viên, chưa giữ chức vụ lãnh đạo.','big');}else log('Bạn chưa qua kỳ tuyển dụng vào UBND. Bạn giữ công việc hiện tại và có thể chuẩn bị lại hồ sơ cho đợt sau.','neutral');}}
];
paths.forEach(function(p){var id='civic106_'+p.id;function ready(l){return civic(l)&&l.age>=p.min&&(!p.max||l.age<=p.max)&&p.qual(l)&&peek(l)[p.id+'At']!==l.age;}
 E.SC(id,{title:p.name,prep:stamp,valid:ready,text:p.text,opts:[{k:'apply',l:p.id==='committee'?'Nộp hồ sơ; nếu trúng tuyển, nhận việc và nghỉ việc cũ':'Đăng ký và dành thời gian tham gia',run:function(l,r,log,d){if(!ready(l)||!live(l,d))return;d.done=true;state(l)[p.id+'At']=l.age;p.success(l,r,log);H.fx(l,{hea:-1});}},{k:'cancel',l:'Chưa tham gia lúc này',run:function(l,r,log,d){if(d)d.done=true;}}]});
 E.ACT.push({id:id,g:'Nhà nước & cộng đồng',l:p.name,min:p.min,max:p.max,sc:id,avail:function(l){return ready(l)?true:p.id==='committee'&&l.edu<5?'Cần bằng đại học':'Chưa phù hợp hoặc đã tham gia năm nay';}});
});
var profile=E.profile;E.profile=function(l){var p=profile.apply(this,arguments),s=l.flags.pg106;(l.flags.postgradDegrees||[]).forEach(function(d){p.edu.push('Bằng '+title(d.level)+' · '+fields[d.field]+' · '+d.school);});if(s&&!s.done)p.edu.push('Đang học '+title(s.lv)+' · '+fields[s.field]+' · '+s.name);if(l.flags.doanVien)p.jobInfo.push('Đoàn viên Thanh niên');if(l.flags.dangVien)p.jobInfo.push('Đảng viên');if(l.flags.civic106&&l.flags.civic106.front)p.jobInfo.push('Tham gia hoạt động Mặt trận tại khu dân cư');return p;};
E.POSTGRAD106={eligible:eligible,fields:fields};
})(globalThis.G);

;
/* ===== js/life107.js ===== */
/* More player-led education, service, technology and adult relationships. */
(function(G){'use strict';var E=G.E,H=E.H,U=G.U;
function free(l){return l&&l.alive&&['vn','world'].includes(l.mode)&&l.age>=18&&E.FAMILY53.free(l)&&!(l.flags.military&&l.age<l.flags.military);}
function jid(l){return l.job&&E.resolveJob(l.job.id);}
function stamp(l){return {at:l.age,job:jid(l),done:false};}
function live(l,d){return free(l)&&d&&!d.done&&d.at===l.age;}
function push(l,id,r,arg){var d=E.DEC[id].make(l,r,arg);d.manual=true;l.pending.push(d);}
function action(id,g,label,valid,arg){E.ACT.push({id:id,g:g,l:label,min:18,sc:id,arg:arg,avail:function(l){return valid(l)?true:'Chưa phù hợp với hoàn cảnh hiện tại';}});}
var fields=E.POSTGRAD106.fields;
// Preserve the aptitude module's admission checks while keeping the selected program visible.
var wishes=E.DEC.study_wishes54,wm=wishes.make,wa=wishes.apply;
wishes.make=function(l){var d=wm.apply(this,arguments),s=E.EDUCATION54.state(l),schools=E.EDUCATION54.schools,u=schools.find(function(x){return x.id===s.selected;});if(u&&!u.nk)d.opts.forEach(function(o){var p=E.EDUCATION54.programs(u).find(function(p){return p.key===o.k;});if(p&&o.k.indexOf('program_')===0)o.h+=' · xét khối '+E.ARTS84.blocksOf(u,p.major).join(', ');});s.wishes.forEach(function(x,i){var u=schools.find(function(u){return u.id===x.school;});if(!u||u.nk||!x.program)return;d.text=d.text.replace(u.name+' · '+E.MAJORS[x.major],u.name+' · '+x.program);var remove=d.opts.find(function(o){return o.k==='remove_'+i;});if(remove)remove.l='Bỏ NV'+(i+1)+': '+u.name+' · '+x.program;});return d;};
wishes.apply=function(l,d,k){var x=wa.apply(this,arguments),s=E.EDUCATION54.state(l),a=s.admitted;if(k==='submit'&&a&&a.age===l.age){var u=E.EDUCATION54.schools.find(function(u){return u.id===a.school;}),w=s.wishes.find(function(w){return w.school===a.school&&w.major===a.major;});if(u&&!u.nk&&w&&w.program){a.program=w.program;l.majorName=w.program;}}return x;};

// A country, institution and subject are selected before any money or residence changes.
var destinations=[
 ['US','Hoa Kỳ','en',['Arizona State University','University of Arizona']],
 ['GB','Vương quốc Anh','en',['University of Manchester','University of Leeds']],
 ['AU','Úc','en',['Monash University','University of Melbourne']],
 ['JP','Nhật Bản','jp',['Osaka University','Tohoku University']],
 ['KR','Hàn Quốc','kr',['Seoul National University','Yonsei University']],
 ['DE','Đức','de',['Technical University of Munich','Heidelberg University']],
 ['FR','Pháp','fr',['Université Paris-Saclay','Université de Strasbourg']],
 ['CA','Canada','en',['University of Alberta','University of Ottawa']]
].filter(function(c){return !!G.W.BY[c[0]];});
function abroadReady(l){return free(l)&&!l.school&&!l.abroad&&!l.flags.researchStudy&&!l.retired&&l.edu>=3&&l.edu<7;}
function lvReady(l,lv){return abroadReady(l)&&(lv===5?l.edu>=3&&l.edu<5:l.edu===lv-1);}
function dest(code){return destinations.filter(function(c){return c[0]===code;})[0];}
E.SC('abroad107',{title:'Tự chọn hành trình du học',prep:stamp,valid:abroadReady,text:'Bạn chọn bậc học, quốc gia, trường rồi ngành. Sau đó mới nộp hồ sơ học bổng hoặc tự túc. Nếu nhập học, công việc hiện tại kết thúc và nơi ở chuyển sang nước đến.',opts:[5,6,7].map(function(lv){return {k:String(lv),l:lv===5?'Đại học':lv===6?'Thạc sĩ':'Tiến sĩ',req:function(l){return lvReady(l,lv);},run:function(l,r,log,d){if(!live(l,d)||!lvReady(l,lv))return;d.done=true;push(l,'abroad107_country',r,{at:l.age,lv:lv,done:false});}};}).concat([{k:'cancel',l:'Chưa đi du học',run:function(l,r,log,d){if(d)d.done=true;}}])});
E.SC('abroad107_country',{title:'Chọn quốc gia du học',valid:function(l,d){return live(l,d)&&lvReady(l,d.lv);},text:'Chọn nơi muốn học. Các ngành và chi phí trong game là mô phỏng; hồ sơ vẫn có thể trượt.',opts:destinations.map(function(c){return {k:c[0],l:c[1],run:function(l,r,log,d){if(!E.DEC.abroad107_country.valid(l,d))return;d.done=true;push(l,'abroad107_school',r,{at:l.age,lv:d.lv,country:c[0],done:false});}};}).concat([{k:'cancel',l:'Dừng chuẩn bị hồ sơ',run:function(l,r,log,d){if(d)d.done=true;}}])});
E.SC('abroad107_school',{title:'Chọn trường du học',valid:function(l,d){return live(l,d)&&lvReady(l,d.lv)&&!!dest(d.country);},text:'Bạn tìm hiểu môi trường học và chuẩn bị hồ sơ cho trường mình chọn.',opts:[0,1].map(function(i){return {k:String(i),l:function(l,d){return dest(d.country)[3][i];},run:function(l,r,log,d){if(!E.DEC.abroad107_school.valid(l,d))return;d.done=true;push(l,'abroad107_field',r,{at:l.age,lv:d.lv,country:d.country,school:i,done:false});}};}).concat([{k:'cancel',l:'Chưa chọn trường',run:function(l,r,log,d){if(d)d.done=true;}}])});
E.SC('abroad107_field',{title:'Chọn ngành du học',valid:function(l,d){return live(l,d)&&lvReady(l,d.lv)&&!!dest(d.country)&&[0,1].includes(d.school);},text:'Bạn chọn hướng học và viết kế hoạch phù hợp với hồ sơ của mình.',opts:Object.keys(fields).filter(function(k){return k!=='med';}).map(function(k){return {k:k,l:fields[k],run:function(l,r,log,d){if(!E.DEC.abroad107_field.valid(l,d))return;d.done=true;push(l,'abroad107_apply',r,{at:l.age,lv:d.lv,country:d.country,school:d.school,field:k,done:false});}};}).concat([{k:'cancel',l:'Dừng hồ sơ',run:function(l,r,log,d){if(d)d.done=true;}}])});
function application(l,d){return live(l,d)&&lvReady(l,d.lv)&&!!dest(d.country)&&[0,1].includes(d.school)&&!!fields[d.field]&&d.field!=='med';}
function tuition(l,d){return l.base*(d.lv===6?2:4);}
function admission(l,r,log,d,scholar){if(!application(l,d)||l.money<(scholar?l.base*.02:tuition(l,d)))return;d.done=true;H.cash(l,-(scholar?l.base*.02:tuition(l,d)),scholar?'Chuẩn bị hồ sơ học bổng':'Dự trù học phí du học toàn khóa');if(r()>U.clamp((scholar?.12:.5)+l.st.kno/250,.15,scholar?.65:.9)){log('Hồ sơ vào '+dest(d.country)[3][d.school]+' chưa được chấp nhận. Bạn giữ công việc và nơi ở hiện tại. '+(scholar?'Chi phí chuẩn bị hồ sơ không được hoàn.':'Khoản học phí dự trù được trả lại.'),'neutral');if(!scholar)H.cash(l,tuition(l,d),'Hoàn học phí chưa nhập học');return;}
 var c=dest(d.country),host=G.W.BY[c[0]],old=G.W.BY[l.country],home={place:l.place,city:l.city,urban:l.urban,cur:l.cur,base:l.base},duration=d.lv===6?2:4;
 l.flags.study107={at:l.age,lv:d.lv,country:c[0],school:c[3][d.school],field:d.field,home:home,finished:false,scholar:scholar};
 if(l.job){var history=l.jobsHist||[];if(history.length&&history[history.length-1].to==null)history[history.length-1].to=l.age;}l.job=null;l.income=0;l.fin=null;l.flags.needJob=false;delete l.flags.postNext;
 E.abroadConvert(l,l.cur==='vnd'?1e6/G.CUR.VND/G.CUR.priceLevel(host.gdp):G.CUR.priceLevel(old.gdp)/G.CUR.priceLevel(host.gdp));l.cur='usd';l.abroad={code:c[0],name:c[1],pool:c[2],study:true,until:l.age+duration,base:host.gdp*1000*.4};l.place=host.cities[0];l.city=l.place;l.urban=true;H.setBase(l);if(d.lv===5){l.uniName=c[3][d.school];l.uniCity=l.place;}l.flags.studiedAbroad=c[1];
 if(d.lv===5){l.major=d.field;l.majorName=fields[d.field];l.school='abroad';}else{l.school=d.lv===6?'post':'phd';l.flags.pg106={lv:d.lv,field:d.field,name:c[3][d.school],started:l.age,end:l.age+duration,residence:c[0],abroad:true,done:false};}l.schoolEnd=l.age+duration;
 log('Bạn nhập học '+c[3][d.school]+' ngành '+fields[d.field]+' tại '+c[1]+'. Công việc cũ kết thúc; từ nay nơi ở, chi phí và tiền tệ tính theo nước du học.','big');}
E.SC('abroad107_apply',{title:'Nộp hồ sơ du học',valid:application,text:function(l,d){return dest(d.country)[3][d.school]+' · '+fields[d.field]+' · '+(d.lv===6?2:4)+' năm. Tự túc dự trù học phí toàn khóa '+H.money(l,tuition(l,d))+'; chi phí sinh hoạt trả hằng năm tại nước đến. Hồ sơ học bổng tốn '+H.money(l,l.base*.02)+', không bảo đảm được chọn. Nhập học đồng nghĩa rời công việc hiện tại.';},opts:[{k:'scholar',l:'Nộp hồ sơ học bổng',req:function(l){return l.money>=l.base*.02;},run:function(l,r,log,d){admission(l,r,log,d,true);}},{k:'self',l:'Nộp hồ sơ tự túc',req:function(l,d){return l.money>=tuition(l,d);},run:function(l,r,log,d){admission(l,r,log,d,false);}},{k:'cancel',l:'Chưa nộp hồ sơ',run:function(l,r,log,d){if(d)d.done=true;}}]});
action('abroad107','Học tập','Tự chọn quốc gia, trường và ngành du học',abroadReady);
// The original school-leaving choice now also opens the country picker.
var oldStudy=E.DEC.du_hoc.make;E.DEC.du_hoc.make=function(l,r){if(!abroadReady(l))return oldStudy.apply(this,arguments);var d=E.DEC.abroad107.make(l,r);d.id='du_hoc';d.data.picker107=true;return d;};
var oldStudyApply=E.DEC.du_hoc.apply;E.DEC.du_hoc.apply=function(l,d){return d.data&&d.data.picker107?E.DEC.abroad107.apply.apply(E.DEC.abroad107,arguments):oldStudyApply.apply(this,arguments);};
var oldStudyAuto=E.DEC.du_hoc.auto;E.DEC.du_hoc.auto=function(l,d,r){return d.data&&d.data.picker107?E.DEC.abroad107.auto(l,d,r):oldStudyAuto.apply(this,arguments);};
function finishAbroad(l){var s=l.flags.study107;return free(l)&&s&&!s.finished&&l.edu>=s.lv&&l.abroad&&l.abroad.code===s.country;}
E.SC('abroad107_finish',{title:'Sau những năm du học',valid:finishAbroad,text:'Bạn đã hoàn thành chương trình. Bạn muốn trở về hay ở lại tìm việc? Công việc mới phải tìm từ đầu, không tự khôi phục lương cũ.',opts:[{k:'home',l:'Trở về nơi từng sống',run:function(l,r,log){if(!finishAbroad(l))return;var s=l.flags.study107,h=s.home,c=G.W.BY[s.country];E.abroadConvert(l,h.cur==='vnd'?G.CUR.priceLevel(c.gdp)*G.CUR.VND/1e6:G.CUR.priceLevel(c.gdp)/G.CUR.priceLevel(G.W.BY[l.country].gdp));l.cur=h.cur;l.abroad=null;l.place=h.place;l.city=h.city;l.urban=h.urban;H.setBase(l);s.finished=true;l.job=null;l.income=0;l.flags.needJob=true;log('Bạn trở về với tấm bằng từ '+s.school+', bắt đầu tìm công việc phù hợp.','big');}},{k:'stay',l:'Ở lại tìm việc',run:function(l,r,log){if(!finishAbroad(l))return;l.flags.study107.finished=true;l.abroad.study=false;l.abroad.perm=true;delete l.abroad.until;l.job=null;l.income=0;l.flags.needJob=true;log('Bạn ở lại tìm việc sau tốt nghiệp, giữ nơi ở tại '+l.abroad.name+'.','big');}}]});
E.HOOKS.year.push(function(l,r,log){if(finishAbroad(l)&&!l.pending.some(function(d){return d.id==='abroad107_finish';})){l.sched=l.sched.filter(function(x){return x.id!=='du_hoc_ve';});l.pending=l.pending.filter(function(x){return x.id!=='du_hoc_ve';});push(l,'abroad107_finish',r);}});
var defend=E.DEC.pg106_defense.apply;E.DEC.pg106_defense.apply=function(l,d,k,r,log){defend.apply(this,arguments);if(finishAbroad(l)&&!l.pending.some(function(x){return x.id==='abroad107_finish';}))push(l,'abroad107_finish',r);};

// Merit supports an earlier review, without converting a parade into an automatic rank.
function uniform(l){return free(l)&&!l.retired&&['quan_doi','cong_an'].includes(jid(l));}
function service(l){return l.flags.service107||(l.flags.service107={merit:0,used:{}});}
function servicePeek(l){return l.flags.service107||{merit:0,used:{}};}
['parade','rescue','campaign'].forEach(function(type){var id='service107_'+type,labels={parade:'Tình nguyện đội hình diễu binh, diễu hành',rescue:'Tham gia nhiệm vụ cứu hộ',campaign:'Xung phong nhiệm vụ trong chiến dịch lớn'};function ready(l){return uniform(l)&&servicePeek(l).missionAt!==l.age;}
 E.SC(id,{title:labels[type],prep:stamp,valid:ready,text:type==='parade'?'Đơn vị tuyển người tập luyện cho lễ diễu binh, diễu hành. Nhiều tuần rèn đội hình đòi hỏi sức khỏe và kỷ luật; hoàn thành tốt được ghi nhận thành tích, không tự động tăng quân hàm.':'Đơn vị nhận nhiệm vụ dài ngày. Bạn có thể tình nguyện nhận phần việc khó, phối hợp cùng đồng đội. Có áp lực, nguy cơ chấn thương và khả năng không đạt kết quả mong đợi.',opts:[{k:'go',l:'Nhận nhiệm vụ và chuẩn bị kỹ',run:function(l,r,log,d){if(!ready(l)||!live(l,d)||d.job!==jid(l))return;d.done=true;var s=service(l);s.missionAt=l.age;H.fx(l,{hea:type==='parade'?-2:-5,kno:1});if(r()<U.clamp(.45+l.st.hea/250,.4,.85)){s.merit=Math.min(12,s.merit+(type==='parade'?1:2));log('Bạn hoàn thành tốt nhiệm vụ, được ghi nhận '+(type==='parade'?1:2)+' điểm thành tích. Có thể dùng hồ sơ để xin xét thăng hàm trước hạn.','good');}else{H.fx(l,{hea:-3});log('Nhiệm vụ gặp trở ngại. Bạn trở về đơn vị, chưa được đề nghị khen thưởng trong đợt này.','neutral');}}},{k:'cancel',l:'Tiếp tục nhiệm vụ thường xuyên',run:function(l,r,log,d){if(d)d.done=true;}}]});action(id,'Quân đội & công an',labels[type],ready);
 E.TRIG.push({id:id,when:ready,p:type==='parade'?.06:.1,cd:3,max:8});
});
var canAdvance=E.canAdvance;
function review(l){if(!uniform(l))return false;var s=servicePeek(l),j=l.job,c=E.CAR[jid(l)],since=j.rankSince==null?l.age-(j.yrs||0):j.rankSince;if(s.merit<3||s.reviewAt===l.age||j.rank>=c.t.length-1||l.age-since<2)return false;var old=j.rankSince,tracked=j.rankTracked;try{j.rankSince=since-Math.min(2,Math.floor(s.merit/3));j.rankTracked=j.rank;return canAdvance(l,c,false);}finally{j.rankSince=old;j.rankTracked=tracked;}}
E.SC('service107_review',{title:'Xin xét thăng hàm trước hạn',prep:stamp,valid:review,text:'Bạn nộp hồ sơ thành tích để xin xét trước hạn. Cần ít nhất hai năm ở cấp hàm hiện tại, đủ đào tạo và chức vụ. Ba điểm thành tích dùng cho một lần xét, kể cả khi chưa được duyệt.',opts:[{k:'review',l:'Nộp hồ sơ thành tích',run:function(l,r,log,d){if(!live(l,d)||d.job!==jid(l)||!review(l))return;d.done=true;var s=service(l);s.merit-=3;s.reviewAt=l.age;if(r()<.65){var j=l.job;j.rank++;j.yrs=0;j.rankSince=l.age;j.rankTracked=j.rank;log('Hồ sơ được duyệt. Bạn được thăng lên '+E.CAR[jid(l)].t[j.rank]+' trước hạn nhờ thành tích nhiệm vụ.','big');}else log('Đợt xét chưa được duyệt vì chưa có vị trí hoặc chỉ tiêu phù hợp. Bạn tiếp tục công tác ở cấp hàm hiện tại.','neutral');}},{k:'cancel',l:'Tích lũy thêm thành tích',run:function(l,r,log,d){if(d)d.done=true;}}]});action('service107_review','Quân đội & công an','Xin xét thăng quân hàm trước hạn',review);
['hv_nang_cao','hv_quoc_phong','bo_nhiem_chien_luoc'].forEach(function(id){var label={hv_nang_cao:'Đăng ký học viện nâng cao',hv_quoc_phong:'Xin học chương trình cán bộ cấp cao',bo_nhiem_chien_luoc:'Đề nghị xét nhiệm vụ cấp chiến lược'}[id];action(id,'Quân đội & công an',label,function(l){return uniform(l)&&E.DEC[id].valid(l,{});});});
var posts={quan_doi:[['Trợ lý chính ủy',2],['Phó trung đoàn trưởng',4],['Trung đoàn trưởng',5],['Sư đoàn phó',6],['Sư đoàn trưởng',7],['Phó tư lệnh quân khu',8],['Tư lệnh quân khu',9],['Chủ nhiệm Tổng cục Chính trị',10],['Bộ trưởng Bộ Quốc phòng',10]],cong_an:[['Đội trưởng nghiệp vụ',2],['Phó trưởng phòng',4],['Trưởng phòng',5],['Phó giám đốc công an tỉnh',6],['Giám đốc công an tỉnh',7],['Phó cục trưởng',8],['Cục trưởng',9],['Thứ trưởng Bộ Công an',10],['Bộ trưởng Bộ Công an',10]]};
E.SC('service107_post',{title:'Đăng ký hướng phát triển chức vụ',prep:stamp,valid:uniform,text:'Bạn trình bày nguyện vọng và tham gia đợt xét bố trí nhân sự trong game. Chức vụ và quân hàm là hai thông tin riêng; có đủ điều kiện vẫn có thể chưa được bổ nhiệm.',opts:Array.from({length:posts.quan_doi.length},function(_,i){return {k:String(i),l:function(l){return posts[jid(l)][i][0];},req:function(l){var p=posts[jid(l)][i];return l.job.rank>=p[1]&&(p[1]<8||l.flags.topAcad>0)&&(!l.flags.service107||l.flags.service107.postAt!==l.age);},run:function(l,r,log,d){if(!uniform(l)||!live(l,d)||d.job!==jid(l))return;var p=posts[jid(l)][i],s=service(l);if(l.job.rank<p[1]||p[1]>=8&&!(l.flags.topAcad>0)||s.postAt===l.age)return;d.done=true;s.postAt=l.age;if(r()<.4+Math.min(.25,s.merit*.03)){s.post={name:p[0],rank:p[1],track:jid(l),at:l.age};if(p[1]>=8)l.flags.strategicPost=jid(l);log('Bạn được giao chức vụ '+p[0]+'. Quân hàm vẫn được xét theo hồ sơ và thời gian công tác riêng.','big');}else log('Nguyện vọng được ghi nhận, nhưng đợt này chưa có vị trí phù hợp. Bạn tiếp tục chức vụ hiện tại.','neutral');}};}).concat([{k:'cancel',l:'Tiếp tục công tác tại vị trí hiện tại',run:function(l,r,log,d){if(d)d.done=true;}}])});action('service107_post','Quân đội & công an','Đăng ký hướng phát triển chức vụ',uniform);
var jobTitle=E.jobTitle;E.jobTitle=function(l){var t=jobTitle.apply(this,arguments),p=servicePeek(l).post;return t&&p&&p.track===jid(l)?t+' · '+p.name:t;};

// Opt-in annual upgrades respect a shared budget and a living-cost reserve.
var kinds=[['ios','iPhone'],['samsung','Samsung'],['pixel','Google Pixel'],['lt_vp','Laptop văn phòng / MacBook'],['lt_gaming','Laptop gaming'],['pc','PC']];
function techSlot(k){return k==='pc'?'pc':/^lt_/.test(k)?'laptop':'phone';}
E.SC('tech107',{title:'Tự động lên đời đồ công nghệ',prep:stamp,valid:free,text:function(l){var s=l.flags.autoTech107||{kinds:{},budget:.25};return 'Đang bật: '+(Object.keys(s.kinds).filter(function(k){return s.kinds[k];}).join(', ')||'chưa có')+'. Tổng ngân sách tối đa '+Math.round(s.budget*100)+'% thu nhập cơ bản/năm; luôn giữ lại ít nhất nửa năm chi phí cơ bản. Thiếu tiền sẽ bỏ qua, không vay để mua máy.';},opts:kinds.map(function(x){return {k:x[0],l:'Bật/tắt tự lên đời '+x[1],run:function(l,r,log,d){if(!live(l,d))return;d.done=true;var s=l.flags.autoTech107||(l.flags.autoTech107={kinds:{},budget:.25});s.kinds[x[0]]=!s.kinds[x[0]];if(s.kinds[x[0]])kinds.forEach(function(y){if(y[0]!==x[0]&&techSlot(y[0])===techSlot(x[0]))s.kinds[y[0]]=false;});log((s.kinds[x[0]]?'Bật':'Tắt')+' tự lên đời '+x[1]+' hằng năm.','neutral');push(l,'tech107',r);}};}).concat([.1,.25,.5,1].map(function(b){return {k:'budget'+b,l:'Giới hạn '+Math.round(b*100)+'% ngân sách cơ bản/năm',run:function(l,r,log,d){if(!live(l,d))return;d.done=true;var s=l.flags.autoTech107||(l.flags.autoTech107={kinds:{},budget:.25});s.budget=b;push(l,'tech107',r);}};})).concat([{k:'limits',l:'Đặt hạn mức cho từng loại máy',run:function(l,r,log,d){if(!live(l,d))return;d.done=true;push(l,'tech107_limit',r);}}]).concat([{k:'off',l:'Tắt toàn bộ tự mua',run:function(l,r,log,d){if(!live(l,d))return;d.done=true;l.flags.autoTech107={kinds:{},budget:.25};log('Đã tắt tự động mua đồ công nghệ.','neutral');}},{k:'done',l:'Lưu và đóng',run:function(l,r,log,d){if(d)d.done=true;}}])});action('tech107','Giải trí','Cài đặt tự lên đời điện thoại, laptop, PC',free);
E.SC('tech107_limit',{title:'Hạn mức cho từng loại máy',prep:stamp,valid:free,text:'Mỗi lần mua phải thỏa cả hạn mức riêng của loại máy và tổng ngân sách năm. Máy quá giá hoặc làm thiếu tiền sinh hoạt sẽ được bỏ qua.',opts:kinds.map(function(x){return {k:x[0],l:x[1],h:function(l){var s=l.flags.autoTech107||{budget:.25};return 'Hạn mức hiện tại: '+H.money(l,l.base*(s.limits&&s.limits[x[0]]!=null?s.limits[x[0]]:s.budget));},run:function(l,r,log,d){if(!live(l,d))return;d.done=true;push(l,'tech107_limit_value',r,{at:l.age,kind:x[0],done:false});}};}).concat([{k:'back',l:'Quay lại cài đặt chung',run:function(l,r,log,d){if(!live(l,d))return;d.done=true;push(l,'tech107',r);}}])});
E.SC('tech107_limit_value',{title:'Chọn hạn mức một lần mua',valid:function(l,d){return free(l)&&live(l,d)&&kinds.some(function(x){return x[0]===d.kind;});},text:function(l,d){return 'Hạn mức cho '+kinds.find(function(x){return x[0]===d.kind;})[1]+', tính theo thu nhập cơ bản năm. Tổng ngân sách năm vẫn được giữ.';},opts:[.05,.1,.25,.5,1].map(function(b){return {k:String(b),l:Math.round(b*100)+'% thu nhập cơ bản năm',h:function(l){return H.money(l,l.base*b);},run:function(l,r,log,d){if(!E.DEC.tech107_limit_value.valid(l,d))return;d.done=true;var s=l.flags.autoTech107||(l.flags.autoTech107={kinds:{},budget:.25});(s.limits||(s.limits={}))[d.kind]=b;push(l,'tech107',r);}};}).concat([{k:'back',l:'Chưa đổi hạn mức',run:function(l,r,log,d){if(!E.DEC.tech107_limit_value.valid(l,d))return;d.done=true;push(l,'tech107',r);}}])});
function autoTech(l,r,log){var s=l.flags.autoTech107;if(!free(l)||!l.indep||!s||s.lastAt===l.age)return;s.lastAt=l.age;var budget=Math.max(0,l.base*s.budget),used=0;
 kinds.forEach(function(x){if(!s.kinds[x[0]])return;var list=E.techLineup(l,x[0]),year=l.birthYear+l.age,slot=techSlot(x[0]),old=(l.flags.tech||{})[slot];if(old&&old.y>=year)return;var candidates=list.filter(function(m){var cost=H.isVN(l)&&l.cur==='vnd'&&!(l.abroad&&l.abroad.perm)?m.c:m.c/90*l.base;return cost<=budget-used&&cost<=l.base*(s.limits&&s.limits[x[0]]!=null?s.limits[x[0]]:s.budget)&&cost<=l.money-l.base*.5&&(!old||old.n!==m.n);});if(!candidates.length){log('Tự lên đời '+x[1]+': giữ máy cũ vì chưa có mẫu phù hợp ngân sách hoặc cần giữ tiền sinh hoạt.','neutral');return;}var m=candidates[0],i=list.indexOf(m),cash=l.money;E.DEC.cn_mau.def.opts[i].run(l,r,log,{kind:x[0],y:year});used+=Math.max(0,cash-l.money);});
}E.HOOKS.year.push(autoTech);

function showbiz(l){return free(l)&&!l.retired&&E.showbizFans(l);}
E.SC('mentor107',{title:'Nâng đỡ một nghệ sĩ đàn em',prep:function(l,r){return Object.assign(stamp(l),{name:H.stranger(l,r,H.partnerSex(l,r))});},valid:function(l){return showbiz(l)&&l.job.rank>=1&&(!l.flags.mentor107||l.flags.mentor107.at!==l.age);},text:function(l,d){return 'Một nghệ sĩ trẻ đã trưởng thành tên '+((l.flags.mentor107||{}).name||d.name)+' xin bạn góp ý và giới thiệu cơ hội làm nghề. Bạn có thể giúp chuyên môn hoặc làm sản phẩm chung, không bảo đảm người ấy sẽ nổi tiếng.';},opts:[{k:'teach',l:'Hướng dẫn và giới thiệu buổi thử vai / thử giọng',req:function(l){return l.money>=l.base*.02;},run:function(l,r,log,d){mentor(l,r,log,d,false);}},{k:'project',l:'Đầu tư sản phẩm chung với đàn em',req:function(l){return l.money>=l.base*.12;},run:function(l,r,log,d){mentor(l,r,log,d,true);}},{k:'cancel',l:'Chưa đủ thời gian, hẹn dịp khác',run:function(l,r,log,d){if(d)d.done=true;}}]});
function mentor(l,r,log,d,project){if(!live(l,d)||d.job!==jid(l)||!E.DEC.mentor107.valid(l)||l.money<l.base*(project?.12:.02))return;d.done=true;H.cash(l,-l.base*(project?.12:.02),'Hỗ trợ nghệ sĩ đàn em');var s=l.flags.mentor107||(l.flags.mentor107={name:d.name,progress:0});s.at=l.age;s.progress++;H.fx(l,{soc:1});if(r()<.55){l.fame=Math.max(0,l.fame||0)+(project?800:150);log(s.name+' tiến bộ và có cơ hội làm nghề mới. Bạn được nhắc đến như người hỗ trợ; cả hai vẫn cần chứng minh mình bằng sản phẩm.','good');}else log('Dự án của '+s.name+' chưa được chú ý. Bạn cùng đàn em xem lại cách làm; khoản hỗ trợ không tạo ra lợi nhuận.','neutral');}action('mentor107','Showbiz & người hâm mộ','Nâng đỡ đàn em',function(l){return E.DEC.mentor107.valid(l);});

function marriage(l){var p=l.partner;return free(l)&&p&&p.alive!==false&&p.status==='married';}
function marriageKey(l){var p=l.partner;return p&&(p.nameBeforeCustomization||p.name)+'|'+p.since;}
function affairReady(l){return marriage(l)&&!l.flags.affair107;}
E.SC('affair107',{title:'Một mối quan hệ ngoài hôn nhân',prep:function(l,r){return Object.assign(stamp(l),{spouse:marriageKey(l),name:H.stranger(l,r,H.partnerSex(l,r))});},valid:affairReady,text:'Bạn biết mình đang bước qua ranh giới của hôn nhân. Giữ bí mật có thể dẫn đến mất niềm tin, tai tiếng, ly hôn và tranh chấp tài sản.',opts:[{k:'start',l:'Vẫn bắt đầu mối quan hệ vụng trộm',run:function(l,r,log,d){if(!live(l,d)||!affairReady(l)||d.spouse!==marriageKey(l))return;d.done=true;l.flags.affair107={name:d.name,spouse:d.spouse,at:l.age};H.fx(l,{karma:-12,hap:2});H.sched(l,'affair107_confront',1,{spouse:d.spouse});log('Bạn bắt đầu mối quan hệ với '+d.name+' ngoài hôn nhân. Những lời nói dối khiến khoảng cách với người bạn đời lớn dần.','bad');}},{k:'cancel',l:'Dừng lại, giữ ranh giới với người kia',run:function(l,r,log,d){if(d)d.done=true;}}]});action('affair107','Tình cảm & gia đình','Ngoại tình: bắt đầu quan hệ ngoài hôn nhân',affairReady);
E.SC('affair107_confront',{title:'Người bạn đời phát hiện sự thật',valid:function(l,d){return marriage(l)&&l.flags.affair107&&d&&d.spouse===marriageKey(l);},text:'Những tin nhắn không còn giấu được. Người bạn đời muốn nghe sự thật và cần bạn quyết định; nếu chia tay, hai người còn phải giải quyết tài sản và việc nuôi con.',opts:[{k:'repair',l:'Chấm dứt quan hệ bên ngoài, xin cùng hàn gắn',run:function(l,r,log,d){if(!E.DEC.affair107_confront.valid(l,d)||d.done)return;d.done=true;if(E.RELATIONS108)E.RELATIONS108.endAffair(l);delete l.flags.affair107;H.fx(l,{hap:-8});if(r()<.5){log('Người bạn đời đồng ý thử hàn gắn. Niềm tin chưa trở lại ngay; hai người dành thời gian cho tư vấn và gia đình.','neutral');H.cash(l,-Math.min(Math.max(0,l.money),l.base*.02),'Tư vấn hôn nhân');}else{log('Người bạn đời không còn muốn tiếp tục cuộc hôn nhân.','bad');E.DEC.divorce.apply(l,E.DEC.divorce.make(l,r),'div',r,log);}}},{k:'divorce',l:'Chấp nhận ly hôn và giải quyết trách nhiệm',run:function(l,r,log,d){if(!E.DEC.affair107_confront.valid(l,d)||d.done)return;d.done=true;delete l.flags.affair107;if(showbiz(l))l.fame=Math.max(0,(l.fame||0)*.85);E.DEC.divorce.apply(l,E.DEC.divorce.make(l,r),'div',r,log);}}]});
function queueSettlement(l,p,before,r){if(!p||p.status!=='married'||l.partner)return;var key=(p.nameBeforeCustomization||p.name)+'|'+p.since;if((l.flags.settled107||[]).includes(key)||l.pending.some(function(d){return d.id==='settlement107'&&d.data.key===key;}))return;delete l.flags.affair107;push(l,'settlement107',r,{key:key,name:p.name,before:Math.max(0,before),lost:Math.max(0,before-l.money),done:false});}
var divorce=E.DEC.divorce.apply;E.DEC.divorce.apply=function(l,d,k,r,log){var p=l.partner,cash=l.money;var x=divorce.apply(this,arguments);queueSettlement(l,p,cash,r);return x;};
var endPartner=H.endPartner;H.endPartner=function(l,log,how){var p=l.partner,cash=l.money;var x=endPartner.apply(this,arguments);if(how==='div')queueSettlement(l,p,cash,H.rf(l));return x;};
E.SC('settlement107',{title:'Sau ly hôn: tài sản và thỏa thuận',valid:function(l,d){return free(l)&&d&&!d.done&&typeof d.key==='string'&&d.key.length>0&&typeof d.name==='string'&&d.name.length>0&&Number.isFinite(d.before)&&d.before>=0&&Number.isFinite(d.lost)&&d.lost>=0&&d.lost<=d.before&&!(l.flags.settled107||[]).includes(d.key);},text:function(l,d){return 'Cuộc hôn nhân với '+d.name+' đã kết thúc. Phần tiền và nhà đã được chia theo cơ chế ly hôn của game. Bạn có thể chấp nhận thỏa thuận hoặc chịu thêm chi phí để yêu cầu rà soát khoản tiền tranh chấp. Quyền nuôi con được giải quyết riêng.';},opts:[{k:'agree',l:'Chấp nhận thỏa thuận, khép lại tranh chấp',run:function(l,r,log,d){settle(l,r,log,d,false);}},{k:'dispute',l:'Nhờ hòa giải và rà soát tài sản tranh chấp',h:function(l){return 'Phí '+H.money(l,l.base*.03)+'; có thể không thu hồi được thêm';},req:function(l){return l.money>=l.base*.03;},run:function(l,r,log,d){settle(l,r,log,d,true);}}]});
function settle(l,r,log,d,dispute){if(!E.DEC.settlement107.valid(l,d)||dispute&&l.money<l.base*.03)return;d.done=true;(l.flags.settled107||(l.flags.settled107=[])).push(d.key);if(dispute){H.cash(l,-l.base*.03,'Hòa giải và rà soát tranh chấp tài sản');if(r()<.45){var recovered=Math.min(d.lost*.25,d.before*.1);H.cash(l,recovered,'Điều chỉnh khoản tiền sau hòa giải');log('Sau khi đối chiếu chứng từ, hai người thống nhất trả lại cho bạn '+H.money(l,recovered)+'. Hồ sơ tranh chấp được khép lại.','neutral');}else log('Việc rà soát chưa làm thay đổi phần chia tài sản. Bạn chịu chi phí và chấp nhận khép lại hồ sơ.','neutral');}else log('Hai người chấp nhận phần tài sản đã chia, thống nhất không kéo dài tranh chấp.','neutral');if((l.kids||[]).some(function(k){return k.alive&&l.age-k.born<18;})&&!l.pending.some(function(x){return x.id==='quyen_nuoi_con';})){l.flags.divEx=d.name;push(l,'quyen_nuoi_con',r);}}
// The initial custody decision belongs to one divorce, even when both yearly history and settlement queue it.
var custodyValid=E.DEC.quyen_nuoi_con.valid,custodyApply=E.DEC.quyen_nuoi_con.apply;
function custodyKey(l){return l.flags.divEx+'|'+(l.exes||0);}
E.DEC.quyen_nuoi_con.valid=function(l,d){return custodyValid(l,d)&&l.flags.custodyDecision107!==custodyKey(l);};
E.DEC.quyen_nuoi_con.apply=function(l,d,k,r,log){if(!E.DEC.quyen_nuoi_con.valid(l,d.data)||!['nuoi','ex','chung'].includes(k))return;var key=custodyKey(l),out=custodyApply.apply(this,arguments);l.flags.custodyDecision107=key;return out;};
E.EXPANSION107={abroadReady:abroadReady,destinations:destinations,review:review,autoTech:autoTech,uniform:uniform};
})(globalThis.G);

;
/* ===== js/life108.js ===== */
/* Adult relationships, family planning and stable co-parent records. */
(function(G){'use strict';var E=G.E,H=E.H,U=G.U;
function free(l){return l&&l.alive&&['vn','world'].includes(l.mode)&&l.age>=18&&E.FAMILY53.free(l);}
function person(l,p){if(!p)return null;if(!p.relation108)p.relation108='r'+(l.flags.relationSerial108=(l.flags.relationSerial108||0)+1);return p.relation108;}
function bond(l,p){person(l,p);if(p.affection108==null)p.affection108=Math.min(85,35+Math.max(0,l.age-(p.since==null?l.age:p.since))*10);return p.affection108;}
function snapshot(l,p){person(l,p);return JSON.parse(JSON.stringify(p));}
function next(l,id,r,arg){var d=E.DEC[id].make(l,r,arg);d.manual=true;l.pending.push(d);}
function action(id,label,valid,group){E.ACT.push({id:id,g:group||'Tình cảm & gia đình',l:label,min:18,sc:id,avail:function(l){return valid(l)?true:'Chưa phù hợp với hoàn cảnh hiện tại';}});}
function stamp(l){return {at:l.age,done:false};}function live(l,d){return free(l)&&d&&!d.done&&d.at===l.age;}
var nations={VN:'Việt Nam',US:'Hoa Kỳ',FR:'Pháp',JP:'Nhật Bản',KR:'Hàn Quốc',GB:'Anh',AU:'Úc'};
function preferences(l){return l.flags.dating108||(l.flags.dating108={lo:Math.max(18,l.age-5),hi:Math.max(25,Math.min(95,l.age+5)),sex:'orient',country:'local'});}
var ranges=[[18,25],[26,35],[30,40],[40,55],[55,70],[70,95]];
E.SC('dating108',{title:'Bạn muốn tìm hiểu người như thế nào?',valid:free,text:function(l){var s=preferences(l);return 'Độ tuổi '+s.lo+'–'+s.hi+' · '+({orient:'theo xu hướng hiện tại',M:'nam',F:'nữ',any:'không giới hạn giới tính'}[s.sex])+' · '+(s.country==='local'?'người đang sống cùng quốc gia':nations[s.country])+'. Các cuộc gặp đều tự nguyện; người ấy có thể từ chối.';},opts:ranges.map(function(x){return {k:'age'+x[0],l:'Độ tuổi '+x[0]+'–'+x[1],run:function(l,r){preferences(l).lo=x[0];preferences(l).hi=x[1];next(l,'dating108',r);}};}).concat(['orient','M','F','any'].map(function(x){return {k:'sex'+x,l:{orient:'Theo xu hướng tình cảm',M:'Tìm hiểu nam',F:'Tìm hiểu nữ',any:'Tìm hiểu cả nam và nữ'}[x],run:function(l,r){preferences(l).sex=x;next(l,'dating108',r);}};}),Object.keys(nations).concat(['local']).map(function(x){return {k:'country'+x,l:x==='local'?'Tìm người sống gần mình':'Tìm người '+nations[x],run:function(l,r){preferences(l).country=x;next(l,'dating108',r);}};}),[{k:'search',l:'Bắt đầu tìm người yêu',req:function(l){return !l.partner;},run:function(l,r){next(l,'tim_nguoi_yeu',r);}},{k:'close',l:'Để dịp khác',run:function(){}}])});
action('dating108','Chọn tuổi, giới tính và quốc tịch khi hẹn hò',free);
E.ACT.filter(function(a){return a.sc==='tim_nguoi_yeu';}).forEach(function(a){a.sc='dating108';});
var lm=E.DEC.love.make,la=E.DEC.love.apply;
E.DEC.love.make=function(l,r,arg){var d=lm.apply(this,arguments),p=d.data.p;if(l.age<18)return d;var s=preferences(l);p.age=U.randint(r,s.lo,s.hi);p.sex=s.sex==='any'?(r()<.5?'M':'F'):s.sex==='orient'?H.partnerSex(l,r):s.sex;p.name=H.stranger(l,r,p.sex);p.country108=s.country==='local'?(l.abroad?l.abroad.code:l.country):s.country;if(s.country!=='local'&&s.country!==(l.abroad?l.abroad.code:l.country)){var pool={VN:'vn',US:'en',FR:'fr',JP:'jp',KR:'kr',GB:'en',AU:'en'}[s.country];if(pool==='vn')p.name=G.VN.vnName(r,'kinh',p.sex).full;else if(G.NAMES.P[pool])p.name=G.NAMES.worldName(r,pool,p.sex).full;}p.residence108=(l.abroad?l.abroad.name:l.city||l.place||l.countryName);p.met108=arg&&arg.where||'qua bạn bè và hoạt động xã hội';p.affection108=35;H.partnerJob(l,p,r);
 if(/trường/.test(p.met108)&&l.school){p.school108=l.uniName||l.school;p.job='sinh viên';p.jobId=null;p.inc=0;}else if(/chỗ làm/.test(p.met108)&&l.job){p.jobId=E.resolveJob(l.job.id);p.job=E.jobTitle(l);p.workplace108='Cùng nơi làm việc với bạn';p.inc=E.monthlyEst(l,p.jobId,Math.max(0,l.job.rank-1));}
 d.text='Bạn gặp '+p.name+' ('+(p.sex==='M'?'nam':'nữ')+', '+p.age+' tuổi, '+(nations[p.country108]||p.country108)+') '+p.met108+'. Nơi ở: '+p.residence108+'. '+(p.school108?'Cùng học tại '+p.school108:p.workplace108||'Nghề nghiệp: '+p.job)+'. Hai người cần thời gian tìm hiểu nhau.';return d;};
E.DEC.love.apply=function(l,d,k,r,log){if(k==='yes'&&l.partner)return;la.apply(this,arguments);if(k==='yes'&&l.partner&&l.partner.name===d.data.p.name){['country108','residence108','met108','school108','workplace108','affection108'].forEach(function(x){l.partner[x]=d.data.p[x];});person(l,l.partner);}};
E.SC('bond108',{title:'Dành thời gian cho người thương',prep:function(l){return Object.assign(stamp(l),{who:person(l,l.partner)});},valid:function(l){return free(l)&&l.partner&&l.partner.alive!==false;},text:function(l){return 'Tình cảm với '+l.partner.name+': '+Math.round(bond(l,l.partner))+'/100. Trò chuyện và gặp gỡ giúp hiểu nhau; mỗi năm chỉ có một lần tăng tình cảm từ hoạt động này.';},opts:[{k:'talk',l:'Hẹn gặp và nói chuyện thật lòng',run:function(l,r,log,d){if(!live(l,d)||!l.partner||person(l,l.partner)!==d.who||l.partner.bondAt108===l.age)return;d.done=true;l.partner.affection108=Math.min(100,bond(l,l.partner)+12);l.partner.bondAt108=l.age;log('Hai người dành thời gian nói rõ mong muốn và dự định. Tình cảm tăng lên '+l.partner.affection108+'/100.','good');}},{k:'close',l:'Để dịp khác',run:function(){}}]});action('bond108','Bồi đắp tình cảm với người yêu / bạn đời',function(l){return free(l)&&l.partner&&l.partner.alive!==false;});
var mm=E.DEC.marry.make,ma=E.DEC.marry.apply;
function marryReady(l){return free(l)&&l.partner&&l.partner.alive!==false&&l.partner.age>=18&&l.partner.status==='dating';}
E.DEC.marry.make=function(l){var d=mm.apply(this,arguments);if(!marryReady(l))return d;d.data=Object.assign(d.data||{},{who:person(l,l.partner),at:l.age});d.text+=' Tình cảm '+bond(l,l.partner)+'/100; cần 75 điểm và ít nhất một năm bên nhau để cùng bàn chuyện cưới.';if(bond(l,l.partner)<75||l.age-l.partner.since<1)d.opts=d.opts.filter(function(o){return !['marry','small'].includes(o.k);}).concat([{k:'urge108',l:'Ngỏ lời cưới sớm, lắng nghe quyết định của người ấy',h:'Có thể bị từ chối; gây áp lực sẽ làm giảm tình cảm'}]);return d;};
E.DEC.marry.apply=function(l,d,k,r,log){if(!marryReady(l))return;if(d.data&&(d.data.who&&d.data.who!==person(l,l.partner)||d.data.at!=null&&d.data.at!==l.age))return;if(k==='urge108'){if(l.partner.urgeAt108===l.age)return;l.partner.urgeAt108=l.age;if(bond(l,l.partner)>=50&&r()<.25){next(l,'contract108',r,{at:l.age,who:person(l,l.partner),style:'small',done:false});log('Người ấy đồng ý bàn kỹ về tương lai trước khi quyết định cưới.','neutral');}else{l.partner.affection108=Math.max(0,bond(l,l.partner)-8);log('Người ấy chưa sẵn sàng. Bạn cần tôn trọng thời gian và quyết định của họ.','neutral');}return;}if(['marry','small'].includes(k)){if(bond(l,l.partner)<75||l.age-l.partner.since<1)return;next(l,'contract108',r,{at:l.age,who:person(l,l.partner),style:k,done:false});return;}return ma.apply(this,arguments);};
var marryAuto=E.DEC.marry.auto;E.DEC.marry.auto=function(l,d,r){var key=marryAuto.apply(this,arguments);return d.opts.some(function(o){return o.k===key;})?key:d.opts.some(function(o){return o.k==='wait';})?'wait':d.opts[0].k;};
E.SC('contract108',{title:'Thỏa thuận trước khi về chung nhà',valid:function(l,d){return marryReady(l)&&live(l,d)&&person(l,l.partner)===d.who;},text:'Hai người cùng bàn về tài sản nếu sau này chia tay. Đây là thỏa thuận mô phỏng trong game, chỉ có hiệu lực khi cả hai đồng ý; không làm mất nghĩa vụ nuôi con. Người ấy có quyền từ chối.',opts:[['default','Giữ cách chia tài sản mặc định',null],['separate','Giữ tài sản riêng, không chuyển tài sản khi ly hôn',0],['limited','Thỏa thuận chuyển 10% tài sản khi ly hôn',.1]].map(function(x){return {k:x[0],l:x[1],run:function(l,r,log,d){if(!E.DEC.contract108.valid(l,d))return;d.done=true;if(x[2]!=null&&r()>.65){log('Người ấy chưa đồng ý điều khoản tài sản. Hai người hoãn cưới để trao đổi thêm.','neutral');return;}l.partner.contract108={share:x[2],agreed:true};ma(l,mm(l,r),d.style,r,log);}};}).concat([{k:'cancel',l:'Chưa kết hôn',run:function(l,r,log,d){d.done=true;}}])});
function adjust(l,p,before){if(!p||l.partner||!p.contract108||p.contract108.share==null)return;var rate=p.contract108.share;l.money=before.money*(1-rate);if(before.house){l.houseVal=before.houseVal*(1-rate);l.mortgage=before.mortgage*(1-rate);(l.loans||[]).forEach(function(x,i){if(x.type==='home'&&before.loans[i]!=null)x.bal=before.loans[i]*(1-rate);});}(l.pending||[]).filter(function(d){return d.id==='settlement107';}).forEach(function(d){d.data.lost=Math.max(0,before.money-l.money);});}
function assets(l){return {money:l.money,house:l.ownHouse,houseVal:l.houseVal,mortgage:l.mortgage||0,loans:(l.loans||[]).map(function(x){return x.bal;})};}
var dm=E.DEC.divorce.make,dv=E.DEC.divorce.valid,da=E.DEC.divorce.apply;
E.DEC.divorce.make=function(l){var d=dm.apply(this,arguments);d.data=Object.assign(d.data||{},{who:person(l,l.partner),at:l.age});return d;};
E.DEC.divorce.valid=function(l,d){return !!(free(l)&&l.partner&&l.partner.alive!==false&&l.partner.status!=='dating'&&(!dv||dv(l,d))&&(!d||d.at==null||d.at===l.age)&&(!d||!d.who||d.who===person(l,l.partner)));};
E.DEC.divorce.apply=function(l,d){if(!d||!d.data||!d.data.who||!E.DEC.divorce.valid(l,d.data))return;var p=l.partner,b=assets(l);var out=da.apply(this,arguments);adjust(l,p,b);return out;};var ep=H.endPartner;H.endPartner=function(l,log,how){var p=l.partner,b=assets(l),out=ep.apply(this,arguments);if(how==='div')adjust(l,p,b);return out;};
function plan(l){return l.flags.familyPlan108||(l.flags.familyPlan108={want:2,spacing:3});}
function fertile(l,p){if(!free(l)||!p||p.alive===false||p.age<18||l.flags.pregnancy108||l.flags.tryBabyAt108===l.age)return false;var last=(l.kids||[]).reduce(function(a,k){return Math.max(a,k.born);},-100);return l.age-last>=plan(l).spacing;}
function chance(l,p){if(l.sex===p.sex)return 0;var age=l.sex==='F'?l.age:p.age;return age>49?0:age<=29?.35:age<=34?.28:age<=39?.17:age<=44?.07:.015;}
function conceive(l,p,r,log,source,protectedSex){if(!fertile(l,p))return false;l.flags.tryBabyAt108=l.age;var probability=chance(l,p)*(protectedSex?.02:1);if(r()<probability){l.flags.pregnancy108={due:l.age+1,parent:snapshot(l,p),source:source};log('Hai người có tin vui. Thai kỳ cần được theo dõi; em bé dự kiến chào đời vào năm sau.','big');return true;}log(protectedSex?'Hai người tôn trọng ranh giới, chủ động dùng biện pháp bảo vệ.':'Lần này chưa có tin vui. Hai người tiếp tục chăm sóc sức khỏe, có thể thử lại năm sau.','neutral');return false;}
var km=E.DEC.kid.make,ka=E.DEC.kid.apply;
function cancelPregnancy(l,p){var s=l.flags.pregnancy108;if(s&&p&&s.parent&&person(l,p)===s.parent.relation108){delete l.flags.pregnancy108;return true;}return false;}
function deliver(l,p,r,log,details){if(!p)return null;details=details||{};person(l,p);var original=l.partner,count=l.kids.length;try{l.partner=p;ka(l,{data:{adopt:!!details.adopt}},'yes',r,log);}finally{l.partner=original;}var child=l.kids[count];if(child){child.coParent108={id:p.relation108,name:p.name,sex:p.sex};child.birthContext108=details.source||'partner';child.family108Known=true;cancelPregnancy(l,p);}return child;}
function endAffair(l){var a=l.flags.affair107,p=a&&a.person108;if(!p)return;l.flags.network108=network(l).filter(function(q){return q!==p&&q.relation108!==p.relation108;});p.secret108=false;p.status='ended';}
var legacyPregnancy=E.DEC.co_bau_som,legacyValid=legacyPregnancy.valid,legacyApply=legacyPregnancy.apply,legacyMake=legacyPregnancy.make;
legacyPregnancy.make=function(l){var d=legacyMake.apply(this,arguments);Object.assign(d.data,{who108:person(l,l.partner),at108:l.age,done108:false});return d;};
legacyPregnancy.valid=function(l,d){var s=l.flags.pregnancy108;return (!d||!d.done108&&(d.at108==null||d.at108===l.age)&&(!d.who108||l.partner&&d.who108===person(l,l.partner)))&&legacyValid(l,d)&&(!s||!s.adopt&&l.partner&&s.parent.relation108===person(l,l.partner));};
legacyPregnancy.apply=function(l,d,k,r,log){if(!legacyPregnancy.valid(l,d.data))return;var result=legacyApply.apply(this,arguments);d.data.done108=true;return result;};
E.DEC.kid.make=function(l,r){var d=km.apply(this,arguments);d.data.adopt=chance(l,l.partner)===0;d.data.who=person(l,l.partner);d.data.at=l.age;d.text+=' Kế hoạch: '+plan(l).want+' con, cách nhau ít nhất '+plan(l).spacing+' năm. '+(d.data.adopt?'Nhận nuôi cần thời gian xét hồ sơ và chuẩn bị gia đình.':'Thử có con không bảo đảm thành công; xác suất hiện tại khoảng '+Math.round(chance(l,l.partner)*100)+'% mỗi lần thử trong năm.');d.opts[0].l=d.data.adopt?'Nộp hồ sơ nhận con nuôi':'Cùng người yêu / bạn đời thử có con';return d;};
E.DEC.kid.apply=function(l,d,k,r,log){if(k!=='yes')return ka.apply(this,arguments);if(!free(l)||!l.partner||l.partner.age<18||d.data.at!==l.age||d.data.who!==person(l,l.partner)||!fertile(l,l.partner))return;if(d.data.adopt){l.flags.tryBabyAt108=l.age;if(r()<.55){l.flags.pregnancy108={due:l.age+1,parent:snapshot(l,l.partner),source:'adopt',adopt:true};log('Hồ sơ nhận nuôi được chấp thuận bước đầu. Hai người dành năm tới chuẩn bị đón trẻ.','good');}else log('Hồ sơ cần được bổ sung, chưa thể đón trẻ trong năm nay.','neutral');return;}conceive(l,l.partner,r,log,'partner',false);};
E.ACT.filter(function(a){return a.id==='sinh_con';}).forEach(function(a){a.l='Lên kế hoạch có con / nhận nuôi';a.avail=function(l){return free(l)&&l.partner&&l.partner.age>=18&&fertile(l,l.partner)?true:'Cần người cùng nuôi con đã trưởng thành, chưa có thai và đủ khoảng cách giữa các lần sinh';};});
E.SC('familyPlan108',{title:'Kế hoạch con cái',valid:free,text:function(l){return 'Mong muốn '+plan(l).want+' con; khoảng cách '+plan(l).spacing+' năm. Kế hoạch giúp giảm lời nhắc sinh con tự động; bạn vẫn có thể chủ động đổi quyết định.';},opts:[0,1,2,3,4].map(function(n){return {k:'want'+n,l:'Mong muốn '+n+' con',run:function(l,r){plan(l).want=n;next(l,'familyPlan108',r);}};}).concat([2,3,4,5].map(function(n){return {k:'gap'+n,l:'Giãn cách ít nhất '+n+' năm',run:function(l,r){plan(l).spacing=n;next(l,'familyPlan108',r);}};}),[{k:'close',l:'Lưu kế hoạch',run:function(){}}])});action('familyPlan108','Chọn số con mong muốn và khoảng cách sinh',free);
function network(l){return l.flags.network108||(l.flags.network108=[]);}
E.SC('network108',{title:'Những mối quan hệ ngoài nhãn gọi',valid:free,text:'Gặp gỡ người trưởng thành, nói rõ mong đợi và giới hạn. Mập mờ hay gặp gỡ một đêm có thể để lại lưu luyến, thai kỳ và tổn thương. Nếu đang có gia đình, đây là lựa chọn phản bội có thể bị phát hiện.',opts:[{k:'new',l:'Làm quen người mới theo lựa chọn hẹn hò',req:function(l){return network(l).length<5;},run:function(l,r){var p=E.DEC.love.make(l,r,{where:'trong buổi giao lưu'}).data.p;p.alive=true;p.since=l.age;p.status='ambiguous';person(l,p);network(l).push(p);next(l,'network108',r);}}].concat(Array.from({length:5},function(_,i){return {k:'p'+i,l:function(l){var p=network(l)[i];return p?p.name+' · '+p.age+' tuổi · '+(p.secret108?'gia đình bí mật':p.status==='ambiguous'?'mập mờ':'quan hệ riêng'):'';},req:function(l){return !!network(l)[i];},run:function(l,r){var p=network(l)[i];next(l,'network108_person',r,{at:l.age,who:p.relation108,done:false});}};}),[{k:'close',l:'Quay lại cuộc sống của mình',run:function(){}}])});action('network108','Mập mờ, gặp gỡ một đêm và quan hệ riêng',free);
function target(l,d){return network(l).find(function(p){return p.relation108===d.who&&p.alive!==false;});}
E.SC('network108_person',{title:'Nói rõ mong đợi của hai người',valid:function(l,d){return live(l,d)&&!!target(l,d);},text:function(l,d){var p=target(l,d);return p.name+' · '+p.age+' tuổi · '+(nations[p.country108]||p.country108)+' · sống ở '+p.residence108+'. Các quyết định đều cần hai người tự nguyện. Mỗi năm chỉ có một cuộc gặp có tác động với người này.';},opts:[['talk','Giữ mối quan hệ mập mờ, tiếp tục tìm hiểu'],['casual','Một đêm tự nguyện, có bảo vệ'],['baby','Thân mật không bảo vệ, chấp nhận khả năng có con'],['secret','Cùng duy trì một gia đình bí mật'],['date','Đề nghị hẹn hò nghiêm túc'],['end','Kết thúc mối quan hệ']].map(function(x){return {k:x[0],l:x[1],req:function(l){return x[0]!=='date'||!l.partner;},run:function(l,r,log,d){var p=target(l,d);if(!live(l,d)||!p||p.meetAt108===l.age)return;d.done=true;p.meetAt108=l.age;if(x[0]==='end'){l.flags.network108=network(l).filter(function(q){return q!==p;});log('Bạn nói rõ quyết định dừng lại, không để người ấy phải tiếp tục đoán.','neutral');return;}if(x[0]==='date'){if(l.partner)return;if(r()<.6){l.partner=p;p.status='dating';p.since=l.age;l.flags.network108=network(l).filter(function(q){return q!==p;});log('Hai người đồng ý hẹn hò nghiêm túc.','good');}else log('Người ấy chưa muốn một mối quan hệ chính thức.','neutral');return;}if(x[0]==='secret'){if(!l.partner||l.partner.status==='dating'||l.money<l.base*.25)return;if(r()>.5){log('Người ấy không chấp nhận phải sống trong bí mật.','neutral');return;}p.secret108=true;p.status='private';H.cash(l,-l.base*.15,'Chuẩn bị nơi sống của gia đình bí mật');log('Bạn duy trì thêm một mái nhà trong bí mật. Trách nhiệm tiền bạc và nguy cơ bị phát hiện bắt đầu từ đây.','bad');return;}if(x[0]==='talk'){p.affection108=Math.min(100,bond(l,p)+8);log('Hai người tiếp tục tìm hiểu nhưng chưa cam kết độc quyền.','neutral');}else conceive(l,p,r,log,'outside',x[0]==='casual');if(l.partner)H.fx(l,{karma:-5,hap:-2});}};})});
var aa=E.DEC.affair107.apply;E.DEC.affair107.apply=function(l,d,k,r,log){aa.apply(this,arguments);var a=l.flags.affair107;if(k==='start'&&a&&!a.person108){var p={name:a.name,sex:H.partnerSex(l,r),age:Math.max(18,l.age+U.randint(r,-3,3)),alive:true,since:l.age,status:'private',residence108:l.city||l.place,country108:l.abroad?l.abroad.code:l.country};person(l,p);a.person108=p;network(l).push(p);}};
E.SC('childGuide108',{title:'Mong muốn và con đường riêng của con',valid:function(l){return free(l)&&(l.kids||[]).some(function(k){return k.alive&&l.age-k.born>=10;});},text:'Bạn có thể chia sẻ kỳ vọng, cho con thử việc và học kỹ năng. Con vẫn có sở thích riêng; gây sức ép sẽ làm tình cảm xa cách.',opts:Array.from({length:20},function(_,i){return {k:String(i),l:function(l){return l.kids[i]?l.kids[i].name:'';},req:function(l){var k=l.kids[i];return k&&k.alive&&l.age-k.born>=10;},run:function(l,r){var k=l.kids[i];next(l,'childGuide108_path',r,{at:l.age,index:i,name:k.name,done:false});}};}).concat([{k:'close',l:'Để dịp khác',run:function(){}}])});
E.SC('childGuide108_path',{title:'Cùng con bàn chuyện tương lai',valid:function(l,d){var k=l.kids[d&&d.index];return live(l,d)&&k&&k.alive&&k.name===d.name;},text:'Một buổi trò chuyện giúp hiểu con thích gì và gia đình hỗ trợ được đến đâu. Mục tiêu không thay con quyết định nghề nghiệp.',opts:[['business','Cho con thử sức kinh doanh'],['tradition','Giới thiệu nghề và truyền thống gia đình'],['freedom','Ủng hộ con tự chọn hướng đi'],['pressure','Ép con theo mong muốn của mình']].map(function(x){return {k:x[0],l:x[1],run:function(l,r,log,d){if(!E.DEC.childGuide108_path.valid(l,d))return;var k=l.kids[d.index];if(k.guideAt108===l.age)return;d.done=true;k.guideAt108=l.age;k.careerWish108=x[0];if(x[0]==='pressure'){k.close=Math.max(0,(k.close||50)-12);log(k.name+' cảm thấy mình không được lắng nghe. Khoảng cách giữa hai người lớn hơn.','bad');}else{k.close=Math.min(100,(k.close||50)+5);k.study=Math.min(100,(k.study||50)+2);k.careerTrial108={path:x[0],familyJob:l.job?E.jobTitle(l):null,age:l.age};log('Bạn cùng '+k.name+(x[0]==='business'?' lập một kế hoạch buôn bán nhỏ, thử tính vốn và chi phí.':x[0]==='tradition'?' tìm hiểu nghề của gia đình, quan sát một buổi làm việc thực tế.':' bàn về sở thích và những bước học tập tiếp theo. Con được giữ quyền lựa chọn.'),'good');}}};})});action('childGuide108','Hướng nghiệp và chia sẻ kỳ vọng với con',function(l){return E.DEC.childGuide108.valid(l);});
E.SC('luxury108',{title:'Thú vui khi đã có của để dành',prep:stamp,valid:function(l){return free(l)&&l.age>=40&&l.money>=l.base*5;},text:'Một cuộc vui đắt đỏ không bảo đảm hạnh phúc hay danh tiếng. Chi phí được trừ thật; mỗi năm chỉ chọn một lần.',opts:[['golf','Chơi golf và giao lưu',.1],['yacht','Thuê du thuyền mở tiệc',.5],['collect','Sưu tầm đồng hồ và nghệ thuật',1],['night','Tiệc riêng thâu đêm',.25]].map(function(x){return {k:x[0],l:x[1],h:function(l){return H.money(l,l.base*x[2]);},run:function(l,r,log,d){if(!live(l,d)||l.flags.luxuryAt108===l.age||l.money<l.base*x[2])return;d.done=true;l.flags.luxuryAt108=l.age;H.cash(l,-l.base*x[2],x[1]);H.fx(l,{hap:3,hea:x[0]==='night'?-5:0,soc:1});log({golf:'Bạn dành buổi sáng trên sân golf, cùng nhóm bạn bàn chuyện cuộc sống sau mỗi vòng đánh.',yacht:'Du thuyền rời bến lúc hoàng hôn. Bạn mời một nhóm bạn thân ăn tối, nghe nhạc giữa mặt nước.',collect:'Bạn xem kỹ xuất xứ, chọn một món đồ cho bộ sưu tập và dành riêng một góc nhà để trưng bày.',night:'Bữa tiệc kéo dài đến gần sáng. Âm nhạc và những lời chúc vui vẻ đổi lại một ngày hôm sau mệt mỏi.'}[x[0]],'neutral');}};}).concat([{k:'close',l:'Giữ tiền cho việc khác',run:function(){}}])});action('luxury108','Golf, du thuyền, sưu tầm và tiệc riêng',function(l){return E.DEC.luxury108.valid(l);},'Giải trí & trải nghiệm');
E.HOOKS.year.push(function(l,r,log){if(!l.alive||!['vn','world'].includes(l.mode))return;var p=l.partner;if(p){bond(l,p);if(p.status==='dating')p.affection108=Math.min(100,p.affection108+5);}var pregnancy=l.flags.pregnancy108;if(pregnancy&&pregnancy.due<=l.age){deliver(l,pregnancy.parent,r,log,pregnancy);delete l.flags.pregnancy108;}
 network(l).forEach(function(q){if(q.lastAge108!==l.age){q.age++;q.lastAge108=l.age;}if(q.secret108){H.cash(l,-l.base*.12,'Chi phí duy trì mái nhà riêng');if(p&&r()<.18){log('Những khoản chi và lịch vắng nhà khiến người bạn đời phát hiện mối quan hệ bí mật.','bad');H.fx(l,{hap:-15});if(l.flags.affair107)next(l,'affair107_confront',r,{spouse:l.flags.affair107.spouse});else next(l,'divorce',r);}}});});
E.childRelation108=function(l,k){if(!k.coParent108)return 'Chưa có thông tin người cùng nuôi con trong bản lưu cũ';var p=l.partner;return (p&&person(l,p)===k.coParent108.id?'Con chung':'Con riêng')+' · cùng '+k.coParent108.name+(k.birthContext108==='outside'?' · ngoài hôn nhân':'');};

E.SC('postgraduate108',{title:'Học thạc sĩ, tiến sĩ ở đâu?',valid:free,text:'Mở Hành động → Học tập để đăng ký bất kỳ năm nào đủ điều kiện. Thạc sĩ cần bằng đại học; tiến sĩ cần bằng thạc sĩ. Không có giới hạn 30 tuổi. Bạn chọn ngành, trường, chuẩn bị học phí rồi bảo vệ luận văn hoặc luận án. Muốn học ở nước ngoài, chọn Tự chọn quốc gia, trường và ngành du học.',opts:[6,7].map(function(lv){return {k:String(lv),l:lv===6?'Chọn trường và ngành thạc sĩ':'Chọn trường và ngành tiến sĩ',req:function(l){return E.POSTGRAD106.eligible(l,lv);},run:function(l,r){if(E.POSTGRAD106.eligible(l,lv))next(l,'pg106_'+lv,r);}};}).concat([{k:'close',l:'Đã hiểu',run:function(){}}])});action('postgraduate108','Học cao học / tiến sĩ: điều kiện và đăng ký',free,'Học tập');
var ca=E.DEC.casual101.apply;E.DEC.casual101.apply=function(l,d,k,r,log){ca.apply(this,arguments);if(k==='yes'&&d.data&&d.data.age>=18&&l.age>=18)conceive(l,{name:d.data.n,sex:d.data.sex,age:d.data.age,alive:true},r,log,'outside',true);};

E.RELATIONS108={plan:plan,fertile:fertile,chance:chance,conceive:conceive,person:person,bond:bond,deliver:deliver,cancelPregnancy:cancelPregnancy,endAffair:endAffair};
})(globalThis.G);

;
