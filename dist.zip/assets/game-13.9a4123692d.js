/* ===== js/life50.js ===== */
/* v4.5.4 — cùng danh mục game, lịch sử chơi và cửa hàng vật phẩm. */
(function (G) {
  'use strict';
  var E = G.E, H = E.H;
  // Giá VNĐ là ngân sách mô phỏng, không phải báo giá trực tiếp của nhà phát hành.
  var cats = { fps: ['Counter-Strike 2', 'Valorant', 'Delta Force', 'Free Fire', 'Đột Kích (CrossFire)', 'PUBG Mobile'], moba: ['Liên Minh Huyền Thoại', 'Liên Quân Mobile', 'Mobile Legends: Bang Bang', 'Liên Minh: Tốc Chiến'], other: ['Minecraft', 'Roblox', 'Nghịch Thủy Hàn', 'Đấu Trường Chân Lý (TFT)'] };
  var names = { fps: 'FPS', moba: 'MOBA', other: 'Game khác' }, all = [].concat(cats.fps, cats.moba, cats.other);
  var aliases = { CS2: 'Counter-Strike 2', CF: 'Đột Kích (CrossFire)', 'Liên quân': 'Liên Quân Mobile', 'Liên Minh Tốc Chiến': 'Liên Minh: Tốc Chiến', 'Delta Force Mobile': 'Delta Force' };
  function norm(g) { return aliases[g] || g; }
  function free(l) { return l.alive && !(l.jailUntil != null && l.age < l.jailUntil) && !(l.abroad && l.abroad.trapped) && !(l.flags.military && l.age < l.flags.military); }
  function played(l) { return (l.flags.homeGames || []).map(norm).filter(function (g, i, a) { return all.indexOf(g) >= 0 && a.indexOf(g) === i; }); }
  function cost(l, n) { return l.cur === 'vnd' ? n : n / 90 * l.base; }
  function queue(l, r, id, arg) { l.pending.unshift(E.DEC[id].make(l, r, arg)); }
  function opts(list, cb) { return list.map(function (x) { return { k: x, l: x, run: cb(x) }; }); }
  var back = { k: 'no', l: 'Để dịp khác', run: function () {} };
  E.HOME_GAMES = cats; E.playedGames = played;
  E.GAMES.fps.pc = cats.fps.slice(0, 3).concat([cats.fps[4]]); E.GAMES.fps.mobile = ['Free Fire', 'PUBG Mobile'];
  E.GAMES.moba.pc = [cats.moba[0]]; E.GAMES.moba.mobile = cats.moba.slice(1);
  E.SC('choi_game_nha', { title: 'Chơi game ở nhà', valid: free, text: 'Bạn muốn chơi thể loại nào?', opts: Object.keys(cats).map(function (c) { return { k: c, l: names[c], run: function (l, r) { queue(l, r, 'home_game_list', { cat: c }); } }; }).concat([back]) });
  E.SC('home_game_list', { title: function (l, d) { return names[d.cat]; }, valid: free, text: 'Chọn game bạn muốn chơi:', prep: function (l, r, a) { return { cat: a && cats[a.cat] ? a.cat : 'other' }; }, opts: opts(all, function (g) { return function (l, r, log, d) { if (cats[d.cat].indexOf(g) >= 0) queue(l, r, 'home_game_play', { g: g }); }; }).map(function (o) { o.req = function (l, d) { return cats[d.cat].indexOf(o.k) >= 0; }; return o; }).concat([back]) });
  function play(l, d, log, night) {
    if (!free(l) || all.indexOf(d.g) < 0) return;
    l.flags.homeGames = played(l); if (l.flags.homeGames.indexOf(d.g) < 0) l.flags.homeGames.push(d.g);
    l.flags.lastHomeGame = d.g;
    if (E.esportsPractice) E.esportsPractice(l, d.g, night);
    H.fx(l, night ? { hap: 3, hea: -2, kno: -1 } : { hap: 2 });
    if (night && l.talent === 'game' && norm(l.game) === d.g) l.skill = Math.min(100, (l.skill || 20) + 3);
    log('Chơi ' + d.g + (night ? ' xuyên đêm, sáng ra mệt mỏi.' : ' một lúc để thư giãn.'), 'neutral');
  }
  E.SC('home_game_play', { title: function (l, d) { return d.g || 'Chơi game'; }, valid: function (l, d) { return free(l) && !!d && all.indexOf(d.g) >= 0; }, text: 'Bạn muốn chơi thế nào?', opts: [
    { k: 'bit', l: 'Chơi một lúc rồi nghỉ', run: function (l, r, log, d) { play(l, d, log, false); } },
    { k: 'night', l: 'Cày xuyên đêm', run: function (l, r, log, d) { play(l, d, log, true); } }, back
  ] });
  // Bậc giá có căn cứ: Riot (875/1775 VP, 1350/1820 RP), Garena (399/599 QH).
  // Các game không công khai bảng giá ổn định dùng ngân sách, không bịa giá một skin cụ thể.
  var catalog = {
    'Valorant': [['Skin Select — 875 VP', 0.18], ['Skin Premium — 1.775 VP', 0.36]],
    'Liên Minh Huyền Thoại': [['Skin Sử thi — 1.350 RP', 0.25], ['Skin Huyền thoại — 1.820 RP', 0.34]],
    'Liên Quân Mobile': [['Trang phục cửa hàng — 399 Quân Huy', 0.20], ['Trang phục cửa hàng — 599 Quân Huy', 0.30]],
    'Counter-Strike 2': [['Ngân sách skin trên Steam Market', 0.10], ['Ngân sách skin trên Steam Market', 1]],
    'Minecraft': [['Battle & Beasts 2 Skin Pack — 310 Minecoins', 0.06]],
    'Roblox': [['Phụ kiện avatar — ngân sách Robux', 0.13]],
    'Liên Minh: Tốc Chiến': [['Trang phục trong cửa hàng — ngân sách Wild Cores', 0.25]],
    'Mobile Legends: Bang Bang': [['Trang phục cửa hàng — ngân sách kim cương', 0.25]],
    'Delta Force': [['Ngoại hình cửa hàng — ngân sách Delta Coins', 0.30]],
    'Free Fire': [['Trang phục cửa hàng — ngân sách kim cương', 0.20]],
    'Đột Kích (CrossFire)': [['Vật phẩm cửa hàng — ngân sách Vcoin', 0.30]],
    'PUBG Mobile': [['Trang phục bán trực tiếp — ngân sách UC', 0.30]],
    'Nghịch Thủy Hàn': [['Ngoại trang Nghịch Thủy Hàn', 1]],
    'Đấu Trường Chân Lý (TFT)': [['Linh thú tí nị', 2.5], ['Linh thú đột phá', 2.5], ['Linh thú hàng hiệu', 7]]
  };
  E.GAME_SHOP = catalog;
  function has(l, d) { return free(l) && played(l).indexOf(d.g) >= 0; }
  function own(l, d, label, log) { var a = l.flags.gameItems || (l.flags.gameItems = []); var item = label.replace('Ngân sách skin trên Steam Market', 'skin trên Steam Market').replace(/ — ngân sách.*$/, '').replace(' — ngân sách', ''); a.push({ game: d.g, item: item, age: l.age }); H.fx(l, { hap: 2 }); log(d.g + ': nhận ' + item + '.', 'good'); }
  E.SC('nap_game', { title: 'Vật phẩm cho game đã chơi', valid: function (l) { return free(l) && played(l).length > 0; }, prep: function (l, r, a) { var p = played(l); return { g: a && p.indexOf(a.g) >= 0 ? a.g : p.indexOf(l.flags.lastHomeGame) >= 0 ? l.flags.lastHomeGame : p[0] }; },
    text: function (l, d) { if (/Nghịch Thủy Hàn|Đấu Trường Chân Lý/.test(d.g)) return 'Chọn vật phẩm cho ' + d.g + '.'; return d.g ? 'Bạn đang xem vật phẩm của ' + d.g + '. Giá quy đổi VNĐ là ước tính, thay đổi theo máy chủ, gói nạp và khuyến mại. Ngân sách không phải báo giá một skin cụ thể.' + (d.g === 'Counter-Strike 2' ? ' Giá chợ còn phụ thuộc mẫu, độ mòn và người bán.' : '') : 'Hãy chọn và chơi một game ở nhà trước.'; },
    opts: [0, 1, 2].map(function (i) { return { k: 'buy' + i, l: function (l, d) { var x = (catalog[d.g] || [])[i]; return x ? x[0] + ' — ~' + H.money(l, cost(l, x[1])) : ''; }, req: function (l, d) { return has(l, d) && !!(catalog[d.g] || [])[i]; }, run: function (l, r, log, d) { if (!has(l, d)) return; var x = catalog[d.g][i], n = cost(l, x[1]); if (l.money < n) { log('Chưa đủ tiền tiết kiệm để mua vật phẩm ' + d.g + '.', 'neutral'); return; } H.cash(l, -n, 'Vật phẩm ' + d.g); own(l, d, x[0], log); } }; }).concat([
      { k: 'free', l: 'Dùng skin tự tạo / miễn phí', req: function (l, d) { return has(l, d) && /Minecraft|Roblox/.test(d.g); }, run: function (l, r, log, d) { if (has(l, d)) own(l, d, 'diện mạo miễn phí', log); } },
      { k: 'game', l: 'Chọn game đã chơi khác', req: function (l) { return played(l).length > 1; }, run: function (l, r) { queue(l, r, 'home_skin_games'); } },
      { k: 'no', l: 'Giữ đồ hiện tại, không nạp', run: function () {} }
    ]) });
  E.SC('home_skin_games', { title: 'Vật phẩm game', valid: function (l) { return free(l) && played(l).length > 0; }, text: 'Chỉ hiện những game bạn đã chơi ở nhà:', opts: opts(all, function (g) { return function (l, r) { queue(l, r, 'nap_game', { g: g }); }; }).map(function (o) { o.req = function (l) { return free(l) && played(l).indexOf(o.k) >= 0; }; return o; }).concat([back]) });
  E.ACT.push({ id: 'home_skin_games', g: E.ACT.filter(function (a) { return a.id === 'choi_game_nha'; })[0].g, l: 'Skin / vật phẩm game đã chơi', min: 6, avail: function (l) { return free(l) && played(l).length > 0 ? true : 'Chơi một game ở nhà trước'; }, ai: { w: 0.03 } });
  E.TRIG.filter(function (t) { return t.id === 'nap_game'; }).forEach(function (t) { var before = t.when; t.when = function (l, a) { return free(l) && played(l).length > 0 && before(l, a); }; });
  E.skinPrice = function (g) { return catalog[norm(g)] ? catalog[norm(g)][0][1] : 0; };
})(globalThis.G);

;
/* ===== js/life51.js ===== */
/* v4.5.7 — một đợt quân ngũ, lựa chọn còn hiệu lực, lịch hẹn không bị mất. */
(function (G) {
  'use strict';
  var E = G.E, H = E.H;
  function served(l) { return l.flags.milDone || l.flags.milVet || l.flags.milReleasedAt != null || (l.log || []).some(function (x) { return /Lên đường nhập ngũ|Hoàn thành nghĩa vụ quân sự|Ra quân sau 24 tháng|Nhận trợ cấp xuất ngũ/.test(x.t); }); }
  E.canServe = function (l) {
    var id = l.job && E.resolveJob(l.job.id);
    return l.alive && l.sex === 'M' && l.age >= 18 && l.age <= 27 && !served(l) && !l.flags.military && !l.abroad && !(l.jailUntil != null && l.age < l.jailUntil) && l.st.hea >= 55 && !(l.ill && l.ill.mult >= 2) && id !== 'quan_doi' && id !== 'cong_an';
  };
  function start(l, r, log) {
    if (!E.canServe(l)) return;
    l.flags.milDone = true; l.flags.milSince = l.age; l.flags.military = l.age + 2;
    l.flags.milTB = false; l.flags.milRole = null; l.flags.milSeen = {}; l.school = null; l.flags.retryUni = null;
    log('Lên đường nhập ngũ, thực hiện nghĩa vụ quân sự trong hai năm.', 'big');
    H.chain(l, 'nv_don_vi'); H.chain(l, 'nv_tan_binh');
  }
  var uniMake = E.DEC.uni.make, uniApply = E.DEC.uni.apply;
  E.DEC.uni.make = function (l) { var d = uniMake.apply(this, arguments); if (!E.canServe(l)) d.opts = d.opts.filter(function (o) { return o.k !== 'military'; }); return d; };
  E.DEC.uni.apply = function (l, d, k, r, log) { if (k === 'military') { if (E.canServe(l)) start(l, r, log); return; } return uniApply.apply(this, arguments); };
  E.SC('nv_lenh_goi', { title: 'Đợt khám tuyển nghĩa vụ quân sự', valid: E.canServe,
    text: 'Bạn nhận lịch khám tuyển. Kết quả sức khỏe và hoàn cảnh hiện tại được xem xét trước khi nhập ngũ.',
    opts: [
      { k: 'di', l: 'Tham gia khám tuyển', run: function (l, r, log) { if (!E.canServe(l)) return; if (r() < 0.65) start(l, r, log); else { l.flags.milScreened = true; log('Đợt khám tuyển kết thúc, bạn không được chọn nhập ngũ trong đợt này.', 'neutral'); } } },
      { k: 'hoi', l: 'Hỏi hướng dẫn về sức khỏe và hoàn cảnh cá nhân', run: function (l, r, log) { if (E.canServe(l)) { l.flags.milScreened = true; log('Bạn trình bày hoàn cảnh và nhận hướng dẫn bổ sung hồ sơ. Chưa có quyết định nhập ngũ.', 'neutral'); } } }
    ] });
  // Tân binh / phân đơn vị / ra quân đều chỉ có một lần, kể cả mở lại lựa chọn cũ.
  Object.keys(E.DEC).filter(function (id) { return /^nv_/.test(id) && id !== 'nv_lenh_goi'; }).forEach(function (id) {
    var D = E.DEC[id], apply = D.apply, before = D.valid;
    D.valid = function (l, d) {
      if (!l.alive || !(l.flags.military > 0) || l.jailUntil != null && l.age < l.jailUntil) return false;
      if (id === 'nv_xuat_ngu') return l.age >= l.flags.military && !l.flags.milVet && l.flags.milReleasedAt == null;
      return l.age < l.flags.military && !(l.flags.milResolved || {})[id] && (!before || before(l, d));
    };
    D.apply = function (l, d, k, r, log) {
      if (!D.valid(l, d.data)) return;
      (l.flags.milResolved || (l.flags.milResolved = {}))[id] = true;
      if (id === 'nv_xuat_ngu') {
        // Đóng trạng thái trước khi phát trợ cấp / nhận việc, không thể nhận lần hai.
        l.flags.military = null; l.flags.milVet = true; l.flags.milDone = true; l.flags.milReleasedAt = l.age;
        if (!l.job) l.flags.needJob = true;
      }
      return apply.apply(this, arguments);
    };
  });
  var milYear = E.milYear;
  E.milYear = function (l, r, a) {
    l.flags.milDone = true;
    if (l.flags.milPlanAge === a) return [];
    l.flags.milPlanAge = a;
    if (l.flags.milTB) (l.flags.milResolved || (l.flags.milResolved = {})).nv_tan_binh = true;
    if (l.flags.milRole) (l.flags.milResolved || (l.flags.milResolved = {})).nv_don_vi = true;
    return milYear(l, r, a).filter(function (x) { return E.DEC[x[0]].valid(l, {}); });
  };
  function sender(l) { return l.fam.mAlive ? 'mẹ' : l.fam.fAlive && !l.fam.noDad ? 'bố' : H.sibs(l).length ? 'anh chị em' : null; }
  E.DEC.nv_thu_nha.def.text = function (l) {
    if (l.partner && l.partner.alive !== false) return l.partner.name + ' gửi lời hỏi thăm, động viên bạn trong những ngày xa nhà.';
    var s = sender(l); return s ? 'Nhận được thư và một ít quà từ ' + s + ', bạn đem chia với đồng đội.' : 'Một người bạn gửi lời hỏi thăm; đồng đội rủ bạn cùng chia quà hậu phương trong phòng.';
  };
  E.DEC.nv_thu_nha.def.opts[0].run = function (l, r, log) { var s = l.partner && l.partner.alive !== false ? l.partner.name : sender(l); log(s ? 'Gửi lời hỏi thăm và cảm ơn ' + s + ', chia niềm vui với đồng đội.' : 'Ngồi chuyện trò cùng đồng đội, những ngày xa nhà bớt cô quạnh.', 'good'); H.fx(l, { hap: 3, soc: 2 }); };
  var leave = E.DEC.nv_phep.def.opts.filter(function (o) { return o.k === 'nha'; })[0];
  leave.run = function (l, r, log) { var s = sender(l), n = l.cur === 'vnd' ? 1 : l.base / 90; if (l.money < n) { log('Chưa đủ tiền tàu xe, bạn xin ở lại đơn vị và liên lạc hỏi thăm từ xa.', 'neutral'); return; } H.cash(l, -n, 'Tàu xe về phép'); H.fx(l, { hap: 8, soc: 3 }); log(s ? 'Về phép thăm ' + s + ', dành những ngày nghỉ bên người thân.' : 'Dùng ngày phép về thăm quê, gặp lại bạn bè rồi trở lại đơn vị đúng hẹn.', 'good'); };
  E.quietYear = function (l, a, r) {
    var pool = [
      'Một năm không có bước ngoặt lớn, những chuyện nhỏ vẫn làm nên cuộc sống.',
      'Thêm một năm nhìn cảnh vật quanh mình thay đổi theo mùa.',
      'Những ngày nắng mưa nối nhau, bạn tiếp tục nhịp sống thường ngày.',
      'Năm nay không có tin lớn, chỉ những thay đổi rất nhỏ qua từng tháng.',
      'Một năm đủ yên để nhận ra những điều trước kia thường bỏ qua.',
      'Nhịp sống có lúc chậm, có lúc vội; năm nay rồi cũng qua.',
      'Cuối năm nhìn lại, điều đáng nhớ nằm trong những ngày rất đỗi bình thường.',
      'Năm nay trôi qua giữa những việc quen thuộc, không có biến động lớn.',
      'Những dự định nhỏ, có việc làm được, có việc để sang năm.',
      'Một năm lặng lẽ, cuộc sống tiếp tục bằng những việc thường nhật.',
      'Bước sang một mùa mới, bạn thêm quen với nhịp sống của mình.',
      'Năm nay không nhiều chuyện để kể, nhưng thời gian vẫn để lại dấu ấn.',
      'Có những ngày dài và những tháng qua rất nhanh; lại thêm một năm.',
      'Những điều quen thuộc quanh nơi ở trở thành ký ức của năm nay.',
      'Thời tiết đổi mùa, sinh hoạt vẫn giữ nhịp quen thuộc.',
      'Qua một năm tương đối ổn định, bạn lại nhìn về chặng đường phía trước.'
    ];
    if (a < 6) pool = ['Thêm một năm khám phá thế giới qua những điều nhỏ xíu.', 'Những âm thanh và màu sắc quanh nhà dần trở nên quen thuộc.', 'Lớn thêm một chút, học thêm những thói quen mới.', 'Mỗi ngày là một khám phá nhỏ trong những năm đầu đời.'];
    else if (l.school) pool = pool.concat(['Một năm đi học, những trang vở đầy dần theo từng tháng.', 'Bài học mới nối tiếp bài cũ, bạn bước thêm một đoạn trên đường học tập.', 'Những ngày đến lớp đan xen với thời gian tự học và nghỉ ngơi.']);
    else if (l.job) pool = pool.concat(['Thêm một năm làm việc, bạn quen hơn với nhịp của nghề.', 'Công việc tiếp diễn qua những ngày bận rộn và những lúc yên ắng.', 'Một năm tích lũy thêm trải nghiệm từ những việc quen thuộc.']);
    if (l.flags.military && a < l.flags.military) pool = ['Một năm rèn nề nếp trong doanh trại, dần quen với sinh hoạt tập thể.', 'Những ngày quân ngũ nối tiếp nhau qua huấn luyện, sinh hoạt và trực gác.'];
    var recent = {}, allSeen = {}; (l.log || []).forEach(function (e) { allSeen[e.t] = true; if (e.a >= a - 12) recent[e.t] = true; });
    var fresh = pool.filter(function (t) { return !allSeen[t]; });
    if (!fresh.length) fresh = pool.filter(function (t) { return !recent[t]; });
    return G.U.pick(r, fresh.length ? fresh : pool);
  };
})(globalThis.G);

;
/* ===== js/life52.js ===== */
/* v4.5.8 — chế độ hưu trí theo nghề, hợp đồng thi đấu theo thành tích (mô phỏng). */
(function (G) {
  'use strict';
  var E = G.E, H = E.H, U = G.U;
  E.pensionPolicy = function (l, c) {
    c = c || E.jobDef(l); if (!c || !l.job) return { covered: false, reason: 'Chưa có công việc' };
    if (c.sec === 'crime' || c.cat === 'crime') return { covered: false, reason: 'Nghề phi pháp không có chế độ hưu trí' };
    if (c.cat === 'free' || c.cat === 'creator' || c.fame) return { covered: false, reason: 'Hoạt động tự do: không tự động đóng bảo hiểm hưu trí' };
    if (/^(an_xin|ve_so|ve_chai|ban_rong|xe_om|tx_cn|phu_giup|nong|ngu_dan|xkld|dau_tu_es|pt_gym)$/.test(c.id) || c.sec === 'farm') return { covered: false, reason: 'Nghề tự doanh hoặc thu nhập không theo hợp đồng lao động' };
    var title = c.t[Math.min(l.job.rank || 0, c.t.length - 1)] || '';
    if (c.owner || c.cat === 'biz' || c.sec !== 'formal' && (l.job.fam || /^(chủ|cai thầu|giám đốc công ty|nhà đầu tư)/.test(title))) return { covered: false, reason: 'Chủ cơ sở / kinh doanh riêng: không tự động đóng bảo hiểm hưu trí' };
    return { covered: true, reason: 'Công việc theo hợp đồng, tự động tích lũy năm đóng bảo hiểm để nhận lương hưu' };
  };
  E.pensionCovered = function (l, c) { return E.pensionPolicy(l, c).covered; };
  E.finalizePension = function (l, log, recalc) {
    if (l.pensioned && !recalc) return false;
    var si = l.si, years = si && si.yrs || 0;
    if (years < 15 || !si || !(si.sum > 0)) return false;
    var rate = l.sex === 'M' ? years < 20 ? .4 + (years - 15) * .01 : .45 + (years - 20) * .02 : .45 + (years - 15) * .02;
    l.pensionRate = U.clamp(rate, .4, .75); l.pensionInc = si.sum / years * l.pensionRate;
    l.pensioned = true;
    if (log) log('Đủ ' + years + ' năm đóng bảo hiểm, bắt đầu hưởng lương hưu ' + H.money(l, l.pensionInc / 12) + '/tháng theo mức lương đóng bình quân.', 'good');
    return true;
  };
  function pensionAge(l) { return H.isVN(l) ? l.sex === 'M' ? 62 : 60 : 65; }
  var cy = E.careerYear;
  E.careerYear = function (l, r, log) {
    var had = !!l.pensioned, siAtStart = l.si && l.si.yrs || 0;
    if (!had && l.age >= pensionAge(l) && siAtStart >= 15) {
      E.finalizePension(l, log); had = !!l.pensioned;
      if (l.pensioned && !l.job) { l.retired = true; l.flags.fullRetire = true; }
    }
    var income = cy.apply(this, arguments);
    // Tính cả năm đóng cuối cùng, không dùng toàn bộ số năm lao động thay số năm đóng.
    if (!had && l.alive && (l.retired || l.age >= pensionAge(l))) E.finalizePension(l, log, true);
    return income;
  };
  var offer = E.offerHint;
  E.offerHint = function (l, id) {
    var hint = offer.apply(this, arguments), c = E.CAR[E.resolveJob(id)]; if (!c) return hint;
    var fake = Object.assign({}, l, { job: { id: id, rank: E.startRank(l, c) } });
    if (c && !E.pensionCovered(fake, c)) hint += ' · không tự động tích lũy lương hưu';
    return hint;
  };
  function athlete(l) { return l.job && /^(vdv|tuyen_thu_es|ky_thu)$/.test(E.resolveJob(l.job.id)); }
  function discipline(l) { return E.resolveJob(l.job.id) === 'vdv' ? l.talentSub || 'thể thao' : E.resolveJob(l.job.id) === 'tuyen_thu_es' ? l.game || 'esports' : l.talentSub || 'cờ'; }
  E.recordSportResult = function (l, tier, result, key) {
    if (!athlete(l)) return;
    var records = l.flags.sportResults || (l.flags.sportResults = []), career = E.resolveJob(l.job.id), sport = discipline(l), year = l.birthYear + l.age;
    if (records.some(function (x) { return x.key === key && x.y === year && x.career === career && x.sport === sport; })) return;
    records.push({ career: career, sport: sport, tier: tier, result: result, key: key, y: year });
  };
  var safeMatch = E.DEC.tt_tran_lon.def.opts.filter(function (o) { return o.k === 'safe'; })[0];
  safeMatch.run = function (l, r, log) { var won = r() < .35; log(won ? 'Thắng nhẹ nhàng nhờ đồng đội tỏa sáng.' : 'Thua trận, bị huấn luyện viên phê bình thiếu quyết tâm.', 'neutral'); if (won) E.recordSportResult(l, 'national', 'win', 'big-match'); };
  E.sportPerformance = function (l) {
    if (!athlete(l)) return { points: 0, multiplier: 1, rank: 0 };
    var career = E.resolveJob(l.job.id), sport = discipline(l), year = l.birthYear + l.age, points = 0, seen = {};
    function add(key, tier, result, y) {
      if (seen[key] || y > year) return; seen[key] = true;
      var weight = { national: 5, regional: 12, world: 28, olympic: 45 }[tier] || 5;
      var placing = { vàng: 1, bạc: .6, đồng: .35, win: 1, record: .8 }[result] || 0;
      points += weight * placing * (year - y <= 3 ? 1 : .3);
    }
    (l.medals || []).forEach(function (m) {
      if (m.career && m.career !== career || m.sport && m.sport !== sport) return;
      if (!m.career && !m.sport && !(career === 'vdv' && (String(m.ev).includes('(' + sport + ')') || sport === 'bóng đá' && /ASEAN Cup/.test(m.ev)))) return;
      var tier = /Olympic|Thế vận hội/i.test(m.ev) ? 'olympic' : /thế giới|World|chung kết thế giới|Chung kết thế giới/i.test(m.ev) ? 'world' : /SEA Games|ASIAD|ASEAN|châu Á/i.test(m.ev) ? 'regional' : 'national';
      add('medal:' + m.ev + ':' + m.y + ':' + m.m, tier, m.m, m.y);
    });
    (l.flags.sportResults || []).forEach(function (x) { if (x.career === career && x.sport === sport) add('result:' + x.key + ':' + x.y, x.tier, x.result, x.y); });
    return { points: points, multiplier: 1 + Math.min(2.5, points * .025), rank: points >= 65 ? 3 : points >= 25 ? 2 : points >= 5 ? 1 : 0 };
  };
  var sportPay = E.sportPay;
  E.sportPromote = function (l, log) {
    if (!athlete(l)) return;
    var perf = E.sportPerformance(l), c = E.jobDef(l), rank = Math.min(perf.rank, c.t.length - 1);
    if (rank > l.job.rank) { l.job.rank = rank; log('Thành tích thi đấu giúp lên bậc: ' + E.jobTitle(l) + '.', 'good'); }
  };
  E.athletePay = function (l, rank) {
    var perf = E.sportPerformance(l), j = l.job, key = E.resolveJob(j.id) + ':' + discipline(l);
    if (j.sportKey !== key) { j.sportKey = key; j.sportContract = 1; j.sportPrevSalary = null; j.sportPaidFactor = 1; }
    j.sportContract = Math.max(j.sportContract || 1, perf.multiplier);
    return (E.resolveJob(j.id) === 'vdv' ? sportPay(l, rank) : 1) * j.sportContract;
  };
  var monthly = E.monthlyEst;
  E.monthlyEst = function (l, id, rank) {
    var base = monthly.apply(this, arguments), resolved = E.resolveJob(id);
    if (!/^(vdv|tuyen_thu_es|ky_thu)$/.test(resolved)) return base;
    var job = l.job && E.resolveJob(l.job.id) === resolved ? Object.assign({}, l.job) : { id: resolved, rank: rank || 0 };
    var fake = Object.assign({}, l, { job: job });
    return base * E.athletePay(fake, rank || 0);
  };
  E.sportSalary = function (l, income, log) {
    var j = l.job, factor = j.sportContract || 1, old = j.sportPaidFactor || 1;
    if (factor > old + .001) {
      if (j.sportPrevSalary > 0) income = Math.max(income, j.sportPrevSalary * factor / old);
      log('Thành tích thi đấu giúp thương lượng hợp đồng mới: hệ số lương thành tích ×' + factor.toFixed(2) + ' (trước ×' + old.toFixed(2) + '). Tiền thưởng giải được tính riêng.', 'good');
    }
    j.sportPaidFactor = factor; j.sportPrevSalary = income;
    return income;
  };
  var profile = E.profile;
  E.profile = function (l) {
    var p = profile(l);
    if (l.job) { var policy = E.pensionPolicy(l); p.jobInfo.push(policy.reason); if (policy.covered && !p.si) p.si = { yrs: 0, pension: null }; }
    if (athlete(l)) { var v = E.sportPerformance(l); p.jobInfo.push('Điểm thành tích: ' + v.points.toFixed(1) + ' · hệ số hợp đồng thành tích ×' + (l.job.sportContract || v.multiplier).toFixed(2)); }
    return p;
  };
})(globalThis.G);

;
/* ===== js/life53.js ===== */
/* v4.5.9 — ai thanh toán chi phí tuổi thơ phải rõ trong nhật ký. */
(function (G) {
  'use strict';
  var E = G.E, H = E.H;
  function payer(l) { var f = l.fam || {}, m = f.mAlive, d = f.fAlive && !f.noDad; if (m || d) return m && d ? 'Bố mẹ' : m ? 'Mẹ' : 'Bố'; var c = E.orphanCarer && E.orphanCarer(l); return c ? c.charAt(0).toUpperCase() + c.slice(1) : null; } // v7.1: trẻ mồ côi — người nuôi dưỡng trả
  E.childExpense = function (l, amount, reason, forced) {
    if (!(amount > 0) || !isFinite(amount)) return { ok: false, note: 'Khoản chi không hợp lệ.' };
    var who = payer(l), dependent = l.age < 18 && !l.indep;
    if (dependent && who) {
      var f = l.fam, yr = l.yr || (l.yr = { items: [] }), entries = yr.familyExpenses || (yr.familyExpenses = []);
      var income = (f.mAlive ? f.mInc || 0 : 0) + (f.fAlive && !f.noDad ? f.fInc || 0 : 0);
      var spent = entries.reduce(function (sum, x) { return sum + x.amount; }, 0), budget = income > 0 ? income * 12 * .1 : l.base * .02;
      if (!forced && amount + spent > budget) return { ok: false, note: who + ' chưa đủ ngân sách cho khoản này, chọn cách ít tốn kém hơn.' };
      entries.push({ t: reason, amount: amount, payer: who });
      return { ok: true, note: who + ' thanh toán ' + H.money(l, amount) + ' từ tiền gia đình; không trừ tiền tiết kiệm của bạn.' };
    }
    if (l.money < amount) return { ok: false, note: 'Bạn chưa đủ tiền tiết kiệm cho khoản này, cần chọn phương án ít tốn kém hơn.' };
    H.cash(l, -amount, reason);
    return { ok: true, note: 'Bạn thanh toán bằng tiền tiết kiệm của mình.' };
  };
  var birthday = E.DEC.sinh_nhat.def, party = birthday.opts.filter(function (o) { return o.k === 'party'; })[0];
  party.h = function (l) { return (l.age < 18 && !l.indep && payer(l) ? payer(l) + ' dự kiến trả ' : 'Bạn tự trả ') + H.money(l, l.base * (l.fam.q >= 4 ? .03 : .005)); };
  party.run = function (l, r, log) {
    var rich = l.fam.q >= 4, pay = E.childExpense(l, l.base * (rich ? .03 : .005), 'Tiệc sinh nhật');
    if (!pay.ok) { log(pay.note + ' Chưa tổ chức tiệc.', 'neutral'); return; }
    H.fx(l, { hap: 5, soc: 3 });
    log((rich ? 'Tiệc sinh nhật ở nhà hàng, có cả ảo thuật gia. Cả lớp trầm trồ. ' : 'Mấy đứa bạn đến nhà, cùng thổi nến, ăn bánh kem. ') + pay.note, 'good');
    if (r() < .25) H.mem(l, 'Bữa tiệc sinh nhật ' + l.age + ' tuổi.', 2);
  };
  // Hai tình huống nói rõ tiền của bố mẹ nhưng trước đây vẫn trừ ví của con.
  var phone = E.DEC.dien_thoai_be.def.opts.filter(function (o) { return o.k === 'game'; })[0];
  phone.run = function (l, r, log) { if (r() < .25) { var pay = E.childExpense(l, l.base * .01, 'Lỡ nạp game trên điện thoại', true); log(pay.ok ? 'Bấm nhầm nạp tiền trong game trên điện thoại. ' + pay.note + ' Bị nhắc nhở và hạn chế dùng điện thoại.' : pay.note, 'bad'); H.fx(l, { hap: -4 }); } else { log('Chơi game cả buổi chiều, giấu điện thoại về chỗ cũ trót lọt.', 'neutral'); H.fx(l, { hap: 2 }); } };
  var glass = E.DEC.da_bong_vo_kinh.def.opts.filter(function (o) { return o.k === 'admit'; })[0];
  glass.run = function (l, r, log) { var pay = E.childExpense(l, l.base * .005, 'Đền cửa kính', true); H.fx(l, { karma: 4 }); log(pay.ok ? 'Sang nhận lỗi về cửa kính bị vỡ. ' + pay.note + ' Bác hàng xóm khen bạn thật thà.' : 'Sang nhận lỗi về cửa kính bị vỡ. ' + pay.note + ' Xin hẹn việc bồi thường.', 'good'); };
})(globalThis.G);

;
/* ===== js/life54.js ===== */
/* v4.6.0 — đồng hành cùng từng người con; lựa chọn có tuổi, danh tính và thời hạn. */
(function (G) {
  'use strict';
  var E = G.E, H = E.H, U = G.U;
  function free(l) { return l.alive && !(l.jailUntil != null && l.age < l.jailUntil) && !(l.flags.military && l.age < l.flags.military) && !(l.abroad && l.abroad.trapped); }
  function age(l, k) { return l.age - k.born; }
  function init(l, k) {
    if (!k.parentId) { var id; do { id=l.id+':child:'+(l.flags.parentSerial=(l.flags.parentSerial||0)+1); } while((l.kids||[]).some(function(c){return c.parentId===id;})); k.parentId=id; }
    if (!k.upbringing) k.upbringing = { stress: 25, independence: U.clamp(10+age(l,k)*2,10,70), social: 40, seen: {}, count: 0 };
    k.upbringing.seen=k.upbringing.seen||{};
    if (!isFinite(k.upbringing.count)) k.upbringing.count=0;
    if (!isFinite(k.upbringing.stress)) k.upbringing.stress=25;
    if (!isFinite(k.upbringing.independence)) k.upbringing.independence=U.clamp(10+age(l,k)*2,10,70);
    if (!isFinite(k.upbringing.social)) k.upbringing.social=40;
    k.close=U.clamp(isFinite(k.close)&&k.close!=null?k.close:70,0,100); k.study=U.clamp(isFinite(k.study)&&k.study!=null?k.study:50,0,100);
    return k;
  }
  function children(l) { return (l.kids || []).filter(function (k) { return k.alive && age(l, k) >= 0; }).map(function (k) { return init(l, k); }); }
  function home(l, k) { return k.custody !== 'ex' && !l.abroad && !(k.jail && age(l, k) < k.jail); }
  function school(l, k) { return age(l, k) >= 6 && age(l, k) <= 17 && k.vice !== 'bỏ học'; }
  function budget(l, n) { return l.cur === 'vnd' ? n : n / 90 * l.base; }
  var CASES = [
    ['sleep',0,2,'Nhịp ngủ của bé','Bé thường thức giấc, việc chăm sóc khiến bạn thiếu ngủ.', 'Sắp xếp lại thời gian nghỉ và chăm bé', 'Thuê hỗ trợ chăm bé một buổi',2,'baby'],
    ['explore',0,2,'Bé khám phá thế giới','Bé thích chạm vào mọi thứ trong tầm tay.', 'Cùng bé chơi và sắp xếp không gian an toàn', 'Mua đồ chơi phù hợp lứa tuổi',.4,'baby'],
    ['routine',0,2,'Thời gian dành cho con','Bạn đang cân nhắc cách dành thời gian đều đặn cho bé.', 'Dành một khoảng thời gian mỗi ngày bên bé', 'Đăng ký buổi hoạt động cha mẹ và bé',.5,'baby'],
    ['preschool',3,5,'Làm quen môi trường mới','Con lo lắng khi tham gia một nhóm sinh hoạt dành cho trẻ nhỏ.', 'Cho con làm quen từng bước, không ép ngay', 'Đăng ký vài buổi trải nghiệm có hướng dẫn',.8,'social'],
    ['tantrum',3,5,'Con chưa biết diễn đạt cảm xúc','Con khóc và giận vì một việc không như ý.', 'Giúp con bình tĩnh rồi gọi tên cảm xúc', 'Mua sách tranh để cùng học về cảm xúc',.2,'social'],
    ['sharing',3,10,'Học cách chia sẻ','Con chưa muốn nhường lượt chơi cho bạn cùng nhóm.', 'Cùng con tập chờ lượt, nói rõ nhu cầu', 'Tham gia hoạt động nhóm nhỏ',.3,'social'],
    ['school',6,7,'Nhịp học đầu cấp','Con cần làm quen thời gian biểu và những bài học đầu tiên.', 'Cùng con lập thời gian biểu có cả giờ nghỉ', 'Mua bộ dụng cụ học tập vừa đủ',.5,'study'],
    ['homework',6,10,'Bài học khó hơn','Con nản khi gặp một dạng bài mới.', 'Gợi ý từng bước, để con tự làm phần còn lại', 'Đăng ký vài buổi hỗ trợ đúng phần còn yếu',.8,'study'],
    ['hobby',6,17,'Sở thích riêng của con','Con muốn thử một hoạt động ngoài việc học.', 'Tìm cách trải nghiệm ít tốn kém trước', 'Đăng ký khóa trải nghiệm ngắn theo ý con',1.2,'independence'],
    ['bully',8,14,'Một chuyện không vui ở lớp','Con kể bị bạn trêu chọc và không muốn nói thêm.', 'Lắng nghe, hỏi rõ rồi trao đổi với giáo viên', 'Thu xếp buổi hỗ trợ tâm lý học đường',.8,'study'],
    ['screens',8,17,'Thỏa thuận thời gian dùng màn hình','Giờ chơi game bắt đầu lấn vào giờ nghỉ và các việc khác.', 'Cùng con thống nhất giờ chơi và giờ nghỉ', 'Thử một hoạt động ngoài màn hình con chọn',.5,'independence'],
    ['pressure',10,17,'Áp lực thành tích','Con sợ làm bạn thất vọng khi điểm số chưa như mong muốn.', 'Nhìn vào tiến bộ, giảm so sánh với người khác', 'Tìm buổi hỗ trợ học tập phù hợp, có giờ nghỉ',1,'study'],
    ['privacy',11,17,'Khoảng riêng của con','Con muốn được tôn trọng nhật ký và những cuộc trò chuyện riêng.', 'Thống nhất ranh giới và cách tìm hỗ trợ khi cần', 'Mua sách kỹ năng để cùng trao đổi',.2,'independence'],
    ['friends',11,17,'Bạn bè của con','Con muốn tự chọn bạn và tham gia một nhóm hoạt động mới.', 'Hỏi về nhóm bạn, cùng thống nhất cách giữ an toàn', 'Hỗ trợ phí tham gia hoạt động con đã chọn',.6,'social'],
    ['money',12,17,'Tập quản lý tiền','Con muốn tự quản một khoản tiêu vặt nhỏ.', 'Cùng lập sổ chi tiêu và mục tiêu tiết kiệm', 'Cho con một khoản nhỏ, thống nhất giới hạn',.3,'independence'],
    ['future',15,17,'Định hướng sau phổ thông','Con đang phân vân giữa học tiếp, học nghề và các hướng khác.', 'Tìm hiểu sở thích, năng lực và nhiều lựa chọn', 'Tham gia buổi hướng nghiệp theo nguyện vọng con',.7,'study'],
    ['adult',18,24,'Con tập tự lập','Con muốn tự quyết nhiều việc nhưng vẫn cần người lắng nghe.', 'Lắng nghe kế hoạch, để con chịu trách nhiệm từng bước', 'Hỗ trợ một khóa kỹ năng con chủ động đề xuất',1.5,'independence'],
    ['boundaries',25,45,'Giữ kết nối khi con trưởng thành','Con đã lớn; cách quan tâm cũng cần thay đổi.', 'Hỏi con cần hỗ trợ gì, tôn trọng quyết định của con', 'Hẹn một bữa ăn, chỉ khi con đồng ý',.5,'social'],
    ['remote',0,45,'Đồng hành khi ở xa','Bạn không trực tiếp chăm con hằng ngày trong hoàn cảnh hiện tại.', 'Liên lạc và hỏi thăm người trực tiếp chăm bé', 'Gửi khoản hỗ trợ, trao đổi rõ mục đích sử dụng',1,'remote']
  ].map(function (x) { return { id:x[0], min:x[1], max:x[2], title:x[3], text:x[4], gentle:x[5], paid:x[6], cost:x[7], skill:x[8] }; });
  function allowed(l, k, c) {
    var a = age(l,k); if (a<c.min || a>c.max) return false;
    if (c.id==='remote') return !home(l,k);
    return home(l,k) && (c.skill!=='study' || a>=18 || school(l,k));
  }
  function slots(l,k) { var p=k.upbringing;return p.at!==l.age || p.count<2; }
  function pool(l,k) { return CASES.filter(function(c){return allowed(l,k,c) && (k.upbringing.seen[c.id]==null || l.age-k.upbringing.seen[c.id]>=3);}); }
  function eligible(l) { return free(l)?children(l).filter(function(k){return slots(l,k)&&pool(l,k).length;}):[]; }
  function target(l,d) { return children(l).filter(function(k){return d&&k.parentId===d.pid;})[0]; }
  function valid(l,d) {
    if(!free(l))return false;if(!d||!d.pid)return eligible(l).length>0;
    var k=target(l,d),c=CASES.filter(function(x){return x.id===d.caseId;})[0];
    return !!(k&&c&&d.at===l.age&&slots(l,k)&&allowed(l,k,c)&&pool(l,k).indexOf(c)>=0&&(!d.auto||l.flags.parentAutoAt!==l.age));
  }
  function finish(l,k,c,d) {var p=k.upbringing;if(p.at!==l.age){p.at=l.age;p.count=0;}p.count++;p.seen[c.id]=l.age;p.last=l.age;if(d.auto)l.flags.parentAutoAt=l.age;}
  function change(k,values) { Object.keys(values).forEach(function(key){if(key==='close'||key==='study')k[key]=U.clamp(k[key]+values[key],0,100);else k.upbringing[key]=U.clamp(k.upbringing[key]+values[key],0,100);}); }
  E.SC('nd_su_kien',{
    title:function(l,d){return d.title||'Đồng hành cùng con';},
    prep:function(l,r,arg){
      var ks=eligible(l),k=arg&&arg.pid?ks.filter(function(x){return x.parentId===arg.pid;})[0]:null;
      if(!k&&!(arg&&arg.pid)){ks.sort(function(a,b){return (a.upbringing.last==null?-1e6:a.upbringing.last)-(b.upbringing.last==null?-1e6:b.upbringing.last);});k=ks[0];}
      if(!k)return{};var c=U.pick(r,pool(l,k));return{pid:k.parentId,caseId:c.id,n:k.name,age:age(l,k),at:l.age,auto:!(arg&&arg.pid),title:c.title+' · '+k.name};
    },valid:valid,
    text:function(l,d){var c=CASES.filter(function(x){return x.id===d.caseId;})[0];if(!c)return'Chưa có tình huống phù hợp.';return d.n+' · '+d.age+' tuổi. '+(c.id==='remote'?(d.age<3?'Bạn trao đổi với người đang trực tiếp chăm bé về sinh hoạt và nhu cầu của bé.':'Bạn và con có thể liên lạc từ xa, theo hoàn cảnh và lịch phù hợp.') :c.text);},
    opts:[
      {k:'listen',l:function(l,d){var c=CASES.filter(function(x){return x.id===d.caseId;})[0];return c?c.id==='remote'&&d.age>=3?'Liên lạc hỏi thăm, lắng nghe con':c.gentle:'Lắng nghe';},ai:{w:1.4},run:function(l,r,log,d){act(l,r,log,d,'listen');}},
      {k:'paid',l:function(l,d){var c=CASES.filter(function(x){return x.id===d.caseId;})[0];return c?c.paid:'Hỗ trợ';},h:function(l,d){var c=CASES.filter(function(x){return x.id===d.caseId;})[0];return c?'Bạn chi '+H.money(l,budget(l,c.cost))+' từ tiền riêng':'';},req:function(l,d){var c=CASES.filter(function(x){return x.id===d.caseId;})[0];return valid(l,d)&&c&&l.money>=budget(l,c.cost);},ai:{w:.6},run:function(l,r,log,d){act(l,r,log,d,'paid');}},
      {k:'strict',l:function(l,d){return d.age>=18?'Áp đặt lựa chọn của mình lên con':d.age<3?'Bỏ qua tín hiệu khó chịu, giữ lịch cứng nhắc':'Áp đặt quy tắc, không nghe giải thích';},req:function(l,d){return d.caseId!=='remote';},ai:{w:.25},run:function(l,r,log,d){act(l,r,log,d,'strict');}},
      {k:'later',l:'Hẹn một thời điểm phù hợp để trao đổi lại',ai:{w:.4},run:function(l,r,log,d){act(l,r,log,d,'later');}}
    ]
  });
  function act(l,r,log,d,choice){
    if(!d||!d.pid||!valid(l,d))return;var k=target(l,d),c=CASES.filter(function(x){return x.id===d.caseId;})[0];
    var prefix=c.title+' · '+k.name+' ('+age(l,k)+' tuổi): ';
    if(choice==='paid'){var cost=budget(l,c.cost);if(l.money<cost)return;H.cash(l,-cost,'Đồng hành cùng '+k.name+': '+c.title);change(k,{close:3,stress:-3});if(c.skill!=='baby'&&c.skill!=='remote')change(k,c.skill==='study'&&school(l,k)?{study:2}:{independence:2});log(prefix+c.paid+'. Khoản chi do bạn trả; kết quả còn cần thời gian và sự tham gia của con.','good');}
    else if(choice==='listen'){change(k,{close:4,stress:-4});if(c.skill==='study'&&school(l,k))change(k,{study:2});if(c.skill==='independence'&&age(l,k)>=6)change(k,{independence:3});if(c.skill==='social')change(k,{social:3});log(prefix+(c.id==='remote'&&age(l,k)>=3?'Liên lạc hỏi thăm, lắng nghe con':c.gentle)+'. '+(age(l,k)>=18?'Bạn hỗ trợ, không quyết định thay con.':'Con được quan tâm; thay đổi cần được duy trì qua thời gian.'),'good');}
    else if(choice==='strict'){change(k,{close:-4,stress:6});log(prefix+'áp đặt ý mình khiến con căng thẳng và ít chia sẻ hơn. Không có gì bảo đảm cách này làm kết quả học tập tốt lên.','neutral');}
    else {change(k,{close:-1});log(prefix+'bạn hẹn sẽ trao đổi lại khi có thể tập trung hơn. Chưa có thay đổi lớn.','neutral');}
    finish(l,k,c,d);
  }
  E.SC('nuoi_day_con',{title:'Nuôi dạy và đồng hành cùng con',valid:function(l){return free(l)&&children(l).length>0;},prep:function(l){return{cs:children(l).slice(0,8).map(function(k){return{pid:k.parentId,n:k.name,age:age(l,k)};})};},text:'Chọn người con bạn muốn dành thời gian. Mỗi con tối đa hai tình huống trong một năm; hoạt động phụ thuộc độ tuổi và quyền chăm sóc.',
    opts:Array.from({length:8},function(_,i){return{k:'k'+i,l:function(l,d){var c=d.cs[i],k=target(l,c);return c?c.n+' · '+c.age+' tuổi'+(k&&!home(l,k)?' · liên lạc từ xa':''):'';},h:function(l,d){var k=target(l,d.cs[i]);return k?'Gắn kết '+Math.round(k.close)+'/100 · áp lực '+Math.round(k.upbringing.stress)+'/100':'';},req:function(l,d){var k=target(l,d.cs[i]);return !!(k&&slots(l,k)&&pool(l,k).length);},run:function(l,r,log,d){var k=target(l,d.cs[i]);if(k&&free(l)&&slots(l,k)&&pool(l,k).length)l.pending.unshift(E.DEC.nd_su_kien.make(l,r,{pid:k.parentId}));}};}).concat([{k:'no',l:'Để dịp khác',run:function(){}}])});
  var familyGroup=E.ACT.filter(function(a){return a.id==='sinh_con';})[0];
  E.ACT.push({id:'nuoi_day_con',g:familyGroup?familyGroup.g:'Gia đình & bạn bè',l:'Nuôi dạy / đồng hành cùng con',min:16,avail:function(l){return eligible(l).length?true:'Chưa có con hoặc chưa có tình huống phù hợp';},ai:{w:.15}});
  E.TRIG.push({id:'nd_su_kien',when:function(l){return eligible(l).length>0&&l.flags.parentAutoAt!==l.age;},p:.55,cd:1,rep:true});
  E.PARENTING={children:children,eligible:eligible,valid:valid,home:home,cases:CASES,pool:pool};
  E.parentingYear=function(l,r,log,a){if(!l.alive)return;children(l).forEach(function(k){var p=k.upbringing;if(p.yearAt===a)return;p.yearAt=a;if(school(l,k))k.study=U.clamp(k.study+(p.stress>=70?-1:p.stress<=35&&p.independence>=45?.5:0),0,100);});};
  E.HOOKS.year.push(E.parentingYear);
  // Không dùng học lực kém để suy diễn rằng con cờ bạc, vay tín dụng đen.
  function gambling(l){return(l.kids||[]).filter(function(k){return k.alive&&age(l,k)>=18&&age(l,k)<=45&&(/cờ bạc|cá độ/.test(k.vice||'')||k.gamblingDebt>0);});}
  E.DEC.con_pha_gia.valid=function(l,d){return gambling(l).some(function(k){return !d||!d.n||k.name===d.n;});};
  E.DEC.con_pha_gia.def.prep=function(l,r){var k=U.pick(r,gambling(l));return k?{n:k.name,debt:k.gamblingDebt||Math.round(80+r()*400)}:{};};
  E.TRIG.filter(function(t){return t.id==='con_pha_gia';}).forEach(function(t){t.when=function(l){return free(l)&&gambling(l).length>0;};});
  // Học khá không đồng nghĩa đã là bác sĩ, tiến sĩ hoặc có công ty ở tuổi 18.
  function achievers(l){return(l.kids||[]).filter(function(k){return k.alive&&age(l,k)>=18&&age(l,k)<=45&&(k.study==null?50:k.study)>=65;});}
  E.DEC.con_thanh_tai.valid=function(l,d){return achievers(l).some(function(k){return !d||!d.n||k.name===d.n;});};
  E.DEC.con_thanh_tai.def.prep=function(l,r){var k=U.pick(r,achievers(l));if(!k)return{};var text=k.job?'nỗ lực trong công việc '+E.kidTitle(k):k.edu>=5&&age(l,k)>=22?'hoàn thành bậc học và đang xây dựng hướng đi riêng':k.uniUntil?'ngày càng chủ động trong việc học':'đã tiến bộ và tự tin hơn khi lên kế hoạch tương lai';return{n:k.name,t:text};};
  ['con_hoc','con_hu'].forEach(function(id){var D=E.DEC[id];function pupils(l){return children(l).filter(function(k){return school(l,k)&&home(l,k)&&age(l,k)>=(id==='con_hu'?12:6);});}D.valid=function(l,d){return free(l)&&pupils(l).some(function(k){return !d||!d.n||d.n===k.name;});};D.def.prep=function(l){var k=pupils(l)[0];return k?{n:k.name}:{};};});
  E.DEC.con_hoc.def.opts.forEach(function(o){if(o.k==='extra')o.req=function(l){return l.money>=l.base*.05;};if(o.k==='intl')o.req=function(l){return l.money>=l.base*.6;};});
  var oldSchoolApply=E.DEC.con_hoc.apply;
  E.DEC.con_hoc.apply=function(l,d,k,r,log){if((k==='extra'&&l.money<l.base*.05)||(k==='intl'&&l.money<l.base*.6))k='free';return oldSchoolApply.call(this,l,d,k,r,log);};
  // Bảo vệ các chuỗi cũ khi một người con đã mất trong lúc chờ quyết định.
  ['con_18','con_hoc','con_hu','con_lac_loi','con_von','con_thanh_tai','con_pha_gia','con_sau_ly_hon'].forEach(function(id){var D=E.DEC[id];if(!D)return;var v=D.valid,ap=D.apply;D.valid=function(l,d){if(v&&!v(l,d))return false;if(!d||!d.n)return true;var matches=(l.kids||[]).filter(function(k){return k.name===d.n;});return matches.length===1&&matches[0].alive;};D.apply=function(l,d){if(!D.valid(l,d.data))return;return ap.apply(this,arguments);};});
})(globalThis.G);

;
/* ===== js/life55.js ===== */
/* v4.6.1 — hồ sơ đúng tuổi, điều kiện hẹn hò và tình huống theo nghề. */
(function(G){
  'use strict';
  var E=G.E,H=E.H,U=G.U;
  function free(l){return l.alive&&!(l.jailUntil!=null&&l.age<l.jailUntil)&&!(l.flags.military&&l.age<l.flags.military)&&!(l.abroad&&l.abroad.trapped);}
  function normalize(l,p,r){
    if(!p)return;
    var c=p.jobId&&E.CAR[p.jobId];
    if(!c&&p.job)c=Object.keys(E.CAR).map(function(id){return E.CAR[id];}).filter(function(j){return j.t.indexOf(p.job)>=0;})[0];
    if(p.age<18){p.job=p.age<15?'học sinh THCS':'học sinh THPT';p.jobId=null;p.inc=0;}
    else if(/^học sinh/.test(p.job||'')||(p.job==='sinh viên'&&p.age>=22)||(c&&((c.minAge||0)>p.age||(c.cat==='med'&&p.age<24)||((c.edu||0)>=5&&p.age<22))))H.partnerJob(l,p,r);
  }
  E.normalizePartnerAge=normalize;
  var love=E.DEC.love,mk=love.make,ap=love.apply;
  love.make=function(l,r,arg){var d=mk.call(this,l,r,arg),p=d.data.p,old=p.job;normalize(l,p,r);if(old!==p.job){var phrase=old==='sinh viên'?'đang là sinh viên':old==='đã nghỉ hưu'?'đã nghỉ hưu':'đang làm '+old;d.text=d.text.replace(phrase,/^học sinh/.test(p.job)?'đang là '+p.job:p.job==='sinh viên'?'đang là sinh viên':'đang làm '+p.job);}return d;};
  love.apply=function(l,d,k,r,log){normalize(l,d.data.p,r);return ap.call(this,l,d,k,r,log);};
  function repairLove(l,d,r){if(!d||!d.data||!d.data.p)return;var p=d.data.p,old=p.job;normalize(l,p,r);if(old!==p.job&&typeof d.text==='string'){var phrase=old==='sinh viên'?'đang là sinh viên':old==='đã nghỉ hưu'?'đã nghỉ hưu':'đang làm '+old;d.text=d.text.replace(phrase,/^học sinh/.test(p.job)?'đang là '+p.job:p.job==='sinh viên'?'đang là sinh viên':'đang làm '+p.job);}}
  var migration=E.migrateExt;
  E.migrateExt=function(l){if(migration)migration(l);var r=function(){return U.rand(l);};normalize(l,l.partner,r);(l.pending||[]).forEach(function(d){if(d.id==='love')repairLove(l,d,r);});};
  E.HOOKS.year.push(function(l,r){normalize(l,l.partner,r);});
  E.SC('tc_dieu_kien',{title:'Chu cấp và chương trình hẹn hò',text:function(l){return 'Quan hệ chu cấp: từ 18 tuổi, bạn có thể ngẫu nhiên nhận lời đề nghị của người lớn tuổi, có thu nhập cao. Chỉ sau khi bạn đồng ý và quan hệ còn tiếp tục, mục “Quan hệ chu cấp / đặt lại ranh giới” mới mở. Bạn được thương lượng hoặc chấm dứt, không bắt buộc nhận lời.\n\nNgười ấy là ai: vào Tình cảm → Đăng ký show hẹn hò trên truyền hình → Người ấy là ai. Điều kiện trong game: 20–42 tuổi, độc thân, sinh sống tại Việt Nam, không bị giam hay đang nghĩa vụ; hồ sơ có học vấn cao, độ nổi tiếng hoặc khả năng giao tiếp phù hợp. Một lần đăng ký mỗi năm. Đăng ký không bảo đảm được ghép đôi. Định dạng hiện tại dành cho hẹn hò nam–nữ; Bạn muốn hẹn hò có lựa chọn theo xu hướng của nhân vật.\n\nHiện tại: '+l.age+' tuổi; '+(l.partner?'đang có người yêu / bạn đời':'độc thân')+'; '+(E.sponsorActive&&E.sponsorActive(l)?'có quan hệ chu cấp đang tiếp tục':'chưa có quan hệ chu cấp đang tiếp tục')+'.';},opts:[{k:'ok',l:'Đã hiểu',run:function(){}}]});
  E.ACT.push({id:'tc_dieu_kien',g:'Tình cảm',l:'Cách mở chu cấp / Người ấy là ai',min:16,sc:'tc_dieu_kien',ai:{w:0}});
  Object.keys(E.DEC).filter(function(id){return /^hh_/.test(id);}).forEach(function(id){var d=E.DEC[id],before=d.valid,make=d.make;d.make=function(l){var scene=make.apply(this,arguments);scene.data.showAt=l.age;return scene;};d.valid=function(l,data){return free(l)&&!l.partner&&l.age>=20&&l.age<=42&&(!data||data.showAt==null||data.showAt===l.age)&&(id!=='hh_moi'||l.flags.datingShowAt!==l.age)&&(!before||before(l,data));};});
  var invitation=E.DEC.hh_moi,apply=invitation.apply;
  invitation.apply=function(l,d,k,r,log){if(k!=='khong'&&d.opts.some(function(o){return o.k===k;}))l.flags.datingShowAt=l.age;return apply.call(this,l,d,k,r,log);};
  E.ACT.forEach(function(a){if(a.id==='show_hen_ho'){var avail=a.avail;a.avail=function(l){return l.flags.datingShowAt===l.age?'Đã đăng ký chương trình trong năm nay':avail(l);};}});
  var rows=[
    ['office','Đối chiếu dữ liệu','Hai bản báo cáo có số liệu chưa khớp.','Kiểm tra nguồn dữ liệu và ghi lại cách đối chiếu','Học thêm công cụ kiểm tra dữ liệu'],
    ['office','Bàn giao dự án','Một dự án cần chuyển sang giai đoạn mới.','Lập danh sách đầu việc và xác nhận người phụ trách','Bổ sung kỹ năng quản lý dự án'],
    ['worker','Chất lượng vật tư','Một lô vật tư có dấu hiệu khác tiêu chuẩn.','Kiểm tra tiêu chuẩn trước khi sử dụng','Học thêm cách kiểm tra chất lượng'],
    ['worker','Quy trình thiết bị','Thiết bị quen thuộc có quy trình vận hành mới.','Đọc hướng dẫn và kiểm tra an toàn','Tham gia buổi thực hành có hướng dẫn'],
    ['sale','Cam kết với khách','Khách muốn làm rõ một điều khoản trước khi quyết định.','Giải thích đúng phạm vi, xác nhận bằng văn bản','Bồi dưỡng kỹ năng tư vấn'],
    ['sale','Báo giá thay đổi','Giá đầu vào thay đổi khi bạn chuẩn bị tư vấn.','Cập nhật giá và trao đổi minh bạch','Học cách dự toán và quản lý báo giá'],
    ['edu','Người học cần hỗ trợ','Phản hồi cho thấy một phần nội dung còn khó tiếp cận.','Điều chỉnh cách giải thích và hỏi lại người học','Bồi dưỡng phương pháp giảng dạy'],
    ['edu','Kế hoạch học tập','Bạn cần sắp xếp nội dung trong thời gian hữu hạn.','Ưu tiên kiến thức cốt lõi, giữ thời gian ôn tập','Tham khảo học liệu có bản quyền'],
    ['uniform','Bàn giao nhiệm vụ','Thông tin của một nhiệm vụ cần được xác nhận đầy đủ.','Đối chiếu hồ sơ và báo cáo theo đúng quy trình','Ôn tập kỹ năng chuyên môn'],
    ['uniform','Phối hợp lực lượng','Nhiệm vụ chung yêu cầu phối hợp nhiều bộ phận.','Làm rõ vai trò, liên lạc và phương án an toàn','Tham gia buổi diễn tập phù hợp nhiệm vụ'],
    ['state','Hồ sơ cần bổ sung','Một hồ sơ thiếu giấy tờ khiến người dân phải chờ.','Hướng dẫn rõ phần còn thiếu, tránh yêu cầu lặp lại','Bồi dưỡng nghiệp vụ xử lý hồ sơ'],
    ['state','Cải thiện quy trình','Một quy trình có bước trùng lặp gây chậm trễ.','Đề xuất cải tiến đúng thẩm quyền','Học công cụ hỗ trợ xử lý công việc'],
    ['service','Lịch phục vụ thay đổi','Lịch phục vụ có thay đổi cần được xác nhận.','Kiểm tra khả năng đáp ứng trước khi hứa','Bồi dưỡng nghiệp vụ tổ chức công việc'],
    ['service','Thông tin bàn giao','Một yêu cầu quan trọng có thể bị bỏ sót khi bàn giao.','Ghi nhận và xác nhận lại thông tin','Tham gia khóa giao tiếp trong dịch vụ'],
    ['beauty','Vệ sinh dụng cụ','Dụng cụ cần được kiểm tra trước lượt phục vụ tiếp theo.','Tuân thủ vệ sinh và thay dụng cụ không đạt','Bồi dưỡng kỹ năng vệ sinh chuyên ngành'],
    ['beauty','Kỳ vọng của khách','Khách đưa mẫu nhưng kết quả phụ thuộc điều kiện thực tế.','Trao đổi giới hạn và chỉ làm khi khách đồng ý','Học kỹ thuật phù hợp chuyên môn'],
    ['farm','Chi phí đầu vào','Giá vật tư sản xuất có biến động.','Tính lại chi phí và chọn phương án vừa sức','Học cách lập kế hoạch sản xuất'],
    ['farm','Bảo quản sản phẩm','Sản phẩm cần được bảo quản để giảm hao hụt.','Kiểm tra điều kiện bảo quản và đầu ra','Bồi dưỡng kỹ thuật bảo quản'],
    ['biz','Đối tác cung ứng','Một đối tác mới đề nghị điều kiện hấp dẫn nhưng chưa rõ năng lực.','Xác minh năng lực, thử hợp đồng nhỏ trước','Học kỹ năng đánh giá đối tác'],
    ['biz','Chi phí vận hành','Bạn muốn biết khâu nào đang tiêu tốn nguồn lực.','Đối chiếu sổ sách trước khi quyết định','Bồi dưỡng kỹ năng quản trị chi phí'],
    ['free','Phạm vi công việc','Yêu cầu mới vượt phần việc đã thỏa thuận.','Thương lượng lại phạm vi và thời hạn','Học cách lập hợp đồng dịch vụ'],
    ['free','Quyền sử dụng tài liệu','Một tài liệu có điều kiện sử dụng chưa rõ.','Xác minh quyền sử dụng hoặc chọn tài liệu thay thế','Mua khóa học về bản quyền nghề nghiệp'],
    ['law','Đối chiếu chứng cứ','Các tài liệu của một vụ việc có chi tiết chưa khớp.','Đối chiếu hồ sơ, xác minh thông tin trước khi kết luận','Bồi dưỡng kỹ năng nghiên cứu hồ sơ'],
    ['law','Thời hạn thủ tục','Một thủ tục có thời hạn cần theo dõi chặt chẽ.','Kiểm tra mốc thời gian và thông báo rõ trách nhiệm','Bồi dưỡng nghiệp vụ quản lý hồ sơ'],
    ['media','Kiểm chứng thông tin','Một nguồn tin cung cấp chi tiết chưa được xác nhận.','Đối chiếu nguồn độc lập trước khi sử dụng','Bồi dưỡng kỹ năng kiểm chứng'],
    ['media','Đính chính nội dung','Một nội dung cũ cần cập nhật cho chính xác.','Kiểm tra, đính chính và ghi rõ thay đổi','Học cách quản lý nguồn tư liệu'],
    ['poor','Sắp xếp công việc','Thời tiết thay đổi ảnh hưởng việc làm và sinh hoạt.','Điều chỉnh kế hoạch, ưu tiên an toàn','Học thêm kỹ năng phù hợp công việc'],
    ['poor','Giữ uy tín nghề','Một công việc cần xác nhận rõ yêu cầu để tránh hiểu lầm.','Trao đổi rõ công sức và điều kiện thực hiện','Bồi dưỡng kỹ năng giao tiếp với khách']
  ];
  var cases=rows.map(function(x,i){return{id:'case'+i,cat:x[0],title:x[1],text:x[2],care:x[3],learn:x[4]};});
  function state(l){if(!l.flags.careerStories)l.flags.careerStories={seen:{},count:0};return l.flags.careerStories;}
  function pool(l){if(!free(l)||!l.job)return[];var c=E.jobDef(l),s=state(l);if(!c||l.job.id==='an_xin'||c.sec==='crime'||(s.at===l.age&&s.count>=2))return[];return cases.filter(function(x){var at=s.seen[l.job.id+':'+x.id];return x.cat===c.cat&&(at==null||l.age-at>=4);});}
  function token(l){if(!l.job.storyToken){l.flags.careerStorySerial=(l.flags.careerStorySerial||0)+1;l.job.storyToken=l.flags.careerStorySerial;}return l.job.storyToken;}
  function valid(l,d){if(!d||!d.caseId)return pool(l).length>0;return !!(l.job&&d.at===l.age&&d.job===l.job.id&&d.token===token(l)&&d.rank===(l.job.rank||0)&&pool(l).some(function(c){return c.id===d.caseId;}));}
  function cost(l){return l.cur==='vnd'?.8:l.base*.8/90;}
  function outcome(l,r,log,d,k){if(!valid(l,d))return;var s=state(l),c=cases.filter(function(x){return x.id===d.caseId;})[0];if(k==='learn'&&l.money<cost(l))return;if(s.at!==l.age){s.at=l.age;s.count=0;}s.count++;s.seen[l.job.id+':'+c.id]=l.age;
    var rep=k==='care'?3:k==='learn'?4:k==='rush'?-4:0;l.job.rep=U.clamp((l.job.rep==null?50:l.job.rep)+rep,0,100);
    if(k==='learn'){H.cash(l,-cost(l),'Bồi dưỡng kỹ năng nghề');H.fx(l,{kno:1});log(c.title+': bạn tự chi '+H.money(l,cost(l))+' từ tiền riêng để bồi dưỡng kỹ năng; chưa đồng nghĩa được thăng chức.','neutral');}
    else if(k==='care'){H.fx(l,{kno:.5});log(c.title+' · '+d.role+': bạn xử lý cẩn thận, giữ uy tín trong nghề.','good');}
    else if(k==='rush'){if(l.mind)l.mind.stress=U.clamp(l.mind.stress+3,0,100);log(c.title+' · '+d.role+': làm vội khiến chất lượng giảm, bạn cần khắc phục.','bad');}
    else log(c.title+': '+U.pick(r,['bạn tạm hoãn để thu xếp công việc, chưa có kết quả mới.','việc này để sang tuần sau, trước mắt chưa có gì thay đổi.','bạn gác lại để lo việc gấp hơn, chưa có kết quả.','bạn xin dời lịch, mọi chuyện vẫn đang chờ.']),'neutral');
  }
  E.SC('nghe_chuyen_moi',{title:function(l,d){return d.title||'Tình huống trong nghề';},valid:valid,prep:function(l,r){var p=pool(l);if(!p.length)return{};var c=U.pick(r,p),j=E.jobDef(l);return{caseId:c.id,at:l.age,job:l.job.id,rank:l.job.rank||0,token:token(l),title:c.title,role:j.t[l.job.rank||0]};},text:function(l,d){var c=cases.filter(function(x){return x.id===d.caseId;})[0];return c?d.role+': '+c.text+'':'';},opts:[
    {k:'care',l:function(l,d){var c=cases.filter(function(x){return x.id===d.caseId;})[0];return c?c.care:'Xử lý cẩn thận';},run:function(l,r,log,d){outcome(l,r,log,d,'care');}},
    {k:'learn',l:function(l,d){var c=cases.filter(function(x){return x.id===d.caseId;})[0];return(c?c.learn:'Bồi dưỡng kỹ năng')+' · tự chi '+H.money(l,cost(l));},req:function(l){return l.money>=cost(l);},run:function(l,r,log,d){outcome(l,r,log,d,'learn');}},
    {k:'rush',l:'Làm qua loa để xong sớm',run:function(l,r,log,d){outcome(l,r,log,d,'rush');}},
    {k:'later',l:'Tạm hoãn để sắp xếp lại',run:function(l,r,log,d){outcome(l,r,log,d,'later');}}
  ]});
  E.ACT.push({id:'nghe_chuyen_moi',g:'Công việc',l:'Tình huống chuyên môn trong nghề',min:18,sc:'nghe_chuyen_moi',avail:function(l){return pool(l).length?true:'Chưa có tình huống mới phù hợp công việc';},ai:{w:.2}});
  E.TRIG.push({id:'nghe_chuyen_moi',when:function(l){return pool(l).length>0;},p:.45,cd:2,rep:true});
  E.CAREER_STORIES={cases:cases,pool:pool,valid:valid};
})(G);

;
/* ===== js/life56.js ===== */
/* v4.6.4 — quê hương theo 63 tỉnh/thành trước sáp nhập, du lịch cùng người yêu/bạn đời.
   Địa danh và đặc sản là gợi ý văn hóa; ngân sách chuyến đi là cân bằng game.
   Nguồn đối chiếu và quy ước: docs/heritage-sources.md. */
(function(G){
  'use strict';
  var E=G.E,H=E.H,U=G.U,VN=G.VN;
  var ROWS=[
    ['Hà Nội','hồ Hoàn Kiếm','Văn Miếu – Quốc Tử Giám','phở Hà Nội','bún chả'],
    ['Hà Giang','cao nguyên đá Đồng Văn','cột cờ Lũng Cú','cháo ấu tẩu','bánh tam giác mạch'],
    ['Cao Bằng','thác Bản Giốc','khu di tích Pác Bó','bánh cuốn Cao Bằng','hạt dẻ Trùng Khánh'],
    ['Bắc Kạn','hồ Ba Bể','động Hua Mạ','miến dong Na Rì','gạo nếp Khẩu Nua Lếch'],
    ['Tuyên Quang','khu di tích Tân Trào','hồ Na Hang','cam sành Hàm Yên','bánh gai Chiêm Hóa'],
    ['Lào Cai','Sa Pa','chợ Bắc Hà','thắng cố','cơm lam'],
    ['Điện Biên','di tích chiến trường Điện Biên Phủ','hồ Pá Khoang','xôi nếp nương','pa pỉnh tộp'],
    ['Lai Châu','bản Sì Thâu Chải','cao nguyên Sìn Hồ','xôi tím','lợn bản nướng'],
    ['Sơn La','cao nguyên Mộc Châu','di tích Nhà tù Sơn La','bê chao Mộc Châu','sữa Mộc Châu'],
    ['Yên Bái','ruộng bậc thang Mù Cang Chải','hồ Thác Bà','xôi Tú Lệ','cốm Tú Lệ'],
    ['Hòa Bình','thung lũng Mai Châu','hồ Hòa Bình','cơm lam','cá sông Đà'],
    ['Thái Nguyên','hồ Núi Cốc','ATK Định Hóa','chè Tân Cương','bánh chưng Bờ Đậu'],
    ['Lạng Sơn','động Tam Thanh','Mẫu Sơn','vịt quay Lạng Sơn','phở chua'],
    ['Quảng Ninh','vịnh Hạ Long','Yên Tử','chả mực Hạ Long','bún bề bề'],
    ['Bắc Giang','Tây Yên Tử','chùa Vĩnh Nghiêm','vải thiều Lục Ngạn','mỳ Chũ'],
    ['Phú Thọ','khu di tích Đền Hùng','Vườn quốc gia Xuân Sơn','thịt chua Thanh Sơn','bánh tai'],
    ['Vĩnh Phúc','Tam Đảo','hồ Đại Lải','ngọn su su Tam Đảo','bánh trùng Vĩnh Tường'],
    ['Bắc Ninh','chùa Dâu','đền Đô','bánh phu thê Đình Bảng','bánh tẻ làng Chờ'],
    ['Hải Dương','Côn Sơn – Kiếp Bạc','đảo cò Chi Lăng Nam','bánh đậu xanh','bánh gai Ninh Giang'],
    ['Hải Phòng','đảo Cát Bà','Đồ Sơn','bánh đa cua','bánh mì cay'],
    ['Hưng Yên','Phố Hiến','đền Chử Đồng Tử','nhãn lồng Hưng Yên','bún thang lươn Phố Hiến'],
    ['Thái Bình','chùa Keo','Cồn Đen','canh cá Quỳnh Côi','bánh cáy làng Nguyễn'],
    ['Hà Nam','khu du lịch Tam Chúc','nhà Bá Kiến ở làng Đại Hoàng','chuối ngự Đại Hoàng','cá kho làng Vũ Đại'],
    ['Nam Định','đền Trần','Vườn quốc gia Xuân Thủy','phở bò Nam Định','bánh nhãn Hải Hậu'],
    ['Ninh Bình','quần thể Tràng An','Tam Cốc – Bích Động','cơm cháy Ninh Bình','thịt dê núi'],
    ['Thanh Hóa','biển Sầm Sơn','Pù Luông','nem chua Thanh Hóa','chả tôm'],
    ['Nghệ An','khu di tích Kim Liên','Vườn quốc gia Pù Mát','cháo lươn','bánh mướt'],
    ['Hà Tĩnh','Ngã ba Đồng Lộc','chùa Hương Tích','kẹo cu đơ','bưởi Phúc Trạch'],
    ['Quảng Bình','Phong Nha – Kẻ Bàng','biển Nhật Lệ','cháo canh','bánh lọc Quảng Bình'],
    ['Quảng Trị','đôi bờ Hiền Lương – Bến Hải','Thành cổ Quảng Trị','bún hến Mai Xá','cháo vạt giường'],
    ['Thừa Thiên Huế','Đại Nội Huế','chùa Thiên Mụ','bún bò Huế','cơm hến'],
    ['Đà Nẵng','biển Mỹ Khê','Ngũ Hành Sơn','mì Quảng','bánh tráng cuốn thịt heo'],
    ['Quảng Nam','phố cổ Hội An','thánh địa Mỹ Sơn','cao lầu Hội An','mì Quảng'],
    ['Quảng Ngãi','đảo Lý Sơn','khu chứng tích Sơn Mỹ','don','kẹo gương'],
    ['Bình Định','tháp Đôi Quy Nhơn','Kỳ Co','bánh ít lá gai','bánh hỏi lòng heo'],
    ['Phú Yên','Gành Đá Đĩa','Mũi Điện','bánh canh hẹ','cá ngừ đại dương'],
    ['Khánh Hòa','Tháp Bà Ponagar','vịnh Nha Trang','bún cá sứa','nem nướng Ninh Hòa'],
    ['Ninh Thuận','tháp Po Klong Garai','vịnh Vĩnh Hy','nho Phan Rang','bánh căn'],
    ['Bình Thuận','Mũi Né','Bàu Trắng','bánh canh chả cá','bánh quai vạc'],
    ['Kon Tum','Nhà thờ gỗ Kon Tum','Măng Đen','gỏi lá Kon Tum','cơm lam'],
    ['Gia Lai','Biển Hồ','núi lửa Chư Đăng Ya','phở khô Gia Lai','bún mắm cua'],
    ['Đắk Lắk','Buôn Đôn','thác Dray Nur','cà phê Buôn Ma Thuột','cơm lam'],
    ['Đắk Nông','hồ Tà Đùng','thác Đray Sáp','canh thụt','gà xào măng chua'],
    ['Lâm Đồng','hồ Xuân Hương','Vườn quốc gia Bidoup – Núi Bà','bánh căn Đà Lạt','hồng treo gió'],
    ['Bình Phước','Vườn quốc gia Bù Gia Mập','Sóc Bom Bo','hạt điều Bình Phước','cơm lam'],
    ['Tây Ninh','núi Bà Đen','Tòa Thánh Tây Ninh','bánh tráng phơi sương Trảng Bàng','muối tôm'],
    ['Bình Dương','vườn cây Lái Thiêu','chùa Bà Thiên Hậu','gỏi gà măng cụt','bánh bèo bì'],
    ['Đồng Nai','Vườn quốc gia Cát Tiên','khu du lịch Bửu Long','gỏi cá Biên Hòa','bưởi Tân Triều'],
    ['Bà Rịa – Vũng Tàu','Côn Đảo','biển Vũng Tàu','bánh khọt','bánh canh Long Hương'],
    ['TP. Hồ Chí Minh','chợ Bến Thành','địa đạo Củ Chi','cơm tấm','bánh mì Sài Gòn'],
    ['Long An','làng nổi Tân Lập','khu bảo tồn đất ngập nước Láng Sen','gạo Nàng Thơm Chợ Đào','lạp xưởng Cần Đước'],
    ['Tiền Giang','cù lao Thới Sơn','biển Tân Thành','hủ tiếu Mỹ Tho','vú sữa Lò Rèn'],
    ['Bến Tre','Cồn Phụng','cù lao Minh','kẹo dừa','bánh tráng Mỹ Lồng'],
    ['Trà Vinh','Ao Bà Om','chùa Âng','bún nước lèo','bánh tét Trà Cuôn'],
    ['Vĩnh Long','cù lao An Bình','Văn Thánh Miếu Vĩnh Long','bưởi Năm Roi Bình Minh','khoai lang Bình Tân'],
    ['Đồng Tháp','Vườn quốc gia Tràm Chim','làng hoa Sa Đéc','nem Lai Vung','hủ tiếu Sa Đéc'],
    ['An Giang','rừng tràm Trà Sư','núi Sam','bún cá Châu Đốc','tung lò mò'],
    ['Kiên Giang','đảo Phú Quốc','Vườn quốc gia U Minh Thượng','bún kèn Hà Tiên','gỏi cá trích'],
    ['Cần Thơ','chợ nổi Cái Răng','bến Ninh Kiều','bánh cống','bánh tét lá cẩm'],
    ['Hậu Giang','Ngã Bảy','khu bảo tồn Lung Ngọc Hoàng','chả cá thác lác','khóm Cầu Đúc'],
    ['Sóc Trăng','chùa Dơi','chùa Chén Kiểu','bánh pía','bún nước lèo'],
    ['Bạc Liêu','khu lưu niệm nghệ thuật đờn ca tài tử và nhạc sĩ Cao Văn Lầu','cánh đồng điện gió Bạc Liêu','bánh tằm Ngan Dừa','bún bò cay'],
    ['Cà Mau','Mũi Cà Mau','Vườn quốc gia U Minh Hạ','cua Năm Căn','ba khía Rạch Gốc']
  ];
  var DATA=Object.create(null);ROWS.forEach(function(x){DATA[x[0]]={name:x[0],places:[x[1],x[2]],foods:[x[3],x[4]],region:VN.byName[x[0]].region};});
  function profile(name){return DATA[name==='Huế'?'Thừa Thiên Huế':name]||null;}
  function own(l){return l.country==='VN'&&l.prov?profile(l.prov.old):null;}
  function hash(s){var h=2166136261;for(var i=0;i<s.length;i++)h=Math.imul(h^s.charCodeAt(i),16777619);return h|0;}
  function ensure(l,p,country){
    if(!p)return null;l.flags=l.flags||{};
    if(!p.heritageId)p.heritageId=String(l.id||l.seed||'life')+':partner:'+(l.flags.heritageSerial=(l.flags.heritageSerial||0)+1);
    if(!p.homeCountry)p.homeCountry=country||p.country||l.country;
    if(p.homeCountry==='VN'&&!profile(p.home63)){var holder={rs:hash(p.heritageId+':'+p.name)},r=function(){return U.rand(holder);};p.home63=U.wpick(r,VN.P63,function(x){return x.pop;}).name;}
    return p.homeCountry==='VN'?profile(p.home63):null;
  }
  // v5.8.0: chơi 34 tỉnh/thành thì gọi quê theo tên sau sáp nhập; chơi 63 tỉnh/thành thì giữ tên cũ — không ghi chú thêm
  function pname(l,n){if(l.variant!=='34')return n;var p=VN.byName&&VN.byName[n];return p&&p.newName||n;}
  function current(l){
    var code=l.abroad&&l.abroad.code||l.country;if(code!=='VN')return{code:code,province:null};
    var city=l.cityStudent&&l.cityStudent.city||l.movedTo;
    if(!city)return{code:'VN',province:own(l)&&own(l).name};
    var found=VN.P63.filter(function(p){return p.name===city||p.city===city;})[0];return{code:'VN',province:found?found.name:null};
  }
  function locationKey(l){var c=current(l);return[c.code,c.province,l.cur,l.movedTo||'',l.cityStudent&&l.cityStudent.city||''].join('|');}
  function free(l){return l.alive&&l.age>=18&&!(l.jailUntil!=null&&l.age<l.jailUntil)&&!(l.flags.military&&l.age<l.flags.military)&&!(l.abroad&&l.abroad.trapped);}
  function couple(l){var p=l.partner;return free(l)&&p&&p.alive!==false&&p.age>=18?ensure(l,p)||true:false;}
  function target(l,side){return side==='mine'?own(l):side==='theirs'?ensure(l,l.partner):null;}
  function ledger(l){return l.flags.heritageTravel||(l.flags.heritageTravel={seen:{},visits:[]});}
  function slot(l,side){var s=ledger(l);return(s.at!==l.age||s.count<2)&&s.seen[l.partner.heritageId+':'+side]!==l.age;}
  function eligible(l,side){return !!(couple(l)&&target(l,side)&&slot(l,side));}
  function baseValid(l,d){return !!(d&&eligible(l,d.side)&&l.partner.heritageId===d.pid&&l.age===d.at&&target(l,d.side).name===d.province&&locationKey(l)===d.location);}
  function context(l,side){if(!eligible(l,side))return{};return{side:side,pid:l.partner.heritageId,n:l.partner.name,province:target(l,side).name,at:l.age,location:locationKey(l)};}
  function unit(l,v){return l.cur==='vnd'?v:v*1e6/(G.CUR.VND*G.CUR.priceLevel(l.gdp||14.3));}
  function transport(l,name){
    var c=current(l),p=profile(name),from=profile(c.province);
    if(c.code!=='VN')return{v:/^(CN|LA|KH|TH|SG|MY|JP|KR|TW|PH|ID)$/.test(c.code)?18:40,text:'vé khứ hồi về Việt Nam cho hai người'};
    if(c.province===name)return{v:.06,text:'đi lại tại địa phương cho hai người'}; // v5.6.1: đi lại trong tỉnh chỉ vài chục nghìn
    if(from&&from.region===p.region)return{v:1.2,text:'đi lại khứ hồi liên tỉnh cho hai người'};
    return{v:4,text:'đi lại khứ hồi đường dài cho hai người'};
  }
  var PLANS=[{id:'place0',i:0,extra:.7},{id:'place1',i:1,extra:.7},{id:'food',extra:.5},{id:'both',extra:1.6}];
  function plan(id){return PLANS.filter(function(p){return p.id===id;})[0];}
  function quote(l,d){if(!d||!profile(d.province))return 0;var t=transport(l,d.province),p=plan(d.plan);return p?Math.round(unit(l,t.v+p.extra)*10000)/10000:0;}
  function partnerRemaining(l){var p=l.partner,b=p.heritageSpending,a=p.leisureSpending;return Math.max(0,(isFinite(p.inc)&&p.inc>0?p.inc*12*.1:0)-(b&&b.at===l.age&&b.cur===l.cur?b.spent:0)-(a&&a.at===l.age&&a.cur===l.cur?a.spent:0));}
  function invoiceValid(l,d){var q=l.flags.heritageQuote;return baseValid(l,d)&&!!plan(d.plan)&&!!q&&q.token===d.token&&q.pid===d.pid&&q.plan===d.plan&&q.province===d.province&&q.side===d.side;}
  function portion(d,k){return k==='self'?1:k==='split'?.5:0;}
  function canPay(l,d,k){if(!invoiceValid(l,d))return false;var c=quote(l,d),share=portion(d,k);return l.money+1e-8>=c*share&&partnerRemaining(l)+1e-8>=c*(1-share);}
  function meal(l,p){
    var allergy=[l.allergy,l.partner&&l.partner.allergy].filter(function(a){return a&&!/phấn hoa|penicillin|bụi nhà/.test(a);});
    if(allergy.length)return 'món địa phương đã kiểm tra thành phần và tránh '+allergy.join(', ');
    if(l.flags.vegetarian||l.partner&&l.partner.vegetarian)return 'món chay địa phương phù hợp chế độ ăn của hai người';
    if(/Hồi giáo|Hindu|Ấn Độ giáo/.test((l.religion||'')+' '+(l.partner&&l.partner.religion||'')))return 'món địa phương phù hợp kiêng kỵ tôn giáo, trao đổi nguyên liệu trước khi gọi';
    return p.foods.join(' và ');
  }
  function pay(l,d,k,log){
    if(!canPay(l,d,k))return;var cost=quote(l,d),self=cost*portion(d,k),other=cost-self,p=l.partner,info=profile(d.province),tour=plan(d.plan),s=ledger(l);
    if(self>0)H.cash(l,-self,'Khám phá '+info.name+' cùng '+p.name);
    if(other>0){if(!p.heritageSpending||p.heritageSpending.at!==l.age||p.heritageSpending.cur!==l.cur)p.heritageSpending={at:l.age,cur:l.cur,spent:0};p.heritageSpending.spent+=other;}
    if(s.at!==l.age){s.at=l.age;s.count=0;}s.count++;s.seen[p.heritageId+':'+d.side]=l.age;
    var places=tour.id==='both'?info.places.join(' và '):tour.id==='food'?'khu ẩm thực địa phương':info.places[tour.i];
    var story=(d.side==='mine'?'Bạn dẫn '+p.name+' khám phá quê mình':'Theo lời mời của '+p.name+', hai người khám phá quê người ấy')+' ở '+pname(l,info.name)+': ghé '+places+'.';
    if(tour.id==='food'||tour.id==='both')story+=' Hai người chọn '+meal(l,info)+', cùng tìm hiểu câu chuyện món ăn.';
    else story+=' Hai người nghe kể về địa danh và chụp vài tấm ảnh làm kỷ niệm.';
    story+=' Tổng ngân sách '+H.money(l,cost)+': '+(self>0?'bạn tự trả '+H.money(l,self)+' từ tiền riêng':'bạn không phải trả tiền')+(other>0?'; '+p.name+' trả '+H.money(l,other)+' từ thu nhập riêng':'; bạn mời toàn bộ')+'. Chuyến đi kết thúc, hai người trở lại nơi đang sống.';
    log(story,'good');H.fx(l,{hap:4,soc:2,kno:1});p.close=U.clamp((p.close==null?60:p.close)+3,0,100);
    var first=!s.visits.some(function(v){return v.province===info.name;});s.visits.push({province:info.name,side:d.side,pid:p.heritageId,age:l.age,places:places,plan:d.plan,self:self,partner:other,cur:l.cur});
    if(first)H.mem(l,'Cùng '+p.name+' khám phá '+info.name+': '+places+'.',3);
    delete l.flags.heritageQuote;
  }
  E.SC('que_doc',{title:function(l,d){return 'Dấu ấn quê hương · '+(d.province||'Việt Nam');},prep:function(l,r,a){var p=profile(a&&a.province)||own(l);return{province:p?p.name:''};},valid:function(l,d){return l.alive&&!!profile(d&&d.province||own(l)&&own(l).name);},text:function(l,d){var p=profile(d.province);return p?pname(l,p.name)+'.\nĐịa danh: '+p.places.join('; ')+'.\nẨm thực và sản vật: '+p.foods.join('; ')+'.\nĐây là gợi ý tìm hiểu văn hóa địa phương; một món ăn có thể được yêu thích ở nhiều tỉnh.':'';},opts:[{k:'ok',l:'Ghi nhớ nét đẹp quê hương',run:function(){}}]});
  E.SC('que_hen_ho',{title:'Cùng nhau khám phá quê hương',valid:function(l){return eligible(l,'mine')||eligible(l,'theirs');},text:'Bạn muốn dẫn người ấy khám phá quê mình hay cùng người ấy về quê chơi? Mỗi hướng một chuyến/năm, tối đa hai chuyến trong năm.',opts:['mine','theirs'].map(function(side){return{k:side,l:function(l){var p=target(l,side);return(side==='mine'?'Mời người ấy về quê mình':'Cùng người ấy về quê')+' · '+(p?p.name:'chưa có quê ở Việt Nam');},req:function(l){return eligible(l,side);},run:function(l,r,log){l.pending.unshift(E.DEC.que_chuyen_di.make(l,r,{side:side}));}};}).concat([{k:'no',l:'Để dịp khác',run:function(){}}])});
  E.SC('que_loi_moi',{title:'Người ấy muốn dẫn bạn về quê chơi',valid:function(l,d){return baseValid(l,d&&d.pid?d:context(l,'theirs'));},prep:function(l){return context(l,'theirs');},text:function(l,d){var p=profile(d.province);return p?d.n+' ngỏ lời: “Mình cùng về '+p.name+' nhé? Ở đó có '+p.places.join(', ')+', rồi mình tìm hiểu '+p.foods.join(', ')+'. Bạn có muốn đi không?”'+(own(l)&&own(l).name===p.name?' Hai người cùng quê, có thể chọn một buổi khám phá địa phương.':''):'';},opts:[{k:'go',l:'Cùng lên lịch, xem địa điểm và ngân sách',run:function(l,r,log,d){l.flags.queLater=0;l.pending.unshift(E.DEC.que_chuyen_di.make(l,r,{side:d.side}));}},{k:'later',l:'Hẹn dịp thuận tiện, chưa nhận lời',run:function(l,r,log,d){l.flags.queLater=(l.flags.queLater||0)+1;l.flags.queLaterAll=(l.flags.queLaterAll||0)+1;log(l.flags.queLaterAll<=1?'Hẹn '+d.n+' một dịp thuận tiện để cùng khám phá '+d.province+', chưa đặt chuyến hoặc chi tiền.':U.pick(r,['Lại khất '+d.n+' chuyến về '+d.province+'. Người ấy cười bảo: "Hẹn mãi thôi đấy nhé."','Công việc dồn dập, chuyến đi '+d.province+' cùng '+d.n+' lại lỡ hẹn thêm lần nữa.']),'neutral');}}]});
  E.SC('que_chuyen_di',{title:function(l,d){return 'Lịch chơi · '+(d.province||'quê hương');},prep:function(l,r,a){var side=a&&a.side;if(side)return eligible(l,side)?context(l,side):{unavailable:true};return context(l,eligible(l,'theirs')?'theirs':'mine');},valid:function(l,d){if(d&&d.unavailable)return false;return d&&d.pid?baseValid(l,d):eligible(l,'theirs')||eligible(l,'mine');},text:function(l,d){var p=profile(d.province);if(!p)return'Chưa có điểm đến phù hợp.';var t=transport(l,p.name);return(d.side==='mine'?'Bạn sẽ giới thiệu quê mình với '+d.n:d.n+' sẽ dẫn bạn khám phá quê người ấy')+' ở '+p.name+'. Địa danh: '+p.places.join('; ')+'. Đặc sản: '+p.foods.join('; ')+'.\nNgân sách gồm '+t.text+' và chi phí trải nghiệm cho hai người. Đây là ngân sách mô phỏng; bước sau cho chọn ai thanh toán. Chuyến đi không thay đổi nơi ở hoặc quê quán.';},opts:PLANS.map(function(p){return{k:p.id,l:function(l,d){var x=profile(d.province);return!x?'Chọn trải nghiệm':p.id==='both'?'Tham quan và tìm hiểu ẩm thực':p.id==='food'?'Khám phá ẩm thực địa phương':'Tham quan '+x.places[p.i];},h:function(l,d){var a=Object.assign({},d,{plan:p.id});return'Dự kiến cho hai người: '+H.money(l,quote(l,a));},run:function(l,r,log,d){if(!baseValid(l,d))return;var a=Object.assign({},d,{plan:p.id,token:l.flags.heritageQuoteSerial=(l.flags.heritageQuoteSerial||0)+1});l.flags.heritageQuote=a;l.pending.unshift(E.DEC.que_thanh_toan.make(l,r,a));}};}).concat([{k:'no',l:'Chưa sắp xếp được chuyến đi',run:function(){}}])});
  E.SC('que_thanh_toan',{title:'Thống nhất chi phí chuyến đi',prep:function(l,r,a){return a||l.flags.heritageQuote||{};},valid:function(l,d){return invoiceValid(l,d||l.flags.heritageQuote);},text:function(l,d){if(!invoiceValid(l,d))return'Kế hoạch này không còn phù hợp.';return'Chuyến khám phá '+d.province+' cùng '+d.n+' cần '+H.money(l,quote(l,d))+' cho cả hai người. Chỉ chi khi bạn xác nhận. Phần người ấy trả phải nằm trong ngân sách riêng còn lại từ thu nhập, không tự tạo thêm tiền.';},opts:['self','split','partner'].map(function(k){return{k:k,l:function(l,d){var cost=invoiceValid(l,d)?quote(l,d):0;return k==='self'?'Mình mời · tự trả '+H.money(l,cost):k==='split'?'Chia đôi · mình trả '+H.money(l,cost/2):'Người ấy mời · mình không trả tiền';},req:function(l,d){return canPay(l,d,k);},ai:{w:k==='split'?1.2:.7},run:function(l,r,log,d){pay(l,d,k,log);}};}).concat([{k:'no',l:'Hoãn lại, chưa chi tiền',run:function(l,r,log,d){if(invoiceValid(l,d))delete l.flags.heritageQuote;}}])});
  ['que_chuyen_di','que_loi_moi','que_thanh_toan'].forEach(function(id){var D=E.DEC[id],ap=D.apply;D.apply=function(l,d){if(!D.valid(l,d.data))return;return ap.apply(this,arguments);};});
  E.ACT.push({id:'que_doc',g:'Gia đình & bạn bè',l:'Địa danh / đặc sản quê mình',min:6,sc:'que_doc',avail:function(l){return own(l)?true:'Chưa có nơi sinh thuộc 63 tỉnh/thành Việt Nam';},ai:{w:0}});
  E.ACT.push({id:'que_hen_ho',g:'Tình cảm',l:'Mời nhau về quê chơi / ăn đặc sản',min:18,sc:'que_hen_ho',avail:function(l){return eligible(l,'mine')||eligible(l,'theirs')?true:'Cần người yêu / bạn đời đủ 18 tuổi, còn sống và lịch đi quê phù hợp';},ai:{w:.15}});
  E.TRIG.push({id:'que_loi_moi',when:function(l){return eligible(l,'theirs')&&(l.flags.queLater||0)<3;},p:.22,cd:3,rep:true});
  var love=E.DEC.love,mk=love.make,ap=love.apply;
  love.make=function(l,r,a){var d=mk.call(this,l,r,a),p=d.data.p,home=ensure(l,p,current(l).code);if(home)d.text+=' Quê của người ấy ở '+pname(l,home.name)+'.';return d;};
  love.apply=function(l,d){var result=ap.apply(this,arguments),p=d.data.p;if(l.partner&&l.partner.name===p.name){['home63','homeCountry','heritageId'].forEach(function(k){if(p[k]!=null)l.partner[k]=p[k];});ensure(l,l.partner);}return result;};
  var sponsor=E.DEC.sn_loi_moi;if(sponsor){var sm=sponsor.make,sa=sponsor.apply;
    sponsor.make=function(l,r,a){var d=sm.call(this,l,r,a);ensure(l,d.data.p,l.partner&&l.partner.homeCountry||current(l).code);return d;};
    sponsor.apply=function(l,d){var result=sa.apply(this,arguments);if(l.partner&&l.partner.name===d.data.p.name){['home63','homeCountry','heritageId'].forEach(function(k){if(d.data.p[k]!=null)l.partner[k]=d.data.p[k];});}return result;};
  }
  var migrate=E.migrateExt;E.migrateExt=function(l){if(migrate)migrate(l);ensure(l,l.partner);(l.pending||[]).forEach(function(d){if(d.id==='love'&&d.data&&d.data.p)ensure(l,d.data.p);});};
  E.HOMETOWN={data:DATA,profile:profile,own:own,partner:ensure,eligible:eligible,context:context,quote:quote,transport:transport,meal:meal,remaining:partnerRemaining};
})(G);

;
/* ===== js/life57.js ===== */
/* v4.7.0 — đời sống thế giới. Tình huống hư cấu, không phải xác suất thống kê.
   Nguồn và quy ước: world-events-sources.md. */
(function(G){
'use strict';
var E=G.E,H=E.H,U=G.U,W=G.W,CASES=[];
// quốc gia | trải nghiệm văn hóa | hoàn cảnh | lựa chọn | chuyện đời sống | hoàn cảnh | lựa chọn | nhóm
var ROWS=`
US|Buổi nhạc tại thư viện|Thư viện địa phương tổ chức buổi nghe nhạc jazz kèm giới thiệu lịch sử.|Nghe nhạc và trao đổi với người hướng dẫn|Học ở community college|Bạn tìm hiểu khóa học ngắn tại trường cộng đồng, nhưng cần cân đối lịch và học phí.|So sánh học phí, thời gian và khả năng chuyển tín chỉ|study
CA|Ngày hội mùa đông|Một trung tâm cộng đồng giới thiệu hoạt động mùa đông phù hợp người mới.|Chọn hoạt động nhẹ trong nhà nếu thời tiết xấu|Chuẩn bị mùa lạnh|Dự báo rét khiến lịch đi làm cần điều chỉnh, bạn còn thiếu kế hoạch dự phòng.|Kiểm tra trang phục và tuyến đi làm an toàn|work
MX|Xưởng làm giấy cắt|Một xưởng cộng đồng giới thiệu nghệ thuật giấy cắt papel picado.|Thử làm mẫu trang trí và hỏi về nguồn gốc|Ý tưởng bán hàng thủ công|Bạn được mời phụ trách một gian hàng cuối tuần, chưa rõ tiền nguyên liệu và hoa hồng.|Lập bảng chi phí và thống nhất phần việc|work
BR|Vòng tròn capoeira|Một nhóm giới thiệu capoeira và phần âm nhạc của loại hình này.|Quan sát rồi thử nhịp cơ bản theo sức khỏe|Lịch ca và trận bóng|Đồng nghiệp đề xuất đổi ca để xem bóng, nhưng chưa ai nhận phần bàn giao.|Thống nhất đổi ca và ghi lại việc cần bàn giao|work
AR|Buổi giới thiệu tango|Nhà văn hóa mở buổi tìm hiểu âm nhạc và lịch sử tango.|Nghe nhạc, không bắt buộc phải khiêu vũ|Hợp đồng làm thêm|Một công việc ngắn hạn trả theo sản phẩm, phần nghiệm thu còn mơ hồ.|Yêu cầu xác nhận khối lượng và lịch thanh toán|work
CL|Đêm kể chuyện bầu trời|Nhóm khoa học cộng đồng giới thiệu quan sát bầu trời qua ảnh và bản đồ sao.|Học cách đọc bản đồ sao ở điểm sinh hoạt gần nhà|Bài tập môi trường|Lớp học đề nghị xây dựng dự án tiết kiệm nước với số liệu đo tại trường.|Đo thực tế rồi đề xuất cách giảm lãng phí|school
PE|Xưởng dệt cộng đồng|Người hướng dẫn giới thiệu cách phối màu trong một số nghề dệt của Peru.|Tìm hiểu hoa văn và ghi rõ nguồn khi giới thiệu|Dự án du lịch nhỏ|Bạn nhận nhiệm vụ giới thiệu một hành trình, nhưng ảnh quảng cáo chưa được phép sử dụng.|Xin phép tác giả và mô tả đúng điều kiện chuyến đi|work
CO|Buổi tìm hiểu cà phê|Một buổi giới thiệu hành trình hạt cà phê có cả phần tham quan bằng hình ảnh.|Tìm hiểu quy trình, không cần uống cà phê|Học kỹ năng số|Trung tâm cộng đồng có nhóm thực hành công cụ số, lịch trùng một việc riêng.|Chọn buổi phù hợp rồi học theo nhóm|study
GB|Câu lạc bộ đọc sách|Thư viện mời người dân thảo luận một cuốn sách, có bản dễ đọc.|Mượn bản phù hợp và chia sẻ cảm nhận|Chuyến tàu đi làm|Tuyến bạn thường đi thông báo thay đổi giờ, bạn có cuộc hẹn công việc.|Kiểm tra lịch mới và báo thời gian đến|work
FR|Một ngày tìm hiểu điện ảnh|Nhà văn hóa chiếu trích đoạn phim Pháp kèm thảo luận, không yêu cầu kiến thức trước.|Tham gia buổi thảo luận miễn phí|Hồ sơ thuê chỗ ở|Bạn xem một nơi ở mới nhưng hợp đồng chưa tách rõ tiền thuê và phí dịch vụ.|Đọc hợp đồng, kiểm tra chủ cho thuê trước khi đặt cọc|housing
DE|Buổi sửa đồ cộng đồng|Một repair café mời người dân học sửa vật dụng cùng tình nguyện viên.|Mang đồ nhỏ đã ngắt điện để tìm hiểu an toàn|Lộ trình học nghề|Bạn cân nhắc một khóa đào tạo kết hợp thực hành, thông tin tuyển sinh còn thiếu.|Hỏi rõ chuẩn đầu vào, chi phí và lịch thực hành|study
IT|Xưởng tìm hiểu tranh khảm|Nhà văn hóa giới thiệu kỹ thuật tranh khảm bằng vật liệu mô hình.|Làm mẫu nhỏ và tìm hiểu cách bảo tồn|Khách muốn giao sớm|Đơn hàng cần giao sớm hơn lịch, nhưng cắt bước kiểm tra có thể làm sai chất lượng.|Thương lượng tiến độ thay vì bỏ kiểm tra|work
ES|Buổi học nhịp flamenco|Một câu lạc bộ giới thiệu nhạc và nhịp vỗ tay flamenco.|Học nhịp nhẹ, chọn ngồi nghe nếu cần|Dự án lớp bằng hai ngôn ngữ|Nhóm học sinh có người mới chuyển đến, chưa hiểu hết phần phân công.|Chia việc rõ ràng và hỗ trợ ngôn ngữ|school
PT|Buổi nghe fado|Một thư viện mở buổi giới thiệu fado và các bản ghi âm có chú giải.|Nghe và hỏi về bối cảnh bài hát|Việc làm theo mùa|Lịch công việc theo mùa được đề xuất nhưng giờ nghỉ và tiền làm thêm chưa rõ.|Hỏi điều kiện bằng văn bản trước khi nhận|work
NL|Chuyến đi xe đạp cộng đồng|Nhóm dân cư giới thiệu cách tổ chức đường đi an toàn, có lựa chọn đi bộ.|Chọn lộ trình phù hợp khả năng vận động|Dự án bảo vệ nguồn nước|Lớp học cần xây dựng mô hình quản lý nước với vật liệu tái sử dụng.|Thử mô hình rồi ghi cả kết quả chưa thành công|school
BE|Gặp gỡ truyện tranh|Thư viện tổ chức buổi trao đổi về truyện tranh Bỉ và cách kể chuyện bằng hình.|Đọc một tác phẩm và thử vẽ khung truyện|Bàn giao đa ngôn ngữ|Một thông báo công việc cần gửi cho nhóm dùng nhiều ngôn ngữ.|Dùng bản hướng dẫn dễ hiểu và xác nhận lại|work
CH|Ngày hội đường mòn|Câu lạc bộ giới thiệu bản đồ đường mòn, kèm lựa chọn tuyến bằng phẳng gần nhà.|Chọn tuyến theo thể lực và dự báo thời tiết|Học quản lý ngân sách|Một khóa cộng đồng hướng dẫn lập ngân sách cá nhân, không hứa hẹn lợi nhuận.|Lập quỹ dự phòng trước khi tính đầu tư|study
AT|Buổi nghe nhạc cổ điển|Nhà văn hóa mở buổi nghe nhạc có người giải thích cấu trúc tác phẩm.|Nghe và hỏi điều mình chưa hiểu|Dự án thực hành nghề|Bạn có cơ hội dự giờ một lớp thực hành, cần phân biệt buổi tham khảo và chứng chỉ chính thức.|Xác nhận giá trị khóa học trước khi đăng ký|study
SE|Buổi trò chuyện cộng đồng|Một nhóm dân cư mời mọi người nghỉ giải lao cùng nhau, đồ uống tùy chọn.|Tham gia và lắng nghe người mới|Cuộc họp quá tải|Lịch họp kéo dài làm việc cá nhân bị dồn, bạn muốn đề xuất thay đổi.|Đề xuất chương trình họp gọn và giờ tập trung|work
NO|Câu chuyện về thiên nhiên|Nhóm địa phương giới thiệu cách đi chơi ngoài trời mà giảm tác động môi trường.|Chọn đường ngắn và mang rác về|Lịch làm việc mùa tối|Ngày ít ánh sáng khiến bạn khó giữ giờ ngủ khi làm việc.|Sắp xếp giờ nghỉ, trao đổi lịch phù hợp|work
FI|Tìm hiểu văn hóa sauna|Một buổi sinh hoạt giới thiệu văn hóa sauna; tham gia thực tế hoàn toàn tự nguyện.|Nghe giới thiệu, không cần vào phòng nóng|Học cùng thư viện|Thư viện có nhóm học độc lập, bạn đang cần lịch ôn đều đặn.|Chọn mục tiêu nhỏ và ghi tiến bộ mỗi tuần|study
DK|Xưởng thiết kế đơn giản|Nhà văn hóa mời người dân thử thiết kế một vật dụng dùng lại nhiều lần.|Thử làm mô hình rồi trao đổi công năng|Góp ý ở nơi làm việc|Nhóm đang chọn cách phân công, ý kiến người mới chưa được nghe.|Mời mọi người góp ý và xác nhận trách nhiệm|work
PL|Buổi kể chuyện dân gian|Thư viện giới thiệu truyện dân gian Ba Lan và mời kể lại bằng tranh.|Chọn một câu chuyện để tìm hiểu|Nhóm học lập trình|Bạn được mời tham gia dự án nhỏ, có người mới và người đã biết nhiều.|Chia nhiệm vụ vừa sức và kiểm tra mã cùng nhau|study
GR|Buổi giới thiệu sân khấu|Một câu lạc bộ nói về sân khấu Hy Lạp qua trích đoạn và mô hình.|Nghe giới thiệu rồi thử đọc một đoạn ngắn|Tổ chức sự kiện địa phương|Bạn giúp chuẩn bị hoạt động cộng đồng, ngân sách và người phụ trách chưa rõ.|Công khai kế hoạch và kiểm tra khả năng tiếp cận|community
TR|Xưởng nghệ thuật ebru|Người hướng dẫn giới thiệu vẽ họa tiết trên mặt nước bằng vật liệu phù hợp.|Thử mẫu đơn giản theo hướng dẫn|Báo giá thay đổi|Chi phí nguyên liệu của đơn hàng đổi, khách vẫn nghĩ dùng báo giá cũ.|Giải thích phần thay đổi trước khi tiếp tục|work
RU|Câu lạc bộ văn học|Thư viện tổ chức buổi đọc truyện ngắn Nga, có phần trao đổi dành cho người mới.|Chọn đoạn dễ đọc và chia sẻ cảm nhận|Lịch học từ xa|Khóa học trực tuyến thay đổi giờ gặp nhóm, bạn chưa có cách theo dõi bài.|Thống nhất giờ và lưu bản ghi bài học được phép|study
UA|Xưởng trang trí trứng|Một nhóm văn hóa giới thiệu nghệ thuật pysanka qua vật liệu mô hình.|Tìm hiểu hoa văn và thử trang trí|Giữ bản sao giấy tờ|Bạn muốn sắp xếp hồ sơ cá nhân để tránh thất lạc khi chuyển chỗ ở.|Lưu bản sao an toàn và ghi thông tin liên hệ cần thiết|housing
JP|Tìm hiểu washoku|Trung tâm cộng đồng giới thiệu washoku qua ảnh và cách sắp xếp bữa ăn.|Hỏi về nguyên liệu, chọn phần phù hợp chế độ ăn|Nhóm chuẩn bị phỏng vấn|Bạn cân nhắc buổi thực hành phỏng vấn, nhóm muốn chia sẻ cả điều chưa làm tốt.|Luyện trả lời trung thực và xin phản hồi|study
KR|Buổi thử viết Hangul|Thư viện mở buổi thực hành nét chữ Hangul cho người quan tâm ngôn ngữ.|Thử viết và tìm hiểu lịch sử chữ viết|Đề nghị làm thêm giờ|Công việc phát sinh cuối ngày, lịch nghỉ đã được sắp xếp từ trước.|Trao đổi phạm vi công việc và thời gian bù phù hợp|work
CN|Xưởng thư pháp|Nhà văn hóa giới thiệu thư pháp, có người hướng dẫn cho người mới.|Tập nét cơ bản, không so thành tích|Dự án học theo nhóm|Lớp học cần trình bày một ý tưởng kỹ thuật, nhóm đang chia việc không đều.|Phân công rõ và ghi nguồn tài liệu|school
SG|Câu chuyện khu ăn uống cộng đồng|Một buổi giới thiệu văn hóa hawker có phần nói về người giữ nghề.|Tìm hiểu câu chuyện người bán, không bắt buộc mua món|Ứng dụng học tập mới|Khóa học mời bạn dùng một nền tảng, nhưng yêu cầu quá nhiều thông tin riêng.|Kiểm tra quyền riêng tư và chọn dữ liệu cần thiết|study
IN|Buổi tìm hiểu yoga|Nhà văn hóa giới thiệu yoga, có lựa chọn chỉ nghe và bài tập rất nhẹ.|Chọn mức phù hợp sức khỏe, dừng nếu khó chịu|Dự án ngôn ngữ|Nhóm học có người dùng nhiều ngôn ngữ khác nhau, tài liệu chung khó hiểu.|Thống nhất cách chú giải và hỏi lại nội dung|school
ID|Xưởng tìm hiểu batik|Một nhóm thợ giới thiệu hoa văn và kỹ thuật batik qua mẫu vật.|Hỏi nguồn gốc họa tiết rồi thử trên giấy|Cửa hàng lên mạng|Bạn được giao đưa danh mục hàng lên mạng, ảnh và mô tả chưa thống nhất.|Kiểm tra tồn kho và mô tả đúng sản phẩm|work
TH|Buổi giới thiệu múa khon|Nhà văn hóa giới thiệu mặt nạ và sân khấu khon bằng tư liệu.|Nghe câu chuyện và quan sát động tác mẫu|Khách quốc tế cần hướng dẫn|Trong công việc, khách hiểu nhầm một phần dịch vụ do khác ngôn ngữ.|Giải thích rõ điều đã bao gồm và xin xác nhận|work
MY|Buổi kể chuyện đa văn hóa|Thư viện mời người dân kể về ngôn ngữ và ký ức trong khu phố.|Nghe nhiều góc nhìn, không gán tập quán cho mọi người|Nhóm làm việc nhiều ngôn ngữ|Hướng dẫn mới chưa có bản mọi người đều hiểu, dễ dẫn đến sai sót.|Viết lại bằng ngôn ngữ dễ hiểu và minh họa|work
PH|Buổi giới thiệu dệt thủ công|Một nhóm cộng đồng giới thiệu các mẫu dệt và người giữ nghề.|Tìm hiểu nguồn gốc trước khi dùng họa tiết|Cuộc gọi với người thân xa nhà|Bạn có người thân còn sống ở xa, lịch liên lạc thường bị lệch.|Hẹn giờ phù hợp và hỏi thăm việc thực tế|family
BD|Xưởng dệt jamdani|Một buổi giới thiệu jamdani giải thích công sức của người dệt.|Quan sát mẫu và hỏi về cách giữ nghề|Nhóm học chống lừa đảo số|Trung tâm cộng đồng hướng dẫn kiểm tra tin nhắn và thông tin tài khoản.|Thực hành nhận biết đường dẫn giả|study
PK|Buổi tìm hiểu nghệ thuật trang trí xe|Nhóm văn hóa giới thiệu các họa tiết và câu chuyện trên xe tải trang trí.|Vẽ mẫu trên giấy và hỏi về người làm nghề|Khóa kỹ năng điện tử|Bạn được giới thiệu khóa học sửa thiết bị, thông tin dụng cụ và an toàn còn thiếu.|Kiểm tra nội dung thực hành và điều kiện an toàn|study
NP|Buổi kể chuyện núi rừng|Thư viện giới thiệu đời sống vùng núi qua lời kể, ảnh và bản đồ.|Nghe câu chuyện của nhiều cộng đồng|Đi học khi đường khó đi|Tuyến đến lớp tạm khó đi do thời tiết, trường cho phép nhận bài từ xa.|Liên hệ giáo viên và chọn cách đi an toàn|school
LK|Xưởng giới thiệu mặt nạ|Nhà văn hóa giới thiệu nghề làm mặt nạ và các bối cảnh biểu diễn.|Quan sát, tìm hiểu ý nghĩa trước khi thử vẽ|Góc học ở thư viện|Bạn cần chỗ học yên tĩnh, thư viện đang tổ chức nhóm hỗ trợ người học.|Đặt lịch phù hợp và chia sẻ tài liệu hợp pháp|study
AU|Buổi tìm hiểu nghệ thuật bản địa|Trung tâm văn hóa có người được cộng đồng cho phép giới thiệu tác phẩm và bối cảnh.|Nghe hướng dẫn, tôn trọng quyền sử dụng hình ảnh|Lịch làm ngoài trời|Trong công việc ngoài trời, thông báo nắng nóng khiến lịch ban đầu không phù hợp.|Đề xuất nghỉ mát và điều chỉnh giờ theo cảnh báo|outdoor
NZ|Buổi nghe chuyện văn hóa Māori|Một hoạt động do người hướng dẫn giới thiệu tiếng nói và câu chuyện Māori.|Lắng nghe, hỏi quy tắc trước khi chụp ảnh|Dự án bảo vệ cảnh quan|Nhóm dân cư chuẩn bị dọn rác, khu vực làm việc cần chọn theo mức an toàn.|Nhận việc nhẹ phù hợp, không vào khu bị hạn chế|community
EG|Tìm hiểu nghề thủ công|Nhà văn hóa giới thiệu một số nghề thủ công Ai Cập qua mẫu và tư liệu.|Trao đổi với người hướng dẫn và ghi lại nguồn|Chỗ ở gần nơi học|Bạn đang chọn chỗ ở để học tiếp, giá thuê rẻ nhưng đường đi dài.|Tính cả tiền đi lại và thời gian trước khi chọn|housing
MA|Xưởng tìm hiểu zellige|Nhóm nghệ nhân giới thiệu cách phối hình của gạch khảm zellige.|Thử ghép mẫu bằng giấy|Đơn hàng thủ công mới|Một khách muốn dùng họa tiết truyền thống, nhưng chưa rõ nguồn và quyền sử dụng ảnh.|Trao đổi với người giữ nghề và làm rõ thỏa thuận|work
ZA|Buổi kể chuyện bằng nhiều tiếng|Thư viện có hoạt động đọc truyện bằng nhiều ngôn ngữ Nam Phi.|Chọn câu chuyện và nghe người khác diễn giải|Học kỹ năng phỏng vấn|Một nhóm cộng đồng giúp thực hành phỏng vấn, không hứa bảo đảm có việc.|Soạn hồ sơ trung thực và luyện tình huống|study
NG|Câu lạc bộ điện ảnh|Một nhóm giới thiệu cách kể chuyện trong điện ảnh Nigeria.|Xem trích đoạn được phép rồi thảo luận|Kinh doanh qua mạng|Bạn được giao trả lời khách trực tuyến, một đơn đòi chuyển tiền ngoài quy trình.|Xác minh danh tính và giữ thanh toán trong thỏa thuận|work
KE|Buổi giới thiệu văn học|Thư viện mời người dân đọc truyện của các tác giả Kenya.|Đọc một đoạn rồi trao đổi về góc nhìn|Giải chạy cộng đồng|Nhóm dân cư tổ chức đi bộ và chạy nhẹ, mỗi người tự chọn cự ly.|Chọn đi bộ theo sức khỏe, không chạy đua thành tích|community
ET|Tìm hiểu văn hóa cà phê|Một buổi giới thiệu văn hóa cà phê có cả lựa chọn chỉ nghe câu chuyện.|Hỏi về trình tự và chọn đồ uống phù hợp|Bài tập lưu ký ức|Giáo viên mời lớp tìm hiểu một nghề ở địa phương qua phỏng vấn tự nguyện.|Xin phép người kể và ghi đúng lời|school
GH|Xưởng tìm hiểu kente|Người hướng dẫn giới thiệu hoa văn kente và công sức người dệt.|Tìm hiểu ý nghĩa, không tự gán một mẫu cho mọi người|Khóa quản lý cửa hàng|Bạn cân nhắc học quản lý tồn kho, nhóm thực hành bằng số liệu mô phỏng.|So sánh đầu vào, hàng tồn và doanh thu|study
SA|Buổi tìm hiểu thư pháp Ả Rập|Một buổi sinh hoạt giới thiệu nghệ thuật chữ viết, không yêu cầu tham gia nghi lễ.|Tìm hiểu hình thức chữ và thử mẫu đơn giản|Dự án tiết kiệm nước|Tại nơi làm việc, nhóm đề xuất giảm lãng phí nước, chưa có số liệu trước sau.|Đo mức dùng rồi thử cải tiến nhỏ|work
AE|Câu chuyện nghề lặn ngọc trai|Nhà văn hóa giới thiệu lịch sử nghề lặn ngọc trai qua tư liệu.|Nghe câu chuyện và hỏi về điều kiện lao động xưa|Làm việc với nhóm quốc tế|Nhóm dùng nhiều múi giờ, lịch họp khiến vài người liên tục bị bất tiện.|Luân phiên giờ họp và gửi nội dung trước|work
KH|Buổi giới thiệu múa truyền thống|Nhà văn hóa giới thiệu động tác và trang phục sân khấu Khmer.|Nghe hướng dẫn, không tự nhận vai trò nghi lễ|Lớp kỹ năng du lịch|Bạn cân nhắc khóa học hỗ trợ khách, trung tâm chưa giải thích rõ bằng chứng nhận.|Hỏi học phí và giá trị chứng nhận trước khi học|study
LA|Buổi kể chuyện nghề dệt|Người hướng dẫn giới thiệu các mẫu dệt và câu chuyện người làm nghề.|Quan sát và hỏi xin phép trước khi chụp mẫu|Nhóm học gần nhà|Một nhóm cộng đồng chia sẻ tài liệu học, có người không có mạng ổn định.|Chuẩn bị bản giấy và chia lịch trao đổi|study
`.trim().split('\n');
ROWS.forEach(function(line){var x=line.split('|');if(!W.BY[x[0]])throw Error('Unknown world country '+x[0]);
 CASES.push({id:x[0]+'_culture',code:x[0],kind:'culture',min:12,max:100,title:x[1],text:x[2],care:x[3]});
 CASES.push({id:x[0]+'_life',code:x[0],kind:x[7],min:x[7]==='school'?8:x[7]==='family'?12:18,max:x[7]==='school'?17:100,title:x[4],text:x[5],care:x[6]});
});
var COMMON=[
 ['child',5,7,'Ngày đầu nhóm sinh hoạt','Nhóm sinh hoạt gần nhà có trò ghép hình, bạn chưa quen ai.','Xin người hướng dẫn giúp làm quen'],
 ['child',5,7,'Một câu chuyện bằng tranh','Thư viện tổ chức đọc truyện bằng tranh cho trẻ nhỏ.','Nghe kể và thử kể lại bằng lời của mình'],
 ['child',5,7,'Không muốn tham gia trò chơi','Một trò chơi khiến bạn không thoải mái, người hướng dẫn cho phép chọn khác.','Nói điều mình cần và chọn trò nhẹ hơn'],
 ['child',5,7,'Đồ chơi dùng chung','Bạn muốn giữ một món đồ nhưng người khác cũng đang chờ.','Thỏa thuận chơi lần lượt cùng người hướng dẫn'],
 ['child',5,7,'Nhận biết người hỗ trợ','Buổi sinh hoạt giới thiệu cách tìm người có trách nhiệm khi cần giúp.','Nhớ điểm hẹn và hỏi khi chưa hiểu'],
 ['child',5,7,'Buổi vẽ nơi mình sống','Bạn được mời vẽ điều quen thuộc quanh nhà, không có xếp hạng.','Vẽ theo điều mình nhớ, không cần giống người khác'],
 ['school',8,17,'Người bạn mới trong lớp','Một bạn vừa chuyển đến còn bối rối với lịch học.','Giải thích lịch và mời bạn cùng làm bài'],
 ['school',10,17,'Dự án tìm hiểu nơi sống','Lớp học cần một bản giới thiệu khu vực bằng thông tin có nguồn.','Phân biệt điều quan sát được và điều cần kiểm chứng'],
 ['school',8,17,'Bài kiểm tra chưa phản ánh đúng','Bạn làm sai một phần dù đã học, cần xem lại cách hiểu đề.','Nhờ giáo viên giải thích rồi tự làm lại'],
 ['study',18,65,'Học tiếp khi đã trưởng thành','Bạn tìm được khóa học nhưng thông tin học phí và lịch chưa đầy đủ.','Hỏi chi phí toàn khóa và chọn lịch vừa sức'],
 ['study',18,65,'Học bổng cần hồ sơ','Một quỹ công bố cơ hội học tập, bạn chưa biết mình đáp ứng yêu cầu không.','Kiểm tra điều kiện và nộp hồ sơ trung thực'],
 ['work',18,100,'Mức lương trong lời mời','Lời mời công việc chưa phân biệt lương cơ bản và khoản phụ thuộc kết quả.','Yêu cầu làm rõ điều kiện trước khi quyết định'],
 ['work',18,100,'Đồng nghiệp cần bàn giao','Một đồng nghiệp nghỉ ngắn hạn, bạn cần biết giới hạn việc được giao.','Chốt đầu việc, thời hạn và người hỗ trợ'],
 ['work',18,100,'Công cụ tự động hóa mới','Nhóm cân nhắc dùng công cụ mới, có nguy cơ đưa dữ liệu nhạy cảm lên mạng.','Thử dữ liệu giả và kiểm tra quyền truy cập'],
 ['housing',18,100,'Tiền cọc cần minh bạch','Bạn xem một nơi ở, người giới thiệu thúc chuyển cọc ngay.','Xác minh nơi ở và thỏa thuận trước khi chuyển tiền'],
 ['housing',18,100,'Chia sẻ không gian sống','Bạn cân nhắc ở chung để giảm chi phí, chưa thống nhất giờ nghỉ và việc nhà.','Thỏa thuận quy tắc trước khi nhận lời'],
 ['community',12,100,'Nhóm tình nguyện địa phương','Nhóm dân cư có việc hỗ trợ phù hợp nhiều mức thể lực.','Chọn nhiệm vụ vừa sức và xác nhận giờ tham gia'],
 ['community',12,100,'Tin đồn trong khu phố','Một thông tin chưa rõ nguồn đang được chia sẻ nhiều.','Kiểm chứng trước khi chuyển tiếp'],
 ['community',12,100,'Đồ cũ còn dùng được','Điểm trao đổi cộng đồng nhận đồ sạch còn hoạt động, không yêu cầu đóng góp tiền.','Chỉ chia sẻ món mình có quyền cho'],
 ['urban',18,100,'Đường đi thay đổi','Tuyến đi quen thuộc đang được sửa chữa, lịch sinh hoạt bị ảnh hưởng.','Xem tuyến dự phòng và báo người có hẹn'],
 ['rural',18,100,'Kết nối ngoài trung tâm','Buổi học từ xa cần mạng ổn định hơn nơi bạn đang ở.','Tải tài liệu được phép và xin lịch dự phòng'],
 ['partner',18,100,'Hai lịch nghỉ khác nhau','Bạn và người ấy có lịch rảnh không trùng nhau.','Cùng chọn khoảng thời gian phù hợp cả hai'],
 ['parent',18,100,'Con hỏi về văn hóa','Một người con còn nhỏ hỏi vì sao mỗi người có thói quen khác nhau.','Cùng tìm hiểu, không phán xét khác biệt'],
 ['elder',60,100,'Nhịp sống tuổi già','Nhóm cộng đồng giới thiệu sinh hoạt nhẹ và trò chuyện theo sở thích.','Chọn hoạt động hợp sức khỏe, không cố theo người khác'],
 ['elder',60,100,'Lưu lại câu chuyện đời mình','Thư viện mời người lớn tuổi tự nguyện ghi lại ký ức, có quyền giữ riêng.','Viết một đoạn và tự chọn người được đọc'],
 ['community',12,100,'Dữ liệu cá nhân cần giữ kín','Một biểu mẫu hoạt động xin thông tin không liên quan.','Hỏi mục đích và chỉ cung cấp phần cần thiết'],
 ['community',12,100,'Lối vào chưa thuận tiện','Hoạt động công cộng có lối vào khó tiếp cận với một số người.','Góp ý thêm lựa chọn tham gia thuận tiện'],
 ['family',12,100,'Giữ liên lạc với người thân','Một người thân còn sống muốn hẹn trò chuyện, lịch hai bên chưa hợp.','Hẹn thời gian vừa sức và nghe điều họ muốn nói'],
 ['culture',12,100,'Buổi trao đổi ẩm thực','Nhóm cộng đồng giới thiệu món ăn qua câu chuyện, ảnh và công thức.','Tìm hiểu nguyên liệu, không cần nếm món'],
 ['culture',12,100,'Tủ sách về nơi đang sống','Thư viện có tài liệu về nhiều cộng đồng tại nơi bạn sống.','Chọn một góc nhìn mới và ghi lại điều học được']
];
COMMON.forEach(function(x,i){CASES.push({id:'common_'+i,kind:x[0],min:x[1],max:x[2],title:x[3],text:x[4],care:x[5]});});
function current(l){return l.abroad&&l.abroad.code||l.country;}
function free(l){return l.alive&&!(l.jailUntil!=null&&l.age<l.jailUntil)&&!(l.flags.military&&l.age<l.flags.military)&&!(l.abroad&&l.abroad.trapped);}
function family(l){var f=l.fam;return !!(f&&((!f.noMom&&f.mAlive)||(!f.noDad&&f.fAlive))||(l.kids||[]).some(function(k){return k.alive!==false;})||(l.sibList||[]).some(function(s){return s.alive===true; }));}
function suitable(l,c){if(!free(l)||!W.BY[current(l)]||current(l)==='VN'||l.age<c.min||l.age>c.max||c.code&&c.code!==current(l))return false;
 if(c.kind==='school')return !!l.school;
 if(c.kind==='work'||c.kind==='outdoor'){var j=l.job&&E.jobDef(l);return !!j&&j.sec!=='crime'&&(c.kind!=='outdoor'||['worker','poor'].indexOf(j.cat)>=0);}
 if(c.kind==='partner')return !!l.partner&&l.partner.alive!==false&&l.partner.age>=18;
 if(c.kind==='parent')return(l.kids||[]).some(function(k){return k.alive!==false&&l.age-k.born>=4&&l.age-k.born<18;});
 if(c.kind==='family')return family(l);
 if(c.kind==='urban')return !!l.urban;
 if(c.kind==='rural')return !l.urban;
 return true;
}
function state(l){return l.flags.worldStories||(l.flags.worldStories={seen:{},count:0,serial:0});}
function pool(l){if(!free(l)||current(l)==='VN'||!W.BY[current(l)])return[];var s=state(l);if(s.at===l.age&&s.count>=2)return[];return CASES.filter(function(c){var a=s.seen[c.id];return suitable(l,c)&&(a==null||l.age-a>=8);});}
function key(l){return[current(l),l.cur,l.abroad&&l.abroad.since||'',l.movedTo||'',l.city||''].join('|');}
function subject(l,c){
 if(c.kind==='work'||c.kind==='outdoor')return[l.job&&l.job.id,l.job&&l.job.rank,l.job&&l.job.rankSince].join('|');
 if(c.kind==='school')return[l.school,l.schoolEnd].join('|');
 if(c.kind==='partner')return l.partner?[l.partner.heritageId||'',l.partner.name,l.partner.since,l.partner.age,l.partner.status].join('|'):'';
 if(c.kind==='parent')return(l.kids||[]).filter(function(k){return k.alive!==false&&l.age-k.born>=4&&l.age-k.born<18;}).map(function(k){return[k.parentId||'',k.name,k.born].join(':');}).join('|');
 return '';
}
function valid(l,d){if(!d||!d.caseId)return pool(l).length>0;var s=state(l);var c=get(d);return !!c&&d.subject===subject(l,c)&&d.at===l.age&&d.location===key(l)&&d.token===s.serial&&!s.usedToken&&pool(l).some(function(c){return c.id===d.caseId;});}
function get(d){return CASES.filter(function(c){return c.id===d.caseId;})[0];}
function cost(l){return Math.max(0,l.base||0)*.015;}
function finish(l,r,log,d,k){if(!valid(l,d))return;var s=state(l),c=get(d);if(k==='learn'&&(l.age<18||l.money<cost(l)))return;
 if(s.at!==l.age){s.at=l.age;s.count=0;}s.count++;s.seen[c.id]=l.age;s.usedToken=true;
 var where=W.BY[current(l)].name;
 if(k==='care'){H.fx(l,{kno:1,soc:1,hap:1});
 if(c.kind==='work'||c.kind==='outdoor')l.job.rep=U.clamp((l.job.rep==null?50:l.job.rep)+2,0,100);
 if(c.kind==='partner')l.partner.close=U.clamp((l.partner.close||50)+2,0,100);
 if(c.kind==='parent'){var child=l.kids.filter(function(x){return x.alive!==false&&l.age-x.born>=4&&l.age-x.born<18;})[0];child.close=U.clamp((child.close||50)+2,0,100);}
 log(where+' · '+c.title+': '+c.care+'. '+U.pick(r,['Bạn dành thời gian thực hiện, hiểu rõ hơn hoàn cảnh và giữ được cuộc trao đổi tôn trọng.','Bạn lắng nghe người hướng dẫn, hỏi thêm vài điều và ra về với nhiều suy nghĩ.','Một buổi chậm rãi, bạn học được cách nhìn mới từ người bản xứ.','Bạn ghi chép cẩn thận, hẹn lần sau sẽ quay lại tìm hiểu thêm.','Người ở đó vui vẻ giải thích, bạn hiểu thêm phong tục nơi mình đang sống.']),'good');}
 else if(k==='learn'){var amount=cost(l);H.cash(l,-amount,'Tự chi buổi tìm hiểu: '+c.title);H.fx(l,{kno:2,hap:1});log(where+' · '+c.title+': bạn tự trả '+H.money(l,amount)+' từ tiền riêng cho một buổi tìm hiểu có hướng dẫn. Đây là chi phí mô phỏng, không phải học phí thị trường hay bằng cấp.','neutral');}
 else if(k==='rush'){H.fx(l,{soc:-2});if(l.mind)l.mind.stress=U.clamp(l.mind.stress+2,0,100);if(c.kind==='work'&&l.job)l.job.rep=U.clamp((l.job.rep==null?50:l.job.rep)-3,0,100);log(where+' · '+c.title+': quyết định vội khi chưa kiểm tra khiến bạn phải giải thích và làm lại, chưa có thay đổi hợp đồng hay chuyển tiền.','bad');}
 else if(k==='rest'){H.fx(l,{hap:1});if(l.mind)l.mind.stress=U.clamp(l.mind.stress-2,0,100);log(where+' · '+c.title+': '+U.pick(H.rf(l),['bạn chọn nghỉ và giữ lịch riêng, không phát sinh phí.','bạn để dịp khác, dành thời gian nghỉ ngơi.','bạn xin phép vắng lần này, ở nhà thư giãn.'])+'','neutral');}
 else log(where+' · '+c.title+': '+U.pick(H.rf(l),['bạn chưa tham gia, không phát sinh phí hoặc thay đổi hoàn cảnh.','bạn cảm ơn lời mời nhưng chưa tham gia lần này.','bạn để dành dịp khác, chưa tham gia.']),'neutral');
}
E.SC('world_doi_song',{title:function(l,d){var c=get(d);return c?c.title:'Chuyện nơi đang sống';},valid:valid,
 prep:function(l,r,arg){var p=pool(l);if(arg&&arg.group)p=p.filter(function(c){return GROUPS[arg.group]&&GROUPS[arg.group].indexOf(c.kind)>=0;});if(!p.length)return{};var local=p.filter(function(c){return c.code;});var c=U.pick(r,local.length&&r()<.65?local:p);var s=state(l);s.serial++;s.usedToken=false;return{caseId:c.id,at:l.age,location:key(l),subject:subject(l,c),token:s.serial};},
 text:function(l,d){var c=get(d);return c?W.BY[current(l)].name+' · '+c.text:'';},opts:[
 {k:'care',l:function(l,d){var c=get(d);return c?c.care+' · không phát sinh phí':'Tìm hiểu miễn phí';},run:function(l,r,log,d){finish(l,r,log,d,'care');}},
 {k:'learn',l:function(l){return'Dành một buổi tìm hiểu có hướng dẫn · tự trả '+H.money(l,cost(l));},req:function(l){return l.age>=18&&l.money>=cost(l);},run:function(l,r,log,d){finish(l,r,log,d,'learn');}},
 {k:'rush',l:'Quyết định vội, bỏ qua việc kiểm tra · có thể mất uy tín',req:function(l,d){var c=get(d);return c&&['work','school','housing'].indexOf(c.kind)>=0;},ai:{w:.1},run:function(l,r,log,d){finish(l,r,log,d,'rush');}},
 {k:'rest',l:'Giữ thời gian nghỉ ngơi · miễn phí',run:function(l,r,log,d){finish(l,r,log,d,'rest');}},
 {k:'no',l:'Để dịp khác · không chi tiền',run:function(l,r,log,d){finish(l,r,log,d,'no');}}
]});
var GROUPS={culture:['culture'],learn:['school','study','child'],work:['work','outdoor'],people:['family','parent','partner','elder'],local:['community','urban','rural','housing']};
E.SC('world_chu_de',{title:'Cuộc sống nơi đang sống',valid:function(l){return pool(l).length>0;},text:function(l){var code=current(l),count=CASES.filter(function(c){return c.code===code;}).length;return W.BY[code].name+' · Chọn một chủ đề đang phù hợp hoàn cảnh. Có '+count+' tình huống riêng cho quốc gia này và '+COMMON.length+' tình huống chung được lọc theo tuổi, học tập, công việc, nơi ở, người thân. Mỗi năm tối đa hai chuyện; cùng một chuyện chỉ trở lại sau ít nhất tám năm. Các khoản chi và xác suất chọn sự kiện là cân bằng mô phỏng.';},opts:Object.keys(GROUPS).map(function(k,i){return{k:k,l:['Văn hóa và nghệ thuật','Tuổi thơ / học tập','Công việc','Người thân / tình yêu / tuổi già','Nhà ở / sinh hoạt cộng đồng'][i],req:function(l){return pool(l).some(function(c){return GROUPS[k].indexOf(c.kind)>=0;});},run:function(l,r){if(pool(l).some(function(c){return GROUPS[k].indexOf(c.kind)>=0;}))l.pending.unshift(E.DEC.world_doi_song.make(l,r,{group:k}));}};}).concat([{k:'no',l:'Đóng lại',run:function(){}}])});
var D=E.DEC.world_doi_song,apply=D.apply;D.apply=function(l,d){if(!valid(l,d.data))return;return apply.apply(this,arguments);};
E.ACT.push({id:'world_doi_song',g:'Gia đình & bạn bè',l:'Chuyện đời sống / văn hóa nơi đang sống',min:5,sc:'world_chu_de',avail:function(l){return pool(l).length?true:'Chưa có chuyện mới phù hợp nơi sống hoặc đã đủ hai chuyện năm nay';},ai:{w:.35}});
E.TRIG.push({id:'world_doi_song',when:function(l){return pool(l).length>0;},p:.7,cd:1,rep:true});
E.WORLD_STORIES={cases:CASES,pool:pool,valid:valid,current:current,cost:cost,suitable:suitable,groups:GROUPS};
})(G);

;
/* ===== js/market-data.js ===== */
/* Bảng giá dự phòng có nguồn và thời điểm; không tự nhận là giá trực tiếp. */
G.MARKET_SEED = {"quotes": {"SJC": {"symbol": "SJC", "name": "Vàng miếng SJC", "kind": "gold", "currency": "VND", "unit": "chỉ", "bid": 14060000.0, "ask": 14360000.0, "asOf": "2026-10-17T01:30:03+00:00", "source": "Vang.today", "url": "https://www.vang.today/api/prices?type=SJL1L10"}, "NHAN": {"symbol": "NHAN", "name": "Vàng nhẫn SJC 9999", "kind": "gold", "currency": "VND", "unit": "chỉ", "bid": 14010000.0, "ask": 14310000.0, "asOf": "2026-10-17T01:30:03+00:00", "source": "Vang.today", "url": "https://www.vang.today/api/prices?type=SJ9999"}, "PNJ": {"symbol": "PNJ", "name": "Vàng PNJ 24K", "kind": "gold", "currency": "VND", "unit": "chỉ", "bid": 14000000.0, "ask": 14300000.0, "asOf": "2026-10-17T01:30:03+00:00", "source": "Vang.today", "url": "https://www.vang.today/api/prices?type=PQHN24NTT"}, "E1VFVN30": {"symbol": "E1VFVN30", "name": "ETF VN30", "kind": "stock", "currency": "VND", "unit": "chứng chỉ quỹ", "bid": 33450.0, "ask": 33450.0, "asOf": "2026-10-16T15:10:05+07:00", "source": "VNDIRECT · giá phiên gần nhất", "url": "https://banggia.vndirect.com.vn/"}, "VCB": {"symbol": "VCB", "name": "Vietcombank", "kind": "stock", "currency": "VND", "unit": "cổ phiếu", "bid": 56900.0, "ask": 56900.0, "asOf": "2026-10-16T15:10:04+07:00", "source": "VNDIRECT · giá phiên gần nhất", "url": "https://banggia.vndirect.com.vn/"}, "FPT": {"symbol": "FPT", "name": "FPT", "kind": "stock", "currency": "VND", "unit": "cổ phiếu", "bid": 58200.0, "ask": 58200.0, "asOf": "2026-10-16T15:10:05+07:00", "source": "VNDIRECT · giá phiên gần nhất", "url": "https://banggia.vndirect.com.vn/"}, "VNM": {"symbol": "VNM", "name": "Vinamilk", "kind": "stock", "currency": "VND", "unit": "cổ phiếu", "bid": 57800.0, "ask": 57800.0, "asOf": "2026-10-16T15:10:04+07:00", "source": "VNDIRECT · giá phiên gần nhất", "url": "https://banggia.vndirect.com.vn/"}, "HPG": {"symbol": "HPG", "name": "Hòa Phát", "kind": "stock", "currency": "VND", "unit": "cổ phiếu", "bid": 20900.0, "ask": 20900.0, "asOf": "2026-10-16T15:10:05+07:00", "source": "VNDIRECT · giá phiên gần nhất", "url": "https://banggia.vndirect.com.vn/"}, "MWG": {"symbol": "MWG", "name": "Thế Giới Di Động", "kind": "stock", "currency": "VND", "unit": "cổ phiếu", "bid": 73900.0, "ask": 73900.0, "asOf": "2026-10-16T15:10:04+07:00", "source": "VNDIRECT · giá phiên gần nhất", "url": "https://banggia.vndirect.com.vn/"}, "GAS": {"symbol": "GAS", "name": "PV GAS", "kind": "stock", "currency": "VND", "unit": "cổ phiếu", "bid": 76100.0, "ask": 76100.0, "asOf": "2026-10-16T15:10:04+07:00", "source": "VNDIRECT · giá phiên gần nhất", "url": "https://banggia.vndirect.com.vn/"}, "SPY": {"symbol": "SPY", "name": "ETF S&P 500", "kind": "stock", "currency": "USD", "unit": "chứng chỉ quỹ", "bid": 763.25, "ask": 763.25, "asOf": "2026-10-16T20:00:00+00:00", "source": "Yahoo Finance · giá phiên gần nhất", "url": "https://finance.yahoo.com/quote/SPY/"}, "AAPL": {"symbol": "AAPL", "name": "Apple", "kind": "stock", "currency": "USD", "unit": "cổ phiếu", "bid": 343.46, "ask": 343.46, "asOf": "2026-10-16T20:00:01+00:00", "source": "Yahoo Finance · giá phiên gần nhất", "url": "https://finance.yahoo.com/quote/AAPL/"}, "MSFT": {"symbol": "MSFT", "name": "Microsoft", "kind": "stock", "currency": "USD", "unit": "cổ phiếu", "bid": 529.05, "ask": 529.05, "asOf": "2026-10-16T20:00:01+00:00", "source": "Yahoo Finance · giá phiên gần nhất", "url": "https://finance.yahoo.com/quote/MSFT/"}, "NVDA": {"symbol": "NVDA", "name": "NVIDIA", "kind": "stock", "currency": "USD", "unit": "cổ phiếu", "bid": 214.13, "ask": 214.13, "asOf": "2026-10-16T20:00:00+00:00", "source": "Yahoo Finance · giá phiên gần nhất", "url": "https://finance.yahoo.com/quote/NVDA/"}, "KO": {"symbol": "KO", "name": "Coca-Cola", "kind": "stock", "currency": "USD", "unit": "cổ phiếu", "bid": 93.9, "ask": 93.9, "asOf": "2026-10-16T20:00:02+00:00", "source": "Yahoo Finance · giá phiên gần nhất", "url": "https://finance.yahoo.com/quote/KO/"}, "TM": {"symbol": "TM", "name": "Toyota", "kind": "stock", "currency": "USD", "unit": "cổ phiếu", "bid": 194.61, "ask": 194.61, "asOf": "2026-10-16T20:00:02+00:00", "source": "Yahoo Finance · giá phiên gần nhất", "url": "https://finance.yahoo.com/quote/TM/"}}, "fx": {"usdVnd": 25868.901996, "asOf": "2026-10-17T00:02:32+00:00", "source": "ExchangeRate-API", "url": "https://www.exchangerate-api.com/docs/free"}, "fetchedAt": "2026-10-17T02:00:49.374301+00:00"};

;
