/* ===== js/life64.js ===== */
/* V5.1: điều kiện sinh hoạt, học bơi, giờ sinh và gia đình hai bên. */
(function(G){
  'use strict';
  var E=G.E,H=E.H,U=G.U;
  function hash(s){var h=2166136261;for(var i=0;i<s.length;i++)h=Math.imul(h^s.charCodeAt(i),16777619);return h>>>0;}
  function free(l){return l.alive&&!(l.jailUntil!=null&&l.age<l.jailUntil)&&!(l.flags.military&&l.age<l.flags.military)&&!(l.abroad&&l.abroad.trapped);}
  function snapshot(l){return[l.age,l.cur,l.abroad&&l.abroad.code||l.country,l.movedTo||'',l.cityStudent&&l.cityStudent.city||'',l.prov&&l.prov.old||''].join('|');}
  function guarded(id){var D=E.DEC[id],ap=D.apply;D.apply=function(l,d){if(!D.valid(l,d.data))return;return ap.apply(this,arguments);};}
  // Các cảnh có thể chờ qua lúc nghỉ học phải kiểm tra lại khi mở và khi chọn.
  ['thu_nac_danh','he_nay'].forEach(function(id){var D=E.DEC[id];if(!D)return;var valid=D.valid;D.valid=function(l,d){return !!l.school&&valid.call(this,l,d);};guarded(id);});
  var kham=E.DEC.kham,kv=kham.valid;
  kham.valid=function(l,d){return (!(l.recur&&l.recur.kham_dk)||!!(d&&d.requested))&&kv.call(this,l,d);};
  E.TRIG.forEach(function(t){if(t.id==='kham'){var when=t.when;t.when=function(l,a){return !(l.recur&&l.recur.kham_dk)&&when(l,a);};}});
  var city=E.DEC.city,cityApply=city.apply;
  city.valid=function(l){return free(l)&&l.age>=18&&l.age<=35&&!l.urban&&!l.school&&!l.abroad&&!l.flags.cityAsked;};
  city.apply=function(l){if(!city.valid(l))return;return cityApply.apply(this,arguments);};
  // Sân đấu theo nơi đang sống, không theo quốc tịch lúc sinh.
  E.DEC.xem_bong_da.def.text=function(l){var r=function(){return ((l.age*7+(l.rs||0))%10)/10;},code=l.abroad&&l.abroad.code||l.country,city=l.cityStudent&&l.cityStudent.city||l.movedTo||l.prov&&l.prov.old||'';
    if(code!=='VN')return 'Câu lạc bộ địa phương ở '+(G.W.BY[code]&&G.W.BY[code].name||code)+' có trận đấu sân nhà cuối tuần này.';
    var S=[[/Hà Nội/,'sân Mỹ Đình (đội tuyển Việt Nam)','sân Hàng Đẫy'],[/Hồ Chí Minh/,'sân Thống Nhất'],[/Hải Phòng/,'sân Lạch Tray'],[/Nam Định/,'sân Thiên Trường'],[/Thanh Hóa/,'sân vận động Thanh Hóa'],[/Nghệ An/,'sân Vinh'],[/Hà Tĩnh/,'sân Hà Tĩnh'],[/Bình Dương/,'sân Gò Đậu'],[/Đà Nẵng/,'sân Hòa Xuân'],[/Gia Lai/,'sân Pleiku'],[/Bình Định/,'sân Quy Nhơn'],[/Khánh Hòa/,'sân 19 tháng 8 (Nha Trang)'],[/Phú Thọ/,'sân Việt Trì (đội tuyển Việt Nam)'],[/Quảng Ninh/,'sân Cẩm Phả'],[/Quảng Nam/,'sân Tam Kỳ'],[/Ninh Bình/,'sân Ninh Bình'],[/Cần Thơ/,'sân Cần Thơ']].filter(function(x){return x[0].test(city);})[0];
    var stadium=S?(S[2]&&r()<.5?S[2]:S[1]):'sân vận động tỉnh '+(city||'nơi bạn sống');
    return 'Cuối tuần có trận bóng ở '+stadium+'. Bạn muốn ra sân hay xem ở nhà?';};
  E.DEC.xem_bong_da.def.opts.forEach(function(o){if(o.k==='stadium')o.run=function(l,r,log){var bill=E.childExpense(l,l.base*.005,'Vé bóng đá',false);log(bill.note,'neutral');if(!bill.ok)return;log(r()<.55?'Đội nhà thắng, khán đài vỡ òa tiếng reo hò!':'Đội nhà thua sát nút, bạn vẫn giơ khăn cổ vũ đến hết trận.','good');H.fx(l,{hap:6,soc:3});};if(o.k==='cafe')o.run=function(l,r,log){var bill=E.childExpense(l,l.base*.001,'Đồ uống xem bóng đá',false);log(bill.note,'neutral');if(bill.ok){log('Xem bóng ở quán cà phê, hò hét cùng cả quán.','good');H.fx(l,{hap:3,soc:2});}};});
  ['xem_bong_da','phuot','leo_nui'].forEach(function(id){var D=E.DEC[id],make=D.make,valid=D.valid;D.make=function(l){var d=make.apply(this,arguments);d.data.outing51=snapshot(l);return d;};D.valid=function(l,d){return free(l)&&(!d||!d.outing51||d.outing51===snapshot(l))&&valid.call(this,l,d);};});
  var phuot=E.DEC.phuot.def,pp=phuot.prep;phuot.prep=function(l,r){return (l.abroad&&l.abroad.code||l.country)!=='VN'?{p:'khu cắm trại gần nơi bạn sống'}:pp(l,r);};

  var hike=E.DEC.leo_nui.def,hp=hike.prep;hike.prep=function(l,r){return (l.abroad&&l.abroad.code||l.country)!=='VN'?{p:'một cung đường đi bộ gần nơi bạn sống'}:hp(l,r);};

  function swimValid(l,d){return free(l)&&l.age>=6&&(!d||!d.location||d.location===snapshot(l));}
  function swimCost(l){return E.activityPrice(l,1.2);}
  function learned(l,log){l.flags.swim=true;(l.skills||(l.skills={})).boi=l.age;H.fx(l,{hea:2,hap:2});log('Bạn đã biết bơi cơ bản, vẫn tránh vùng nước nguy hiểm.','good');H.mem(l,'Lần đầu tự bơi được một đoạn ngắn.',3);}
  function practice(l,log){l.flags.swimPractice=(l.flags.swimPractice||0)+1;if(l.flags.swimPractice>=2)learned(l,log);else{H.fx(l,{hea:1});log('Bạn tập nổi và làm quen với nước, chưa đủ vững để bơi xa.','good');}}
  E.SC('hoc_boi51',{title:'Học bơi',valid:swimValid,prep:function(l){return{location:snapshot(l)};},text:function(l){return l.flags.swim?'Bạn muốn luyện bơi thêm hay ôn kỹ năng an toàn?':'Bạn muốn học bơi theo cách nào?';},opts:[
    {k:'course',l:'Đăng ký khóa học có huấn luyện viên',h:function(l){return 'Học phí '+H.money(l,swimCost(l))+(l.age<18?' · xin gia đình chi trả':'');},run:function(l,r,log){var b=E.childExpense(l,swimCost(l),'Khóa học bơi',false);log(b.note,'neutral');if(b.ok)learned(l,log);}},
    {k:'safe',l:'Tập ở khu nước nông có cứu hộ',h:'Miễn phí · luyện từng bước cùng người hướng dẫn',run:function(l,r,log){practice(l,log);}},
    {k:'pond',l:'Tự tập ở ao cùng người quen',h:'Miễn phí · có nguy cơ đuối nước',run:function(l,r,log){wild(l,r,log,.025,'ao');}},
    {k:'river',l:'Tự tập ở sông cùng người quen',h:'Miễn phí · dòng chảy nguy hiểm hơn ao',run:function(l,r,log){wild(l,r,log,.06,'sông');}},
    {k:'lake',l:'Tự tập ở hồ cùng người quen',h:'Miễn phí · có nguy cơ đuối nước',run:function(l,r,log){wild(l,r,log,.04,'hồ');}},
    {k:'no',l:'Để dịp khác',run:function(){}}
  ]});
  function wild(l,r,log,risk,where){if(l.flags.swim||E.hasSkill(l,'boi'))risk*=.25;
    if(r()<risk){if(r()<.12){H.kill(l,'đuối nước khi tự tập bơi ở '+where,log);return;}H.fx(l,{hea:-10,hap:-5});log('Bạn bị hụt chân ở '+where+', người đi cùng gọi cứu hộ kịp thời. Buổi tập phải dừng lại.','bad');return;}
    log('Người quen đi cùng trông chừng khi bạn tập ở '+where+'.','neutral');practice(l,log);}
  guarded('hoc_boi51');
  E.ACT.push({id:'hoc_boi51',g:'Sức khỏe & tâm hồn',l:'Học bơi / luyện kỹ năng an toàn',min:6,avail:function(l){return free(l)?true:'Chưa thể đi học bơi lúc này';},ai:{w:.1}});
  [['k_hoc_boi','hoc'],['he_nay','swim'],['tam_song','learn']].forEach(function(x){var D=E.DEC[x[0]];if(D&&D.def)D.def.opts.forEach(function(o){if(o.k===x[1])o.run=function(l,r){if(swimValid(l))l.pending.unshift(E.DEC.hoc_boi51.make(l,r));};});});

  var SIGNS=['Ma Kết','Bảo Bình','Song Ngư','Bạch Dương','Kim Ngưu','Song Tử','Cự Giải','Sư Tử','Xử Nữ','Thiên Bình','Bọ Cạp','Nhân Mã'],CUT=[20,19,21,20,21,21,23,23,23,23,22,22];
  var HOURS=['Tý','Sửu','Dần','Mão','Thìn','Tỵ','Ngọ','Mùi','Thân','Dậu','Tuất','Hợi'];
  function birth(l){if(l.astro51)return l.astro51;var h=hash([l.name,l.birthPlace,l.birthYear,l.birthMonth].join('|')),m=l.birthMonth||1,days=new Date(Date.UTC(l.birthYear,m,0)).getUTCDate();
    l.birthDay=l.birthDay||1+h%days;l.birthHour=l.birthHour==null?(h>>>8)%24:l.birthHour;
    var sign=(m-1+(l.birthDay>=CUT[m-1]?1:0))%12,trait=['amb','soc','moral','risk'][sign%4];
    var a=l.astro51={sign:SIGNS[sign],hour:HOURS[Math.floor((l.birthHour+1)%24/2)],trait:trait,theme:['kiên trì','cởi mở','quan tâm người khác','ưa khám phá'][sign%4]};
    if(l.age===0&&l.tr){l.tr[trait]=U.clamp(l.tr[trait]+4,5,98);l.tr[HOURS.indexOf(a.hour)%2?'soc':'amb']=U.clamp(l.tr[HOURS.indexOf(a.hour)%2?'soc':'amb']+2,5,98);}
    return a;}
  var migrate=E.migrateExt;E.migrateExt=function(l){if(migrate)migrate(l);birth(l);family(l);l.pending=(l.pending||[]).filter(function(d){return d.id!=='me_chong'&&!H.schoolOff(l,(d.title||'')+' '+(d.text||''))&&!(d.id==='kham'&&l.recur&&l.recur.kham_dk&&!(d.data&&d.data.requested));});};
  E.astroText=function(l){var a=birth(l);return a.sign+' · giờ '+a.hour+' ('+l.birthHour+'h) · '+a.theme;};
  E.SC('van_hoi51',{title:'Một dịp đáng thử',valid:function(l){return free(l)&&l.age>=16;},text:function(l){return 'Bạn đang thiên về '+birth(l).theme+'. Một người quen rủ bạn thử một việc mới.';},opts:[
    {k:'learn',l:'Học một kỹ năng mới cùng họ',run:function(l,r,log){H.fx(l,{kno:2,hap:1});log(U.pick(r,['Buổi học mở ra một sở thích mới, bạn muốn dành thời gian luyện thêm.','Học xong buổi đầu, bạn hẹn họ tuần sau học tiếp.','Buổi học vụng về nhưng vui, bạn ghi lại vài mẹo để tự tập ở nhà.']),'good');}},
    {k:'meet',l:'Đến gặp gỡ, mở rộng quan hệ',run:function(l,r,log){H.fx(l,{soc:3,hap:1});if(l.job)l.job.rep=U.clamp((l.job.rep||50)+2,0,100);log(U.pick(r,['Bạn quen thêm vài người và có một cuộc trò chuyện hữu ích.','Một người lạ hóa ra cùng ngành, hai bên trao đổi danh thiếp.','Buổi gặp gỡ đông người, bạn nhớ được dăm cái tên và một lời khuyên hay.','Bạn kết nối được với một người có thể giúp công việc sau này.','Ngồi cùng bàn với vài người thú vị, câu chuyện kéo dài đến tối.']),'good');}},
    {k:'rest',l:'Giữ lịch riêng, nghỉ ngơi',run:function(l,r,log){H.fx(l,{hea:1,hap:2});log(U.pick(H.rf(l),['Bạn dành ngày rảnh cho bản thân.','Bạn để ngày rảnh cho riêng mình, ngủ nướng rồi đọc sách.','Bạn nghỉ ngơi, đi dạo một vòng cho thư thái.']),'good');}}
  ]});
  E.TRIG.push({id:'van_hoi51',when:function(l){return free(l)&&l.age>=16;},p:function(l){return .06+(birth(l).trait==='soc'?.04:0);},cd:5,max:3});

  function couple(l){return free(l)&&l.age>=18&&l.partner&&l.partner.alive!==false&&l.partner.age>=18;}
  function pid(l){return l.partner&&(l.partner.heritageId||l.partner.name+':'+l.partner.since);}
  function family(l){var f=l.flags.family51||(l.flags.family51={strict:E.birthContext?/quy tắc|ít tự quyết|hay lo xa|kỳ vọng|áp lực lựa chọn/.test(E.birthContext(l).text):hash(l.name+':family')%100<35});return f;}
  function inlaws(l){var p=l.partner;if(!p)return null;if(!p.inlaws51){var h=hash(pid(l)+':inlaws');p.inlaws51={strict:h%100<35,mDeath:68+(h>>>10)%26,mAgeAtBirth:22+(h>>>6)%13,orphan:p.orphan===true||p.parentsAlive===false||p.mAlive===false};}return p.inlaws51;}
  function mother(l){var p=l.partner,f=inlaws(l);return f&&!f.orphan&&p.mAlive!==false&&p.age+f.mAgeAtBirth<f.mDeath;}
  // Cảnh cũ không lưu gia đình phía người ấy; thay bằng cảnh có hồ sơ và tuổi.
  E.DEC.me_chong.valid=function(){return false;};
  E.TRIG.forEach(function(t){if(t.id==='me_chong')t.when=function(){return false;};});
  function familyValid(l,d){return !!(couple(l)&&(!d||!d.pid||d.pid===pid(l))&&(!d||d.at==null||d.at===l.age));}
  E.SC('gia_dinh_hai_ben51',{title:'Chuyện gia đình hai bên',valid:function(l,d){var own=l.partner&&l.partner.status==='dating'&&family(l).strict&&(l.fam.mAlive||l.fam.fAlive&&!l.fam.noDad);return familyValid(l,d)&&(d&&d.caseId?(d.caseId==='own'?own:mother(l)):own||mother(l));},prep:function(l,r){var p=l.partner,f=inlaws(l),own=p.status==='dating'&&(l.fam.mAlive||l.fam.fAlive&&!l.fam.noDad)&&family(l).strict;
    var earned=l.job&&E.monthlyEst?E.monthlyEst(l,l.job.id,l.job.rank)*12:l.retired&&l.pensionInc?l.pensionInc:l.income||0;
    var low=l.sex==='M'&&p.sex==='F'&&earned<l.base*.5&&E.netWorth(l)<l.base*5,job=E.jobDef(l),bias=f.strict&&l.sex==='M'&&p.sex==='F'&&job&&/^(poor|service|free|worker)$/.test(job.cat);
    return{pid:pid(l),at:l.age,caseId:own?'own':p.status==='dating'&&f.strict?'oppose':f.strict?'boundary':'warm',reason:low?'income':bias?'job':'fit',name:p.name};},
    text:function(l,d){return d.caseId==='own'?(l.fam.mAlive&&l.fam.fAlive&&!l.fam.noDad?'Bố mẹ':l.fam.mAlive?'Mẹ':'Bố')+' lo hai người chưa hợp nhau, muốn bạn hoãn chuyện cưới xin.':d.caseId==='oppose'?'Gia đình '+d.name+(d.reason==='income'?' lo thu nhập của bạn chưa ổn định, phản đối chuyện cưới.':d.reason==='job'?' có định kiến với công việc bạn đang làm, phản đối chuyện cưới.':' chưa đồng ý chuyện cưới, muốn tìm hiểu hai người thêm.'):d.caseId==='boundary'?(l.sex==='F'&&l.partner.sex==='M'&&l.partner.status==='married'?'Mẹ chồng':'Mẹ của '+d.name)+' muốn bạn làm theo nếp sinh hoạt nhà bà, khiến bạn thấy ngột ngạt.':'Mẹ của '+d.name+' hỏi bạn thích ăn gì và chủ động giúp hai người một việc trong nhà.';},opts:[
      {k:'talk',l:'Ngồi lại nói chuyện, lắng nghe nhau',run:function(l,r,log,d){H.fx(l,{soc:2,hap:1});l.partner.close=U.clamp((l.partner.close||50)+2,0,100);log(d.caseId==='warm'?U.pick(H.rf(l),['Bạn cảm ơn và cùng chuẩn bị một bữa cơm.','Bạn cảm ơn, xắn tay vào bếp phụ một tay, bữa cơm hôm ấy ấm cúng hẳn.','Bạn nhận lời, cả nhà quây quần bên mâm cơm, chuyện trò rôm rả.']):'Hai người giải thích dự định của mình. Gia đình '+(r()<.6?'dần bớt căng thẳng.':'vẫn cần thêm thời gian để chấp nhận.'),'neutral');family(l).lastTalk=l.age;}},
      {k:'boundary',l:'Cùng người ấy đặt ranh giới rõ ràng',run:function(l,r,log){l.partner.close=U.clamp((l.partner.close||50)+3,0,100);if(l.mind)l.mind.stress=Math.max(0,l.mind.stress-3);family(l).boundaries=pid(l);log(U.pick(H.rf(l),['Hai người thống nhất tự quyết việc riêng, vẫn giữ liên lạc với gia đình.','Hai người ngồi lại, thống nhất chuyện nhà mình thì mình quyết, vẫn thăm hỏi gia đình đều đặn.','Hai bạn nhẹ nhàng đặt ranh giới với gia đình mà vẫn giữ hòa khí.']),'good');}},
      {k:'wait',l:'Tạm nhường một bước, hẹn nói sau',run:function(l,r,log){H.fx(l,{hap:-1});log(U.pick(r,['Bạn tránh tranh luận lúc này, hẹn một dịp bình tĩnh hơn.','Bạn im lặng cho qua, để mọi người nguôi giận rồi nói chuyện sau.','Bạn xin phép nói chuyện vào hôm khác, khi ai cũng bình tĩnh hơn.','Bạn nhường một bước, giữ hòa khí trước đã.']),'neutral');}}
    ]});guarded('gia_dinh_hai_ben51');
  E.TRIG.push({id:'gia_dinh_hai_ben51',when:function(l){return couple(l)&&(l.partner.status!=='dating'||l.partner.since!=null&&l.age-l.partner.since>=1)&&((l.partner.status==='dating'&&family(l).strict&&(l.fam.mAlive||l.fam.fAlive&&!l.fam.noDad))||mother(l));},p:function(l){return family(l).boundaries===pid(l)?.08:.22;},cd:3,max:12,rep:true});
  var V=E.DEC.vr_vong,vm=V.make,va=V.apply,vu=V.auto;
  var challenges=[
    {title:'Mật mã chiếc hộp',text:'Mật mã là tổng số chấm trên hai thẻ: 7 và 8. Bạn nhập số nào?',labels:['14','15','16'],answer:1},
    {title:'Nhớ thứ tự vật phẩm',text:'Ê-kíp vừa cho xem: nón, quạt, giỏ. Vật đứng giữa là gì?',labels:['Chiếc giỏ','Chiếc nón','Chiếc quạt'],answer:2},
    {title:'Ghép bản đồ',text:'Từ vạch xuất phát, đi hai ô về đông rồi một ô về bắc. Bạn chọn mảnh đường nào?',labels:['Hai ô phải, một ô lên','Hai ô trái, một ô lên','Một ô phải, hai ô xuống'],answer:0},
    {title:'Chuyền bóng tiếp sức',text:'Đội bạn bị chậm ở khúc cua. Bạn muốn đổi cách phối hợp thế nào?',labels:['Chuyền ngắn, giữ nhịp đều','Ra hiệu trước mỗi lượt chuyền','Chạy bứt lên để bù thời gian'],strategies:['team','mind','hard']},
    {title:'Truy tìm vật phẩm',text:'Manh mối nhắc đến một chỗ có mái che và tiếng nước. Đội bạn tìm ở đâu trước?',labels:['Quanh giếng có mái','Giữa sân nắng','Ở cổng làng'],answer:0},
    {title:'Giữ thăng bằng',text:'Hai đồng đội đang bước lệch nhịp trên cầu thử thách. Bạn xử lý ra sao?',labels:['Đếm nhịp để cả đội bước cùng','Dừng lại quan sát cách đặt chân','Nhận đoạn khó nhất về mình'],strategies:['team','mind','hard']},
    {title:'Đoán từ bằng hành động',text:'Đồng đội làm động tác mở ô, chỉ lên trời rồi giả vờ ướt áo. Bạn đoán gì?',labels:['Trời mưa','Đi câu cá','Tưới cây'],answer:0},
    {title:'Vòng cuối xé bảng tên',text:'Đối thủ đang giữ lối tắt. Bạn bàn với đội kế hoạch nào?',labels:['Chia hai hướng hỗ trợ nhau','Dụ đối thủ rời lối tắt','Chạy đua thẳng tới đích'],strategies:['team','mind','hard']}
  ];
  // v5.6.1: thử thách có đáp án được sinh đề mới mỗi lần, không lặp nguyên câu đố trong cùng mùa quay
  function mix(r,a){a=a.slice();for(var i=a.length-1;i>0;i--){var j=Math.floor(r()*(i+1)),t=a[i];a[i]=a[j];a[j]=t;}return a;}
  function quiz(r,text,right,wrong){var labels=mix(r,[right].concat(mix(r,wrong).slice(0,2)));return{text:text,labels:labels,answer:labels.indexOf(right)};}
  var ITEMS=['chiếc nón','chiếc quạt','chiếc giỏ','đèn lồng','cái trống','chiếc khăn','ấm trà','chiếc ô','bình hoa','con diều'];
  var CLUES=[['có mái che và tiếng nước','Quanh giếng có mái'],['có tiếng chuông vào giờ chiều','Trong sân đình'],['có bóng mát và tiếng lá xào xạc','Dưới gốc đa đầu làng'],['có thuyền neo và mùi sông nước','Ở bến đò'],['thơm mùi bánh mới ra lò','Trước lò bánh đầu ngõ'],['ồn ào tiếng mặc cả từ sáng sớm','Giữa chợ phiên']];
  var ACTS=[['mở ô, chỉ lên trời rồi giả vờ ướt áo','Trời mưa'],['quăng cần ra xa rồi giật mạnh','Đi câu cá'],['khom lưng cắm mạ, lau mồ hôi','Cấy lúa'],['đạp hai chân, tay giữ tay lái','Đạp xe'],['chụm tay thổi rồi xoa xoa hai vai','Trời lạnh'],['vẫy tay chào rồi kéo vali','Đi du lịch'],['múa tay theo nhịp, miệng hát không thành tiếng','Hát karaoke']];
  var GEN={
    'Mật mã chiếc hộp':function(r){var a=3+Math.floor(r()*7),b=3+Math.floor(r()*7),s=a+b;return quiz(r,'Mật mã là tổng số chấm trên hai thẻ: '+a+' và '+b+'. Bạn nhập số nào?',String(s),[String(s-1),String(s+1),String(s+2)]);},
    'Nhớ thứ tự vật phẩm':function(r){var x=mix(r,ITEMS).slice(0,3);return quiz(r,'Ê-kíp vừa cho xem: '+x.join(', ')+'. Vật đứng giữa là gì?',U.cap(x[1]),[U.cap(x[0]),U.cap(x[2])]);},
    'Ghép bản đồ':function(r){var n=1+Math.floor(r()*3),m=1+Math.floor(r()*2),e=r()<.5,up=r()<.5;var lab=function(n,e,m,up){return n+' ô '+(e?'phải':'trái')+', '+m+' ô '+(up?'lên':'xuống');};
      return quiz(r,'Từ vạch xuất phát, đi '+n+' ô về '+(e?'đông':'tây')+' rồi '+m+' ô về '+(up?'bắc':'nam')+'. Bạn chọn mảnh đường nào?',lab(n,e,m,up),[lab(n,!e,m,up),lab(n,e,m,!up),lab(m,e,n,up)].filter(function(x){return x!==lab(n,e,m,up);}));},
    'Truy tìm vật phẩm':function(r){var c=U.pick(r,CLUES);return quiz(r,'Manh mối nhắc đến một chỗ '+c[0]+'. Đội bạn tìm ở đâu trước?',c[1],CLUES.filter(function(x){return x!==c;}).map(function(x){return x[1];}));},
    'Đoán từ bằng hành động':function(r){var c=U.pick(r,ACTS);return quiz(r,'Đồng đội '+c[0]+'. Bạn đoán gì?',c[1],ACTS.filter(function(x){return x!==c;}).map(function(x){return x[1];}));}
  };
  function challengeOf(v){var c=challenges[v.challenge51.index];return v.challenge51.q?Object.assign({},c,v.challenge51.q):c;}
  V.make=function(l,r){var d=vm.apply(this,arguments),v=l.flags.variety;if(!v.compact)return d;var key=v.ep+':'+v.stage;
    if(!v.challenge51||v.challenge51.key!==key){var seen=v.usedChallenges51||(v.usedChallenges51=[]),pool=challenges.map(function(c,i){return i;}).filter(function(i){return seen.indexOf(i)<0;});if(!pool.length){seen.length=0;pool=challenges.map(function(c,i){return i;});}var index=U.pick(r,pool);seen.push(index);v.challenge51={key:key,index:index,token:v.token};var gen=GEN[challenges[index].title];if(gen)v.challenge51.q=gen(r);}
    var c=challengeOf(v);v.challengeName51=c.title;d.data.challenge51=v.challenge51.index;d.title=E.VARIETY.titles[v.k]+' · Tập '+(v.ep+1)+'/'+v.total+' · '+c.title;
    d.text=v.location+' · Khách mời: '+v.guests.join(', ')+'. Đội bạn: '+v.team.join(', ')+'. '+c.text;
    d.opts=c.labels.map(function(label,i){return{k:'pick'+i,l:label,h:''};}).filter(function(o,i){return !c.strategies||c.strategies[i]!=='hard'||!v.injured&&l.st.hea>=55;});d.opts.push({k:'quit',l:'Xin dừng quay để giữ sức',h:''});return d;};
  V.apply=function(l,d,k,r,log){var v=l.flags.variety;if(!v||!v.compact)return va.apply(this,arguments);if(!E.VARIETY.valid(l,d.data)||!v.challenge51||d.data.challenge51!==v.challenge51.index||!d.opts.some(function(o){return o.k===k;}))return;
    if(k==='quit')return va.call(this,l,d,k,r,log);var i=+k.slice(4),c=challengeOf(v);if(!c||!c.labels[i])return;
    var first=true,rr=c.strategies?r:function(){if(first){first=false;return i===c.answer?0:.999999;}return r();};
    if(!c.strategies)log((c.title?c.title+': ':'')+(i===c.answer?U.pick(r,['trả lời đúng — ','đoán trúng — ','chính xác — '])+c.labels[c.answer]+'.':U.pick(r,['chưa đúng, đáp án là ','trượt mất rồi, đáp án đúng là ','tiếc quá, đáp án là '])+c.labels[c.answer]+'.'),i===c.answer?'good':'neutral');
    return va.call(this,l,d,c.strategies?c.strategies[i]:'team',rr,log);
  };
  V.auto=function(l,d,r){if(l.flags.variety&&l.flags.variety.compact)return U.pick(r,d.opts.filter(function(o){return o.k!=='quit';})).k;return vu.apply(this,arguments);};
  E.DEC.vr_vai_tro.def.text='Bạn muốn làm khách mời 2 tập hay thành viên cố định 6 tập? Mỗi tập có hai thử thách chính.';
  E.DEC.vr_vai_tro.def.opts.forEach(function(o){if(o.k==='guest'||o.k==='regular')o.h=function(l,d){return(o.k==='guest'?'4':'12')+' lượt chọn · cát-xê '+H.money(l,E.VARIETY.quote(d.fee,o.k));};});
  E.DEC.gameshow.def.text='Chọn show để xem lịch khách mời hoặc thành viên cố định.';
  var major=E.isMajor;E.isMajor=function(d){if(d&&d.id==='vr_vong'&&d.data&&d.data.challenge51!=null)return false;return major.apply(this,arguments);};
  E.LIFE51={birth:birth,free:free,snapshot:snapshot,swimCost:swimCost,family:family,inlaws:inlaws,mother:mother,challenges:challenges};
})(G);

;
/* ===== js/life65.js ===== */
/* Quê hương 63 / 34: kỷ niệm và những buổi đi chơi có người đồng hành. */
(function(G){
  'use strict';
  var E=G.E,H=E.H,U=G.U,T=E.HOMETOWN,F=E.LIFE51;
  function profile(l){var p=T.own(l);if(!p)return null;var members=l.variant==='34'&&l.prov?G.VN.P34[l.prov.neuId]:null;
    var names=members?members.members.map(function(x){return x.name;}):[p.name],places=[],foods=[];
    names.forEach(function(n){var x=T.profile(n);if(!x)return;x.places.forEach(function(s){places.push({name:s,province:n});});x.foods.forEach(function(s){foods.push({name:s,province:n});});});
    return{name:members?members.name:p.name,places:places,foods:foods,key:l.variant+':'+(members?members.id:p.name)};}
  function state(l){return l.flags.local51||(l.flags.local51={memories:{},trips:[]});}
  function parent(l){return !!(l.fam.mAlive||l.fam.fAlive&&!l.fam.noDad);}
  function allowed(l,party){if(!F.free(l)||l.age<6||!profile(l))return false;if(party==='parents')return parent(l);if(party==='friend')return l.age>=12&&l.bff&&l.bff.alive!==false;if(party==='partner')return l.age>=16&&l.partner&&l.partner.alive!==false&&l.partner.age>=16;return party==='solo'&&l.age>=16;}
  function count(l,p){return p==='parents'?(l.fam.mAlive?1:0)+(l.fam.fAlive&&!l.fam.noDad?1:0)+1:p==='solo'?1:2;}
  function who(l,p){return p==='parents'?'cùng '+(l.fam.mAlive&&l.fam.fAlive&&!l.fam.noDad?'bố mẹ':l.fam.mAlive?'mẹ':'bố'):p==='friend'?'cùng '+l.bff.name:p==='partner'?'cùng '+l.partner.name:'một mình';}
  function company(l,p){return p==='parents'?[l.fam.mAlive,l.fam.fAlive,l.fam.noDad].join(':'):p==='friend'?l.bff&&l.bff.name:p==='partner'?l.partner&&(l.partner.heritageId||l.partner.name):'solo';}
  function valid(l,d){var a=state(l).plan;return !!(a&&d&&a.token===d.token&&a.type===d.type&&a.party===d.party&&a.at===l.age&&a.location===F.snapshot(l)&&a.factor===E.lifestyleFactor(l)&&allowed(l,a.party)&&a.company===company(l,a.party)&&(!a.pid||a.pid===(l.partner.heritageId||l.partner.name))&&(!a.friend||a.friend===l.bff.name)&&state(l).trips.filter(function(t){return t.age===l.age;}).length<3);}
  // v5.6.1: giá món ăn theo mức quán bình dân / phần quà thông thường ngoài đời (triệu đồng mỗi người)
  var DISH=[[/cua Năm Căn/,.4],[/cá kho làng Vũ Đại/,.3],[/cá ngừ đại dương/,.25],[/bê chao|thịt dê/,.2],[/lợn bản|vịt quay|gỏi gà|chả mực|cá sông Đà|gỏi cá|gỏi lá/,.15],[/chè Tân Cương|hạt điều/,.15],[/bánh tráng cuốn thịt heo|gà xào măng|thắng cố|pa pỉnh tộp|thịt chua|lạp xưởng|tung lò mò|ba khía/,.11],[/canh thụt|hạt dẻ|chả cá thác lác/,.08],[/^(phở|bún|mì|mỳ|hủ tiếu|bánh canh|cao lầu|cơm tấm|cơm hến|miến|cháo|canh cá|phở chua|phở khô)/,.05],[/nem|chả tôm|cơm cháy|cam|bưởi|vải|nhãn lồng|nho|vú sữa|khóm|chuối|hồng treo|khoai|gạo|cốm/,.06],[/^bánh (căn|khọt|bèo|hỏi|cuốn|xèo)/,.045],[/^bánh|^kẹo|xôi|cơm lam|sữa|cà phê|muối tôm|don|ngọn su su/,.035]];
  function dish(name){for(var i=0;i<DISH.length;i++)if(DISH[i][0].test(name))return DISH[i][1];return .07;}
  E.dishPrice=dish;
  // địa danh: biển, hồ, phố cổ, chợ… gần như miễn phí (chỉ ăn uống, gửi xe); khu du lịch / cáp treo đắt hơn
  function place(name){if(/Bà Nà|Vinpearl|Sun World|Fansipan|cáp treo|khu du lịch|công viên|VinWonders/i.test(name))return .6;if(/biển|bãi|hồ|phố|chợ|đồi|đèo|làng|sông|núi|thác|cầu|bến|đảo|vịnh|rừng|ruộng|đồng|suối|ghềnh|mũi|phá|đầm/i.test(name))return .08;return .15;}
  E.placePrice=place;
  function cost(l,d,item){return E.activityPrice(l,(T.transport(l,item.province).v/2+(d.type==='food'?dish(item.name):place(item.name)))*count(l,d.party));}
  function begin(l,r,party){if(!allowed(l,party))return;var s=state(l);if(s.trips.filter(function(t){return t.age===l.age;}).length>=3)return;
    s.serial=(s.serial||0)+1;s.plan={token:s.serial,at:l.age,location:F.snapshot(l),factor:E.lifestyleFactor(l),party:party,company:company(l,party),type:'place',pid:party==='partner'?(l.partner.heritageId||l.partner.name):null,friend:party==='friend'?l.bff.name:null};l.pending.unshift(E.DEC.que_di51.make(l,r));}
  E.SC('que_doc',{title:function(l){var p=profile(l);return 'Khám phá quê hương · '+(p?p.name:'');},valid:function(l){return l.age>=6&&F.free(l)&&!!profile(l);},text:function(l){var p=profile(l);return p?'Quê mình có '+p.places.map(function(x){return x.name;}).join(', ')+'. Đặc sản: '+p.foods.map(function(x){return x.name;}).join(', ')+'. Bạn muốn ăn đặc sản hay rủ ai đó đi chơi?':'';},opts:[
    {k:'ok',l:function(l){return state(l).memories[profile(l).key]?'Xem kỷ niệm quê hương đã lưu':'Ghi nhớ nét đẹp quê hương';},run:function(l,r,log){var s=state(l),p=profile(l);if(!s.memories[p.key]){s.memories[p.key]=l.age;H.fx(l,{kno:1});H.mem(l,'Quê mình ở '+p.name+': '+p.places.map(function(x){return x.name;}).join(', ')+'; '+p.foods.map(function(x){return x.name;}).join(', ')+'.',3);log('Đã lưu '+p.name+' vào kỷ niệm quê hương · kiến thức +1.','good');}else log('Bạn nhớ lại '+p.name+', những món ăn và địa danh thân thuộc.','neutral');}}
  ].concat(['solo','parents','friend','partner'].map(function(p){return{k:p,l:{solo:'Tự đi khám phá',parents:'Dắt bố mẹ đi chơi',friend:'Rủ bạn thân đi chơi',partner:'Mời người yêu / bạn đời đi chơi'}[p],req:function(l){return allowed(l,p)&&state(l).trips.filter(function(t){return t.age===l.age;}).length<3;},run:function(l,r){begin(l,r,p);}};})).concat([{k:'no',l:'Để dịp khác',run:function(){}}])});
  E.DEC.que_di51={valid:valid,make:function(l){var d=Object.assign({},state(l).plan),p=profile(l),list=d.type==='food'?p.foods:p.places;
    return{id:'que_di51',title:(d.type==='food'?'Ăn đặc sản':'Đi chơi')+' · '+p.name,text:'Chọn điểm đến '+who(l,d.party)+'. Giá đã gồm đi lại và trải nghiệm cho '+count(l,d.party)+' người.',data:d,opts:list.map(function(x,i){return{k:'item'+i,l:x.name+(l.variant==='34'?' · '+x.province:''),h:H.money(l,cost(l,d,x))};}).concat([{k:'switch',l:d.type==='food'?'Chọn địa danh tham quan':'Chọn món ăn địa phương',h:''},{k:'no',l:'Hủy kế hoạch',h:''}])};},auto:function(){return 'no';},apply:function(l,dec,k,r,log){if(!valid(l,dec.data))return;var s=state(l),d=s.plan,p=profile(l);if(k==='no'){delete s.plan;return;}if(k==='switch'){d.type=d.type==='food'?'place':'food';l.pending.unshift(this.make(l,r));return;}
    if(!/^item\d+$/.test(k))return;var item=(d.type==='food'?p.foods:p.places)[+k.slice(4)];if(!item)return;var total=cost(l,d,item),bill=E.childExpense(l,total,'Đi chơi quê hương: '+item.name,false);log(bill.note,'neutral');if(!bill.ok)return;
    var text=(d.type==='food'?'Thưởng thức ':'Tham quan ')+item.name+' '+who(l,d.party)+'.';H.fx(l,{hap:3,soc:d.party==='solo'?0:2});if(d.party==='partner')l.partner.close=U.clamp((l.partner.close||50)+2,0,100);if(d.party==='friend')l.bff.close=U.clamp((l.bff.close||50)+2,0,100);
    H.mem(l,text,3);s.trips.push({age:l.age,party:d.party,name:item.name,province:item.province,cost:total,payer:bill.note});s.trips=s.trips.slice(-30);log(text,'good');delete s.plan;
  }};
  var doc=E.ACT.filter(function(a){return a.id==='que_doc';})[0];doc.avail=function(l){return profile(l)&&F.free(l)?true:'Chưa thể đi chơi quê hương lúc này';};
  // Giữ thông tin cần chọn, bỏ lời giải thích kỹ thuật trong lời kể.
  E.DEC.que_hen_ho.def.text='Bạn muốn dẫn người ấy khám phá quê mình hay cùng người ấy về quê chơi?';
  E.DEC.que_chuyen_di.def.text=function(l,d){var p=T.profile(d.province);return p?'Cùng '+d.n+' khám phá '+p.name+': chọn điểm tham quan hoặc ăn đặc sản.':'';};
  E.DEC.que_thanh_toan.def.text=function(l,d){return 'Chuyến đi cùng '+d.n+' cần '+H.money(l,T.quote(l,d))+'. Hai người chia chi phí thế nào?';};
  var wc=E.DEC.wc_su_kien;if(wc){var txt=wc.def.text;wc.def.text=function(l,d){return txt(l,d).replace(/ Tổ chức và tình huống đều hư cấu\.[\s\S]*$/,'');};}
  E.WORLD_CRIME.profiles.forEach(function(p){p[3]=p[3].map(function(s){return s.replace(/ hư cấu/g,'');});});
  E.WORLD_CRIME.cases.forEach(function(c){c.text=c.text.replace(/ hư cấu/g,'');});
  E.DEC.wc_to_chuc.def.text=function(l){return 'Một người quen ở '+G.W.BY[l.abroad&&l.abroad.code||l.country].name+' muốn giới thiệu bạn với một nhóm địa phương. Bạn có nhận lời không?';};
  E.DEC.wc_nghe.def.text='Bạn muốn tham gia hoạt động nào? Bạn sẽ bắt đầu từ vai trò nhỏ nhất.';
  E.DEC.wc_menu.def.text=function(l){return 'Những mối liên hệ ở '+G.W.BY[l.abroad&&l.abroad.code||l.country].name+'. Bạn muốn gặp người quen, xem việc hay rút lui?';};
  var migrate=E.migrateExt;E.migrateExt=function(l){if(migrate)migrate(l);l.pending=(l.pending||[]).map(function(d){if(d.id==='que_doc'&&profile(l)&&F.free(l)){var fresh=E.DEC.que_doc.make(l);fresh.manual=d.manual;return fresh;}
    var D=E.DEC[d.id];if(/^(wc_|que_hen_ho$|que_chuyen_di$|que_thanh_toan$|gameshow$|vr_vai_tro$)/.test(d.id)&&D&&D.def&&D.valid(l,d.data||{})){
      var def=D.def,a=d.data||{};d.text=typeof def.text==='function'?def.text(l,a):def.text;
      d.opts.forEach(function(o){var source=def.opts.filter(function(x){return x.k===o.k;})[0];if(!source)return;o.l=typeof source.l==='function'?source.l(l,a):source.l;o.h=typeof source.h==='function'?source.h(l,a):source.h||'';});
    }return d;});};
  E.LOCAL51={profile:profile,valid:valid,cost:cost,begin:begin};
})(G);

;
/* ===== js/life66.js ===== */
/* V5.3 — stable family identities, schooling and extracurricular development. */
(function(G){
  'use strict';
  var E=G.E,H=E.H,U=G.U;
  var TALENTS={music:'Âm nhạc',art:'Hội họa',sport:'Thể thao',science:'Khoa học',language:'Ngoại ngữ',acting:'Diễn xuất'};
  var SCHOOLS={public:{name:'Trường công',rate:0},private:{name:'Trường tư',rate:.18},international:{name:'Trường quốc tế',rate:.75}};
  var COURSES={home:{name:'Tự trải nghiệm cùng gia đình',rate:0},club:{name:'Câu lạc bộ',rate:.025},coach:{name:'Lớp có giáo viên hướng dẫn',rate:.08}};
  function hash(s){var h=2166136261;for(var i=0;i<s.length;i++)h=Math.imul(h^s.charCodeAt(i),16777619);return h>>>0;}
  function age(l,k){return l.age-k.born;}
  function init(l){E.PARENTING.children(l);(l.kids||[]).forEach(function(k){if(!k.parentId){do{l.flags.parentSerial=(l.flags.parentSerial||0)+1;k.parentId=l.id+':child:'+l.flags.parentSerial;}while(l.kids.some(function(x){return x!==k&&x.parentId===k.parentId;}));}
    if(!k.family53){var keys=Object.keys(TALENTS),v=hash(k.parentId);k.family53={innate:v%10<3?null:keys[v%keys.length],interest:keys[hash(k.parentId+'interest')%keys.length],skills:{},school:'public',course:'home'};}
    var s=k.family53;if(!SCHOOLS[s.school])s.school='public';if(!COURSES[s.course])s.course='home';if(!s.skills||typeof s.skills!=='object')s.skills={};
  });return l.kids||[];}
  function find(l,id){return init(l).filter(function(k){return k.parentId===id;})[0];}
  function free(l){return l.alive&&!(l.jailUntil!=null&&l.age<l.jailUntil)&&!(l.abroad&&l.abroad.trapped)&&!(l.flags.military&&l.age<l.flags.military);}
  function care(l,k){return k&&k.alive&&age(l,k)>=0&&k.custody!=='ex'&&!(k.jail&&age(l,k)<k.jail)&&!k.abroadStudy&&!(l.abroad&&!l.abroad.perm);}
  function schoolOK(l,k){return care(l,k)&&age(l,k)>=3&&age(l,k)<18&&k.vice!=='bỏ học'&&!k.job&&!k.uniUntil;}
  function stage(l,k){var a=age(l,k);return a<3?'Chưa đến tuổi đi học':a<6?'Mầm non':a<11?'Tiểu học':a<15?'Trung học cơ sở':a<18?'Trung học phổ thông':k.uniUntil?'Đang học đại học':k.edu>=5?'Đã học đại học':k.edu===4?'Học nghề':'Đã trưởng thành';}
  function context(l){return l.cur+':'+(l.abroad&&l.abroad.perm?l.abroad.code:l.country);}
  function quote(l,kind,key){var p=(kind==='school'?SCHOOLS:COURSES)[key];return p?l.base*p.rate:null;}
  function log(l,fn,t){if(fn)fn(t,'good');else(l.log||(l.log=[])).push({a:l.age,y:l.birthYear+l.age,t:t,k:'good'});}
  function paid(l,k,kind,amount,fn){if(!isFinite(amount)||amount<0)return {ok:false,message:'Khoản học phí không hợp lệ.'};var s=k.family53,key=kind+'Payment',p=s[key],old=p&&p.age===l.age&&p.context===context(l)?p.amount:0,delta=Math.max(0,amount-old);
    if(l.money+1e-9<delta)return {ok:false,message:'Chưa đủ tiền. Bạn có thể chọn phương án miễn phí.'};
    if(delta){H.cash(l,-delta,(kind==='school'?'Học phí':'Lớp năng khiếu')+' của '+k.name);log(l,fn,'Bạn trả '+H.money(l,delta)+' '+(kind==='school'?'học phí':'phí hoạt động')+' cho '+k.name+'.');}
    s[key]={age:l.age,amount:Math.max(old,amount),context:context(l)};return {ok:true};
  }
  function valid(l,id,at){var k=find(l,id);return free(l)&&care(l,k)&&(at==null||at===l.age)?k:null;}
  function name(l,id,value,at,fn){var k=valid(l,id,at);if(!k||age(l,k)>=18)return {ok:false,message:'Không thể đổi tên trong hoàn cảnh hiện tại.'};
    value=String(value||'').normalize('NFC').trim().replace(/\s+/g,' ');
    if(!value||value.length>60||!/^\p{L}[\p{L}\p{M} .’'\-]*$/u.test(value))return {ok:false,message:'Tên cần dài 1–60 ký tự, dùng chữ và khoảng trắng.'};
    if(age(l,k)<=2){if(l.kids.some(function(x){return x!==k&&String(x.name||'').normalize('NFC').toLocaleLowerCase()===value.toLocaleLowerCase();}))return {ok:false,message:'Tên này trùng với một người con khác.'};
      var old=k.name;if(old===value)return {ok:true,message:'Tên được giữ nguyên.'};k.name=value;
      function update(o){if(!o||typeof o!=='object')return;Object.keys(o).forEach(function(key){if((key==='n'||key==='name')&&o[key]===old)o[key]=value;else if(typeof o[key]==='object')update(o[key]);});}
      (l.pending||[]).forEach(function(d){update(d.data);});(l.sched||[]).forEach(function(d){update(d.arg);});
      log(l,fn,'Đặt tên cho bé: '+old+' → '+value+'.');H.mem(l,'Bạn chọn tên '+value+' cho con.',3);
    }else{if(k.family53.nickname===value)return {ok:true,message:'Tên gọi được giữ nguyên.'};k.family53.nickname=value;log(l,fn,'Tên gọi ở nhà của '+k.name+' là '+value+'.');}
    return {ok:true,message:'Đã lưu tên của con.'};
  }
  function school(l,id,key,at,fn){var k=valid(l,id,at);if(!k||!schoolOK(l,k)||!SCHOOLS[key])return {ok:false,message:'Con chưa thể chọn trường ở thời điểm này.'};
    var p=paid(l,k,'school',quote(l,'school',key),fn);if(!p.ok)return p;var s=k.family53;if(s.school!==key)log(l,fn,'Chọn '+SCHOOLS[key].name.toLowerCase()+' cho '+k.name+' ở bậc '+stage(l,k).toLowerCase()+'.');s.school=key;s.context=context(l);return {ok:true,message:'Đã lưu trường. Học phí bổ sung được đóng mỗi năm; đổi sang gói rẻ hơn không hoàn phần đã đóng.'};}
  function train(l,id,talent,course,at,fn){var k=valid(l,id,at);if(!k||age(l,k)<4||age(l,k)>=18||!TALENTS[talent]||!COURSES[course])return {ok:false,message:'Hoạt động dành cho con từ 4 đến 17 tuổi.'};
    var p=paid(l,k,'course',quote(l,'course',course),fn);if(!p.ok)return p;var s=k.family53;if(s.activity!==talent||s.course!==course)log(l,fn,'Đồng hành cùng '+k.name+' khám phá '+TALENTS[talent].toLowerCase()+' · '+COURSES[course].name.toLowerCase()+'.');s.activity=talent;s.course=course;s.context=context(l);return {ok:true,message:'Đã lưu hoạt động. Kỹ năng tiến bộ sau mỗi năm; năng khiếu bẩm sinh không bị thay đổi.'};}
  E.HOOKS.year.push(yearHook);function yearHook(l,r,fn){if(!l.alive)return;init(l).forEach(function(k){var s=k.family53;if(!care(l,k)||s.year===l.age)return;s.year=l.age;
    if(s.context&&s.context!==context(l)){s.school='public';s.course='home';log(l,fn,'Đã thay đổi nơi sống; chọn lại trường hoặc lớp cho '+k.name+' nếu cần.');}s.context=context(l);
    if(schoolOK(l,k)){if(!paid(l,k,'school',quote(l,'school',s.school),fn).ok){s.school='public';log(l,fn,'Ngân sách chưa đủ học phí của '+k.name+'; gia đình chuyển sang chương trình công để con tiếp tục học.');}if(s.school!=='public')k.study=U.clamp((k.study==null?50:k.study)+1,0,100);}
    if(age(l,k)>=4&&age(l,k)<18&&s.activity){if(!paid(l,k,'course',quote(l,'course',s.course),fn).ok){s.course='home';log(l,fn,'Chưa đủ tiền lớp của '+k.name+'; tiếp tục luyện tập miễn phí cùng gia đình.');}
      var t=s.activity;s.skills[t]=U.clamp((s.skills[t]||0)+2+(t===s.innate?1:0)+(s.course==='coach'?1:0),0,100);if(t==='science'||t==='language')k.study=U.clamp((k.study==null?50:k.study)+.5,0,100);
      if(s.skills[t]>=25&&!s['milestone_'+t]){s['milestone_'+t]=true;log(l,fn,k.name+' tự tin thể hiện '+TALENTS[t].toLowerCase()+' sau thời gian luyện tập.');H.mem(l,'Lần đầu '+k.name+' tự tin thể hiện '+TALENTS[t].toLowerCase()+'.',3);}
    }
  });}
  var oldMig=E.migrateExt;E.migrateExt=function(l){if(oldMig)oldMig(l);init(l);};
  E.FAMILY53={yearHook:yearHook,init:init,find:find,age:age,free:free,care:care,schoolOK:schoolOK,stage:stage,quote:quote,name:name,school:school,train:train,talents:TALENTS,schools:SCHOOLS,courses:COURSES};
})(G);

;
/* ===== js/life67.js ===== */
/* V5.4 — học chuyên, đội tuyển và nguyện vọng đại học. Điểm tuyển sinh là mô phỏng. */
(function(G){
  'use strict';
  var E=G.E,H=E.H,U=G.U;
  var SUBJECTS={math:'Toán',physics:'Vật lý',chem:'Hóa học',bio:'Sinh học',it:'Tin học',lit:'Ngữ văn',english:'Tiếng Anh',history:'Lịch sử',geo:'Địa lý'};
  var OLYMPIC=['math','physics','chem','bio','it'];
  // Nhóm ngành dùng chung với hệ thống bằng cấp/nghề nghiệp của game.
  var SCHOOLS=[
    ['hust','Đại học Bách khoa Hà Nội','Bắc','Hà Nội',26,['it']],
    ['neu','Đại học Kinh tế Quốc dân','Bắc','Hà Nội',26,['eco']],
    ['ftu','Trường Đại học Ngoại thương','Bắc','Hà Nội',27,['eco']],
    ['hmu','Trường Đại học Y Hà Nội','Bắc','Hà Nội',28,['med']],
    ['hnue','Trường Đại học Sư phạm Hà Nội','Bắc','Hà Nội',25,['edu']],
    ['hlu','Trường Đại học Luật Hà Nội','Bắc','Hà Nội',25,['law']],
    ['uet','Trường Đại học Công nghệ – ĐHQGHN','Bắc','Hà Nội',27,['it']],
    ['hus','Trường Đại học Khoa học Tự nhiên – ĐHQGHN','Bắc','Hà Nội',24,['it']],
    ['haui','Đại học Công nghiệp Hà Nội','Bắc','Hà Nội',22,['it','eco']],
    ['tump','Trường Đại học Y Dược – Đại học Thái Nguyên','Bắc','Thái Nguyên',25,['med']],
    ['dut','Trường Đại học Bách khoa – Đại học Đà Nẵng','Trung','Đà Nẵng',24,['it']],
    ['due','Trường Đại học Kinh tế – Đại học Đà Nẵng','Trung','Đà Nẵng',23,['eco']],
    ['ued','Trường Đại học Sư phạm – Đại học Đà Nẵng','Trung','Đà Nẵng',23,['edu']],
    ['huey','Trường Đại học Y – Dược, Đại học Huế','Trung','Huế',26,['med']],
    ['huelaw','Trường Đại học Luật, Đại học Huế','Trung','Huế',21,['law']],
    ['vinh','Trường Đại học Vinh','Trung','Nghệ An',20,['it','eco','edu']],
    ['qnu','Trường Đại học Quy Nhơn','Trung','Quy Nhơn',19,['it','eco','edu']],
    ['hcmut','Trường Đại học Bách khoa – ĐHQG-HCM','Nam','TP. Hồ Chí Minh',26,['it']],
    ['hcmus','Trường Đại học Khoa học tự nhiên – ĐHQG-HCM','Nam','TP. Hồ Chí Minh',25,['it']],
    ['uit','Trường Đại học Công nghệ Thông tin – ĐHQG-HCM','Nam','TP. Hồ Chí Minh',26,['it']],
    ['ueh','Đại học Kinh tế TP. Hồ Chí Minh','Nam','TP. Hồ Chí Minh',25,['eco']],
    ['ump','Đại học Y Dược TP. Hồ Chí Minh','Nam','TP. Hồ Chí Minh',28,['med']],
    ['hcmue','Trường Đại học Sư phạm TP. Hồ Chí Minh','Nam','TP. Hồ Chí Minh',25,['edu']],
    ['hcmulaw','Trường Đại học Luật TP. Hồ Chí Minh','Nam','TP. Hồ Chí Minh',25,['law']],
    ['ctu','Đại học Cần Thơ','Nam','Cần Thơ',22,['it','eco','edu','law']],
    ['agu','Trường Đại học An Giang – ĐHQG-HCM','Nam','An Giang',19,['it','eco','edu']],
    ['dthu','Trường Đại học Đồng Tháp','Nam','Đồng Tháp',19,['edu','eco']]
  ].map(function(x){return{id:x[0],name:x[1],region:x[2],city:x[3],score:x[4],majors:x[5]};});
  function state(l){return l.flags.study54||(l.flags.study54={records:{},wishes:[]});}
  function free(l){return l.alive&&(l.abroad&&l.abroad.code||l.country)==='VN'&&!(l.jailUntil!=null&&l.age<l.jailUntil)&&!(l.flags.military&&l.age<l.flags.military)&&!(l.abroad&&l.abroad.trapped);}
  function pupil(l){return free(l)&&l.age>=9&&l.age<18&&['primary','lower','upper','priv'].indexOf(l.school)>=0;}
  function applicant(l){return free(l)&&l.age>=18&&l.edu>=3&&!l.school&&!l.retired;}
  function school(id){return SCHOOLS.filter(function(x){return x.id===id;})[0];}
  var PROGRAMS={it:['Công nghệ thông tin','Kỹ thuật phần mềm','Kỹ thuật điện – điện tử','Kỹ thuật cơ khí'],eco:['Quản trị kinh doanh','Tài chính – Ngân hàng','Kế toán','Kinh tế quốc tế'],med:['Y khoa','Y học dự phòng','Điều dưỡng'],edu:['Sư phạm Toán','Sư phạm Ngữ văn','Sư phạm Tiếng Anh'],law:['Luật','Luật kinh tế','Luật quốc tế'],art:['Mỹ thuật','Thiết kế đồ họa','Nghệ thuật học']};
  function programs(u){if(u.nk)return u.majors.map(function(m){return {key:'major_'+m,major:m,name:u.mn||E.MAJORS[m]};});return u.majors.reduce(function(a,m){return a.concat((m==='it'&&/^(uit|uet|hcmus|hus)$/.test(u.id)?['Công nghệ thông tin','Kỹ thuật phần mềm','Khoa học máy tính','Hệ thống thông tin']:PROGRAMS[m]||[E.MAJORS[m]]).map(function(n,i){return {key:i?'program_'+m+'_'+i:'major_'+m,major:m,name:n};}));},[]);}
  function option(k,l,h){return{k:k,l:l,h:h||''};}
  function push(l,id,r){l.pending.unshift(E.DEC[id].make(l,r));}
  function same(l,d,kind){var s=state(l);return d&&d.at===l.age&&d.serial===s.serial&&(!kind||s.kind===kind);}
  function start(l,kind){var s=state(l);s.serial=(s.serial||0)+1;s.kind=kind;return s;}
  function stamp(l){return{at:l.age,serial:state(l).serial};}
  function readyContest(l){return pupil(l)&&state(l).contestYear!==l.age;}
  function rank(l,subject){return state(l).records[subject]||0;}
  function high(l){return l.age>=15&&(l.school==='upper'||l.school==='priv');}
  function tier(l,subject){var n=rank(l,subject);return !high(l)?Math.min(n,1):Math.min(n,OLYMPIC.indexOf(subject)>=0?4:2);}
  var LEVELS=['Đội tuyển trường','Học sinh giỏi tỉnh / thành phố','Học sinh giỏi quốc gia','Tuyển chọn đội tuyển Olympic','Olympic quốc tế'];
  function contestValid(l,d){return pupil(l)&&same(l,d,'contest')&&state(l).contestYear===l.age;}
  E.DEC.study_team54={valid:function(l,d){return readyContest(l)&&(!d||same(l,d,'choose'));},make:function(l){return{id:'study_team54',title:'Chọn môn đội tuyển',text:'Chọn một môn để thử sức trong năm nay. Thành tích trước giúp bạn tiến lên vòng cao hơn.',data:stamp(l),opts:Object.keys(SUBJECTS).map(function(k){return option(k,SUBJECTS[k],LEVELS[tier(l,k)]);}).concat([option('no','Để năm sau')])};},auto:function(l,d,r){return U.pick(r,Object.keys(SUBJECTS));},apply:function(l,d,k,r,log){if(!this.valid(l,d.data)||!d.opts.some(function(o){return o.k===k;}))return;if(k==='no')return;var s=state(l);s.kind='contest';s.subject=k;s.stage='train';s.contestYear=l.age;s.level=tier(l,k);s.prep=0;push(l,'study_contest54',r);}};
  E.DEC.study_contest54={valid:contestValid,make:function(l){var s=state(l),train=s.stage==='train';return{id:'study_contest54',title:train?'Lịch ôn đội tuyển · '+SUBJECTS[s.subject]:LEVELS[s.level]+' · '+SUBJECTS[s.subject],text:train?'Bạn muốn chuẩn bị thế nào?':s.level===3?'Bạn làm bài tuyển chọn để giành suất vào đội tuyển quốc gia.':'Buổi thi bắt đầu. Bạn chọn cách làm bài.',data:Object.assign(stamp(l),{stage:s.stage,level:s.level}),opts:train?[option('steady','Ôn đều, giữ giấc ngủ'),option('intense','Luyện đề chuyên sâu','Tiến bộ nhanh hơn, dễ căng thẳng'),option('group','Học nhóm với bạn đội tuyển'),option('stop','Rút khỏi đội tuyển')]:[option('careful','Làm chắc phần nền tảng'),option('hard','Ưu tiên bài khó','Khó hơn, có thể tạo khác biệt'),option('check','Phân bổ thời gian, kiểm tra bài')]};},auto:function(l,d){return state(l).stage==='train'?'steady':'check';},apply:function(l,d,k,r,log){var s=state(l);if(!contestValid(l,d.data)||d.data.stage!==s.stage||d.data.level!==s.level||!d.opts.some(function(o){return o.k===k;}))return;
    if(s.stage==='train'){if(k==='stop'){s.kind=null;log('Bạn rút khỏi đội tuyển năm nay để giữ sức học chính khóa.','neutral');return;}s.prep=k==='intense'?9:k==='group'?7:6;H.fx(l,{kno:k==='intense'?3:2,hap:k==='intense'?-2:1});if(l.mind)l.mind.stress=U.clamp(l.mind.stress+(k==='intense'?8:-2),0,100);s.stage='exam';push(l,'study_contest54',r);return;}
    var thresholds=[57,70,84,104,110],power=l.st.kno+s.prep+(k==='check'?2:k==='hard'?(r()<.45?6:-6):1)+(r()-.5)*12-(l.mind&&l.mind.stress>80?5:0),pass=power>=thresholds[s.level];
    if(pass){var award=power>=thresholds[s.level]+10?'giải Nhất':power>=thresholds[s.level]+5?'giải Nhì':'giải Ba';if(s.level===3)award='suất vào đội tuyển Olympic';if(s.level===4)award=power>=117?'huy chương Vàng':power>=113?'huy chương Bạc':'huy chương Đồng';
      log(SUBJECTS[s.subject]+': đạt '+award+' · '+LEVELS[s.level]+'.','big');H.mem(l,SUBJECTS[s.subject]+' · '+award+' · '+LEVELS[s.level]+'.',4);s.records[s.subject]=Math.max(rank(l,s.subject),s.level+1);H.fx(l,{hap:5});
      if(s.level<4&&high(l)&&(s.level<2||OLYMPIC.indexOf(s.subject)>=0)){s.level++;s.stage='train';push(l,'study_contest54',r);return;}
    }else{log('Chưa đạt yêu cầu '+LEVELS[s.level]+' môn '+SUBJECTS[s.subject]+'. Bạn nhận lại bài để rút kinh nghiệm.','neutral');H.fx(l,{kno:1});}s.kind=null;
  }};
  E.SC('doi_tuyen54',{title:'Thử sức đội tuyển học sinh giỏi',valid:readyContest,text:'Thầy cô mở đợt tuyển đội học sinh giỏi. Bạn muốn chọn môn để ôn luyện?',opts:[{k:'yes',l:'Chọn môn tham gia',run:function(l,r){if(readyContest(l)){start(l,'choose');push(l,'study_team54',r);}}},{k:'no',l:'Tập trung học chính khóa',run:function(){}}]});
  E.ACT.push({id:'doi_tuyen54',g:'Học tập',l:'Đội tuyển học sinh giỏi',min:9,max:17,avail:function(l){return readyContest(l)?true:'Cần đang đi học ở Việt Nam; mỗi năm một môn';},ai:{w:.2}});
  E.EVENTS.push({c:function(l){return readyContest(l)&&l.age>=15&&l.st.kno>=70&&state(l).offerYear!==l.age;},p:.45,run:function(l,a,r){state(l).offerYear=l.age;if(!l.pending.some(function(d){return /^(doi_tuyen54|study_team54|study_contest54)$/.test(d.id);}))push(l,'doi_tuyen54',r);}});
  // Sự kiện cũ dẫn vào cùng một lộ trình, không tự cấp giải tỉnh ngay lập tức.
  var oldHsg=E.DEC.thi_hsg;oldHsg.valid=readyContest;oldHsg.apply=function(l,d,k,r){if(k==='yes'&&readyContest(l)){start(l,'choose');push(l,'study_team54',r);}};
  var hs=E.DEC.hs,hm=hs.make,ha=hs.apply;
  hs.make=function(l){var d=hm.apply(this,arguments);if(free(l)&&l.age===15)d.opts.unshift(option('special54','Thi vào trường THPT chuyên','Chọn môn chuyên · có phương án trường thường nếu chưa đỗ'));return d;};
  hs.apply=function(l,d,k,r,log){if(k==='special54'){if(!free(l)||l.age!==15||!d.opts.some(function(o){return o.k===k;}))return;start(l,'special');state(l).hsFallback=d;push(l,'study_special54',r);return;}return ha.apply(this,arguments);};
  E.DEC.study_special54={valid:function(l,d){return free(l)&&l.age===15&&same(l,d,'special')&&l.school!=='voc'&&!state(l).specialDone;},make:function(l){return{id:'study_special54',title:'Thi vào THPT chuyên',text:'Đăng ký môn chuyên tại địa phương. Kết quả phụ thuộc học lực, quá trình ôn tập và bài thi.',data:stamp(l),opts:Object.keys(SUBJECTS).map(function(k){return option(k,'Chuyên '+SUBJECTS[k]);}).concat([option('regular','Chọn trường THPT thường')])};},auto:function(){return 'math';},apply:function(l,d,k,r,log){if(!this.valid(l,d.data)||!d.opts.some(function(o){return o.k===k;}))return;var s=state(l);s.specialDone=true;if(k!=='regular'&&l.st.kno+rank(l,k)*3+(r()-.5)*10>=78){s.special={subject:k,name:'THPT chuyên tại '+(l.provLabel||(l.prov&&(l.prov.neu||l.prov.old))||l.city||'địa phương'),since:l.age};l.school='upper';l.schoolEnd=18;log('Đỗ lớp chuyên '+SUBJECTS[k]+' · '+s.special.name+'.','big');H.mem(l,'Ngày đỗ lớp chuyên '+SUBJECTS[k]+'.',4);}else{if(k!=='regular')log('Chưa đỗ lớp chuyên; xét tiếp nguyện vọng THPT thường.','neutral');ha.call(hs,l,s.hsFallback,'thpt',r,log);}delete s.hsFallback;s.kind=null;}};
  function wishes(l){return state(l).wishes;}
  function threshold(s,m){return Math.min(29.5,s.score+(m==='it'?.5:0));}
  function direct(l,m){var eligible={it:['math','physics','it','chem'],eco:['math','english'],med:['bio','chem'],edu:Object.keys(SUBJECTS),law:['lit','history','english'],art:['lit','history']};return (eligible[m]||[]).some(function(k){return rank(l,k)>=3;});}
  function choiceText(x){var u=school(x.school);return u.name+' · '+(x.program||E.MAJORS[x.major]);}
  function wishValid(l,d){return applicant(l)&&same(l,d,'wishes')&&!state(l).submitted;}
  function openWishes(l,r){var s=start(l,'wishes');if(s.wishAge!==l.age){s.wishes=[];s.wishAge=l.age;s.submitted=false;}s.region=null;s.selected=null;push(l,'study_wishes54',r);}
  E.DEC.study_wishes54={valid:wishValid,make:function(l){var s=state(l),os=[];if(s.selected){var u=school(s.selected);os=programs(u).map(function(p){return option(p.key,p.name,'Mốc mô phỏng '+threshold(u,p.major)+'/30'+(direct(l,p.major)?' · đủ thành tích xét tuyển thẳng phù hợp':''));});os.push(option('back','Quay lại danh sách trường'));}
    else if(s.region){os=SCHOOLS.filter(function(x){return x.region===s.region;}).map(function(x){return option('school_'+x.id,x.name,x.city);});os.push(option('back','Đổi khu vực'));}
    else{if(s.wishes.length<5)['Bắc','Trung','Nam'].forEach(function(x){os.push(option('region_'+x,'Thêm nguyện vọng · miền '+x));});s.wishes.forEach(function(x,i){os.push(option('remove_'+i,'Bỏ NV'+(i+1)+': '+choiceText(x),'Có thể thêm lại ở cuối danh sách'));});if(s.wishes.length)os.push(option('submit','Nộp danh sách '+s.wishes.length+' nguyện vọng'));os.push(option('cancel','Quay lại ngã rẽ sau phổ thông'));}
    return{id:'study_wishes54',title:'Nguyện vọng đại học Việt Nam',text:(s.wishes.length?s.wishes.map(function(x,i){return 'NV'+(i+1)+': '+choiceText(x);}).join('; '):'Chưa có nguyện vọng')+'. Chọn tối đa 5 trường/ngành theo thứ tự yêu thích. Xét nguyện vọng đầu tiên đủ điểm; điểm trong game là mô phỏng.',data:Object.assign(stamp(l),{view:s.selected||s.region||'list'}),opts:os};},auto:function(l,d,r){var s=state(l);if(d.opts.some(function(o){return o.k==='submit';}))return 'submit';if(s.selected){var u=school(s.selected);return 'major_'+u.majors[0];}if(s.region){var candidates=SCHOOLS.filter(function(x){return x.region===s.region;});var score=Number.isFinite(l.examScore)?l.examScore:E.rollExamScore(l,r);return 'school_'+(candidates.filter(function(x){return threshold(x,x.majors[0])<=score;})[0]||candidates[candidates.length-1]).id;}return 'region_'+U.pick(r,['Bắc','Trung','Nam']);},apply:function(l,d,k,r,log){var s=state(l);if(!wishValid(l,d.data)||d.data.view!==(s.selected||s.region||'list')||!d.opts.some(function(o){return o.k===k;}))return;
    if(k==='cancel'){s.kind=null;push(l,'uni',r);return;}if(k==='back'){if(s.selected)s.selected=null;else s.region=null;}
    else if(k.indexOf('region_')===0)s.region=k.slice(7);
    else if(k.indexOf('school_')===0)s.selected=k.slice(7);
    else if(k.indexOf('major_')===0||k.indexOf('program_')===0){var u=school(s.selected),p=u&&programs(u).filter(function(x){return x.key===k;})[0];if(s.wishes.length>=5||!p)return;if(!s.wishes.some(function(x){return x.school===u.id&&x.major===p.major&&(x.program||PROGRAMS[p.major][0])===p.name;}))s.wishes.push({school:u.id,major:p.major,program:p.name});s.selected=null;s.region=null;}
    else if(k.indexOf('remove_')===0)s.wishes.splice(+k.slice(7),1);
    else if(k==='submit'){if(!s.wishes.length)return;s.submitted=true;s.kind=null;if(!Number.isFinite(l.examScore))l.examScore=E.rollExamScore(l,r);var found=s.wishes.filter(function(x){return l.examScore>=threshold(school(x.school),x.major)||direct(l,x.major);})[0];
      log('Điểm xét tuyển: '+U.fmtNum(l.examScore,2)+'/30.','neutral');if(!found){log('Chưa đạt các nguyện vọng đã nộp. Bạn có thể ôn thi lại, học nghề hoặc đi làm.','neutral');push(l,'uniFail',r);return;}
      var admitted=school(found.school);s.admitted={school:found.school,major:found.major,program:found.program,age:l.age};l.uniName=admitted.name;l.uniCity=admitted.city;l.uniTier=admitted.score>=25?1.15:1;l.cityStudent={city:admitted.city,since:l.age};E.DEC.major.apply(l,E.DEC.major.make(l),found.major,r,log);if(found.program)l.majorName=found.program;log('Trúng tuyển NV'+(s.wishes.indexOf(found)+1)+': '+choiceText(found)+(direct(l,found.major)?' · xét thành tích học sinh giỏi.':'.'),'big');H.mem(l,'Nhập học '+choiceText(found)+'.',4);return;}
    push(l,'study_wishes54',r);
  }};
  var uni=E.DEC.uni,um=uni.make,ua=uni.apply,auto=uni.auto;
  uni.make=function(l){var d=um.apply(this,arguments);if(applicant(l)){d.opts=d.opts.filter(function(o){return o.k!=='uni_big'&&o.k!=='uni_local';});d.opts.unshift(option('wishes54','Đăng ký nguyện vọng đại học Việt Nam','Chọn trường, ngành và thứ tự ưu tiên'));}return d;};
  uni.auto=function(l,d,r){if(!d.opts.some(function(o){return o.k==='wishes54';}))return auto.apply(this,arguments);var legacy=Object.assign({},d,{opts:d.opts.filter(function(o){return o.k!=='wishes54';}).concat([option('uni_big',''),option('uni_local','')])}),k=auto.call(this,l,legacy,r);return k==='uni_big'||k==='uni_local'?'wishes54':k;};
  uni.apply=function(l,d,k,r){if(k==='wishes54'){if(applicant(l)&&d.opts.some(function(o){return o.k===k;}))openWishes(l,r);return;}return ua.apply(this,arguments);};
  // Nguyện vọng Y khoa đã chọn rõ ngành, không đổi sang Quân y hoặc trường khác sau nhập học.
  var med=E.DEC.nganh_y,mm=med.make,ma=med.apply,mt=med.auto;
  function namedMed(l){var a=state(l).admitted;return a&&a.age===l.age&&a.major==='med'&&l.school==='uni';}
  med.make=function(l){var d=mm.apply(this,arguments);if(namedMed(l)){d.text='Xác nhận chương trình Y khoa tại '+l.uniName+'.';d.opts=d.opts.filter(function(o){return o.k==='dk';});}return d;};
  med.auto=function(l){return namedMed(l)?'dk':mt.apply(this,arguments);};
  med.apply=function(l,d,k,r,log){if(!namedMed(l))return ma.apply(this,arguments);if(k!=='dk'||!d.opts.some(function(o){return o.k===k;}))return;l.med={track:'dk',spec:null};l.majorName=E.MED_TRACK.dk.n;l.schoolEnd=l.age+6;log('Xác nhận học Y khoa tại '+l.uniName+' · 6 năm.','good');};
  E.EDUCATION54={state:state,schools:SCHOOLS,programs:programs,subjects:SUBJECTS,pupil:pupil,applicant:applicant,tier:tier,direct:direct,threshold:threshold,open:openWishes};
})(G);

;
/* ===== js/finale.js ===== */
/* Một Đời — khúc cuối đời (hồi tưởng, di nguyện, hôn mê, xuôi tay), chia sẻ cuộc đời qua đường link, lưu 10 đời gần nhất. */
(function (G) {
  'use strict';
  var U = G.U, E = G.E;

  function pickMemories(l, n) {
    var m = (l.mem || []).slice().filter(function (x) { return x && x.t; });
    // v2.3: những dòng người chơi đánh dấu ⭐ được ưu tiên trong hồi tưởng
    // v2.9: dòng đã có trong ký ức thì nâng lên thành khoảnh khắc ⭐ (trước đây bị bỏ qua)
    starred(l).forEach(function (e) {
      var t = e.t.replace(/\.$/, ''), same = m.filter(function (x) { return x.t === e.t || x.t === t; })[0];
      if (same) { var i = m.indexOf(same); m[i] = { a: same.a, t: same.t, w: 10, star: true }; } else m.push({ a: e.a, t: t, w: 10, star: true });
    });
    m.sort(function (a, b) { return b.w - a.w || a.a - b.a; });
    var top = m.slice(0, n);
    // luôn giữ một ký ức tuổi thơ để khúc hồi tưởng trọn vẹn
    if (n >= 3 && !top.some(function (x) { return x.a < 16; })) {
      var kid = m.filter(function (x) { return x.a < 16 && x.a > 0; })[0] || m.filter(function (x) { return x.a < 16; })[0];
      if (kid) { top = top.slice(0, n - 1); top.push(kid); }
    }
    // v4.4: hồi tưởng luôn có người bạn đời (còn sống hay đã mất)
    var sp = E.spousesOf ? E.spousesOf(l) : [];
    if (n >= 3 && sp.length && !top.some(function (x) { return sp.some(function (s) { return x.t.indexOf(s) >= 0; }); })) {
      var sm = m.filter(function (x) { return sp.some(function (s) { return x.t.indexOf(s) >= 0; }); })[0];
      if (sm) { var drop = top.filter(function (x) { return !(x.a < 16) && !x.star; }).sort(function (a, b) { return a.w - b.w; })[0] || top[top.length - 1]; top.splice(top.indexOf(drop), 1, sm); }
    }
    top.sort(function (a, b) { return a.a - b.a; });
    return top;
  }
  function selfWord(l) { return l.kids.some(function (k) { return k.alive; }) ? (l.sex === 'M' ? 'bố' : 'mẹ') : 'tôi'; }

  function wishes(l, r) {
    var me = selfWord(l), w = [];
    var kids = l.kids.filter(function (k) { return k.alive; });
    var lost = l.kids.filter(function (k) { return !k.alive; });
    if (kids.length > 1) w.push('Các con phải thương yêu, đùm bọc lấy nhau. Anh em trong nhà đừng vì đồng tiền mà xa nhau.');
    else if (kids.length === 1) w.push('Con ơi, sống cho thật vui, đừng gồng gánh một mình. ' + U.cap(me) + ' luôn tự hào về con.');
    if (l.partner && l.partner.status !== 'dating') w.push(kids.length ? 'Các con thay ' + me + ' chăm sóc ' + (l.partner.sex === 'F' ? 'mẹ' : 'bố') + ' nhé.' : 'Gửi ' + l.partner.name + ': cảm ơn vì đã đi cùng tôi đến tận cuối con đường.');
    if (l.grand) w.push('Dạy các cháu sống tử tế, học hành tới nơi tới chốn.');
    if (E.H.debtTotal(l) > 0.5 || l.money < 0) w.push('Khoản nợ ' + me + ' còn để lại, ' + (kids.length ? 'các con' : 'mọi người') + ' thu xếp trả giúp, đừng để người ta chê cười.');
    if (l.record || (l.addict && (l.addict.gamble || l.addict.drugs))) w.push('Đừng bao giờ đi vào con đường ' + me + ' từng đi. Cái giá phải trả đắt lắm.');
    if (!l.flags.will70 && l.flags.will === 'equal' && kids.length > 1) w.push('Tài sản chia đều cho các con. Đừng vì nó mà mất lòng nhau.');
    else if (!l.flags.will70 && l.flags.will && l.flags.will !== 'charity' && l.flags.will !== 'none' && kids.length === 1) w.push('Ngôi nhà này để lại cho con, giữ lấy hương hỏa tổ tiên.');
    if (!l.flags.will70 && l.flags.will === 'charity') w.push('Phần tài sản đã hứa, nhớ mang tặng ngôi trường trên bản cho ' + me + '.');
    if (l.movedTo || (l.abroad && l.abroad.perm)) w.push('Đưa ' + me + ' về quê, cho ' + me + ' nằm cạnh ông bà.');
    if (/Phật/.test(l.religion || '')) w.push('Làm lễ theo nghi thức nhà Phật, đừng làm linh đình tốn kém.');
    else if (/Công giáo|Tin Lành|Kitô|Chính Thống/.test(l.religion || '')) w.push('Cho ' + me + ' được an nghỉ trong nghĩa trang của giáo xứ.');
    if (l.bff && l.bff.alive) w.push('Nhắn với ' + l.bff.name + ': cảm ơn vì đã làm bạn với ' + me + ' suốt một đời.');
    if (lost.length) w.push('Kiếp sau, mong được gặp lại ' + lost[0].name + '.');
    if (l.ins && l.ins.type === 'protect' && (kids.length || l.partner)) w.push('Hợp đồng bảo hiểm ' + me + ' cất trong tủ, nhớ làm thủ tục nhận tiền mà lo cho gia đình.');
    if (l.assets && l.assets.land > 0.5) w.push('Lô đất ' + me + ' mua năm ấy, đừng bán vội.');
    var pts = E.H.pets ? E.H.pets(l) : [];
    if (pts.length) w.push('Nhờ ai đó nuôi giúp ' + pts[0].n + ', nó quen được ' + me + ' cho ăn mỗi chiều.');
    if (!kids.length && !l.partner) w.push('Đừng tổ chức tang lễ rình rang. Cứ để ' + me + ' đi nhẹ nhàng như một cơn gió.');
    if ((l.karma || 0) >= 30) w.push('Cứ sống tử tế, rồi đời sẽ thương mình.');
    if (!w.length) w.push('Sống vui lên, đừng tiếc nuối điều gì.');
    // trộn nhẹ & giới hạn 4
    for (var i = w.length - 1; i > 0; i--) { var j = Math.floor(r() * (i + 1)); var t = w[i]; w[i] = w[j]; w[j] = t; }
    return w.slice(0, 4);
  }

  function companions(l) {
    var c = [];
    if (l.partner && l.partner.status !== 'dating') c.push(E.H.partnerWord(l, l.partner) + ' ' + l.partner.name);
    var kids = l.kids.filter(function (k) { return k.alive; });
    if (kids.length) c.push(kids.length === 1 ? 'con ' + kids[0].name : 'các con');
    if (l.grand) c.push('đàn cháu');
    if (l.bff && l.bff.alive) c.push('người bạn thân ' + l.bff.name);
    var pts = E.H.pets ? E.H.pets(l) : [];
    if (pts.length && (pts[0].k === 'chó' || pts[0].k === 'mèo')) c.push((c.length ? 'cả ' : '') + 'chú ' + pts[0].k + ' ' + pts[0].n);
    return c;
  }

  function suddenText(l, cause) {
    if (/giao thông|xe|đua/.test(cause)) return 'Một tiếng phanh gấp. Ánh đèn pha chói lòa. Rồi tất cả tối sầm.';
    if (/đuối nước|lũ/.test(cause)) return 'Dòng nước cuộn xiết kéo bạn đi. Bạn cố vươn tay về phía bờ…';
    if (/Campuchia/.test(cause)) return 'Nơi đất khách, giữa những bức tường rào kẽm gai, bạn nhắm mắt khi vẫn còn nghĩ về nhà.';
    if (/chiến|pháo|súng|đạn|trận/.test(cause)) return 'Một tiếng nổ chát chúa. Mặt đất rung chuyển. Bầu trời bỗng lặng im.';
    if (/đâm|bắn|thanh toán|cướp|đánh/.test(cause)) return 'Một nhát dao trong đêm. Bạn ngã xuống mặt đường lạnh ngắt.';
    if (/cứu người/.test(cause)) return 'Bạn đã kịp đẩy người kia lên bờ. Còn bạn thì không kịp nữa.';
    if (/nhồi máu|đột quỵ/.test(cause)) return 'Một cơn đau thắt ngực ập đến không báo trước. Bạn khuỵu xuống.';
    return 'Mọi chuyện xảy ra quá nhanh, không ai kịp trở tay.';
  }

  function finale(l) {
    var d = l.death; if (!d) return [];
    var h = { rs: (l.rs ^ 0x5bd1e995) | 0 }, r = function () { return U.rand(h); };
    var a = d.age, name = l.name, st = [];
    var mems = pickMemories(l, a >= 40 ? 6 : 4);
    if (a < 6) {
      st.push({ h: 'Một sinh linh bé nhỏ', x: 'Bố mẹ ôm ' + name + ' vào lòng. Tiếng khóc ngày nào còn văng vẳng bên tai.' });
      st.push({ h: 'Ra đi', x: name + ' ra đi vì ' + d.cause + ' khi ' + (a === 0 ? 'chưa tròn một tuổi' : 'mới ' + a + ' tuổi') + '. Có những cuộc đời ngắn ngủi như một cánh chuồn chuồn.' });
      return st;
    }
    if (d.sudden) {
      st.push({ h: 'Khoảnh khắc ấy', x: suddenText(l, d.cause) });
      var last4 = mems.slice(-4), sp4 = E.spousesOf ? E.spousesOf(l) : [], spm = mems.filter(function (x) { return sp4.some(function (s) { return x.t.indexOf(s) >= 0; }); })[0];
      if (spm && last4.indexOf(spm) < 0) { last4[0] = spm; last4.sort(function (a, b) { return a.a - b.a; }); }
      if (mems.length) st.push({ h: 'Những hình ảnh cuối cùng lướt qua', list: last4.map(function (m) { return (m.a === 0 ? 'Lúc chào đời' : m.a + ' tuổi') + ' — ' + m.t; }) });
      st.push({ h: 'Lặng im', x: name + ' ra đi ở tuổi ' + a + (a < 50 ? ', khi còn quá nhiều điều dang dở.' : '.') + ' Không kịp nói lời từ biệt.' });
      return st;
    }
    var season = U.pick(r, ['Một sáng mùa đông', 'Một chiều cuối thu', 'Một đêm mưa phùn', 'Giữa mùa hè oi ả']);
    var where = l.gdp < 4 && l.money < l.base ? 'nằm ở nhà vì không đủ tiền viện phí' : U.pick(r, ['nhập viện', 'nằm điều trị ở bệnh viện tỉnh', 'được đưa về nhà theo ý nguyện']);
    var comp = companions(l);
    st.push({ h: 'Phát bệnh', x: season + ' năm ' + d.year + ', ' + name + ' trở bệnh nặng vì ' + d.cause + ', phải ' + where + '. ' +
      (comp.length ? U.cap(comp.join(', ')) + ' thay nhau túc trực bên giường.' : 'Bên giường bệnh chỉ có một cô y tá trực đêm.') });
    var late = l.flags && l.flags.lateSpouse && !(l.partner && l.partner.status !== 'dating') ? l.flags.lateSpouse : null;
    if (mems.length) st.push({ h: 'Hồi tưởng', x: 'Trong cơn mê, ký ức ùa về như một thước phim cũ' + (late ? ' — có lúc ' + name + ' khẽ gọi tên ' + late + ', như thể người ấy đang ngồi ngay bên giường' : '') + ':', list: mems.map(function (m) { return (m.a === 0 ? 'Lúc chào đời' : m.a + ' tuổi') + ' — ' + m.t; }) });
    st.push({ h: 'Di nguyện', x: 'Lúc còn tỉnh táo, ' + name + ' nắm tay ' + (comp[0] || 'người bên cạnh') + ', thều thào dặn dò:', list: wishes(l, r).map(function (w) { return '“' + w + '”'; }) });
    st.push({ h: 'Hôn mê', x: 'Những ngày cuối, ' + name + ' chìm vào trạng thái mê man. Tiếng ' + (l.kids.some(function (k) { return k.alive; }) ? 'con cháu gọi' : 'người thân gọi') + ' văng vẳng, xa dần, xa dần…' });
    var t = U.pick(r, ['Rạng sáng', 'Lúc gà gáy canh tư', 'Một buổi chiều lặng gió', 'Nửa đêm']);
    st.push({ h: 'Xuôi tay', x: t + ', ' + name + ' trút hơi thở cuối cùng, ' + (a >= 60 ? 'hưởng thọ ' : 'hưởng dương ') + a + ' tuổi. Gương mặt thanh thản như đang ngủ.' });
    return st;
  }

  // ---------- Chia sẻ qua đường link ----------
  function b64encode(str) {
    if (typeof TextEncoder !== 'undefined' && typeof btoa !== 'undefined') {
      var bytes = new TextEncoder().encode(str), bin = '';
      for (var i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
      return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    }
    return Buffer.from(str, 'utf8').toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }
  function b64decode(s) {
    s = s.replace(/-/g, '+').replace(/_/g, '/'); while (s.length % 4) s += '=';
    if (typeof TextDecoder !== 'undefined' && typeof atob !== 'undefined') {
      var bin = atob(s), bytes = new Uint8Array(bin.length);
      for (var i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
      return new TextDecoder().decode(bytes);
    }
    return Buffer.from(s, 'base64').toString('utf8');
  }
  function summary(l, words) {
    return {
      v: 1, difficulty: l.difficulty || 'normal', id: l.id, n: l.name, s: l.nameSub || '', x: l.sex, w: E.isVN(l) ? (l.provLabel || l.prov.old) + ', Việt Nam' : l.countryName,
      y: l.birthYear + ' – ' + (l.death ? l.death.year : l.birthYear + l.age), a: l.death ? l.death.age : l.age, c: l.death ? l.death.cause : '',
      o: E.obituary(l), f: words || l.finalWords || '', e: Math.round(l.e0sex * 10) / 10, k: l.karma || 0,
      m: (l.yrs || []).map(function (y) { return Math.min(9, Math.max(0, Math.floor(y.hap / 10))); }).join(''),
      mem: pickMemories(l, 3).map(function (m) { return m.a + '|' + m.t; }),
      md: (l.medals || []).length, kd: l.kids.length, ed: E.EDU[l.edu],
      // v2.3: khoảnh khắc người chơi đánh dấu ⭐, nghề chính, tài sản cuối đời, thế hệ
      st: starred(l).slice(0, 3).map(function (e) { return e.a + '|' + String(e.t).slice(0, 140); }),
      jt: mainJob(l), nw: l.indep ? E.fmtMoney(l, E.netWorth(l)) : '', g: l.gen || 1
    };
  }
  function starred(l) { return (l.log || []).filter(function (e) { return e && e.star; }); }
  function mainJob(l) {
    if (l.peakTitle) return U.cap(l.peakTitle);
    if (l.job) return U.cap(E.jobTitle(l));
    var h = l.jobsHist || [];
    if (!h.length) return '';
    var main = h.map(function (x, i) { return { id: x.id, len: (h[i + 1] ? h[i + 1].from : l.age) - x.from }; }).sort(function (a, b) { return b.len - a.len; })[0];
    return U.cap(E.jobLabel(main.id));
  }
  function encode(sum) { return b64encode(JSON.stringify(sum)); }
  function decode(s) { try { var o = JSON.parse(b64decode(s)); return o && o.n ? o : null; } catch (e) { return null; } }
  function pushRecent(list, item, max) {
    list = (list || []).filter(function (x) { return x && x.id !== item.id; });
    list.unshift(item);
    return list.slice(0, max || 10);
  }

  E.finale = finale; E.wishes = function (l) { var h = { rs: 7 }; return wishes(l, function () { return U.rand(h); }); };
  E.starred = starred; E.mainJob = mainJob;
  E.pickMemories = pickMemories; E.share = { summary: summary, encode: encode, decode: decode, pushRecent: pushRecent };
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
/* ===== js/life68.js ===== */
/* V5.5.1 — di chúc chủ động từ tuổi 70, không tiêu hao lượt/năm.
   V6.5.0 — di chúc đa dạng hơn: tự chia theo tỉ lệ cho từng người con, bạn đời, bạn bè, các cháu, một người khác
   hoặc để lại cho xã hội (quỹ khuyến học, bệnh nhi, mái ấm…); phần chưa chia và người không có di chúc chia theo pháp luật;
   con chưa thành niên luôn được ít nhất 2/3 một suất thừa kế theo pháp luật (Việt Nam). */
(function(G){
  'use strict';
  var E=G.E,H=E.H;
  var CAUSES={hoc:'Quỹ khuyến học cho học sinh nghèo ở quê nhà',benh:'Quỹ hỗ trợ bệnh nhi ung thư',tre:'Mái ấm, trại trẻ mồ côi',truong:'Quỹ học bổng mang tên bạn ở trường cũ',tho:'Nơi thờ tự bạn vẫn hay lui tới',rung:'Quỹ trồng rừng, bảo vệ môi trường',gia:'Viện dưỡng lão cho người già neo đơn'};
  function allowed(l){return l.alive&&l.age>=70;}
  function kids(l){return(l.kids||[]).filter(function(k){return k.alive!==false;});}
  function spouse(l){return l.partner&&l.partner.alive!==false&&l.partner.status!=='dating'?l.partner:null;}
  function partnerKey(l,p){return p&&(p.heritageId||[p.name,p.sex,l.birthYear+l.age-p.age].join(':'));}
  function friends(l){return E.friendsOf?E.friendsOf(l).filter(function(f){return f&&f.name;}):[];}
  function kidAge(l,k){return l.age-(k.born||0);}
  // người có thể nhận khi tự chia theo tỉ lệ
  function recipients(l){
    var a=[],p=spouse(l);
    (l.kids||[]).forEach(function(k,i){if(k.alive!==false)a.push({key:'k'+i,name:k.name,kind:'kid',idx:i,note:(k.sex==='M'?'con trai':'con gái')+', '+kidAge(l,k)+' tuổi'});});
    if(p)a.push({key:'p',name:p.name,kind:'spouse',note:'bạn đời'});
    if((l.grand||0)>0)a.push({key:'g',name:'Các cháu',kind:'grand',note:l.grand+' đứa cháu'});
    var seen={};friends(l).forEach(function(f){if(seen[f.name])return;seen[f.name]=1;a.push({key:'f:'+f.name,name:f.name,kind:'friend',note:'bạn thân'});});
    a.push({key:'o',name:'Một người khác',kind:'other',note:'tự ghi tên'});
    a.push({key:'s',name:'Xã hội / từ thiện',kind:'society',note:'chọn quỹ bên dưới'});
    return a;
  }
  function choices(l){var a=[{k:'personal',l:'Chỉ để lại lời nhắn'}];if(kids(l).length)a.push({k:'equal',l:'Chia đều di sản cho các con còn sống'});if(spouse(l))a.push({k:'spouse',l:'Để lại di sản cho '+spouse(l).name});if(spouse(l)&&kids(l).length)a.push({k:'family',l:'Một nửa cho bạn đời, một nửa chia đều cho các con'});a.push({k:'custom',l:'Tự chia theo tỉ lệ: từng người con, bạn đời, người khác, xã hội'});a.push({k:'charity',l:'Để lại toàn bộ cho xã hội / hoạt động từ thiện'});return a;}
  function valid(l,d){return allowed(l)&&(!d||d.at==null||d.at===l.age)&&(!d||d.revision==null||d.revision===(l.flags.willRevision70||l.flags.will70&&l.flags.will70.revision||0));}
  function shareSum(sh){return Object.keys(sh||{}).reduce(function(s,k){return s+(+sh[k]||0);},0);}
  function check(l,d){
    if(!valid(l,d))return 'Hoàn cảnh đã thay đổi, hãy mở lại di chúc.';
    if(!choices(l).some(function(x){return x.k===d.plan;}))return 'Người nhận không còn phù hợp. Hãy chọn lại.';
    if(typeof d.note!=='string'||d.note.length>1000)return 'Lời nhắn tối đa 1.000 ký tự.';
    if(d.plan==='personal'&&!d.note.trim())return 'Hãy viết lời nhắn hoặc chọn cách để lại tài sản.';
    if(d.plan==='spouse'||d.plan==='family'){if(d.partner!==partnerKey(l,spouse(l)))return 'Thông tin bạn đời đã thay đổi, hãy mở lại di chúc.';}
    if((d.plan==='charity'||d.plan==='custom')&&d.cause&&!CAUSES[d.cause])return 'Hãy chọn lại quỹ / tổ chức nhận.';
    if(d.plan==='custom'){
      var sh=d.shares||{},keys=recipients(l).map(function(x){return x.key;}),bad=Object.keys(sh).filter(function(k){var v=sh[k];return keys.indexOf(k)<0&&+v>0||!(typeof v==='number'&&isFinite(v)&&v>=0&&v<=100&&Math.round(v)===v);});
      if(bad.length)return 'Mỗi phần phải là số nguyên từ 0 đến 100%.';
      var sum=shareSum(sh);if(sum<=0)return 'Hãy chia ít nhất một phần cho ai đó.';if(sum>100)return 'Tổng các phần đang là '+sum+'%, không được quá 100%.';
      if(+sh.p>0&&d.partner!==partnerKey(l,spouse(l)))return 'Thông tin bạn đời đã thay đổi, hãy mở lại di chúc.';
      if(+sh.o>0){var n=typeof d.otherName==='string'?d.otherName.trim():'';if(!n||n.length>60)return 'Hãy ghi tên người nhận (tối đa 60 ký tự).';}
      if(+sh.s>0&&!d.cause)return 'Hãy chọn quỹ / tổ chức xã hội nhận phần di sản.';
    }
    return '';
  }
  E.DEC.di_chuc={valid:valid,make:function(l){var w=l.flags.will70,plan=w&&w.plan||(['equal','charity'].indexOf(l.flags.will)>=0?l.flags.will:'personal');if(!choices(l).some(function(x){return x.k===plan;}))plan='personal';
    var shares={};if(w&&w.shares)Object.keys(w.shares).forEach(function(k){if(recipients(l).some(function(x){return x.key===k;}))shares[k]=w.shares[k];});
    return{id:'di_chuc',title:w?'Xem / sửa di chúc':'Viết di chúc',text:'Bạn có thể sửa bất cứ lúc nào. Bản lưu mới nhất sẽ thay thế bản trước; tài sản vẫn thuộc về bạn khi còn sống. Phần không ghi trong di chúc sẽ chia theo pháp luật.',data:{at:l.age,revision:l.flags.willRevision70||w&&w.revision||0,note:w&&w.note||'',plan:plan,partner:partnerKey(l,spouse(l)),shares:shares,cause:w&&w.cause||'hoc',otherName:w&&w.otherName||''},opts:[{k:'save',l:'Lưu di chúc',h:''},{k:'none',l:'Đóng, không thay đổi',h:''}].concat(w?[{k:'revoke',l:'Hủy bản di chúc đã lưu',h:''}]:[])};},
    auto:function(){return 'none';},
    apply:function(l,d,k,r,log){if(!valid(l,d.data)||!d.opts.some(function(o){return o.k===k;}))return;if(k==='none')return;if(k==='revoke'){l.flags.willRevision70=(l.flags.willRevision70||l.flags.will70&&l.flags.will70.revision||0)+1;delete l.flags.will70;delete l.flags.will;log('Bạn hủy bản di chúc đã lưu.','neutral');return;}if(check(l,d.data))return;var old=l.flags.will70,revision=(l.flags.willRevision70||old&&old.revision||0)+1;l.flags.willRevision70=revision;
      var w={revision:revision,age:l.age,year:l.birthYear+l.age,note:d.data.note.trim(),plan:d.data.plan,partner:d.data.partner,partnerName:spouse(l)&&spouse(l).name};
      if(d.data.plan==='charity')w.cause=CAUSES[d.data.cause]?d.data.cause:'hoc';
      if(d.data.plan==='custom'){var sh={},rs=recipients(l);Object.keys(d.data.shares||{}).forEach(function(key){var v=+d.data.shares[key];if(v>0){sh[key]=v;var x=rs.filter(function(y){return y.key===key;})[0];if(x&&x.kind==='kid')(w.kidNames||(w.kidNames={}))[key]=x.name;}});w.shares=sh;if(sh.s)w.cause=d.data.cause;if(sh.o)w.otherName=d.data.otherName.trim();}
      l.flags.will70=w;l.flags.will=d.data.plan;log((old?'Cập nhật':'Lưu')+' di chúc ở tuổi '+l.age+'.','neutral');}};
  E.ACT.push({id:'di_chuc70',g:'Tiền bạc',l:'Viết / sửa di chúc',min:70,jail:true,trap:true,mil:true,sc:'di_chuc',avail:function(l){return allowed(l)?true:'Từ 70 tuổi';},ai:{w:0}});
  var actions=E.actions,act=E.act,avail=E.actAvail;
  E.actions=function(l){return actions.apply(this,arguments).map(function(a){if(a.id==='di_chuc70')a.ok=allowed(l)?true:'Từ 70 tuổi';return a;});};
  E.actAvail=function(l,a){return a&&a.id==='di_chuc70'?(allowed(l)?true:'Từ 70 tuổi'):avail.apply(this,arguments);};
  E.act=function(l,id){if(id!=='di_chuc70')return act.apply(this,arguments);if(!allowed(l))return null;var d=E.DEC.di_chuc.make(l);d.manual=true;l.pending=(l.pending||[]).filter(function(x){return x.id!=='di_chuc';});l.pending.unshift(d);return d;};
  // người thừa kế theo pháp luật (hàng thứ nhất): các con còn sống và bạn đời còn sống
  function legalHeirs(l){var a=[];(l.kids||[]).forEach(function(k,i){if(k.alive!==false)a.push({name:k.name,kid:i});});var p=spouse(l);if(p)a.push({name:p.name,spouse:true});return a;}
  function vn(l){return H.isVN(l)&&!(l.abroad&&l.abroad.perm);}
  function compute(l,w){
    var amount=Math.max(0,E.netWorth(l)),list=[],p=spouse(l),samePartner=w&&p&&partnerKey(l,p)===w.partner,recipients=kids(l);
    function give(name,fraction,extra){if(fraction>0)list.push(Object.assign({name:name,amount:amount*fraction},extra||{}));}
    function kidGive(fraction){recipients.forEach(function(k){give(k.name,fraction/recipients.length,{kid:l.kids.indexOf(k)});});}
    if(w){
      if(w.plan==='equal'&&recipients.length)kidGive(1);
      if(w.plan==='spouse'&&samePartner)give(p.name,1,{spouse:true});
      if(w.plan==='family'){if(samePartner)give(p.name,.5,{spouse:true});if(recipients.length)kidGive(.5);}
      if(w.plan==='charity')give(CAUSES[w.cause]||'Hoạt động từ thiện',1,{society:true});
      if(w.plan==='custom'){var sh=w.shares||{};Object.keys(sh).forEach(function(key){var f=(+sh[key]||0)/100;if(!(f>0))return;
        if(key.charAt(0)==='k'&&key.charAt(1)!==':'){var i=+key.slice(1),k=l.kids[i];if(k&&k.alive!==false&&(!w.kidNames||!w.kidNames[key]||w.kidNames[key]===k.name))give(k.name,f,{kid:i});}
        else if(key==='p'){if(samePartner)give(p.name,f,{spouse:true});}
        else if(key==='g'){if((l.grand||0)>0)give('Các cháu',f,{grand:true});}
        else if(key==='o'){if(w.otherName)give(w.otherName,f,{other:true});}
        else if(key==='s')give(CAUSES[w.cause]||'Hoạt động từ thiện',f,{society:true});
        else if(key.indexOf('f:')===0){var fn=key.slice(2);if(friends(l).some(function(x){return x.name===fn;}))give(fn,f,{friend:true});}
      });}
    }
    var notes=[],heirs=legalHeirs(l);
    // VN: con chưa thành niên được ít nhất 2/3 một suất thừa kế theo pháp luật dù di chúc chia khác
    if(w&&vn(l)&&heirs.length&&amount>0){var legal=amount/heirs.length,floor=legal*2/3;
      recipients.forEach(function(k){if(kidAge(l,k)>=18)return;var i=l.kids.indexOf(k),got=list.filter(function(x){return x.kid===i;}).reduce(function(s,x){return s+x.amount;},0);if(got>=floor-1e-9)return;
        var need=floor-got,assigned=list.reduce(function(s,x){return s+x.amount;},0),free=Math.max(0,amount-assigned),fromFree=Math.min(free,need);need-=fromFree;
        if(need>1e-9){var pool=list.filter(function(x){return !(x.kid!=null&&kidAge(l,l.kids[x.kid])<18);}),tot=pool.reduce(function(s,x){return s+x.amount;},0);if(tot>0)pool.forEach(function(x){x.amount-=need*x.amount/tot;});}
        var own=list.filter(function(x){return x.kid===i;})[0];if(own)own.amount=floor;else list.push({name:k.name,amount:floor,kid:i,forced:true});
        notes.push(k.name+' chưa đủ 18 tuổi nên theo luật vẫn được hưởng ít nhất 2/3 một suất thừa kế ('+H.money(l,floor)+').');});}
    list=list.filter(function(x){return x.amount>1e-9;});
    var assigned=list.reduce(function(s,x){return s+x.amount;},0),unassigned=Math.max(0,amount-assigned),law=[];
    if(unassigned>1e-6&&heirs.length)heirs.forEach(function(h){law.push(Object.assign({amount:unassigned/heirs.length},h));});
    return{net:amount,list:list,unassigned:unassigned,law:law,notes:notes,debt:Math.min(0,E.netWorth(l))};
  }
  function settle(l){var w=l.flags.will70;if(!w||l.alive)return null;if(w.settlement)return w.settlement;w.settlement=compute(l,w);return w.settlement;}
  // di sản khi mất (có hoặc không có di chúc) — dùng cho "sống tiếp đời con"
  function estate(l){return settle(l)||(l.flags.estate65||(l.alive?compute(l,null):(l.flags.estate65=compute(l,null))));}
  function forKid(l,i){var s=estate(l);return s.list.concat(s.law).filter(function(x){return x.kid===i;}).reduce(function(t,x){return t+x.amount;},0);}
  var finale=E.finale;E.finale=function(l){var stages=finale.apply(this,arguments),w=l.flags.will70,s=settle(l);
    if(!s){if(l.alive||!l.death||l.death.age<18)return stages;var e=estate(l);if(e.net>0&&e.law.length){stages.push({h:'Thừa kế theo pháp luật',x:'Không để lại di chúc, di sản ròng '+H.money(l,e.net)+' được chia đều cho những người thừa kế hàng thứ nhất.',list:e.law.map(function(x){return x.name+': '+H.money(l,x.amount)+'.';})});}else if(e.debt<0&&legalHeirs(l).length){stages.push({h:'Thừa kế theo pháp luật',x:'Tài sản để lại không đủ trả nợ. Theo luật, người thừa kế chỉ trả nợ trong phạm vi di sản được hưởng, nên không con cháu nào phải gánh thêm.'});}return stages;}
    var lines=[];if(w.note)lines.push(w.note);if(w.plan!=='personal'){lines.push('Di sản ròng còn lại: '+H.money(l,s.net)+'.');s.list.forEach(function(x){lines.push(x.name+': '+H.money(l,x.amount)+(s.net>0?' ('+Math.round(x.amount/s.net*100)+'%)':'')+'.');});s.notes.forEach(function(n){lines.push(n);});if(s.unassigned>.000001)lines.push('Chưa phân chia: '+H.money(l,s.unassigned)+(s.list.length?' (phần của người nhận không còn phù hợp hoặc chưa ghi trong di chúc)':' (không còn người nhận phù hợp)')+(s.law.length?' — chia theo pháp luật cho '+s.law.map(function(x){return x.name;}).join(', ')+'.':'.'));}
    else if(s.law.length&&s.net>0)lines.push('Di sản ròng '+H.money(l,s.net)+' chia theo pháp luật cho '+s.law.map(function(x){return x.name;}).join(', ')+'.');
    stages.push({h:'Di chúc để lại',x:'Bản lưu năm '+w.year+' · '+w.age+' tuổi.',list:lines});return stages;};
  var migrate=E.migrateExt;E.migrateExt=function(l){if(migrate)migrate(l);l.pending=(l.pending||[]).filter(function(d){return d.id!=='di_chuc'||allowed(l);}).map(function(d){if(d.id==='di_chuc'&&(!d.data||!d.data.plan)){var fresh=E.DEC.di_chuc.make(l);fresh.manual=d.manual;return fresh;}if(d.id==='di_chuc'&&d.data&&!d.data.shares){d.data.shares={};d.data.cause=d.data.cause||'hoc';d.data.otherName=d.data.otherName||'';}return d;});};
  E.WILL70={allowed:allowed,choices:choices,check:check,settle:settle,estate:estate,forKid:forKid,recipients:recipients,causes:CAUSES,legalHeirs:legalHeirs};
})(G);

;
/* ===== js/esports-data.js ===== */
/* Danh mục tham chiếu có ngày chốt riêng; xem esports-sources.md. */
(function(G){ G.ESPORTS_DATA={
  "season": 2026,
  "checked": "2026-10-18",
  "games": {
    "lol": {
      "name": "Liên Minh Huyền Thoại"
    },
    "val": {
      "name": "Valorant"
    },
    "aov": {
      "name": "Liên Quân Mobile"
    },
    "tft": {
      "name": "Đấu Trường Chân Lý (TFT)"
    }
  },
  "leagues": [
    {
      "id": "LCK",
      "game": "lol",
      "name": "LCK",
      "host": "KR",
      "teams": [
        {
          "id": "LCK-0",
          "name": "DN SOOPers",
          "players": [
            "DuDu",
            "Pyosik",
            "Clozer",
            "deokdam",
            "Peter"
          ]
        },
        {
          "id": "LCK-1",
          "name": "KT Rolster",
          "players": [
            "PerfecT",
            "Cuzz",
            "Bdd",
            "Aiming",
            "Effort"
          ]
        },
        {
          "id": "LCK-2",
          "name": "Dplus Kia",
          "players": [
            "Siwoo",
            "Lucid",
            "ShowMaker",
            "Smash",
            "Career"
          ]
        },
        {
          "id": "LCK-3",
          "name": "HANJIN BRION",
          "players": [
            "Casting",
            "GIDEON",
            "Loki",
            "Teddy",
            "Namgung"
          ]
        },
        {
          "id": "LCK-4",
          "name": "Kiwoom DRX",
          "players": [
            "Rich",
            "Willer",
            "Ucal",
            "LazyFeel",
            "Andil"
          ]
        },
        {
          "id": "LCK-5",
          "name": "Gen.G",
          "players": [
            "Kiin",
            "Canyon",
            "Chovy",
            "Ruler",
            "Duro"
          ]
        },
        {
          "id": "LCK-6",
          "name": "Nongshim RedForce",
          "players": [
            "Kingen",
            "Sponge",
            "Scout",
            "Taeyoon",
            "Lehends"
          ]
        },
        {
          "id": "LCK-7",
          "name": "BNK FEARX",
          "players": [
            "Clear",
            "Raptor",
            "VicLa",
            "Diable",
            "Kellin"
          ]
        },
        {
          "id": "LCK-8",
          "name": "T1",
          "players": [
            "Doran",
            "Oner",
            "Faker",
            "Peyz",
            "Keria"
          ]
        },
        {
          "id": "LCK-9",
          "name": "Hanwha Life Esports",
          "players": [
            "Zeus",
            "Kanavi",
            "Zeka",
            "Gumayusi",
            "Delight"
          ]
        }
      ],
      "snapshot": "Đội hình ra sân đến 10/04/2026; LEC gồm khách mời Versus"
    },
    {
      "id": "LPL",
      "game": "lol",
      "name": "LPL",
      "host": "CN",
      "teams": [
        {
          "id": "LPL-0",
          "name": "Invictus Gaming",
          "players": [
            "Breathe",
            "Wei",
            "Renard",
            "JiaQi",
            "Meiko"
          ]
        },
        {
          "id": "LPL-1",
          "name": "Weibo Gaming",
          "players": [
            "Zika",
            "Jiejie",
            "Xiaohu",
            "Elk",
            "Hang"
          ]
        },
        {
          "id": "LPL-2",
          "name": "JD Gaming",
          "players": [
            "Xiaoxu",
            "JunJia",
            "HongQ",
            "GALA",
            "Vampire"
          ]
        },
        {
          "id": "LPL-3",
          "name": "Top Esports",
          "players": [
            "ZUIAN",
            "Tian",
            "Creme",
            "JackeyLove",
            "fengyue"
          ]
        },
        {
          "id": "LPL-4",
          "name": "Ultra Prime",
          "players": [
            "Liangchen",
            "Grizzly",
            "Saber",
            "Hena",
            "Xiaoxia"
          ]
        },
        {
          "id": "LPL-5",
          "name": "LGD Gaming",
          "players": [
            "sasi",
            "Heng",
            "Tangyuan",
            "Shaoye",
            "Ycx"
          ]
        },
        {
          "id": "LPL-6",
          "name": "Anyone's Legend",
          "players": [
            "Flandre",
            "Tarzan",
            "Shanks",
            "Hope",
            "Kael"
          ]
        },
        {
          "id": "LPL-7",
          "name": "Bilibili Gaming",
          "players": [
            "Bin",
            "Xun",
            "Knight",
            "Viper",
            "ON"
          ]
        },
        {
          "id": "LPL-8",
          "name": "Oh My God",
          "players": [
            "Hery",
            "re0",
            "haichao",
            "Starry",
            "Moham"
          ]
        },
        {
          "id": "LPL-9",
          "name": "LNG Esports",
          "players": [
            "sheer",
            "Croco",
            "BuLLDoG",
            "1xn",
            "MISSING"
          ]
        },
        {
          "id": "LPL-10",
          "name": "EDward Gaming",
          "players": [
            "Zdz",
            "Xiaohao",
            "Angel",
            "Leave",
            "Parukia"
          ]
        },
        {
          "id": "LPL-11",
          "name": "Team WE",
          "players": [
            "Cube",
            "Monki",
            "Karis",
            "About",
            "Erha"
          ]
        },
        {
          "id": "LPL-12",
          "name": "ThunderTalk Gaming",
          "players": [
            "Keshi",
            "Junhao",
            "Heru",
            "Ryan3",
            "Feather"
          ]
        },
        {
          "id": "LPL-13",
          "name": "Ninjas in Pyjamas",
          "players": [
            "HOYA",
            "Guwon",
            "Care",
            "Assum",
            "Zhuo"
          ]
        }
      ],
      "snapshot": "Đội hình ra sân đến 10/04/2026; LEC gồm khách mời Versus"
    },
    {
      "id": "LEC",
      "game": "lol",
      "name": "LEC",
      "host": "DE",
      "teams": [
        {
          "id": "LEC-0",
          "name": "Fnatic",
          "players": [
            "Empyros",
            "Razork",
            "Vladi",
            "Upset",
            "Lospa"
          ]
        },
        {
          "id": "LEC-1",
          "name": "Los Ratones",
          "players": [
            "Baus",
            "Velja",
            "Nemesis",
            "Crownie",
            "Rekkles"
          ],
          "guest": true
        },
        {
          "id": "LEC-2",
          "name": "GiantX",
          "players": [
            "Lot",
            "ISMA",
            "Jackies",
            "Noah",
            "Jun"
          ]
        },
        {
          "id": "LEC-3",
          "name": "Shifters",
          "players": [
            "Rooster",
            "Boukada",
            "nuc",
            "Paduck",
            "Trymbi"
          ]
        },
        {
          "id": "LEC-4",
          "name": "Team Heretics",
          "players": [
            "Tracyn",
            "Sheo",
            "Serin",
            "Ice",
            "Way"
          ]
        },
        {
          "id": "LEC-5",
          "name": "Natus Vincere",
          "players": [
            "Maynter",
            "Rhilech",
            "Poby",
            "SamD",
            "Parus"
          ]
        },
        {
          "id": "LEC-6",
          "name": "SK Gaming",
          "players": [
            "Wunder",
            "Skeanz",
            "LIDER",
            "Jopa",
            "Mikyx"
          ]
        },
        {
          "id": "LEC-7",
          "name": "Team Vitality",
          "players": [
            "Naak Nako",
            "Lyncas",
            "Humanoid",
            "Carzzy",
            "Fleshy"
          ]
        },
        {
          "id": "LEC-8",
          "name": "Karmine Corp",
          "players": [
            "Canna",
            "Yike",
            "kyeahoo",
            "Caliste",
            "Busio"
          ]
        },
        {
          "id": "LEC-9",
          "name": "Karmine Corp Blue",
          "players": [
            "Tao",
            "Yukino",
            "Kamiloo",
            "Hazel",
            "Prime"
          ],
          "guest": true
        },
        {
          "id": "LEC-10",
          "name": "G2 Esports",
          "players": [
            "BrokenBlade",
            "SkewMond",
            "Caps",
            "Hans Sama",
            "Labrov"
          ]
        },
        {
          "id": "LEC-11",
          "name": "Movistar KOI",
          "players": [
            "Myrwn",
            "Elyoya",
            "Jojopyun",
            "Supa",
            "Alvaro"
          ]
        }
      ],
      "snapshot": "Đội hình ra sân đến 10/04/2026; LEC gồm khách mời Versus"
    },
    {
      "id": "LCS",
      "game": "lol",
      "name": "LCS",
      "host": "US",
      "teams": [
        {
          "id": "LCS-0",
          "name": "Team Liquid",
          "players": [
            "Morgan",
            "Josedeodo",
            "Quid",
            "Yeon",
            "CoreJJ"
          ]
        },
        {
          "id": "LCS-1",
          "name": "Cloud9",
          "players": [
            "Thanatos",
            "Blaber",
            "APA",
            "Zven",
            "Vulcan"
          ]
        },
        {
          "id": "LCS-2",
          "name": "Disguised",
          "players": [
            "Castle",
            "KryRa",
            "Callme",
            "sajed",
            "Lyonz"
          ]
        },
        {
          "id": "LCS-3",
          "name": "Sentinels",
          "players": [
            "Impact",
            "HamBak",
            "DARKWINGS",
            "Rahel",
            "huhi"
          ]
        },
        {
          "id": "LCS-4",
          "name": "FlyQuest",
          "players": [
            "Gakgos",
            "Gryffinn",
            "Quad",
            "Massu",
            "Cryogen"
          ]
        },
        {
          "id": "LCS-5",
          "name": "Shopify Rebellion",
          "players": [
            "Fudge",
            "Contractz",
            "Zinie",
            "Bvoy",
            "Ceos"
          ]
        },
        {
          "id": "LCS-6",
          "name": "LYON",
          "players": [
            "Dhokla",
            "Inspired",
            "Saint",
            "Berserker",
            "Isles"
          ]
        },
        {
          "id": "LCS-7",
          "name": "Dignitas",
          "players": [
            "Photon",
            "eXyu",
            "Palafox",
            "FBI",
            "Ignar"
          ]
        }
      ],
      "snapshot": "Đội hình ra sân đến 10/04/2026; LEC gồm khách mời Versus"
    },
    {
      "id": "CBLOL",
      "game": "lol",
      "name": "CBLOL",
      "host": "BR",
      "teams": [
        {
          "id": "CBLOL-0",
          "name": "Vivo Keyd Stars",
          "players": [
            "Wizer",
            "Disamis",
            "Mireu",
            "ceo",
            "Kaiwing"
          ]
        },
        {
          "id": "CBLOL-1",
          "name": "paiN Gaming",
          "players": [
            "Robo",
            "Samkz",
            "Keine",
            "Trigger",
            "Kuri"
          ]
        },
        {
          "id": "CBLOL-2",
          "name": "RED Canids",
          "players": [
            "zynts",
            "STEPZ",
            "Kaze",
            "Morttheus",
            "frosty"
          ]
        },
        {
          "id": "CBLOL-3",
          "name": "Fluxo W7M",
          "players": [
            "curty",
            "Peach",
            "cody",
            "BAO",
            "Momochi"
          ]
        },
        {
          "id": "CBLOL-4",
          "name": "LOUD",
          "players": [
            "xyno",
            "YoungJae",
            "Envy",
            "Bull",
            "RedBert"
          ]
        },
        {
          "id": "CBLOL-5",
          "name": "FURIA",
          "players": [
            "Guigo",
            "Tatu",
            "Tutsz",
            "Ayu",
            "JoJo"
          ]
        },
        {
          "id": "CBLOL-6",
          "name": "LØS",
          "players": [
            "Zest",
            "Drakehero",
            "Feisty",
            "Duduhh",
            "Ackerman"
          ]
        },
        {
          "id": "CBLOL-7",
          "name": "Leviatan",
          "players": [
            "Devost",
            "Booki",
            "Enga",
            "Snaker",
            "TopLop"
          ]
        }
      ],
      "snapshot": "Đội hình ra sân đến 10/04/2026; LEC gồm khách mời Versus"
    },
    {
      "id": "LCP",
      "game": "lol",
      "name": "LCP",
      "host": "TW",
      "teams": [
        {
          "id": "LCP-0",
          "name": "Ground Zero Gaming",
          "players": [
            "1Jiang",
            "Husha",
            "JimieN",
            "Shunn",
            "Orca"
          ]
        },
        {
          "id": "LCP-1",
          "name": "Team Secret Whales",
          "players": [
            "Pun",
            "Hizto",
            "Dire",
            "Eddie",
            "Bie"
          ]
        },
        {
          "id": "LCP-2",
          "name": "Fukuoka SoftBank HAWKS gaming",
          "players": [
            "Evi",
            "Van",
            "Aria",
            "Marble",
            "Vsta"
          ]
        },
        {
          "id": "LCP-3",
          "name": "Deep Cross Gaming",
          "players": [
            "Flauren",
            "POP9",
            "HongSuo",
            "Feng",
            "ShiauC"
          ]
        },
        {
          "id": "LCP-4",
          "name": "CTBC Flying Oyster",
          "players": [
            "Rest",
            "Shad0w",
            "Pungyeon",
            "Doggo",
            "2274"
          ]
        },
        {
          "id": "LCP-5",
          "name": "GAM Esports",
          "players": [
            "Kiaya",
            "Draktharr",
            "Aress",
            "Artemis",
            "Taki"
          ]
        },
        {
          "id": "LCP-6",
          "name": "DetonatioN FocusMe",
          "players": [
            "Momo",
            "Citrus",
            "Fisher",
            "Kakkun",
            "Woody"
          ]
        },
        {
          "id": "LCP-7",
          "name": "MVK Esports",
          "players": [
            "Steller",
            "Gury",
            "Chika",
            "Harky",
            "SiuLoong"
          ]
        }
      ],
      "snapshot": "Đội hình ra sân đến 10/04/2026; LEC gồm khách mời Versus"
    },
    {
      "id": "AOG",
      "game": "aov",
      "name": "Đấu Trường Danh Vọng · Việt Nam",
      "host": "VN",
      "teams": [
        {
          "id": "AOG-0",
          "name": "BOOM Esports",
          "players": [
            "Emper",
            "Anne",
            "Failure",
            "DucTiep",
            "Tama",
            "Seed"
          ],
          "winterOnly": true
        },
        {
          "id": "AOG-1",
          "name": "Rex Regum Qeon",
          "players": [
            "TKien",
            "Yang",
            "Tack4",
            "Triet",
            "Karl",
            "LittleQ",
            "Veritas"
          ],
          "winterOnly": true
        },
        {
          "id": "AOG-2",
          "name": "Team Secret",
          "players": [
            "Acacia",
            "Kaisa",
            "Boka",
            "TNhan",
            "Tlinhhh",
            "TrPhuoc",
            "Ducky"
          ]
        },
        {
          "id": "AOG-3",
          "name": "BOX Gaming",
          "players": [
            "TriNguyen",
            "08QT",
            "Peak",
            "Ciara",
            "Mapu",
            "Chip"
          ]
        },
        {
          "id": "AOG-4",
          "name": "One Star Esports",
          "players": [
            "Libr4",
            "Stark",
            "Zet",
            "Sea",
            "Spiris",
            "NamMilk"
          ]
        },
        {
          "id": "AOG-5",
          "name": "FPT Polytechnic",
          "players": [
            "VIT",
            "ThanhDuy",
            "Sleepy",
            "Sindhu",
            "TheKhang",
            "Chu"
          ]
        },
        {
          "id": "AOG-6",
          "name": "GAM Esports",
          "players": [
            "Kuga",
            "Yiuling",
            "Aliyah",
            "TienPhat",
            "PhuHoang",
            "Adonis",
            "Owen"
          ]
        },
        {
          "id": "AOG-7",
          "name": "Saigon Phantom",
          "players": [
            "Nolan",
            "Yuu",
            "Fish",
            "Shin",
            "Khoa",
            "23xJuly",
            "Soul"
          ]
        },
        {
          "id": "AOG-8",
          "name": "FPT x Flash",
          "players": [
            "HuyHoang",
            "Julius",
            "Maris",
            "BeTroc",
            "Yutan",
            "HieuDuc",
            "Nắng"
          ]
        },
        {
          "id": "AOG-SPN",
          "name": "Super Nova",
          "players": [
            "Acacia",
            "Kaisa",
            "Phoenix",
            "Triết",
            "zzZ"
          ],
          "archived": true,
          "snapshot": "Mùa Xuân 2026; đã rời giải trước mùa Đông"
        }
      ],
      "snapshot": "Mùa Đông 2026"
    },
    {
      "id": "RPL",
      "game": "aov",
      "name": "RoV Pro League · Thái Lan",
      "host": "TH",
      "teams": [
        {
          "id": "RPL-0",
          "name": "Buriram United Esports",
          "players": [
            "Littleboyz",
            "AlmondP",
            "NuNu",
            "Ligky",
            "Deawwy",
            "Summer"
          ]
        },
        {
          "id": "RPL-1",
          "name": "FULL SENSE",
          "players": [
            "AshEarth",
            "Overone",
            "Agetsive",
            "Sharkz",
            "NOARje",
            "Givemeakiss"
          ]
        },
        {
          "id": "RPL-2",
          "name": "Bacon Time",
          "players": [
            "Markky",
            "Bonus",
            "Kimsensei",
            "Opar",
            "Alawin",
            "PIXZY"
          ]
        },
        {
          "id": "RPL-3",
          "name": "King of Gamers Club",
          "players": [
            "Baskung",
            "Cinderella",
            "PuPu",
            "Nightza",
            "JDust (KrataiA)",
            "GIMPO",
            "Pmons"
          ]
        },
        {
          "id": "RPL-4",
          "name": "Hydra Esports",
          "players": [
            "Possu",
            "Commiw",
            "Barely (Koffi)",
            "Wonderwall",
            "Acapae",
            "PPKAZ"
          ]
        },
        {
          "id": "RPL-5",
          "name": "eArena",
          "players": [
            "JKP",
            "NBank",
            "Jdai",
            "NEGAN",
            "Pj",
            "Ohmmy",
            "EXOLAR"
          ]
        },
        {
          "id": "RPL-6",
          "name": "Tenacity",
          "players": [
            "SRY",
            "Erez",
            "Fakeplayz",
            "MOOP",
            "Difoxn",
            "POGPOG"
          ]
        },
        {
          "id": "RPL-7",
          "name": "SOLYX Esports",
          "players": [
            "Farook",
            "Myra",
            "Psocute",
            "1S1K",
            "Joelong",
            "Ch1lly"
          ]
        },
        {
          "id": "RPL-8",
          "name": "Godji Check",
          "players": [
            "NTNz",
            "Faye",
            "Lisnyp",
            "Rika",
            "larminq",
            "Artie"
          ]
        }
      ],
      "snapshot": "Mùa Đông 2026"
    },
    {
      "id": "GCS",
      "game": "aov",
      "name": "GCS · Đài Loan / Hồng Kông",
      "host": "TW",
      "teams": [
        {
          "id": "GCS-0",
          "name": "ANK Gaming",
          "players": [
            "LiTing",
            "Tao",
            "Long",
            "BUU",
            "Guoguy",
            "WeiT"
          ]
        },
        {
          "id": "GCS-1",
          "name": "Banmei Gaming",
          "players": [
            "Neil",
            "XCaiii",
            "Junnn",
            "Yanyan",
            "Kai",
            "Leduo",
            "Baini"
          ]
        },
        {
          "id": "GCS-2",
          "name": "Cathay ONE Team",
          "players": [
            "Wuliu",
            "XH",
            "Inu",
            "Luky",
            "Hong",
            "Shao"
          ]
        },
        {
          "id": "GCS-3",
          "name": "Deep Cross Gaming",
          "players": [
            "Xcen",
            "XinChen",
            "Miruki",
            "YouLun",
            "Yaooo",
            "Weiyu"
          ]
        },
        {
          "id": "GCS-4",
          "name": "Hong Kong Attitude",
          "players": [
            "Weinnn",
            "Dwei",
            "YanPu",
            "Takeshi",
            "Metaverse",
            "Afu"
          ]
        },
        {
          "id": "GCS-5",
          "name": "LIT ESPORTS",
          "players": [
            "Kajaa",
            "Dong",
            "Baduck",
            "Yummy",
            "Zirui",
            "Leng",
            "XNNX",
            "Zui"
          ]
        },
        {
          "id": "GCS-6",
          "name": "WANIN FlashWolves",
          "players": [
            "YuXiang",
            "Zhenzhe",
            "NaiLiu",
            "Abao",
            "Zhan",
            "WeiZ"
          ]
        }
      ],
      "snapshot": "Danh sách hiện hành trên trang GCS, đọc 18/10/2026"
    },
    {
      "id": "ACS",
      "game": "aov",
      "name": "AoV Crown Series · Indonesia",
      "host": "ID",
      "teams": [
        {
          "id": "ACS-0",
          "name": "Carnifex",
          "players": [
            "Amane",
            "Tuna",
            "Yoloo",
            "Godspeed",
            "Kenshin"
          ]
        },
        {
          "id": "ACS-1",
          "name": "Cyberlaxy Esports",
          "players": [
            "Outlaw",
            "Daamha",
            "Twenty",
            "Rinss",
            "Sugarmini"
          ]
        },
        {
          "id": "ACS-2",
          "name": "Jumpstart",
          "players": [
            "Yuzuki",
            "Chandler",
            "Momochan",
            "Babymeow",
            "Han"
          ]
        },
        {
          "id": "ACS-3",
          "name": "Phenomenal One",
          "players": [
            "Kobokkobok",
            "Kocekkocek",
            "Kobelkobel",
            "Kekerkeker",
            "Krocokroco",
            "Kedutkedut"
          ]
        },
        {
          "id": "ACS-4",
          "name": "DarksideID",
          "players": [
            "Mif",
            "Volker",
            "Escipion",
            "NiChulian",
            "Yay"
          ]
        },
        {
          "id": "ACS-5",
          "name": "Timeless",
          "players": [
            "Hekal",
            "sagwa",
            "Anyaa",
            "Miracle",
            "3Muu",
            "Donuts"
          ]
        },
        {
          "id": "ACS-6",
          "name": "Silence But Deadly",
          "players": [
            "Celcius",
            "Gunslinger",
            "Shiro",
            "Molana",
            "Articvoier",
            "Yuna'",
            "Regalia'"
          ]
        },
        {
          "id": "ACS-7",
          "name": "Ascendant",
          "players": [
            "Valdo",
            "Febrychi",
            "SKRULL",
            "Hyo",
            "Nagii"
          ]
        }
      ],
      "snapshot": "24–26/04/2026 · vòng tuyển chọn APL"
    },
    {
      "id": "TFT-AMER",
      "game": "tft",
      "name": "AMER",
      "host": "US",
      "teams": [
        {
          "id": "TFT-AMER-0",
          "name": "VIT k3soju",
          "players": [
            "VIT k3soju"
          ]
        },
        {
          "id": "TFT-AMER-1",
          "name": "FNC Darth Nub",
          "players": [
            "FNC Darth Nub"
          ]
        },
        {
          "id": "TFT-AMER-2",
          "name": "ACAD Dishsoap",
          "players": [
            "ACAD Dishsoap"
          ]
        },
        {
          "id": "TFT-AMER-3",
          "name": "CTG Kaiweng",
          "players": [
            "CTG Kaiweng"
          ]
        },
        {
          "id": "TFT-AMER-4",
          "name": "CTG Dankmemes01",
          "players": [
            "CTG Dankmemes01"
          ]
        },
        {
          "id": "TFT-AMER-5",
          "name": "K0nda1",
          "players": [
            "K0nda1"
          ]
        },
        {
          "id": "TFT-AMER-6",
          "name": "FL Upsetmax",
          "players": [
            "FL Upsetmax"
          ]
        },
        {
          "id": "TFT-AMER-7",
          "name": "BruhbruhbruhWHO",
          "players": [
            "BruhbruhbruhWHO"
          ]
        },
        {
          "id": "TFT-AMER-8",
          "name": "VCLF",
          "players": [
            "VCLF"
          ]
        }
      ],
      "snapshot": "40 tuyển thủ Space Gods Tactician’s Crown · 10–12/07/2026",
      "individual": true
    },
    {
      "id": "TFT-EMEA",
      "game": "tft",
      "name": "EMEA",
      "host": "DE",
      "teams": [
        {
          "id": "TFT-EMEA-0",
          "name": "MIH ZyK0o",
          "players": [
            "MIH ZyK0o"
          ]
        },
        {
          "id": "TFT-EMEA-1",
          "name": "MIH Tarteman",
          "players": [
            "MIH Tarteman"
          ]
        },
        {
          "id": "TFT-EMEA-2",
          "name": "M8 Jedusor",
          "players": [
            "M8 Jedusor"
          ]
        },
        {
          "id": "TFT-EMEA-3",
          "name": "Pepoglad",
          "players": [
            "Pepoglad"
          ]
        },
        {
          "id": "TFT-EMEA-4",
          "name": "Guillosko h",
          "players": [
            "Guillosko h"
          ]
        },
        {
          "id": "TFT-EMEA-5",
          "name": "MIH Bensac",
          "players": [
            "MIH Bensac"
          ]
        },
        {
          "id": "TFT-EMEA-6",
          "name": "MKOI Safo20",
          "players": [
            "MKOI Safo20"
          ]
        },
        {
          "id": "TFT-EMEA-7",
          "name": "AG Horox",
          "players": [
            "AG Horox"
          ]
        },
        {
          "id": "TFT-EMEA-8",
          "name": "Hypno",
          "players": [
            "Hypno"
          ]
        }
      ],
      "snapshot": "40 tuyển thủ Space Gods Tactician’s Crown · 10–12/07/2026",
      "individual": true
    },
    {
      "id": "TFT-APAC",
      "game": "tft",
      "name": "APAC",
      "host": "VN",
      "teams": [
        {
          "id": "TFT-APAC-0",
          "name": "RRQ YBY1",
          "players": [
            "RRQ YBY1"
          ]
        },
        {
          "id": "TFT-APAC-1",
          "name": "FQ AQ1H",
          "players": [
            "FQ AQ1H"
          ]
        },
        {
          "id": "TFT-APAC-2",
          "name": "Seoill",
          "players": [
            "Seoill"
          ]
        },
        {
          "id": "TFT-APAC-3",
          "name": "Steppy",
          "players": [
            "Steppy"
          ]
        },
        {
          "id": "TFT-APAC-4",
          "name": "steelo of bora",
          "players": [
            "steelo of bora"
          ]
        },
        {
          "id": "TFT-APAC-5",
          "name": "VP Maris",
          "players": [
            "VP Maris"
          ]
        },
        {
          "id": "TFT-APAC-6",
          "name": "ZETA Title",
          "players": [
            "ZETA Title"
          ]
        },
        {
          "id": "TFT-APAC-7",
          "name": "VP Milo",
          "players": [
            "VP Milo"
          ]
        },
        {
          "id": "TFT-APAC-8",
          "name": "FW Iron Bog",
          "players": [
            "FW Iron Bog"
          ]
        },
        {
          "id": "TFT-APAC-9",
          "name": "A Long",
          "players": [
            "A Long"
          ]
        }
      ],
      "snapshot": "40 tuyển thủ Space Gods Tactician’s Crown · 10–12/07/2026",
      "individual": true
    },
    {
      "id": "TFT-CN",
      "game": "tft",
      "name": "CN",
      "host": "CN",
      "teams": [
        {
          "id": "TFT-CN-0",
          "name": "WBG XZZ",
          "players": [
            "WBG XZZ"
          ]
        },
        {
          "id": "TFT-CN-1",
          "name": "AG LiTuChuan",
          "players": [
            "AG LiTuChuan"
          ]
        },
        {
          "id": "TFT-CN-2",
          "name": "TEC Ringo",
          "players": [
            "TEC Ringo"
          ]
        },
        {
          "id": "TFT-CN-3",
          "name": "AUR Huanmie",
          "players": [
            "AUR Huanmie"
          ]
        },
        {
          "id": "TFT-CN-4",
          "name": "QituX",
          "players": [
            "QituX"
          ]
        },
        {
          "id": "TFT-CN-5",
          "name": "Jiejie",
          "players": [
            "Jiejie"
          ]
        },
        {
          "id": "TFT-CN-6",
          "name": "LiShao",
          "players": [
            "LiShao"
          ]
        },
        {
          "id": "TFT-CN-7",
          "name": "TLG diaomei",
          "players": [
            "TLG diaomei"
          ]
        },
        {
          "id": "TFT-CN-8",
          "name": "WBG Tianlong",
          "players": [
            "WBG Tianlong"
          ]
        },
        {
          "id": "TFT-CN-9",
          "name": "suirenka",
          "players": [
            "suirenka"
          ]
        },
        {
          "id": "TFT-CN-10",
          "name": "XiaoGe",
          "players": [
            "XiaoGe"
          ]
        },
        {
          "id": "TFT-CN-11",
          "name": "huanyi",
          "players": [
            "huanyi"
          ]
        }
      ],
      "snapshot": "40 tuyển thủ Space Gods Tactician’s Crown · 10–12/07/2026",
      "individual": true
    },
    {
      "id": "VCT-Americas",
      "game": "val",
      "name": "VCT Americas",
      "host": "US",
      "teams": [
        {
          "id": "VCT-188",
          "name": "Cloud9",
          "players": [
            "Jackk",
            "Zellsis",
            "FireBallOps",
            "v1c",
            "OXY"
          ],
          "snapshot": "Đội hình ra sân tại cloud9 vs bestia vct 2026 americas stage 2 lr1"
        },
        {
          "id": "VCT-427",
          "name": "ENVY",
          "players": [
            "keznit",
            "GLYPH",
            "Rossy",
            "nightz",
            "Demon1"
          ],
          "snapshot": "Đội hình ra sân tại envy vs g2 esports vct 2026 americas stage 2 lr3"
        },
        {
          "id": "VCT-11058",
          "name": "G2 Esports",
          "players": [
            "jawgemo",
            "leaf",
            "trent",
            "BABYBAY",
            "valyn"
          ],
          "snapshot": "Đội hình ra sân tại 100 thieves vs g2 esports valorant champions 2026 lr3"
        },
        {
          "id": "VCT-2359",
          "name": "LEVIATÁN",
          "players": [
            "Sato",
            "kiNgg",
            "Neon",
            "blowz",
            "spike"
          ],
          "snapshot": "Đội hình ra sân tại leviat n vs g2 esports vct 2026 americas stage 2 lr2"
        },
        {
          "id": "VCT-6961",
          "name": "LOUD",
          "players": [
            "Darker",
            "DaviH",
            "lukxo",
            "erde",
            "tkzin"
          ],
          "snapshot": "Đội hình ra sân tại loud vs team vitality valorant champions 2026 gf"
        },
        {
          "id": "VCT-7386",
          "name": "MIBR",
          "players": [
            "Mazino",
            "aspas",
            "zekken",
            "Verno",
            "tex"
          ],
          "snapshot": "Đội hình ra sân tại loud vs mibr vct 2026 americas stage 2 lr2"
        },
        {
          "id": "VCT-120",
          "name": "100 Thieves",
          "players": [
            "Timotino",
            "vora",
            "Cryocells",
            "Asuna",
            "bang"
          ],
          "snapshot": "Đội hình ra sân tại team vitality vs 100 thieves valorant champions 2026 lbf"
        },
        {
          "id": "VCT-5248",
          "name": "Evil Geniuses",
          "players": [
            "Paincakes",
            "bao",
            "zerona",
            "supamen",
            "dgzin"
          ],
          "snapshot": "Đội hình ra sân tại mibr vs evil geniuses vct 2026 americas stage 2 lr1"
        },
        {
          "id": "VCT-2406",
          "name": "FURIA",
          "players": [
            "Shyy",
            "artzin",
            "koalanoob",
            "basic",
            "C0M"
          ],
          "snapshot": "Đội hình ra sân tại furia vs g2 esports vct 2026 americas stage 2 lr1"
        },
        {
          "id": "VCT-2355",
          "name": "KRÜ Esports",
          "players": [
            "Less",
            "heat",
            "saadhak",
            "Dantedeu5",
            "mwzera"
          ],
          "snapshot": "Đội hình ra sân tại evil geniuses vs kr esports vct 2026 americas stage 2 lr3"
        },
        {
          "id": "VCT-1034",
          "name": "NRG",
          "players": [
            "keiko",
            "mada",
            "brawk",
            "skuba",
            "Ethan"
          ],
          "snapshot": "Đội hình ra sân tại nrg vs 100 thieves valorant champions 2026 lr2"
        },
        {
          "id": "VCT-2",
          "name": "Sentinels",
          "players": [
            "johnqt",
            "Reduxx",
            "cortezia",
            "JonahP",
            "Jerrwin"
          ],
          "snapshot": "Đội hình ra sân tại sentinels vs kr esports vct 2026 americas stage 2 lr2"
        }
      ],
      "snapshot": "Đội VCT 2026; đội hình VLR đọc 18/10/2026"
    },
    {
      "id": "VCT-EMEA",
      "game": "val",
      "name": "VCT EMEA",
      "host": "DE",
      "teams": [
        {
          "id": "VCT-12694",
          "name": "Gentle Mates",
          "players": [
            "marteen",
            "H1ber",
            "Proxh",
            "starxo",
            "Minny"
          ],
          "snapshot": "Đội hình ra sân tại gentle mates vs eintracht frankfurt vct 2026 emea stage 2 lr1"
        },
        {
          "id": "VCT-474",
          "name": "Team Liquid",
          "players": [
            "Kicks",
            "kamo",
            "trexx",
            "GSR",
            "nAts"
          ],
          "snapshot": "Đội hình ra sân tại g2 esports vs team liquid valorant champions 2026 decider c"
        },
        {
          "id": "VCT-1001",
          "name": "Team Heretics",
          "players": [
            "RieNs",
            "Wo0t",
            "benjyfishy",
            "Boo",
            "koshmaras"
          ],
          "snapshot": "Đội hình ra sân tại eintracht frankfurt vs team heretics vct 2026 emea stage 2 lr2"
        },
        {
          "id": "VCT-4915",
          "name": "Natus Vincere",
          "players": [
            "chloric",
            "hiro",
            "ExiT",
            "Ruxic",
            "Kolosha"
          ],
          "snapshot": "Đội hình ra sân tại team heretics vs natus vincere vct 2026 emea stage 2 lr1"
        },
        {
          "id": "VCT-8877",
          "name": "Karmine Corp",
          "players": [
            "SUYGETSU",
            "N4RRATE",
            "dos9",
            "LewN",
            "Avez"
          ],
          "snapshot": "Đội hình ra sân tại karmine corp vs nongshim redforce valorant champions 2026 decider d"
        },
        {
          "id": "VCT-1184",
          "name": "FUT Esports",
          "players": [
            "yetujey",
            "xeus",
            "KROSTALY",
            "s0pp",
            "sociablEE"
          ],
          "snapshot": "Đội hình ra sân tại fut esports vs fire flux esports monsters reloaded 2026 main event sf"
        },
        {
          "id": "VCT-397",
          "name": "BBL Esports",
          "players": [
            "Lar0k",
            "Loita",
            "westside",
            "Flickless",
            "ara"
          ],
          "snapshot": "Đội hình ra sân tại giantx vs bbl esports monsters reloaded 2026 main event sf"
        },
        {
          "id": "VCT-2593",
          "name": "FNATIC",
          "players": [
            "Boaster",
            "Alfajer",
            "Cloud",
            "crashies",
            "kaajak"
          ],
          "snapshot": "Đội hình ra sân tại joblife vs fnatic vct 2026 emea stage 2 lr2"
        },
        {
          "id": "VCT-2059",
          "name": "Team Vitality",
          "players": [
            "Chronicle",
            "Derke",
            "PROFEK",
            "Jamppi",
            "Sayonara"
          ],
          "snapshot": "Đội hình ra sân tại loud vs team vitality valorant champions 2026 gf"
        },
        {
          "id": "VCT-14419",
          "name": "GIANTX",
          "players": [
            "westside",
            "Flickless",
            "ara",
            "globeX",
            "CyvOph"
          ],
          "snapshot": "Đội hình ra sân tại giantx vs bbl esports monsters reloaded 2026 main event sf"
        },
        {
          "id": "VCT-6392",
          "name": "Eternal Fire",
          "players": [
            "Favian",
            "echo",
            "Spear",
            "audaz",
            "nekky"
          ],
          "snapshot": "Đội hình ra sân tại eternal fire vs pcific esports monsters reloaded 2026 closed qualifier play ins"
        },
        {
          "id": "VCT-3478",
          "name": "PCIFIC Esports",
          "players": [
            "Crewen",
            "Burzzy",
            "Izzy",
            "JN3v1cEEE",
            "BadreX"
          ],
          "snapshot": "Đội hình ra sân tại misa esports vs pcific esports monsters reloaded 2026 closed qualifier playoffs lr1"
        }
      ],
      "snapshot": "Đội VCT 2026; đội hình VLR đọc 18/10/2026"
    },
    {
      "id": "VCT-Pacific",
      "game": "val",
      "name": "VCT Pacific",
      "host": "KR",
      "teams": [
        {
          "id": "VCT-11060",
          "name": "Nongshim RedForce",
          "players": [
            "Ivy",
            "Francis",
            "Xross",
            "Dambi",
            "Rb"
          ],
          "snapshot": "Đội hình ra sân tại 100 thieves vs nongshim redforce valorant champions 2026 lr1"
        },
        {
          "id": "VCT-624",
          "name": "Paper Rex",
          "players": [
            "something",
            "d4v41",
            "Jinggg",
            "invy",
            "f0rsakeN"
          ],
          "snapshot": "Đội hình ra sân tại t1 vs paper rex valorant champions 2026 lr1"
        },
        {
          "id": "VCT-8185",
          "name": "KIWOOM DRX",
          "players": [
            "BeYN",
            "MaKo",
            "HYUNMIN",
            "free1ng",
            "yong"
          ],
          "snapshot": "Đội hình ra sân tại kiwoom drx vs t1 vct 2026 pacific stage 2 lr1"
        },
        {
          "id": "VCT-918",
          "name": "Global Esports",
          "players": [
            "PatMen",
            "Autumn",
            "xavi8k",
            "Kr1stal",
            "UdoTan"
          ],
          "snapshot": "Đội hình ra sân tại loud vs global esports valorant champions 2026 decider b"
        },
        {
          "id": "VCT-17",
          "name": "Gen.G",
          "players": [
            "t3xture",
            "Raxcal",
            "Ash",
            "Karon",
            "Efina"
          ],
          "snapshot": "Đội hình ra sân tại gen g vs t1 vct 2026 pacific stage 2 lr2"
        },
        {
          "id": "VCT-6199",
          "name": "Team Secret",
          "players": [
            "Sylvan",
            "natz",
            "STYRON",
            "Zeus",
            "kellyS"
          ],
          "snapshot": "Đội hình ra sân tại team secret vs onside gaming vct 2026 pacific stage 2 lr1"
        },
        {
          "id": "VCT-14",
          "name": "T1",
          "players": [
            "Meteor",
            "stax",
            "iZu",
            "Munchkin",
            "BuZz"
          ],
          "snapshot": "Đội hình ra sân tại g2 esports vs t1 valorant champions 2026 lr2"
        },
        {
          "id": "VCT-878",
          "name": "Rex Regum Qeon",
          "players": [
            "Monyet",
            "xffero",
            "crazyguy",
            "Xan",
            "Jemkin"
          ],
          "snapshot": "Đội hình ra sân tại full sense vs rex regum qeon vct 2026 pacific stage 2 lr1"
        },
        {
          "id": "VCT-278",
          "name": "DetonatioN FocusMe",
          "players": [
            "Meiy",
            "Akame",
            "Caedye",
            "yatsuka",
            "SSeeS"
          ],
          "snapshot": "Đội hình ra sân tại t1 vs detonation focusme vct 2026 pacific stage 2 lr3"
        },
        {
          "id": "VCT-4050",
          "name": "FULL SENSE",
          "players": [
            "JitBoyS",
            "Killua",
            "primmie",
            "Crws",
            "seph1roth"
          ],
          "snapshot": "Đội hình ra sân tại onside gaming vs full sense vct 2026 pacific stage 2 lr2"
        },
        {
          "id": "VCT-5448",
          "name": "ZETA DIVISION",
          "players": [
            "eKo",
            "Absol",
            "SugarZ3ro",
            "Xdll",
            "SyouTa"
          ],
          "snapshot": "Đội hình ra sân tại detonation focusme vs zeta division vct 2026 pacific stage 2 lr2"
        },
        {
          "id": "VCT-11229",
          "name": "VARREL",
          "players": [
            "Klaus",
            "XuNa",
            "Zexy",
            "oonzmlp",
            "Foxy9"
          ],
          "snapshot": "Đội hình ra sân tại varrel vs t1 vct 2026 pacific stage 2 lr3"
        }
      ],
      "snapshot": "Đội VCT 2026; đội hình VLR đọc 18/10/2026"
    },
    {
      "id": "VCT-CN",
      "game": "val",
      "name": "VCT CN",
      "host": "CN",
      "teams": [
        {
          "id": "VCT-1119",
          "name": "All Gamers",
          "players": [
            "Sakura",
            "Tensions3Y",
            "sanye",
            "Never",
            "Xp1Aner"
          ],
          "snapshot": "Đội hình ra sân tại all gamers vs jd gaming china evolution series 2026 act 3 ro16"
        },
        {
          "id": "VCT-12010",
          "name": "Bilibili Gaming",
          "players": [
            "lac",
            "yilai",
            "XiaoFeng",
            "egggg",
            "bud"
          ],
          "snapshot": "Đội hình ra sân tại bilibili gaming vs keepbest gaming china evolution series 2026 act 3 qf"
        },
        {
          "id": "VCT-731",
          "name": "TYLOO",
          "players": [
            "slowly",
            "Erv",
            "SiuFatBB",
            "splash",
            "Scales"
          ],
          "snapshot": "Đội hình ra sân tại tyloo vs team liquid valorant champions 2026 elim c"
        },
        {
          "id": "VCT-13576",
          "name": "JD Gaming",
          "players": [
            "crownfisher",
            "jkuro",
            "Yuicaw",
            "zhe",
            "BerLIN"
          ],
          "snapshot": "Đội hình ra sân tại t1 vs jd gaming valorant champions 2026 elim a"
        },
        {
          "id": "VCT-14137",
          "name": "Titan Esports Club",
          "players": [
            "lucas",
            "Coco",
            "ra1ny",
            "Haodong",
            "Dynamite"
          ],
          "snapshot": "Đội hình ra sân tại titan esports club vs unsettled resentment china evolution series 2026 act 3 qf"
        },
        {
          "id": "VCT-11328",
          "name": "FunPlus Phoenix",
          "players": [
            "Zhubibi",
            "coconut",
            "Setrod",
            "AAAAY",
            "Xlele"
          ],
          "snapshot": "Đội hình ra sân tại keepbest gaming vs funplus phoenix china evolution series 2026 act 3 gf"
        },
        {
          "id": "VCT-13581",
          "name": "Xi Lai Gaming",
          "players": [
            "Lysoar",
            "happywei",
            "WsLeo",
            "Rarga",
            "NoMan"
          ],
          "snapshot": "Đội hình ra sân tại xi lai gaming vs nongshim redforce valorant champions 2026 elim d"
        },
        {
          "id": "VCT-1120",
          "name": "EDward Gaming",
          "players": [
            "ZmjjKK",
            "CHICHOO",
            "nobody",
            "stew",
            "Smoggy"
          ],
          "snapshot": "Đội hình ra sân tại global esports vs edward gaming valorant champions 2026 elim b"
        },
        {
          "id": "VCT-11981",
          "name": "Dragon Ranger Gaming",
          "players": [
            "Life",
            "Nicc",
            "T1an",
            "SpiritZ1",
            "Verse"
          ],
          "snapshot": "Đội hình ra sân tại dragon ranger gaming vs any questions gaming china evolution series 2026 act 3 ro16"
        },
        {
          "id": "VCT-12685",
          "name": "Trace Esports",
          "players": [
            "FengF",
            "FKEY",
            "LuoK1ng",
            "Kai",
            "Toosy"
          ],
          "snapshot": "Đội hình ra sân tại trace esports vs unsettled resentment china evolution series 2026 act 3 ro16"
        },
        {
          "id": "VCT-13790",
          "name": "Wolves Esports",
          "players": [
            "glacier",
            "Spring",
            "yosemite",
            "Deryeon",
            "aluba"
          ],
          "snapshot": "Đội hình ra sân tại wolves esports vs keepbest gaming china evolution series 2026 act 3 ro16"
        },
        {
          "id": "VCT-12064",
          "name": "Nova Esports",
          "players": [
            "Doomer",
            "nono",
            "leo7",
            "GREEN",
            "OnGod"
          ],
          "snapshot": "Đội hình ra sân tại nova esports vs funplus phoenix china evolution series 2026 act 3 qf"
        }
      ],
      "snapshot": "Đội VCT 2026; đội hình VLR đọc 18/10/2026"
    },
    {
      "id": "VCT-Americas-Challengers",
      "game": "val",
      "name": "VCT Americas · Challengers Stage 2",
      "host": "US",
      "teams": [
        {
          "id": "VCT-11001",
          "name": "M80",
          "players": [
            "alvinboy",
            "Kyu",
            "NiSMO",
            "Boni",
            "Spaz"
          ],
          "snapshot": "Đội hình ra sân tại g2 esports vs m80 vct 2026 americas stage 2 lr1"
        },
        {
          "id": "VCT-15072",
          "name": "2Game Esports",
          "players": [
            "xenom",
            "Brinks",
            "frz",
            "gobera",
            "qck"
          ],
          "snapshot": "Đội hình ra sân tại sentinels vs 2game esports vct 2026 americas stage 2 lr1"
        },
        {
          "id": "VCT-23141",
          "name": "Fluxo W7M",
          "players": [
            "jzz",
            "Palla",
            "tuyz",
            "Zanatsu",
            "mazin"
          ],
          "snapshot": "Đội hình ra sân tại kr esports vs fluxo w7m vct 2026 americas stage 2 lr1"
        },
        {
          "id": "VCT-extra-Americas",
          "name": "BESTIA",
          "players": [
            "chubi",
            "david",
            "Melser",
            "Tacolilla",
            "Loss"
          ]
        }
      ],
      "snapshot": "Các đội vượt Challengers vào Stage 2 · 2026",
      "challengers": true
    },
    {
      "id": "VCT-EMEA-Challengers",
      "game": "val",
      "name": "VCT EMEA · Challengers Stage 2",
      "host": "DE",
      "teams": [
        {
          "id": "VCT-876",
          "name": "Enterprise Esports",
          "players": [
            "kozzy",
            "MAGNUM",
            "iluri",
            "paTiTek",
            "Lime"
          ],
          "snapshot": "Đội hình ra sân tại enterprise esports vs team liquid vct 2026 emea stage 2 lr2"
        },
        {
          "id": "VCT-20085",
          "name": "Fire Flux Esports",
          "players": [
            "hezacoil",
            "Kachoww",
            "yetujey",
            "xeus",
            "KROSTALY"
          ],
          "snapshot": "Đội hình ra sân tại fut esports vs fire flux esports monsters reloaded 2026 main event sf"
        },
        {
          "id": "VCT-11232",
          "name": "Joblife",
          "players": [
            "runneR",
            "doma",
            "UNFAKE",
            "kamyk",
            "Pa1ze"
          ],
          "snapshot": "Đội hình ra sân tại fire flux esports vs joblife vct 2026 emea stage 2 lr3"
        },
        {
          "id": "VCT-14478",
          "name": "Eintracht Frankfurt",
          "players": [
            "Fizzy",
            "azury",
            "Jamelinho213",
            "Zyppan",
            "musashi"
          ],
          "snapshot": "Đội hình ra sân tại eintracht frankfurt vs samcro monsters reloaded 2026 emea qualifier open 2 qf"
        }
      ],
      "snapshot": "Các đội vượt Challengers vào Stage 2 · 2026",
      "challengers": true
    },
    {
      "id": "VCT-Pacific-Challengers",
      "game": "val",
      "name": "VCT Pacific · Challengers Stage 2",
      "host": "KR",
      "teams": [
        {
          "id": "VCT-623",
          "name": "Sharper Esports",
          "players": [
            "NIZ",
            "Apinya",
            "Laz",
            "PTC",
            "Kadoom"
          ],
          "snapshot": "Đội hình ra sân tại sharper esports vs onside gaming vct 2026 pacific stage 2 lr3"
        },
        {
          "id": "VCT-18299",
          "name": "QT DIG∞",
          "players": [
            "margaret",
            "yuran",
            "Pkm",
            "Kippei",
            "Misaya"
          ],
          "snapshot": "Đội hình ra sân tại detonation focusme vs qt dig vct 2026 pacific stage 2 lr1"
        },
        {
          "id": "VCT-17167",
          "name": "Xipto Esports",
          "players": [
            "aLerT",
            "canady",
            "endoist",
            "doffy",
            "Surf"
          ],
          "snapshot": "Đội hình ra sân tại zeta division vs xipto esports vct 2026 pacific stage 2 lr1"
        },
        {
          "id": "VCT-extra-Pacific",
          "name": "ONSIDE GAMING",
          "players": [
            "Wolverine",
            "Ray",
            "Cloudy",
            "Hermes",
            "Xiesta"
          ]
        }
      ],
      "snapshot": "Các đội vượt Challengers vào Stage 2 · 2026",
      "challengers": true
    },
    {
      "id": "VCT-CN-Challengers",
      "game": "val",
      "name": "VCT CN · Challengers Stage 2",
      "host": "CN",
      "teams": [
        {
          "id": "VCT-12784",
          "name": "KeepBest Gaming",
          "players": [
            "sibeastw0w",
            "Akeman",
            "Tonk",
            "Krst1Ng",
            "Ying"
          ],
          "snapshot": "Đội hình ra sân tại keepbest gaming vs funplus phoenix china evolution series 2026 act 3 gf"
        },
        {
          "id": "VCT-extra-CN",
          "name": "A Team",
          "players": [
            "Monk",
            "Eren",
            "Folykiki",
            "dingwei",
            "Layla"
          ]
        }
      ],
      "snapshot": "Các đội vượt Challengers vào Stage 2 · 2026",
      "challengers": true
    }
  ]
}; })(globalThis.G);

;
