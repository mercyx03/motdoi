/* ===== js/life85.js ===== */
/* Một Đời — v6.7.0: con người, văn hóa, lịch sử Việt Nam sát thực tế hơn
   · dùng số liệu tổng hợp từ Nemotron-Personas-Vietnam (NVIDIA & FPT, CC BY 4.0; xem data-personas-vn.js):
     người quen quanh bạn có nghề nghiệp, sở thích đúng với vùng miền, thành thị / nông thôn, lứa tuổi;
     thú vui phổ biến theo vùng và tuổi; món ăn quê nhà theo vùng
   · di sản văn hóa phi vật thể được UNESCO ghi danh gắn với đúng địa phương, lễ tết của các dân tộc
   · bài học lịch sử (chỉ những mốc đã được ghi nhận chính thức), chuyện ông bà kể, Ngày Thương binh – Liệt sĩ 27/7,
     Giỗ Tổ Hùng Vương, kỳ nghỉ 30/4 – 1/5 và quyền lợi khi làm ngày lễ (Bộ luật Lao động 2019),
     bầu cử đại biểu Quốc hội và HĐND (Luật Bầu cử 2015: cử tri phải tự mình đi bầu)
   Nguồn: docs/culture-sources.md */
(function (G) {
  'use strict';
  var U = G.U, E = G.E, H = E.H, SC = E.SC, VN = G.VN;
  function pick(r, a) { return U.pick(r, a); }
  function ch(r, p) { return r() < p; }
  function free(l) { return !(l.jailUntil != null && l.age < l.jailUntil) && !(l.abroad && l.abroad.trapped) && !(l.flags.military && l.age < l.flags.military); }
  function vn(l) { return H.isVN(l) && l.mode === 'vn' && !(l.abroad && (l.abroad.perm || l.abroad.trapped)); }
  function year(l) { return l.birthYear + l.age; }
  function T(id, when, p, cd, max, rep) { E.TRIG.push({ id: id, when: function (l, a) { return free(l) && when(l, a); }, p: p, cd: cd || 4, max: max || 1, rep: !!rep }); }
  function KT(id, a0, a1, when, cw) { E.TRIG.push({ id: id, when: function (l, a) { return a >= a0 && a <= a1 && free(l) && (!when || when(l, a)); }, p: 0.08, cd: 99, child: true, cw: cw || 1, max: 1 }); }
  function mom(l) { return l.fam.mAlive ? 'mẹ' : l.fam.fAlive && !l.fam.noDad ? 'bố' : 'bà'; }

  // ===================================================================
  // 1. SỐ LIỆU PERSONA THEO VÙNG
  // ===================================================================
  var P = G.PERSONAS_VN && G.PERSONAS_VN.regions || {};
  var REG = { DBSH: 'DBSH', MNPB: 'MNPB', BTB: 'BTB', NTB: 'BTB', TN: 'TN', DNB: 'DNB', DBSCL: 'DBSCL' };
  var REG_NAME = { DBSH: 'đồng bằng Bắc Bộ', MNPB: 'miền núi phía Bắc', BTB: 'miền Trung', TN: 'Tây Nguyên', DNB: 'miền Đông Nam Bộ', DBSCL: 'miền Tây Nam Bộ' };
  var COMMON = ['phở', 'bánh mì', 'trà', 'cà phê', 'hải sản', 'ốc', 'xôi', 'chè', 'cơm gà', 'vịt', 'bún bò', 'gà nướng', 'cá kho', 'thịt kho'];
  function regionCode(name) { var p = VN && VN.byName && VN.byName[name]; return p ? REG[p.region] || null : null; }
  function homeRegion(l) { return (l.prov && REG[l.prov.region]) || regionCode(l.prov && l.prov.old) || null; }
  function liveRegion(l) { return (l.movedTo && regionCode(l.movedTo)) || homeRegion(l); }
  function group(l, reg) { var g = reg || liveRegion(l); if (!g) return null; return P[g + '_' + (l.urban ? 'u' : 'r')] || P[g + '_r'] || P[g + '_u'] || null; }
  function wpick(r, list, skip) { var a = (list || []).filter(function (x) { return !skip || skip.indexOf(x[0]) < 0; }); if (!a.length) return null; var t = a.reduce(function (s, x) { return s + x[1]; }, 0), z = r() * t; for (var i = 0; i < a.length; i++) { z -= a[i][1]; if (z <= 0) return a[i][0]; } return a[a.length - 1][0]; }
  function band(a) { return a < 30 ? 'y' : a < 45 ? 'm' : a < 60 ? 'o' : 's'; }
  function hobbies(g, age) { if (!g) return []; var b = g.hobAge && g.hobAge[band(age)], L = b && b.length >= 6 ? b : g.hob; return age > 65 ? L.filter(function (x) { return !/gym|bóng đá|đá bóng|đá banh|bóng rổ|leo núi|boxing|võ thuật|nhảy hiện đại|chạy marathon/i.test(Array.isArray(x) ? x[0] : x); }) : L; } // v7.3.1: người già không được gợi ý tập gym, đá bóng
  function low(s) { return s ? s.charAt(0).toLowerCase() + s.slice(1) : ''; }
  // nghề trong dữ liệu là danh từ chỉ người ("Tiểu thương chợ", "Bác sĩ") hoặc hoạt động ("Trồng cà phê", "Kinh doanh online")
  function jobPhrase(j) { j = low(j); if (/^nghỉ hưu/.test(j)) return 'đã ' + j; return /^(trồng|kinh doanh|đang|nội trợ|làm|buôn|bán|chăn|nuôi|đánh|học)/.test(j) ? j : 'làm ' + j; }
  E.PERSONA = { region: liveRegion, group: group, regionName: function (k) { return REG_NAME[k] || ''; } };
  function call(l, age, sex) { var d = age - l.age; return d >= 18 ? (sex === 'F' ? 'cô' : 'chú') : d >= 3 ? (sex === 'F' ? 'chị' : 'anh') : d >= -3 ? 'bạn' : 'em'; }

  SC('pv_nguoi_quen', {
    title: 'Người quanh ta',
    prep: function (l, r) {
      var g = group(l); if (!g) return { none: true };
      var sx = r() < 0.5 ? 'M' : 'F', age = U.clamp(l.age + U.randint(r, -12, 22), 18, 85), RET = g.job.filter(function (x) { return /^(Nghỉ hưu|Hưu trí)/.test(x[0]); }).map(function (x) { return x[0]; }), job;
      if (age >= 60 && r() < 0.65 && RET.length) job = pick(r, RET); else job = wpick(r, g.job, RET.concat(age < 23 ? [] : ['Học sinh THPT'])) || 'Làm tự do';
      var hs = hobbies(g, age), h1 = wpick(r, hs) || 'Đọc sách', h2 = wpick(r, hs, [h1]) || 'Nấu ăn';
      return { n: H.stranger(l, r, sx), sex: sx, age: age, job: job, h1: h1, h2: h2, w: l.urban ? pick(r, ['khu phố', 'tổ dân phố', 'chung cư']) : pick(r, ['xóm', 'làng', 'thôn']) };
    },
    valid: function (l, d) { return !d || !d.none; },
    text: function (l, d) { if (!d || d.none) return ''; var c = call(l, d.age, d.sex); return 'Ở ' + d.w + ', bạn quen ' + c + ' ' + d.n + ', ' + d.age + ' tuổi, ' + jobPhrase(d.job) + '. Lúc rảnh, ' + c + ' ấy thích ' + low(d.h1) + ' và ' + low(d.h2) + '.'; },
    opts: [
      { k: 'cung', l: function (l, d) { return 'Rủ nhau cùng ' + low(d.h1); }, ai: { soc: 1, w: 1.2 }, run: function (l, r, log, d) { var c = call(l, d.age, d.sex); log(pick(r, ['Cuối tuần ấy bạn cùng ' + c + ' ' + d.n + ' ' + low(d.h1) + '. Từ đó gặp nhau là nói chuyện không dứt.', 'Lần đầu thử ' + low(d.h1) + ', bạn vụng về nhưng ' + c + ' ' + d.n + ' kiên nhẫn chỉ cho từng chút.', 'Hai người hẹn nhau ' + low(d.h1) + ' mấy lần. Có thêm một người quen tốt bụng ngay gần nhà.']), 'good'); H.fx(l, { hap: 3, soc: 2 }); } },
      { k: 'nghe', l: function (l, d) { return 'Hỏi chuyện nghề của ' + call(l, d.age, d.sex) + ' ấy'; }, ai: { smart: 1 }, run: function (l, r, log, d) { var c = call(l, d.age, d.sex); log(pick(r, ['Nghe ' + c + ' ' + d.n + ' kể chuyện ' + jobPhrase(d.job) + ', bạn mới biết nghề nào cũng có cái khó riêng.', c.charAt(0).toUpperCase() + c.slice(1) + ' ' + d.n + ' kể say sưa về công việc ' + jobPhrase(d.job) + '. Bạn học được vài điều hay.']), 'neutral'); H.fx(l, { kno: 1, soc: 1 }); } },
      { k: 'chao', l: 'Chỉ chào hỏi xã giao', run: function (l, r, log, d) { log('Mỗi lần gặp nhau ở ' + d.w + ', hai bên gật đầu chào, hỏi thăm vài câu.', 'neutral'); } }
    ] });
  T('pv_nguoi_quen', function (l, a) { return vn(l) && a >= 16 && !!group(l); }, 0.07, 7, 3, true);

  SC('pv_thu_vui', {
    title: 'Một thú vui mới',
    prep: function (l, r) { var g = group(l); if (!g) return { none: true }; var have = (l.flags.hobbies || []).slice(), hs = hobbies(g, l.age), a = []; for (var i = 0; i < 3; i++) { var h = wpick(r, hs, have.concat(a)); if (h) a.push(h); } return a.length >= 2 ? { list: a, reg: liveRegion(l) } : { none: true }; },
    valid: function (l, d) { return !d || !d.none; },
    text: function (l, d) { if (!d || d.none) return ''; return 'Ở ' + (REG_NAME[d.reg] || 'chỗ bạn ở') + ', người tuổi bạn hay dành thời gian rảnh cho mấy thú vui này. Bạn muốn thử cái nào?'; },
    opts: [0, 1, 2].map(function (i) { return { k: 'h' + i, l: function (l, d) { return d.list && d.list[i] ? 'Thử ' + low(d.list[i]) : ''; }, req: function (l, d) { return !!(d && d.list && d.list[i]); }, ai: { w: 1 }, run: function (l, r, log, d) { var h = d.list[i]; l.flags.hobbies = (l.flags.hobbies || []).concat([h]).slice(-4); log(pick(r, ['Bạn bắt đầu ' + low(h) + '. Mấy tháng sau đã thành thói quen mỗi tuần.', 'Thử ' + low(h) + ' vài lần, bạn thấy đầu óc nhẹ nhõm hẳn.', 'Bạn tìm được hội ' + low(h) + ' ngay gần nhà, quen thêm vài người bạn mới.']), 'good'); H.fx(l, { hap: 3, soc: 1 }); } }; }).concat([{ k: 'thoi', l: 'Thôi, mình không có thời gian', run: function (l, r, log) { log('Bạn bận quá, để dành thú vui cho lúc khác.', 'neutral'); } }]) });
  T('pv_thu_vui', function (l, a) { return vn(l) && a >= 15 && a <= 80 && (l.flags.hobbies || []).length < 4 && !!group(l); }, 0.05, 8, 3, true);
  E.HOOKS.year.unshift(function (l, r, log, a) {
    var hs = l.flags && l.flags.hobbies; if (!hs || !hs.length || !l.alive || a < 15) return; if (a > 65) { hs = hs.filter(function (h) { return !/gym|bóng đá|đá bóng|đá banh|bóng rổ|leo núi|boxing|võ thuật|nhảy hiện đại|chạy marathon/i.test(h); }); if (!hs.length) return; } // v7.1: người già không còn tập gym, đá bóng
    if (r() < 0.12) { var h = hs[Math.floor(r() * hs.length)]; log(pick(r, ['Năm nay vẫn giữ thói quen ' + low(h) + ' mỗi cuối tuần.', 'Những lúc mệt mỏi, ' + low(h) + ' giúp bạn cân bằng lại.']), 'neutral'); H.fx(l, { hap: 1 }); }
  });

  SC('pv_mon_que', {
    title: 'Nhớ món quê',
    prep: function (l, r) { var g = group(l, homeRegion(l)); var d = g && wpick(r, (g.dish || []).filter(function (x) { return COMMON.indexOf(x[0]) < 0; }).slice(0, 12)); return d ? { d: d, reg: homeRegion(l) } : { none: true }; },
    valid: function (l, d) { return !d || !d.none; },
    text: function (l, d) { if (!d || d.none) return ''; return 'Sống xa quê, có hôm bạn thèm đến quặn lòng món ' + d.d + ' — món ' + mom(l) + ' vẫn nấu, món quen thuộc của ' + (REG_NAME[d.reg] || 'quê nhà') + '.'; },
    opts: [
      { k: 'nau', l: 'Tự vào bếp nấu theo trí nhớ', ai: { w: 1.1 }, run: function (l, r, log, d) { l.flags.homeDish = (l.flags.homeDish || 0) + 1; log(ch(r, 0.5) ? 'Nấu theo trí nhớ, vị không giống hẳn nhưng ăn vào thấy như được về nhà.' : 'Nấu hỏng một lần, lần thứ hai thì ra đúng vị ngày xưa. Bạn chụp ảnh gửi về cho gia đình.', 'good'); H.fx(l, { hap: 3 }); } },
      { k: 'goi', l: function (l) { return 'Gọi điện hỏi ' + mom(l) + ' cách nấu'; }, req: function (l) { return l.fam.mAlive || l.fam.fAlive; }, ai: { soc: 1 }, run: function (l, r, log, d) { l.flags.homeDish = (l.flags.homeDish || 0) + 1; log('Cuộc gọi hỏi cách nấu ' + d.d + ' kéo dài cả tiếng, toàn chuyện ở nhà.', 'good'); H.fx(l, { hap: 4 }); H.mem(l, 'Cuộc gọi về nhà hỏi cách nấu ' + d.d + '.', 2); } },
      { k: 'quan', l: 'Đi tìm quán của người cùng quê', run: function (l, r, log, d) { log('Tìm được một quán nhỏ của người cùng quê. Ăn bát ' + d.d + ', nghe giọng nói quen thuộc, bạn ngồi lâu hơn dự định.', 'good'); H.fx(l, { hap: 2, soc: 1 }); } }
    ] });
  T('pv_mon_que', function (l, a) { return a >= 18 && H.isVN(l) && (!!l.movedTo || !!l.abroad) && !!homeRegion(l); }, 0.06, 7, 3, true);

  // ===================================================================
  // 2. DI SẢN VĂN HÓA PHI VẬT THỂ (UNESCO) GẮN VỚI ĐỊA PHƯƠNG
  // ===================================================================
  var HER = [
    { id: 'quan_ho', n: 'Dân ca Quan họ Bắc Ninh', p: ['Bắc Ninh', 'Bắc Giang'], t: 'Hội Lim mùa xuân, liền anh liền chị mặc áo the, khăn xếp, nón quai thao hát đối đáp trên thuyền và trong sân đình.' },
    { id: 'xoan', n: 'Hát Xoan Phú Thọ', p: ['Phú Thọ'], t: 'Đầu xuân, phường Xoan hát mừng ở đình làng, những làn điệu cổ được truyền từ đời này sang đời khác.' },
    { id: 'hung_vuong', n: 'Tín ngưỡng thờ cúng Hùng Vương', p: ['Phú Thọ'], t: 'Mùng 10 tháng 3 âm lịch, dòng người về Đền Hùng dâng hương tưởng nhớ các Vua Hùng.' },
    { id: 'giong', n: 'Hội Gióng ở đền Phù Đổng và đền Sóc', p: ['Hà Nội'], t: 'Hội Gióng tái hiện truyền thuyết Thánh Gióng đánh giặc Ân, cờ lau, trống chiêng rộn ràng.' },
    { id: 'ca_tru', n: 'Nghệ thuật Ca trù', p: ['Hà Nội', 'Hải Dương', 'Hưng Yên', 'Bắc Ninh', 'Nam Định', 'Thái Bình', 'Hà Tĩnh', 'Nghệ An', 'Thanh Hóa', 'Quảng Bình', 'Ninh Bình', 'Hà Nam'], t: 'Một tối nghe ca trù: tiếng phách giòn, đàn đáy trầm, đào nương ngân nga những câu hát cổ.' },
    { id: 'nha_nhac', n: 'Nhã nhạc Cung đình Huế', p: ['Thừa Thiên Huế', 'Huế'], t: 'Buổi diễn Nhã nhạc trong Đại Nội, những âm thanh trang nghiêm của cung đình xưa.' },
    { id: 'cong_chieng', n: 'Không gian văn hóa Cồng chiêng Tây Nguyên', p: ['Kon Tum', 'Gia Lai', 'Đắk Lắk', 'Đắk Nông', 'Lâm Đồng'], t: 'Đêm lễ hội bên ánh lửa, tiếng cồng chiêng vang vọng núi rừng, mọi người nắm tay nhau múa xoang.' },
    { id: 'vi_giam', n: 'Dân ca Ví, Giặm Nghệ Tĩnh', p: ['Nghệ An', 'Hà Tĩnh'], t: 'Những câu ví, giặm mộc mạc vang lên trong buổi sinh hoạt câu lạc bộ dân ca của xã.' },
    { id: 'tai_tu', n: 'Nghệ thuật Đờn ca tài tử Nam Bộ', reg: ['DNB', 'DBSCL'], t: 'Chiều cuối tuần, mấy ông bác trong xóm ôm đàn kìm, đàn tranh, ca vọng cổ bên bộ ván gỗ.' },
    { id: 'bai_choi', n: 'Nghệ thuật Bài chòi Trung Bộ', p: ['Quảng Bình', 'Quảng Trị', 'Thừa Thiên Huế', 'Huế', 'Đà Nẵng', 'Quảng Nam', 'Quảng Ngãi', 'Bình Định', 'Phú Yên', 'Khánh Hòa'], t: 'Hội bài chòi ngày Tết, anh hiệu hô câu thai, ai trúng con bài thì gõ mõ reo vui.' },
    { id: 'tho_mau', n: 'Thực hành Tín ngưỡng thờ Mẫu Tam phủ của người Việt', p: ['Nam Định', 'Hà Nội', 'Thái Bình', 'Hà Nam', 'Ninh Bình', 'Thanh Hóa', 'Bắc Ninh', 'Hải Phòng'], t: 'Lễ hội ở phủ Mẫu, tiếng hát văn hòa cùng những giá hầu đồng sặc sỡ.' },
    { id: 'keo_co', n: 'Nghi lễ và trò chơi kéo co', p: ['Lào Cai', 'Vĩnh Phúc', 'Bắc Ninh', 'Hà Nội'], t: 'Hội làng đầu năm có kéo co ngồi, hai bên dân làng hò reo cổ vũ.' },
    { id: 'gom_cham', n: 'Nghệ thuật làm gốm của người Chăm', p: ['Ninh Thuận'], t: 'Ở làng gốm Bàu Trúc, các nghệ nhân nặn gốm bằng tay, đi vòng quanh bàn xoay, nung gốm ngoài trời.' },
    { id: 'ba_chua_xu', n: 'Lễ hội Vía Bà Chúa Xứ núi Sam', p: ['An Giang'], t: 'Mùa lễ Vía Bà ở Châu Đốc, người Việt, Khmer, Chăm, Hoa cùng về núi Sam.' },
    { id: 'then', n: 'Thực hành Then của người Tày, Nùng, Thái', eth: ['Tày', 'Nùng', 'Thái'], t: 'Tiếng đàn tính và câu hát Then trong buổi lễ của bản, ông bà bảo đó là lời cầu chúc bình an.' },
    { id: 'xoe', n: 'Nghệ thuật Xòe Thái', eth: ['Thái'], p: ['Lai Châu', 'Sơn La', 'Điện Biên', 'Yên Bái'], t: 'Cả bản nắm tay nhau thành vòng xòe quanh đống lửa, ai đi ngang qua cũng được kéo vào.' }
  ];
  E.HERITAGE_VN = HER;
  function heritageFor(l) {
    var p = l.prov && l.prov.old, reg = l.prov && l.prov.region, eth = l.eth;
    return HER.filter(function (h) { return (h.p && h.p.indexOf(p) >= 0) || (h.reg && h.reg.indexOf(reg) >= 0) || (h.eth && h.eth.indexOf(eth) >= 0); });
  }
  E.heritageFor = heritageFor;
  SC('vh_di_san', {
    title: function (l, d) { return d && d.h ? d.h.n : 'Di sản quê hương'; },
    prep: function (l, r) { var a = heritageFor(l).filter(function (h) { return !(l.flags.dsSeen || {})[h.id]; }); return a.length ? { h: pick(r, a) } : { none: true }; },
    valid: function (l, d) { return !d || !d.none; },
    text: function (l, d) { if (!d || d.none) return ''; return d.h.t + ' Đây là di sản văn hóa phi vật thể của quê bạn được UNESCO ghi danh.'; },
    opts: [
      { k: 'tham_gia', l: 'Hòa vào cùng mọi người', ai: { soc: 1, w: 1.3 }, run: function (l, r, log, d) { (l.flags.dsSeen || (l.flags.dsSeen = {}))[d.h.id] = l.age; log(pick(r, ['Bạn hòa vào không khí ấy, thấy tự hào về quê mình.', 'Lần đầu tự mình tham gia, bạn hiểu vì sao ông bà quý những điều này đến thế.']), 'good'); H.fx(l, { hap: 3, soc: 2 }); H.mem(l, d.h.n + ' ở quê nhà.', 3); } },
      { k: 'hoc', l: 'Xin học từ nghệ nhân trong vùng', ai: { smart: 1 }, run: function (l, r, log, d) { (l.flags.dsSeen || (l.flags.dsSeen = {}))[d.h.id] = l.age; l.flags.dsLearn = (l.flags.dsLearn || 0) + 1; log('Bạn theo một nghệ nhân lớn tuổi học mấy tháng. Bà / ông dặn: "Giữ được cái này là giữ được hồn quê."', 'good'); H.fx(l, { kno: 2, hap: 2, karma: 2 }); } },
      { k: 'xem', l: 'Đứng xem một lúc rồi về', run: function (l, r, log, d) { (l.flags.dsSeen || (l.flags.dsSeen = {}))[d.h.id] = l.age; log('Bạn đứng xem một lúc rồi về. Âm thanh ấy còn văng vẳng mãi.', 'neutral'); H.fx(l, { hap: 1 }); } }
    ] });
  T('vh_di_san', function (l, a) { return vn(l) && a >= 7 && heritageFor(l).some(function (h) { return !(l.flags.dsSeen || {})[h.id]; }); }, 0.07, 5, 3, true);

  // lễ tết của các dân tộc (theo dân tộc của bạn)
  var FEST = {
    'Khmer': [['Tết Chôl Chnăm Thmây', 'Giữa tháng 4, cả phum sóc lên chùa làm lễ, đắp núi cát, té nước chúc nhau năm mới an lành.'], ['Lễ Sene Dolta', 'Mùa lễ cúng ông bà, con cháu đi xa cũng về, mang lễ vật lên chùa.'], ['Lễ hội Ok Om Bok', 'Đêm rằm tháng 10 âm lịch, cúng trăng, đút cốm dẹp cho trẻ con, cả xóm đi xem đua ghe ngo.']],
    'Tày': [['Lễ hội Lồng tồng', 'Tháng Giêng, cả bản ra đồng làm lễ xuống đồng, ném còn, kéo co, cầu mùa màng tươi tốt.']],
    'Nùng': [['Lễ hội Lồng tồng', 'Tháng Giêng, cả bản ra đồng làm lễ xuống đồng, ném còn, cầu mưa thuận gió hòa.']],
    'Mông': [['Tết của người Mông', 'Cuối năm, nhà nhà giã bánh dày, mặc váy áo mới, trai gái thổi khèn, ném pao.'], ['Lễ hội Gầu tào', 'Đầu xuân, lễ hội Gầu tào cầu phúc, cầu may, cây nêu dựng giữa bãi đất rộng.']],
    'Thái': [['Lễ hội Xên bản, Xên mường', 'Cả bản làm lễ cầu bình an, sau đó múa xòe quanh đống lửa đến khuya.']],
    'Mường': [['Lễ hội Khai hạ', 'Đầu năm, người Mường mở hội Khai hạ, đánh chiêng, chơi đu, ném còn.']],
    'Ê Đê': [['Lễ mừng lúa mới', 'Mùa lúa chín, cả buôn làm lễ mừng lúa mới, uống rượu cần, nghe cồng chiêng.']],
    'Gia Rai': [['Lễ mừng lúa mới', 'Thu hoạch xong, làng làm lễ mừng lúa mới, cồng chiêng vang suốt đêm.']],
    'Ba Na': [['Lễ mừng lúa mới', 'Thu hoạch xong, làng làm lễ mừng lúa mới ở nhà rông.']],
    'Chăm': [['Lễ hội Katê', 'Mùa lễ Katê, người Chăm về đền tháp, tiếng trống Ginăng, kèn Saranai rộn ràng.']],
    'Hoa': [['Tết Nguyên tiêu', 'Rằm tháng Giêng, phố người Hoa rực đèn lồng, múa lân, viếng hội quán.']]
  };
  E.ETHNIC_FESTIVALS = FEST;
  SC('vh_le_dan_toc', {
    title: function (l, d) { return d && d.f ? d.f[0] : 'Lễ hội của dân tộc mình'; },
    prep: function (l, r) { var a = FEST[l.eth]; return a ? { f: pick(r, a) } : { none: true }; },
    valid: function (l, d) { return !d || !d.none; },
    text: function (l, d) { if (!d || d.none) return ''; return d.f[1]; },
    opts: [
      { k: 've', l: function (l) { return l.movedTo || l.abroad ? 'Thu xếp về quê dự lễ' : 'Cùng gia đình tham gia trọn vẹn'; }, ai: { soc: 1, w: 1.3 }, run: function (l, r, log, d) { l.flags.ethFest = (l.flags.ethFest || 0) + 1; log(pick(r, ['Bạn mặc trang phục truyền thống, cùng gia đình dự lễ. Thấy mình thuộc về nơi này.', 'Gặp lại họ hàng, bạn bè cũ trong ngày lễ, ai cũng hỏi han rối rít.']), 'good'); H.fx(l, { hap: 4, soc: 2 }); H.mem(l, d.f[0] + ' cùng gia đình.', 3); } },
      { k: 'ban', l: 'Bận việc, chỉ gọi điện chúc mừng', run: function (l, r, log) { log('Năm nay bận, bạn chỉ gọi điện về chúc mừng. Nhìn ảnh mọi người gửi lên mà nhớ.', 'neutral'); H.fx(l, { hap: -1 }); } }
    ] });
  T('vh_le_dan_toc', function (l, a) { return H.isVN(l) && !!FEST[l.eth] && a >= 5; }, 0.1, 4, 3, true);

  // ===================================================================
  // 3. LỊCH SỬ & CÔNG DÂN — chỉ những mốc đã được ghi nhận chính thức
  // ===================================================================
  var HIST = [
    ['Năm 938', 'Ngô Quyền đánh tan quân Nam Hán trên sông Bạch Đằng, mở ra thời kỳ độc lập lâu dài.'],
    ['Năm 1077', 'Lý Thường Kiệt chặn đứng quân Tống ở phòng tuyến sông Như Nguyệt; bài thơ "Nam quốc sơn hà" gắn với cuộc kháng chiến này.'],
    ['Năm 1288', 'Hưng Đạo Đại vương Trần Quốc Tuấn đánh tan quân Nguyên Mông trên sông Bạch Đằng.'],
    ['Năm 1428', 'Khởi nghĩa Lam Sơn do Lê Lợi lãnh đạo toàn thắng; Nguyễn Trãi viết "Bình Ngô đại cáo".'],
    ['Năm 1789', 'Vua Quang Trung đại phá quân Thanh, làm nên chiến thắng Ngọc Hồi – Đống Đa.'],
    ['Ngày 2/9/1945', 'Chủ tịch Hồ Chí Minh đọc Tuyên ngôn Độc lập tại Quảng trường Ba Đình, khai sinh nước Việt Nam Dân chủ Cộng hòa.'],
    ['Ngày 7/5/1954', 'Chiến thắng Điện Biên Phủ "lừng lẫy năm châu, chấn động địa cầu".'],
    ['Ngày 30/4/1975', 'Giải phóng hoàn toàn miền Nam, thống nhất đất nước.'],
    ['Năm 1986', 'Đại hội đại biểu toàn quốc lần thứ VI của Đảng khởi xướng công cuộc Đổi mới.'],
    ['Năm 1995 và 2007', 'Việt Nam gia nhập ASEAN (1995) và trở thành thành viên Tổ chức Thương mại Thế giới WTO (2007).'],
    ['Ngày 1/7/2025', 'Cả nước sắp xếp lại còn 34 tỉnh, thành phố và vận hành chính quyền địa phương hai cấp.']
  ];
  E.HISTORY_VN = HIST;
  SC('ls_bai_hoc', {
    title: 'Tiết Lịch sử',
    prep: function (l, r) { var seen = l.flags.lsSeen || [], a = HIST.map(function (x, i) { return i; }).filter(function (i) { return seen.indexOf(i) < 0; }); return { i: a.length ? pick(r, a) : Math.floor(r() * HIST.length) }; },
    text: function (l, d) { if (!d || d.i == null) return ''; var h = HIST[d.i]; return 'Tiết Lịch sử hôm nay: ' + h[0] + ', ' + low(h[1]); },
    opts: [
      { k: 'chu_y', l: 'Chăm chú nghe, ghi chép', ai: { smart: 1, w: 1.2 }, run: function (l, r, log, d) { (l.flags.lsSeen || (l.flags.lsSeen = [])).push(d.i); l.flags.lsGood = (l.flags.lsGood || 0) + 1; log(pick(r, ['Bạn ghi chép cẩn thận, về nhà kể lại cho cả nhà nghe.', 'Bài học khiến bạn tò mò, tối ấy tìm đọc thêm sách về giai đoạn này.']), 'good'); H.fx(l, { kno: 2 }); } },
      { k: 'hoi', l: 'Giơ tay hỏi thêm thầy cô', ai: { soc: 1 }, run: function (l, r, log, d) { (l.flags.lsSeen || (l.flags.lsSeen = [])).push(d.i); l.flags.lsGood = (l.flags.lsGood || 0) + 1; log('Thầy cô khen câu hỏi hay, kể thêm nhiều chi tiết không có trong sách giáo khoa.', 'good'); H.fx(l, { kno: 2, soc: 1 }); } },
      { k: 'ngu_gat', l: 'Lơ đãng nhìn ra cửa sổ', ai: { w: 0.6 }, run: function (l, r, log) { log('Bạn lơ đãng cả tiết. Đến bài kiểm tra mới cuống cuồng học thuộc.', 'neutral'); } }
    ] });
  E.TRIG.push({ id: 'ls_bai_hoc', when: function (l, a) { return a >= 10 && a <= 17 && !!l.school && H.isVN(l) && l.mode === 'vn' && free(l); }, p: 0.1, cd: 3, max: 3, rep: false });

  // ông bà kể chuyện ngày xưa (theo thế hệ của ông bà)
  SC('ls_ong_ba_ke', {
    title: 'Chuyện ngày xưa của ông bà',
    prep: function (l, r) {
      var gy = l.birthYear - 55, a = [];
      if (gy <= 1978) a.push('thời bao cấp, cả nhà xếp hàng từ sáng sớm mua gạo, mua dầu bằng tem phiếu');
      if (gy <= 1985) a.push('những năm đầu Đổi mới, nhà bắt đầu có chiếc xe máy đầu tiên, cả xóm ra xem');
      a.push('ngày xưa cả xóm chỉ có một chiếc tivi, tối nào cũng kéo nhau sang xem nhờ');
      a.push('ngày xưa đi học phải lội bộ mấy cây số, mùa mưa đường trơn như mỡ');
      a.push('ông bà gặp nhau ở buổi lao động công ích của xã, rồi cưới nhau chỉ với mâm cơm và chè thuốc');
      a.push('cái Tết đầu tiên trong căn nhà mới, cả nhà ngồi canh nồi bánh chưng đến sáng');
      return { s: pick(r, a) };
    },
    text: function (l, d) { if (!d || d.none) return ''; return 'Tối mùa đông, ông bà kể chuyện ' + d.s + '.'; },
    opts: [
      { k: 'nghe', l: 'Ngồi nghe, hỏi thêm', ai: { w: 1.3 }, run: function (l, r, log, d) { log('Bạn nghe say sưa, hỏi hết câu này đến câu khác. Ông bà cười: "Giờ các cháu sướng hơn nhiều rồi."', 'good'); H.fx(l, { hap: 2, kno: 1, karma: 1 }); H.mem(l, 'Ông bà kể chuyện ' + d.s + '.', 3); } },
      { k: 'ghi', l: 'Ghi lại vào sổ nhật ký', ai: { smart: 1 }, run: function (l, r, log, d) { log('Bạn ghi lại chuyện ông bà kể vào sổ. Nhiều năm sau đọc lại, thấy quý vô cùng.', 'good'); H.fx(l, { kno: 1, hap: 1 }); H.mem(l, 'Cuốn sổ ghi chuyện ông bà kể.', 3); } },
      { k: 'game', l: 'Mải chơi điện thoại', ai: { w: 0.5 }, run: function (l, r, log) { log('Bạn mải chơi điện thoại. Lớn lên mới tiếc vì không nghe kỹ hơn.', 'neutral'); } }
    ] });
  KT('ls_ong_ba_ke', 6, 14, function (l) { return H.isVN(l) && l.mode === 'vn'; }, 1.1);

  // Ngày Thương binh – Liệt sĩ 27/7
  SC('ls_27_7', { title: 'Ngày Thương binh – Liệt sĩ 27/7', text: 'Ngày 27/7, địa phương tổ chức thắp nến tri ân ở nghĩa trang liệt sĩ, thăm hỏi các gia đình thương binh, liệt sĩ.', opts: [
    { k: 'thap', l: 'Đến nghĩa trang thắp nén nhang', ai: { moral: 1, w: 1.3 }, run: function (l, r, log) { log(pick(r, ['Hàng nghìn ngọn nến sáng lên giữa những hàng bia mộ. Bạn đứng lặng rất lâu trước những ngôi mộ ghi "Liệt sĩ chưa xác định được thông tin".', 'Bạn thắp nhang, dọn cỏ quanh những ngôi mộ ít người lui tới. Một cụ bà cảm ơn, bảo con bà nằm ở hàng thứ ba.']), 'good'); H.fx(l, { karma: 3, hap: 1 }); l.flags.triAn = (l.flags.triAn || 0) + 1; H.mem(l, 'Đêm thắp nến tri ân ở nghĩa trang liệt sĩ.', 3); } },
    { k: 'tham', l: 'Cùng Đoàn thanh niên thăm gia đình chính sách', ai: { soc: 1 }, run: function (l, r, log) { l.flags.triAn = (l.flags.triAn || 0) + 1; log('Bạn theo đoàn đến thăm một bác thương binh. Bác kể chuyện ngày xưa, giọng vẫn sang sảng.', 'good'); H.fx(l, { karma: 3, soc: 1 }); } },
    { k: 'ban', l: 'Bận, chỉ dành một phút tưởng niệm', run: function (l, r, log) { log('Bận việc, bạn dành một phút lặng im tưởng niệm.', 'neutral'); } }] });
  T('ls_27_7', function (l, a) { return vn(l) && a >= 12; }, 0.04, 10, 3);

  // Giỗ Tổ Hùng Vương
  SC('gio_to', { title: 'Giỗ Tổ Hùng Vương', text: function (l) { return 'Mùng 10 tháng 3 âm lịch, cả nước nghỉ lễ Giỗ Tổ Hùng Vương.' + (l.prov && l.prov.old === 'Phú Thọ' ? ' Quê bạn có Đền Hùng, những ngày này người các nơi đổ về rất đông.' : ''); }, opts: [
    { k: 'den_hung', l: 'Về Đền Hùng dâng hương', ai: { w: 1 }, run: function (l, r, log) { if (l.prov && l.prov.old !== 'Phú Thọ' && l.indep) H.cash(l, -l.base * 0.01, 'Đi lễ Đền Hùng'); l.flags.denHung = true; log(pick(r, ['Leo hết mấy trăm bậc đá lên đền Thượng, đông nghịt người mà ai cũng vui vẻ nhường nhau.', 'Bạn dâng hương ở Đền Hùng, ăn bánh chưng, bánh giầy, nghe hát Xoan dưới chân núi.']), 'good'); H.fx(l, { hap: 2 }); } },
    { k: 'nha', l: 'Ở nhà thắp hương, nghỉ ngơi cùng gia đình', ai: { w: 1.2 }, run: function (l, r, log) { log('Ngày nghỉ lễ, bạn thắp nén hương, cả nhà quây quần ăn bữa cơm.', 'good'); H.fx(l, { hap: 2 }); } }] });
  T('gio_to', function (l, a) { return vn(l) && a >= 10; }, 0.03, 10, 2);

  // kỳ nghỉ 30/4 – 1/5 (Bộ luật Lao động 2019: Điều 112 ngày nghỉ, Điều 98 làm ngày lễ được trả ít nhất 300%)
  SC('le_30_4', { title: 'Kỳ nghỉ 30/4 – 1/5', text: 'Kỳ nghỉ lễ Ngày Giải phóng miền Nam, thống nhất đất nước và Quốc tế Lao động. Công ty hỏi ai muốn đi làm, làm ngày lễ được trả ít nhất 300% lương, chưa kể tiền lương ngày lễ.', opts: [
    { k: 'du_lich', l: 'Đi du lịch biển', h: function (l) { return 'Khoảng ' + H.money(l, l.base * 0.08); }, ai: { w: 1.1 }, run: function (l, r, log) { H.cash(l, -l.base * 0.08, 'Du lịch dịp 30/4'); log(pick(r, ['Kẹt xe cả tiếng ra khỏi thành phố, nhưng ra tới biển thì quên hết mệt.', 'Biển đông nghịt người, giá phòng tăng gấp đôi, vẫn vui vì cả nhà được đi cùng nhau.']), 'good'); H.fx(l, { hap: 4 }); } },
    { k: 've_que', l: 'Về quê thăm bố mẹ', req: function (l) { return l.fam.mAlive || l.fam.fAlive; }, ai: { soc: 1, w: 1.1 }, run: function (l, r, log) { log('Về quê mấy ngày, ăn cơm mẹ nấu, ngủ trưa trên chiếc chõng tre.', 'good'); H.fx(l, { hap: 3 }); } },
    { k: 'tang_ca', l: 'Đi làm ngày lễ lấy lương 300%', ai: { amb: 1 }, run: function (l, r, log) { var x = (l.income || l.base) / 365 * 2 * 3; H.cash(l, x, 'Lương làm ngày lễ 30/4 – 1/5'); l.flags.tangCaLe = (l.flags.tangCaLe || 0) + 1; log('Đi làm hai ngày lễ, cuối tháng nhận thêm khoản lương gấp ba. Mệt nhưng đáng.', 'neutral'); H.fx(l, { hea: -1 }); } }] });
  T('le_30_4', function (l, a) { return vn(l) && a >= 20 && a <= 62 && !!l.job && l.indep; }, 0.05, 8, 3);

  // bầu cử đại biểu Quốc hội và HĐND các cấp (5 năm một lần; năm 2026, 2031, 2036…)
  SC('bau_cu', { title: 'Ngày bầu cử', text: 'Năm nay cả nước bầu cử đại biểu Quốc hội và đại biểu Hội đồng nhân dân các cấp. Danh sách và tiểu sử ứng cử viên được niêm yết ở khu phố.', opts: [
    { k: 'tim_hieu', l: 'Đọc kỹ tiểu sử, chương trình hành động rồi đi bầu', ai: { smart: 1, w: 1.3 }, run: function (l, r, log) { log('Bạn đọc kỹ tiểu sử từng người, sáng chủ nhật cầm thẻ cử tri đi bầu từ sớm.', 'good'); H.fx(l, { kno: 1, karma: 1 }); l.flags.voted = (l.flags.voted || 0) + 1; } },
    { k: 'di_som', l: 'Đi bầu từ sáng sớm', ai: { w: 1.1 }, run: function (l, r, log) { log(pick(r, ['Bạn đi bầu từ sớm. Tổ bầu cử phát cho bạn tờ phiếu và hướng dẫn tận tình.', 'Lần đầu đi bầu cử, bạn hơi hồi hộp khi bỏ lá phiếu vào hòm.']), 'good'); l.flags.voted = (l.flags.voted || 0) + 1; } },
    { k: 'nho', l: 'Bận, nhờ người nhà bầu hộ', ai: { w: 0.5 }, run: function (l, r, log) { log('Tổ bầu cử giải thích: theo Luật Bầu cử, cử tri phải tự mình đi bầu, không được nhờ người khác bầu thay. Bạn thu xếp quay lại bỏ phiếu trước giờ đóng hòm.', 'neutral'); l.flags.voted = (l.flags.voted || 0) + 1; } }] });
  T('bau_cu', function (l, a) { var y = year(l); return vn(l) && a >= 18 && y >= 2026 && (y - 2026) % 5 === 0 && l.flags.votedAt !== y; }, function (l) { return (l.flags.voted || 0) < 2 ? 0.3 : 0.04; }, 4, 99, true);
  var bauApply = E.DEC.bau_cu.apply; E.DEC.bau_cu.apply = function (l) { l.flags.votedAt = year(l); return bauApply.apply(this, arguments); };
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
/* ===== js/life86.js ===== */
/* Một Đời — v6.8.0: khai thác sâu hơn Nemotron-Personas-Vietnam (NVIDIA & FPT, CC BY 4.0; xem data-personas-vn.js)
   · người quen kể kỹ năng nghề và điều họ đang mong muốn (theo nghề, theo vùng)
   · môn thể thao người cùng vùng, cùng tuổi hay chơi; nơi người cùng vùng hay đi du lịch; loại hình văn nghệ được ưa chuộng
   · thêm 30 thành tựu (thể thao, xê dịch, văn hóa, công dân, gia đình…) */
(function (G) {
  'use strict';
  var U = G.U, E = G.E, H = E.H, SC = E.SC;
  var PV = G.PERSONAS_VN || {}, P = PV.regions || {};
  function pick(r, a) { return U.pick(r, a); }
  function free(l) { return !(l.jailUntil != null && l.age < l.jailUntil) && !(l.abroad && l.abroad.trapped) && !(l.flags.military && l.age < l.flags.military); }
  function vn(l) { return H.isVN(l) && l.mode === 'vn' && !(l.abroad && (l.abroad.perm || l.abroad.trapped)); }
  function T(id, when, p, cd, max, rep) { E.TRIG.push({ id: id, when: function (l, a) { return free(l) && when(l, a); }, p: p, cd: cd || 4, max: max || 1, rep: !!rep }); }
  function low(s) { return s ? s.charAt(0).toLowerCase() + s.slice(1) : ''; }
  function band(a) { return a < 30 ? 'y' : a < 45 ? 'm' : a < 60 ? 'o' : 's'; }
  function wpick(r, list, skip) { var a = (list || []).filter(function (x) { return !skip || skip.indexOf(x[0]) < 0; }); if (!a.length) return null; var t = a.reduce(function (s, x) { return s + x[1]; }, 0), z = r() * t; for (var i = 0; i < a.length; i++) { z -= a[i][1]; if (z <= 0) return a[i][0]; } return a[a.length - 1][0]; }
  function group(l) { return E.PERSONA && E.PERSONA.group ? E.PERSONA.group(l) : null; }
  function regName(l) { var k = E.PERSONA && E.PERSONA.region(l); return k ? E.PERSONA.regionName(k) : ''; }

  // 1. người quen kể thêm kỹ năng nghề và điều đang mong muốn
  var NQ = E.DEC.pv_nguoi_quen;
  if (NQ) {
    var nqMake = NQ.make;
    NQ.make = function (l, r) {
      var d = nqMake.apply(this, arguments), x = d.data;
      if (!x || x.none || !x.job) return d;
      var sk = PV.skills && PV.skills[x.job], gl = PV.goalsByJob && PV.goalsByJob[x.job], g = group(l);
      if (!x.skill && sk && sk.length) x.skill = pick(r, sk.slice(0, 4));
      if (!x.goal) x.goal = gl && gl.length ? pick(r, gl) : (g && g.goal && g.goal.length ? wpick(r, g.goal.slice(0, 6)) : null);
      var dd = x.age - l.age, who = dd >= 18 ? (x.sex === 'F' ? 'cô ấy' : 'chú ấy') : dd >= 3 ? (x.sex === 'F' ? 'chị ấy' : 'anh ấy') : dd >= -3 ? 'bạn ấy' : 'em ấy';
      var extra = (x.skill ? ' Ai cũng khen ' + who + ' giỏi ' + low(x.skill) + '.' : '') + (x.goal ? ' Điều ' + who + ' đang mong nhất: ' + low(x.goal) + '.' : '');
      d.text = d.text + extra;
      return d;
    };
  }

  // 2. thể thao theo vùng, theo tuổi
  SC('pv_the_thao', {
    title: 'Rủ nhau rèn luyện',
    prep: function (l, r) { var g = group(l); if (!g || !g.sport) return { none: true }; var by = g.sportAge && g.sportAge[band(l.age)], src = (by && by.length >= 4 ? by : g.sport).filter(function (x) { return l.age <= 65 || !/gym|bóng đá|bóng rổ|leo núi|võ thuật/.test(x[0]); }), have = l.flags.sports || [], a = []; for (var i = 0; i < 3; i++) { var s = wpick(r, src, have.concat(a)); if (s) a.push(s); } return a.length >= 2 ? { list: a } : { none: true }; },
    valid: function (l, d) { return !d || !d.none; },
    text: function (l, d) { if (!d || d.none) return ''; return 'Ở ' + (regName(l) || 'chỗ bạn ở') + ', người tuổi bạn hay rủ nhau ' + d.list.map(low).join(', ') + '. Bạn muốn tham gia môn nào?'; },
    opts: [0, 1, 2].map(function (i) { return { k: 's' + i, l: function (l, d) { return d && d.list && d.list[i] ? 'Tham gia ' + low(d.list[i]) : ''; }, req: function (l, d) { return !!(d && d.list && d.list[i]); }, ai: { w: 1 }, run: function (l, r, log, d) { var s = d.list[i]; l.flags.sports = (l.flags.sports || []).concat([s]).slice(-3); log(pick(r, ['Bạn bắt đầu ' + low(s) + ' đều đặn mỗi tuần, người khỏe khoắn hẳn.', 'Nhóm ' + low(s) + ' ở gần nhà đón bạn rất nhiệt tình. Tập xong cả hội còn rủ nhau đi ăn.', 'Mấy buổi đầu ê ẩm cả người, nhưng rồi ' + low(s) + ' thành thói quen không bỏ được.']), 'good'); H.fx(l, { hea: 3, hap: 2, soc: 1 }); } }; }).concat([{ k: 'thoi', l: 'Thôi, mình ít vận động', run: function (l, r, log) { log('Bạn từ chối. Lâu lâu nghe nhóm bạn kể chuyện tập luyện cũng thấy vui lây.', 'neutral'); } }]) });
  T('pv_the_thao', function (l, a) { return vn(l) && a >= 15 && a <= 80 && (l.flags.sports || []).length < 3 && !!group(l); }, 0.05, 8, 3, true);
  E.HOOKS.year.unshift(function (l, r, log, a) { var s = l.flags && l.flags.sports; if (!s || !s.length || !l.alive || a < 15) return; if (r() < 0.08) { var sp = s[Math.floor(r() * s.length)]; if (a > 65 && /gym|bóng đá|bóng rổ|leo núi|võ thuật/.test(sp)) sp = 'đi bộ, tập dưỡng sinh'; H.fx(l, { hea: 1 }); log(pick(r, ['Vẫn giữ đều ' + low(sp) + ' — năm nay khám sức khỏe bác sĩ khen.', 'Nhóm ' + low(sp) + ' vẫn hẹn nhau đều đặn, năm nay có thêm vài người mới.', 'Nhờ ' + low(sp) + ' mà cả năm ít ốm vặt.', 'Năm nay ' + low(sp) + ' chăm hơn, người nhẹ nhõm hẳn.']), 'neutral'); } });

  // 3. du lịch: nơi người cùng vùng hay đi
  var ABROAD = ['Thái Lan', 'Singapore', 'Hàn Quốc', 'Nhật Bản', 'Trung Quốc', 'Đài Loan', 'Malaysia', 'Campuchia', 'châu Âu', 'Úc', 'Bali'];
  SC('pv_du_lich', {
    title: 'Chuyến đi năm nay',
    prep: function (l, r) { var g = group(l); if (!g || !g.place) return { none: true }; var here = String(l.provLabel || '') + ' ' + String(l.movedTo || '') + ' ' + String(l.prov && l.prov.old || ''), been = (l.flags.places || []).concat(['Sài Gòn', 'Hà Nội', 'Huế', 'Đà Nẵng', 'Cần Thơ', 'Đà Lạt', 'Vũng Tàu', 'Nha Trang', 'Tây Ninh', 'Cà Mau', 'Bến Tre', 'Lạng Sơn', 'Cao Bằng', 'Hà Giang', 'Pleiku', 'Buôn Ma Thuột', 'Quy Nhơn', 'Phan Thiết', 'Châu Đốc'].filter(function (p) { return here.indexOf(p) >= 0 || (p === 'Sài Gòn' && /Hồ Chí Minh/.test(here)) || (p === 'Đà Lạt' && /Lâm Đồng/.test(here)); })), rich = l.money > l.base * 3, a = []; for (var i = 0; i < 3; i++) { var p = wpick(r, g.place.filter(function (x) { return rich || ABROAD.indexOf(x[0]) < 0; }), been.concat(a)); if (p) a.push(p); } return a.length >= 2 ? { list: a } : { none: true }; },
    valid: function (l, d) { return !d || !d.none; },
    text: function (l, d) { if (!d || d.none) return ''; return 'Có mấy ngày nghỉ, bạn tính đi chơi một chuyến. Người ở ' + (regName(l) || 'quê bạn') + ' hay rủ nhau đi ' + d.list.join(', ') + '.'; },
    opts: [0, 1, 2].map(function (i) { return { k: 'p' + i, l: function (l, d) { return d && d.list && d.list[i] ? 'Đi ' + d.list[i] : ''; }, h: function (l, d) { var p = d && d.list && d.list[i]; return p ? 'Khoảng ' + H.money(l, l.base * (ABROAD.indexOf(p) >= 0 ? 0.25 : 0.06)) : ''; }, req: function (l, d) { var p = d && d.list && d.list[i]; return !!p && l.money >= l.base * (ABROAD.indexOf(p) >= 0 ? 0.25 : 0.06); }, ai: { w: 1 }, run: function (l, r, log, d) { var p = d.list[i], far = ABROAD.indexOf(p) >= 0; H.cash(l, -l.base * (far ? 0.25 : 0.06), 'Du lịch ' + p); l.flags.places = (l.flags.places || []).concat([p]); log(pick(r, ['Chuyến đi ' + p + ' để lại bao nhiêu ảnh đẹp, về nhà ai cũng hỏi.', 'Đi ' + p + ' mấy ngày, ăn đủ món ngon, về nhà vẫn còn nhớ.', 'Lần đầu đến ' + p + ', bạn đứng ngẩn người ngắm cảnh, thấy chuyến đi thật đáng.']), 'good'); H.fx(l, { hap: 4 }); H.mem(l, 'Chuyến đi ' + p + '.', 2); } }; }).concat([{ k: 'nha', l: 'Ở nhà nghỉ ngơi cho đỡ tốn', run: function (l, r, log) { log('Bạn ở nhà ngủ bù, dọn dẹp nhà cửa. Cũng là một kiểu nghỉ ngơi.', 'neutral'); } }]) });
  T('pv_du_lich', function (l, a) { return vn(l) && a >= 18 && l.indep && l.money > l.base * 0.3 && !!group(l); }, 0.06, 4, 3, true);

  // 4. văn nghệ được ưa chuộng ở vùng bạn (chỉ tiết mục biểu diễn)
  var STAGE = ['nhiếp ảnh', 'phim Hàn Quốc', 'vẽ tranh', 'thư pháp', 'đan len, thêu thùa', 'làm gốm', 'karaoke', 'đọc thơ'];
  SC('pv_van_nghe', {
    title: 'Đêm văn nghệ',
    prep: function (l, r) { var g = group(l); if (!g || !g.art) return { none: true }; var have = l.flags.arts || [], a = []; for (var i = 0; i < 3; i++) { var s = wpick(r, g.art.filter(function (x) { return STAGE.indexOf(x[0]) < 0; }).slice(0, 18), have.concat(a)); if (s) a.push(s); } return a.length >= 2 ? { list: a } : { none: true }; },
    valid: function (l, d) { return !d || !d.none; },
    text: function (l, d) { if (!d || d.none) return ''; return 'Nhà văn hóa tổ chức đêm văn nghệ, có ' + d.list.join(', ') + '. Bạn hứng thú với tiết mục nào nhất?'; },
    opts: [0, 1, 2].map(function (i) { return { k: 'a' + i, l: function (l, d) { return d && d.list && d.list[i] ? U.cap(d.list[i]) : ''; }, req: function (l, d) { return !!(d && d.list && d.list[i]); }, ai: { w: 1 }, run: function (l, r, log, d) { var s = d.list[i]; l.flags.arts = (l.flags.arts || []).concat([s]).slice(-5); log(pick(r, ['Bạn say sưa với ' + s + ' suốt buổi tối, về nhà vẫn ngân nga mãi.', 'Tiết mục ' + s + ' làm cả hội trường vỗ tay không ngớt. Bạn quyết định tìm hiểu thêm.']), 'good'); H.fx(l, { hap: 3 }); } }; }) });
  T('pv_van_nghe', function (l, a) { return vn(l) && a >= 10 && (l.flags.arts || []).length < 5 && !!group(l); }, 0.04, 8, 3, true);


  // 6. mai mối, xem mắt, giục cưới — tập quán phổ biến; đối chiếu số liệu cho thấy game có quá nhiều người 30–44 tuổi chưa lập gia đình
  function single(l) { return !l.partner || l.partner.alive === false; }
  function parentsUrge(l) { return l.fam.mAlive ? 'mẹ' : l.fam.fAlive && !l.fam.noDad ? 'bố' : 'họ hàng'; }
  SC('vn_xem_mat', {
    title: 'Đi xem mắt',
    prep: function (l, r) { var sx = H.partnerSex(l, r), g = group(l), age = U.clamp(l.age + U.randint(r, -4, 4), 20, 60), job = g && wpick(r, g.job.filter(function (x) { return !/^(Nghỉ hưu|Học sinh|Đang tìm)/.test(x[0]); }).slice(0, 30)) || 'Nhân viên văn phòng'; return { n: H.stranger(l, r, sx), sex: sx, age: age, job: job }; },
    valid: function (l) { return single(l); },
    text: function (l, d) { if (!d || !d.n) return ''; var u = parentsUrge(l); return U.cap(u) + ' sốt ruột vì bạn ' + l.age + ' tuổi rồi mà chưa có ai, nhờ người quen giới thiệu ' + d.n + ', ' + d.age + ' tuổi, ' + low(d.job) + '. "Gặp một buổi cho biết, có mất gì đâu."'; },
    opts: [
      { k: 'gap', l: 'Đi gặp một buổi cho bố mẹ vui', ai: { soc: 1, w: 1.3 }, run: function (l, r, log, d) { if (r() < 0.6) { l.partner = { name: d.n, sex: d.sex, age: d.age, status: 'dating', since: l.age, alive: true }; log(pick(r, ['Buổi xem mắt ở quán cà phê bắt đầu ngượng ngùng, rồi hai người nói chuyện mãi không dứt. Hẹn gặp lại lần nữa.', 'Không ngờ hai người hợp nhau đến vậy. ' + U.cap(parentsUrge(l)) + ' mừng ra mặt.']), 'good'); H.fx(l, { hap: 4 }); H.mem(l, 'Buổi xem mắt gặp ' + d.n + '.', 4); } else { log(pick(r, ['Gặp một buổi, hai người lịch sự chào nhau rồi thôi. Không có duyên.', 'Nói chuyện được vài câu thì hết chuyện. Về nhà ' + parentsUrge(l) + ' thở dài.']), 'neutral'); } } },
      { k: 'tu_choi', l: 'Từ chối, muốn tự tìm người mình thương', ai: { w: 0.8 }, run: function (l, r, log) { log('Bạn từ chối. ' + U.cap(parentsUrge(l)) + ' buồn mấy hôm, rồi lại dặn: "Thôi thì tùy con, nhưng đừng để muộn quá."', 'neutral'); if (l.mind) l.mind.stress = U.clamp((l.mind.stress || 0) + 3, 0, 100); } }
    ] });
  T('vn_xem_mat', function (l, a) { return vn(l) && a >= 26 && a <= 42 && single(l) && l.orient !== 'gay' && (l.fam.mAlive || l.fam.fAlive || true); }, 0.22, 3, 4, true);
  SC('vn_giuc_cuoi', {
    title: 'Hai bên gia đình giục cưới',
    valid: function (l) { return !!(l.partner && l.partner.alive !== false && l.partner.status === 'dating'); },
    text: function (l) { return 'Bạn và ' + (l.partner ? l.partner.name : 'người ấy') + ' quen nhau đã lâu. Tết này hai bên gia đình gặp nhau, ai cũng hỏi: "Bao giờ cho bố mẹ ăn cỗ?"'; },
    opts: [
      { k: 'cuoi', l: 'Bàn chuyện cưới xin', ai: { w: 1.3 }, run: function (l, r, log) { log('Hai người ngồi bàn chuyện cưới. Hai bên gia đình mừng rỡ.', 'good'); var W = E.DEC.cuoi_to_chuc; if (W && (!W.valid || W.valid(l, {}))) l.pending.unshift(W.make(l, r)); else if (E.DEC.marry && E.DEC.marry.make) l.pending.unshift(E.DEC.marry.make(l, r)); } },
      { k: 'chua', l: 'Xin thêm thời gian, lo sự nghiệp trước', ai: { w: 0.8 }, run: function (l, r, log) { log('Bạn xin thêm thời gian. Người ấy gật đầu, nhưng ánh mắt có chút buồn.', 'neutral'); } }
    ] });
  T('vn_giuc_cuoi', function (l, a) { var p = l.partner; return vn(l) && a >= 23 && a <= 45 && !!p && p.alive !== false && p.status === 'dating' && a - (p.since || a) >= 2; }, 0.35, 2, 4, true);


  // 7. v6.9: số liệu theo từng tỉnh / thành (34 đơn vị) — món đặc trưng của đúng tỉnh mình
  var PR = PV.provinces || {};
  function provKey(l) { if (!l.prov) return null; if (l.prov.neu && PR[l.prov.neu]) return l.prov.neu; var p = G.VN && G.VN.byName && G.VN.byName[l.prov.old]; return p && PR[p.newName] ? p.newName : PR[l.prov.old] ? l.prov.old : null; }
  // đặc sản đã được biết rộng rãi của từng tỉnh (34 đơn vị sau sắp xếp 2025, kể cả phần sáp nhập); dữ liệu persona chỉ dùng để xếp món nào hay được nhắc hơn
  var SPECIAL = { 'Hà Nội': ['phở', 'bún chả', 'chả cá', 'bánh cuốn'], 'Huế': ['bún bò Huế', 'cơm hến', 'bánh bèo', 'bánh nậm', 'bánh lọc'], 'Hải Phòng': ['bánh đa cua'], 'Đà Nẵng': ['mì Quảng', 'cao lầu', 'bánh tráng'], 'Thanh Hóa': ['nem chua'], 'Nghệ An': ['lươn'], 'Khánh Hòa': ['bún cá', 'bánh căn'], 'Lâm Đồng': ['bánh căn'], 'Gia Lai': ['bún cá', 'bánh xèo'], 'Tây Ninh': ['bánh tráng'], 'Đắk Lắk': ['cà phê'], 'Lào Cai': ['thắng cố', 'lẩu thắng cố'], 'Tuyên Quang': ['thắng cố', 'lẩu thắng cố'], 'Sơn La': ['thịt trâu gác bếp', 'cơm lam'], 'Điện Biên': ['thịt trâu gác bếp', 'cơm lam'], 'Lai Châu': ['thịt trâu gác bếp', 'cơm lam'], 'Lạng Sơn': ['heo quay', 'vịt'], 'Ninh Bình': ['phở'], 'Vĩnh Long': ['bún nước lèo'], 'Cần Thơ': ['bánh pía', 'bún nước lèo'], 'Đồng Tháp': ['hủ tiếu'], 'Cà Mau': ['bánh tằm'], 'An Giang': ['bún cá', 'nước mắm'], 'TP. Hồ Chí Minh': ['cơm tấm', 'hủ tiếu', 'bánh khọt'], 'Thái Nguyên': ['trà'], 'Phú Thọ': ['cơm lam'] };
  E.PROVINCE_SPECIALTIES = SPECIAL;
  function signature(k) { var sp = SPECIAL[k]; if (!sp) return []; var q = PR[k], cnt = {}; (q && q.dish || []).forEach(function (x) { cnt[x[0]] = x[1]; }); return sp.map(function (dn) { return [dn, (cnt[dn] || 0) + 1]; }).sort(function (a, b) { return b[1] - a[1]; }); }
  E.PERSONA.province = provKey; E.PERSONA.signatureDishes = signature;
  var MQ = E.DEC.pv_mon_que;
  if (MQ) {
    var mqMake = MQ.make;
    MQ.make = function (l, r) {
      var d = mqMake.apply(this, arguments), k = provKey(l) || (l.prov && (l.prov.neu || l.prov.old)), sig = k ? signature(k) : [];
      if (d.data && !d.data.none && sig.length && r() < 0.7) { var dish = wpick(r, sig); if (dish) { d.data.d = dish; d.data.prov = k; d.text = d.text.replace(/món [^—]+ —/, 'món ' + dish + ' —').replace(/món quen thuộc của [^.]+\./, 'món đặc trưng của ' + (l.variant === '63' && l.prov && l.prov.old && l.prov.old !== k ? 'quê bạn' : k) + '.'); } }
      return d;
    };
  }

  // 5. thêm thành tựu
  function lg(l, re) { return (l.log || []).some(function (e) { return e && re.test(e.t); }); }
  function dAge(l) { return l.death ? l.death.age : l.age; }
  var N = ['Hà Giang', 'Sa Pa', 'Hạ Long', 'Ninh Bình', 'Tràng An', 'Tam Cốc', 'Mộc Châu', 'Mai Châu', 'Cát Bà', 'Cao Bằng', 'Bản Giốc', 'Ba Bể', 'Lạng Sơn', 'Tam Đảo', 'Hà Nội', 'Chùa Hương', 'Yên Tử', 'Đền Hùng', 'Sầm Sơn'],
    M = ['Huế', 'Đà Nẵng', 'Hội An', 'Phong Nha', 'Lý Sơn', 'Quy Nhơn', 'Nha Trang', 'Đà Lạt', 'Buôn Ma Thuột', 'Pleiku', 'Măng Đen', 'Cửa Lò'],
    S = ['Phú Quốc', 'Cần Thơ', 'Châu Đốc', 'Bến Tre', 'Cà Mau', 'Vũng Tàu', 'Côn Đảo', 'Phan Thiết', 'Mũi Né', 'Tây Ninh', 'Sài Gòn'];
  function been(l, list) { return (l.flags.places || []).some(function (p) { return list.indexOf(p) >= 0; }); }
  function titles(l) { return [l.peakTitle || '', l.job ? E.jobTitle(l) : ''].concat((l.jobsHist || []).map(function (h) { try { return E.jobLabel(h.id); } catch (e) { return ''; } })).join(' | '); }
  if (E.addAchievements) E.addAchievements([
    ['khoe_tre', '🏃', 'Khỏe như thanh niên', 'Chơi từ 2 môn thể thao và sống tới 70 tuổi', function (l) { return (l.flags.sports || []).length >= 2 && dAge(l) >= 70; }],
    ['xe_dich', '🎒', 'Xê dịch', 'Đi du lịch từ 5 nơi', function (l) { return (l.flags.places || []).length >= 5; }],
    ['xuyen_viet', '🇻🇳', 'Xuyên Việt', 'Đặt chân tới cả ba miền Bắc, Trung, Nam', function (l) { return been(l, N) && been(l, M) && been(l, S); }],
    ['ra_the_gioi', '🌏', 'Ra thế giới', 'Đi du lịch nước ngoài', function (l) { return been(l, ABROAD); }],
    ['giu_hon_que', '🪕', 'Giữ hồn quê', 'Theo nghệ nhân học từ 2 di sản văn hóa', function (l) { return (l.flags.dsLearn || 0) >= 2; }],
    ['con_cua_di_san', '🏮', 'Người con của di sản', 'Tham dự từ 3 di sản văn hóa phi vật thể', function (l) { return Object.keys(l.flags.dsSeen || {}).length >= 3; }],
    ['cong_dan', '🗳️', 'Công dân gương mẫu', 'Đi bầu cử từ 3 lần', function (l) { return (l.flags.voted || 0) >= 3; }],
    ['me_su', '📜', 'Sử Ta Phải Biết', 'Chăm chú học từ 2 bài lịch sử', function (l) { return (l.flags.lsGood || 0) >= 2; }],
    ['tam_hon_nghe_si', '🎭', 'Tâm hồn nghệ sĩ', 'Mê từ 3 loại hình văn nghệ', function (l) { return (l.flags.arts || []).length >= 3; }],
    ['song_cham', '🍃', 'Sống chậm', 'Có 4 thú vui riêng', function (l) { return (l.flags.hobbies || []).length >= 4; }],
    ['lang_gieng', '🏘️', 'Bán anh em xa, mua láng giềng gần', 'Quen từ 3 người hàng xóm', function (l) { return ((l.flags.scN || {}).pv_nguoi_quen || 0) >= 3; }],
    ['huong_vi_que', '🍲', 'Hương vị quê nhà', 'Sống xa quê vẫn tự nấu món quê', function (l) { return (l.flags.homeDish || 0) >= 1; }],
    ['giu_le_dan_toc', '🎎', 'Nét đẹp ngàn đời', 'Về dự lễ tết của dân tộc mình từ 2 lần', function (l) { return (l.flags.ethFest || 0) >= 2; }],
    ['uong_nuoc_nho_nguon', '🕯️', 'Uống nước nhớ nguồn', 'Tri ân các anh hùng liệt sĩ ngày 27/7', function (l) { return (l.flags.triAn || 0) >= 1; }],
    ['ve_den_hung', '⛩️', 'Về nguồn', 'Dâng hương ở Đền Hùng ngày Giỗ Tổ', function (l) { return !!l.flags.denHung; }],
    ['cay_ngay_le', '⏱️', 'Cày cả ngày lễ', 'Đi làm ngày lễ 30/4 – 1/5 từ 2 lần', function (l) { return (l.flags.tangCaLe || 0) >= 2; }],
    ['vuot_so_phan', '🌄', 'Vượt số phận', 'Sống lâu hơn tuổi thọ kỳ vọng 15 năm', function (l) { return !!(l.death && l.e0sex && l.death.age >= l.e0sex + 15); }],
    ['chat_dan', '🍼', 'Chắt đàn', 'Có từ 5 đứa chắt', function (l) { return (l.ggrand || 0) >= 5; }],
    ['vuon_thu', '🦜', 'Vườn thú tại gia', 'Nuôi từ 4 thú cưng trong đời', function (l) { return (l.pets || []).length >= 4; }],
    ['hoc_sinh_gioi', '🥇', 'Học sinh giỏi', 'Đoạt giải học sinh giỏi', function (l) { return lg(l, /giải (nhất|nhì|ba|khuyến khích)[^.]*(học sinh giỏi|HSG)|học sinh giỏi (cấp )?(tỉnh|thành|quốc gia)[^.]*giải/); }],
    ['thu_khoa', '🎖️', 'Thủ khoa', 'Đỗ thủ khoa', function (l) { return lg(l, /thủ khoa/i); }],
    ['tron_ven', '🌕', 'Một đời trọn vẹn', 'Sống tới 75, có con cháu, không nợ nần, bạn đời bên cạnh 40 năm', function (l) { var p = l.partner; return dAge(l) >= 75 && (l.kids || []).length >= 2 && (l.grand || 0) > 0 && E.netWorth(l) > 0 && !!(p && p.alive !== false && p.status !== 'dating' && p.since != null && dAge(l) - p.since >= 40); }],
    ['xe_hoi', '🚙', 'Xe hơi đầu tiên', 'Sở hữu ô tô', function (l) { return lg(l, /(mua|tậu|sắm)[^.]{0,30}(ô tô|xe hơi|chiếc xe [A-Z])/) || !!(l.veh && /ô tô|xe hơi|sedan|SUV|bán tải/i.test(JSON.stringify(l.veh))); }],
    ['ra_di_thanh_than', '🕊️', 'Ra đi thanh thản', 'Sống tới 80 tuổi và ra đi nhẹ nhàng vì tuổi già', function (l) { return !!(l.death && l.death.age >= 80 && /tuổi già|thanh thản/.test(l.death.cause || '')); }],
    ['ban_xu', '🏡', 'Một đời bên quê', 'Sống trọn đời ở quê nhà tới 70 tuổi', function (l) { return dAge(l) >= 70 && !l.movedTo && !l.abroad && !lg(l, /xuất khẩu lao động|định cư/); }],
    ['khong_nghi', '🛠️', 'Không chịu ngồi yên', 'Vẫn đi làm ở tuổi 70', function (l) { return dAge(l) >= 70 && !!l.job && !l.retired; }],
    ['tieu_thuong', '🧺', 'Buôn bán giỏi', 'Làm tiểu thương, chủ cửa hàng', function (l) { return /tiểu thương|bán hàng|chủ (cửa hàng|tiệm|sạp)|buôn/.test(titles(l)); }],
    ['tho_lanh_nghe', '🔧', 'Thợ lành nghề', 'Làm thợ, công nhân hơn 20 năm', function (l) { return /thợ|công nhân/.test(titles(l)) && (l.workYrs || 0) >= 20; }],
    ['dai_gia_dinh', '👪', 'Đại gia đình', 'Có từ 3 người con và 6 đứa cháu', function (l) { return (l.kids || []).length >= 3 && (l.grand || 0) >= 6; }],
    ['tinh_nguyen', '💗', 'Trái tim thiện nguyện', 'Sống tử tế và nhiều lần làm từ thiện', function (l) { return (l.karma || 0) >= 40 && (l.log || []).filter(function (e) { return /từ thiện|ủng hộ|quyên góp|thiện nguyện|công quả|phát cơm/.test(e.t); }).length >= 2; }]
  ]);
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
/* ===== js/life87.js ===== */
/* Một Đời — v7.0.0: rà soát lỗi logic toàn hệ thống
   · tuổi kết hôn theo luật: Việt Nam nam từ đủ 20, nữ từ đủ 18 tuổi (Luật Hôn nhân và Gia đình 2014, Điều 8);
     các nước khác từ 18 tuổi. Chưa đủ tuổi thì không có lời cầu hôn / đám cưới; có thai sớm thì về chung sống,
     đợi đủ tuổi mới đăng ký kết hôn */
(function (G) {
  'use strict';
  var U = G.U, E = G.E, H = E.H;
  function vnLaw(l) { return H.isVN(l) && !(l.abroad && l.abroad.perm); }
  function marryAge(l, sex) { return vnLaw(l) ? (sex === 'M' ? 20 : 18) : 18; }
  function legalToMarry(l) { var p = l.partner; if (!p || p.alive === false) return false; return l.age >= marryAge(l, l.sex) && (p.age == null || p.age >= marryAge(l, p.sex)); }
  E.marryAge = marryAge; E.legalToMarry = legalToMarry;
  function gate(id) { var D = E.DEC[id]; if (!D) return; var v = D.valid; D.valid = function (l, d) { return legalToMarry(l) && (!v || v.apply(this, arguments)); }; }
  gate('marry'); gate('cuoi_to_chuc'); gate('vn_giuc_cuoi');
  // giục cưới chỉ khi cả hai đã đủ tuổi
  E.TRIG.forEach(function (t) { if (t.id === 'vn_giuc_cuoi' || t.id === 'marry') { var w = t.when; t.when = function (l) { return legalToMarry(l) && w.apply(this, arguments); }; } });
  // đám cưới chạy bầu khi chưa đủ tuổi: về chung sống, đủ tuổi mới đăng ký
  var CB = E.DEC.co_bau_som;
  if (CB) {
    var cbAp = CB.apply;
    CB.apply = function (l, d, k, r, log) {
      if (k === 'cuoi' && l.partner && !legalToMarry(l)) {
        var p = l.partner, need = Math.max(marryAge(l, l.sex) - l.age, p.age != null ? marryAge(l, p.sex) - p.age : 0);
        log((vnLaw(l) ? 'Theo Luật Hôn nhân và Gia đình, nam từ đủ 20, nữ từ đủ 18 tuổi mới được đăng ký kết hôn. ' : 'Chưa đủ tuổi kết hôn theo luật. ') + 'Hai gia đình cho hai bạn về ở cùng nhau, hẹn ' + need + ' năm nữa đủ tuổi sẽ làm đám cưới.', 'neutral');
        l.flags.marryWhenLegal = p.name;
        return cbAp.call(this, l, d, 'cung_nuoi', r, log);
      }
      return cbAp.apply(this, arguments);
    };
  }
  // đủ tuổi rồi thì tổ chức đám cưới đã hẹn
  E.HOOKS.year.unshift(function (l, r, log, a) {
    var n = l.flags.marryWhenLegal; if (!n || !l.partner || l.partner.name !== n || l.partner.status === 'married' || l.partner.alive === false) return;
    if (legalToMarry(l)) { l.flags.marryWhenLegal = null; var W = E.DEC.cuoi_to_chuc; if (W && W.valid(l, {})) l.pending.unshift(W.make(l, r)); else if (E.DEC.marry) l.pending.unshift(E.DEC.marry.make(l, r)); }
  });
  // lưới an toàn: không để hôn nhân dưới tuổi luật định xuất hiện từ bất kỳ đường nào
  E.HOOKS.year.unshift(function (l, r, log, a) {
    var p = l.partner; if (!p || p.status !== 'married' || p.alive === false) return;
    if (l.age < marryAge(l, l.sex) && (p.since == null || p.since >= l.age - 1)) { p.status = 'dating'; l.flags.marryWhenLegal = p.name; }
  });
  // nghỉ hưu trước tuổi (lực lượng vũ trang sau sắp xếp tổ chức): chỉ khi đã từ 48 tuổi và có từ 20 năm công tác — trước đây có người 38 tuổi đã nhận lương hưu
  E.TRIG.forEach(function (t) { if (t.id === 'qd_nghi_huu_som') { var w = t.when; t.when = function (l, a) { return l.age >= 48 && (l.workYrs || 0) >= 20 && w.apply(this, arguments); }; } });
  var NHS = E.DEC.qd_nghi_huu_som; if (NHS) { var nv = NHS.valid; NHS.valid = function (l) { return l.age >= 48 && (l.workYrs || 0) >= 20 && (!nv || nv.apply(this, arguments)); }; }
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
/* ===== js/life88.js ===== */
/* Một Đời — v7.1.0: xuất thân mồ côi ngẫu nhiên
   · khoảng 1–4% ca sinh (nhà càng nghèo càng dễ gặp) không còn bố mẹ bên cạnh từ khi chào đời — dùng RNG riêng nên các đời khác không đổi
   · bốn hoàn cảnh: ông bà nuôi, họ hàng cưu mang, mái ấm / trại trẻ mồ côi (hoặc gia đình nuôi dưỡng tạm thời ở nước ngoài), bị bỏ rơi trước cổng chùa
   · người nuôi dưỡng chi tiêu cho bạn đến tuổi tự lập; không có thừa kế, không ai chu cấp, ra đời với hai bàn tay trắng
   · trẻ ở mái ấm có thể được một gia đình nhận làm con nuôi; người lớn tuổi nuôi bạn có thể mất trước khi bạn trưởng thành
   · học bổng cho trẻ mồ côi, ngày rời mái ấm, tìm lại bố mẹ ruột, thành tựu dành riêng */
(function (G) {
  'use strict';
  var U = G.U, E = G.E, H = E.H, SC = E.SC, isVN = H.isVN;
  function pick(r, a) { return U.pick(r, a); }
  function ch(r, p) { return r() < p; }
  function inJail(l) { return l.jailUntil != null && l.age < l.jailUntil; }
  function free(l) { return !inJail(l) && !(l.abroad && l.abroad.trapped); }
  function T(id, when, p, cd, max) { E.TRIG.push({ id: id, when: function (l, a) { return free(l) && when(l, a); }, p: p, cd: cd || 4, max: max || 1 }); }
  function O(l) { return l && l.fam && l.fam.orphan || null; }
  function raised(l) { var o = O(l); return o && !o.adopted ? o : null; }
  function stress(l, x) { if (l.mind) l.mind.stress = U.clamp(l.mind.stress + x, 0, 100); }
  var RICH = /^(us|gb|ca|au|nz|de|fr|nl|se|no|dk|fi|ie|be|at|ch)$/;
  var KIND = {
    ong_ba: { carer: 'ông bà', one: 'bà', label: 'ông bà nuôi nấng' },
    ho_hang: { carer: 'cô chú', one: 'cô', label: 'họ hàng cưu mang' },
    mai_am: { carer: 'các cô ở mái ấm', one: 'cô bảo mẫu', label: 'lớn lên ở mái ấm trẻ mồ côi' },
    chua: { carer: 'sư cô', one: 'sư cô', label: 'được nhà chùa nuôi dưỡng' }
  };
  function kindOf(l) { var o = O(l); return o ? KIND[o.kind] : null; }
  E.isOrphanBorn = function (l) { return !!raised(l); };
  // người nuôi dưỡng trẻ không còn bố mẹ (mồ côi từ khi chào đời, hoặc bố mẹ mất khi còn nhỏ)
  E.orphanCarer = function (l) {
    if (!l || !l.fam || l.age >= 18 || l.indep) return null;
    var o = raised(l); if (o) return o.carer;
    var f = l.fam; if (f.mAlive || (f.fAlive && !f.noDad)) return null;
    return l.flags && l.flags.orphanCarer || null;
  };

  function setup(l, h) {
    var f = l.fam, vn = isVN(l), rich = RICH.test(l.pool || '') || (l.gdp || 0) >= 30;
    var w = vn ? 'ong_ba:5,ho_hang:3,mai_am:2.5,chua:1' : rich ? 'ong_ba:3,ho_hang:3,mai_am:3' : 'ong_ba:5,ho_hang:3,mai_am:2.5';
    var kind = U.wkey(function () { return U.rand(h); }, w), K = KIND[kind];
    var o = { kind: kind, carer: K.carer, one: K.one, unknown: kind === 'chua' || (kind === 'mai_am' && U.rand(h) < 0.5) };
    if (kind === 'mai_am' && rich) { o.carer = 'gia đình nuôi dưỡng tạm thời'; o.one = 'mẹ nuôi tạm thời'; o.foster = true; }
    o.cause = o.unknown ? null : pick(function () { return U.rand(h); }, ['mất trong một vụ tai nạn giao thông', 'mất trong một trận lũ dữ', 'lần lượt qua đời vì bạo bệnh', 'mất trong một vụ cháy nhà', 'mất trong một vụ sập công trình']);
    o.carerAge = kind === 'ong_ba' ? 52 + Math.floor(U.rand(h) * 16) : 30 + Math.floor(U.rand(h) * 18);
    f.orphan = o;
    f.mAlive = false; f.fAlive = false; f.mInc = 0; f.fInc = 0; f.vice = null;
    if (o.unknown) { f.noDad = true; f.mName = 'Không rõ'; f.mJob = 'không rõ tung tích'; f.fJob = ''; f.sibs = 0; }
    else { f.noDad = false; f.mJob = 'đã mất'; f.fJob = 'đã mất'; }
    if (kind === 'mai_am' || kind === 'chua') { f.q = 1; f.home = kind === 'chua' ? 'nhà chùa' : (o.foster ? 'nhà nuôi dưỡng tạm thời' : 'mái ấm'); f.sibs = o.unknown ? 0 : f.sibs; }
    else { f.q = Math.max(1, f.q - 1); }
    l.sendParents = false; l.flags.famHardship = true; l.flags.orphanBorn = kind; l.flags.birthQ = f.q;
    var s = l.log[0] ? l.log[0].t : '';
    s = s.replace(/,? (thuộc|trong) (một trong những gia đình|một gia đình)[^.]*\./, '.').replace(/ Bạn có \d+ anh chị\.| Bạn là con đầu lòng\.| Mẹ một mình nuôi bạn\.| Bố bạn [^.]*\./g, '');
    var add = o.unknown
      ? (kind === 'chua' ? ' Một sáng sớm, sư cô quét sân thấy bạn nằm trong chiếc giỏ nhựa trước cổng chùa, quấn chiếc khăn mỏng, kèm mảnh giấy ghi ngày sinh. Không ai biết bố mẹ bạn là ai.'
        : ' Bạn được tìm thấy ở ' + pick(function () { return U.rand(h); }, ['cổng bệnh viện', 'trạm y tế', 'một bến xe']) + ' khi mới vài ngày tuổi, rồi được đưa vào ' + (o.foster ? 'một gia đình nuôi dưỡng tạm thời' : 'mái ấm trẻ mồ côi') + '. Không ai biết bố mẹ bạn là ai.')
      : ' Khi bạn còn đỏ hỏn, bố mẹ ' + o.cause + '. ' + (kind === 'ong_ba' ? 'Ông bà ' + (U.rand(h) < 0.5 ? 'nội' : 'ngoại') + ' đón bạn về nuôi.' : kind === 'ho_hang' ? 'Cô chú bên ' + (U.rand(h) < 0.5 ? 'nội' : 'ngoại') + ' cưu mang bạn, dù nhà cũng chẳng dư dả.' : 'Không còn người thân đủ sức nuôi, bạn được đưa vào ' + (o.foster ? 'một gia đình nuôi dưỡng tạm thời' : 'mái ấm trẻ mồ côi') + '.');
    if (l.log[0]) { l.log[0].t = s + add; l.log[0].k = 'big'; }
    H.mem(l, o.unknown ? 'Không ai biết bạn chào đời ở đâu, chỉ có mảnh giấy ghi ngày sinh.' : 'Bố mẹ ra đi khi bạn còn chưa kịp nhớ mặt.', 5, 0);
  }

  var createLife = E.createLife;
  E.createLife = function (opts) {
    var l = createLife.apply(this, arguments), PA = opts && opts.parent;
    if (PA || (opts && opts.noOrphan) || l.fam.elite || (l.flags && l.flags.royal)) return l;
    var h = { rs: (l.rs ^ 0x0a1f4a7) | 0 }, x = U.rand(h), p = [0, 0.04, 0.025, 0.014, 0.008, 0.004][l.fam.q] || 0.01;
    if (opts && opts.orphan) p = 1;
    if (x < p) setup(l, h);
    return l;
  };

  // bối cảnh xuất phát
  var bc = E.birthContext;
  if (bc) E.birthContext = function (l) {
    var o = raised(l), x = bc.apply(this, arguments);
    if (o && x && l.age < 18) x.text = U.cap(KIND[o.kind] && o.foster ? 'lớn lên trong gia đình nuôi dưỡng tạm thời' : KIND[o.kind].label) + ', ' + (o.unknown ? 'không rõ bố mẹ ruột là ai' : 'bố mẹ mất khi bạn còn đỏ hỏn') + '. Không có chỗ dựa tài chính, mọi thứ phải tự gây dựng';
    return x;
  };

  // người nuôi dưỡng già yếu, qua đời
  E.HOOKS.year.unshift(function (l, r, log, a) {
    var o = raised(l); if (!o || !l.alive || a < 1 || a > 17) return;
    if ((o.kind === 'ong_ba' || o.kind === 'ho_hang') && !o.carerGone) {
      var age = o.carerAge + a, q = age < 60 ? 0.004 : age < 70 ? 0.015 : age < 80 ? 0.045 : 0.12;
      if (r() < q) {
        o.carerGone = a;
        log(o.kind === 'ong_ba' ? 'Bà qua đời ở tuổi ' + age + '. Người đã thay bố mẹ nuôi bạn khôn lớn ra đi, bạn chuyển về ở với ' + (o.kind2 = pick(r, ['cô ruột', 'chú ruột', 'bác ruột'])) + '.' : 'Chú qua đời vì bạo bệnh. Cô một mình gồng gánh, bạn tự nhủ phải lớn thật nhanh.', 'bad');
        o.carer = o.kind === 'ong_ba' ? o.kind2 : 'cô'; o.one = 'cô';
        H.fx(l, { hap: -10 }); stress(l, 15); H.mem(l, 'Ngày người nuôi mình khôn lớn ra đi.', 6); if (l.fam.q > 1) l.fam.q--;
      }
    }
  });

  // tuổi thơ không có bố mẹ
  E.EVENTS.push({ c: function (l, a) { return !!raised(l) && a >= 4 && a <= 17; }, p: 0.3, cd: 3, run: function (l, a, r, log) {
    var o = raised(l), k = o.carerGone ? 'ho_hang' : o.kind, vn = isVN(l);
    var t = k === 'ong_ba' ? ['Bà còng lưng ra đồng từ tờ mờ sáng, tối về vẫn ngồi vá áo cho bạn dưới bóng đèn.', 'Ông chở bạn đi học bằng chiếc xe đạp cũ, đến dốc thì hai ông cháu cùng xuống dắt.', 'Hôm họp phụ huynh, bà là người lớn tuổi nhất trong lớp. Bạn vừa thương vừa thấy tủi.', 'Bà hay kể chuyện ngày xưa của bố mẹ bạn. Bạn nghe mãi không chán.']
      : k === 'ho_hang' ? ['Nhà cô chú đông con, bạn quen nhường phần ngon cho các em.', 'Bạn nghe lỏm được cô chú bàn chuyện tiền học của mình, đêm đó bạn trằn trọc mãi.', 'Chú ít nói nhưng hay dúi cho bạn ít tiền ăn sáng, dặn đừng nói với ai.', 'Bạn tự giặt quần áo, tự nấu cơm từ năm lên tám để đỡ đần cô chú.']
      : k === 'chua' ? ['Sáng nào bạn cũng dậy từ bốn giờ quét sân chùa cùng các chú tiểu.', 'Sư cô dạy bạn chữ và dạy cả cách sống tử tế. "Không có bố mẹ thì con càng phải thương người."', 'Rằm tháng Bảy, khách thập phương về chùa đông. Bạn lặng nhìn những đứa trẻ được bố mẹ dắt tay.', 'Bạn mặc lại quần áo cũ của các anh chị đi trước, đôi dép đứt quai được buộc lại bằng dây thép.']
      : o.foster ? ['Lại chuyển sang một gia đình nuôi dưỡng mới. Bạn quen với việc sống trong vali.', 'Cán bộ xã hội đến thăm định kỳ, hỏi bạn có ổn không. Bạn gật đầu, như mọi lần.', 'Gia đình nuôi dưỡng tạm thời đối xử tốt, nhưng bạn biết mình chỉ là khách.']
      : ['Bữa cơm ở mái ấm có hai mươi đứa trẻ ngồi chung một mâm dài. Đứa lớn gắp cho đứa bé.', 'Các cô ở mái ấm thay nhau thức đêm khi bạn sốt cao.', vn ? 'Trung thu, một đoàn từ thiện đến phát bánh, ai cũng chụp ảnh với bọn trẻ rồi về.' : 'Một nhóm tình nguyện đến tổ chức tiệc sinh nhật chung cho cả mái ấm.', 'Ngày Tết, mái ấm vắng hẳn vì có đứa được họ hàng đón về. Bạn ở lại cùng các cô.', 'Bạn có một người anh em cùng mái ấm, hai đứa hứa sau này lớn lên sẽ đỡ đần nhau.'];
    if (!l.school) t = t.filter(function (s) { return !/phụ huynh|đi học/.test(s); }); if (!t.length) return;
    log(pick(r, t), 'neutral');
    if (ch(r, 0.5)) H.fx(l, { hap: -1 }); else H.fx(l, { soc: 1, karma: 1 });
  } });
  E.EVENTS.push({ c: function (l, a) { return !!raised(l) && a >= 7 && a <= 15; }, p: 0.08, cd: 5, run: function (l, a, r, log) {
    log(pick(r, ['Bài văn "Tả mẹ của em", bạn ngồi nhìn trang giấy trắng rất lâu rồi viết về ' + raised(l).one + '.', 'Có đứa bạn trêu bạn là "đứa không có bố mẹ". Bạn không khóc, chỉ siết chặt tay.', 'Ngày 8/3, cả lớp làm thiệp tặng mẹ. Bạn làm một tấm và tặng ' + raised(l).one + '.']), 'neutral');
    H.fx(l, { hap: -2 }); stress(l, 4);
  } });

  // con nuôi
  SC('mc_nhan_nuoi', {
    title: 'Có người muốn nhận bạn làm con nuôi',
    prep: function (l, r) { return { m: H.name(l, r, 'F').full, f: H.name(l, r, 'M').full, q: U.wkey(r, '2:2,3:4,4:3,5:1') | 0 }; },
    valid: function (l) { var o = raised(l); return !!o && (o.kind === 'mai_am' || o.kind === 'chua') && l.age >= 1 && l.age <= 9; },
    text: function (l, d) { return 'Một cặp vợ chồng hiếm muộn đến ' + (raised(l).kind === 'chua' ? 'chùa' : 'mái ấm') + ' nhiều lần, ngồi chơi với bạn cả buổi. Họ làm thủ tục xin nhận bạn làm con nuôi.'; },
    opts: [
      { k: 'theo', l: 'Về nhà mới', ai: { w: 3 }, run: function (l, r, log, d) {
        var f = l.fam, o = f.orphan, vn = isVN(l);
        o.adopted = l.age; f.mAlive = true; f.fAlive = true; f.noDad = false; f.mName = d.m; f.fName = d.f; f.q = U.clamp(d.q, 2, 5);
        var J = vn ? ['giáo viên', 'nhân viên văn phòng', 'kinh doanh nhỏ', 'công chức', 'kỹ sư', 'bác sĩ', 'công nhân'] : ['giáo viên', 'nhân viên văn phòng', 'kỹ sư', 'y tá', 'chủ cửa hàng'];
        f.mJob = pick(r, J); f.fJob = pick(r, J); f.mInc = E.parentMonthly(l, f.mJob, r) * (0.6 + f.q * 0.2); f.fInc = E.parentMonthly(l, f.fJob, r) * (0.6 + f.q * 0.2); f.mInc0 = f.mInc; f.fInc0 = f.fInc;
        f.mAge = U.clamp(Math.round(33 + r() * 10) - l.age, 20, 50); f.fAge = f.mAge + 2; f.sibs = 0; f.home = 'nhà riêng';
        l.sendParents = vn || f.q <= 3; l.flags.famHardship = f.q <= 1;
        log('Thủ tục nhận con nuôi hoàn tất. Bạn có bố mẹ: ' + d.f + ' và ' + d.m + '. Đêm đầu tiên ở nhà mới, mẹ ngồi bên giường đến khi bạn ngủ.', 'big');
        H.fx(l, { hap: 10 }); stress(l, -10); H.mem(l, 'Ngày có bố mẹ, có một ngôi nhà để về.', 7);
      } },
      { k: 'o_lai', l: 'Khóc, níu áo các cô không chịu đi', ai: { w: 0.4 }, run: function (l, r, log) { log('Bạn khóc cả buổi, níu áo ' + raised(l).one + ' không buông. Cặp vợ chồng thương mà đành ra về.', 'neutral'); H.fx(l, { hap: -2 }); } }
    ]
  });
  T('mc_nhan_nuoi', function (l, a) { var o = raised(l); return !!o && (o.kind === 'mai_am' || o.kind === 'chua') && a >= 1 && a <= 9 && !(l.abroad); }, 0.12, 2, 1);

  // học bổng
  SC('mc_hoc_bong', {
    title: 'Học bổng cho học sinh mồ côi',
    text: function (l) { return (isVN(l) ? 'Một quỹ khuyến học' : 'Một tổ chức từ thiện') + ' trao học bổng cho học sinh mồ côi vượt khó. Thầy chủ nhiệm muốn giới thiệu bạn, nhưng phải viết bài kể về hoàn cảnh của mình.'; },
    valid: function (l) { return !!raised(l) && !!l.school; },
    opts: [
      { k: 'viet', l: 'Viết thật lòng về hoàn cảnh của mình', ai: { w: 2 }, run: function (l, r, log) { var v = l.base * (0.05 + r() * 0.06); H.cash(l, v, 'Học bổng cho học sinh mồ côi'); l.flags.orphanScholar = true; log('Bạn viết về ' + raised(l).one + ', về những bữa cơm đạm bạc. Bạn nhận học bổng ' + H.money(l, v) + ', đủ mua sách vở và một đôi giày mới.', 'good'); H.fx(l, { hap: 4, kno: 1 }); } },
      { k: 'thoi', l: 'Từ chối, không muốn ai thương hại', ai: { w: 0.5, risk: 1 }, run: function (l, r, log) { log('Bạn từ chối. "Em tự lo được." Thầy chủ nhiệm nhìn bạn rất lâu.', 'neutral'); H.fx(l, { hap: -1 }); } }
    ]
  });
  T('mc_hoc_bong', function (l, a) { return !!raised(l) && !!l.school && a >= 10 && a <= 17; }, 0.25, 3, 1);

  // rời mái ấm
  E.HOOKS.year.unshift(function (l, r, log, a) {
    var o = raised(l); if (!o || a !== 18 || o.left || !l.alive) return;
    o.left = a;
    if (o.kind === 'mai_am' || o.kind === 'chua') {
      var gift = l.base * 0.03; H.cash(l, gift, o.kind === 'chua' ? 'Sư cô cho làm vốn' : 'Mái ấm hỗ trợ khi ra đời');
      log((o.kind === 'chua' ? 'Mười tám tuổi, bạn chào sư cô rời chùa. Sư cô dúi vào tay bạn ' : o.foster ? 'Mười tám tuổi, bạn hết tuổi được nuôi dưỡng tạm thời. Cán bộ xã hội trao cho bạn ' : 'Mười tám tuổi, bạn rời mái ấm với một chiếc ba lô và ') + H.money(l, gift) + '. Từ nay không còn ai lo cơm áo cho bạn nữa.', 'big');
      H.mem(l, o.kind === 'chua' ? 'Ngày rời cổng chùa, quay lại vẫn thấy sư cô đứng nhìn theo.' : 'Ngày rời mái ấm với chiếc ba lô cũ.', 5);
    } else log('Mười tám tuổi. ' + U.cap(o.carer) + ' đã làm hết sức mình. Từ đây bạn phải tự lo lấy thân.', 'neutral');
  });

  // tìm lại bố mẹ ruột
  SC('mc_tim_bo_me', {
    title: 'Tìm lại bố mẹ ruột',
    text: 'Mảnh giấy ghi ngày sinh bạn vẫn giữ trong ví. Một chương trình truyền hình tìm người thân đang nhận hồ sơ, có hỗ trợ xét nghiệm ADN miễn phí.',
    valid: function (l) { var o = O(l); return !!o && o.unknown && !o.searched; },
    opts: [
      { k: 'tim', l: 'Gửi hồ sơ tìm người thân', ai: { w: 1.2 }, run: function (l, r, log) {
        var o = O(l); o.searched = l.age;
        if (ch(r, 0.3)) { o.found = l.age; log(pick(r, ['Ba tháng sau, chương trình báo tin: mẫu ADN trùng khớp. Mẹ ruột của bạn ở một tỉnh khác, năm ấy mới mười bảy tuổi, bị gia đình ép bỏ con. Hai mẹ con ôm nhau khóc nghẹn trên sân khấu.', 'Có người nhận ra vết bớt trên vai bạn. Bố mẹ ruột tìm đến, giờ đã có gia đình riêng. Cuộc gặp lúng túng, nhưng bạn cuối cùng cũng biết mình từ đâu đến.']), 'big'); H.fx(l, { hap: 8 }); H.mem(l, 'Ngày tìm lại được người sinh ra mình.', 8); }
        else { log('Hồ sơ đăng lên, có vài cuộc gọi nhưng xét nghiệm đều không khớp. Bạn cất mảnh giấy vào ví, như cũ.', 'neutral'); H.fx(l, { hap: -3 }); }
      } },
      { k: 'thoi', l: 'Thôi, người nuôi mình mới là gia đình', ai: { w: 1 }, run: function (l, r, log) { O(l).searched = l.age; log('Bạn quyết định không tìm nữa. Người đã nuôi bạn khôn lớn mới là gia đình.', 'neutral'); H.fx(l, { hap: 1 }); } }
    ]
  });
  T('mc_tim_bo_me', function (l, a) { var o = O(l); return !!o && o.unknown && !o.searched && a >= 20 && a <= 45; }, 0.15, 5, 1);

  // người lớn lên không có bố mẹ: giỗ bố mẹ, ngày cưới không có người đưa dâu
  E.EVENTS.push({ c: function (l, a) { var o = O(l); return !!o && !o.adopted && !o.unknown && a >= 18 && isVN(l) && !l.abroad; }, p: 0.05, cd: 8, run: function (l, a, r, log) {
    log(pick(r, ['Ngày giỗ bố mẹ, bạn thắp hương trước tấm ảnh duy nhất còn giữ được. Bạn đã lớn hơn tuổi bố mẹ lúc ấy.', 'Bạn về thăm ' + (O(l).kind === 'ong_ba' ? 'mộ ông bà và bố mẹ' : 'cô chú') + ', mang theo ít quà. Cô bảo: "Bố mẹ con mà thấy con bây giờ thì mừng lắm."']), 'neutral');
  } });
  E.EVENTS.push({ c: function (l, a) { var o = O(l); return !!o && !o.adopted && (o.kind === 'mai_am' || o.kind === 'chua') && a >= 25 && l.money > l.base * 2; }, p: 0.06, cd: 10, run: function (l, a, r, log) {
    var v = l.base * 0.04; H.cash(l, -v, O(l).kind === 'chua' ? 'Công đức nhà chùa nơi mình lớn lên' : 'Ủng hộ mái ấm nơi mình lớn lên');
    log(O(l).kind === 'chua' ? 'Bạn về chùa thăm sư cô, công đức ' + H.money(l, v) + '. Sân chùa vẫn y như ngày bạn quét lá.' : 'Bạn quay về mái ấm cũ, mang theo quà và ' + H.money(l, v) + ' cho các em. Lũ trẻ nhìn bạn như ngày xưa bạn nhìn các anh chị.', 'good');
    H.fx(l, { hap: 4, karma: 3 }); l.flags.orphanGaveBack = true;
  } });

  if (E.addAchievements) E.addAchievements([
    ['tay_trang', '🌱', 'Tay trắng dựng nghiệp', 'Xuất thân mồ côi, cuối đời có tài sản từ 30 lần thu nhập cơ sở', function (l) { return !!O(l) && !O(l).adopted && E.netWorth && E.netWorth(l) >= l.base * 30; }],
    ['co_nha', '🏡', 'Có một mái nhà', 'Lớn lên ở mái ấm hoặc nhà chùa, được một gia đình nhận làm con nuôi', function (l) { var o = O(l); return !!o && o.adopted != null; }],
    ['nguon_coi', '🧬', 'Tìm về nguồn cội', 'Tìm lại được bố mẹ ruột', function (l) { var o = O(l); return !!o && o.found != null; }],
    ['uong_nuoc', '🙏', 'Uống nước nhớ nguồn', 'Quay về giúp đỡ mái ấm / ngôi chùa nơi mình lớn lên', function (l) { return !!l.flags.orphanGaveBack; }]
  ]);
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
/* ===== js/life89.js ===== */
/* Một Đời — v7.2.0 (góp ý của người chơi):
   · người yêu / bạn đời qua đời thì mọi nơi đều biết người đó đã mất: bạn thân (nếu người yêu vốn là bạn thân) không còn hẹn đi chơi,
     không hỏi vay tiền; không còn "liên lạc lại với người cũ" hay tái hôn với người đã mất. Ngược lại, người bạn thân đang là
     người yêu mà qua đời thì bạn cũng mất người yêu. Bản lưu cũ được dọn lại theo nhật ký.
   · nghề "nở sớm": cầu thủ, vận động viên các môn đỉnh cao sớm và tuyển thủ esports có năng khiếu được học viện / câu lạc bộ /
     đội trẻ mời ký hợp đồng từ 15–17 tuổi; học văn hóa hệ giáo dục thường xuyên ngay trong học viện. Có thể chọn học xong cấp ba
     rồi mới lên đội. */
(function (G) {
  'use strict';
  var U = G.U, E = G.E, H = E.H, SC = E.SC, isVN = H.isVN;
  function pick(r, a) { return U.pick(r, a); }
  function free(l) { return l.alive && !(l.jailUntil != null && l.age < l.jailUntil) && !(l.abroad && l.abroad.trapped); }
  function T(id, when, p, cd, max) { E.TRIG.push({ id: id, when: function (l, a) { return free(l) && when(l, a); }, p: p, cd: cd || 2, max: max || 1 }); }

  // ===================================================================
  // 1. NGƯỜI ĐÃ MẤT THÌ MẤT Ở MỌI NƠI
  // ===================================================================
  function dead(l) { return l.flags.deadPartners || (l.flags.deadPartners = []); }
  function people(l) { return [l.bff].concat(l.friends || []).filter(function (f) { return f && f.name; }); }
  function sameEx(x, d) { return x.name === d.n; } // so theo tên: ngày bắt đầu có thể đổi khi cưới
  E.isDeadPartner = function (l, p) { return !!p && dead(l).some(function (d) { return sameEx({ name: p.name, since: p.since }, d); }); };
  // gọi khi người yêu / bạn đời qua đời
  E.personDied = function (l, p, a) {
    if (!p || !p.name) return;
    p.alive = false; if (p.died == null) p.died = a;
    if (!E.isDeadPartner(l, p)) dead(l).push({ n: p.name, s: p.since, a: a });
    people(l).forEach(function (f) { if (f.name === p.name && (!f.sex || !p.sex || f.sex === p.sex)) { f.alive = false; f.died = a; f.lover = false; } });
    var L = l.flags.exList; if (L) l.flags.exList = L.filter(function (x) { return !sameEx(x, { n: p.name, s: p.since }); });
  };
  E.partnerGone = function (l, a, log, why) { if (l.partner) partnerGone(l, l.partner, a, log, why); };
  function partnerGone(l, p, a, log, why) {
    l.partner = null; p.alive = false; p.died = a;
    if (p.status !== 'dating') l.widowed = (l.widowed || 0) + 1; else l.flags.lateDating = p.name;
    if (log && why) log(why, 'bad');
    E.personDied(l, p, a);
  }
  E.HOOKS.year.unshift(function (l, r, log, a) {
    if (!l.alive) return;
    var F = l.flags;
    // bản lưu cũ: người yêu đã mất nhưng vẫn nằm trong danh sách người cũ / bạn thân còn sống
    if (!F.deathSync72) {
      F.deathSync72 = true;
      (l.log || []).forEach(function (e) {
        var m = /^(?:Người yêu|Vợ|Chồng|Người bạn đời|Bạn trai|Bạn gái|Người ấy) (.+?) qua đời ở tuổi/.exec(e.t || '');
        if (m && !(l.partner && l.partner.name === m[1] && l.partner.alive !== false)) { if (!dead(l).some(function (d) { return d.n === m[1]; })) dead(l).push({ n: m[1], s: null, a: e.a }); }
      });
      dead(l).forEach(function (d) {
        people(l).forEach(function (f) { if (f.name === d.n && f.alive !== false && (f.lover || (l.log || []).some(function (e) { return (e.t || '').indexOf(f.name) >= 0 && /Bạn thân thành người yêu/.test(e.t); }))) { f.alive = false; f.died = d.a; f.lover = false; } });
        if (F.exList) F.exList = F.exList.filter(function (x) { return x.name !== d.n; });
      });
    }
    loverFriendGone(l, a);
  });
  // bạn thân (từng là người yêu cũ) qua đời thì không còn trong danh sách "người cũ"
  E.HOOKS.year.unshift(function (l) {
    var L = l.flags && l.flags.exList; if (!L || !L.length) return;
    var gone = people(l).filter(function (f) { return f.alive === false; }).map(function (f) { return f.name; });
    if (gone.length) l.flags.exList = L.filter(function (x) { return gone.indexOf(x.name) < 0; });
  });
  // tên người lạ không trùng tên người trong nhà, bạn bè, người cũ (trước đây có lúc bạn mới trùng tên con gái vừa sinh)
  var stranger = H.stranger;
  function known(l) {
    var a = [l.name], f = l.fam || {};
    [f.mName, f.fName].forEach(function (n) { if (n) a.push(n); });
    (l.kids || []).forEach(function (k) { a.push(k.name); });
    (l.sibList || []).forEach(function (s) { if (s && (s.n || s.name)) a.push(s.n || s.name); });
    if (l.partner) a.push(l.partner.name);
    people(l).forEach(function (x) { a.push(x.name); });
    ((l.flags && l.flags.exList) || []).forEach(function (x) { a.push(x.name); });
    ((l.flags && l.flags.deadPartners) || []).forEach(function (x) { a.push(x.n); }); // v7.4.1: người yêu / bạn đời đã mất
    return a;
  }
  H.stranger = function (l, r, sex) {
    var n = stranger.apply(this, arguments); if (!l || !l.kids) return n;
    var K = known(l);
    for (var i = 0; i < 6 && K.indexOf(n) >= 0; i++) n = stranger.call(this, l, r, sex);
    return n;
  };
  // bạn thân đang là người yêu / bạn đời mà qua đời (tuổi già, tai nạn…) thì cũng là mất người yêu
  function loverFriendGone(l, a) {
    var p = l.partner; if (!l.alive || !p) return;
    if (p.alive !== false && people(l).some(function (f) { return f.name === p.name && f.alive === false; })) {
      partnerGone(l, p, a, null, null);
      H.mem(l, 'Ngày mất ' + p.name + ' — vừa là bạn thân, vừa là người thương.', 7);
    } else if (p.alive === false) partnerGone(l, p, a, null, null);
  }
  E.HOOKS.year.unshift(function (l, r, log, a) { loverFriendGone(l, a); });

  // ===================================================================
  // 2. NGHỀ NỞ SỚM: KÝ HỢP ĐỒNG TỪ 15–17 TUỔI
  // ===================================================================
  // đội trẻ / hệ đào tạo trẻ esports nhận tuyển thủ từ 16 tuổi (trước đây khóa đến 18)
  if (E.CAR.tuyen_thu_es) E.CAR.tuyen_thu_es.minAge = 16;
  var EARLY_SPORT = /^(bóng đá|bơi lội|thể dục dụng cụ|điền kinh|cầu lông|bóng bàn|quần vợt|bóng rổ|bóng chuyền)$/;
  function kindOf(l) { if (l.talent === 'game') return 'es'; if (l.talent === 'thể thao' && EARLY_SPORT.test(l.talentSub || '')) return 'vdv'; return null; }
  function ready(l) {
    var k = kindOf(l); if (!k || l.job || (k === 'es' && l.age < 16)) return false;
    var s = l.skill || 0, bonus = l.flags.vdNkOk ? 12 : 0;
    return s + bonus >= (k === 'es' ? 45 : 42) && l.st.hea >= 50;
  }
  function who(l) { var f = l.fam || {}; return f.mAlive && f.fAlive && !f.noDad ? 'bố mẹ' : f.mAlive ? 'mẹ' : f.fAlive && !f.noDad ? 'bố' : (E.orphanCarer && E.orphanCarer(l)) || 'người giám hộ'; }
  function club(l, r) {
    if (kindOf(l) === 'es') return pick(r, isVN(l) ? ['Team Flash', 'Saigon Phantom', 'GAM Esports', 'Team Secret', 'Box Gaming', 'Cerberus Esports', 'Vikings Esports'] : ['T1', 'G2 Esports', 'Team Liquid', 'Fnatic', 'Paper Rex', 'Team Vitality']);
    var S = E.sportInfo ? E.sportInfo(l) : null;
    if (l.talentSub === 'bóng đá') return pick(r, isVN(l) ? ['Học viện PVF', 'Học viện HAGL – JMG', 'Trung tâm đào tạo trẻ Hà Nội FC', 'Học viện Viettel', 'lò đào tạo Sông Lam Nghệ An'] : ['học viện bóng đá của một câu lạc bộ hạng nhất', 'học viện La Masia của Barcelona', 'học viện bóng đá Ajax', 'học viện của một câu lạc bộ Premier League']);
    return S && S.club ? pick(r, S.club) : (isVN(l) ? 'Trung tâm huấn luyện thể thao quốc gia' : 'trung tâm huấn luyện thể thao quốc gia');
  }
  SC('ky_som', {
    title: function (l) { return kindOf(l) === 'es' ? 'Đội esports mời vào đội trẻ' : 'Lời mời ký hợp đồng trẻ'; },
    prep: function (l, r) { return { c: club(l, r) }; },
    valid: function (l) { return !!l.school && l.age >= 15 && l.age <= 17 && ready(l) && !l.flags.earlyPro; },
    text: function (l, d) {
      var k = kindOf(l);
      if (k === 'es') return d.c + ' theo dõi bạn leo hạng trên máy chủ ' + (l.game || 'game') + ' cả mùa. Họ mời bạn vào đội trẻ (academy): ở gaming house, có lương, tập theo giáo án, học văn hóa hệ giáo dục thường xuyên. ' + U.cap(who(l)) + ' phải ký thay vì bạn chưa đủ 18 tuổi.';
      return 'Tuyển trạch viên của ' + d.c + ' theo dõi bạn ở giải trẻ ' + (l.talentSub || 'thể thao') + '. Họ mời bạn ký hợp đồng đào tạo: bao ăn ở, có trợ cấp, tập chuyên nghiệp, học văn hóa ngay trong học viện. ' + U.cap(who(l)) + ' phải ký thay vì bạn chưa đủ 18 tuổi.';
    },
    opts: [
      { k: 'ky', l: 'Ký hợp đồng, theo nghiệp ngay', h: 'Tập chuyên nghiệp từ sớm, học văn hóa hệ giáo dục thường xuyên', ai: { w: 1.4, amb: 1 }, run: function (l, r, log, d) {
        var k = kindOf(l), id = k === 'es' ? 'tuyen_thu_es' : 'vdv';
        l.flags.earlyPro = { at: l.age, club: d.c, kind: k, gdtx: l.age + Math.max(1, 18 - l.age) };
        l.edu = Math.max(l.edu || 0, 2); l.indep = true;
        E.startJob(l, id, r, function () { }, true);
        l.skill = Math.min(100, (l.skill || 40) + 6);
        log((k === 'es' ? 'Ký hợp đồng đội trẻ ' + d.c + ' năm ' + l.age + ' tuổi. Bạn xách balo lên gaming house, mỗi ngày tập 10 tiếng, buổi tối học văn hóa trực tuyến.' : 'Ký hợp đồng đào tạo với ' + d.c + ' năm ' + l.age + ' tuổi. Sáng tập, chiều tập, tối học văn hóa ở lớp của học viện.') + ' ' + U.cap(who(l)) + ' tiễn bạn đi, vừa mừng vừa lo.', 'big');
        H.fx(l, { hap: 6 }); H.mem(l, k === 'es' ? 'Ngày đầu tiên ở gaming house, mới ' + l.age + ' tuổi.' : 'Ngày đặt chân vào ' + d.c + ', mới ' + l.age + ' tuổi.', 6);
      } },
      { k: 'cho', l: 'Học xong cấp ba rồi mới lên đội', h: 'Giữ con đường học hành; đội vẫn để ngỏ lời mời', ai: { w: 1, smart: 1 }, run: function (l, r, log, d) { l.flags.earlyPro = { wait: true, club: d.c, kind: kindOf(l) }; log('Bạn xin học hết cấp ba. ' + d.c + ' hẹn: "Tốt nghiệp xong cứ liên hệ, cửa vẫn mở."', 'neutral'); } },
      { k: 'thoi', l: 'Từ chối, giữ đam mê làm sở thích', ai: { w: 0.4 }, run: function (l, r, log, d) { l.flags.earlyPro = { no: true }; log('Bạn từ chối lời mời của ' + d.c + '. Đam mê vẫn còn, nhưng bạn chọn một con đường khác.', 'neutral'); } }
    ]
  });
  T('ky_som', function (l, a) { return a >= 15 && a <= 17 && !!l.school && ready(l) && !l.flags.earlyPro; }, 0.45, 1, 1);
  E.MAJOR.ky_som = 1;
  E.ACT.push({ id: 'thu_viec_doi_tre', g: 'Học tập', l: 'Đi thử việc ở học viện / đội trẻ', min: 15, sc: 'ky_som', avail: function (l) { if (!kindOf(l)) return 'Cần năng khiếu thể thao hoặc chơi game'; if (l.age > 17) return 'Chỉ dành cho tuổi 15–17'; if (!l.school) return 'Đang không đi học'; if (l.flags.earlyPro) return 'Đã có lời mời từ trước'; return ready(l) ? true : 'Tay nghề chưa đủ để được chú ý'; }, ai: { w: 0.05 } });
  // học xong cấp ba thì đội giữ lời hẹn
  SC('ky_som_hen', {
    title: 'Đội vẫn giữ lời hẹn', prep: function (l) { var x = l.flags.earlyPro || {}; return { c: x.club || 'Đội cũ' }; },
    valid: function (l) { var x = l.flags.earlyPro; return !!(x && x.wait && !x.done) && !l.school && !(l.job && /^(vdv|tuyen_thu_es)$/.test(E.resolveJob(l.job.id))); },
    text: function (l, d) { return 'Vừa tốt nghiệp, ' + d.c + ' gọi lại: "Suất của em vẫn còn, lên đội chính thức không?"'; },
    opts: [
      { k: 'len', l: 'Lên đội', ai: { w: 1.4 }, run: function (l, r, log, d) { var x = l.flags.earlyPro; x.done = true; E.startJob(l, x.kind === 'es' ? 'tuyen_thu_es' : 'vdv', r, function () { }, true); log('Bạn ký hợp đồng với ' + d.c + '. Con đường đã chờ bạn ba năm.', 'big'); H.fx(l, { hap: 5 }); } },
      { k: 'thoi', l: 'Cảm ơn, mình đã chọn hướng khác', ai: { w: 0.5 }, run: function (l, r, log, d) { l.flags.earlyPro.done = true; log('Bạn cảm ơn ' + d.c + ' và chọn một con đường khác.', 'neutral'); } }
    ]
  });
  T('ky_som_hen', function (l, a) { var x = l.flags.earlyPro; return !!(x && x.wait && !x.done) && a >= 17 && a <= 20 && !l.school && !!kindOf(l); }, 0.8, 1, 1);
  // học văn hóa trong học viện: đủ tuổi thì hoàn thành chương trình giáo dục thường xuyên cấp trung học phổ thông
  E.HOOKS.year.unshift(function (l, r, log, a) {
    var x = l.flags.earlyPro; if (!x || x.wait || x.no || !x.gdtx || x.gdtxDone || a < x.gdtx || !l.alive) return;
    x.gdtxDone = true;
    if (l.job && /^(vdv|tuyen_thu_es)$/.test(E.resolveJob(l.job.id)) && (l.edu || 0) < 3 && r() < 0.8) { l.edu = 3; log('Vừa tập vừa học, bạn hoàn thành chương trình trung học phổ thông hệ giáo dục thường xuyên.', 'good'); }
    else if ((l.edu || 0) < 3) log('Lịch tập dày đặc, bạn bỏ dở chương trình văn hóa, chỉ có bằng trung học cơ sở.', 'neutral');
  });
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
/* ===== js/life90.js ===== */
/* Một Đời — v7.2.0: tính cách bố mẹ và drama gia đình
   · bố và mẹ mỗi người một tính cách (16 kiểu): nghiêm khắc, chiều con, bao bọc, gia trưởng, hay so sánh "con nhà người ta",
     kỳ vọng cao, cởi mở, nóng tính, tằn tiện, sĩ diện, tin bói toán, cuồng công việc, hài hước, hay lo, thiên vị, ấm áp.
     Tính cách ảnh hưởng tuổi thơ (chỉ số, lời kể) và sinh ra tình huống riêng: so sánh với con nhà người ta, ép chọn ngành,
     cấm cưới vì "không hợp tuổi", đám cưới phải to cho bằng họ hàng, thiên vị trong chia tài sản
   · drama gia đình ở mọi hoàn cảnh, không chỉ nhà giàu:
     - nhà giàu: anh chị em tranh giành tài sản khi bố mẹ còn sống, kiện tụng chia di sản, tranh ghế chủ tịch tập đoàn của gia đình
     - nhà bình thường / khó khăn: tranh mảnh đất hương hỏa, đùn đẩy việc nuôi bố mẹ già, anh chị em nợ nần làm khổ cả nhà,
       họ hàng mượn sổ đỏ đi thế chấp, bố mẹ cãi nhau đòi ly thân, con riêng xuất hiện ở đám tang, di chúc thiên vị */
(function (G) {
  'use strict';
  var U = G.U, E = G.E, H = E.H, SC = E.SC, isVN = H.isVN;
  function pick(r, a) { return U.pick(r, a); }
  function ch(r, p) { return r() < p; }
  function fx(l, o) { H.fx(l, o); }
  function mo(l, v) { return H.money(l, v); }
  function stress(l, x) { if (l.mind) l.mind.stress = U.clamp(l.mind.stress + x, 0, 100); }
  function free(l) { return l.alive && !(l.jailUntil != null && l.age < l.jailUntil) && !(l.abroad && l.abroad.trapped) && !(l.flags.military && l.age < l.flags.military); }
  function T(id, when, p, cd, max) { E.TRIG.push({ id: id, when: function (l, a) { return free(l) && when(l, a); }, p: p, cd: cd || 4, max: max || 1 }); }
  function EV(c, p, cd, run) { E.EVENTS.push({ c: c, p: p, cd: cd, run: run }); }
  function sibs(l) { return H.sibs ? H.sibs(l) : []; }
  function call(l, s) { return H.sibCall ? H.sibCall(l, s) : 'anh chị'; }
  function adultSibs(l) { return sibs(l).filter(function (s) { return E.sibAge(l, s) >= 20; }); }
  function mom(l) { return !!l.fam.mAlive; }
  function dad(l) { return !!l.fam.fAlive && !l.fam.noDad; }
  function both(l) { return mom(l) && dad(l); }
  function anyParent(l) { return mom(l) || dad(l); }
  function pAge(l) { var f = l.fam, a = []; if (mom(l)) a.push(f.mAge + l.age); if (dad(l)) a.push(f.fAge + l.age); return a.length ? Math.max.apply(null, a) : 0; }
  function estate(l) { var q = l.fam.q || 3; return H.housePrice(l) * [0, 0.35, 0.6, 1, 1.8, 4][q] * (l.fam.elite ? 6 : 1); }

  // ===================================================================
  // 1. TÍNH CÁCH BỐ MẸ
  // ===================================================================
  var TR = {
    nghiem: { n: 'nghiêm khắc', d: 'đặt nhiều quy tắc, giờ nào việc nấy', w: 3, st: { kno: 2, hap: -2 } },
    chieu: { n: 'chiều con', d: 'con muốn gì cũng chiều', w: 2, st: { hap: 3, kno: -1 } },
    bao_boc: { n: 'bao bọc', d: 'lo cho con từng li từng tí, ít cho con tự làm', w: 2, st: { soc: -2 } },
    gia_truong: { n: 'gia trưởng', d: 'chuyện lớn nhỏ trong nhà đều một mình quyết', w: 2, st: { hap: -3 }, m: 0.4 },
    so_sanh: { n: 'hay so sánh', d: 'hay nhắc "con nhà người ta"', w: 2, st: { hap: -2, kno: 1 } },
    ky_vong: { n: 'kỳ vọng cao', d: 'muốn con học giỏi, đỗ trường top', w: 3, st: { kno: 3, hap: -2 } },
    coi_mo: { n: 'cởi mở', d: 'lắng nghe, để con tự chọn đường', w: 2.5, st: { hap: 3, soc: 2 } },
    nong_tinh: { n: 'nóng tính', d: 'dễ nổi nóng, nói nặng lời', w: 2, st: { hap: -4 } },
    tan_tien: { n: 'tằn tiện', d: 'tiêu đồng nào chắc đồng ấy', w: 2.5, st: {} },
    si_dien: { n: 'sĩ diện', d: 'coi trọng mặt mũi với họ hàng, làng xóm', w: 2, st: {} },
    tam_linh: { n: 'tin bói toán', d: 'việc gì cũng xem ngày, xem tuổi', w: 1.5, st: {} },
    cuong_viec: { n: 'cuồng công việc', d: 'đi sớm về khuya, ít ở nhà', w: 2, st: { hap: -2, soc: -1 } },
    hai_huoc: { n: 'hài hước', d: 'bữa cơm lúc nào cũng có tiếng cười', w: 2, st: { hap: 4 } },
    hay_lo: { n: 'hay lo', d: 'lo xa đủ chuyện, gọi điện hỏi thăm liên tục', w: 2, st: { soc: -1 } },
    thien_vi: { n: 'thiên vị', d: 'thương một đứa con hơn những đứa khác', w: 1.2, st: {} },
    am_ap: { n: 'ấm áp', d: 'hay ôm con, nói lời yêu thương', w: 2.5, st: { hap: 4, soc: 1 } }
  };
  E.PARENT_TRAITS = TR;
  function wk(h) { var tot = 0, k; for (k in TR) tot += TR[k].w; var x = U.rand(h) * tot; for (k in TR) { x -= TR[k].w; if (x <= 0) return k; } return 'am_ap'; }
  function tr(l, who) { var f = l.fam || {}; return who === 'm' ? f.mTrait : f.fTrait; }
  function has(l, k) { return (mom(l) && l.fam.mTrait === k) || (dad(l) && l.fam.fTrait === k); }
  function whoHas(l, k) { return mom(l) && l.fam.mTrait === k ? 'mẹ' : dad(l) && l.fam.fTrait === k ? 'bố' : null; }
  E.parentTraitText = function (l, who) { var k = tr(l, who), t = k && TR[k]; return t ? t.n + ' — ' + t.d : ''; };
  function assign(l) {
    var f = l.fam; if (f.mTrait && f.fTrait) return;
    var h = { rs: (l.rs ^ 0x6a7e3c1) | 0 };
    f.mTrait = f.mTrait || wk(h); f.fTrait = f.fTrait || wk(h);
    for (var i = 0; i < 3 && f.fTrait === f.mTrait; i++) f.fTrait = wk(h);
    if (f.elite && U.rand(h) < 0.5) f.fTrait = U.rand(h) < 0.5 ? 'gia_truong' : 'ky_vong';
    if (f.vice && dad(l) && U.rand(h) < 0.5) f.fTrait = 'nong_tinh';
    if (f.thienVi == null) f.thienVi = U.rand(h) < 0.5; // người thiên vị: thương bạn hơn (true) hay thương anh chị em hơn
  }
  var createLife = E.createLife;
  E.createLife = function (opts) {
    var l = createLife.apply(this, arguments); assign(l);
    [['m', mom(l)], ['f', dad(l)]].forEach(function (x) { if (!x[1]) return; var st = TR[tr(l, x[0])].st; for (var k in st) if (l.st[k] != null) l.st[k] = U.clamp(l.st[k] + st[k], 5, 100); });
    return l;
  };
  // bối cảnh xuất phát nhắc tính cách bố mẹ
  var bc = E.birthContext;
  if (bc) E.birthContext = function (l) {
    var x = bc.apply(this, arguments); if (!x || !l.fam || l.fam.orphan && l.fam.orphan.adopted == null) return x;
    assign(l);
    var s = both(l) ? (l.fam.mTrait === l.fam.fTrait ? 'bố mẹ đều ' + TR[l.fam.mTrait].n : 'bố ' + TR[l.fam.fTrait].n + ', mẹ ' + TR[l.fam.mTrait].n) : mom(l) ? 'mẹ ' + TR[l.fam.mTrait].n : dad(l) ? 'bố ' + TR[l.fam.fTrait].n : '';
    if (s && x.text && x.text.indexOf(s) < 0) {
      // thay câu nuôi dạy chung chung bằng tính cách thật của bố mẹ (tránh mâu thuẫn kiểu "ít so sánh" với bố mẹ "hay so sánh")
      var GEN = /(bố mẹ|mẹ|bố) (coi trọng thành tích|ưu tiên sức khỏe|đặt nhiều quy tắc|khuyến khích tự lập|thường bận công việc|coi trọng nề nếp|quan tâm nhưng hay lo xa|sẵn sàng lắng nghe)[^;.]*/;
      x.text = GEN.test(x.text) ? x.text.replace(GEN, s) : x.text.replace(/\.\s*$/, '') + '; ' + s;
      if (!/\.$/.test(x.text)) x.text += '.';
    }
    return x;
  };
  // tuổi thơ theo tính cách
  var KID = {
    nghiem: ['{P} đặt giờ giới nghiêm 9 giờ tối, trễ một phút là bị phạt quét nhà.', '{P} kiểm tra vở bài tập mỗi tối, chữ xấu là phải viết lại cả trang.'],
    chieu: ['Bạn ăn vạ ở siêu thị, {p} lại mua cho món đồ chơi thứ ba trong tháng.', '{P} lén cho bạn tiền tiêu vặt, dặn đừng nói với ai.'],
    bao_boc: ['Lớn tướng rồi, {p} vẫn không cho bạn ra ngõ chơi một mình.', '{P} không cho bạn đi cắm trại với lớp vì sợ có chuyện.'],
    gia_truong: ['Bữa cơm, {p} nói gì cả nhà phải nghe, không ai dám cãi.', '{P} tự quyết bạn phải học thêm môn gì, không hỏi ý bạn.'],
    so_sanh: ['"Con nhà bác Hùng được học sinh giỏi cấp tỉnh kìa", {p} nhắc lần thứ mười trong tuần.', 'Bạn được 8 điểm, {p} hỏi: "Thế bạn kia được mấy?"'],
    ky_vong: ['{P} dán lịch học kín cả tuần lên tường, kể cả Chủ nhật.', '{P} đăng ký cho bạn ba lớp học thêm cùng lúc.'],
    coi_mo: ['{P} ngồi nghe bạn kể chuyện trường lớp cả buổi tối, không phán xét câu nào.', 'Bạn muốn học vẽ thay vì học thêm toán, {p} gật đầu: "Con thích thì cứ thử."'],
    nong_tinh: ['Làm vỡ cái bát, {p} quát to đến mức hàng xóm phải sang hỏi.', '{P} nổi nóng vì bạn về muộn, ném cả cặp sách ra sân.'],
    tan_tien: ['Áo đồng phục {p} mua rộng hai cỡ, "để mặc được mấy năm".', '{P} tắt điện liên tục: "Tiền điện tháng này lại tăng rồi đấy!"'],
    si_dien: ['Họ hàng đến chơi, {p} bắt bạn đọc thuộc bài thơ cho cả nhà nghe.', '{P} khoe với cả xóm bạn được giấy khen, dù chỉ là giấy khen chuyên cần.'],
    tam_linh: ['{P} đi xem bói về, bảo năm nay bạn "phạm sao", cấm đi chơi xa.', 'Trước kỳ thi, {p} dẫn bạn lên chùa xin lộc, đeo cho bạn cái bùa.'],
    cuong_viec: ['Sinh nhật bạn, {p} lại đi công tác, gọi video chúc mừng lúc đã khuya.', 'Cả tuần bạn chỉ gặp {p} vào bữa sáng Chủ nhật.'],
    hai_huoc: ['{P} giả giọng nhân vật hoạt hình, cả nhà cười đau bụng.', 'Bạn bị điểm kém, {p} pha trò một câu khiến bạn bớt sợ hẳn.'],
    hay_lo: ['Đi học về muộn mười phút, {p} đã gọi bảy cuộc điện thoại.', '{P} nhét vào cặp bạn đủ thứ: áo mưa, thuốc, cả lọ dầu gió.'],
    thien_vi: ['Miếng đùi gà ngon nhất bao giờ {p} cũng gắp cho {fav}.', 'Quần áo mới bao giờ cũng đến tay {fav} trước.'],
    am_ap: ['Tối nào {p} cũng xoa đầu bạn trước khi đi ngủ.', '{P} ôm bạn thật chặt khi bạn khóc vì bị bạn bè trêu.']
  };
  var KIDFX = { nghiem: { kno: 1 }, chieu: { hap: 1 }, bao_boc: { soc: -1 }, gia_truong: { hap: -1 }, so_sanh: { hap: -2 }, ky_vong: { kno: 1, hap: -1 }, coi_mo: { hap: 1, soc: 1 }, nong_tinh: { hap: -2 }, hai_huoc: { hap: 2 }, am_ap: { hap: 2 }, thien_vi: { hap: -1 } };
  EV(function (l, a) { return a >= 4 && a <= 16 && anyParent(l) && !(l.fam.orphan && l.fam.orphan.adopted == null); }, 0.22, 3, function (l, a, r, log) {
    assign(l);
    var w = both(l) ? pick(r, ['m', 'f']) : mom(l) ? 'm' : 'f', k = tr(l, w), lines = KID[k]; if (!lines) return;
    if (k === 'thien_vi' && !sibs(l).length) return;
    if (!l.school) lines = lines.filter(function (x) { return !/trường|học|điểm|vở|thi|lớp|phụ huynh/.test(x); }); if (!lines.length) return;
    var me = l.fam.thienVi, fav = me ? 'bạn' : (sibs(l)[0] ? call(l, sibs(l)[0]) : 'đứa em');
    var p = w === 'm' ? 'mẹ' : 'bố', t = pick(r, lines).replace(/\{P\}/g, U.cap(p)).replace(/\{p\}/g, p).replace(/\{fav\}/g, fav);
    if (k === 'thien_vi' && me) t += ' Anh chị em nhìn bạn, không nói gì.';
    log(t, 'neutral');
    if (KIDFX[k]) fx(l, KIDFX[k]);
    if (k === 'nong_tinh' || k === 'so_sanh') stress(l, 3);
  });

  // con nhà người ta
  SC('ps_con_nha_nguoi_ta', {
    title: '"Con nhà người ta"', prep: function (l, r) { return { w: whoHas(l, 'so_sanh') || 'bố mẹ', x: pick(r, ['đỗ trường chuyên', 'được học bổng du học', 'vừa mua nhà ở thành phố', 'làm ngân hàng lương mấy chục triệu']) }; },
    valid: function (l) { return !!whoHas(l, 'so_sanh'); },
    text: function (l, d) { return 'Bữa cơm, ' + d.w + ' lại nhắc chuyện con bà hàng xóm ' + d.x + '. "Sao con không được như nó?"'; },
    opts: [
      { k: 'co_gang', l: 'Im lặng, tự nhủ sẽ cố gắng hơn', ai: { w: 1.2, amb: 1 }, run: function (l, r, log, d) { fx(l, { kno: 2, hap: -2 }); stress(l, 5); log('Bạn im lặng ăn hết bát cơm, tối đó ngồi học đến khuya. Câu nói ấy cứ lởn vởn trong đầu.', 'neutral'); } },
      { k: 'cai', l: 'Cãi lại: "Con là con, không phải nó"', ai: { w: 0.6, risk: 1 }, run: function (l, r, log, d) { if (ch(r, 0.4)) { log('Bạn nói thẳng. ' + U.cap(d.w) + ' sững người, rồi lần đầu tiên xin lỗi bạn.', 'good'); fx(l, { hap: 3 }); l.fam.cmpStop = true; } else { log('Bạn cãi lại, ' + d.w + ' giận dỗi cả tuần, cả nhà căng như dây đàn.', 'bad'); fx(l, { hap: -4 }); stress(l, 6); } } },
      { k: 'ke', l: 'Tâm sự thật lòng là mình đang áp lực', ai: { w: 0.8, soc: 1 }, run: function (l, r, log, d) { log('Bạn kể mình mệt mỏi thế nào mỗi lần bị so sánh. ' + U.cap(d.w) + ' im lặng hồi lâu: "Bố mẹ chỉ muốn con hơn bố mẹ thôi."', 'neutral'); fx(l, { hap: 1 }); stress(l, -4); } }
    ]
  });
  T('ps_con_nha_nguoi_ta', function (l, a) { return a >= 10 && a <= 25 && !!whoHas(l, 'so_sanh') && !l.fam.cmpStop; }, 0.2, 3, 2);
  // gia trưởng / kỳ vọng cao: ép chọn ngành
  SC('ps_ep_nganh', {
    title: 'Ai chọn ngành cho bạn?', prep: function (l, r) { return { w: whoHas(l, 'gia_truong') || whoHas(l, 'ky_vong') || 'bố mẹ', n: pick(r, isVN(l) ? ['Y đa khoa', 'Công an', 'Sư phạm', 'Ngân hàng', 'Luật'] : ['Y khoa', 'Luật', 'Kỹ thuật', 'Tài chính']) }; },
    valid: function (l) { return !!(whoHas(l, 'gia_truong') || whoHas(l, 'ky_vong')) && !!l.school; },
    text: function (l, d) { return 'Chuẩn bị làm hồ sơ thi đại học, ' + d.w + ' tuyên bố: "Con phải học ' + d.n + '. Bố mẹ đã tính hết rồi."'; },
    opts: [
      { k: 'nghe', l: 'Nghe lời, học ngành ' + 'bố mẹ chọn', ai: { w: 1 }, run: function (l, r, log, d) { l.flags.forcedMajor = d.n; log('Bạn nghe lời, ghi nguyện vọng ' + d.n + '. Giấc mơ riêng cất vào ngăn kéo.', 'neutral'); fx(l, { hap: -3 }); H.mem(l, 'Năm mười tám tuổi, bạn ghi nguyện vọng ' + d.n + ' theo ý ' + d.w + '.', 3); } },
      { k: 'theo_y', l: 'Kiên quyết theo đam mê của mình', ai: { w: 0.8, amb: 1, risk: 0.5 }, run: function (l, r, log, d) { if (ch(r, 0.5)) { log('Bạn thuyết phục được ' + d.w + ' sau nhiều đêm nói chuyện. "Con tự chịu trách nhiệm nhé."', 'good'); fx(l, { hap: 4 }); } else { log('Bạn tự nộp hồ sơ ngành mình thích. ' + U.cap(d.w) + ' không nói chuyện với bạn suốt mấy tháng.', 'bad'); fx(l, { hap: -2 }); stress(l, 8); l.fam.coldWar = l.age; } } },
      { k: 'thoa_hiep', l: 'Thỏa hiệp: học song song hai ngành', ai: { w: 0.5, smart: 1 }, run: function (l, r, log, d) { log('Bạn đề nghị học ngành mình thích, học thêm văn bằng hai theo ý ' + d.w + '. Cả nhà chấp nhận.', 'neutral'); fx(l, { kno: 2, hap: -1 }); stress(l, 4); } }
    ]
  });
  T('ps_ep_nganh', function (l, a) { return a === 17 && !!l.school && !!(whoHas(l, 'gia_truong') || whoHas(l, 'ky_vong')); }, 0.6, 1, 1);
  // tin bói toán: cấm cưới vì không hợp tuổi
  SC('ps_khong_hop_tuoi', {
    title: '"Hai đứa không hợp tuổi"', prep: function (l) { return { w: whoHas(l, 'tam_linh') || 'bố mẹ', n: l.partner ? l.partner.name : '' }; },
    valid: function (l) { return isVN(l) && !!whoHas(l, 'tam_linh') && !!l.partner && l.partner.status === 'dating'; },
    text: function (l, d) { return U.cap(d.w) + ' đi xem bói về, mặt nặng như chì: "Thầy bảo tuổi con với ' + d.n + ' là tứ hành xung, cưới về thì lục đục, khắc con cái."'; },
    opts: [
      { k: 'giai_han', l: 'Chiều bố mẹ, đi cúng giải hạn rồi cưới', ai: { w: 1 }, run: function (l, r, log, d) { var v = l.base * 0.04; H.cash(l, -v, 'Lễ giải hạn trước khi cưới'); log('Hai đứa theo ' + d.w + ' đi làm lễ "giải hạn" mất ' + mo(l, v) + '. ' + U.cap(d.w) + ' yên tâm, gật đầu cho cưới.', 'neutral'); l.flags.okTuoi = true; } },
      { k: 'mac_ke', l: 'Không tin, vẫn quyết cưới', ai: { w: 0.8, risk: 1 }, run: function (l, r, log, d) { log('Bạn nói thẳng: "Con không tin chuyện tuổi tác." ' + U.cap(d.w) + ' giận, nhưng rồi cũng đành chiều con.', 'neutral'); fx(l, { hap: -1 }); l.flags.okTuoi = true; } },
      { k: 'chia_tay', l: 'Áp lực quá, đành chia tay', ai: { w: 0.25 }, run: function (l, r, log, d) { if (l.partner) { log('Không chịu nổi áp lực từ gia đình, bạn và ' + d.n + ' chia tay. ' + d.n + ' khóc: "Chỉ vì một lá số thôi sao?"', 'bad'); l.partner = null; fx(l, { hap: -10 }); stress(l, 10); H.mem(l, 'Mối tình tan vỡ chỉ vì "không hợp tuổi".', 5); } } }
    ]
  });
  T('ps_khong_hop_tuoi', function (l, a) { return isVN(l) && !!whoHas(l, 'tam_linh') && !!l.partner && l.partner.status === 'dating' && !l.flags.okTuoi && a >= 20; }, 0.25, 3, 1);
  // sĩ diện: đám cưới phải to bằng họ hàng
  SC('ps_cuoi_to', {
    title: 'Đám cưới "cho bằng người ta"', prep: function (l) { return { w: whoHas(l, 'si_dien') || 'bố mẹ', v: l.base * (l.fam.q >= 4 ? 0.8 : 0.35) }; },
    valid: function (l) { return isVN(l) && !!whoHas(l, 'si_dien') && !!l.partner && l.partner.status === 'dating' && (!E.legalToMarry || E.legalToMarry(l)); },
    text: function (l, d) { return 'Nghe tin bạn sắp cưới, ' + d.w + ' muốn làm 60 mâm cỗ, thuê ban nhạc, xe hoa: "Con nhà bác Tư cưới 50 mâm, nhà mình không thể kém." Ước tính tốn thêm ' + mo(l, d.v) + '.'; },
    opts: [
      { k: 'chieu', l: 'Chiều bố mẹ, làm thật to', ai: { w: 0.8 }, run: function (l, r, log, d) { H.cash(l, -d.v * 0.5, 'Góp tiền đám cưới to theo ý bố mẹ'); l.flags.bigWedding = true; log('Bạn góp ' + mo(l, d.v * 0.5) + ' để làm đám cưới thật to. ' + U.cap(d.w) + ' nở mày nở mặt với họ hàng, còn bạn lo khoản nợ sau cưới.', 'neutral'); fx(l, { hap: 1 }); } },
      { k: 'gon', l: 'Thuyết phục làm gọn, dành tiền mua nhà', ai: { w: 1, smart: 1 }, run: function (l, r, log, d) { if (ch(r, 0.55)) { log('Bạn tính cho ' + d.w + ' xem số tiền ấy đủ trả trước một phần căn hộ. ' + U.cap(d.w) + ' gật gù đồng ý làm gọn.', 'good'); fx(l, { hap: 2 }); } else { log(U.cap(d.w) + ' phật ý: "Mất mặt với họ hàng!" Không khí trong nhà nặng nề suốt mấy tháng trước cưới.', 'bad'); stress(l, 8); } } }
    ]
  });
  T('ps_cuoi_to', function (l, a) { return isVN(l) && !!whoHas(l, 'si_dien') && !!l.partner && l.partner.status === 'dating' && a >= 22 && !l.flags.bigWedding && (!E.legalToMarry || E.legalToMarry(l)); }, 0.2, 3, 1);
  // ấm áp / cởi mở: khoảnh khắc đẹp khi trưởng thành
  EV(function (l, a) { return a >= 18 && a <= 50 && (has(l, 'am_ap') || has(l, 'coi_mo') || has(l, 'hai_huoc')); }, 0.04, 6, function (l, a, r, log) {
    var p = has(l, 'am_ap') ? whoHas(l, 'am_ap') : has(l, 'coi_mo') ? whoHas(l, 'coi_mo') : whoHas(l, 'hai_huoc');
    log(pick(r, [U.cap(p) + ' nhắn tin lúc nửa đêm: "Con ăn uống đầy đủ nhé. Mệt thì cứ về nhà."', 'Mỗi lần bạn về, ' + p + ' lại nấu đúng món bạn thích từ hồi bé.', U.cap(p) + ' bảo: "Con chọn gì bố mẹ cũng ủng hộ, miễn con vui."']), 'good'); fx(l, { hap: 2 }); stress(l, -3);
  });
  // hay lo / bao bọc khi con đã lớn
  EV(function (l, a) { return a >= 18 && a <= 40 && (has(l, 'hay_lo') || has(l, 'bao_boc')); }, 0.05, 5, function (l, a, r, log) {
    var p = whoHas(l, 'hay_lo') || whoHas(l, 'bao_boc');
    log(pick(r, ['Ba mươi tuổi đầu, ' + p + ' vẫn gọi điện mỗi tối hỏi bạn đã ăn cơm chưa.', U.cap(p) + ' gửi lên thành phố cả thùng đồ ăn, kèm tờ giấy dặn dò kín hai mặt.', 'Bạn đi công tác xa, ' + p + ' mất ngủ cả tuần cho đến khi bạn về.']), 'neutral');
  });

  // ===================================================================
  // 2. DRAMA GIA ĐÌNH
  // ===================================================================
  // 2a. nhà giàu: tranh giành tài sản khi bố mẹ còn sống
  SC('fd_tranh_gianh', {
    title: 'Anh chị em tranh giành tài sản',
    prep: function (l, r) { var s = pick(r, adultSibs(l)); return s ? { i: l.sibList.indexOf(s), v: estate(l), what: l.fam.elite ? 'cổ phần tập đoàn' : pick(r, ['căn biệt thự và mấy lô đất', 'chuỗi cửa hàng của gia đình', 'khu đất mặt tiền', 'xưởng sản xuất của gia đình']) } : { i: -1 }; },
    valid: function (l, d) { return l.fam.q >= 4 && anyParent(l) && adultSibs(l).length > 0 && !l.flags.fdTranh && (!d || d.i == null || d.i >= 0); },
    text: function (l, d) { var s = l.sibList[d.i]; return (both(l) ? 'Bố mẹ' : mom(l) ? 'Mẹ' : 'Bố') + ' đã ' + pAge(l) + ' tuổi, sức khỏe yếu dần. ' + U.cap(call(l, s)) + ' bắt đầu thúc ' + (both(l) ? 'bố mẹ' : mom(l) ? 'mẹ' : 'bố') + ' sang tên ' + d.what + ' (khoảng ' + mo(l, d.v) + ') cho mình, nói xấu bạn sau lưng. Bữa cơm gia đình thành chiến trường.'; },
    opts: [
      { k: 'giu', l: 'Đứng về phía bố mẹ: tài sản là của bố mẹ', ai: { w: 1.2, moral: 1 }, run: function (l, r, log, d) { var s = l.sibList[d.i]; l.flags.fdTranh = 'giu'; s.close = Math.max(0, s.close - 15); fx(l, { karma: 3 }); log('Bạn nói thẳng: "Bố mẹ còn sống, tài sản là của bố mẹ." ' + U.cap(call(l, s)) + ' đập bàn bỏ về. Bố mẹ nhìn bạn, mắt đỏ hoe.', 'neutral'); H.mem(l, 'Ngày bênh bố mẹ trước mặt ' + call(l, s) + '.', 3); } },
      { k: 'doi', l: 'Cũng đòi phần của mình cho công bằng', ai: { w: 0.7, risk: 1, bad: 0.5 }, run: function (l, r, log, d) { var s = l.sibList[d.i]; l.flags.fdTranh = 'doi'; s.close = Math.max(0, s.close - 25); if (ch(r, 0.5)) { var v = d.v / (sibs(l).length + 1) * 0.6; H.cash(l, v, 'Bố mẹ chia trước một phần tài sản'); log('Bố mẹ buồn bã chia trước cho mỗi người một phần. Bạn nhận ' + mo(l, v) + ', nhưng từ đó anh chị em nhìn nhau như người dưng.', 'bad'); } else log('Bạn lên tiếng đòi phần. Bố mẹ giận cả hai: "Bố mẹ chưa chết mà các con đã chia nhau!"', 'bad'); fx(l, { hap: -6 }); stress(l, 10); } },
      { k: 'hoa_giai', l: 'Mời luật sư, đề nghị bố mẹ lập di chúc rõ ràng', h: function (l) { return 'Phí luật sư khoảng ' + mo(l, l.base * 0.05); }, ai: { w: 0.9, smart: 1 }, run: function (l, r, log, d) { var s = l.sibList[d.i]; l.flags.fdTranh = 'di_chuc'; H.cash(l, -l.base * 0.05, 'Phí luật sư tư vấn di chúc'); l.flags.parentWill = true; s.close = Math.max(0, s.close - 5); log('Luật sư giúp bố mẹ lập di chúc công chứng, chia rành mạch. ' + U.cap(call(l, s)) + ' cằn nhằn nhưng không còn cớ để tranh.', 'good'); } },
      { k: 'ngoai', l: 'Đứng ngoài, không dính vào', ai: { w: 0.8 }, run: function (l, r, log, d) { l.flags.fdTranh = 'ngoai'; log('Bạn đứng ngoài cuộc. Tiếng cãi vã vẫn vọng qua điện thoại mỗi lần bạn gọi về.', 'neutral'); stress(l, 4); } }
    ]
  });
  T('fd_tranh_gianh', function (l, a) { return a >= 28 && a <= 65 && l.fam.q >= 4 && anyParent(l) && pAge(l) >= 62 && adultSibs(l).length > 0 && !l.flags.fdTranh; }, 0.06, 3, 1);
  // 2b. nhà giàu: kiện tụng chia di sản sau khi bố mẹ mất
  SC('fd_kien_di_san', {
    title: 'Ra tòa vì di sản',
    prep: function (l, r) { var s = pick(r, adultSibs(l)); return s ? { i: l.sibList.indexOf(s), v: estate(l) * 0.5 } : { i: -1 }; },
    valid: function (l, d) { return !anyParent(l) && l.fam.q >= 4 && adultSibs(l).length > 0 && !l.flags.fdKien && (!d || d.i == null || d.i >= 0); },
    text: function (l, d) { var s = l.sibList[d.i]; return 'Chưa hết tang, ' + call(l, s) + ' gửi đơn ra tòa, cho rằng việc chia di sản không công bằng và đòi thêm khoảng ' + mo(l, d.v) + '.'; },
    opts: [
      { k: 'kien', l: 'Thuê luật sư theo kiện đến cùng', h: function (l) { return 'Án phí, luật sư khoảng ' + mo(l, l.base * 0.3); }, ai: { w: 0.7, risk: 1 }, run: function (l, r, log, d) { var s = l.sibList[d.i]; l.flags.fdKien = true; H.cash(l, -l.base * 0.3, 'Án phí, phí luật sư kiện di sản'); s.close = 5; if (ch(r, 0.55)) { log('Ba năm ra tòa, bạn thắng kiện, giữ nguyên phần của mình. Nhưng ' + call(l, s) + ' tuyên bố từ mặt, đám giỗ bố mẹ hai nhà làm riêng.', 'neutral'); } else { H.cash(l, -d.v * 0.4, 'Thua kiện, chia lại di sản'); log('Tòa xử chia lại di sản. Bạn mất thêm ' + mo(l, d.v * 0.4) + ', mất cả người thân.', 'bad'); fx(l, { hap: -8 }); } stress(l, 15); H.mem(l, 'Những năm anh chị em gặp nhau ở tòa án.', 5); } },
      { k: 'nhuong', l: 'Nhường một phần để giữ hòa khí', ai: { w: 1, moral: 1 }, run: function (l, r, log, d) { var s = l.sibList[d.i]; l.flags.fdKien = true; H.cash(l, -d.v * 0.3, 'Nhường bớt di sản cho anh chị em'); s.close = Math.min(100, s.close + 10); fx(l, { karma: 5, hap: -2 }); log('Bạn chủ động nhường ' + mo(l, d.v * 0.3) + ', mời ' + call(l, s) + ' rút đơn. "Bố mẹ trên trời nhìn xuống chắc cũng không muốn thấy thế này."', 'neutral'); } },
      { k: 'hoa_giai', l: 'Nhờ họ hàng đứng ra hòa giải', ai: { w: 0.8 }, run: function (l, r, log, d) { var s = l.sibList[d.i]; l.flags.fdKien = true; if (ch(r, 0.5)) { s.close = Math.min(100, s.close + 5); log('Bác cả họp cả họ, phân xử. ' + U.cap(call(l, s)) + ' rút đơn, hai bên bắt tay dù còn gượng.', 'good'); } else { H.cash(l, -d.v * 0.2, 'Chia lại một phần di sản'); log('Hòa giải bất thành, cuối cùng vẫn phải chia lại một phần ' + mo(l, d.v * 0.2) + '.', 'bad'); } } }
    ]
  });
  T('fd_kien_di_san', function (l, a) { return !!l.flags.inherit && !anyParent(l) && l.fam.q >= 4 && adultSibs(l).length > 0 && !l.flags.fdKien; }, 0.06, 2, 1);
  // 2c. tập đoàn gia đình: tranh ghế chủ tịch
  SC('fd_ghe_chu_tich', {
    title: 'Ghế chủ tịch tập đoàn gia đình',
    prep: function (l, r) { var s = pick(r, adultSibs(l)); return s ? { i: l.sibList.indexOf(s) } : { i: -1 }; },
    valid: function (l, d) { return !!l.fam.elite && l.fam.elite !== 'ct' && dad(l) && adultSibs(l).length > 0 && !l.flags.fdGhe && (!d || d.i == null || d.i >= 0); },
    text: function (l, d) { var s = l.sibList[d.i]; return 'Bố chuẩn bị rút khỏi ghế chủ tịch. ' + U.cap(call(l, s)) + ' âm thầm gom phiếu các cổ đông, tung tin bạn "không đủ năng lực". Đại hội cổ đông sắp tới sẽ quyết định ai nắm quyền.'; },
    opts: [
      { k: 'dau', l: 'Vận động cổ đông, giành ghế chủ tịch', ai: { w: 1, amb: 1.5, risk: 1 }, run: function (l, r, log, d) { var s = l.sibList[d.i]; l.flags.fdGhe = true; s.close = Math.max(0, s.close - 30); if (ch(r, U.clamp(0.35 + (l.st.soc - 50) / 150 + (l.tr.amb - 50) / 200, 0.15, 0.75))) { l.flags.chairman = true; l.fame = (l.fame || 0) + 5e4; H.cash(l, l.base * 3, 'Thưởng nhiệm kỳ chủ tịch'); log('Đại hội cổ đông bầu bạn làm chủ tịch tập đoàn. Báo chí gọi đây là "cuộc chiến vương quyền" của giới tài phiệt. ' + U.cap(call(l, s)) + ' rời hội đồng quản trị.', 'big'); H.mem(l, 'Ngày ngồi vào ghế chủ tịch sau cuộc chiến với chính ' + call(l, s) + '.', 6); } else { log('Bạn thua phiếu. ' + U.cap(call(l, s)) + ' lên làm chủ tịch, bạn bị đẩy khỏi ban điều hành.', 'bad'); fx(l, { hap: -8 }); } stress(l, 12); } },
      { k: 'nhuong', l: 'Nhường ghế, giữ cổ phần và tình anh em', ai: { w: 0.9, moral: 1 }, run: function (l, r, log, d) { var s = l.sibList[d.i]; l.flags.fdGhe = true; s.close = Math.min(100, s.close + 8); H.cash(l, l.base * 0.8, 'Cổ tức tập đoàn gia đình'); log('Bạn nhường ghế cho ' + call(l, s) + ', giữ cổ phần và nhận cổ tức đều đặn. Gia đình yên ổn, dù có người bảo bạn "nhu nhược".', 'neutral'); } },
      { k: 'ban', l: 'Bán hết cổ phần, ra ngoài tự lập', ai: { w: 0.5, amb: 0.5 }, run: function (l, r, log, d) { var s = l.sibList[d.i]; l.flags.fdGhe = true; H.cash(l, l.base * 15, 'Bán cổ phần tập đoàn gia đình'); log('Bạn bán toàn bộ cổ phần cho ' + call(l, s) + ', cầm ' + mo(l, l.base * 15) + ' ra ngoài tự lập. Nhẹ nhõm như trút được gánh nặng.', 'good'); fx(l, { hap: 4 }); } }
    ]
  });
  T('fd_ghe_chu_tich', function (l, a) { return a >= 32 && a <= 55 && !!l.fam.elite && l.fam.elite !== 'ct' && dad(l) && adultSibs(l).length > 0 && !l.flags.fdGhe; }, 0.2, 3, 1);
  // 2d. nhà bình thường / khó khăn: mảnh đất hương hỏa
  SC('fd_dat_huong_hoa', {
    title: 'Mảnh đất hương hỏa',
    prep: function (l, r) { var s = pick(r, adultSibs(l)); return s ? { i: l.sibList.indexOf(s), v: H.housePrice(l) * 0.4 } : { i: -1 }; },
    valid: function (l, d) { return l.fam.q <= 3 && adultSibs(l).length > 0 && !l.flags.fdDat && (!d || d.i == null || d.i >= 0); },
    text: function (l, d) { var s = l.sibList[d.i]; return 'Mảnh đất có nhà thờ tổ (khoảng ' + mo(l, d.v) + ') chưa sang tên ai. ' + U.cap(call(l, s)) + ' muốn bán đi chia tiền, còn ' + (anyParent(l) ? (mom(l) ? 'mẹ' : 'bố') : 'các bác trong họ') + ' nhất quyết giữ làm nơi thờ cúng.'; },
    opts: [
      { k: 'giu', l: 'Giữ đất hương hỏa, nhận trông nom nhà thờ', ai: { w: 1.1, moral: 0.6 }, run: function (l, r, log, d) { var s = l.sibList[d.i]; l.flags.fdDat = 'giu'; s.close = Math.max(0, s.close - 8); fx(l, { karma: 3 }); log('Bạn nhận trông nom nhà thờ tổ, Tết nhất giỗ chạp đều về thắp hương. ' + U.cap(call(l, s)) + ' cho rằng bạn "giữ đất để sau này chiếm".', 'neutral'); } },
      { k: 'ban', l: 'Đồng ý bán, chia đều cho anh chị em', ai: { w: 0.8 }, run: function (l, r, log, d) { var s = l.sibList[d.i]; l.flags.fdDat = 'ban'; var v = d.v / (sibs(l).length + 1); H.cash(l, v, 'Phần chia từ bán đất hương hỏa'); s.close = Math.min(100, s.close + 4); log('Đất bán được, mỗi người nhận khoảng ' + mo(l, v) + '. Các cụ trong họ buồn lắm: "Bán đất tổ tiên là mất gốc."', 'neutral'); fx(l, { hap: -1 }); } },
      { k: 'mua', l: 'Gom tiền mua lại phần của anh chị em', h: function (l, d) { return 'Khoảng ' + mo(l, d.v * 0.7); }, req: function (l, d) { return l.money >= d.v * 0.7; }, ai: { w: 0.6 }, run: function (l, r, log, d) { var s = l.sibList[d.i]; l.flags.fdDat = 'mua'; H.cash(l, -d.v * 0.7, 'Mua lại phần đất hương hỏa'); s.close = Math.min(100, s.close + 6); log('Bạn bỏ tiền mua lại phần của anh chị em, đứng tên mảnh đất, giữ nguyên nhà thờ tổ.', 'good'); } }
    ]
  });
  T('fd_dat_huong_hoa', function (l, a) { return a >= 30 && a <= 70 && l.fam.q <= 3 && isVN(l) && adultSibs(l).length > 0 && !l.flags.fdDat; }, 0.025, 4, 1);
  // 2e. đùn đẩy nuôi bố mẹ già
  SC('fd_nuoi_bo_me', {
    title: 'Ai nuôi bố mẹ?',
    prep: function (l, r) { var s = pick(r, adultSibs(l)); return s ? { i: l.sibList.indexOf(s), w: both(l) ? 'bố mẹ' : mom(l) ? 'mẹ' : 'bố' } : { i: -1 }; },
    valid: function (l, d) { return anyParent(l) && pAge(l) >= 75 && adultSibs(l).length > 0 && l.indep && !l.flags.fdNuoi && (!d || d.i == null || d.i >= 0); },
    text: function (l, d) { var s = l.sibList[d.i]; return U.cap(d.w) + ' đã ' + pAge(l) + ' tuổi, cần người ở cạnh. Họp gia đình, ' + call(l, s) + ' bảo nhà chật, công việc bận, "đứa nào gần thì đứa ấy lo". Ai cũng nhìn bạn.'; },
    opts: [
      { k: 'nhan', l: 'Đón ' + 'bố mẹ về ở cùng mình', ai: { w: 1.2, moral: 1 }, run: function (l, r, log, d) { var s = l.sibList[d.i]; l.flags.fdNuoi = 'nhan'; l.flags.caring = true; s.close = Math.max(0, s.close - 5); fx(l, { karma: 6, hap: -2 }); stress(l, 6); log('Bạn đón ' + d.w + ' về ở cùng. Chật chội, vất vả, nhưng tối nào cũng có người hỏi "con ăn cơm chưa".', 'neutral'); H.mem(l, 'Những năm chăm ' + d.w + ' già yếu trong căn nhà nhỏ.', 4); } },
      { k: 'chia', l: 'Đề nghị luân phiên: mỗi nhà vài tháng', ai: { w: 1 }, run: function (l, r, log, d) { var s = l.sibList[d.i]; l.flags.fdNuoi = 'chia'; if (ch(r, 0.6)) { log('Anh chị em thống nhất luân phiên, mỗi nhà ba tháng. ' + U.cap(d.w) + ' cười: "Thành ra bố mẹ đi du lịch khắp nơi."', 'good'); } else { s.close = Math.max(0, s.close - 12); log('Luân phiên được một vòng thì ' + call(l, s) + ' viện cớ bận. Cuối cùng gánh nặng vẫn dồn về bạn.', 'bad'); stress(l, 8); } } },
      { k: 'vien', l: 'Góp tiền thuê người chăm / viện dưỡng lão', h: function (l) { return 'Khoảng ' + mo(l, l.base * 0.25) + '/năm'; }, req: function (l) { return l.money >= l.base * 0.25; }, ai: { w: 0.7 }, run: function (l, r, log, d) { l.flags.fdNuoi = 'vien'; H.cash(l, -l.base * 0.25, 'Thuê người chăm bố mẹ'); log('Bạn góp tiền thuê người chăm ' + d.w + '. Họ hàng xì xào "có tiền mà không có hiếu", ' + d.w + ' lại bảo: "Con đừng để ý."', 'neutral'); } }
    ]
  });
  T('fd_nuoi_bo_me', function (l, a) { return anyParent(l) && pAge(l) >= 75 && adultSibs(l).length > 0 && l.indep && !l.flags.fdNuoi; }, 0.07, 3, 1);
  // 2f. anh chị em nợ nần, chủ nợ đến tận nhà
  SC('fd_anh_em_no', {
    title: 'Nợ nần trong nhà',
    prep: function (l, r) { var s = pick(r, adultSibs(l)); return s ? { i: l.sibList.indexOf(s), why: pick(r, ['cờ bạc bóng đá', 'chơi tiền ảo', 'làm ăn thua lỗ', 'vay app tín dụng đen']), v: l.base * pick(r, [0.3, 0.6, 1.2]) } : { i: -1 }; },
    valid: function (l, d) { return adultSibs(l).length > 0 && l.indep && !l.flags.fdNo && (!d || d.i == null || d.i >= 0); },
    text: function (l, d) { var s = l.sibList[d.i]; return U.cap(call(l, s)) + ' nợ ' + mo(l, d.v) + ' vì ' + d.why + '. Chủ nợ ' + (anyParent(l) ? 'đến tận nhà bố mẹ đòi, ' + (mom(l) ? 'mẹ' : 'bố') + ' khóc gọi điện cho bạn.' : 'gọi điện khủng bố cả họ hàng.'); },
    opts: [
      { k: 'tra', l: 'Trả nợ giúp một lần, ra điều kiện', h: function (l, d) { return mo(l, d.v); }, req: function (l, d) { return l.money >= d.v; }, ai: { w: 1, soc: 0.6 }, run: function (l, r, log, d) { var s = l.sibList[d.i]; l.flags.fdNo = 'tra'; H.cash(l, -d.v, 'Trả nợ giúp ' + call(l, s)); if (ch(r, 0.55)) { s.close = Math.min(100, s.close + 10); log('Bạn trả nợ giúp, bắt ' + call(l, s) + ' viết cam kết. Lần này ' + call(l, s) + ' tu chí làm ăn thật.', 'good'); } else { s.close = Math.max(0, s.close - 10); log('Bạn trả nợ giúp. Một năm sau, ' + call(l, s) + ' lại nợ, lần này nhiều hơn.', 'bad'); fx(l, { hap: -5 }); } } },
      { k: 'ban_nha', l: 'Để bố mẹ tự lo', req: function (l) { return anyParent(l); }, ai: { w: 0.5 }, run: function (l, r, log, d) { var s = l.sibList[d.i]; l.flags.fdNo = 'bo_me'; log((mom(l) ? 'Mẹ' : 'Bố') + ' bán mảnh vườn, rút cả sổ tiết kiệm dưỡng già để trả nợ cho ' + call(l, s) + '. Bạn thương mà giận.', 'bad'); fx(l, { hap: -4 }); if (l.fam.mInc) l.fam.mInc *= 0.9; } },
      { k: 'mac_ke', l: 'Kiên quyết không dính vào', ai: { w: 0.7 }, run: function (l, r, log, d) { var s = l.sibList[d.i]; l.flags.fdNo = 'ke'; s.close = Math.max(0, s.close - 20); log('Bạn từ chối: "Tự làm thì tự chịu." ' + U.cap(call(l, s)) + ' bỏ trốn vào Nam, cả năm không liên lạc.', 'neutral'); stress(l, 6); } }
    ]
  });
  T('fd_anh_em_no', function (l, a) { return a >= 25 && a <= 65 && adultSibs(l).length > 0 && l.indep && !l.flags.fdNo; }, 0.012, 4, 1);
  // 2g. họ hàng mượn sổ đỏ đi thế chấp
  SC('fd_so_do', {
    title: 'Mượn sổ đỏ',
    prep: function (l, r) { return { who: pick(r, ['Ông chú họ', 'Bà cô bên nội', 'Anh rể', 'Người dì bên ngoại']), v: H.housePrice(l) * 0.3 }; },
    valid: function (l) { return l.ownHouse && l.indep && !l.flags.fdSoDo; },
    text: function (l, d) { return d.who + ' đến nhà, ngồi cả buổi tối: muốn mượn sổ đỏ nhà bạn thế chấp ngân hàng vay ' + mo(l, d.v) + ' làm ăn. "Người trong nhà cả, chú hứa một năm trả."'; },
    opts: [
      { k: 'cho', l: 'Cho mượn, vì nể tình họ hàng', ai: { w: 0.5, soc: 1 }, run: function (l, r, log, d) { l.flags.fdSoDo = 'cho'; if (ch(r, 0.5)) { log(d.who + ' làm ăn được, đúng hẹn trả sổ, mang sang biếu cả thùng quà.', 'good'); fx(l, { soc: 2 }); } else { H.cash(l, -d.v * 0.6, 'Trả nợ ngân hàng thay họ hàng để giữ nhà'); log(d.who + ' thua lỗ, ngân hàng gửi giấy đòi siết nhà. Bạn phải bỏ ra ' + mo(l, d.v * 0.6) + ' trả nợ thay để giữ lại căn nhà.', 'bad'); fx(l, { hap: -10 }); stress(l, 15); H.mem(l, 'Năm suýt mất nhà vì cho họ hàng mượn sổ đỏ.', 5); } } },
      { k: 'khong', l: 'Từ chối khéo', ai: { w: 1.2, smart: 1 }, run: function (l, r, log, d) { l.flags.fdSoDo = 'khong'; log('Bạn từ chối khéo. ' + d.who + ' ra về, từ đó gặp nhau ở đám giỗ chỉ gật đầu chào.', 'neutral'); } }
    ]
  });
  T('fd_so_do', function (l, a) { return a >= 30 && a <= 70 && isVN(l) && l.ownHouse && l.indep && !l.flags.fdSoDo; }, 0.01, 4, 1);
  // 2h. bố mẹ cãi nhau, đòi ly thân
  SC('fd_bo_me_cai', {
    title: 'Bố mẹ cãi nhau',
    prep: function (l, r) { return { why: pick(r, ['tiền bạc', 'bố nghi mẹ', 'mẹ phát hiện bố có người khác bên ngoài', 'chuyện bên nội bên ngoại', 'bố nhậu say về muộn']) }; },
    valid: function (l) { return both(l) && l.age >= 7 && l.age <= 17 && !l.fam.sepAt; },
    text: function (l, d) { return 'Đêm nào bố mẹ cũng cãi nhau vì ' + d.why + '. Có hôm mẹ xếp quần áo vào va li, nói sẽ về ngoại ở hẳn.'; },
    opts: [
      { k: 'giu', l: 'Ôm chặt mẹ, xin bố mẹ đừng bỏ nhau', ai: { w: 1.2 }, run: function (l, r, log) { if (ch(r, 0.6)) { log('Bố mẹ nhìn bạn khóc, im lặng hồi lâu. Hôm sau, mẹ cất va li lên nóc tủ.', 'neutral'); fx(l, { hap: -2 }); } else { l.fam.sepAt = l.age; log('Mẹ vẫn đi. Bố mẹ ly thân, bạn ở với ' + pick(r, ['bố', 'mẹ']) + ', cuối tuần mới gặp người kia.', 'bad'); fx(l, { hap: -8 }); stress(l, 12); H.mem(l, 'Năm ' + l.age + ' tuổi, bố mẹ ly thân.', 5); } } },
      { k: 'im', l: 'Trùm chăn kín đầu, cố không nghe', ai: { w: 0.9 }, run: function (l, r, log) { log('Bạn trùm chăn kín đầu, đeo tai nghe bật nhạc thật to. Sáng ra, cả nhà ăn sáng trong im lặng.', 'neutral'); fx(l, { hap: -3 }); stress(l, 6); } },
      { k: 'noi', l: 'Nói chuyện riêng với từng người', ai: { w: 0.6, soc: 1, smart: 1 }, run: function (l, r, log) { log('Bạn lần lượt nói chuyện với bố, rồi với mẹ. Hai người bất ngờ vì đứa con đã lớn từ lúc nào. Không khí trong nhà dịu đi.', 'good'); fx(l, { soc: 2 }); } }
    ]
  });
  T('fd_bo_me_cai', function (l, a) { return both(l) && a >= 7 && a <= 17 && !l.fam.sepAt && (has(l, 'nong_tinh') || has(l, 'gia_truong') || has(l, 'cuong_viec') || !!l.fam.vice || l.fam.q <= 2); }, 0.045, 4, 1);
  // ly thân thì nhà ít hơi ấm (lời kể đều đặn)
  EV(function (l, a) { return l.fam.sepAt != null && a > l.fam.sepAt && a <= 17 && both(l); }, 0.2, 3, function (l, a, r, log) {
    log(pick(r, ['Cuối tuần, bạn xách ba lô sang nhà ' + pick(r, ['bố', 'mẹ']) + ', hai ngôi nhà, hai cái bàn chải đánh răng.', 'Họp phụ huynh, bố mẹ ngồi cách nhau hai dãy ghế.', 'Sinh nhật bạn, bố mẹ thay nhau tổ chức hai lần, bạn cười mà thấy lạc lõng.']), 'neutral'); fx(l, { hap: -1 });
  });
  // 2i. con riêng xuất hiện ở đám tang
  var conRieng = function (l, r, log, a) {
    if (!l.alive || l.flags.fdConRieng != null || dad(l) || l.fam.noDad) return;
    if (!l.flags.fdDadSeen) { l.flags.fdDadSeen = a; if (!l.indep || l.age < 20 || l.flags.parentLostAt == null || a - l.flags.parentLostAt > 1) { l.flags.fdConRieng = false; return; } if (ch(r, 0.025 + (l.fam.vice ? 0.05 : 0) + (l.fam.q >= 4 ? 0.03 : 0))) l.flags.fdConRieng = 'pending'; else l.flags.fdConRieng = false; }
  };
  E.HOOKS.year.unshift(function (l, r, log, a) { if (l.fam && l.fam.fAlive === false && !l.fam.noDad && !(l.fam.orphan && l.fam.orphan.adopted == null)) conRieng(l, r, log, a); });
  SC('fd_con_rieng', {
    title: 'Người lạ ở đám tang bố', prep: function (l, r) { var sx = r() < 0.5 ? 'M' : 'F'; return { n: H.stranger(l, r, sx), sex: sx, v: estate(l) * 0.15 }; },
    valid: function (l) { return l.flags.fdConRieng === 'pending'; },
    text: function (l, d) { return 'Đám tang bố, một ' + (d.sex === 'M' ? 'người đàn ông' : 'người phụ nữ') + ' lạ mặt chừng ' + Math.max(18, l.age - 6) + ' tuổi đến thắp hương rồi quỳ rất lâu. Hóa ra là ' + d.n + ', con riêng của bố với một người khác, mang theo giấy xét nghiệm ADN và muốn được nhận một phần di sản (khoảng ' + mo(l, d.v) + ').'; },
    opts: [
      { k: 'nhan', l: 'Nhận làm anh chị em, chia phần theo luật', ai: { w: 0.9, moral: 1 }, run: function (l, r, log, d) { l.flags.fdConRieng = 'nhan'; H.cash(l, -Math.min(Math.max(0, l.money), d.v * 0.4), 'Chia phần di sản cho con riêng của bố'); fx(l, { karma: 6, hap: -3 }); log('Bạn chấp nhận ' + d.n + ' là người trong nhà, chia phần theo luật. ' + (l.fam.mAlive ? 'Mẹ khóc suốt mấy ngày, rồi cũng mời ' + d.n + ' ở lại ăn cơm.' : 'Từ đó đám giỗ bố có thêm một người.'), 'neutral'); H.mem(l, 'Ngày biết mình còn một người anh chị em cùng cha khác mẹ.', 5); } },
      { k: 'kien', l: 'Không nhận, để tòa phân xử', ai: { w: 0.6, risk: 1 }, run: function (l, r, log, d) { l.flags.fdConRieng = 'kien'; H.cash(l, -l.base * 0.1, 'Phí luật sư vụ con riêng'); if (ch(r, 0.5)) { log('Tòa công nhận ' + d.n + ' là con của bố, được hưởng một phần di sản theo luật. Bạn mất cả tiền lẫn bình yên.', 'bad'); H.cash(l, -Math.min(Math.max(0, l.money), d.v * 0.5), 'Chia di sản theo phán quyết của tòa'); } else log(d.n + ' rút đơn, không quay lại nữa. Bạn thở phào, nhưng câu chuyện về bố cứ day dứt mãi.', 'neutral'); stress(l, 10); } },
      { k: 'giu_kin', l: 'Thương lượng riêng, giữ kín với ' + 'cả nhà', ai: { w: 0.5 }, run: function (l, r, log, d) { l.flags.fdConRieng = 'kin'; H.cash(l, -Math.min(Math.max(0, l.money), d.v * 0.3), 'Thỏa thuận riêng với con riêng của bố'); log('Bạn gặp riêng ' + d.n + ', đưa một khoản để giữ kín chuyện. Bí mật ấy bạn mang theo suốt nhiều năm.', 'neutral'); stress(l, 8); } }
    ]
  });
  T('fd_con_rieng', function (l) { return l.flags.fdConRieng === 'pending'; }, 0.9, 1, 1);
  // 2j. di chúc thiên vị
  SC('fd_di_chuc', {
    title: 'Bản di chúc',
    prep: function (l, r) { var s = pick(r, adultSibs(l)); return s ? { i: l.sibList.indexOf(s), me: l.fam.thienVi, v: estate(l) * 0.4 } : { i: -1 }; },
    valid: function (l, d) { return has(l, 'thien_vi') && anyParent(l) && pAge(l) >= 68 && adultSibs(l).length > 0 && !l.flags.fdDiChuc && (!d || d.i == null || d.i >= 0); },
    text: function (l, d) { var s = l.sibList[d.i]; return 'Bạn tình cờ biết ' + (whoHas(l, 'thien_vi') || 'bố mẹ') + ' đã lập di chúc để gần hết nhà đất (khoảng ' + mo(l, d.v) + ') cho ' + (d.me ? 'bạn' : call(l, s)) + '. ' + (d.me ? U.cap(call(l, s)) + ' chưa biết gì.' : 'Còn bạn, chỉ được vài món kỷ niệm.'); },
    opts: [
      { k: 'noi', l: function (l, d) { return d && d.me ? 'Xin bố mẹ chia lại cho công bằng' : 'Nói chuyện thẳng với bố mẹ'; }, ai: { w: 1, moral: 0.6 }, run: function (l, r, log, d) { var s = l.sibList[d.i], w = whoHas(l, 'thien_vi') || 'bố mẹ'; l.flags.fdDiChuc = 'noi'; if (ch(r, 0.55)) { log('Sau nhiều lần nói chuyện, ' + w + ' sửa lại di chúc chia đều. "Bố mẹ già rồi, lẩm cẩm, các con đừng giận."', 'good'); s.close = Math.min(100, s.close + 6); } else { log(U.cap(w) + ' gạt đi: "Của bố mẹ, bố mẹ muốn cho ai thì cho."', 'neutral'); if (!d.me) { fx(l, { hap: -4 }); stress(l, 6); } } } },
      { k: 'im', l: 'Im lặng, coi như không biết', ai: { w: 0.9 }, run: function (l, r, log, d) { l.flags.fdDiChuc = d.me ? 'im_loi' : 'im_thiet'; l.flags.willBias = d.me ? 1 : -1; log(d.me ? 'Bạn im lặng. Sự im lặng ấy nặng hơn bạn tưởng.' : 'Bạn im lặng, nuốt nỗi tủi thân vào lòng. "Thương ai hơn thì bố mẹ biết."', 'neutral'); stress(l, 4); } }
    ]
  });
  T('fd_di_chuc', function (l, a) { return has(l, 'thien_vi') && anyParent(l) && pAge(l) >= 68 && adultSibs(l).length > 0 && !l.flags.fdDiChuc; }, 0.12, 3, 1);
  // di chúc thiên vị ảnh hưởng phần chia tài sản sau này
  var cts = E.DEC.chia_tai_san;
  if (cts) { var ap = cts.apply; cts.apply = function (l, d, k, r, log) { var m0 = l.money, out = ap.apply(this, arguments); var b = l.flags.willBias; if (b && l.money > m0) { var gain = l.money - m0, adj = gain * (b > 0 ? 0.8 : -0.6); H.cash(l, adj, b > 0 ? 'Phần hơn theo di chúc của bố mẹ' : 'Di chúc thiên vị, phần của bạn ít hơn'); log(b > 0 ? 'Theo di chúc, bạn được phần hơn anh chị em. Có người không nhìn mặt bạn trong ngày giỗ đầu.' : 'Di chúc để phần lớn cho anh chị em, phần của bạn ít hơn hẳn.', b > 0 ? 'neutral' : 'bad'); } return out; }; }
  [['ps_ep_nganh', 1], ['fd_tranh_gianh', 1], ['fd_kien_di_san', 1], ['fd_ghe_chu_tich', 1], ['fd_con_rieng', 1], ['fd_nuoi_bo_me', 1]].forEach(function (x) { E.MAJOR[x[0]] = x[1]; });
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
