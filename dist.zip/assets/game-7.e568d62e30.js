/* ===== js/life3.js ===== */
/* Một Đời — v3.0 (bản cập nhật lớn):
   · HIV chỉ lây qua quan hệ tình dục không an toàn, kim tiêm, hoặc từ mẹ sang con — không "tự nhiên" mắc
   · lương theo trình độ (thạc sĩ, tiến sĩ, chứng chỉ ngoại ngữ), đóng BHXH, BHYT, BHTN; lương hưu theo số năm đóng
   · làm đúng sở trường thì năng suất cao, lương cao, vui hơn; làm việc không thích dễ căng thẳng (thang 0–100) → trầm cảm
   · năng khiếu có cấp độ (EXP) · bằng lái B hết hạn sau 10 năm, A1/A vĩnh viễn · IELTS, TOPIK, HSK hết hạn sau 2 năm
   · xăng xe đổ hằng tuần, thuê xe chạy dịch vụ (Xanh SM, Grab), thay pin xe điện 2 năm một lần
   · hẹn hò qua ứng dụng (Tinder, Bumble, Hinge, Facebook Hẹn hò, Blued, HER…) · thu nhập chi tiết đến từ đâu · hồ sơ chi tiết */
(function (G) {
  'use strict';
  var U = G.U, E = G.E, H = E.H, SC = E.SC, isVN = H.isVN;
  function T(id, when, p, cd) { E.TRIG.push({ id: id, when: when, p: p, cd: cd || 0 }); }
  function A(id, g, label, o) { var x = { id: id, g: g, l: label }; for (var k in o) x[k] = o[k]; E.ACT.push(x); }
  function EV(c, p, run) { E.EVENTS.push({ c: c, p: p, run: run }); }
  function fx(l, o) { H.fx(l, o); }
  function mo(l, v) { return H.money(l, v); }
  function pick(r, a) { return U.pick(r, a); }
  function ch(r, p) { return r() < p; }
  function free(l) { return !(l.jailUntil != null && l.age < l.jailUntil) && !(l.abroad && l.abroad.trapped); }
  function yr(l, a) { return l.birthYear + (a == null ? l.age : a); }
  function vnd(l) { return isVN(l) && l.cur === 'vnd' && !(l.abroad && l.abroad.perm); }
  // số tiền ghi theo triệu đồng ở Việt Nam; nước khác quy đổi theo mức sống
  function V(l, tr) { return vnd(l) ? tr : tr / 90 * l.base; }
  function wrapApply(id, after) { var D = E.DEC[id]; if (!D) return; var ap = D.apply; D.apply = function (l, dec, k, r, log) { var x = ap.apply(this, arguments); after(l, dec, k, r, log); return x; }; }
  function jobC(l) { return l.job ? E.jobDef(l) : null; }
  function hobbyName(l) { var h = l.hobby && E.leisure && E.leisure.HOBBY[l.hobby]; return h ? h.n : ''; }

  // ===================================================================
  // 1. CHỐNG LẶP: chuỗi sự kiện đang diễn ra (nghiện cờ bạc, đòi nợ, kỳ thi năng khiếu từng cấp) vẫn được lặp
  // ===================================================================
  E.TRIG.forEach(function (t) { if (/^(khung_bo|nghien_bac|nk_thi)$/.test(t.id)) { t.rep = true; t.cd = Math.max(t.cd || 0, t.id === 'nk_thi' ? 1 : 2); } });

  // ===================================================================
  // 2. HIV: chỉ có khi có đường lây
  // ===================================================================
  E.hivRisk = function (l) {
    var f = l.flags || {}, w = 0;
    if (f.hivMom) w += 3;
    if (l.addict && l.addict.drugs && f.inject) w += 2.5;
    if (f.injYrs) w += Math.min(3, f.injYrs) * 0.4; // đã từng chích chung kim tiêm: có thể đã nhiễm từ trước, giờ mới phát hiện
    if (f.unsafe) w += Math.min(3, f.unsafe * 0.5) * (l.pool === 'afs' ? 3 : /^(af|et|ao)/.test(l.pool || '') ? 1.5 : 1);
    return w;
  };
  function hivRoute(l) {
    var f = l.flags, r = [];
    if (f.hivMom) r.push('lây từ mẹ trong lúc mang thai, khi sinh');
    if (l.addict && l.addict.drugs && f.inject) r.push('dùng chung kim tiêm khi chích ma túy');
    if (f.unsafe) r.push('quan hệ tình dục không dùng bao cao su');
    return r.join(' hoặc ') || 'chưa rõ';
  }
  // một mối quan hệ ngoài luồng thường không phòng bị
  ['ngoai_tinh', 'khung_hoang_40'].forEach(function (id) { wrapApply(id, function (l, d, k, r) { if (k === 'affair' && ch(r, 0.4)) l.flags.unsafe = (l.flags.unsafe || 0) + 1; }); });
  var tm0 = E.DEC.treat.make;
  E.DEC.treat.make = function (l, r) {
    var d = tm0.apply(this, arguments);
    if (l.ill && l.ill.n === 'HIV') d.text = 'Xét nghiệm dương tính với HIV. Đường lây nhiều khả năng do ' + hivRoute(l) + '. Bác sĩ nói điều trị ARV sớm, uống thuốc đều thì vẫn sống, làm việc gần như bình thường. ' + d.text.replace(/^Bác sĩ nói cần điều trị sớm\. /, '');
    return d;
  };

  // ===================================================================
  // 3. HỌC TIẾN SĨ
  // ===================================================================
  SC('phd', {
    title: 'Học tiếp tiến sĩ?', major: 1,
    text: function (l) { return 'Bạn vừa nhận bằng thạc sĩ. Thầy hướng dẫn muốn nhận bạn làm nghiên cứu sinh tiến sĩ (3–4 năm, có học bổng nhỏ và việc trợ giảng). Có học vị tiến sĩ thì làm giảng viên, nghiên cứu viên, chuyên gia được trả cao hơn hẳn.'; },
    opts: [
      { k: 'yes', l: 'Làm nghiên cứu sinh tiến sĩ', h: '3–4 năm, thu nhập thấp trong lúc học', ai: { smart: 1.2, amb: 0.8, w: 0.8 }, run: function (l, r, log) { l.school = 'phd'; l.schoolEnd = l.age + U.randint(r, 3, 4); log('Trở thành nghiên cứu sinh tiến sĩ' + (l.major ? ' ngành ' + (l.majorName || E.MAJORS[l.major]) : '') + '.', 'good'); fx(l, { kno: 4 }); } },
      { k: 'no', l: 'Đi làm luôn với bằng thạc sĩ', ai: { w: 1.2 }, run: function (l, r, log) { l.flags.needJob = true; log('Cầm bằng thạc sĩ đi xin việc.', 'neutral'); } }
    ]
  });
  E.MAJOR.phd = 1;

  // ===================================================================
  // 4. VIỆC LÀM: sở trường, chứng chỉ, bảo hiểm
  // ===================================================================
  var FIT = {
    'toán học': /^(ke_toan|ngan_hang|ngan_hang_cao|dev|ky_su|ky_su_xd|ky_su_co_dien|data|kiem_toan|thue|nghien_cuu|giang_vien|giao_vien|fl_dev|kien_truc|logistics|gia_su|chu_dau_tu)$/,
    'ngoại ngữ': /^(fl_dich|hdv|tiep_vien|ngoai_giao|le_tan|giang_vien|giao_vien|gia_su|marketing|sale_b2b|phi_cong|fl_day)$/,
    'âm nhạc': /^(ca_si|rapper|nhac_si|dj|vu_cong|giao_vien|ql_nghe_si)$/,
    'hội họa': /^(thiet_ke|fl_thiet_ke|nhiep_anh|tho_xam|kien_truc|tk_thoi_trang|makeup|fl_video|dao_dien|nail)$/,
    'ăn nói': /^(luat_su|mc_tv|mc_su_kien|dv_hai|telesale|sale_bh|sale_bds|sale_oto|sale_mp|sale_b2b|chinh_tri|chinh_khach|giao_vien|giang_vien|kol_live|youtuber|hdv|fl_long_tieng|phong_vien|kiem_sat|tham_phan|tro_giup_phap_ly)$/,
    'khéo tay': /^(tho_may|tho_dien|tho_sua_xe|tho_han|ky_thuat_vien|dau_bep|tho_moc|tho_mo|nail|tho_toc|barber|spa|makeup|nha_si|ky_su_co_dien|kien_truc)$/,
    'kinh doanh': /^(kd_|chu_|tiem_|sale_|telesale|marketing|cam_do|ngan_hang)/,
    'thể thao': /^(vdv|hlv_tt|pt_gym|quan_doi|cong_an)$/,
    'game': /^(tuyen_thu_es|coach_es|caster_es|dau_tu_es|streamer|quan_net|dev|fl_dev)$/,
    'cờ': /^(ky_thu|hlv_co|nghien_cuu|dev)$/,
    'làm đẹp': /^(tho_toc|nail|makeup|stylist|tk_thoi_trang|nguoi_mau|barber|spa)$/,
    'diễn xuất': /^(dien_vien|dv_hai|nguoi_mau|mc_tv|mc_su_kien|kol_live|youtuber|fl_long_tieng)$/
  };
  var HOB_JOB = { rap: /^(rapper|dj|ca_si)$/, nhay: /^(vu_cong|pt_gym|ca_si)$/, guitar: /^(nhac_si|ca_si|giao_vien)$/, ve: /^(thiet_ke|fl_thiet_ke|kien_truc|tho_xam)$/, chupanh: /^(nhiep_anh|fl_video|phong_vien)$/,
    nauan: /^(dau_bep|chu_quan_an|chu_nha_hang|kd_quan)$/, doc: /^(phong_vien|bien_kich|giao_vien|giang_vien|nghien_cuu|fl_content|luat_su)$/, kpop: /^(vu_cong|ca_si|fl_dich|tk_thoi_trang)$/, bongda: /^(vdv|hlv_tt|pt_gym)$/ };
  // +1: đúng sở trường / đam mê · −1: có sở trường rõ rệt nhưng làm việc chẳng liên quan · 0: bình thường
  function fitOf(l, c) {
    if (!c || c.sec === 'crime' || /^(phu_giup|xkld|scam_kh)$/.test(c.id)) return 0;
    var t = l.talent, hb = l.hobby;
    if (t && (c.talent === t || (FIT[t] && FIT[t].test(c.id)))) return 1;
    if (hb && HOB_JOB[hb] && HOB_JOB[hb].test(c.id) && (l.hobbySk || 0) >= 30) return 1;
    if ((t && (l.skill || 0) >= 30) || (hb && (l.hobbySk || 0) >= 45)) return -1;
    return 0;
  }
  E.jobFit = fitOf;
  // chứng chỉ ngoại ngữ còn hạn: được trả thêm ở nghề văn phòng, dịch vụ, giáo dục…
  var EXPIRE = { en: 2, ko: 2, zh: 2 }; // IELTS, TOPIK, HSK có giá trị 2 năm; JLPT, Goethe không thời hạn
  function certValid(l, k) { return !!(l.lang && l.lang[k]) && !(l.langExp && l.langExp[k]); }
  E.certValid = certValid;
  E.certBonus = function (l, c) {
    if (!c || c.sec === 'crime' || c.fame) return 1;
    var k = 1, en = (l.lang && l.lang.en) || 0, office = /^(office|service|edu|law|state|media|free|sale|med)$/.test(c.cat);
    if (office && en >= 3 && certValid(l, 'en')) k *= en >= 4 ? 1.1 : 1.06;
    if (office && ['ja', 'ko', 'zh', 'de'].some(function (x) { return ((l.lang && l.lang[x]) || 0) >= 3 && certValid(l, x); })) k *= 1.04;
    return k;
  };
  // người làm công ăn lương ở khu vực chính thức đóng BHXH 8% · BHYT 1,5% · BHTN 1% (tối đa trên 46,8 triệu/tháng)
  function insured(l) {
    var c = jobC(l);
    return !!(c && (E.pensionCovered ? E.pensionCovered(l, c) : c.sec === 'formal' && H.isEmployee(l)) && c.id !== 'xkld' && !l.pensioned && !(l.flags.military && l.age < l.flags.military) && !(l.abroad && !l.abroad.perm) && !(l.jailUntil != null && l.age < l.jailUntil));
  }
  E.insured = insured;
  function siRate(l) { return isVN(l) ? 0.105 : 0.08; }
  E.siLabel = function (l) { return (isVN(l) && !(l.abroad && l.abroad.perm)) ? 'BHXH, BHYT, BHTN' : 'bảo hiểm xã hội & y tế'; };
  var LVN = ['Mới tập', 'Làm quen', 'Khá', 'Giỏi', 'Rất giỏi', 'Xuất sắc', 'Tinh anh', 'Chuyên nghiệp', 'Bậc thầy', 'Huyền thoại'];
  function tLevel(sk) { return Math.min(10, 1 + Math.floor((sk || 0) / 10)); }
  E.talentLevel = function (l, sk) { var s = sk == null ? (l.skill || 0) : sk, lv = tLevel(s); return { lv: lv, name: LVN[lv - 1], exp: lv >= 10 ? 100 : Math.round((s % 10) * 10), next: lv >= 10 ? null : LVN[lv] }; };

  var cy0 = E.careerYear;
  E.careerYear = function (l, r, log, focus) {
    var c0 = jobC(l), job0 = l.job, ins0 = insured(l), rent = l.rentVeh;
    var inc = cy0.apply(this, arguments);
    if (!l.alive) return inc;
    var y = l.yr || (l.yr = { items: [] });
    y.gross = 0; y.si = 0;
    if (!c0 || !(inc > 0)) return inc;
    // thuê ô tô chạy dịch vụ thì chở được khách đi xa, cuốc xe giá cao hơn chạy xe máy
    if (rent && rent.car && E.wealth.isDriver(l)) inc *= 1.6;
    // năng suất theo sở trường
    var fit = fitOf(l, c0);
    if (c0.sec !== 'crime') {
      if (fit > 0) { inc *= 1.04 + tLevel(l.skill) * 0.012; fx(l, { hap: 1.5 }); if (l.mind) l.mind.stress -= 3; }
      else if (fit < 0) { inc *= 0.96; fx(l, { hap: -1 }); if (l.mind) l.mind.stress += 4; }
    }
    if (job0 && fit !== 0 && !job0.fitNoted && l.job === job0) {
      job0.fitNoted = true;
      var tw = l.talent ? E.talentText(l) : (l.hobby && hobbyName(l)) || 'sở thích của bạn';
      log(fit > 0 ? 'Công việc ' + E.jobTitle(l) + ' đúng sở trường (' + tw + ') — làm việc say mê, ' + (H.isEmployee(l) ? (E.hasBoss && !E.hasBoss(l) ? 'năng suất cao, cả đơn vị nể phục.' : 'năng suất cao hơn đồng nghiệp, được cấp trên để ý.') : 'làm ra sản phẩm tốt, khách hàng tin tưởng quay lại.') : 'Công việc ' + E.jobTitle(l) + ' chẳng liên quan gì đến ' + tw + ' — đi làm chủ yếu vì đồng lương, nhiều hôm chán nản, dễ căng thẳng.', fit > 0 ? 'good' : 'neutral');
    }
    y.gross = inc;
    if (ins0 && (!l.si || l.si.last !== l.age)) {
      var capY = V(l, 46.8 * 12), basis = Math.min(inc, capY), si = basis * siRate(l);
      inc -= si; y.si = si;
      l.si = l.si || { yrs: 0, sum: 0 }; l.si.yrs++; l.si.sum += basis; l.si.last = l.age; l.si.m = basis / 12;
      if (l.si.yrs === 1) log('Được ký hợp đồng lao động chính thức, đóng ' + E.siLabel(l) + ' — đủ 15 năm đóng sẽ có lương hưu.', 'neutral');
    }
    // vừa mất việc mà đã đóng BHTN: nhận trợ cấp thất nghiệp 60% lương, 3–12 tháng
    if (ins0 && isVN(l) && !l.job && !l.retired && l.si && l.si.yrs >= 1 && l.alive) {
      var months = Math.min(12, Math.max(3, l.si.yrs)), ben = l.si.m * 0.6 * months;
      H.cash(l, ben, 'Trợ cấp thất nghiệp (BHTN)');
      log('Làm thủ tục nhận trợ cấp thất nghiệp: ' + mo(l, l.si.m * 0.6) + '/tháng trong ' + months + ' tháng, trong lúc tìm việc mới.', 'neutral');
    }
    return inc;
  };
  // người có bằng thạc sĩ / tiến sĩ được mời vào vị trí lương cao tương xứng
  var off0 = E.offers;
  E.offers = function (l, r) {
    var o = off0.apply(this, arguments);
    if (l.edu >= 6 && o.length && E.jobEligible) {
      var est = function (id) { var c = E.CAR[id]; return E.monthlyEst(l, id, E.startRank(l, c)); };
      var cands = Object.keys(E.CAR).filter(function (id) { var c = E.CAR[id]; return c.edu >= 5 && o.indexOf(id) < 0 && E.jobEligible(l, c); });
      if (l.edu >= 7) { var ac = cands.filter(function (id) { return /^(giang_vien|nghien_cuu)$/.test(id); }); if (ac.length) cands = ac.concat(cands.filter(function (id) { return ac.indexOf(id) < 0; })); }
      else cands.sort(function (a, b) { return est(b) - est(a); });
      if (cands.length) {
        var acad = l.edu >= 7 && /^(giang_vien|nghien_cuu)$/.test(cands[0]), best = acad ? cands[0] : cands[Math.floor(r() * Math.min(4, cands.length))];
        var low = o.slice().sort(function (a, b) { return est(a) - est(b); })[0];
        if (acad || est(best) > est(low)) o[o.indexOf(low)] = best; // tiến sĩ luôn có lời mời từ trường đại học / viện nghiên cứu
      }
    }
    return o;
  };
  var oh0 = E.offerHint;
  E.offerHint = function (l, id) {
    var s = oh0.apply(this, arguments), c = E.CAR[E.resolveJob(id)];
    if (!c) return s;
    var fake = { job: { id: id, rank: 0 } }; for (var k in l) if (!(k in fake)) fake[k] = l[k];
    if (fitOf(l, c) > 0) s += ' · đúng sở trường';
    if (E.pensionCovered ? E.pensionCovered(fake, c) : c.sec === 'formal' && H.isEmployee(fake)) s += ' · có đóng ' + E.siLabel(l);
    return s;
  };
  // BHYT chi trả phần lớn viện phí
  function bhyt(l) { return isVN(l) ? (insured(l) || l.age < 6 || l.age >= 75 || l.fam.q <= 1 || l.pensioned || !!l.school || !!l.flags.bhytVol) : l.gdp > 25; }
  E.hasBHYT = bhyt;
  var ta0 = E.DEC.treat.apply;
  E.DEC.treat.apply = function (l, d, k, r, log) {
    var m0 = l.money, x = ta0.apply(this, arguments), spent = m0 - l.money;
    var share = E.bhytShare ? E.bhytShare(l) : (bhyt(l) ? 0.8 : 0), priv = k === 'best' && d.data && d.data.priv;
    if (spent > 0 && share > 0 && priv) { H.cash(l, spent * share, (isVN(l) && !(l.abroad && l.abroad.perm)) ? 'BHYT chi trả phần viện phí chuẩn' : 'Bảo hiểm chi trả phần chuẩn'); }
    else if (spent > 0 && share > 0) { var back = spent * share; H.cash(l, back, (isVN(l) && !(l.abroad && l.abroad.perm)) ? 'BHYT chi trả viện phí' : 'Bảo hiểm y tế chi trả'); log('Viện phí ' + mo(l, spent) + ': ' + ((isVN(l) && !(l.abroad && l.abroad.perm)) ? 'BHYT' : 'bảo hiểm') + ' chi trả ' + Math.round(share * 100) + '% (' + mo(l, back) + '), bạn trả ' + mo(l, spent - back) + '.', 'good'); }
    return x;
  };

  // ===================================================================
  // 5. BẰNG LÁI & CHỨNG CHỈ HẾT HẠN
  // ===================================================================
  function stampLic(l, had) { l.licAt = l.licAt || {}; ['A1', 'A', 'B'].forEach(function (k) { if (l.lic[k] && !(had && had[k])) l.licAt[k] = l.age; }); }
  if (E.DEC.bang_lai) { var bl0 = E.DEC.bang_lai.apply; E.DEC.bang_lai.apply = function (l) { var had = {}; for (var k in l.lic) had[k] = l.lic[k]; var x = bl0.apply(this, arguments); stampLic(l, had); if (l.lic.B) l.flags.licDue = false; return x; }; }
  var sl0 = H.studyLang;
  H.studyLang = function (l, k) { var v0 = (l.lang && l.lang[k]) || 0, x = sl0.apply(this, arguments); if (((l.lang && l.lang[k]) || 0) > v0) { (l.langAt = l.langAt || {})[k] = l.age; if (l.langExp) l.langExp[k] = false; } return x; };
  SC('gplx_het_han', {
    title: 'Bằng lái ô tô hết hạn',
    valid: function (l) { return !!(l.lic && l.lic.B && l.licAt && l.licAt.B != null && l.age - l.licAt.B >= 10); },
    text: function (l) { return 'Bằng lái ô tô hạng B của bạn (cấp năm ' + yr(l, l.licAt.B) + ') đã hết hạn 10 năm. Bằng xe máy A1 / A dùng vĩnh viễn, còn bằng ô tô muốn lái tiếp phải khám sức khỏe và làm thủ tục đổi bằng.' + (l.veh === 'ô tô' ? ' Bạn đang đi ' + (l.vehName || 'ô tô') + '.' : ''); },
    opts: [
      { k: 'renew', l: 'Đi khám sức khỏe, đổi bằng mới', h: function (l) { return 'Lệ phí đổi bằng và khám sức khỏe khoảng ' + mo(l, V(l, 0.7)); }, ai: function (l) { return l.veh === 'ô tô' || l.age < 65 ? 2 : 0.4; }, run: function (l, r, log) {
        l.flags.licDue = false;
        if (l.st.hea < 25 || l.age >= 85) { l.lic.B = false; log('Khám sức khỏe không đạt yêu cầu lái ô tô — bằng không được đổi.', 'bad'); return; }
        H.cash(l, -V(l, 0.7), 'Đổi bằng lái ô tô'); l.licAt.B = l.age; log('Đổi bằng lái hạng B thành công, có giá trị thêm 10 năm (đến năm ' + yr(l, l.age + 10) + ').', 'good');
      } },
      { k: 'no', l: 'Không đổi nữa, ít khi lái ô tô', ai: function (l) { return l.veh === 'ô tô' ? 0.1 : l.age >= 65 ? 2 : 0.6; }, run: function (l, r, log) { l.flags.licDue = false; l.lic.B = false; l.flags.licExpB = yr(l); log('Để bằng lái ô tô hết hạn' + (l.veh === 'ô tô' ? ' — từ giờ cầm lái là lái xe không có bằng hợp lệ, dễ bị phạt nặng.' : '.'), 'neutral'); } }
    ]
  });
  var CERTN = { en: 'IELTS', ko: 'TOPIK', zh: 'HSK' };
  function certText(l, k) { return H.langCert(l, k); }
  SC('chung_chi_het_han', {
    title: function (l, d) { return 'Chứng chỉ ' + CERTN[d.k] + ' hết hạn'; },
    prep: function (l, r, arg) { return arg && arg.k ? arg : { k: 'en' }; },
    valid: function (l, d) { var k = (d && d.k) || 'en'; return !!(l.lang && l.lang[k]) && !(l.langExp && l.langExp[k]); },
    text: function (l, d) { return 'Chứng chỉ ' + certText(l, d.k) + ' của bạn đã hết hạn (chỉ có giá trị 2 năm). Trình độ thì vẫn còn, nhưng nộp hồ sơ xin việc, du học hay định cư phải có chứng chỉ còn hạn. Bạn có muốn thi lại không?'; },
    opts: [
      { k: 'retest', l: 'Đăng ký thi lại', h: function (l, d) { return 'Lệ phí thi khoảng ' + mo(l, V(l, d.k === 'en' ? 4.7 : 1.6)); }, ai: function (l) { return l.age < 40 ? 1.5 : 0.5; }, run: function (l, r, log, d) {
        var k = d.k; H.cash(l, -V(l, k === 'en' ? 4.7 : 1.6), 'Thi lại ' + CERTN[k]);
        var v = l.lang[k], x = r() + (l.st.kno - 60) / 200, max = H.LANG[k].lv.length;
        if (x > 0.85 && v < max) l.lang[k] = v + 1; else if (x < 0.15 && v > 1) l.lang[k] = v - 1;
        (l.langAt = l.langAt || {})[k] = l.age; (l.langExp = l.langExp || {})[k] = false; (l.flags.certDue = l.flags.certDue || {})[k] = false;
        log('Thi lại ' + CERTN[k] + ': đạt ' + certText(l, k) + (l.lang[k] > v ? ' — cao hơn lần trước!' : l.lang[k] < v ? ' — thấp hơn lần trước vì lâu không dùng.' : '.') , l.lang[k] >= v ? 'good' : 'neutral');
      } },
      { k: 'no', l: 'Thôi, không cần nữa', ai: function (l) { return l.age >= 40 ? 1.5 : 0.6; }, run: function (l, r, log, d) { (l.langExp = l.langExp || {})[d.k] = true; (l.flags.certDue = l.flags.certDue || {})[d.k] = false; log('Để chứng chỉ ' + CERTN[d.k] + ' hết hạn.', 'neutral'); } }
    ]
  });
  function certMatters(l) { var c = jobC(l); return l.age <= 45 && (!!l.school || !l.job || !!(c && /^(office|service|edu|law|state|media|free|sale|med)$/.test(c.cat)) || !!(l.abroad && l.abroad.study)); }

  // ===================================================================
  // 6. XE CỘ: xăng đổ hằng tuần, thuê xe chạy dịch vụ
  // ===================================================================
  // tiền xăng (hoặc sạc) mỗi tuần, triệu đồng
  function fuelWeek(l) {
    if (l.age < 16 && l.veh !== 'xe đạp') return 0;
    var k = l.vehK || '', s = l.vehSeg || '', ev = /^(vf3|vf5|vf7|vf8|evo|feliz|theon|yadea)$/.test(k) || /điện/.test(l.vehName || ''), w;
    if (l.veh === 'ô tô') w = ev ? 0.13 : s === 'super' || (l.vehTier || 1) >= 4 ? 0.95 : s === 'sport' || (l.vehTier || 1) === 3 ? 0.6 : (l.vehTier || 1) === 2 ? 0.5 : /^(fortuner|everest)$/.test(k) ? 0.45 : 0.36;
    else if (l.veh === 'xe máy') w = ev ? 0.025 : k === 'z900' ? 0.25 : s === 'con' ? 0.1 : s === 'ga' ? 0.09 : 0.07;
    else if (l.veh === 'xe đạp') w = 0;
    else w = l.urban ? 0.1 : 0.05; // xe buýt, xe ôm, đi nhờ
    if (l.age >= 70) w *= 0.5;
    return w;
  }
  E.fuelWeek = function (l) { return V(l, fuelWeek(l)); };
  E.travelCost = function (l, b, a) {
    var fw = fuelWeek(l), fix;
    if (l.veh === 'ô tô') fix = 1.56 + (l.vehVal ? Math.min(l.vehVal * 0.012, vnd(l) ? 60 : l.vehVal) : 6) + (l.urban ? 14 : 2) + 6; // phí đường bộ, bảo hiểm thân vỏ, gửi xe, bảo dưỡng
    else if (l.veh === 'xe máy') fix = 0.1 + (l.urban ? 1.2 : 0.2) + 0.8; // bảo hiểm bắt buộc, gửi xe, thay nhớt
    else if (l.veh === 'xe đạp') fix = 0.3;
    else fix = 0;
    var tot = V(l, fw * 52 + fix);
    var R = l.rentVeh; if (R) tot += (R.fee + R.fuel) * 12;
    if (!vnd(l)) tot = Math.max(tot * 0.8, (l.veh === 'ô tô' ? b * 0.12 : l.veh === 'xe máy' ? b * 0.03 : b * 0.01));
    return tot;
  };
  var RENT = [
    { k: 'xsm_car', n: 'VinFast VF 5 (taxi điện Xanh SM)', fee: 7.5, fuel: 1.5, ev: true, car: true, lic: 'B', h: 'Thuê ~7,5 triệu/tháng · sạc điện ~1,5 triệu/tháng · cuốc ô tô giá cao hơn xe máy' },
    { k: 'grab_car', n: 'Toyota Vios (chạy Grab, Be)', fee: 9, fuel: 5, ev: false, car: true, lic: 'B', h: 'Thuê ~9 triệu/tháng · tự đổ xăng ~5 triệu/tháng' },
    { k: 'xsm_bike', n: 'xe máy điện VinFast (Xanh SM Bike)', fee: 1.2, fuel: 0.25, ev: true, car: false, lic: 'A1', h: 'Thuê ~1,2 triệu/tháng · sạc ~250 nghìn/tháng · không tốn xăng' }
  ];
  SC('thue_xe', {
    title: 'Thuê xe chạy dịch vụ', valid: function (l) { return E.wealth.isDriver(l) && !l.rentVeh; },
    text: function (l) { return 'Thay vì bỏ cả trăm triệu mua xe, nhiều tài xế thuê xe theo tháng để chạy ' + (isVN(l) ? 'Xanh SM, Grab, Be' : 'dịch vụ gọi xe') + '. Xe điện thì phải bảo dưỡng định kỳ, hai năm kiểm tra / thay pin một lần; xe xăng thì tự đổ xăng.'; },
    opts: RENT.map(function (x) {
      return { k: x.k, l: 'Thuê ' + x.n, h: function (l) { return vnd(l) ? x.h : 'Tiền thuê ~' + mo(l, V(l, x.fee)) + '/tháng · ' + (x.ev ? 'sạc' : 'xăng') + ' ~' + mo(l, V(l, x.fuel)) + '/tháng'; },
        req: function (l) { return !!l.lic[x.lic]; }, ai: { w: x.car ? 1 : 0.8 },
        run: function (l, r, log) { l.rentVeh = { k: x.k, n: x.n, fee: V(l, x.fee), fuel: V(l, x.fuel), ev: x.ev, car: x.car, since: l.age, bat: l.age }; log('Thuê ' + x.n + ' theo tháng để chạy dịch vụ.', 'good'); fx(l, { hap: 2 }); } };
    }).concat([{ k: 'no', l: 'Thôi, chạy xe của mình', ai: { w: 0.8 }, run: function () { } }])
  });
  SC('tra_xe_thue', {
    title: 'Trả xe thuê', valid: function (l) { return !!l.rentVeh; },
    text: function (l) { return 'Bạn đang thuê ' + l.rentVeh.n + ', mỗi tháng tốn ' + mo(l, l.rentVeh.fee + l.rentVeh.fuel) + ' cả tiền thuê lẫn ' + (l.rentVeh.ev ? 'sạc' : 'xăng') + '.'; },
    opts: [{ k: 'return', l: 'Trả xe, không thuê nữa', run: function (l, r, log) { log('Trả lại ' + l.rentVeh.n + '.', 'neutral'); l.rentVeh = null; } }, { k: 'keep', l: 'Tiếp tục thuê', run: function () { } }]
  });
  A('tra_xe_thue', 'Tiền bạc', 'Trả xe đang thuê', { min: 18, avail: function (l) { return l.rentVeh ? true : 'Không thuê xe'; } });

  // ===================================================================
  // 7. MUA SẮM HỢP TUỔI, TÌM NGƯỜI YÊU HỢP TUỔI, HẸN HÒ QUA ỨNG DỤNG
  // ===================================================================
  function itemsFor(l) {
    var a = l.age, F = l.sex === 'F', pw = H.parentsWord ? H.parentsWord(l) : '';
    if (a < 30) return [['chiếc iPhone đời mới nhất', 0.3], ['chiếc xe tay ga SH', 1], [F ? 'chiếc túi hàng hiệu' : 'đôi giày sneaker bản giới hạn', F ? 0.4 : 0.12], ['bộ máy tính chơi game xịn', 0.35], ['chiếc đồng hồ thông minh', 0.1], ['chiếc máy ảnh để quay vlog', 0.25]];
    if (a < 50) return [['chiếc tivi to cho cả nhà', 0.15], ['chiếc đồng hồ hàng hiệu', 0.6], ['bộ sofa da mới', 0.3], ['chiếc máy rửa bát và robot hút bụi', 0.2], ['chiếc xe đạp thể thao', 0.15], [F ? 'chiếc túi hàng hiệu' : 'bộ gậy golf', 0.4]].concat(pw ? [['chiếc ghế massage cho ' + pw, 0.5]] : []);
    return [['chiếc ghế massage toàn thân', 0.5], ['chiếc máy lọc không khí, lọc nước', 0.12], ['bộ ấm chén, tranh treo phòng khách', 0.2], ['chiếc đồng hồ hàng hiệu', 0.6], ['chiếc tivi màn hình lớn để xem thời sự', 0.15]];
  }
  if (E.DEC.mua_sam) {
    var MS = E.DEC.mua_sam.def;
    MS.prep = function (l, r) { var it = pick(r, itemsFor(l)); return { n: it[0], p: it[1] }; };
    MS.valid = function (l) { return l.money < l.base * 25; }; // giàu có thì chẳng còn là "cơn thèm" phải cân nhắc
    MS.text = function (l, d) { var a = l.age; return 'Bạn rất muốn mua ' + d.n + ' (khoảng ' + H.mb(l, d.p) + '). ' + (a < 30 ? 'Bạn bè ai cũng có.' : a < 50 ? 'Quảng cáo cứ hiện lên mỗi lần lướt mạng.' : 'Con cháu bảo cứ mua đi cho sướng tuổi già.') + ' Trong tài khoản hiện có ' + H.money(l, l.money) + '.'; };
    MS.opts.forEach(function (o) {
      if (/^(card|paylater|appden)$/.test(o.k)) { var rq = o.req; o.req = function (l, d) { return l.money < d.p * l.base && (!rq || rq(l, d)); }; } // đủ tiền thì không ai đi vay
      if (o.k === 'save') { o.l = function (l, d) { return l.money >= d.p * l.base ? 'Thôi, không thật sự cần' : 'Để dành, khi nào đủ tiền mới mua'; }; }
    });
  }
  var DAT = {
    tinder: { n: 'Tinder', h: 'Đông người dùng nhất, quẹt nhanh — nhiều người chỉ tìm vui qua đường', p: 0.55, hook: 0.35, scam: 0.06, ok: function (l) { return l.age <= 45; } },
    bumble: { n: 'Bumble', h: 'Con gái nhắn tin trước, ít bị làm phiền', p: 0.5, hook: 0.12, scam: 0.04, ok: function (l) { return l.age <= 45; } },
    hinge: { n: 'Hinge', h: '"Ứng dụng sinh ra để được xóa" — hợp người muốn yêu nghiêm túc', p: 0.5, hook: 0.05, scam: 0.03, serious: 1, ok: function (l) { return l.age >= 20 && l.age <= 45; } },
    fb: { n: 'Facebook Hẹn hò', h: 'Gợi ý theo bạn chung, nhiều người ở gần', p: 0.45, hook: 0.08, scam: 0.08, ok: function (l) { return l.age <= 65; } },
    blued: { n: 'Blued', h: 'Ứng dụng hẹn hò dành cho nam đồng tính, song tính', p: 0.6, hook: 0.4, scam: 0.05, ok: function (l) { return l.sex === 'M' && l.orient !== 'straight' && l.age <= 55; } },
    her: { n: 'HER', h: 'Ứng dụng dành cho nữ đồng tính, song tính', p: 0.5, hook: 0.08, scam: 0.03, ok: function (l) { return l.sex === 'F' && l.orient !== 'straight' && l.age <= 55; } },
    trung_nien: { n: 'nhóm kết bạn tuổi trung niên trên Zalo, Facebook', h: 'Nhiều người cùng cảnh, nhưng cũng nhiều kẻ lừa tình', p: 0.4, hook: 0, scam: 0.15, ok: function (l) { return l.age >= 45; } }
  };
  SC('app_hen_ho', {
    title: 'Chọn ứng dụng hẹn hò', valid: function (l) { return !l.partner && l.age >= 18; },
    text: function (l) { return l.age >= 45 ? 'Con cái khuyên bạn thử kết bạn trên mạng. Bạn chọn cách nào?' : 'Bạn tải vài ứng dụng hẹn hò về máy. Mỗi app một kiểu người dùng:'; },
    opts: Object.keys(DAT).map(function (k) {
      var x = DAT[k];
      return { k: k, l: U.cap(x.n), h: x.h, req: function (l) { return x.ok(l); }, ai: { w: x.serious ? 1 : 0.9, risk: x.hook > 0.2 ? 0.6 : 0 }, run: function (l, r, log) { appDate(l, r, log, k); } };
    }).concat([{ k: 'no', l: 'Thôi, xóa app', ai: { w: 0.2 }, run: function (l, r, log) { log('Tải về rồi lại xóa, thấy không hợp với mình.', 'neutral'); } }])
  });
  function appDate(l, r, log, k) {
    var x = DAT[k], y = r();
    if (y < x.scam) { H.cash(l, -l.base * 0.1, 'Bị lừa tình qua mạng'); log('Quen một "người tình" trên ' + x.n + ', được hứa gửi quà từ nước ngoài rồi bị bắt chuyển "phí hải quan". Mất tiền, mất niềm tin.', 'bad'); fx(l, { hap: -8 }); return; }
    if (y < x.scam + x.p) {
      var ps = H.partnerSex(l, r), nm = H.stranger(l, r, ps);
      if (l.age <= 45 && ch(r, x.hook)) { l.pending.unshift(E.DEC.qua_dem.make(l, r, { app: x.n, name: nm })); return; }
      l.pending.unshift(E.DEC.love.make(l, r, { where: 'qua ' + x.n }));
      return;
    }
    log('Quẹt ' + x.n + ' mỏi tay, nhắn được vài người rồi im bặt.', 'neutral');
  }
  SC('qua_dem', {
    title: function (l, d) { return 'Hẹn gặp qua ' + d.app; },
    prep: function (l, r, arg) { return arg && arg.name ? arg : { app: 'Tinder', name: H.stranger(l, r, H.partnerSex(l, r)) }; },
    valid: function (l) { return l.age >= 18; },
    text: function (l, d) { return 'Nói chuyện vài hôm trên ' + d.app + ', ' + d.name + ' rủ bạn đi chơi tối nay rồi "về chỗ mình".'; },
    opts: [
      { k: 'safe', l: 'Đi, nhưng nhất định dùng bao cao su', ai: { w: 1.2, smart: 0.6 }, run: function (l, r, log, d) { log('Một đêm vui với ' + d.name + ', cả hai đều cẩn thận.', 'neutral'); fx(l, { hap: 3 }); if (ch(r, 0.25)) l.pending.unshift(E.DEC.love.make(l, r, { where: 'qua ' + d.app + ' — từ một buổi hẹn tưởng chỉ qua đường' })); } },
      { k: 'unsafe', l: 'Đi luôn, không phòng bị gì', h: 'Nguy cơ bệnh lây qua đường tình dục, HIV', ai: { risk: 1.2, smart: -1, w: 0.5 }, run: function (l, r, log, d) {
        l.flags.unsafe = (l.flags.unsafe || 0) + 1; fx(l, { hap: 3 });
        if (ch(r, 0.1)) { log('Vài tuần sau thấy khó chịu, đi khám thì mắc bệnh lây qua đường tình dục — may là chữa khỏi được. Bác sĩ dặn đi xét nghiệm HIV định kỳ.', 'bad'); fx(l, { hea: -4, hap: -4 }); H.cash(l, -l.base * 0.02, 'Khám chữa bệnh'); }
        else log('Một đêm "phiêu" với ' + d.name + ' mà không phòng bị gì.', 'neutral');
      } },
      { k: 'coffee', l: 'Chỉ đi cà phê làm quen thôi', ai: { w: 1 }, run: function (l, r, log, d) { if (ch(r, 0.4)) l.pending.unshift(E.DEC.love.make(l, r, { where: 'qua ' + d.app })); else log('Đi cà phê với ' + d.name + ', nói chuyện vui nhưng không thấy "rung động".', 'neutral'); } },
      { k: 'no', l: 'Thôi, không gặp', ai: { w: 0.6 }, run: function (l, r, log) { log('Từ chối khéo rồi xóa app.', 'neutral'); } }
    ]
  });
  if (E.DEC.tim_nguoi_yeu) {
    var TN = E.DEC.tim_nguoi_yeu.def, oldOpts = TN.opts, ob = function (k) { return oldOpts.filter(function (o) { return o.k === k; })[0]; };
    TN.text = function (l) {
      var a = l.age;
      return a < 30 ? 'Bạn bè lần lượt có đôi. Bạn quyết định chủ động tìm một nửa của mình.' : a < 45 ? 'Bạn bè đã yên bề gia thất, ' + (l.fam.mAlive || l.fam.fAlive ? 'bố mẹ giục mãi chuyện lập gia đình' : 'căn nhà đi làm về vắng tanh') + '. Bạn quyết định chủ động hơn.' : a < 60 ? 'Sau nhiều năm một mình, bạn muốn tìm một người cùng đi nốt quãng đường còn lại.' : 'Tuổi xế chiều, con cháu bận rộn, bạn muốn có một người bầu bạn sớm hôm.';
    };
    TN.opts = [
      { k: 'app', l: function (l) { return l.age >= 45 ? 'Kết bạn qua mạng (Facebook Hẹn hò, nhóm Zalo…)' : 'Dùng ứng dụng hẹn hò (Tinder, Bumble…)'; }, req: function (l) { return l.age >= 18 && l.age <= 70; }, ai: { risk: 0.6 }, run: function (l, r, log) { l.pending.unshift(E.DEC.app_hen_ho.make(l, r)); } },
      ob('match'),
      { k: 'work', l: function (l) { return l.age >= 60 || l.retired ? 'Tham gia câu lạc bộ dưỡng sinh, hội người cao tuổi' : l.school ? 'Để ý một người ở trường' : 'Để ý một người ở chỗ làm'; }, ai: { w: 1 }, run: function (l, r, log) { var where = l.age >= 60 || l.retired ? 'ở câu lạc bộ dưỡng sinh' : l.school ? 'ở trường' : 'ở chỗ làm'; if (ch(r, 0.55)) l.pending.unshift(E.DEC.love.make(l, r, { where: where })); else log(l.age >= 60 ? 'Đi sinh hoạt đều đặn, vui là chính, chưa gặp ai hợp.' : 'Người ấy đã có người yêu.', 'neutral'); } },
      { k: 'club', l: function (l) { return l.age >= 50 ? 'Đi khiêu vũ, sinh hoạt câu lạc bộ' : 'Đi bar, câu lạc bộ, sự kiện'; }, ai: { soc: 1.2, cost: 0.05 }, run: function (l, r, log) { H.cash(l, -l.base * 0.03, 'Đi chơi'); if (ch(r, 0.4)) l.pending.unshift(E.DEC.love.make(l, r, { where: l.age >= 50 ? 'ở lớp khiêu vũ' : 'trong một buổi tiệc' })); else log('Một buổi tối vui, nhưng không thêm số điện thoại nào.', 'neutral'); } }
    ].filter(Boolean);
  }

  // ===================================================================
  // 8. GAME HỢP TUỔI
  // ===================================================================
  function ageGame(l, r) {
    var a = l.age, c = jobC(l);
    if (l.game && (a < 30 || (c && /^(esport|creator)$/.test(c.cat)) || (l.talent === 'game' && a < 40))) return l.game;
    return pick(r, a < 12 ? ['Minecraft', 'Roblox', 'Play Together', 'Liên Quân Mobile'] : a < 18 ? ['Liên Quân Mobile', 'Free Fire', 'PUBG Mobile', 'Roblox', 'Minecraft', 'FC Online'] :
      a < 30 ? ['Liên Minh Huyền Thoại', 'Valorant', 'FC Online', 'PUBG', 'Liên Quân Mobile', 'Genshin Impact'] : a < 45 ? ['FC Online', 'Liên Minh Huyền Thoại', 'Đế Chế (Age of Empires)', 'game đua xe', 'Call of Duty'] :
      a < 60 ? ['cờ tướng online', 'Tiến lên miền Nam', 'FC Online', 'Đế Chế (Age of Empires)', 'Candy Crush'] : ['cờ tướng online', 'Tiến lên miền Nam', 'Candy Crush', 'ô chữ, sudoku']);
  }
  E.ageGame = ageGame;
  if (E.DEC.choi_game_nha) E.DEC.choi_game_nha.def.prep = function (l, r) { return { g: ageGame(l, r) }; };

  // ===================================================================
  // 9. ĐỘI, ĐOÀN (Việt Nam): khăn quàng đỏ từ lớp 3, không phải lớp 1
  // ===================================================================
  EV(function (l, a) { return isVN(l) && a === 8 && l.school === 'primary' && !l.flags.doi; }, 0.92, function (l, a, r, log) { l.flags.doi = true; log('Được kết nạp vào Đội Thiếu niên Tiền phong Hồ Chí Minh — lần đầu thắt chiếc khăn quàng đỏ lên vai.', 'good'); fx(l, { hap: 3 }); H.mem(l, 'Ngày được kết nạp Đội, mẹ là chiếc khăn quàng đỏ phẳng phiu.', 2); });
  EV(function (l, a) { return isVN(l) && a >= 16 && a <= 18 && (l.school === 'upper' || l.school === 'priv') && !l.flags.doan; }, 0.35, function (l, a, r, log) { l.flags.doan = true; log('Được kết nạp Đoàn Thanh niên Cộng sản Hồ Chí Minh, cài huy hiệu Đoàn lên áo.', 'good'); fx(l, { soc: 2 }); });

  // ===================================================================
  // 10. VÒNG NĂM: căng thẳng, năng khiếu, bằng lái, chứng chỉ, xe thuê, thu nhập chi tiết
  // ===================================================================
  E.stressLabel = function (s) { return s >= 85 ? 'báo động' : s >= 70 ? 'quá tải' : s >= 50 ? 'căng thẳng' : s >= 30 ? 'bình thường' : 'thư thái'; };
  // phân loại các khoản thu trong năm
  function incomeParts(l) {
    var y = l.yr || {}, F = l.fin || {}, items = y.items || [], P = { biz: 0, rent: 0, bonus: 0, family: 0, gov: 0, other: 0 };
    items.forEach(function (x) {
      var t = x.t || '';
      if (/^(Lãi|Lỗ) /.test(t) && !/tiết kiệm|chứng khoán|vàng|tiền mã hóa|đất nền/.test(t)) P.biz += x.v;
      else if (/^Tiền cho thuê/.test(t)) P.rent += x.v;
      else if (x.v > 0 && /[Tt]hưởng/.test(t)) P.bonus += x.v;
      else if (x.v > 0 && /chu cấp|tiêu vặt|lì xì|biếu/.test(t)) P.family += x.v;
      else if (x.v > 0 && /BHTN|BHYT|trợ cấp|Bảo hiểm/.test(t)) P.gov += x.v;
    });
    var rows = [], inc = F.inc || 0;
    if (y.gross > 0) { rows.push({ k: 'Lương / thu nhập từ công việc', v: y.gross }); if (y.si > 0) rows.push({ k: 'Đóng ' + E.siLabel(l) + ' (' + (isVN(l) ? '10,5%' : '8%') + ')', v: -y.si }); }
    else if (inc > 0) rows.push({ k: l.retired ? (l.pensioned ? 'Lương hưu & con cái biếu' : 'Trợ cấp & con cái biếu') : 'Thu nhập', v: inc });
    if (P.biz) rows.push({ k: 'Lợi nhuận kinh doanh (cửa hàng của bạn)', v: P.biz });
    if (P.rent) rows.push({ k: 'Tiền cho thuê nhà', v: P.rent });
    if (F.interest) rows.push({ k: F.interest >= 0 ? 'Lãi tiền gửi' : 'Lãi phải trả (tiêu lố)', v: F.interest });
    if (P.bonus) rows.push({ k: 'Tiền thưởng', v: P.bonus });
    if (P.family) rows.push({ k: 'Gia đình cho', v: P.family });
    if (P.gov) rows.push({ k: 'Bảo hiểm chi trả, trợ cấp', v: P.gov });
    if (F.partner) rows.push({ k: 'Bạn đời góp', v: F.partner });
    return rows;
  }
  E.incomeParts = incomeParts;
  E.incomeSrc = function (l, F, income) {
    var y = l.yr || {};
    return y.si > 0 ? ' (lương ' + mo(l, y.gross / 12) + '/tháng, đã trừ ' + E.siLabel(l) + ' ' + mo(l, y.si / 12) + '/tháng)' : '';
  };
  E.HOOKS.year.push(function (l, r, log, a, F) {
    if (!l.alive) return;
    var f = l.flags;
    // mẹ mang HIV: nhờ điều trị dự phòng, phần lớn trẻ không bị lây
    if (a === 0 && f.hivMomChecked == null) {
      f.hivMomChecked = true;
      var pMom = l.pool === 'afs' ? 0.12 : /^(af|et|ao)/.test(l.pool || '') ? 0.03 : isVN(l) ? 0.0015 : 0.001;
      if (ch(r, pMom)) {
        if (ch(r, l.gdp > 5 || l.urban ? 0.03 : 0.2)) { f.hivMom = true; l.ill = { n: 'HIV', m: 1.6, base: 0, cure: 0, mult: 1.6, f: 'HIV/AIDS', since: 0, chronic: true }; log('Mẹ mang HIV và bạn bị lây từ mẹ khi sinh — phải uống thuốc ARV hằng ngày từ bé.', 'bad'); }
        else log('Mẹ mang HIV nhưng được điều trị dự phòng lây truyền mẹ con — bạn chào đời khỏe mạnh, không bị lây.', 'neutral');
      }
    }
    if (l.addict && l.addict.drugs && f.inject == null && a >= 14) { f.inject = ch(r, 0.35); if (f.inject) log('Chuyển sang chích ma túy, dùng chung kim tiêm với bạn nghiện.', 'bad'); }
    if (l.addict && l.addict.drugs && f.inject) f.injYrs = (f.injYrs || 0) + 1;
    if (a === 18 && f.bhytVol == null) f.bhytVol = ch(r, 0.65);
    // nghiên cứu sinh có học bổng, trợ giảng
    if (l.school === 'phd') H.cash(l, l.base * 0.35, 'Học bổng & trợ giảng nghiên cứu sinh');
    // căng thẳng ảnh hưởng sức khỏe, các mối quan hệ; kéo dài thì dễ trầm cảm
    var M = l.mind;
    if (M && a >= 12) {
      if (M.stress >= 60) l.st.soc -= (M.stress - 55) / 12;
      if (M.stress >= 75 && l.partner && (f.fightAt == null || a - f.fightAt >= 3) && ch(r, 0.3)) { f.fightAt = a; log('Căng thẳng triền miên khiến bạn hay cáu gắt, ' + l.partner.name + ' nhiều lần giận dỗi bỏ về.', 'bad'); fx(l, { hap: -3, soc: -2 }); }
      M.hiYrs = M.stress >= 80 ? (M.hiYrs || 0) + 1 : 0;
      if (M.hiYrs >= 2 && (f.depAt == null || a - f.depAt >= 6) && ch(r, 0.35)) { f.depAt = a; log('Căng thẳng kéo dài nhiều năm: mất ngủ, chán ăn, không còn thấy vui với bất cứ điều gì — những dấu hiệu của trầm cảm.', 'bad'); H.sched(l, 'tram_cam', 1); }
    }
    // năng khiếu: rèn giũa thì lên cấp
    if (l.talent && a >= 6) {
      var c = jobC(l);
      if (!(c && (c.skillRank != null || c.fame))) {
        var g = c && fitOf(l, c) > 0 ? 1.2 : f.nk && !f.nk.stop ? 0 : a < 25 ? 0.5 : 0.15;
        l.skill = Math.min(100, (l.skill || 20) + g);
      }
      var lv = tLevel(l.skill);
      if (f.tLv == null) f.tLv = lv;
      else if (lv > f.tLv) { f.tLv = lv; if (lv >= 3) log('Năng khiếu ' + E.talentText(l) + ' lên cấp ' + lv + ' — "' + LVN[lv - 1] + '".', 'good'); }
    }
    // bằng lái: B hết hạn sau 10 năm
    l.licAt = l.licAt || {};
    ['A1', 'A', 'B'].forEach(function (k) { if (l.lic && l.lic[k] && l.licAt[k] == null) l.licAt[k] = a; });
    if (l.lic && l.lic.B && a - l.licAt.B >= 10 && !f.licDue && free(l)) { f.licDue = true; H.sched(l, 'gplx_het_han', 0); }
    // chứng chỉ ngoại ngữ hết hạn sau 2 năm
    l.langAt = l.langAt || {}; l.langExp = l.langExp || {};
    Object.keys(EXPIRE).forEach(function (k) {
      if (!(l.lang && l.lang[k])) return;
      if (l.langAt[k] == null) l.langAt[k] = a;
      if (!l.langExp[k] && a - l.langAt[k] >= EXPIRE[k]) {
        var due = f.certDue || (f.certDue = {});
        if (certMatters(l) && free(l)) { if (!due[k]) { due[k] = true; H.sched(l, 'chung_chi_het_han', 0, { k: k }); } }
        else { l.langExp[k] = true; log('Chứng chỉ ' + H.langCert(l, k) + ' hết hạn sau 2 năm — trình độ vẫn còn, nhưng muốn nộp hồ sơ thì phải thi lại.', 'neutral'); }
      }
    });
    // xe thuê: thôi chạy dịch vụ thì trả xe; xe điện 2 năm bảo dưỡng pin một lần
    var R = l.rentVeh;
    if (R) {
      if (!E.wealth.isDriver(l) || l.retired) { log('Không chạy dịch vụ nữa, trả lại ' + R.n + '.', 'neutral'); l.rentVeh = null; }
      else if (R.ev && a - R.bat >= 2) { R.bat = a; var bc = V(l, R.car ? 3 : 3.5); H.cash(l, -bc, R.car ? 'Bảo dưỡng 2 năm, kiểm tra pin xe điện' : 'Đổi pin xe máy điện'); log(R.car ? 'Tròn 2 năm thuê xe: đưa ' + R.n + ' đi bảo dưỡng, kiểm tra và cân bằng pin, tốn ' + mo(l, bc) + '.' : 'Pin xe máy điện chai sau 2 năm chạy liên tục, phải đổi pin mới ' + mo(l, bc) + '.', 'neutral'); }
    }
    // xe điện của mình: 3 năm thay / bảo dưỡng pin
    if (l.vehK && /^(evo|feliz|theon|yadea)$/.test(l.vehK)) { l.vehBat = l.vehBat == null ? a : l.vehBat; if (a - l.vehBat >= (l.vehBatN ? 4 : 3)) { l.vehBat = a; var pc = V(l, 4); H.cash(l, -pc, 'Thay pin xe máy điện'); l.vehBatN = (l.vehBatN || 0) + 1; log(l.vehBatN === 1 ? 'Pin ' + (l.vehName || 'xe máy điện') + ' chai sau 3 năm, thay pin mới hết ' + mo(l, pc) + '.' : U.pick(r, ['Lại đến kỳ thay pin ' + (l.vehName || 'xe máy điện') + ' (lần thứ ' + l.vehBatN + '), hết ' + mo(l, pc) + '.', 'Pin xe yếu dần, đi được nửa quãng đã báo hết — thay bộ pin mới ' + mo(l, pc) + '.', 'Cửa hàng kiểm tra pin ' + (l.vehName || 'xe máy điện') + ' thấy dung lượng còn thấp, thay mới hết ' + mo(l, pc) + '.']) , 'neutral'); } }
    // tổng thu nhập trong năm đến từ đâu (khi có nhiều nguồn)
    if (l.indep && F) {
      var rows = incomeParts(l).filter(function (x) { return !/^Bạn đời/.test(x.k); });
      var extra = rows.filter(function (x) { return (/kinh doanh|cho thuê/.test(x.k) && Math.abs(x.v) >= l.base * 0.05) || (/Lãi tiền gửi/.test(x.k) && x.v >= l.base * 0.3); });
      if (extra.length && rows.length >= 2) log('Thu nhập cả năm đến từ: ' + rows.map(function (x) { return x.k.replace(/ \(.*\)$/, '').toLowerCase() + ' ' + (x.v < 0 ? '−' : '') + mo(l, Math.abs(x.v)); }).join(' · ') + '.', 'money');
    }
  });

  // ===================================================================
  // 11. HỒ SƠ CHI TIẾT (dùng cho giao diện)
  // ===================================================================
  var ACH = /giải (Nhất|Nhì|Ba|Khuyến khích)|huy chương|[Vv]ô địch|Tốt nghiệp|Nhận bằng|học vị|thăng|bổ nhiệm|Lên hạng|nút (bạc|vàng|kim cương)|triệu người|kỷ lục|học bổng|tuyển thẳng|Khai trương|TRÚNG|Đạt danh hiệu|Mở chi nhánh|kết nạp|lên cấp/;
  E.profile = function (l) {
    var c = jobC(l), P = {};
    var vens = (l.ventures || []).map(function (v) { return 'chủ ' + v.n + (v.br > 1 ? ' (' + v.br + ' cơ sở)' : ''); });
    P.job = l.job ? U.cap(E.jobTitle(l)) + (vens.length ? ' · ' + vens.join(', ') : '') : vens.length ? U.cap(vens.join(', ')) : l.retired ? 'Đã nghỉ hưu' + (l.peakTitle ? ' (trước là ' + l.peakTitle + ')' : '') : l.school ? 'Đang đi học' : l.age < 15 ? 'Còn nhỏ' : 'Chưa có việc làm';
    P.jobInfo = [];
    if (c) {
      if (l.job.yrs) P.jobInfo.push('đã làm ' + (l.job.sen || l.job.yrs) + ' năm');
      if (insured(l)) P.jobInfo.push('hợp đồng chính thức, có đóng ' + E.siLabel(l));
      var fit = fitOf(l, c); if (fit > 0) P.jobInfo.push('đúng sở trường — năng suất cao'); else if (fit < 0) P.jobInfo.push('không đúng sở thích — dễ căng thẳng');
      if (l.rentVeh) P.jobInfo.push('đang thuê ' + l.rentVeh.n);
    }
    var y = l.yr || {};
    P.salary = y.gross > 0 ? { gross: y.gross / 12, net: (y.gross - (y.si || 0)) / 12 } : l.income > 0 ? { gross: l.income / 12, net: l.income / 12 } : null;
    P.si = l.si ? { yrs: l.si.yrs, pension: l.pensionInc ? l.pensionInc / 12 : null } : null;
    P.income = incomeParts(l);
    // tài sản
    var A = l.assets || {}, as = [];
    if (l.indep || l.money > 0) as.push(['Tiền mặt / tài khoản', l.money]);
    ['save', 'gold', 'stock', 'land'].forEach(function (k) { if (A[k] > 0.5) as.push([U.cap((E.ASSET_NAME || {})[k] || k), A[k]]); });
    if (l.ownHouse && l.houseVal > 0) as.push([U.cap(l.houseName && l.houseName !== 'nhà riêng' ? l.houseName : 'nhà ở'), l.houseVal]);
    (l.props || []).forEach(function (p) { as.push([U.cap(p.n), p.v]); });
    (l.ventures || []).forEach(function (v) { as.push([U.cap(v.n) + (v.br > 1 ? ' (' + v.br + ' cơ sở)' : ''), v.cap]); });
    if (l.veh && l.vehVal > 0) as.push([U.cap(l.vehName || l.veh), l.vehVal]);
    var debt = H.debtTotal(l) + (l.mortgage || 0); if (debt > 0.5) as.push(['Các khoản nợ', -debt]);
    P.assets = as; P.net = E.netWorth(l);
    // sở thích, năng khiếu
    P.hobbies = [];
    if (l.hobby && hobbyName(l)) P.hobbies.push({ n: hobbyName(l), lv: E.talentLevel(l, l.hobbySk || 0) });
    if (l.idol) P.hobbies.push({ n: 'thần tượng ' + l.idol });
    if (l.game && l.age < 40) P.hobbies.push({ n: 'chơi game ' + l.game });
    P.talent = l.talent ? { n: E.talentText(l), lv: E.talentLevel(l) } : null;
    // học vấn & bằng cấp
    var ed = [], e = l.edu || 0;
    if (e >= 1) ed.push('Tốt nghiệp tiểu học'); if (e >= 2) ed.push('Tốt nghiệp trung học cơ sở'); if (e >= 3) ed.push('Tốt nghiệp trung học phổ thông');
    if (e === 4) ed.push('Bằng trung cấp / cao đẳng nghề');
    if (e >= 5) ed.push('Bằng cử nhân / kỹ sư' + (l.major && (l.majorName || E.MAJORS[l.major]) ? ' ngành ' + (l.majorName || E.MAJORS[l.major]) : '') + (l.uniCity ? ' (' + l.uniCity + ')' : ''));
    if (e >= 6) ed.push('Bằng thạc sĩ'); if (e >= 7) ed.push('Học vị tiến sĩ');
    if (l.school) ed.push('Đang học: ' + E.schoolName(l.school) + (l.schoolEnd ? ' (dự kiến xong năm ' + yr(l, l.schoolEnd) + ')' : ''));
    P.eduLevel = l.age < 6 ? 'Chưa đến tuổi đi học' : U.cap(E.EDU[e] || '');
    P.edu = ed;
    // chứng chỉ, bằng lái
    var ct = [];
    Object.keys(l.lang || {}).forEach(function (k) { if (!l.lang[k]) return; var exp = EXPIRE[k], at = (l.langAt || {})[k]; ct.push(H.langCert(l, k) + (exp ? (l.langExp && l.langExp[k] ? ' · đã hết hạn' : at != null ? ' · còn hạn đến năm ' + yr(l, at + exp) : '') : ' · không thời hạn')); });
    if (l.lic && l.lic.A1) ct.push('Bằng lái xe máy A1 · không thời hạn');
    if (l.lic && l.lic.A) ct.push('Bằng lái xe mô tô A · không thời hạn');
    if (l.lic && l.lic.B) ct.push('Bằng lái ô tô B' + (l.licAt && l.licAt.B != null ? ' · hết hạn năm ' + yr(l, l.licAt.B + 10) : ''));
    else if (l.flags.licExpB) ct.push('Bằng lái ô tô B · đã hết hạn (năm ' + l.flags.licExpB + ')');
    P.certs = ct;
    // thành tựu
    var ach = [], seen = {};
    (l.medals || []).forEach(function (m) { var t = 'Huy chương ' + m.m + ' ' + m.ev; if (!seen[t]) { seen[t] = 1; ach.push({ y: m.y, t: t }); } });
    (l.titles || []).forEach(function (t) { if (!seen[t]) { seen[t] = 1; ach.push({ y: null, t: 'Danh hiệu ' + t }); } });
    // chỉ thành tựu của chính mình — bỏ chuyện bố mẹ, anh chị em, bạn đời, con cái được thăng chức, tốt nghiệp…
    var others = [l.partner && l.partner.name, l.fam && l.fam.mName, l.fam && l.fam.fName, l.bff && l.bff.name].concat((l.kids || []).map(function (k) { return k.name; }), (l.sibList || []).map(function (s) { return s.n; })).filter(Boolean);
    var notMine = /^(Mẹ|Bố|Con |Anh |Chị |Em |Vợ |Chồng |Cháu |Người yêu |Bạn đời |Bạn thân )/;
    (l.log || []).forEach(function (x) {
      if ((x.k === 'big' || x.k === 'good') && ACH.test(x.t) && !seen[x.t] && !notMine.test(x.t) && !/^\p{Lu}\p{Ll}* \p{Lu}/u.test(x.t) && !others.some(function (n) { return x.t.indexOf(n) >= 0; })) { seen[x.t] = 1; ach.push({ y: x.y, a: x.a, t: x.t }); }
    });
    P.ach = ach.slice(-30);
    P.stress = l.mind ? { v: Math.round(l.mind.stress), label: E.stressLabel(l.mind.stress) } : null;
    return P;
  };

  // ===================================================================
  // 12. v3.1 — LỰA CHỌN THƯỜNG NGÀY THEO NƠI ĐANG SỐNG; VỀ THĂM BỐ MẸ TỐN TIỀN THEO KHOẢNG CÁCH; GỢI Ý CHI PHÍ
  // ===================================================================
  var ZONE_REG = { MNPB: 'N', DBSH: 'N', BTB: 'C', NTB: 'C', TN: 'S', DNB: 'S', DBSCL: 'S' };
  function zoneOfCity(c) {
    if (!c) return null;
    if (/Hà Nội|Hải Phòng|Thái Nguyên|Bắc Ninh|Nam Định|Hạ Long|Lào Cai/.test(c)) return 'N';
    if (/Đà Nẵng|Huế|Vinh|Quy Nhơn|Nha Trang|Thanh Hóa|Quảng/.test(c)) return 'C';
    if (/Hồ Chí Minh|Cần Thơ|Thủ Dầu Một|Biên Hòa|Vũng Tàu|Buôn Ma Thuột|Đà Lạt/.test(c)) return 'S';
    return null;
  }
  function homeZone(l) { return ZONE_REG[l.region] || 'S'; }
  // bạn đang sống ở đâu: nước nào, miền nào (Việt Nam)
  function where(l) {
    if (l.abroad) return { vn: false, country: l.abroad.name, code: l.abroad.code, perm: !!l.abroad.perm };
    if (!isVN(l)) return { vn: false, country: l.countryName, code: l.country, home: true };
    var city = (l.cityStudent && l.cityStudent.city) || l.movedTo || null;
    return { vn: true, city: city, zone: zoneOfCity(city) || homeZone(l), away: !!city };
  }
  E.where = where;
  // chuyến về thăm bố mẹ: xa hay gần, đi bằng gì, tốn bao nhiêu
  function trip(l) {
    var w = where(l), home = isVN(l) ? (l.provLabel || (l.prov && l.prov.old) || 'quê nhà') : (l.city || l.countryName);
    if (livesWith(l)) return { same: true, cost: 0, how: 'ở cùng nhà', to: home };
    if (!isVN(l) && !l.abroad) return { same: false, cost: l.base * 0.01, how: 'về nhà bố mẹ', to: home, near: true };
    if (!w.vn) { var farC = /Hoa Kỳ|Canada|Úc|Anh|Đức|Pháp|châu Âu|New Zealand|Ý|Hà Lan|Thụy|Ba Lan|Séc/.test(w.country); return { same: false, abroad: true, cost: isVN(l) ? V(l, farC ? 28 : 10) : l.base * (farC ? 0.25 : 0.1), how: 'mua vé máy bay từ ' + w.country + ' về', to: home }; }
    if (!w.away) return { same: false, near: true, cost: V(l, 0.3), how: 'chạy xe sang nhà bố mẹ', to: home };
    if (w.zone === homeZone(l)) return { same: false, mid: true, cost: V(l, 1.3), how: 'bắt xe khách từ ' + w.city + ' về quê', to: home };
    return { same: false, flight: true, cost: V(l, 4), how: 'mua vé máy bay từ ' + w.city + ' về quê', to: home };
  }
  E.homeTrip = trip;
  // v3.8.1: đang sống cùng nhà với bố mẹ (đã đón bố mẹ về ở cùng, hoặc chưa ra ở riêng, chưa lập gia đình)
  function livesWith(l) { return !!(l.flags.caring || (!l.indep && !l.abroad && !l.cityStudent && !l.movedTo)); }
  E.livesWithParents = livesWith;
  function pw(l) { return l.fam.mAlive && l.fam.fAlive && !l.fam.noDad ? 'bố mẹ' : l.fam.mAlive ? 'mẹ' : (l.fam.fAlive && !l.fam.noDad) ? 'bố' : ''; }
  if (E.DEC.tham_bo_me) {
    var TB = E.DEC.tham_bo_me.def, goOld = TB.opts.filter(function (o) { return o.k === 'go'; })[0];
    TB.valid = function (l) { return !!pw(l); };
    TB.text = function (l) {
      var f = l.fam, a = l.age, p = pw(l), t = trip(l);
      var ages = p === 'bố mẹ' ? (f.mAge + a) + ' và ' + (f.fAge + a) : p === 'mẹ' ? (f.mAge + a) : (f.fAge + a);
      return U.cap(p) + ' giờ đã ' + ages + ' tuổi' + (p === 'bố mẹ' ? '' : ', ở một mình từ ngày ' + (p === 'mẹ' ? 'bố' : 'mẹ') + ' mất') + '. ' +
        (t.same ? 'Bạn đang sống cùng nhà với ' + p + '.' : t.near ? 'Nhà ' + p + ' ở gần, chạy xe một lát là tới.' : 'Bạn đang ở ' + (where(l).city || where(l).country) + ', ' + p + ' ở ' + t.to + ' — muốn về phải ' + t.how + ' (đi lại, quà cáp khoảng ' + mo(l, t.cost) + ').') + ' Lâu rồi bạn chưa dành thời gian cho ' + p + '.';
    };
    TB.opts = [
      { k: 'go', l: function (l) { var t = trip(l), p = pw(l); return t.same ? 'Dành trọn một ngày cho ' + p + ' (đưa đi chơi, đi chùa, đi khám…)' : t.abroad ? 'Bay về Việt Nam thăm ' + p : t.flight ? 'Bay về quê thăm ' + p : t.mid ? 'Bắt xe khách về quê thăm ' + p : 'Về ăn cơm với ' + p; },
        h: function (l) { var t = trip(l); return t.cost > 0 ? (t.abroad || t.flight ? 'Vé máy bay khứ hồi, quà cáp' : t.mid ? 'Vé xe khách, quà cáp' : 'Xăng xe, ít quà') + ' ~' + mo(l, t.cost) : 'Không tốn tiền'; },
        run: function (l, r, log) {
          var t = trip(l), p = pw(l);
          if (t.same) { var tx = pick(r, ['Sáng đưa ' + p + ' đi chợ, chiều cả nhà cùng nấu một bữa cơm thịnh soạn.', 'Đưa ' + p + ' đi chùa, rồi dạo công viên, chụp mấy tấm ảnh kỷ niệm.', 'Cả ngày ngồi nghe ' + p + ' kể chuyện ngày xưa, tiện tay sửa cái quạt, thay bóng đèn.', 'Đưa ' + p + ' đi khám sức khỏe định kỳ, trưa ghé quán bún quen ăn cùng nhau.', 'Tắt điện thoại, cả ngày chỉ ở bên ' + p + ': pha ấm trà, xem lại album ảnh cũ.']); H.cash(l, -V(l, 0.3), 'Đưa ' + p + ' đi chơi'); log(tx, 'good'); fx(l, { hap: 5, soc: 3, karma: 2 }); H.mem(l, tx, 3); return; }
          if (t.cost > 0) H.cash(l, -t.cost, (t.abroad ? 'Vé máy bay về nước thăm ' : t.flight ? 'Vé máy bay về quê thăm ' : t.mid ? 'Vé xe về quê thăm ' : 'Về thăm ') + p);
          var m0 = l.money, it = (l.yr || { items: [] }).items, n0 = it.length;
          goOld.run(l, r, function (txt, k) { log((t.abroad ? 'Bay về Việt Nam sau bao lâu xa nhà. ' : t.flight || t.mid ? U.cap(t.how) + '. ' : '') + txt, k); });
          l.money = m0; it.splice(n0, it.length - n0); // chi phí đã tính theo khoảng cách ở trên
          if (t.abroad || t.flight) fx(l, { hap: 3 });
        } },
      { k: 'week', l: function (l) { return 'Xin nghỉ phép, về ở với ' + pw(l) + ' cả tuần'; }, req: function (l) { return !trip(l).same && !trip(l).near; }, h: function (l) { return 'Tiền đi lại & quà ~' + mo(l, trip(l).cost * 1.3) + (l.job ? ', mất vài ngày công' : ''); },
        run: function (l, r, log) { var t = trip(l), p = pw(l); H.cash(l, -t.cost * 1.3, 'Về quê ở với ' + p + ' một tuần'); if (l.job && l.income > 0) H.cash(l, -l.income / 52, 'Nghỉ không lương'); log('Về ở với ' + p + ' trọn một tuần — ' + pick(r, ['sáng đi chợ, chiều nấu cơm, tối ngồi nghe kể chuyện ngày xưa.', 'sửa lại mái nhà dột, dọn khu vườn cỏ mọc um tùm.', 'đưa ' + p + ' đi khám sức khỏe, mua thêm ít đồ dùng trong nhà.']), 'good'); fx(l, { hap: 9, soc: 4, karma: 3 }); if (l.mind) l.mind.stress -= 8; H.mem(l, 'Một tuần ở nhà với ' + p + ', thấy mình như đứa trẻ ngày nào.', 4); } },
      { k: 'call', l: 'Gọi video hỏi thăm', h: 'Không tốn tiền', req: function (l) { return !trip(l).same; }, run: function (l, r, log) { var p = pw(l); log('Gọi video cho ' + p + ' gần một tiếng. ' + pick(r, [U.cap(p) + ' cứ dặn đi dặn lại phải giữ sức khỏe.', U.cap(p) + ' khoe mấy chuyện ở quê, cười suốt.', 'Thấy ' + p + ' gầy đi, bạn hứa sẽ sớm về.']), 'good'); fx(l, { hap: 2, soc: 1 }); } },
      { k: 'an_toi', l: function (l) { return 'Tối nay về sớm, ăn cơm cùng ' + pw(l); }, h: 'Không tốn tiền', req: function (l) { return trip(l).same; }, run: function (l, r, log) { var p = pw(l); log('Về sớm ăn cơm tối cùng ' + p + '. ' + pick(r, [U.cap(p) + ' gắp cho bạn miếng ngon nhất, kể chuyện hàng xóm cả buổi.', 'Ăn xong cả nhà ngồi xem thời sự, ' + p + ' hỏi han chuyện công việc.', U.cap(p) + ' vui hẳn, bảo lâu lắm rồi mới thấy bạn về sớm.']), 'good'); fx(l, { hap: 3, soc: 2, karma: 1 }); } },
      { k: 'send', l: function (l) { return (trip(l).same ? 'Biếu ' : 'Gửi tiền về biếu ') + pw(l); }, req: function (l) { return l.indep && l.money > l.base * 0.12; }, h: function (l) { return '~' + mo(l, l.base * 0.1); }, run: function (l, r, log) { H.cash(l, -l.base * 0.1, 'Gửi tiền biếu ' + pw(l)); if (trip(l).same) { log('Dúi vào tay ' + pw(l) + ' một khoản tiền tiêu vặt, ' + pw(l) + ' mắng "bày vẽ" mà mắt cười.', 'good'); fx(l, { hap: 3, karma: 2 }); return; } log('Chuyển khoản biếu ' + pw(l) + ' một khoản, ' + pw(l) + ' gọi lại mắng "tiêu xài hoang phí" mà giọng vui hẳn.', 'good'); fx(l, { hap: 3, karma: 2 }); } }
    ];
  }
  // Tết về quê: xa nhà thì tốn tiền vé
  E.EVENTS.forEach(function (ev) {
    var src = ev.run.toString();
    if (/Về quê ăn Tết, gói bánh chưng/.test(src)) {
      var run0 = ev.run;
      ev.run = function (l, a, r, log) {
        run0.call(this, l, a, r, function (t, k) {
          if (/^Về quê ăn Tết/.test(t)) { var tp = trip(l); if (!tp.same && !tp.near && !tp.abroad && tp.cost > 0) { H.cash(l, -tp.cost * 1.5, 'Vé xe / máy bay về quê ăn Tết'); t = U.cap(tp.how) + ' ăn Tết (vé mùa Tết đắt gấp rưỡi), gói bánh chưng cùng gia đình.'; } }
          log(t, k);
        });
      };
    }
    // phong tục ở quê (tảo mộ, giỗ, ông Công ông Táo, hang đá cả xứ…) chỉ khi đang sống ở Việt Nam
    if (/Thanh minh|ông Công ông Táo|Ngày giỗ ông|Rằm tháng Giêng|tảo mộ|hang đá Giáng sinh|xứ đạo|rước kiệu/.test(src)) {
      var c0 = ev.c; ev.c = function (l, a) { return !(l.abroad && !l.abroad.perm) && c0.apply(this, arguments); };
    }
  });

  // địa điểm du lịch, dã ngoại, đi phượt theo nơi đang sống
  var VN_TRAVEL = { N: ['Sa Pa', 'Hạ Long', 'Ninh Bình', 'Hà Giang', 'Mộc Châu', 'Cát Bà'], C: ['Hội An', 'Huế', 'Quy Nhơn', 'Phong Nha', 'Nha Trang', 'Đà Lạt'], S: ['Vũng Tàu', 'Phú Quốc', 'Đà Lạt', 'Côn Đảo', 'Mũi Né', 'Cần Thơ'] };
  var VN_NATURE = { N: ['vườn quốc gia Cúc Phương', 'vườn quốc gia Ba Vì', 'Tam Đảo', 'Fansipan', 'núi Mẫu Sơn'], C: ['vườn quốc gia Bạch Mã', 'Bà Nà', 'bán đảo Sơn Trà', 'Phong Nha – Kẻ Bàng'], S: ['núi Bà Đen', 'vườn quốc gia Cát Tiên', 'đỉnh Langbiang', 'Tà Năng – Phan Dũng', 'núi Chứa Chan'] };
  var VN_PHUOT = { N: ['Hà Giang', 'Tà Xùa', 'Mộc Châu', 'Mù Cang Chải'], C: ['Măng Đen', 'đèo Hải Vân', 'Lý Sơn', 'Phú Yên'], S: ['Đà Lạt', 'Côn Đảo', 'Mũi Né', 'quần đảo Nam Du'] };
  var SPOTS = {
    'Nhật Bản': [['Kyoto', 'Hokkaido', 'Okinawa', 'Osaka'], ['núi Phú Sĩ', 'vườn quốc gia Nikko', 'rừng tre Arashiyama']],
    'Hàn Quốc': [['đảo Jeju', 'Busan', 'Gyeongju'], ['núi Seorak', 'núi Bukhansan', 'núi Hallasan']],
    'Đài Loan': [['Đài Trung', 'Cao Hùng', 'Hoa Liên'], ['núi A Lý', 'hẻm núi Thái Lỗ Các', 'Ngọc Sơn']],
    'Trung Quốc': [['Quế Lâm', 'Thượng Hải', 'Tây An'], ['Trương Gia Giới', 'Hoàng Sơn']],
    'Thái Lan': [['Phuket', 'Chiang Mai', 'Pattaya'], ['núi Doi Inthanon', 'vườn quốc gia Khao Yai']],
    'Singapore': [['đảo Sentosa', 'Vịnh Marina'], ['khu bảo tồn MacRitchie', 'đồi Bukit Timah']],
    'Malaysia': [['Penang', 'Langkawi', 'Malacca'], ['cao nguyên Cameron', 'núi Kinabalu']],
    'Úc': [['Gold Coast', 'Melbourne', 'Tasmania'], ['dãy Blue Mountains', 'công viên Grampians']],
    'Hoa Kỳ': [['Las Vegas', 'San Francisco', 'Hawaii', 'New York'], ['công viên Yosemite', 'hẻm núi Grand Canyon', 'Yellowstone']],
    'Canada': [['Vancouver', 'Québec', 'Toronto'], ['công viên Banff', 'thác Niagara']],
    'Anh': [['Edinburgh', 'Bath', 'Cornwall'], ['vùng hồ Lake District', 'vườn quốc gia Snowdonia']],
    'Đức': [['Munich', 'Hamburg', 'Berlin'], ['Rừng Đen', 'dãy Alps vùng Bavaria']],
    'Pháp': [['Nice', 'Lyon', 'Bordeaux'], ['dãy Alps', 'vùng Provence']]
  };
  function spots(w, i) { var s = SPOTS[w.country]; return s ? s[i] : [i ? 'một công viên quốc gia ở ' + w.country : 'một thành phố biển ở ' + w.country]; }
  function vnPick(r, T, w) { return r() < 0.7 ? pick(r, T[w.zone]) : pick(r, [].concat(T.N, T.C, T.S)); }
  function nearTrip(l, r) { var w = where(l); return w.vn ? vnPick(r, VN_TRAVEL, w) : pick(r, spots(w, 0)); }
  function natureSpot(l, r) { var w = where(l); return w.vn ? vnPick(r, VN_NATURE, w) : pick(r, spots(w, 1)); }
  function phuotSpot(l, r) { var w = where(l); return w.vn ? vnPick(r, VN_PHUOT, w) : pick(r, spots(w, 1).concat(spots(w, 0))); }
  E.nearTrip = nearTrip; E.natureSpot = natureSpot;
  if (E.DEC.leo_nui) E.DEC.leo_nui.def.prep = function (l, r) { return { p: natureSpot(l, r) }; };
  if (E.DEC.phuot) E.DEC.phuot.def.prep = function (l, r) { return { p: phuotSpot(l, r) }; };
  if (E.DEC.du_lich) {
    var DL = E.DEC.du_lich.def, dl0 = DL.prep;
    DL.prep = function (l, r) {
      var d = dl0.apply(this, arguments), w = where(l);
      d.near = nearTrip(l, r);
      if (!w.vn && (d.far === w.country)) d.far = 'Việt Nam';
      return d;
    };
  }
  E.EVENTS.forEach(function (ev) {
    if (/'Đi du lịch ' \+ dest/.test(ev.run.toString())) {
      ev.run = function (l, a, r, log) {
        var w = where(l), abroadTrip = l.money > l.base * 2 && r() < 0.5;
        var dest = abroadTrip ? pick(r, ['Thái Lan', 'Hàn Quốc', 'Nhật Bản', 'Singapore', 'Đài Loan', 'châu Âu'].filter(function (x) { return x !== w.country; })) : nearTrip(l, r);
        var cost = abroadTrip ? 0.15 : 0.05;
        H.cash(l, -l.base * cost, 'Du lịch'); H.visit(l, dest);
        log('Đi du lịch ' + dest + (l.partner ? ' cùng ' + H.partnerWord(l, l.partner) : '') + '.', 'good'); fx(l, { hap: 4 });
      };
    }
  });

  // gợi ý chi phí cho lựa chọn chưa ghi giá: chạy thử lựa chọn trên một bản sao của nhân vật
  E.optCosts = function (l, d) {
    var res = {}, D = E.DEC[d && d.id]; if (!D || !d.opts) return res;
    var base;
    try { base = JSON.stringify(l); } catch (e) { return res; }
    d.opts.forEach(function (o) {
      if (o.h && /\d/.test(o.h)) return; // đã ghi giá
      var nets = [];
      for (var t = 0; t < 3; t++) {
        try {
          var c = JSON.parse(base); c.pending = []; c.yr = { items: [] }; c.rs = (c.rs + 7919 * (t + 1)) | 0; c.log = c.log.slice(-30);
          D.apply(c, JSON.parse(JSON.stringify(d)), o.k, function () { return U.rand(c); }, function () { });
          var net = 0; c.yr.items.forEach(function (x) { if (!/^Vay /.test(x.t)) net += x.v; });
          nets.push(net);
        } catch (e) { return; }
      }
      if (!nets.length) return;
      var lo = Math.min.apply(null, nets), hi = Math.max.apply(null, nets), thr = l.base * 0.002;
      if (hi <= -thr) res[o.k] = 'Chi phí khoảng ' + mo(l, -hi) + (lo < hi * 1.3 ? ' – ' + mo(l, -lo) : '');
      else if (lo <= -thr) res[o.k] = 'Có thể tốn đến ' + mo(l, -lo);
    });
    return res;
  };
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
/* ===== js/life32.js ===== */
/* Một Đời — v3.2:
   · nhà ở chia theo loại (nhà cấp 4, chung cư mini, chung cư cũ, chung cư thương mại, nhà phố, chung cư cao cấp, biệt thự, dinh thự), giá theo nơi ở
   · bệnh viện công (xếp hàng lấy số từ sáng sớm, nằm ghép, chờ lấy thuốc) và bệnh viện tư; phẫu thuật; răng khôn mọc lệch
   · nghề diễn viên: casting, cát-xê web drama / phim truyền hình / điện ảnh, doanh thu phòng vé, hợp đồng quảng cáo, học diễn xuất, game show
   · nhắn tin tán tỉnh (bị ghost, mập mờ), chênh lệch tuổi trong tình yêu, biệt danh hội bạn đặt
   · thi lại chứng chỉ ngoại ngữ trong "Việc bạn muốn làm" · tiền mã hóa theo tỉ lệ thực tế hơn */
(function (G) {
  'use strict';
  var U = G.U, E = G.E, H = E.H, SC = E.SC, isVN = H.isVN;
  function T(id, when, p, cd, max) { E.TRIG.push({ id: id, when: when, p: p, cd: cd || 0, max: max }); }
  function A(id, g, label, o) { var x = { id: id, g: g, l: label }; for (var k in o) x[k] = o[k]; E.ACT.push(x); }
  function EV(c, p, run) { E.EVENTS.push({ c: c, p: p, run: run }); }
  function fx(l, o) { H.fx(l, o); }
  function mo(l, v) { return H.money(l, v); }
  function pick(r, a) { return U.pick(r, a); }
  function ch(r, p) { return r() < p; }
  function free(l) { return !(l.jailUntil != null && l.age < l.jailUntil) && !(l.abroad && l.abroad.trapped); }
  function vnd(l) { return isVN(l) && l.cur === 'vnd' && !(l.abroad && l.abroad.perm); }
  function V(l, tr) { return vnd(l) ? tr : tr / 90 * l.base; }
  function rng(r, a, b) { return a + (b - a) * r(); }
  function jobC(l) { return l.job ? E.jobDef(l) : null; }
  function rich(l) { return l.money > l.base * 8 || (!l.indep && l.fam.q >= 5); }

  // ===================================================================
  // 1. NHÀ Ở THEO LOẠI
  // ===================================================================
  // giá tham khảo (triệu đồng, làm tròn): big = Hà Nội / TP.HCM · urb = thành phố, thị xã tỉnh · rur = nông thôn
  var HT = [
    { k: 'cap4', n: 'nhà cấp 4', t: 1, p: { big: 2600, urb: 1200, rur: 450 }, d: 'nhà một tầng mái ngói / mái tôn, có sân nhỏ' },
    { k: 'mini', n: 'căn hộ chung cư mini', t: 1, p: { big: 1300, urb: 750 }, d: '35–45 m², trong hẻm, pháp lý thường không chắc' },
    { k: 'cu', n: 'căn hộ chung cư cũ (khu tập thể)', t: 1, p: { big: 2000, urb: 900 }, d: 'rộng nhưng xuống cấp, ít khi có thang máy' },
    { k: 'cc', n: 'căn hộ chung cư thương mại 2 phòng ngủ', t: 2, p: { big: 3800, urb: 1900 }, d: 'thang máy, bảo vệ, khu vui chơi cho trẻ' },
    { k: 'lau', n: 'nhà phố 3–4 tầng', t: 2, p: { big: 8000, urb: 3200, rur: 1600 }, d: 'nhà lầu mặt ngõ / mặt đường, vừa ở vừa kinh doanh được' },
    { k: 'ccc', n: 'căn hộ chung cư cao cấp', t: 3, p: { big: 9000, urb: 4000 }, d: 'hồ bơi, phòng gym, view đẹp, phí quản lý cao' },
    { k: 'bt', n: 'biệt thự có sân vườn', t: 4, p: { big: 30000, urb: 12000, rur: 6000 }, d: 'sân vườn rộng, gara ô tô' },
    { k: 'dt', n: 'dinh thự', t: 5, p: { big: 100000, urb: 45000, rur: 20000 }, d: 'hàng nghìn m², có người giúp việc, bảo vệ riêng' }
  ];
  // v3.6: sống ở nước ngoài (định cư, hoặc sinh ra ở nước khác) thì mua nhà theo kiểu và giá của nước đó — giá tính theo số năm thu nhập trung bình ở đó
  var HTW = [
    { k: 'w_studio', n: 'căn hộ studio', t: 1, m: { big: 7, urb: 4.5, rur: 3 }, d: 'một phòng, gọn cho người độc thân' },
    { k: 'w_apt', n: 'căn hộ 2 phòng ngủ', t: 2, m: { big: 11, urb: 7, rur: 4.5 }, d: 'chung cư có thang máy, gần phương tiện công cộng' },
    { k: 'w_town', n: 'nhà liền kề (townhouse)', t: 2, m: { big: 14, urb: 9, rur: 6 }, d: '2 tầng, có sân sau nhỏ, gara một xe' },
    { k: 'w_house', n: 'nhà riêng có sân vườn ở ngoại ô', t: 3, m: { big: 20, urb: 12, rur: 8 }, d: '3–4 phòng ngủ, gara, sân vườn rộng' },
    { k: 'w_villa', n: 'biệt thự', t: 4, m: { big: 50, urb: 30, rur: 18 }, d: 'khu nhà giàu, hồ bơi riêng' },
    { k: 'w_mansion', n: 'dinh thự', t: 5, m: { big: 150, urb: 90, rur: 55 }, d: 'hàng nghìn m², nhân viên phục vụ riêng' }
  ];
  function abroadRes(l) { return !vnd(l); }
  function resCity(l) { var W = G.W, c = W && W.BY[l.abroad && l.abroad.perm ? l.abroad.code : l.country]; return { place: l.place || l.city || (c && c.cities[0]) || 'thành phố', big: !!(c && (l.place || l.city) && c.cities.slice(0, 2).indexOf(l.place || l.city) >= 0) }; }
  function cls(l) { if (abroadRes(l)) { var rc = resCity(l); return rc.big ? 'big' : l.urban ? 'urb' : 'rur'; } return H.inBigCity(l) ? 'big' : (l.urban || l.movedTo) ? 'urb' : 'rur'; }
  function hPrice(l, h, r) {
    var c = cls(l);
    if (h.m) { var g = (G.W && G.W.BY[l.abroad && l.abroad.perm ? l.abroad.code : l.country] || {}).gdp || l.gdp || 20; return h.m[c] * g * 1000 * 0.55 * (l.urban ? 1.1 : 0.8) * (g < 8 ? 1.6 : g < 20 ? 1.25 : 1) * (r ? rng(r, 0.9, 1.15) : 1); } // nước thu nhập thấp: giá nhà / thu nhập cao hơn
    var p = h.p[c] != null ? h.p[c] : h.p.urb;
    if (!vnd(l)) return p / 90 * l.base * 0.35 * (r ? rng(r, 0.9, 1.15) : 1);
    return Math.round(p * (c !== 'big' && l.cityWealth ? Math.min(1.3, Math.max(0.7, l.cityWealth)) : 1) * (r ? rng(r, 0.88, 1.18) : 1));
  }
  function avail(l) { if (abroadRes(l)) return HTW; var c = cls(l); return HT.filter(function (h) { return h.p[c] != null; }); }
  function homeDebt(l) { return (l.loans || []).filter(function (x) { return x.type === 'home'; }).reduce(function (s, x) { return s + x.bal; }, 0) + (l.mortgage || 0); }
  function have(l) { return Math.max(0, l.money) + (l.ownHouse ? Math.max(0, (l.houseVal || 0) - homeDebt(l)) : 0); }
  function canLoan(l, price) { return l.indep && H.canBankLoan(l) && H.loanAgeOk(l, 'home') && (l.income || 0) > 0 && price * 0.7 <= Math.max(l.income || 0, l.base * 0.5) * 9; }
  E.homeMin = function (l) { return Math.min.apply(null, avail(l).map(function (h) { return hPrice(l, h); })); };
  E.HOME_TYPES = HT; E.HOME_TYPES_W = HTW;
  function buyHome(l, h, price, loan, log) {
    if (l.ownHouse) {
      var sold = l.houseVal || 0, debt = homeDebt(l);
      H.cash(l, sold, 'Bán ' + (l.houseName || 'nhà cũ'));
      (l.loans || []).forEach(function (x) { if (x.type === 'home') { H.cash(l, -x.bal, 'Tất toán khoản vay mua nhà cũ'); x.bal = 0; } });
      l.loans = (l.loans || []).filter(function (x) { return x.bal > 0.5; }); if (l.mortgage) { H.cash(l, -l.mortgage, 'Tất toán khoản vay mua nhà cũ'); l.mortgage = 0; }
      log('Bán ' + (l.houseName || 'căn nhà cũ') + ' được ' + mo(l, sold) + (debt > 0.5 ? ', trả hết ' + mo(l, debt) + ' nợ ngân hàng' : '') + '.', 'neutral');
    }
    H.cash(l, -price, 'Mua ' + h.n);
    if (loan) H.addLoan(l, 'home', price * 0.7);
    var first = !l.flags.ownedHome;
    l.ownHouse = true; l.houseVal = price; l.houseTier = h.t; l.houseName = h.n; l.houseK = h.k; l.flags.ownedHome = true;
    log('Mua ' + h.n + ' giá ' + mo(l, price) + (loan ? ' (trả trước 30%, vay ngân hàng 70%, trả góp nhiều năm)' : ' bằng tiền tích lũy') + '.', h.t >= 4 ? 'big' : 'big');
    fx(l, { hap: 6 + h.t * 2 });
    H.mem(l, first ? 'Ngày nhận chìa khóa ' + h.n + ' — căn nhà đầu tiên của chính mình.' : 'Ngày chuyển về ' + h.n + '.', first ? 5 : 3);
  }
  function okH(l, d, h) { var p = d.pr[h.k]; if (p == null) return false; if (d.up && !(h.t > (l.houseTier || 1) || (h.t === (l.houseTier || 1) && p > (l.houseVal || 0) * 1.3 && h.k !== l.houseK))) return false; return have(l) >= p || (have(l) >= p * 0.3 && canLoan(l, p)); }
  function homeDef(up) {
    return {
      title: up ? 'Đổi nhà' : 'Mua nhà', major: up ? 0 : 1,
      prep: function (l, r) { var pr = {}; avail(l).forEach(function (h) { pr[h.k] = hPrice(l, h, r); }); return { pr: pr, up: up }; },
      valid: function (l) { return up ? !!l.ownHouse && l.indep : !l.ownHouse; },
      text: function (l, d) {
        return (l.ownHouse ? 'Bạn đang ở ' + (l.houseName || 'nhà riêng') + ' trị giá khoảng ' + mo(l, l.houseVal) + (homeDebt(l) > 0.5 ? ' (còn nợ ngân hàng ' + mo(l, homeDebt(l)) + ')' : '') + '. ' : '') +
          'Tiền mặt hiện có ' + mo(l, Math.max(0, l.money)) + '. Giá nhà ' + (abroadRes(l) ? 'ở ' + resCity(l).place + (l.abroad && l.abroad.perm ? ', ' + l.abroad.name : '') : cls(l) === 'big' ? 'ở ' + (/Hà Nội/.test(l.movedTo || (l.prov && l.prov.old) || '') ? 'Hà Nội' : 'TP. Hồ Chí Minh') : cls(l) === 'urb' ? 'ở thành phố tỉnh' : 'ở quê') + ' tham khảo (từ rẻ đến đắt):' +
          (avail(l).some(function (h) { return okH(l, d, h); }) ? '' : ' ' + HT.filter(function (h) { return d.pr[h.k] != null; }).slice(0, 5).map(function (h) { return h.n + ' ~' + mo(l, d.pr[h.k]); }).join('; ') + '. Hiện chưa đủ tiền trả trước 30% (hoặc chưa vay được ngân hàng) cho loại nào — hãy tích lũy thêm.');
      },
      opts: HT.concat(HTW).map(function (h) {
        return {
          k: 'n_' + h.k,
          l: function (l, d) { return U.cap(h.n) + ' — ' + mo(l, d.pr[h.k]); },
          h: function (l, d) { var p = d.pr[h.k]; return h.d + ' · ' + (have(l) >= p ? 'trả thẳng được' : 'trả trước ' + mo(l, p * 0.3) + ', vay ngân hàng ' + mo(l, p * 0.7) + ' (trả góp ~' + mo(l, p * 0.7 * 0.12) + '/năm)'); },
          req: function (l, d) { return okH(l, d, h); },
          ai: function (l, d) { var p = d.pr[h.k]; return have(l) >= p ? 1 + h.t * 0.4 : 0.5; },
          run: function (l, r, log, d) { var p = d.pr[h.k], loan = have(l) < p; if (loan && !canLoan(l, p)) { log('Ngân hàng từ chối cho vay mua ' + h.n + ': ' + (H.canBankLoan(l) ? 'thu nhập không đủ.' : 'hồ sơ đang có nợ xấu.'), 'bad'); fx(l, { hap: -4 }); l.flags.houseNo = l.age + 3; return; } buyHome(l, h, p, loan, log); }
        };
      }).concat([{ k: 'no', l: up ? 'Ở nhà cũ cho quen' : 'Tiếp tục thuê / ở cùng gia đình', ai: { w: 1 }, run: function (l) { if (!up) { l.flags.houseNoN = (l.flags.houseNoN || 0) + 1; l.flags.houseNo = l.age + 5 + Math.min(10, l.flags.houseNoN * 3); } } }])
    };
  }
  SC('house', homeDef(false));
  SC('doi_nha', homeDef(true));
  E.ACT.forEach(function (a) {
    if (a.id === 'doi_nha') { a.l = function (l) { return abroadRes(l) ? 'Đổi nhà (nhà rộng hơn, biệt thự…)' : 'Đổi nhà (nhà phố, chung cư cao cấp, biệt thự…)'; }; a.avail = function (l) { return !l.ownHouse ? 'Chưa có nhà riêng' : (l.houseTier || 1) >= 5 ? 'Đã ở dinh thự' : true; }; }
    if (a.id === 'mua_nha') a.l = function (l) { return abroadRes(l) ? 'Mua nhà (căn hộ, nhà riêng…)' : 'Mua nhà (nhà cấp 4, chung cư, nhà phố…)'; };
  });

  // ===================================================================
  // 2. BỆNH VIỆN CÔNG / TƯ, PHẪU THUẬT, RĂNG KHÔN
  // ===================================================================
  var BIG_ILL = /ung thư|mạch vành|dạ dày|đại trực tràng|vú|phổi|suy thận/;
  var tm0 = E.DEC.treat.make;
  E.DEC.treat.make = function (l, r) {
    var d = tm0.apply(this, arguments), pv = rich(l) && l.gdp >= 3;
    d.data.priv = pv;
    d.opts.forEach(function (o) {
      if (o.k === 'best') { o.l = pv ? 'Điều trị ở bệnh viện tư / khoa quốc tế' : 'Lên bệnh viện tuyến trên (bệnh viện công lớn)'; o.h = (pv ? 'Phòng riêng, khám ngay, không phải chờ' : 'Bác sĩ giỏi nhưng quá tải: xếp hàng lấy số, nằm ghép giường') + ' · khoảng ' + mo(l, d.data.cost * (pv ? 1.8 : 1)) + (l.money < d.data.cost * (pv ? 1.8 : 1) ? ' — phải vay mượn' : ''); }
      if (o.k === 'basic') { o.l = 'Điều trị ở bệnh viện huyện / tỉnh gần nhà'; o.h = 'Rẻ hơn (~' + mo(l, d.data.cost * 0.25) + '), ít thiết bị, hiệu quả thấp hơn'; }
    });
    return d;
  };
  var ta0 = E.DEC.treat.apply;
  E.DEC.treat.apply = function (l, d, k, r, log) {
    var x = ta0.apply(this, arguments), ill = l.ill;
    if (k === 'best' && d.data.priv) { H.cash(l, -d.data.cost * 0.8, 'Phụ phí bệnh viện tư'); log(pick(r, ['Vào bệnh viện tư: phòng riêng, bác sĩ khám ngay trong ngày, không phải xếp hàng chờ đợi.', 'Chữa ở bệnh viện tư: đặt lịch qua điện thoại, đến là có bác sĩ khám, y tá chăm sóc tận tình.', 'Nằm phòng dịch vụ ở bệnh viện tư, người nhà được ở cùng, thuốc men đầy đủ — đắt nhưng yên tâm.']), 'neutral'); }
    else if (k === 'best') log(pick(r, ['Bệnh viện tuyến trên quá tải: 4 giờ sáng đã phải dậy xếp hàng lấy số, chờ khám đến chiều, nằm ghép giường với hai người lạ.', 'Mỗi lần tái khám lại dậy từ tờ mờ sáng bắt xe lên viện, xếp hàng lấy số, chờ kết quả xét nghiệm, rồi đứng đợi lấy thuốc cả tiếng.']), 'neutral');
    else if (k === 'basic') log('Bệnh viện gần nhà đông bệnh nhân, ít máy móc; nhiều xét nghiệm phải chuyển lên tuyến trên.', 'neutral');
    if (ill && k !== 'none' && BIG_ILL.test(ill.n) && ch(r, 0.6)) H.chain(l, 'phau_thuat', { why: 'mổ ' + ill.n, ill: true });
    return x;
  };
  SC('phau_thuat', {
    title: 'Phải phẫu thuật', major: 1,
    prep: function (l, r, arg) { return arg && arg.why ? arg : { why: 'mổ cấp cứu' }; },
    text: function (l, d) { return 'Bác sĩ chỉ định ' + d.why + '. Bạn chọn mổ ở đâu?' + (E.hasBHYT && E.hasBHYT(l) ? ' (Bạn có bảo hiểm y tế.)' : ' (Bạn không có bảo hiểm y tế.)'); },
    opts: [
      { k: 'cong', l: 'Bệnh viện công, theo bảo hiểm', h: function (l) { return 'Chờ lịch mổ vài tuần, nằm phòng đông · viện phí ~' + mo(l, V(l, 18)) + (E.medNote ? E.medNote(l, V(l, 18), 1) : ''); }, ai: function (l) { return rich(l) ? 0.3 : 1.5; }, run: function (l, r, log, d) { op(l, r, log, d, V(l, 18), 0.08, 1, 'Chờ ba tuần mới đến lịch mổ, sau mổ nằm phòng tám giường, người nhà trải chiếu ngủ dưới gầm giường.'); } },
      { k: 'dichvu', l: 'Mổ dịch vụ ở bệnh viện công, tự chọn bác sĩ', h: function (l) { return 'Mổ sớm hơn, phòng ít người · ~' + mo(l, V(l, 45)) + (E.medNote ? E.medNote(l, V(l, 45), 0.5) : ''); }, ai: { w: 1 }, run: function (l, r, log, d) { op(l, r, log, d, V(l, 45), 0.05, 0.5, 'Mổ dịch vụ, được chọn bác sĩ giỏi, nằm phòng hai giường.'); } },
      { k: 'tu', l: 'Bệnh viện tư / quốc tế', h: function (l) { return 'Mổ ngay, phòng riêng, chăm sóc chu đáo · ~' + mo(l, V(l, 140)); }, req: function (l) { return l.money > V(l, 140) * 0.5; }, ai: function (l) { return rich(l) ? 2 : 0.2; }, run: function (l, r, log, d) { op(l, r, log, d, V(l, 140), 0.04, 0, 'Mổ ở bệnh viện tư: phòng riêng như khách sạn, y tá túc trực cả ngày.'); } }
    ]
  });
  function op(l, r, log, d, cost, risk, cover, txt) {
    if (E.medBill) E.medBill(l, cost, 'Phẫu thuật: ' + d.why, log, cover); else H.cash(l, -cost, 'Phẫu thuật: ' + d.why);
    if (ch(r, risk)) { log(txt + ' Sau mổ bị biến chứng, phải nằm viện thêm một tháng.', 'bad'); fx(l, { hea: -8, hap: -6 }); if (E.medBill) E.medBill(l, cost * 0.3, 'Điều trị biến chứng sau mổ', log, cover); else H.cash(l, -cost * 0.3, 'Điều trị biến chứng sau mổ'); }
    else { log(txt + ' Ca mổ thành công.', 'good'); fx(l, { hea: d.ill ? 3 : 6, hap: 2 }); }
    if (d.ill && l.ill) { l.ill.cure = Math.min(0.95, l.ill.cure * 1.35); l.ill.mult = Math.max(1, l.ill.mult * 0.85); }
    H.mem(l, 'Lần nằm trên bàn mổ — ' + d.why + '.', 3);
  }
  EV(function (l, a) { return a >= 16 && a <= 75 && (l.veh === 'xe máy' || l.veh === 'ô tô') && free(l); }, 0.005, function (l, a, r, log) { log('Bị tai nạn giao thông, gãy xương phải mổ.', 'bad'); fx(l, { hea: -10, hap: -4 }); H.sched(l, 'phau_thuat', 0, { why: 'mổ kết hợp xương sau tai nạn giao thông' }); });
  SC('rang_khon', {
    title: 'Răng khôn mọc lệch', prep: function (l, r, arg) { return { worse: !!(arg && arg.worse) }; },
    text: function (l, d) { return (d.worse ? 'Chiếc răng khôn để lâu giờ sưng tấy, há miệng không nổi, ăn gì cũng đau.' : 'Chiếc răng khôn mọc lệch đâm vào răng bên cạnh, cứ vài tuần lại sưng đau.') + ' Nha sĩ bảo nên nhổ.'; },
    opts: [
      { k: 'public', l: 'Nhổ ở khoa răng hàm mặt bệnh viện công', h: function (l) { return 'Xếp hàng lấy số từ sáng sớm · ~' + mo(l, V(l, 1.5)) + (E.medNote ? E.medNote(l, V(l, 1.5), 1) : ''); }, ai: function (l) { return rich(l) ? 0.3 : 1.4; }, run: function (l, r, log) { if (E.medBill) E.medBill(l, V(l, 1.5), 'Nhổ răng khôn', log, 1); else H.cash(l, -V(l, 1.5), 'Nhổ răng khôn'); l.flags.wisdom = true; log('Dậy từ 5 giờ sáng xếp hàng lấy số, chờ cả buổi mới đến lượt nhổ răng khôn. Má sưng như quả bóng mất ba ngày.', 'neutral'); fx(l, { hea: 1, hap: -1 }); } },
      { k: 'private', l: 'Nhổ ở nha khoa tư (máy siêu âm, ít đau)', h: function (l) { return 'Hẹn giờ, không phải chờ · ~' + mo(l, V(l, 4)); }, ai: function (l) { return rich(l) ? 2 : 0.6; }, run: function (l, r, log) { if (E.medBill) E.medBill(l, V(l, 4), 'Nhổ răng khôn ở nha khoa tư', log, 0); else H.cash(l, -V(l, 4), 'Nhổ răng khôn ở nha khoa tư'); l.flags.wisdom = true; log('Nhổ răng khôn ở nha khoa tư, hẹn đúng giờ, làm nhanh, về nhà vẫn ăn cháo được.', 'good'); } },
      { k: 'wait', l: 'Uống thuốc giảm đau, để đó tính sau', ai: { w: 0.5 }, run: function (l, r, log, d) { log('Uống thuốc giảm đau cho qua.', 'neutral'); fx(l, { hap: -2 }); if (!d.worse) H.sched(l, 'rang_khon', 2, { worse: true }); } }
    ]
  });
  T('rang_khon', function (l, a) { return a >= 17 && a <= 30 && !l.flags.wisdom && free(l); }, 0.07, 4, 1);
  if (E.DEC.kham) {
    E.DEC.kham.def.text = function (l) { return 'Lâu rồi bạn chưa khám sức khỏe. Bệnh viện công thì rẻ nhưng đông, bệnh viện tư thì nhanh mà đắt.'; };
    var go0 = E.DEC.kham.def.opts.filter(function (o) { return o.k === 'go'; })[0];
    var runGo = function (l, r, log, cost, txt, cover) { var m0 = l.money, it = l.yr.items, n0 = it.length; go0.run(l, r, function () { }); l.money = m0; it.splice(n0, it.length - n0); if (E.medBill) E.medBill(l, cost, 'Khám sức khỏe', log, cover); else H.cash(l, -cost, 'Khám sức khỏe tổng quát'); log(txt + (l.ill && l.ill.treated ? '' : ''), 'neutral'); if (l.ill && !l.ill.treated) log('Đi khám phát hiện sớm ' + l.ill.n + ', điều trị kịp thời.', 'good'); };
    E.DEC.kham.def.opts = [
      { k: 'go', l: 'Khám ở bệnh viện công', h: function (l) { return 'Dậy từ 5 giờ sáng xếp hàng lấy số, chờ cả buổi · ~' + mo(l, V(l, 0.8)) + (E.medNote ? E.medNote(l, V(l, 0.8), 1) : ''); }, ai: function (l) { return rich(l) ? 0.4 : 1.2; }, run: function (l, r, log) { runGo(l, r, log, V(l, 0.8), 'Khám tổng quát ở bệnh viện công: 5 giờ sáng đã xếp hàng lấy số, chờ xét nghiệm, chờ kết quả, rồi đứng đợi lấy thuốc đến trưa.', 1); } },
      { k: 'private', l: 'Gói khám ở bệnh viện tư / khoa quốc tế', h: function (l) { return 'Hẹn giờ, khám nhanh, có kết quả trong ngày · ~' + mo(l, V(l, 4)); }, ai: function (l) { return rich(l) ? 1.5 : 0.3; }, run: function (l, r, log) { runGo(l, r, log, V(l, 4), 'Mua gói khám ở bệnh viện tư: có người hướng dẫn từng phòng, xong trong một buổi sáng.', 0); } },
      { k: 'no', l: 'Thôi, khỏe mà', run: function () { } }
    ];
  }

  // ===================================================================
  // 3. NGHỀ DIỄN VIÊN: CASTING, CÁT-XÊ, DOANH THU PHIM, QUẢNG CÁO, GAME SHOW
  // ===================================================================
  function isActor(l) { return !!(l.job && l.job.id === 'dien_vien'); }
  function act(l) { if (l.actSk == null) l.actSk = l.talent === 'diễn xuất' ? Math.max(30, l.skill || 30) : 22; return l.actSk; }
  function fameK(l) { var f = l.fame || 0; return f >= 1e6 ? 3 : f >= 1e5 ? 2 : f >= 2e4 ? 1.4 : 1; }
  var PROJ = {
    web: { n: 'phim web drama', lead: [70, 150], sup: [20, 45], need: 0 },
    tv: { n: 'phim truyền hình dài tập', lead: [250, 800], sup: [60, 150], need: 40 },
    cinema: { n: 'phim điện ảnh chiếu rạp', lead: [400, 3000], sup: [100, 300], need: 55 }
  };
  SC('casting', {
    title: 'Lời mời casting',
    valid: function (l) { return l.age >= 14 && free(l); },
    text: function (l) { return (isActor(l) ? 'Quản lý gửi cho bạn mấy kịch bản đang tìm diễn viên.' : 'Một đoàn phim đang tuyển diễn viên mới, bạn bè rủ bạn thử sức.') + (l.job && !isActor(l) ? " Nếu trúng vai và theo đuổi diễn xuất, bạn sẽ rời công việc cùng mức lương hiện tại. Tài năng và may mắn có thể đưa bạn thành diễn viên hạng A, nhưng bạn cũng có thể chỉ nhận vai phụ hoặc quần chúng." : '') + ' Khả năng diễn xuất của bạn: ' + Math.round(act(l)) + '/100' + ((l.fame || 0) >= 1e4 ? ', có ' + E.fmtFollowers(l.fame) + ' người hâm mộ' : '') + '.'; },
    opts: Object.keys(PROJ).map(function (k) {
      var P = PROJ[k];
      return { k: k, l: 'Casting ' + P.n,
        h: function (l) { var f = fameK(l); return 'Cát-xê vai chính ~' + mo(l, V(l, P.lead[0] * f)) + '–' + mo(l, V(l, P.lead[1] * f)) + ', vai phụ ~' + mo(l, V(l, P.sup[0] * f)) + '–' + mo(l, V(l, P.sup[1] * f)) + (P.need ? ' · cần diễn xuất khá' : '') + (l.job && !isActor(l) ? ' · Trúng vai: chuyển nghề, mất việc và lương hiện tại' : ''); },
        req: function (l) { return act(l) >= P.need - 15 || (l.fame || 0) >= 1e5; },
        ai: function (l) { return act(l) >= P.need ? 1 + P.need / 40 : 0.4; },
        run: function (l, r, log) { cast(l, r, log, k); } };
    }).concat([
      { k: 'train', l: 'Chưa nhận vai, dành thời gian học diễn xuất', h: function (l) { return 'Lớp diễn xuất ~' + mo(l, V(l, 12)); }, ai: { w: 0.6, smart: 0.5 }, run: function (l, r, log) { H.cash(l, -V(l, 12), 'Học diễn xuất'); l.actSk = Math.min(100, act(l) + 8); log('Đăng ký lớp diễn xuất cả năm: tập thoại, tập biểu cảm, học cách khóc thật trước ống kính.', 'good'); } },
      { k: 'no', l: 'Thôi, bỏ qua', ai: { w: 0.3 }, run: function () { } }
    ])
  });
  // Refresh text of already saved career choices without rerolling prep/options.
  E.refreshActingWarning = function (l, d) {
    if (!d || (d.id !== 'casting' && d.id !== 'len_chuyen')) return;
    if (d.id === 'len_chuyen' && (!d.data || d.data.id !== 'dien_vien')) return;
    var def = E.DEC[d.id].def;
    d.text = def.text(l, d.data || {});
    if (d.id === 'casting') d.opts.forEach(function (o) {
      var source = def.opts.filter(function (x) { return x.k === o.k; })[0];
      if (source && typeof source.h === 'function') o.h = source.h(l, d.data || {});
    });
  };
  function cast(l, r, log, k) {
    var P = PROJ[k], s = act(l), f = l.fame || 0;
    var p = U.clamp(0.3 + (s - P.need) / 120 + Math.log(f + 10) / Math.LN10 / 30, 0.12, 0.9);
    if (!ch(r, p)) { log('Đi casting ' + P.n + ', qua hai vòng rồi trượt ở vòng cuối. "Lần sau em quay lại nhé."', 'neutral'); fx(l, { hap: -2 }); l.actSk = Math.min(100, s + 1); return; }
    var lead = ch(r, U.clamp(p - 0.15 + (f >= 1e5 ? 0.25 : 0), 0.1, 0.9)), range = lead ? P.lead : P.sup, fee = V(l, rng(r, range[0], range[1]) * fameK(l));
    if (!isActor(l)) { E.startJob(l, 'dien_vien', r, log, true); log('Lần đầu trúng vai — chính thức bước vào nghề diễn viên.', 'big'); }
    H.cash(l, fee, 'Cát-xê ' + P.n);
    l.actSk = Math.min(100, s + (lead ? 5 : 3));
    var t = 'Nhận vai ' + (lead ? 'chính' : 'phụ') + ' trong một ' + P.n + ', cát-xê ' + mo(l, fee) + '.';
    if (k !== 'cinema') { l.fame = Math.max(l.fame || 0, 300) * (lead ? rng(r, 1.3, 2.2) : rng(r, 1.05, 1.4)) + (lead ? 5000 : 800); log(t + (lead && ch(r, 0.15) ? ' Phim lên top thịnh hành, khán giả nhớ tên bạn.' : ''), 'good'); fx(l, { hap: lead ? 6 : 3 }); return; }
    // phim điện ảnh: doanh thu phòng vé quyết định số phận
    var q = s / 100 * 0.6 + Math.log(f + 10) / Math.LN10 / 7 * 0.4 + U.normal(r) * 0.25, rev = Math.exp(2.4 + q * 3 + U.normal(r) * 0.6); // tỷ đồng
    var revT = isVN(l) ? U.fmtNum(Math.round(rev)) + ' tỷ đồng' : mo(l, V(l, rev * 1000));
    if (rev >= 300) { l.fame = (l.fame || 0) * 4 + 1e6; log(t + ' Phim thành bom tấn, doanh thu ' + revT + ' — bạn trở thành ngôi sao, lời mời đóng phim và quảng cáo đến dồn dập!', 'big'); fx(l, { hap: 14 }); H.mem(l, 'Đêm công chiếu bộ phim doanh thu ' + revT + ', khán giả đứng dậy vỗ tay.', 7); H.sched(l, 'quang_cao', 0); H.sched(l, 'casting', 1); }
    else if (rev >= 100) { l.fame = (l.fame || 0) * 2.5 + 3e5; log(t + ' Phim đạt doanh thu ' + revT + ' — tên bạn phủ sóng mạng xã hội, các nhãn hàng tìm đến.', 'big'); fx(l, { hap: 10 }); H.mem(l, 'Bộ phim trăm tỷ đầu tiên trong đời.', 5); H.sched(l, 'quang_cao', 0); }
    else if (rev >= 20) { l.fame = (l.fame || 0) * 1.3 + 2e4; log(t + ' Phim thu ' + revT + ', hòa vốn, được khen diễn tròn vai.', 'good'); fx(l, { hap: 4 }); }
    else { l.fame = (l.fame || 0) * 0.85; log(t + ' Phim thất bại phòng vé, chỉ thu ' + revT + ', bị chê kịch bản yếu.', 'bad'); fx(l, { hap: -5 }); }
  }
  SC('quang_cao', {
    title: 'Hợp đồng quảng cáo',
    prep: function (l, r) { var f = l.fame || 0; return { fee: V(l, f >= 1e6 ? rng(r, 1000, 5000) : f >= 1e5 ? rng(r, 250, 900) : rng(r, 40, 150)), brand: pick(r, ['một hãng điện thoại', 'một thương hiệu mỹ phẩm', 'một hãng sữa', 'một ngân hàng', 'một hãng thời trang', 'một chuỗi cà phê']) }; },
    valid: function (l) { return (l.fame || 0) >= 2e4; },
    text: function (l, d) { return U.cap(d.brand) + ' mời bạn làm gương mặt đại diện, thù lao ' + mo(l, d.fee) + '. Cùng lúc, một hãng "thực phẩm chức năng thần dược" cũng trả giá cao gấp rưỡi.'; },
    opts: [
      { k: 'ok', l: 'Nhận làm đại diện cho nhãn hàng uy tín', ai: { w: 1.4 }, run: function (l, r, log, d) { H.cash(l, d.fee, 'Hợp đồng quảng cáo'); l.fame = (l.fame || 0) * 1.1; log('Ký hợp đồng đại diện ' + d.brand + ', thù lao ' + mo(l, d.fee) + '. Biển quảng cáo in mặt bạn khắp các ngã tư.', 'good'); fx(l, { hap: 5 }); } },
      { k: 'dubious', l: 'Nhận quảng cáo "thần dược" giá cao', ai: { bad: 1, risk: 1 }, run: function (l, r, log, d) { H.cash(l, d.fee * 1.5, 'Quảng cáo thực phẩm chức năng'); if (ch(r, 0.3)) { l.fame = (l.fame || 0) * 0.6; H.cash(l, -V(l, 70), 'Bị phạt vì quảng cáo sai sự thật'); log('Sản phẩm bị phanh phui là hàng kém chất lượng. Bạn bị phạt vì quảng cáo sai sự thật, khán giả tẩy chay.', 'bad'); fx(l, { hap: -12, karma: -6 }); } else { log('Nhận quảng cáo "thần dược", tiền về nhiều mà lòng không yên.', 'neutral'); fx(l, { karma: -3 }); } } },
      { k: 'no', l: 'Từ chối hết, tập trung đóng phim', ai: { w: 0.4 }, run: function (l, r, log) { log('Từ chối quảng cáo để giữ hình ảnh, tập trung cho vai diễn.', 'neutral'); l.actSk = Math.min(100, act(l) + 2); } }
    ]
  });
  var SHOWS = {
    rm: { n: 'Running Man Việt Nam', host: 'anh cả biệt danh "Thánh Trần" nổi tiếng hay nâng đỡ người mới: chỉ bạn cách tạo điểm nhấn, nhường cho bạn những khoảnh khắc chiến thắng' },
    hai: { n: '2 Ngày 1 Đêm', host: '"anh lớn" Tràng Dương nổi tiếng hay "bắt nạt" thành viên mới: dồn hết việc nặng cho bạn, chơi khăm ở mọi trò chơi, còn giành cả phần ăn' }
  };
  SC('gameshow', {
    title: 'Lời mời tham gia game show', major: 0,
    prep: function (l, r) { var f = l.fame || 0; return { fee: V(l, f >= 1e6 ? rng(r, 1200, 3000) : rng(r, 300, 900)) }; },
    valid: function (l) { return (l.fame || 0) >= 1e5; },
    text: function (l, d) { return 'Hai chương trình thực tế ăn khách mời bạn tham gia cả mùa, cát-xê khoảng ' + mo(l, d.fee) + '. Quay ngoài trời, dầm mưa dãi nắng, nhưng khán giả cả nước theo dõi.'; },
    opts: [
      { k: 'rm', l: 'Tham gia Running Man Việt Nam', ai: { w: 1 }, run: function (l, r, log, d) { show(l, r, log, d, 'rm'); } },
      { k: 'hai', l: 'Tham gia 2 Ngày 1 Đêm', ai: { w: 1 }, run: function (l, r, log, d) { show(l, r, log, d, 'hai'); } },
      { k: 'no', l: 'Từ chối, lịch quay phim kín rồi', ai: { w: 0.5 }, run: function () { } }
    ]
  });
  function show(l, r, log, d, k) { H.cash(l, d.fee, 'Cát-xê game show ' + SHOWS[k].n); l.fame = (l.fame || 0) * 1.25 + 5e4; log('Tham gia ' + SHOWS[k].n + ', cát-xê cả mùa ' + mo(l, d.fee) + '.', 'big'); fx(l, { hap: 5 }); H.chain(l, 'gameshow_dong', { k: k }); }
  SC('gameshow_dong', {
    title: function (l, d) { return 'Hậu trường ' + SHOWS[d.k].n; }, prep: function (l, r, arg) { return arg && arg.k ? arg : { k: 'rm' }; },
    text: function (l, d) { return 'Trong ' + SHOWS[d.k].n + ' có ' + SHOWS[d.k].host + '. (Nhân vật trong game.)'; },
    opts: [
      { k: 'chiu', l: function (l, d) { return d.k === 'hai' ? 'Chịu trận, diễn vai "em út bị bắt nạt"' : 'Học hỏi anh cả, làm tốt vai trò của mình'; }, ai: { w: 1.2 }, run: function (l, r, log, d) { if (d.k === 'hai') { l.fame *= 1.4; log('Khán giả thích thú với cặp "anh lớn bắt nạt – em út chịu trận", clip của bạn lên xu hướng.', 'good'); fx(l, { hap: -1 }); } else { l.fame *= 1.3; l.actSk = Math.min(100, act(l) + 5); log('Anh cả tận tình chỉ dạy, bạn tiến bộ từng tập và được khán giả thương.', 'good'); fx(l, { hap: 5, soc: 4 }); } } },
      { k: 'phan', l: function (l, d) { return d.k === 'hai' ? 'Phản pháo lại cho vui' : 'Tranh thủ tỏa sáng, giành chiến thắng'; }, ai: { risk: 1 }, run: function (l, r, log, d) { if (ch(r, 0.55)) { l.fame *= 1.6; log(d.k === 'hai' ? 'Màn "trả đũa" anh lớn khiến cả trường quay cười nghiêng ngả — tập phát sóng hút triệu lượt xem.' : 'Giành chiến thắng chung cuộc, cả nước nhớ mặt bạn.', 'big'); fx(l, { hap: 8 }); } else { l.fame *= 0.92; log('Cư dân mạng chê bạn "lấn lướt", "hỗn với đàn anh". Mấy ngày liền bị bình luận chỉ trích.', 'bad'); fx(l, { hap: -6 }); } } },
      { k: 'nho', l: 'Làm thân với các thành viên, nhờ giới thiệu vai diễn', ai: { soc: 1 }, run: function (l, r, log) { log('Thân thiết với cả ê-kíp; một thành viên giới thiệu bạn vào dự án phim mới.', 'good'); fx(l, { soc: 5 }); H.sched(l, 'casting', 1); } }
    ]
  });
  SC('hoc_dien', {
    title: 'Trau dồi diễn xuất', text: function (l) { return 'Khả năng diễn xuất hiện tại: ' + Math.round(act(l)) + '/100. Diễn viên muốn có vai lớn thì phải không ngừng học.'; },
    opts: [
      { k: 'class', l: 'Học lớp diễn xuất chuyên nghiệp', h: function (l) { return '~' + mo(l, V(l, 15)); }, ai: { w: 1 }, run: function (l, r, log) { H.cash(l, -V(l, 15), 'Học diễn xuất'); l.actSk = Math.min(100, act(l) + 8); log('Học một khóa diễn xuất với thầy giỏi, tiến bộ rõ rệt.', 'good'); } },
      { k: 'self', l: 'Tự xem phim, tập thoại trước gương', h: 'Không tốn tiền', ai: { w: 0.8 }, run: function (l, r, log) { l.actSk = Math.min(100, act(l) + 3); log('Tối nào cũng tập thoại trước gương, phân tích từng cảnh phim hay.', 'neutral'); } },
      { k: 'cast', l: 'Đi casting tìm vai', ai: { w: 1 }, run: function (l, r, log) { H.chain(l, 'casting'); } }
    ]
  });
  A('hoc_dien', 'Công việc', 'Học diễn xuất / đi casting', { min: 14, avail: function (l) { var c = jobC(l); return isActor(l) || l.talent === 'diễn xuất' || (c && c.cat === 'show') ? true : 'Dành cho người mê diễn xuất'; }, ai: function (l) { return isActor(l) ? 0.5 : 0.08; } });
  T('casting', function (l, a) { return isActor(l) && free(l) && ((l.flags.scN || {}).casting || 0) < 8; }, 0.5, 2, 99); // v3.7: casting cách năm một lần, không năm nào cũng hỏi
  T('casting', function (l, a) { return !isActor(l) && l.talent === 'diễn xuất' && a >= 16 && a <= 35 && !l.school && free(l); }, 0.1, 4, 3);
  T('gameshow', function (l, a) { var c = jobC(l); return (l.fame || 0) >= 1e5 && a >= 18 && a <= 55 && c && /^(show|media|creator|sport)$/.test(c.cat) && free(l); }, 0.2, 3, 3);
  E.TRIG.forEach(function (t) { if (t.id === 'casting' && t.max === 99) t.rep = true; });
  // sau khi trúng số công khai, người lạ và họ hàng tìm đến liên tục — chuỗi sự kiện, không tính vào giới hạn lặp
  E.TRIG.forEach(function (t) { if (/^(ts_nguoi_la|ts_ho_hang)$/.test(t.id)) { t.rep = true; t.cd = Math.max(t.cd || 0, 1); } });

  // ===================================================================
  // 4. TÌNH YÊU: NHẮN TIN TÁN TỈNH, CHÊNH LỆCH TUỔI, BIỆT DANH HỘI BẠN
  // ===================================================================
  SC('nhan_tin', {
    title: 'Nhắn tin tán tỉnh', valid: function (l) { return !l.partner && l.age >= 15; },
    prep: function (l, r) { var s = H.partnerSex(l, r); return { n: H.stranger(l, r, s), s: s, where: pick(r, l.school ? ['bạn học khác lớp', 'người quen trên mạng xã hội', 'bạn của bạn thân'] : ['đồng nghiệp ở công ty bên cạnh', 'người quen trên mạng xã hội', 'bạn của bạn thân', 'người gặp ở phòng gym']) }; },
    text: function (l, d) { return 'Bạn để ý ' + d.n + ' (' + d.where + ') và bắt đầu nhắn tin làm quen. Tin nhắn nào cũng được trả lời bằng một biểu tượng cảm xúc.'; },
    opts: [
      { k: 'flirt', l: 'Nhắn tiếp, tán tỉnh ra mặt', ai: { w: 1, soc: 0.8 }, run: function (l, r, log, d) {
        var x = r();
        if (x < 0.3) { log('Nhắn tin cho ' + d.n + ' được hai tuần thì bị "ghost": tin nhắn hiện "đã xem" rồi im bặt.', 'bad'); fx(l, { hap: -4 }); }
        else if (x < 0.6) { l.flags.mapMo = d.n; log('Với ' + d.n + ' cứ mập mờ: tối nào cũng nhắn, cuối tuần đi cà phê, nhưng chẳng ai nói ra là gì của nhau.', 'neutral'); fx(l, { hap: 2 }); }
        else l.pending.unshift(E.DEC.love.make(l, r, { where: 'qua những tin nhắn làm quen' }));
      } },
      { k: 'slow', l: 'Từ từ, để xem người ta có ý không', ai: { w: 0.8 }, run: function (l, r, log, d) { if (ch(r, 0.35)) l.pending.unshift(E.DEC.love.make(l, r, { where: 'sau mấy tháng nhắn tin qua lại' })); else log('Nhắn qua nhắn lại vài lần rồi cũng thưa dần.', 'neutral'); } },
      { k: 'stop', l: 'Thôi, không nhắn nữa', ai: { w: 0.4 }, run: function (l, r, log) { log('Xóa đoạn chat, tập trung cho việc của mình.', 'neutral'); } }
    ]
  });
  T('nhan_tin', function (l, a) { return a >= 15 && a <= 45 && !l.partner && free(l); }, 0.1, 4, 3);
  // chênh lệch tuổi: thỉnh thoảng người ấy hơn / kém nhiều tuổi
  var lm0 = E.DEC.love.make;
  E.DEC.love.make = function (l, r, arg) {
    var d = lm0.apply(this, arguments), p = d.data.p, a0 = p.age;
    if (l.age >= 18 && ch(r, 0.16)) {
      p.age = ch(r, 0.55) ? l.age + U.randint(r, 6, 15) : Math.max(18, l.age - U.randint(r, 3, 9));
      d.text = d.text.split(', ' + a0 + ' tuổi)').join(', ' + p.age + ' tuổi)');
    }
    return d;
  };
  wrapAfter('love', function (l, d, k) {
    var p = l.partner; if (k !== 'yes' || !p || p.since !== l.age) return null;
    var gap = p.age - l.age, F = l.sex === 'F', pM = p.sex === 'M';
    if (F && pM && gap <= -4) return 'Người yêu kém bạn ' + (-gap) + ' tuổi — hội bạn trêu bạn "quen hồng hài nhi".';
    if (F && pM && gap >= 10) return 'Người yêu hơn bạn ' + gap + ' tuổi — đám bạn gọi đùa anh ấy là "ngưu ma vương".';
    if (!F && !pM && gap >= 4) return 'Bạn kém người yêu ' + gap + ' tuổi — thành "phi công trẻ lái máy bay", bị bạn bè trêu suốt.';
    if (!F && !pM && gap <= -10) return 'Bạn hơn người yêu ' + (-gap) + ' tuổi — bạn bè trêu "trâu già gặm cỏ non".';
    return null;
  });
  function wrapAfter(id, f) { var D = E.DEC[id], ap = D.apply; D.apply = function (l, dec, k, r, log) { var x = ap.apply(this, arguments), t = f(l, dec, k); if (t) log(t, 'neutral'); return x; }; }
  // biệt danh hội bạn thân đặt sau khi bạn công khai
  E.HOOKS.year.push(function (l, r, log, a) {
    if (!l.alive || l.flags.nick || !l.out || l.orient === 'straight' || !isVN(l)) return;
    l.flags.nick = true;
    log(true ? 'Từ ngày công khai, hội bạn thân vẫn quý bạn như xưa: "Mày vẫn là mày, có gì đâu mà phải giấu."' : l.orient === 'bi' ? 'Từ ngày công khai, hội bạn thân gọi bạn là "bi" — "thích ai thì thích, miễn người ta tử tế".' : l.sex === 'F' ? 'Từ ngày công khai, hội bạn thân gọi bạn trìu mến là "bé Liên" — ai cũng bênh bạn chằm chặp.' : 'Từ ngày công khai, hội bạn thân đặt cho bạn biệt danh "' + (l.role === 'top' ? 'tóp mỡ' : 'bột tôm') + '" — gọi riết thành quen, cả hội cười suốt.', 'good');
    fx(l, { soc: 3 });
  });

  // về già có của ăn của để thì cho con cháu tiền mua nhà, làm vốn (rất phổ biến ở Việt Nam)
  E.HOOKS.year.push(function (l, r, log, a) {
    if (!l.alive || a < 52 || !l.indep || l.money < l.base * 15 || (l.flags.giftAt != null && a - l.flags.giftAt < 4)) return;
    var ks = l.kids.filter(function (k) { return k.alive && a - k.born >= 22; }); if (!ks.length || !ch(r, 0.35)) return;
    var k = pick(r, ks), x = l.money * rng(r, 0.12, 0.25); l.flags.giftAt = a;
    H.cash(l, -x, 'Cho con ' + k.name); k.close = Math.min(100, (k.close || 50) + 8);
    log('Cho con ' + k.name + ' ' + mo(l, x) + ' ' + pick(r, ['mua nhà', 'làm vốn kinh doanh', 'lo cho các cháu ăn học', 'trả nợ ngân hàng']) + ' — "bố mẹ còn khỏe, giúp được gì thì giúp".', 'good');
    fx(l, { hap: 4, karma: 2 });
  });

  // ===================================================================
  // 5. THI LẠI CHỨNG CHỈ (tự chọn trong "Việc bạn muốn làm"), TIỀN MÃ HÓA
  // ===================================================================
  var CERT_K = ['en', 'ko', 'zh'];
  function expired(l) { return CERT_K.filter(function (k) { return l.lang && l.lang[k] && l.langExp && l.langExp[k]; }); }
  A('thi_lai_cc', 'Học tập', 'Thi lại IELTS / TOPIK / HSK đã hết hạn', { min: 16, sc: 'chung_chi_het_han', arg: function (l) { return { k: expired(l)[0] || 'en', manual: true }; },
    avail: function (l) { return expired(l).length ? true : 'Không có chứng chỉ nào hết hạn'; } });
  if (E.DEC.chung_chi_het_han) {
    var cv0 = E.DEC.chung_chi_het_han.def.valid;
    E.DEC.chung_chi_het_han.def.valid = function (l, d) { if (!d || !d.k) return expired(l).length > 0 || cv0(l, d); return d.manual ? !!(l.lang && l.lang[d.k]) : cv0(l, d); };
  }
  if (E.DEC.dau_tu) E.DEC.dau_tu.def.opts.forEach(function (o) {
    if (o.k !== 'crypto') return;
    o.h = 'Rất rủi ro: phần lớn người chơi thua lỗ';
    o.run = function (l, r, log) {
      var m = Math.max(0, l.money) * 0.3, x = r();
      if (m <= l.base * 0.01) { log('Không còn tiền nhàn rỗi để chơi tiền mã hóa.', 'neutral'); return; }
      if (x < 0.3) { H.cash(l, -m * 0.9, 'Mất trắng tiền mã hóa'); log('Đồng coin "tiềm năng" bị rút thảm (rug pull), sàn đóng cửa — mất gần như toàn bộ.', 'bad'); fx(l, { hap: -15 }); H.mem(l, 'Ngày nhìn tài khoản tiền ảo về gần con số 0.', 5); }
      else if (x < 0.65) { H.cash(l, -m * 0.45, 'Lỗ tiền mã hóa'); log('Mua đúng đỉnh, cắt lỗ gần một nửa.', 'bad'); fx(l, { hap: -6 }); }
      else if (x < 0.9) { H.cash(l, m * 0.4, 'Lãi tiền mã hóa'); log('Tiền ảo tăng giá, chốt lời được một ít.', 'good'); fx(l, { hap: 4 }); }
      else if (x < 0.98) { H.cash(l, m * 1.5, 'Lãi lớn tiền mã hóa'); log('Gặp sóng lớn, tài khoản tăng gấp rưỡi.', 'good'); fx(l, { hap: 8 }); }
      else { H.cash(l, m * 4, 'Lãi rất lớn tiền mã hóa'); log('Hiếm có: đồng coin tăng gấp năm lần!', 'big'); fx(l, { hap: 12 }); }
    };
  });
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
/* ===== js/life33.js ===== */
/* Một Đời — v3.3:
   · nghĩa vụ quân sự 2 năm: 3 tháng huấn luyện tân binh, về đơn vị, diễn tập, cứu hộ, về phép, xuất ngũ — trong thời gian đó không có chuyện đời thường bên ngoài
   · hoạt động hợp tuổi (người già không đi battle rap, cắm trại phượt…)
   · đầu tư đa dạng: cổ phiếu từng công ty / quỹ chỉ số, tiền mã hóa theo chu kỳ tăng – giảm, rủi ro sàn sập, coin "rug pull" */
(function (G) {
  'use strict';
  var U = G.U, E = G.E, H = E.H, SC = E.SC, isVN = H.isVN;
  function A(id, g, label, o) { var x = { id: id, g: g, l: label }; for (var k in o) x[k] = o[k]; E.ACT.push(x); }
  function fx(l, o) { H.fx(l, o); }
  function mo(l, v) { return H.money(l, v); }
  function pick(r, a) { return U.pick(r, a); }
  function ch(r, p) { return r() < p; }
  function vnd(l) { return isVN(l) && l.cur === 'vnd' && !(l.abroad && l.abroad.perm); }
  function V(l, tr) { return vnd(l) ? tr : tr / 90 * l.base; }
  function pct(x) { return (x >= 0 ? '+' : '−') + Math.abs(Math.round(x * 100)) + '%'; }

  // ===================================================================
  // 1. NGHĨA VỤ QUÂN SỰ
  // ===================================================================
  function inMil(l) { return !!(l.flags.military && l.age < l.flags.military); }
  E.inMil = inMil;
  E.milYear = function (l, r, a) {
    var L = [];
    if (!l.flags.milTB) { L.push(['nv_tan_binh'], ['nv_don_vi']); }
    else {
      var pool = ['nv_dien_tap', 'nv_cuu_ho', 'nv_phep', 'nv_dong_doi'];
      if (isVN(l) && l.flags.milGood && !l.flags.milDang) pool.push('nv_dang');
      for (var i = pool.length - 1; i > 0; i--) { var j = Math.floor(r() * (i + 1)), t = pool[i]; pool[i] = pool[j]; pool[j] = t; }
      L.push([pool[0]], [pool[1]]);
    }
    return L;
  };
  var MV = function (l) { return isVN(l) ? 'Quân đội nhân dân Việt Nam' : 'quân đội'; };
  SC('nv_tan_binh', {
    title: '3 tháng huấn luyện tân binh', major: 0,
    text: function (l) { return 'Cắt tóc ngắn, nhận quân trang, ' + (isVN(l) ? 'mặc bộ quân phục màu xanh lá cây' : 'mặc quân phục') + '. Ba tháng đầu học điều lệnh đội ngũ, gấp chăn màn vuông thành sắc cạnh, chạy 3 km mỗi sáng, tập bắn đạn thật, hành quân mang vác nặng. Đêm đầu tiên cả tiểu đội trằn trọc vì nhớ nhà.'; },
    opts: [
      { k: 'gang', l: 'Cố gắng hết sức, tập nghiêm túc', ai: { w: 1.3, amb: 0.8 }, run: function (l, r, log) { l.flags.milTB = true; fx(l, { hea: 5, kno: 2 }); if (ch(r, 0.45)) { l.flags.milGood = true; log('Hoàn thành huấn luyện tân binh, bắn đạn thật đạt loại giỏi — được biểu dương "chiến sĩ tiêu biểu" của đại đội.', 'good'); fx(l, { hap: 5 }); H.mem(l, 'Buổi lễ tuyên thệ chiến sĩ mới, giọng cả trung đội vang lên dưới cờ.', 4); } else log('Hoàn thành ba tháng huấn luyện tân binh. Người đen sạm, rắn rỏi hẳn ra, gấp chăn đã ' + (isVN(l) ? 'vuông như bánh chưng.' : 'vuông vức như cắt bằng thước.'), 'good'); } },
      { k: 'nho', l: 'Nhớ nhà, đêm nào cũng viết thư về', ai: { w: 0.8, soc: 0.6 }, run: function (l, r, log) { l.flags.milTB = true; fx(l, { hap: -2, soc: 4 }); log('Những tuần đầu nhớ nhà đến phát khóc. Tiểu đội trưởng và đồng đội động viên, dần dần bạn quen với nếp sống quân ngũ.', 'neutral'); } },
      { k: 'luoi', l: 'Lười tập, tìm cách trốn việc', ai: { bad: 0.8, risk: 0.6, w: 0.3 }, run: function (l, r, log) { l.flags.milTB = true; fx(l, { karma: -3, hea: 1 }); if (ch(r, 0.5)) { log('Bị phát hiện trốn tập, bị kiểm điểm trước đơn vị và phải chạy phạt thêm. Từ đó bạn chăm chỉ hơn.', 'bad'); fx(l, { hap: -4 }); } else log('Tập uể oải, cuối khóa huấn luyện chỉ đạt loại trung bình.', 'neutral'); } }
    ]
  });
  SC('nv_don_vi', {
    title: 'Về đơn vị', text: 'Hết 3 tháng tân binh, bạn được phân về đơn vị. Chỉ huy hỏi nguyện vọng chuyên môn trong gần 2 năm còn lại.',
    opts: [
      { k: 'bo_binh', l: 'Chiến sĩ bộ binh', h: 'Huấn luyện chiến đấu, rèn thể lực', ai: { w: 1 }, run: function (l, r, log) { l.flags.milRole = 'bộ binh'; fx(l, { hea: 4 }); log('Về đại đội bộ binh: sáng thao trường, chiều tăng gia trồng rau, nuôi lợn, tối sinh hoạt chính trị.', 'neutral'); } },
      { k: 'lai_xe', l: 'Học lái xe quân sự', h: 'Được học và thi bằng lái ô tô', ai: { w: 1, smart: 0.5 }, run: function (l, r, log) { l.flags.milRole = 'lái xe'; l.lic = l.lic || {}; l.lic.B = true; (l.licAt = l.licAt || {}).B = l.age; log('Được cử đi học lái xe quân sự, thi đỗ bằng lái — ra quân đã có nghề trong tay.', 'good'); fx(l, { kno: 2, hap: 3 }); } },
      { k: 'quan_y', l: 'Học quân y', h: 'Sơ cứu, chăm sóc thương binh', ai: { w: 0.7, smart: 0.8 }, run: function (l, r, log) { l.flags.milRole = 'quân y'; fx(l, { kno: 4, karma: 2 }); log('Theo học lớp quân y của sư đoàn: băng bó, sơ cứu, phát thuốc cho anh em.', 'good'); } },
      { k: 'anh_nuoi', l: 'Làm "anh nuôi" ở bếp ăn', h: 'Nấu ăn cho cả đơn vị', ai: { w: 0.6 }, run: function (l, r, log) { l.flags.milRole = 'anh nuôi'; fx(l, { soc: 3 }); if (!l.hobby) { l.hobby = 'nauan'; l.hobbySk = 30; } log('Thành "anh nuôi" của đại đội: dậy từ 4 giờ sáng nấu cơm cho cả trăm người, tay nghề bếp lên trông thấy.', 'good'); } },
      { k: 'thong_tin', l: 'Lính thông tin liên lạc', h: 'Học vận hành máy móc, liên lạc', ai: { w: 0.6, smart: 0.6 }, run: function (l, r, log) { l.flags.milRole = 'thông tin'; fx(l, { kno: 3 }); log('Về tiểu đoàn thông tin, học vận hành máy thông tin và kéo dây liên lạc.', 'neutral'); } }
    ]
  });
  SC('nv_dien_tap', {
    title: 'Diễn tập dã ngoại', text: 'Đơn vị hành quân dã ngoại 30 km, mang ba lô hơn 20 kg, ngủ võng trong rừng một tuần để diễn tập. Một đồng đội bị chuột rút giữa đường.',
    opts: [
      { k: 'giup', l: 'Mang đỡ ba lô cho đồng đội', ai: { w: 1.3, soc: 0.8 }, run: function (l, r, log) { fx(l, { hea: -2, soc: 5, karma: 2 }); l.flags.milGood = true; log('Vác hai ba lô suốt chặng cuối. Về đến nơi cả tiểu đội vỗ vai, chỉ huy khen trước hàng quân.', 'good'); H.mem(l, 'Chặng hành quân vác đỡ ba lô cho đồng đội.', 3); } },
      { k: 'minh', l: 'Lo phần mình cho xong', ai: { w: 0.8 }, run: function (l, r, log) { fx(l, { hea: 2 }); log('Hoàn thành cuộc hành quân, mỏi rã rời nhưng không ai bỏ cuộc.', 'neutral'); } }
    ]
  });
  SC('nv_cuu_ho', {
    title: 'Lệnh cứu hộ', text: function (l) { return 'Mưa lũ lớn ở ' + (isVN(l) ? 'miền Trung' : 'một tỉnh lân cận') + ', nhiều nhà dân bị cô lập. Đơn vị được lệnh lên đường cứu hộ ngay trong đêm.'; },
    opts: [
      { k: 'dau', l: 'Xung phong vào tuyến đầu', ai: { w: 1.2, risk: 0.5 }, run: function (l, r, log) { if (ch(r, 0.06)) { log('Lội nước xiết cõng người già ra khỏi vùng ngập, bạn bị trượt chân va vào đá, gãy tay phải nằm viện quân y.', 'bad'); fx(l, { hea: -10, karma: 8 }); } else { log('Cùng đồng đội đưa hàng chục người dân ra khỏi vùng ngập. Một bà cụ nắm tay bạn: "Có bộ đội là dân yên tâm." Đơn vị được tặng bằng khen.', 'big'); fx(l, { karma: 8, hap: 6, soc: 4 }); l.flags.milGood = true; H.mem(l, 'Đêm lội lũ cõng bà cụ ra khỏi căn nhà ngập nước.', 6); } } },
      { k: 'hau_can', l: 'Làm hậu cần, chuyển nhu yếu phẩm', ai: { w: 1 }, run: function (l, r, log) { fx(l, { karma: 4, hap: 3 }); log('Thức trắng mấy đêm bốc vác mì tôm, nước sạch, áo phao cho bà con vùng lũ.', 'good'); } }
    ]
  });
  SC('nv_phep', {
    title: 'Được về phép', text: function (l) { return 'Bạn được nghỉ phép 10 ngày về thăm nhà' + (l.partner ? ', ' + l.partner.name + ' đang đợi' : '') + '.'; },
    opts: [
      { k: 'nha', l: 'Về nhà với gia đình', ai: { w: 1.2 }, run: function (l, r, log) { H.cash(l, -V(l, 1), 'Tàu xe về phép'); fx(l, { hap: 8, soc: 3 }); log('Về phép, mẹ nấu cả mâm cơm, hàng xóm sang hỏi chuyện quân ngũ. Mười ngày trôi qua nhanh như chớp.', 'good'); H.mem(l, 'Mười ngày phép đầu tiên, khoác ba lô về đến đầu ngõ.', 4); } },
      { k: 'nguoi_yeu', l: function (l) { return l.partner ? 'Dành thời gian cho ' + l.partner.name : 'Ở lại đơn vị, nhường phép cho đồng đội'; }, ai: { w: 0.8 }, run: function (l, r, log) {
        if (!l.partner) { fx(l, { karma: 3, soc: 3 }); log('Nhường suất phép cho đồng đội có bố ốm nặng.', 'good'); return; }
        if (l.partner.status === 'dating' && ch(r, 0.15)) { log(l.partner.name + ' nói lời chia tay: "Hai năm xa quá, ' + E.xung(l).me + ' không đợi được."', 'bad'); l.partner = null; l.exes = (l.exes || 0) + 1; fx(l, { hap: -10 }); }
        else { log('Mười ngày phép bên ' + l.partner.name + ', hứa ngày ra quân sẽ về ngay.', 'good'); fx(l, { hap: 8 }); } } }
    ]
  });
  SC('nv_dong_doi', {
    title: 'Chuyện đồng đội', text: 'Một đồng đội nhà nghèo nhận tin mẹ ốm nặng, không đủ tiền vào viện.',
    opts: [
      { k: 'gop', l: 'Góp phụ cấp cùng cả tiểu đội', h: function (l) { return '~' + mo(l, V(l, 1)); }, ai: { w: 1.3, soc: 1 }, run: function (l, r, log) { H.cash(l, -V(l, 1), 'Góp giúp đồng đội'); fx(l, { karma: 4, soc: 5 }); log('Cả tiểu đội góp phụ cấp gửi về cho mẹ đồng đội. Tình đồng chí từ đó thân như anh em ruột.', 'good'); H.mem(l, 'Tình đồng đội những năm quân ngũ.', 3); } },
      { k: 'hoi', l: 'Chỉ hỏi thăm động viên', ai: { w: 0.6 }, run: function (l, r, log) { fx(l, { soc: 1 }); log('Ngồi động viên đồng đội cả buổi tối.', 'neutral'); } }
    ]
  });
  SC('nv_dang', {
    title: 'Được giới thiệu kết nạp Đảng', valid: function (l) { return isVN(l); },
    text: 'Vì rèn luyện tốt, chi bộ đơn vị giới thiệu bạn đi học lớp cảm tình Đảng và xem xét kết nạp trước khi ra quân.',
    opts: [
      { k: 'yes', l: 'Học tập, phấn đấu được kết nạp', ai: { w: 1, amb: 1 }, run: function (l, r, log) { l.flags.milDang = true; l.flags.dangVien = true; fx(l, { hap: 4, kno: 2 }); log('Được kết nạp Đảng ngay trong quân ngũ — hồ sơ thêm sáng khi xin việc ở cơ quan nhà nước sau này.', 'big'); H.mem(l, 'Ngày đứng trước cờ Đảng đọc lời tuyên thệ.', 4); } },
      { k: 'no', l: 'Chưa sẵn sàng', ai: { w: 0.5 }, run: function (l, r, log) { l.flags.milDang = true; log('Xin lùi lại, để mình rèn luyện thêm.', 'neutral'); } }
    ]
  });
  SC('nv_xuat_ngu', {
    title: 'Ra quân', major: 1,
    text: function (l) { return 'Hai năm nghĩa vụ sắp hết' + (l.flags.milRole ? ' (bạn là lính ' + l.flags.milRole + ')' : '') + '. Ra quân được nhận trợ cấp xuất ngũ, trợ cấp tạo việc làm và được ưu tiên khi học nghề, tuyển dụng. Bạn tính sao?'; },
    opts: [
      { k: 've', l: 'Xuất ngũ về địa phương', h: function (l) { return 'Trợ cấp khoảng ' + mo(l, V(l, 25)) + ', được hỗ trợ học nghề'; }, ai: { w: 1.4 }, run: function (l, r, log) { H.cash(l, V(l, 25), 'Trợ cấp xuất ngũ, tạo việc làm'); l.flags.milVet = true; log('Nhận trợ cấp xuất ngũ ' + mo(l, V(l, 25)) + ', chia tay đồng đội trong nước mắt rồi về quê.', 'good'); H.mem(l, 'Buổi chia tay đồng đội ngày ra quân, ai cũng khóc.', 5); } },
      { k: 'si_quan', l: 'Thi vào trường sĩ quan quân đội', h: 'Học 4 năm, ra trường mang quân hàm Thiếu úy', req: function (l) { return l.edu >= 3; }, ai: { amb: 1.2, w: 0.5 }, run: function (l, r, log) { if (ch(r, 0.35 + (l.st.kno - 60) / 150 + (l.flags.milGood ? 0.15 : 0))) { l.flags.military = null; l.school = 'police'; l.schoolEnd = l.age + 4; l.flags.policeTrack = 'quan_doi'; log('Thi đỗ trường sĩ quan — từ người lính nghĩa vụ trở thành học viên sĩ quan.', 'big'); fx(l, { hap: 8 }); } else { var x = V(l, E.milAllowance ? E.milAllowance(l) : 25); H.cash(l, x, 'Trợ cấp xuất ngũ, tạo việc làm'); l.flags.milVet = true; log('Thi trượt trường sĩ quan, đành xuất ngũ về địa phương với trợ cấp ' + mo(l, x) + '.', 'neutral'); } } },
      { k: 'cn', l: 'Ở lại làm quân nhân chuyên nghiệp', h: 'Có lương, chế độ, BHXH', ai: { w: 0.5 }, run: function (l, r, log) { l.flags.military = null; E.startJob(l, 'quan_doi', r, log, true); log('Đăng ký ở lại đơn vị làm quân nhân chuyên nghiệp ' + (l.flags.milRole ? 'ngành ' + l.flags.milRole : '') + '.', 'big'); fx(l, { hap: 4 }); } }
    ]
  });
  ['nv_tan_binh', 'nv_don_vi', 'nv_dien_tap', 'nv_cuu_ho', 'nv_phep', 'nv_dong_doi', 'nv_dang', 'nv_xuat_ngu'].forEach(function (id) { if (id !== 'nv_xuat_ngu' && id !== 'nv_tan_binh') E.MAJOR[id] = 0; });
  // vào quân ngũ là vào luôn khóa huấn luyện tân binh
  var uniAp = E.DEC.uni.apply;
  E.DEC.uni.apply = function (l, d, k, r, log) { var x = uniAp.apply(this, arguments); if (k === 'military' && inMil(l)) { H.chain(l, 'nv_don_vi'); H.chain(l, 'nv_tan_binh'); } return x; };
  // phụ cấp quân ngũ (khoảng 1 triệu đồng/tháng) là thu nhập trong 2 năm, ăn ở trong doanh trại
  var cyM = E.careerYear;
  E.careerYear = function (l) { if (inMil(l)) { fx(l, { hea: 2 }); return V(l, 12.5); } return cyM.apply(this, arguments); };
  // ghi nhận lúc bắt đầu mê một thần tượng
  E.HOOKS.year.push(function (l, r, log, a) { if (l.idol && l.flags.idolName !== l.idol) { l.flags.idolName = l.idol; l.flags.idolAt = a; } });

  // ===================================================================
  // 2. HOẠT ĐỘNG HỢP TUỔI
  // ===================================================================
  var MAXAGE = { show_rap: 45, phuot: 55, xem_bong_da: 75, concert: 55, di_nhau: 75, bang_lai: 75, khoi_nghiep: 72, tim_viec: 72, hoc_dien: 50, cong_vien: 13, karaoke: 80, tim_nguoi_yeu: 85, ca_do_act: 80 };
  E.ACT.forEach(function (a) { if (MAXAGE[a.id] != null && (a.max == null || a.max > MAXAGE[a.id])) a.max = MAXAGE[a.id]; });
  E.TRIG.forEach(function (t) {
    if (/^(concert|concert_di|show_rap|nhan_tin|so_thich)$/.test(t.id)) { var w0 = t.when; t.when = function (l, a) { return a <= (t.id === 'nhan_tin' ? 45 : 50) && w0.apply(this, arguments); }; }
  });

  // ===================================================================
  // 3. ĐẦU TƯ ĐA DẠNG: CỔ PHIẾU TỪNG CÔNG TY, QUỸ CHỈ SỐ, TIỀN MÃ HÓA THEO CHU KỲ
  // ===================================================================
  // mu: lợi suất kỳ vọng / năm (ngoài biến động thị trường), sd: độ biến động riêng, beta: độ nhạy với thị trường, div: cổ tức
  var STK_VN = [
    { k: 'E1VFVN30', n: 'quỹ ETF VN30 (30 công ty lớn nhất)', mu: 0.02, sd: 0.04, beta: 1, div: 0.02 },
    { k: 'VCB', n: 'Vietcombank (ngân hàng)', mu: 0.03, sd: 0.14, beta: 0.9, div: 0.01 },
    { k: 'FPT', n: 'FPT (công nghệ)', mu: 0.07, sd: 0.2, beta: 1.1, div: 0.02 },
    { k: 'VNM', n: 'Vinamilk (sữa, tiêu dùng)', mu: -0.01, sd: 0.12, beta: 0.6, div: 0.05 },
    { k: 'HPG', n: 'Hòa Phát (thép)', mu: 0.02, sd: 0.3, beta: 1.4, div: 0.01 },
    { k: 'MWG', n: 'Thế Giới Di Động (bán lẻ)', mu: 0.02, sd: 0.28, beta: 1.2, div: 0.01 },
    { k: 'GAS', n: 'PV GAS (năng lượng)', mu: 0, sd: 0.18, beta: 0.8, div: 0.05 },
    { k: 'PENNY', n: 'một mã "penny" đang được thổi giá', mu: -0.12, sd: 0.7, beta: 1.8, div: 0, risky: 0.1 }
  ];
  var STK_W = [
    { k: 'SPY', n: 'quỹ ETF S&P 500 (500 công ty lớn của Mỹ)', mu: 0.02, sd: 0.04, beta: 1, div: 0.015 },
    { k: 'AAPL', n: 'Apple (công nghệ)', mu: 0.05, sd: 0.22, beta: 1.1, div: 0.005 },
    { k: 'MSFT', n: 'Microsoft (phần mềm)', mu: 0.05, sd: 0.2, beta: 1, div: 0.008 },
    { k: 'NVDA', n: 'NVIDIA (chip, trí tuệ nhân tạo)', mu: 0.1, sd: 0.45, beta: 1.6, div: 0 },
    { k: 'KO', n: 'Coca-Cola (tiêu dùng)', mu: -0.01, sd: 0.1, beta: 0.5, div: 0.03 },
    { k: 'TM', n: 'Toyota (ô tô)', mu: 0, sd: 0.18, beta: 0.9, div: 0.025 },
    { k: 'PENNY', n: 'một cổ phiếu "penny" trên mạng xã hội', mu: -0.12, sd: 0.7, beta: 1.8, div: 0, risky: 0.1 }
  ];
  function stocks(l) { return isVN(l) || (l.abroad && !l.abroad.perm) ? STK_VN : STK_W; }
  function stk(l, k) { return stocks(l).concat(STK_VN, STK_W).filter(function (s) { return s.k === k; })[0]; }
  var MKT_RET = { 'tăng mạnh': 0.2, 'bình thường': 0.06, 'đi xuống': -0.14, 'sập': -0.32 };
  // tiền mã hóa: chu kỳ thị trường riêng
  var CREG = {
    'tăng mạnh (bull)': { m: 0.7, next: { 'tăng mạnh (bull)': 0.45, 'đi ngang': 0.25, 'giảm sâu (bear)': 0.3 } },
    'đi ngang': { m: 0.02, next: { 'tăng mạnh (bull)': 0.3, 'đi ngang': 0.45, 'giảm sâu (bear)': 0.25 } },
    'giảm sâu (bear)': { m: -0.45, next: { 'đi ngang': 0.45, 'giảm sâu (bear)': 0.35, 'sập': 0.1, 'tăng mạnh (bull)': 0.1 } },
    'sập': { m: -0.7, next: { 'giảm sâu (bear)': 0.6, 'đi ngang': 0.4 } }
  };
  var COINS = [
    { k: 'BTC', n: 'Bitcoin (BTC)', beta: 1, sd: 0.3 },
    { k: 'ETH', n: 'Ethereum (ETH)', beta: 1.2, sd: 0.4 },
    { k: 'SOL', n: 'một altcoin lớn (SOL)', beta: 1.5, sd: 0.55 },
    { k: 'MEME', n: 'một đồng memecoin đang hot trên mạng', beta: 2.2, sd: 1, rug: 0.3 }
  ];
  function coin(k) { return COINS.filter(function (c) { return c.k === k; })[0]; }
  function idle(l) { return Math.max(0, l.money - l.base * 0.3); }
  function hold(l, key) { return l[key] || (l[key] = {}); }
  function sum(o) { var s = 0; for (var k in (o || {})) s += o[k].v || 0; return s; }
  E.portValue = function (l) { return sum(l.port) + sum(l.coins); };
  var nw0 = E.netWorth; E.netWorth = function (l) { return nw0.apply(this, arguments) + E.portValue(l); };
  function buyInto(l, key, k, amt, why) { var h = hold(l, key); h[k] = h[k] || { v: 0, basis: 0 }; h[k].v += amt; h[k].basis += amt; H.cash(l, -amt, why); }
  function sellAll(l, key, log, label) {
    var h = l[key] || {}, tot = 0, bas = 0; for (var k in h) { tot += h[k].v; bas += h[k].basis; }
    if (tot <= 0) return; H.cash(l, tot, 'Bán ' + label); l[key] = {};
    log('Bán toàn bộ ' + label + ', thu về ' + mo(l, tot) + ' (' + (tot >= bas ? 'lãi ' + mo(l, tot - bas) : 'lỗ ' + mo(l, bas - tot)) + ').', tot >= bas ? 'good' : 'bad');
  }
  SC('co_phieu', {
    title: 'Mua cổ phiếu', valid: function (l) { return l.indep; },
    text: function (l) { var M = l.mkt ? l.mkt.stock : 'bình thường'; return 'Thị trường chứng khoán đang ' + M + '. Tiền nhàn rỗi: ' + mo(l, idle(l)) + (sum(l.port) > 0 ? '. Danh mục hiện có: ' + mo(l, sum(l.port)) : '') + '. Mỗi lần bỏ vào khoảng 20% tiền nhàn rỗi. Cổ phiếu lên xuống theo thị trường và theo từng công ty; công ty lớn thì ổn định, có cổ tức, "cổ phiếu penny" thì như canh bạc.'; },
    opts: [].concat(STK_VN.map(function (s) { return s.k; }), STK_W.map(function (s) { return 'w' + s.k; })).map(function (key) {
      var w = key.charAt(0) === 'w' && key !== 'wPENNY' ? true : key === 'wPENNY';
      var k = w ? key.slice(1) : key;
      return { k: key, l: function (l) { var s = stk(l, k); return 'Mua ' + s.n; }, h: function (l) { var s = stk(l, k); return mo(l, idle(l) * 0.2) + ' · ' + (s.risky ? 'cực kỳ rủi ro' : s.sd >= 0.35 ? 'biến động mạnh' : s.sd >= 0.18 ? 'biến động vừa' : 'ổn định') + (s.div ? ' · cổ tức ~' + Math.round(s.div * 100) + '%/năm' : ''); },
        req: function (l) { var list = stocks(l); return (w ? list === STK_W : list === STK_VN) && idle(l) > l.base * 0.05; },
        ai: function (l) { var s = stk(l, k); return s.risky ? 0.2 : s.k === 'E1VFVN30' || s.k === 'SPY' ? 1.4 : 0.7; },
        run: function (l, r, log) { var s = stk(l, k), x = idle(l) * 0.2; buyInto(l, 'port', s.k, x, 'Mua cổ phiếu ' + s.k); log('Mua ' + mo(l, x) + ' ' + s.n + '.', 'neutral'); } };
    }).concat([
      { k: 'sell', l: 'Bán hết cổ phiếu đang có', req: function (l) { return sum(l.port) > 0.5; }, ai: { w: 0.3 }, run: function (l, r, log) { sellAll(l, 'port', log, 'cổ phiếu'); } },
      { k: 'no', l: 'Thôi, chưa mua', ai: { w: 0.5 }, run: function () { } }
    ])
  });
  SC('tien_ao', {
    title: 'Đầu tư tiền mã hóa', valid: function (l) { return l.indep && l.age >= 18; },
    text: function (l) { var R = l.cmkt || 'đi ngang'; return 'Thị trường tiền mã hóa đang ' + R + '. Mỗi lần bỏ vào khoảng 15% tiền nhàn rỗi (' + mo(l, idle(l) * 0.15) + ')' + (sum(l.coins) > 0 ? '; đang nắm giữ ' + mo(l, sum(l.coins)) : '') + '. Giá có thể gấp đôi trong vài tháng — hoặc mất 80% trong vài tuần. Sàn giao dịch cũng có thể phá sản.'; },
    opts: COINS.map(function (c) {
      return { k: c.k, l: 'Mua ' + c.n, h: c.rug ? 'Có thể tăng trăm lần, nhưng phần lớn về 0' : c.k === 'BTC' ? 'Đồng lớn nhất, ít rủi ro nhất trong tiền ảo — vẫn rất biến động' : 'Biến động mạnh hơn Bitcoin',
        req: function (l) { return idle(l) > l.base * 0.05; }, ai: { risk: 1.2, w: c.rug ? 0.3 : 0.6 },
        run: function (l, r, log) { var x = idle(l) * 0.15; buyInto(l, 'coins', c.k, x, 'Mua ' + c.k); log('Mua ' + mo(l, x) + ' ' + c.n + '.', 'neutral'); } };
    }).concat([
      { k: 'sell', l: 'Bán hết tiền mã hóa đang giữ', req: function (l) { return sum(l.coins) > 0.5; }, ai: { w: 0.4 }, run: function (l, r, log) { sellAll(l, 'coins', log, 'tiền mã hóa'); } },
      { k: 'no', l: 'Thôi, tránh xa cho lành', ai: { w: 0.8, smart: 0.6 }, run: function () { } }
    ])
  });
  // nối vào "Đầu tư": mua cổ phiếu / tiền ảo mở bảng chọn chi tiết
  if (E.DEC.dau_tu) E.DEC.dau_tu.def.opts.forEach(function (o) {
    if (o.k === 'stock') { o.l = 'Mua cổ phiếu (chọn công ty, quỹ chỉ số)'; o.h = 'Mở danh sách cổ phiếu'; o.run = function (l, r, log) { H.chain(l, 'co_phieu'); }; }
    if (o.k === 'crypto') { o.l = 'Đầu tư tiền mã hóa'; o.h = 'Bitcoin, Ethereum, altcoin, memecoin — rất rủi ro'; o.run = function (l, r, log) { H.chain(l, 'tien_ao'); }; }
  });
  A('ban_dau_tu_moi', 'Tiền bạc', 'Bán cổ phiếu / tiền mã hóa', { min: 18, avail: function (l) { return E.portValue(l) > 0.5 ? true : 'Chưa nắm giữ cổ phiếu / tiền ảo'; }, sc: 'ban_dt_moi' });
  SC('ban_dt_moi', {
    title: 'Bán bớt đầu tư', valid: function (l) { return E.portValue(l) > 0.5; },
    text: function (l) { return 'Cổ phiếu: ' + mo(l, sum(l.port)) + ' · tiền mã hóa: ' + mo(l, sum(l.coins)) + '.'; },
    opts: [
      { k: 'port', l: 'Bán hết cổ phiếu', req: function (l) { return sum(l.port) > 0.5; }, run: function (l, r, log) { sellAll(l, 'port', log, 'cổ phiếu'); } },
      { k: 'coins', l: 'Bán hết tiền mã hóa', req: function (l) { return sum(l.coins) > 0.5; }, run: function (l, r, log) { sellAll(l, 'coins', log, 'tiền mã hóa'); } },
      { k: 'keep', l: 'Giữ tiếp', run: function () { } }
    ]
  });
  // biến động mỗi năm
  E.HOOKS.year.push(function (l, r, log, a) {
    if (!l.alive) return;
    // chu kỳ thị trường tiền mã hóa (chạy cho mọi người để giá cả nhất quán theo năm)
    var cur = l.cmkt || 'đi ngang', nx = CREG[cur].next, x = r(), acc = 0, nxt = cur;
    for (var k in nx) { acc += nx[k]; if (x < acc) { nxt = k; break; } }
    l.cmkt = nxt;
    var M = MKT_RET[(l.mkt && l.mkt.stock) || 'bình thường'] || 0.06;
    if (l.port && sum(l.port) > 0) {
      var parts = [], before = sum(l.port), divs = 0;
      for (var s in l.port) {
        var S = stk(l, s) || { mu: 0, sd: 0.2, beta: 1, div: 0 }, h = l.port[s];
        if (S.risky && ch(r, S.risky)) { parts.push(s + ' bị hủy niêm yết (−100%)'); h.v = 0; continue; }
        var g = Math.max(-0.85, S.beta * (M - 0.06) + 0.06 + S.mu + U.normal(r) * S.sd);
        h.v *= 1 + g; divs += h.v * S.div; parts.push(s + ' ' + pct(g));
      }
      for (var s2 in l.port) if (!(l.port[s2].v > 0.01)) delete l.port[s2];
      if (divs > 0) H.cash(l, divs, 'Cổ tức');
      log('Danh mục cổ phiếu: ' + parts.join(' · ') + ' — tổng ' + mo(l, sum(l.port)) + (divs > 0 ? ', nhận cổ tức ' + mo(l, divs) : '') + '.', 'money');
    }
    if (l.coins && sum(l.coins) > 0) {
      var cp = [], base = CREG[nxt].m;
      if (ch(r, 0.015)) { for (var c0 in l.coins) l.coins[c0].v *= 0.5; log('Sàn giao dịch tiền mã hóa bạn dùng tuyên bố phá sản, rút được chưa tới một nửa số tiền.', 'bad'); fx(l, { hap: -8 }); }
      for (var c in l.coins) {
        var C = coin(c) || { beta: 1, sd: 0.4 }, hc = l.coins[c];
        if (C.rug && ch(r, C.rug)) { cp.push(c + ' bị "rug pull", về 0'); hc.v = 0; continue; }
        var gc = Math.max(-0.95, base * C.beta + U.normal(r) * C.sd);
        if (C.rug && ch(r, 0.05)) gc = 5 + r() * 15; // hiếm khi memecoin tăng vọt
        hc.v *= 1 + gc; cp.push(c + ' ' + pct(gc));
      }
      for (var c2 in l.coins) if (!(l.coins[c2].v > 0.01)) delete l.coins[c2];
      log('Tiền mã hóa (thị trường ' + nxt + '): ' + cp.join(' · ') + ' — còn ' + mo(l, sum(l.coins)) + '.', 'money');
      if (nxt === 'sập' && sum(l.coins) > l.base) { fx(l, { hap: -6 }); if (l.mind) l.mind.stress += 10; }
    }
  });
  // hồ sơ chi tiết có thêm danh mục đầu tư
  var pf0 = E.profile;
  if (pf0) E.profile = function (l) { var P = pf0.apply(this, arguments); for (var s in (l.port || {})) P.assets.push(['Cổ phiếu ' + s, l.port[s].v]); for (var c in (l.coins || {})) P.assets.push(['Tiền mã hóa ' + c, l.coins[c].v]); P.net = E.netWorth(l); return P; };
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
