/* ===== js/life37.js ===== */
/* Một Đời — v3.7: LGBT+ (góp ý của người chơi)
   · tạo nhân vật: Bột tôm (đồng tính nam – bottom), Tóp mỡ (đồng tính nam – top), Bé Liên (đồng tính nữ), Bi (song tính)
   · tuổi thơ như mọi bạn khác; khoảng 12–13 tuổi nhận ra mình rung động với ai
   · tình huống: thầm thương bạn cùng lớp, nói với bạn thân, bố mẹ giục cưới, đi VietPride, ra mắt người yêu cùng giới với gia đình,
     về chung một nhà, hàng xóm / chủ nhà dò hỏi, hội bạn trêu "ai là tóp mỡ, ai là bột tôm", bị hiểu lầm "song tính là chưa quyết định"…
   Nhân vật và tình huống đều hư cấu, viết với tinh thần tôn trọng. */
(function (G) {
  'use strict';
  var U = G.U, E = G.E, H = E.H, SC = E.SC, isVN = H.isVN;
  function fx(l, o) { H.fx(l, o); }
  function pick(r, a) { return U.pick(r, a); }
  function ch(r, p) { return r() < p; }
  function free(l) { return !(l.jailUntil != null && l.age < l.jailUntil) && !(l.abroad && l.abroad.trapped) && !(l.flags.military && l.age < l.flags.military); }
  function lg(l) { return l.orient !== 'straight' && l.realized; }
  function gayM(l) { return l.orient === 'gay' && l.sex === 'M'; }
  function same(l) { return !!(l.partner && l.partner.sex === l.sex); }
  function T(id, when, p, cd, max) { E.TRIG.push({ id: id, when: function (l, a) { return free(l) && when(l, a); }, p: p, cd: cd || 4, max: max || 1 }); }
  function pa(l) { return l.fam.mAlive && l.fam.fAlive ? 'bố mẹ' : l.fam.mAlive ? 'mẹ' : l.fam.fAlive ? 'bố' : 'họ hàng'; }

  // ---------- nhận ra mình (khoảng 12–13 tuổi) ----------
  E.realizeText = function (l, r) {
    var cls = l.school ? 'cùng lớp' : 'trong xóm';
    if (l.orient === 'bi') return pick(r, ['Năm ' + l.age + ' tuổi, bạn nhận ra mình có thể rung động với cả bạn nam lẫn bạn nữ — thích ai là thích con người ấy.', 'Bạn bối rối khi thấy mình vừa để ý một bạn nam ' + cls + ', vừa thấy tim đập nhanh khi cô bạn ngồi cạnh cười. Hóa ra mình thích được cả hai.']);
    if (l.sex === 'F') return pick(r, ['Năm ' + l.age + ' tuổi, bạn nhận ra mình rung động với cô bạn ' + cls + ' chứ không phải mấy bạn nam như đám bạn gái hay bàn tán.', 'Cả lớp gán ghép bạn với một bạn nam, nhưng người khiến bạn đỏ mặt lại là cô bạn thân.']);
    if (false) return pick(r, ['Năm ' + l.age + ' tuổi, bạn nhận ra mình để ý một bạn nam ' + cls + ' — lúc nào cũng muốn đứng ra che chắn, lo lắng cho cậu ấy.', 'Đám con trai bàn tán về con gái, còn bạn chỉ để ý cậu bạn hiền lành bàn bên — muốn làm "chỗ dựa" cho cậu ấy.']);
    return pick(r, ['Năm ' + l.age + ' tuổi, bạn nhận ra mình hay để ý một bạn nam ' + cls + ' — tim đập nhanh mỗi lần cậu ấy hỏi han, thích được cậu ấy quan tâm.', 'Đám con trai bàn tán về con gái, còn bạn chỉ để ý anh lớp trên đá bóng giỏi, thích được anh ấy chở đi học.']);
  };

  // ---------- người yêu đồng tính nam: tóp mỡ – bột tôm thường bổ sung cho nhau ----------
  var lm0 = E.DEC.love.make, la0 = E.DEC.love.apply;
  E.DEC.love.make = function (l, r) {
    var d = lm0.apply(this, arguments), p = d.data.p;
    if (p.sex === 'M' && l.sex === 'M' && l.orient !== 'straight') p.role = l.role === 'top' ? (r() < 0.8 ? 'bot' : 'top') : l.role === 'bot' ? (r() < 0.8 ? 'top' : 'bot') : (r() < 0.5 ? 'top' : 'bot');
    return d;
  };
  E.DEC.love.apply = function (l, d, k) { var x = la0.apply(this, arguments); if (k === 'yes' && l.partner && d.data.p.role) l.partner.role = d.data.p.role; return x; };

  // ---------- tình huống ----------
  SC('lg_crush', {
    title: 'Thầm thương', prep: function (l, r) { var s = l.orient === 'bi' ? (r() < 0.5 ? 'M' : 'F') : l.sex; return { s: s, n: H.stranger(l, r, s) }; },
    text: function (l, d) { return 'Bạn thầm thương ' + d.n + ' — ' + (d.s === l.sex ? 'một bạn cùng giới' : 'một bạn khác giới') + ' ' + (l.school ? 'học cùng trường' : 'ở gần nhà') + '. Ngày nào cũng tìm cớ đi chung đường, nhưng không biết ' + d.n + ' có giống mình không.'; },
    valid: function (l) { return !l.partner; },
    opts: [
      { k: 'noi', l: 'Lấy hết can đảm nói ra', ai: { risk: 0.8, soc: 0.6 }, run: function (l, r, log, d) { if (d.s !== l.sex ? ch(r, 0.45) : ch(r, 0.3)) { log(d.n + ' đỏ mặt rồi gật đầu: "Tớ cũng thế." Mối tình đầu vụng về mà ngọt ngào.', 'good'); fx(l, { hap: 8 }); if (!l.flags.firstLove) l.flags.firstLove = d.n; H.mem(l, 'Lời tỏ tình run rẩy với ' + d.n + '.', 5); } else if (d.s === l.sex && ch(r, 0.5)) { log(d.n + ' bất ngờ nhưng nhẹ nhàng: "Mình chỉ coi bạn là bạn thôi, nhưng mình sẽ giữ bí mật." Bạn buồn mà nhẹ lòng.', 'neutral'); fx(l, { hap: -2 }); } else { log(d.n + ' từ chối, rồi chuyện lan ra cả lớp. Mấy tuần đó bạn chẳng muốn đến trường.', 'bad'); fx(l, { hap: -8 }); if (l.mind) l.mind.stress += 10; } } },
      { k: 'giu', l: 'Giữ kín trong lòng', ai: { w: 1.2 }, run: function (l, r, log, d) { log('Giữ kín tình cảm với ' + d.n + '. Có những bí mật tuổi học trò chỉ mình mình biết.', 'neutral'); H.mem(l, 'Mối tình thầm lặng với ' + d.n + '.', 3); } }
    ]
  });
  T('lg_crush', function (l, a) { return lg(l) && a >= 13 && a <= 18 && !l.partner; }, 0.35, 4, 1);

  SC('lg_ban_than', {
    title: 'Nói với bạn thân', valid: function (l) { return !!(l.bff && l.bff.alive); },
    text: function (l) { return 'Bạn muốn nói với ' + l.bff.name + ' — người bạn thân nhất — rằng mình là ' + E.orientLabel(l).toLowerCase() + '.'; },
    opts: [
      { k: 'noi', l: 'Nói thật', ai: { soc: 1, w: 1 }, run: function (l, r, log) { if (ch(r, 0.78)) { log(l.bff.name + ' ôm bạn: "Mày là mày, tao quý mày vì mày là mày." Từ đó hai đứa càng thân.', 'good'); fx(l, { hap: 6 }); l.bff.close = Math.min(100, (l.bff.close || 60) + 15); H.mem(l, 'Ngày nói thật với ' + l.bff.name + ' và nhận lại một cái ôm.', 4); } else { log(l.bff.name + ' im lặng mấy ngày, rồi xa dần. Bạn buồn nhưng không hối hận vì đã sống thật.', 'bad'); l.bff.close = Math.max(0, (l.bff.close || 60) - 30); fx(l, { hap: -5 }); } } },
      { k: 'chua', l: 'Chưa sẵn sàng', ai: { w: 0.8 }, run: function (l, r, log) { log('Định nói rồi lại thôi.', 'neutral'); } }
    ]
  });
  T('lg_ban_than', function (l, a) { return lg(l) && a >= 14 && a <= 30 && !!(l.bff && l.bff.alive); }, 0.15, 5, 1);

  SC('lg_pride', {
    title: 'Ngày hội tự hào',
    text: function (l) { return isVN(l) && !(l.abroad && l.abroad.perm) ? 'Cuối tuần này có ngày hội VietPride: đạp xe diễu hành, hội thảo, âm nhạc, ai cũng mang cờ cầu vồng. Hội bạn rủ bạn đi cùng.' : 'Thành phố tổ chức lễ diễu hành Pride, cả con phố rợp cờ cầu vồng. Bạn bè rủ bạn đi cùng.'; },
    opts: [
      { k: 'di', l: 'Đi cùng hội bạn', ai: { soc: 1, w: 1.2 }, run: function (l, r, log) { log('Hòa vào dòng người diễu hành, lần đầu thấy mình không hề lạc lõng. Quen thêm nhiều bạn mới.', 'good'); fx(l, { hap: 8, soc: 5 }); if (l.mind) l.mind.stress = Math.max(0, l.mind.stress - 8); H.mem(l, 'Ngày hội cầu vồng, cả một biển người mỉm cười với nhau.', 4); } },
      { k: 'xem', l: 'Chỉ xem livestream ở nhà', ai: { w: 0.8 }, run: function (l, r, log) { log('Xem livestream, thấy ấm lòng. Hẹn năm sau sẽ đi.', 'neutral'); fx(l, { hap: 2 }); } }
    ]
  });
  T('lg_pride', function (l, a) { return lg(l) && a >= 17 && a <= 45 && l.urban && !(l.abroad && !l.abroad.perm); }, 0.15, 5, 2);

  SC('lg_giuc_cuoi', {
    title: 'Bao giờ lấy vợ / lấy chồng?',
    valid: function (l) { return !l.out && (l.fam.mAlive || l.fam.fAlive); },
    text: function (l) { return 'Tết năm nay, ' + pa(l) + ' và họ hàng lại hỏi: "' + l.age + ' tuổi rồi, bao giờ ' + (l.sex === 'M' ? 'lấy vợ' : 'lấy chồng') + '?" ' + U.cap(pa(l)) + ' còn đã nhờ người mai mối một ' + (l.sex === 'M' ? 'cô gái' : 'chàng trai') + ' ở quê.'; },
    opts: [
      { k: 'noi_that', l: 'Nhân dịp này, nói thật với gia đình', ai: { soc: 0.8, w: 0.9 }, run: function (l, r, log) { l.pending.unshift(E.DEC.out.make(l, r)); } },
      { k: 'gat', l: 'Lấy cớ "đang tập trung sự nghiệp"', ai: { w: 1.1 }, run: function (l, r, log) { log('Lại một cái Tết trốn tránh bằng câu "con đang lo sự nghiệp".', 'neutral'); fx(l, { hap: -2 }); if (l.mind) l.mind.stress += 4; } },
      { k: 'di_xem_mat', l: 'Chiều lòng ' + 'gia đình, đi xem mặt cho xong', ai: { w: 0.5 }, run: function (l, r, log) { log('Đi xem mặt cho bố mẹ vui. Cả buổi hai người nói chuyện lịch sự rồi chẳng ai liên lạc lại. Bạn thấy mệt vì phải đóng vai.', 'neutral'); fx(l, { hap: -4 }); if (l.mind) l.mind.stress += 6; } }
    ]
  });
  T('lg_giuc_cuoi', function (l, a) { return lg(l) && isVN(l) && a >= 25 && a <= 40 && !l.out && !(l.partner && l.partner.sex !== l.sex && l.partner.status !== 'dating'); }, 0.18, 3, 3);

  SC('lg_ra_mat', {
    title: 'Ra mắt gia đình', valid: function (l) { return same(l) && (l.fam.mAlive || l.fam.fAlive); },
    text: function (l) { return 'Bạn và ' + l.partner.name + ' đã bên nhau ' + Math.max(1, l.age - l.partner.since) + ' năm. ' + U.cap(pa(l)) + (l.out ? ' đã biết bạn là ' + E.orientLabel(l).toLowerCase() + ', nhưng chưa từng gặp người ấy.' : ' vẫn chưa biết chuyện.') + ' Có nên đưa người ấy về ra mắt?'; },
    opts: [
      { k: 've', l: 'Đưa người ấy về ra mắt', ai: { soc: 1, w: 1.1 }, run: function (l, r, log) { if (!l.out) { l.out = true; } var acc = l.flags.famTension ? 0.35 : 0.65; if (ch(r, acc)) { l.flags.famTension = false; log(U.cap(pa(l)) + ' ngồi nói chuyện với ' + l.partner.name + ' cả buổi, cuối bữa gắp cho người ấy miếng thịt ngon nhất: "Hai đứa thương nhau thì sống cho tử tế."', 'good'); fx(l, { hap: 10 }); H.mem(l, 'Bữa cơm đầu tiên ' + l.partner.name + ' ngồi cùng mâm với gia đình.', 6); } else { l.flags.famTension = true; log('Bữa cơm im lặng. ' + U.cap(pa(l)) + ' chưa thể chấp nhận, nhưng cũng không đuổi người ấy về.', 'bad'); fx(l, { hap: -6 }); } } },
      { k: 'chua', l: 'Chưa phải lúc', ai: { w: 0.8 }, run: function (l, r, log) { log('Hẹn với người ấy: "Đợi thêm một thời gian nữa nhé."', 'neutral'); } }
    ]
  });
  T('lg_ra_mat', function (l, a) { return same(l) && a - l.partner.since >= 1 && !l.flags.lgRaMat; }, 0.3, 3, 1);
  // ra mắt xong thì không hỏi lại
  var rmA = E.DEC.lg_ra_mat.apply; E.DEC.lg_ra_mat.apply = function (l, d, k) { if (k === 've') l.flags.lgRaMat = true; return rmA.apply(this, arguments); };

  SC('lg_hang_xom', {
    title: 'Hàng xóm dò hỏi', valid: function (l) { return same(l) && l.partner.status !== 'dating'; },
    text: function (l) { return 'Từ ngày bạn và ' + l.partner.name + ' về ở chung, bà chủ nhà / hàng xóm cứ dò hỏi: "Hai ' + (l.sex === 'M' ? 'cậu' : 'cô') + ' là anh em họ à? Sao đi đâu cũng có nhau?"'; },
    opts: [
      { k: 'that', l: 'Cười, nói thật: "Bọn cháu là người yêu ạ"', ai: { soc: 1, w: 1 }, run: function (l, r, log) { if (ch(r, 0.7)) { log('Bà chủ nhà ngớ người, rồi cười xòa: "Thời buổi này thương nhau là được. Có gì ngon thì sang bà cho!" Từ đó hay mang chè sang.', 'good'); fx(l, { hap: 4, soc: 2 }); } else { log('Hàng xóm xì xào mấy tuần, rồi cũng quen.', 'neutral'); fx(l, { hap: -1 }); } } },
      { k: 'lang', l: 'Lảng sang chuyện khác', ai: { w: 0.8 }, run: function (l, r, log) { log('"Dạ, bạn cùng phòng thôi ạ." Về nhà người ấy hơi buồn.', 'neutral'); fx(l, { hap: -2 }); } }
    ]
  });
  T('lg_hang_xom', function (l, a) { return same(l) && l.partner.status !== 'dating'; }, 0.08, 5, 1);

  SC('lg_hoi_ban_treu', {
    title: 'Hội bạn trêu', valid: function (l) { return false; }, // v4.5: bỏ chuyện "top / bot" — đó là chuyện riêng tư, không phải xu hướng tính dục
    text: function (l) { return 'Trong bữa nhậu, hội bạn thân trêu bạn và ' + l.partner.name + ': "Thế rốt cuộc trong nhà ai là tóp mỡ, ai là bột tôm?" Cả bàn cười ồ.'; },
    opts: [
      { k: 'cuoi', l: 'Cười, đáp lại cho vui', ai: { w: 1.2 }, run: function (l, r, log) { var me = l.role === 'top', pr = l.partner.role; log(me && pr === 'bot' ? '"Tóp mỡ thì đi làm nuôi nhà, bột tôm thì quản lý tài chính!" — ' + l.partner.name + ' gật đầu xác nhận, cả bàn vỗ tay.' : !me && pr === 'top' ? '"Hỏi ' + l.partner.name + ' ấy, người ta lo hết từ bữa sáng đến cái bóng đèn!" Cả bàn cười nghiêng ngả.' : '"Nhà này hai bột tôm / hai tóp mỡ, nên việc gì cũng chia đôi!" Cả bàn cười không ngớt.', 'good'); fx(l, { hap: 4, soc: 3 }); } },
      { k: 'nghiem', l: 'Nhắc khéo: chuyện riêng tư thì để riêng', ai: { w: 0.7 }, run: function (l, r, log) { log('Nhắc khéo một câu, hội bạn xin lỗi rồi chuyển chủ đề. Ai cũng hiểu ranh giới.', 'neutral'); } }
    ]
  });
  T('lg_hoi_ban_treu', function (l, a) { return same(l) && l.sex === 'M' && a >= 20; }, 0.12, 6, 1);

  SC('lg_bi_hieu_lam', {
    title: 'Bị hiểu lầm', valid: function (l) { return l.orient === 'bi'; },
    text: function (l) { return 'Một người quen nói thẳng: "Song tính á? Chắc là chưa quyết định được thôi, rồi cũng sẽ chọn một bên."'; },
    opts: [
      { k: 'giai_thich', l: 'Bình tĩnh giải thích: thích ai là thích con người ấy', ai: { smart: 1, w: 1.1 }, run: function (l, r, log) { log('Giải thích nhẹ nhàng. Người kia nghĩ một lúc: "Ừ, nghe cũng có lý." Bạn thấy nhẹ nhõm.', 'good'); fx(l, { hap: 2, soc: 1 }); } },
      { k: 'ke', l: 'Kệ, không cần ai hiểu', ai: { w: 0.8 }, run: function (l, r, log) { log('Mỉm cười cho qua. Mình hiểu mình là đủ.', 'neutral'); } }
    ]
  });
  T('lg_bi_hieu_lam', function (l, a) { return lg(l) && l.orient === 'bi' && a >= 16 && a <= 50; }, 0.12, 6, 1);

  SC('lg_cong_so', {
    title: 'Câu đùa ở chỗ làm', valid: function (l) { return !!l.job && H.isEmployee(l); },
    text: function (l) { return 'Một đồng nghiệp hay pha trò về người đồng tính trong giờ nghỉ trưa, cả phòng cười. Không ai biết bạn là ' + E.orientLabel(l).toLowerCase() + '.'; },
    opts: [
      { k: 'nhac', l: 'Nhẹ nhàng nhắc: "Câu đùa này hơi quá rồi đó"', ai: { w: 1.1 }, run: function (l, r, log) { if (ch(r, 0.65)) { log('Đồng nghiệp ngượng, xin lỗi. Mấy người khác nhắn riêng cảm ơn bạn.', 'good'); fx(l, { hap: 3 }); } else log('Đồng nghiệp bĩu môi "đùa thôi mà". Không khí hơi gượng.', 'neutral'); } },
      { k: 'bao', l: 'Góp ý với phòng nhân sự về quy tắc ứng xử', ai: { smart: 0.8 }, run: function (l, r, log) { log('Phòng nhân sự nhắc nhở chung cả công ty về tôn trọng sự khác biệt.', 'good'); } },
      { k: 'im', l: 'Cười trừ cho qua', ai: { w: 0.7 }, run: function (l, r, log) { log('Cười trừ, nhưng tối về thấy nặng lòng.', 'neutral'); fx(l, { hap: -2 }); } }
    ]
  });
  T('lg_cong_so', function (l, a) { return lg(l) && !!l.job && H.isEmployee(l) && a >= 20 && a <= 55; }, 0.04, 6, 1);

  SC('lg_be_lien', {
    title: 'Hội chị em', valid: function (l) { return l.sex === 'F'; },
    text: function (l) { return 'Bạn được rủ vào một nhóm bạn nữ đồng tính trong thành phố — cuối tuần cà phê, đi phượt, có cả buổi chia sẻ chuyện công khai với gia đình. Mọi người gọi đùa nhau là "hội bé Liên".'; },
    opts: [
      { k: 'vao', l: 'Tham gia', ai: { soc: 1, w: 1.1 }, run: function (l, r, log) { log('Có thêm những người chị em hiểu mình. Cuối tuần nào cũng rộn ràng.', 'good'); fx(l, { hap: 5, soc: 4 }); if (!l.partner && ch(r, 0.35)) l.pending.unshift(E.DEC.love.make(l, r, { where: 'trong hội bạn nữ cùng cộng đồng' })); } },
      { k: 'thoi', l: 'Thôi, mình thích một mình hơn', ai: { w: 0.6 }, run: function (l, r, log) { log('Từ chối khéo, giữ thế giới riêng của mình.', 'neutral'); } }
    ]
  });
  T('lg_be_lien', function (l, a) { return lg(l) && l.sex === 'F' && l.orient === 'gay' && a >= 18 && a <= 40 && l.urban; }, 0.12, 6, 1);

  SC('lg_nuoi_con', {
    title: 'Làm cha mẹ', valid: function (l) { return same(l) && l.partner.status !== 'dating' && !l.kids.some(function (k) { return k.alive; }); },
    text: function (l) { return 'Bạn và ' + l.partner.name + ' ' + Math.max(1, l.age - l.partner.since) + ' năm sống chung, căn nhà nhỏ bắt đầu thấy vắng. Hai người bàn chuyện nhận nuôi một đứa trẻ' + (isVN(l) ? ' (ở Việt Nam, một người đứng tên nhận con nuôi)' : '') + '.'; },
    opts: [
      { k: 'nuoi', l: 'Tìm hiểu thủ tục nhận con nuôi', ai: { w: 0.8 }, run: function (l, r, log) { var k = E.DEC.kid; var d = k.make(l, r); l.pending.unshift(d); } },
      { k: 'chua', l: 'Hai người là đủ', ai: { w: 1 }, run: function (l, r, log) { log('Quyết định cứ hai người bên nhau, nuôi thêm một chú mèo cho vui nhà.', 'neutral'); } }
    ]
  });
  T('lg_nuoi_con', function (l, a) { return same(l) && l.partner.status !== 'dating' && a >= 28 && a <= 45 && !l.kids.some(function (k) { return k.alive; }); }, 0.12, 4, 1);

  E.MAJOR && (E.MAJOR.lg_ra_mat = 1);

  // mức thân thiết với con, anh chị em luôn trong khoảng 0–100 (một số lựa chọn cộng thêm mà chưa chặn trên)
  E.HOOKS.year.push(function (l) { (l.kids || []).concat(l.sibList || []).forEach(function (k) { if (k.close != null) k.close = U.clamp(isFinite(k.close) ? k.close : 50, 0, 100); }); });
  // chống lặp: những ngày u tối được lên lịch từ nhiều nguồn (căng thẳng, nợ, biến cố) — giãn cách ít nhất 3 năm, tối đa 4 lần một đời
  if (E.DEC.tram_cam) { var tv = E.DEC.tram_cam.def.valid, ta = E.DEC.tram_cam.apply; E.DEC.tram_cam.def.valid = function (l, d) { return (l.flags.tcAt == null || l.age - l.flags.tcAt >= 3) && (l.flags.tcN || 0) < 4 && (!tv || tv(l, d)); }; E.DEC.tram_cam.apply = function (l) { l.flags.tcAt = l.age; l.flags.tcN = (l.flags.tcN || 0) + 1; return ta.apply(this, arguments); }; }
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
/* ===== js/life38.js ===== */
/* Một Đời — v3.8 (góp ý của người chơi):
   · concert các chương trình "Say Hi" / Anh tài theo từng mùa: chọn chương trình → hiện toàn bộ nghệ sĩ → chọn bias để ủng hộ
   · fanmeeting: mua vé, có thể được thần tượng gọi tên, chụp ảnh, hỏi han, tặng quà; nhiều chuyện làm fan (sinh nhật idol, cày vote, photocard, đón sân bay…)
   · đã học võ / học bơi / sơ cứu thì về sau có lúc dùng đến (cứu người bị bắt nạt, cứu người đuối nước…); có năng khiếu thì có dịp thể hiện
   · tương tác theo trend: mua trà sữa cho người yêu, vợ / chồng, anh chị em (chọn món), rủ bạn đi ăn Dookki, gà rán, mì cay, Haidilao, Cửu Vân Long…
   · bị giam trong trại lừa đảo thì không chi tiêu, mua sắm, đi chơi được · người cao tuổi không còn bị "đi học chứng chỉ" */
(function (G) {
  'use strict';
  var U = G.U, E = G.E, H = E.H, SC = E.SC, isVN = H.isVN;
  function A(id, g, label, o) { var x = { id: id, g: g, l: label }; for (var k in o) x[k] = o[k]; E.ACT.push(x); }
  function fx(l, o) { H.fx(l, o); }
  function mo(l, v) { return H.money(l, v); }
  function pick(r, a) { return U.pick(r, a); }
  function ch(r, p) { return r() < p; }
  function free(l) { return !(l.jailUntil != null && l.age < l.jailUntil) && !(l.abroad && l.abroad.trapped) && !(l.flags.military && l.age < l.flags.military); }
  function vnd(l) { return isVN(l) && l.cur === 'vnd' && !(l.abroad && l.abroad.perm); }
  function V(l, tr) { return vnd(l) ? tr : tr / 90 * l.base; }
  function pay(l, tr, why) { var x = Math.min(V(l, tr), Math.max(0, l.money) + l.base * 0.3); if (x > 0) H.cash(l, -x, why); return x; }
  function yr(l) { return l.birthYear + l.age; }
  function T(id, when, p, cd, max) { E.TRIG.push({ id: id, when: function (l, a) { return free(l) && when(l, a); }, p: p, cd: cd || 4, max: max || 1 }); }
  function shuffle(r, a) { a = a.slice(); for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(r() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }

  // ===================================================================
  // 0. SỬA LOGIC: tuổi già không "đi học chứng chỉ"; trại lừa đảo khóa mọi chi tiêu
  // ===================================================================
  var MAXAGE = { hoc_them: 60, thi_lai_cc: 60, bang_lai: 70, cay_thue_them: 35, chuyen_noi_o: 80 };
  E.ACT.forEach(function (a) { if (MAXAGE[a.id] != null && (a.max == null || a.max > MAXAGE[a.id])) a.max = MAXAGE[a.id]; });

  // ===================================================================
  // 1. CONCERT THEO CHƯƠNG TRÌNH, CHỌN BIAS
  // ===================================================================
  var SHOWS = E.SHOWS || [];
  function showsOpen(l) { var y = yr(l); return SHOWS.filter(function (s) { return y >= s.from; }); }
  function showByK(k) { return SHOWS.filter(function (s) { return s.k === k; })[0]; }
  SC('show_chon', {
    title: 'Concert chương trình nào?', text: function (l) { return 'Các chương trình truyền hình thực tế âm nhạc tổ chức concert liên tục. Bạn muốn đi concert của chương trình nào?' + (l.bias ? ' Bias hiện tại của bạn: ' + l.bias.n + ' (' + l.bias.show + ').' : ''); },
    opts: [0, 1, 2, 3, 4, 5].map(function (i) {
      return { k: 's' + i, l: function (l) { var s = showsOpen(l)[i]; return s ? s.n : ''; }, h: function (l) { var s = showsOpen(l)[i]; return s ? s.m.length + ' nghệ sĩ' + (yr(l) - s.b > 65 ? ' · concert lưu trữ' : ' · concert / tái hợp') : ''; }, req: function (l) { return !!showsOpen(l)[i]; }, ai: { w: 1 },
        run: function (l, r, log) { var s = showsOpen(l)[i]; l.pending.unshift(E.DEC.bias_chon.make(l, r, { k: s.k, p: 0 })); } };
    }).concat([{ k: 'no', l: 'Thôi, để dịp khác', ai: { w: 0.2 }, run: function () { } }])
  });
  var PER = 10;
  SC('bias_chon', {
    title: function (l, d) { return 'Bias của bạn ở ' + d.s.n; },
    prep: function (l, r, arg) { var s = showByK(arg && arg.k) || SHOWS[0], p = (arg && arg.p) || 0; return { s: s, p: p, m: s.m.slice(p * PER, p * PER + PER) }; },
    text: function (l, d) { return 'Đội hình ' + d.s.n + ' có ' + d.s.m.length + ' ' + d.s.pre + '. Bạn "đu" ai nhất, muốn cầm banner, lightstick cổ vũ ai? (' + (d.p * PER + 1) + '–' + Math.min(d.s.m.length, d.p * PER + PER) + ' / ' + d.s.m.length + ')'; },
    opts: Array.apply(null, Array(PER)).map(function (_, i) {
      return { k: 'b' + i, l: function (l, d) { return d.m[i] ? U.cap(E.memberName(d.s.pre, d.m[i])) : ''; }, req: function (l, d) { return !!d.m[i]; }, ai: { w: 1 },
        run: function (l, r, log, d) { pickBias(l, r, log, d.s, d.m[i]); } };
    }).concat([
      { k: 'more', l: 'Xem thêm các nghệ sĩ khác ›', req: function (l, d) { return d.s.m.length > (d.p + 1) * PER; }, ai: { w: 0.3 }, run: function (l, r, log, d) { l.pending.unshift(E.DEC.bias_chon.make(l, r, { k: d.s.k, p: d.p + 1 })); } },
      { k: 'back', l: '‹ Xem lại từ đầu', req: function (l, d) { return d.p > 0; }, ai: { w: 0 }, run: function (l, r, log, d) { l.pending.unshift(E.DEC.bias_chon.make(l, r, { k: d.s.k, p: 0 })); } },
      { k: 'all', l: 'Thương hết cả đội hình (all-kill)', ai: { w: 0.4 }, run: function (l, r, log, d) { l.bias = { n: 'cả đội hình', show: d.s.n, all: true }; log('Không chọn được — thương hết cả ' + d.s.m.length + ' ' + d.s.pre + ' của ' + d.s.n + '.', 'neutral'); l.pending.unshift(E.DEC.concert_di.make(l, r, { cat: 'show', name: d.s.n })); } }
    ])
  });
  function pickBias(l, r, log, s, name) {
    var was = l.bias && l.bias.n;
    l.bias = { n: name, show: s.n, pre: s.pre }; l.idol = E.memberName(s.pre, name); l.idolCat = 'show'; l.idolBorn = s.b;
    log(was && was !== name ? 'Chuyển bias sang ' + E.memberName(s.pre, name) + ' — "đu" thêm một người nữa thôi mà.' : 'Chọn ' + E.memberName(s.pre, name) + ' làm bias, cày view, bình chọn nhiệt tình.', 'good'); fx(l, { hap: 2 });
    l.pending.unshift(E.DEC.concert_di.make(l, r, { cat: 'show', name: s.n }));
  }
  if (E.DEC.concert_chon) E.DEC.concert_chon.def.opts.forEach(function (o) { if (o.k === 'show') o.run = function (l, r) { l.pending.unshift(E.DEC.show_chon.make(l, r)); }; });
  // vào concert: cổ vũ bias, đôi khi được "fan service"
  var cda = E.DEC.concert_di.apply;
  E.DEC.concert_di.apply = function (l, d, k, r, log) {
    var went = false, lg = function (t, kk) { if (/Săn được vé|kịp đi xem|đưa bạn đi xem|rủ bạn đi xem|Đi xem /.test(t)) went = true; log(t, kk); };
    var x = cda.call(this, l, d, k, r, lg);
    if (went && l.bias && !l.bias.all && d.data.cat === 'show' && l.bias.show === d.data.name) {
      if (ch(r, 0.12)) { log(U.cap(E.memberName(l.bias.pre || 'anh trai', l.bias.n)) + ' nhìn thấy tấm banner bạn giơ, chỉ thẳng xuống và bắn tim! Bạn hét đến lạc giọng.', 'big'); fx(l, { hap: 8 }); H.mem(l, 'Khoảnh khắc ' + l.bias.n + ' bắn tim về phía mình giữa biển lightstick.', 7); }
      else { log('Cả đêm giơ cao banner tên ' + l.bias.n + ', hát theo từng bài của bias.', 'good'); fx(l, { hap: 2 }); }
    }
    return x;
  };

  // ===================================================================
  // 2. FANMEETING & CHUYỆN LÀM FAN
  // ===================================================================
  function idolName(l) { return l.idol || 'thần tượng'; }
  function vnIdol(l) { return /^(vn|show|rapvn)$/.test(l.idolCat || 'vn'); }
  SC('fanmeeting', {
    title: 'Fanmeeting của thần tượng', valid: function (l) { return !!l.idol; },
    prep: function (l, r) { var vn = vnIdol(l) || !vnd(l); return { city: vnd(l) ? pick(r, ['TP. Hồ Chí Minh', 'Hà Nội']) : (l.place || l.city || 'thành phố'), vip: vn ? 3.5 : 6, thuong: vn ? 1.2 : 2.5 }; },
    text: function (l, d) { return U.cap(idolName(l)) + ' tổ chức fanmeeting ở ' + d.city + ': hát, chơi trò chơi với fan, bốc thăm gọi tên fan lên sân khấu. Vé thường khoảng ' + mo(l, V(l, d.thuong)) + ', vé VIP (hi-touch, chụp ảnh nhóm, quà) khoảng ' + mo(l, V(l, d.vip)) + '.' + (l.age < 16 ? ' Bạn còn nhỏ, phải xin bố mẹ.' : ''); },
    opts: [
      { k: 'vip', l: 'Săn vé VIP', h: function (l, d) { return '~' + mo(l, V(l, d.vip)) + ' · cơ hội được gọi tên cao hơn'; }, ai: { w: 0.8, risk: 0.4 }, run: function (l, r, log, d) { fm(l, r, log, d, 'vip'); } },
      { k: 'thuong', l: 'Mua vé thường', h: function (l, d) { return '~' + mo(l, V(l, d.thuong)); }, ai: { w: 1.1 }, run: function (l, r, log, d) { fm(l, r, log, d, 'thuong'); } },
      { k: 'khong', l: 'Xem livestream, để dành tiền', ai: { w: 0.7 }, run: function (l, r, log) { log('Xem livestream fanmeeting, chụp màn hình lúc ' + idolName(l) + ' cười.', 'neutral'); fx(l, { hap: 1 }); } }
    ]
  });
  function fm(l, r, log, d, t) {
    if (ch(r, t === 'vip' ? 0.35 : 0.2)) { log('Canh mở bán vé fanmeeting ' + idolName(l) + ' — vé hết sạch sau 2 phút. Bạn ôm điện thoại thẫn thờ.', 'bad'); fx(l, { hap: -4 }); return; }
    pay(l, t === 'vip' ? d.vip : d.thuong, 'Vé fanmeeting ' + idolName(l));
    var lucky = ch(r, t === 'vip' ? 0.22 : 0.07);
    if (!lucky) { log('Đi fanmeeting ' + idolName(l) + ' ở ' + d.city + (t === 'vip' ? ', được hi-touch và chụp ảnh nhóm' : '') + '. Về nhà vẫn còn cười một mình.', 'good'); fx(l, { hap: t === 'vip' ? 8 : 6 }); return; }
    var fs = pick(r, [
      U.cap(idolName(l)) + ' bốc thăm trúng số ghế của bạn, gọi tên bạn lên sân khấu, hỏi: "Em đi một mình hay đi với bạn?", rồi ôm bạn chụp một tấm ảnh polaroid ký tên tặng.',
      'Bạn được gọi tên lên chơi trò chơi cùng ' + idolName(l) + '. Thua cuộc, ' + idolName(l) + ' cười xòa rồi vẫn tặng bạn món quà tự tay chuẩn bị.',
      'Đến lượt hi-touch, ' + idolName(l) + ' nhớ ra bạn: "Em là người hay cầm banner màu vàng đúng không?" Bạn đứng hình mất mấy giây.',
      U.cap(idolName(l)) + ' đọc to lá thư bạn viết trên sân khấu, cảm ơn bạn đã ủng hộ từ những ngày đầu, rồi ký tên lên áo bạn.'
    ]);
    log(fs, 'big'); fx(l, { hap: 14, soc: 2 }); l.flags.fanService = (l.flags.fanService || 0) + 1;
    H.mem(l, 'Ngày được ' + idolName(l) + ' gọi tên ở fanmeeting — tấm ảnh ấy giữ mãi trong ví.', 8);
  }
  T('fanmeeting', function (l, a) { return !!l.idol && a >= 13 && a <= 45 && !(l.abroad && !l.abroad.perm); }, 0.03, 4, 1);
  A('fanmeeting', 'Giải trí', 'Đi fanmeeting thần tượng', { min: 12, max: 45, sc: 'fanmeeting', avail: function (l) { return l.idol ? true : 'Chưa có thần tượng — thử đi xem concert trước'; } });

  var FAN = [
    ['fan_sinh_nhat', 'Sinh nhật thần tượng', function (l) { return 'Sắp đến sinh nhật ' + idolName(l) + '. Fandom góp tiền thuê màn hình LED ở trung tâm thành phố, làm từ thiện dưới tên thần tượng.'; }, [
      ['gop', 'Góp tiền vào fan project', { w: 1.1 }, function (l, r, log) { pay(l, 0.3, 'Góp fan project'); log('Màn hình LED chạy dòng chữ chúc mừng sinh nhật ' + idolName(l) + ', fandom còn quyên góp xây cầu cho trẻ em vùng cao. ' + U.cap(idolName(l)) + ' đăng ảnh cảm ơn fan.', 'good'); fx(l, { hap: 4, karma: 2 }); }],
      ['tim', 'Chỉ đăng bài chúc mừng, thả tim', { w: 0.8 }, function (l, r, log) { log('Đăng bài chúc mừng sinh nhật ' + idolName(l) + ' kèm loạt ảnh tự chỉnh.', 'neutral'); fx(l, { hap: 1 }); }]]],
    ['fan_vote', 'Cày vote đêm chung kết', function (l) { return 'Bảng bình chọn đang sát nút. Fandom kêu gọi cày vote cho ' + idolName(l) + ' đến 2 giờ sáng.'; }, [
      ['cay', 'Thức cày vote cùng fandom', { w: 1 }, function (l, r, log) { fx(l, { hea: -1 }); if (ch(r, 0.5)) { log('Thức trắng cày vote — ' + idolName(l) + ' giành giải! Cả nhóm chat hét lên lúc 3 giờ sáng.', 'good'); fx(l, { hap: 6 }); } else log('Cày vote cả đêm nhưng ' + idolName(l) + ' về nhì. Sáng ra đi học / đi làm mắt thâm quầng.', 'neutral'); }],
      ['ngu', 'Vote vài lượt rồi đi ngủ', { w: 0.8 }, function (l, r, log) { log('Vote vài lượt rồi đi ngủ — sức khỏe quan trọng hơn.', 'neutral'); }]]],
    ['fan_photocard', 'Photocard bias', function (l) { return 'Album mới của ' + idolName(l) + ' có photocard ngẫu nhiên. Bạn muốn có tấm của ' + (l.bias && !l.bias.all ? l.bias.n : 'bias') + '.'; }, [
      ['mua_nhieu', 'Mua cả chục album cho trúng', { risk: 0.8, w: 0.6 }, function (l, r, log) { pay(l, 3, 'Mua album'); log(ch(r, 0.4) ? 'Bóc đến album thứ 9 thì trúng tấm photocard bias — giữ như báu vật.' : 'Mua 10 album mà toàn trúng thành viên khác. Đành đem đi trao đổi trên hội nhóm.', 'neutral'); fx(l, { hap: 2 }); }],
      ['doi', 'Mua 1 album, lên hội nhóm trao đổi', { w: 1.2 }, function (l, r, log) { pay(l, 0.35, 'Mua album'); log('Mua một album rồi lên hội nhóm đổi photocard — quen thêm mấy bạn cùng fandom.', 'good'); fx(l, { soc: 2 }); }]]],
    ['fan_san_bay', 'Đón thần tượng ở sân bay', function (l) { return U.cap(idolName(l)) + ' sắp về đến sân bay. Fandom rủ nhau ra đón, cầm hoa, cầm banner.'; }, [
      ['van_minh', 'Ra đón, đứng đúng khu vực, không chen lấn', { w: 1.2 }, function (l, r, log) { log('Đứng sau hàng rào, vẫy tay. ' + U.cap(idolName(l)) + ' cúi chào fan rồi lên xe. Văn minh mà vẫn vui.', 'good'); fx(l, { hap: 4 }); }],
      ['chen', 'Chen lên phía trước cho bằng được', { risk: 0.8, w: 0.4 }, function (l, r, log) { log('Chen lấn xô đẩy, bị bảo vệ sân bay nhắc nhở, ảnh chen lấn còn lên báo. Fandom đăng đàn xin lỗi.', 'bad'); fx(l, { hap: -3, karma: -2 }); }]]],
    ['fan_war', 'Cãi nhau trên mạng', function (l) { return 'Trên mạng có người chê bai ' + idolName(l) + ' rất khó nghe, fandom kêu gọi "đi cãi".'; }, [
      ['ke', 'Kệ, report rồi lướt qua', { w: 1.2 }, function (l, r, log) { log('Report bình luận ác ý rồi lướt qua. Tâm trạng vẫn tốt.', 'neutral'); }],
      ['cai', 'Lao vào cãi tay đôi', { risk: 0.6, w: 0.6 }, function (l, r, log) { log('Cãi nhau đến nửa đêm, bị chụp màn hình bêu riếu. Mệt cả người.', 'bad'); fx(l, { hap: -3 }); if (l.mind) l.mind.stress += 5; }]]]
  ];
  FAN.forEach(function (f) {
    SC(f[0], { title: f[1], valid: function (l) { return !!l.idol; }, text: f[2], opts: f[3].map(function (o) { return { k: o[0], l: o[1], ai: o[2], run: o[3] }; }) });
    T(f[0], function (l, a) { return !!l.idol && a >= 13 && a <= 30; }, 0.02, 4, 1);
  });

  // ===================================================================
  // 3. KỸ NĂNG ĐÃ HỌC → CÓ LÚC DÙNG ĐẾN · NĂNG KHIẾU → CÓ DỊP THỂ HIỆN
  // ===================================================================
  function setSkill(l, k) { (l.skills = l.skills || {})[k] = l.age; }
  function has(l, k) { return !!(l.skills && l.skills[k] != null); }
  E.hasSkill = has;
  function wrapOpt(id, key, k) { var D = E.DEC[id]; if (!D) return; D.def.opts.forEach(function (o) { if (o.k === key) { var r0 = o.run; o.run = function (l) { setSkill(l, k); return r0.apply(this, arguments); }; } }); }
  wrapOpt('k_hoc_boi', 'hoc', 'boi'); wrapOpt('k_ngoai_khoa', 'vo', 'vo');
  // nghề y, cứu hộ, công an, quân đội thì biết sơ cứu; vận động viên thì biết bơi; năng khiếu thể thao thì phần lớn biết bơi
  E.HOOKS.year.push(function (l, r, log, a) {
    if (!l.job) return; var j = E.resolveJob(l.job.id);
    if (/^(bac_si|dieu_duong|nha_si|cong_an|quan_doi|pt_gym|hlv_tt)$/.test(j) && !has(l, 'so_cuu')) setSkill(l, 'so_cuu');
    if (/^(cong_an|quan_doi)$/.test(j) && !has(l, 'vo')) setSkill(l, 'vo');
    if (/^(ngu_dan|thuyen_vien)$/.test(j) && !has(l, 'boi')) setSkill(l, 'boi');
  });
  SC('hoc_ky_nang', {
    title: 'Học một kỹ năng', text: function (l) { return 'Bạn muốn học thêm một kỹ năng có ích cho bản thân — biết đâu có ngày dùng đến.'; },
    opts: [
      { k: 'boi', l: 'Học bơi', h: function (l) { return '~' + mo(l, V(l, 1.5)) + ' · biết bơi là biết giữ mạng'; }, req: function (l) { return !has(l, 'boi'); }, ai: { w: 1 }, run: function (l, r, log) { pay(l, 1.5, 'Học bơi'); setSkill(l, 'boi'); fx(l, { hea: 2 }); log('Học bơi một khóa: từ chỗ sợ nước đến bơi được 50 mét.', 'good'); } },
      { k: 'vo', l: 'Học võ (Vovinam, karate, taekwondo…)', h: function (l) { return '~' + mo(l, V(l, 3)) + ' / năm'; }, req: function (l) { return !has(l, 'vo'); }, ai: { w: 1 }, run: function (l, r, log) { pay(l, 3, 'Học võ'); setSkill(l, 'vo'); fx(l, { hea: 3, hap: 2 }); log('Theo lớp võ cả năm, lên đai, người rắn chắc hẳn ra.', 'good'); } },
      { k: 'so_cuu', l: 'Học sơ cứu, hồi sức tim phổi (CPR)', h: function (l) { return '~' + mo(l, V(l, 0.8)); }, req: function (l) { return !has(l, 'so_cuu'); }, ai: { w: 0.8, smart: 0.6 }, run: function (l, r, log) { pay(l, 0.8, 'Học sơ cứu'); setSkill(l, 'so_cuu'); fx(l, { kno: 1 }); log('Học sơ cứu: ép tim, hà hơi thổi ngạt, xử lý hóc dị vật.', 'good'); } },
      { k: 'no', l: 'Thôi, để khi khác', ai: { w: 0.5 }, run: function () { } }
    ]
  });
  A('hoc_ky_nang', 'Sức khỏe & tâm hồn', 'Học bơi / học võ / học sơ cứu', { min: 8, max: 60, sc: 'hoc_ky_nang', avail: function (l) { return has(l, 'boi') && has(l, 'vo') && has(l, 'so_cuu') ? 'Đã biết cả ba' : true; } });

  SC('kn_bat_nat', {
    title: 'Chuyện bất bình', text: function (l) { return 'Trên đường về, bạn thấy một nhóm thanh niên đang vây đánh, giật đồ của một ' + (l.age < 20 ? 'bạn học sinh nhỏ con' : 'cậu sinh viên') + '. Người qua đường đứng nhìn, không ai dám can.' + (has(l, 'vo') ? ' Những năm học võ chợt hiện về trong đầu.' : ''); },
    opts: [
      { k: 'vo', l: function (l) { return has(l, 'vo') ? 'Dùng võ đã học, xông vào can' : 'Xông vào can'; }, ai: { w: 1, risk: 0.5 }, run: function (l, r, log) {
        if (ch(r, has(l, 'vo') ? 0.85 : 0.35)) { log((has(l, 'vo') ? 'Vài đường khóa tay gọn gàng, đám kia bỏ chạy.' : 'Liều mạng lao vào, may mà đám kia hoảng bỏ chạy.') + ' Cậu bé rối rít cảm ơn; công an phường đến ghi nhận, sau đó còn gửi giấy khen "hành động dũng cảm".', 'big'); fx(l, { karma: 6, hap: 6 }); H.mem(l, 'Ngày đứng ra bảo vệ người bị bắt nạt giữa phố.', 6); }
        else { log('Lao vào can nhưng bị đánh trả, rách môi, bầm tím. Người bị hại thì thoát được. Đau mà không hối hận.', 'bad'); fx(l, { hea: -6, karma: 4 }); } } },
      { k: 'goi', l: 'Gọi 113, quay video làm bằng chứng', ai: { w: 1.1, smart: 1 }, run: function (l, r, log) { log('Gọi 113 và quay lại toàn bộ. Công an đến nhanh, nhờ đoạn video mà bắt được cả nhóm.', 'good'); fx(l, { karma: 4 }); } },
      { k: 'di', l: 'Lặng lẽ đi qua', ai: { w: 0.4 }, run: function (l, r, log) { log('Lặng lẽ đi qua. Tối về cứ nghĩ mãi về đôi mắt hoảng sợ ấy.', 'neutral'); fx(l, { hap: -3 }); } }
    ]
  });
  T('kn_bat_nat', function (l, a) { return a >= 14 && a <= 55; }, function (l) { return has(l, 'vo') ? 0.025 : 0.004; }, 8, 1);

  SC('kn_duoi_nuoc', {
    title: 'Có người đuối nước', text: function (l) { return 'Đi biển cùng ' + (l.partner ? l.partner.name : 'bạn bè') + ', bạn nghe tiếng kêu cứu: một đứa trẻ bị sóng cuốn ra xa, chới với.' + (has(l, 'boi') ? '' : ' Bạn không biết bơi.'); },
    opts: [
      { k: 'cuu', l: function (l) { return has(l, 'boi') ? 'Lao xuống bơi ra cứu' : 'Liều lao xuống cứu dù không biết bơi'; }, ai: { w: 1, risk: 0.5 }, run: function (l, r, log) {
        if (has(l, 'boi')) { if (ch(r, 0.88)) { log('Bơi ra kéo được đứa bé vào bờ, sơ cứu cho bé tỉnh lại. Bố mẹ bé ôm chầm lấy bạn mà khóc.', 'big'); fx(l, { karma: 8, hap: 8 }); H.mem(l, 'Ngày kéo đứa bé từ dưới sóng lên — may mà hồi nhỏ được học bơi.', 8); } else { log('Bơi ra kéo được đứa bé nhưng bị sóng đánh uống nhiều nước, kiệt sức. Đội cứu hộ kịp lao ra đưa cả hai vào.', 'neutral'); fx(l, { hea: -4, karma: 6 }); } }
        else if (ch(r, 0.4)) { log('Không biết bơi mà vẫn lao xuống, may đội cứu hộ đến kịp kéo cả hai vào. Ai cũng mắng mà cũng phục.', 'neutral'); fx(l, { hea: -5, karma: 4 }); }
        else { log('Lao xuống rồi chính mình bị đuối, phải nhờ cứu hộ cứu lên, nằm viện mấy ngày. Đứa bé được người khác cứu.', 'bad'); fx(l, { hea: -12 }); } } },
      { k: 'phao', l: 'Ném phao, hô hoán gọi cứu hộ', ai: { w: 1.1, smart: 1 }, run: function (l, r, log) { log('Vớ lấy phao ném ra, hô hoán gọi cứu hộ. Đứa bé bám được phao, được đưa vào an toàn.', 'good'); fx(l, { karma: 4 }); } }
    ]
  });
  T('kn_duoi_nuoc', function (l, a) { return a >= 14 && a <= 65; }, function (l) { return has(l, 'boi') ? 0.025 : 0.003; }, 8, 1);

  SC('kn_so_cuu', {
    title: 'Ngưng tim giữa đường', text: function (l) { return 'Một người đàn ông trung niên đột ngột ngã gục ở quán cà phê, ngừng thở. Mọi người cuống cuồng, chưa ai biết làm gì.' + (has(l, 'so_cuu') ? ' Bạn từng học sơ cứu.' : ''); },
    opts: [
      { k: 'cpr', l: function (l) { return has(l, 'so_cuu') ? 'Ép tim, hô hấp nhân tạo như đã học' : 'Thử ép tim theo video từng xem'; }, ai: { w: 1 }, run: function (l, r, log) { if (ch(r, has(l, 'so_cuu') ? 0.6 : 0.2)) { log('Ép tim liên tục đến khi xe cấp cứu tới. Bác sĩ bảo: "Nhờ mấy phút đầu mà ông ấy sống." Gia đình ông tìm đến cảm ơn.', 'big'); fx(l, { karma: 8, hap: 6 }); H.mem(l, 'Những phút ép tim cứu sống một người xa lạ.', 7); } else { log('Cố hết sức ép tim nhưng ông ấy không qua khỏi. Bạn ngồi thẫn thờ rất lâu.', 'bad'); fx(l, { hap: -6, karma: 3 }); } } },
      { k: 'goi', l: 'Gọi 115, giữ mọi người tránh ra', ai: { w: 1 }, run: function (l, r, log) { log('Gọi 115 và giữ đám đông giãn ra. Xe cấp cứu đến sau mười phút.', 'neutral'); fx(l, { karma: 2 }); } }
    ]
  });
  T('kn_so_cuu', function (l, a) { return a >= 18 && a <= 70; }, function (l) { return has(l, 'so_cuu') ? 0.025 : 0.003; }, 8, 1);

  // năng khiếu → có dịp thể hiện
  var TAL = {
    'âm nhạc': ['Hát mừng đám cưới', 'Đứa bạn thân cưới, cả họ nhà gái biết bạn hát hay nên mời lên hát mừng.', 'Lên hát một bài, cả rạp cưới im phăng phắc rồi vỗ tay rầm rầm. Cô dâu khóc, có người còn xin số để mời hát đám cưới nhà mình.'],
    'hội họa': ['Bức tranh tặng bà', 'Bà sắp mừng thọ, cả nhà muốn có một món quà ý nghĩa.', 'Bạn vẽ chân dung bà bằng sơn dầu. Bà ngắm mãi, treo ngay giữa nhà, ai đến chơi cũng khoe.'],
    'diễn xuất': ['Tiết mục cuối năm', 'Trường / công ty tổ chức tiệc cuối năm, cần một vai chính cho tiểu phẩm hài.', 'Bạn đóng vai chính, diễn tròn vai đến mức khán giả cười chảy nước mắt — clip được chia sẻ khắp nơi.'],
    'thể thao': ['Giải bóng đá phong trào', 'Giải bóng đá phong trào của khu phố / công ty đang thiếu người.', 'Bạn ghi bàn quyết định trận chung kết, được cả đội công kênh.'],
    'ngoại ngữ': ['Du khách lạc đường', 'Một cặp du khách nước ngoài đứng giữa phố, loay hoay vì lạc đường, không ai hiểu họ nói gì.', 'Bạn bắt chuyện, chỉ đường, giới thiệu luôn quán phở ngon gần đó. Họ cảm ơn rối rít, còn kết bạn mạng xã hội.'],
    'toán học': ['Kèm bài cho em', 'Đứa em họ sắp thi vào lớp 10 mà toán yếu, cả nhà nhờ bạn kèm.', 'Kèm em mấy tháng, em đỗ trường điểm cao. Cô chú biếu quà cảm ơn.'],
    'ăn nói': ['MC bất đắc dĩ', 'MC đám cưới đứa bạn thân đến muộn, bạn được đẩy lên cầm micro.', 'Dẫn duyên đến mức ai cũng tưởng MC chuyên nghiệp, mấy người xin số để thuê dẫn đám cưới.'],
    'khéo tay': ['Đồ hỏng của hàng xóm', 'Quạt, nồi cơm, xe đạp của hàng xóm hỏng, ai cũng bảo "nhờ đứa khéo tay xem giúp".', 'Bạn sửa ngon lành cả ba món. Hàng xóm mang biếu đĩa xôi, từ đó gặp gì cũng gọi bạn.'],
    'kinh doanh': ['Gian hàng hội chợ', 'Hội chợ cuối tuần, nhà có một gian hàng nhỏ bán đồ ăn vặt.', 'Bạn bày lại hàng, làm biển giá bắt mắt, livestream rao bán — bán hết sạch trước giờ đóng cửa.'],
    'làm đẹp': ['Trang điểm cho cô dâu', 'Cô bạn thân cưới, thợ trang điểm báo bận phút chót.', 'Bạn trang điểm cho cô dâu, ảnh cưới lung linh. Mấy người bạn khác đặt luôn lịch nhờ bạn trang điểm.'],
    'game': ['Giải game ở quán net', 'Quán net đầu ngõ tổ chức giải đấu, giải nhất 5 triệu.', 'Bạn gánh team vô địch, chia nhau tiền thưởng, được cả xóm game gọi là "thần đồng".'],
    'cờ': ['Ván cờ ở công viên', 'Mấy ông cụ ở công viên thách thanh niên chơi cờ.', 'Bạn thắng liền ba ván, các cụ tâm phục khẩu phục, ngày nào cũng rủ bạn ra đánh cờ.']
  };
  SC('kn_the_hien', {
    title: function (l) { var t = TAL[l.talent]; return t ? t[0] : 'Dịp thể hiện'; }, valid: function (l) { return !!TAL[l.talent]; },
    text: function (l) { return TAL[l.talent][1] + ' Mọi người đều biết bạn có năng khiếu ' + E.talentText(l) + '.'; },
    opts: [
      { k: 'lam', l: 'Thể hiện hết mình', ai: { w: 1.2 }, run: function (l, r, log) { var ok = ch(r, 0.55 + (l.skill || 30) / 250); if (ok) { log(TAL[l.talent][2], 'good'); fx(l, { hap: 6, soc: 4 }); if (l.talent === 'game') H.cash(l, V(l, 2.5), 'Thưởng giải game'); H.mem(l, TAL[l.talent][0] + ' — lần năng khiếu của mình làm mọi người vui.', 4); } else { log('Hơi run nên chưa được như ý, nhưng ai cũng khen bạn có tâm.', 'neutral'); fx(l, { hap: 1 }); } l.skill = Math.min(100, (l.skill || 30) + 2); } },
      { k: 'thoi', l: 'Khiêm tốn từ chối', ai: { w: 0.5 }, run: function (l, r, log) { log('Từ chối khéo, nhường dịp cho người khác.', 'neutral'); } }
    ]
  });
  T('kn_the_hien', function (l, a) { return !!TAL[l.talent] && a >= 14 && a <= 50; }, 0.02, 8, 1);

  // ===================================================================
  // 4. TRÀ SỮA, ĐỒ UỐNG, RỦ NHAU ĐI ĂN — THEO TREND
  // ===================================================================
  // [tên, giá (nghìn đồng), chuỗi quán hay bán]
  var DRINKS = [['trà sữa trân châu đường đen', 45, 'TocoToco'], ['trà sữa Đài Loan', 40, 'Gong Cha'], ['matcha latte', 55, 'Katinat'], ['trà đào cam sả', 45, 'Highlands'], ['cà phê muối', 35, 'quán cà phê muối'],
    ['bạc xỉu', 30, 'quán cà phê vỉa hè'], ['hồng trà macchiato', 50, 'Phúc Long'], ['sữa tươi trân châu đường đen', 45, 'Tiger Sugar'], ['trà sữa nướng', 40, 'TocoToco'], ['trà vải', 40, 'The Coffee House'],
    ['sinh tố bơ', 40, 'quán sinh tố'], ['trà chanh giã tay', 25, 'quán trà chanh'], ['kem ốc quế', 10, 'Mixue'], ['trà sữa khoai môn', 40, 'Ding Tea'], ['oolong sữa', 50, 'Phê La'],
    ['cacao đá', 30, 'quán quen'], ['yakult đào', 40, 'quán trà trái cây'], ['trà xanh kem phô mai', 55, 'Gong Cha'], ['nước ép dưa hấu', 35, 'quán nước ép'], ['Phindi hạnh nhân', 45, 'Highlands']];
  // v5.9.1: người nhận tự xưng (I) và gọi bạn (U) đúng quan hệ, tuổi, giới tính — không còn câu nào cũng "anh"
  function you(l) { return l.sex === 'F' ? 'chị' : 'anh'; }
  function people(l) {
    var c = [], p = l.partner, f = l.fam || {};
    if (p && p.alive !== false) { var I = p.sex !== l.sex ? (p.sex === 'M' ? 'anh' : 'em') : (p.age > l.age ? (p.sex === 'M' ? 'anh' : 'chị') : 'em'); c.push({ k: 'p', n: p.name, w: E.H.partnerWord ? E.H.partnerWord(l, p) : 'người yêu', I: I, U: I === 'em' ? you(l) : 'em' }); }
    if (!f.noMom && f.mAlive) c.push({ k: 'mom', n: '', w: 'mẹ', I: 'mẹ', U: 'con' });
    if (!f.noDad && f.fAlive) c.push({ k: 'dad', n: '', w: 'bố', I: 'bố', U: 'con' });
    (l.sibList || []).filter(function (x) { return x.alive; }).forEach(function (x) { var old = x.born < 0, I = old ? (x.sex === 'M' ? 'anh' : 'chị') : 'em'; c.push({ k: 's', n: x.n.split(' ').pop(), w: I, I: I, U: old ? 'em' : you(l), s: x }); });
    (l.kids || []).filter(function (k) { return k.alive !== false && l.age - k.born >= 6 && k.custody !== 'other'; }).forEach(function (k) { c.push({ k: 'kid', n: k.name.split(' ').pop(), w: 'con', I: 'con', U: l.sex === 'F' ? 'mẹ' : 'bố', kid: k }); });
    if (l.bff && l.bff.alive) c.push({ k: 'b', n: l.bff.name, w: 'bạn thân', I: 'tớ', U: 'cậu' });
    (l.friends || []).filter(function (x) { return x.alive !== false && !x.lover; }).forEach(function (x) { c.push({ k: 'f', n: x.name, w: 'bạn thân', I: 'tớ', U: 'cậu', fr: x }); });
    return c;
  }
  function target(l, r) { var c = people(l); if (!c.length) return null; return c[0].k === 'p' && ch(r, 0.5) ? c[0] : pick(r, c); }
  function whoOf(t) { return (t.w + (t.n ? ' ' + t.n : '')).trim(); }
  function fill(t, x) { return x.replace(/\{I\}/g, t.I).replace(/\{U\}/g, t.U).replace(/\{Ic\}/g, U.cap(t.I)).replace(/\{Uc\}/g, U.cap(t.U)); }
  SC('mua_nuoc_ai', {
    title: 'Mua nước cho ai?', valid: function (l) { return people(l).length > 0; },
    text: 'Bạn muốn mua đồ uống "lấy lòng" ai?',
    opts: [0, 1, 2, 3, 4, 5, 6, 7].map(function (i) { return { k: 'p' + i, l: function (l) { var t = people(l)[i]; return t ? U.cap(whoOf(t)) : ''; }, req: function (l) { return !!people(l)[i]; }, ai: { w: 1 }, run: function (l, r) { var t = people(l)[i]; if (t) l.pending.unshift(E.DEC.mua_nuoc.make(l, r, { t: t })); } }; })
  });
  SC('mua_nuoc', {
    title: 'Mua nước "lấy lòng"',
    valid: function (l) { return people(l).length > 0; },
    prep: function (l, r, a) { return { t: (a && a.t) || target(l, r) || { k: 'b', n: 'đứa bạn', w: 'bạn', I: 'tớ', U: 'cậu' }, d: shuffle(r, DRINKS).slice(0, 5), like: Math.floor(r() * 5), mood: pick(r, ['đang dỗi vì bạn quên trả lời tin nhắn', 'vừa thi xong / chạy deadline mệt rã rời', 'nhắn "nóng quá đi"', 'đang buồn chuyện gì đó', 'vừa giúp bạn một việc lớn']) }; },
    text: function (l, d) { return U.cap(whoOf(d.t)) + ' ' + d.mood + '. Một ly nước mát lúc này là "lấy lòng" chuẩn bài. Mua gì đây?'; },
    opts: [0, 1, 2, 3, 4].map(function (i) {
      return { k: 'd' + i, l: function (l, d) { var x = d.d[i]; return U.cap(x[0]) + (vnd(l) ? ' (' + x[2] + ')' : ''); }, h: function (l, d) { return '~' + mo(l, V(l, d.d[i][1] * 2 / 1000)) + ' cho 2 ly'; }, ai: { w: 1 },
        run: function (l, r, log, d) { buy(l, r, log, d, d.d[i], i === d.like); } };
    }).concat([
      { k: 'hoi', l: 'Hỏi "uống gì?" trước cho chắc', ai: { w: 0.8 }, run: function (l, r, log, d) { if (ch(r, 0.5)) { log('Hỏi "uống gì?", nhận về câu trả lời kinh điển: "Gì cũng được." Mua đại ' + d.d[0][0] + ' thì bị chê "' + fill(d.t, '{Uc} biết {I} không thích món này mà') + '".', 'neutral'); H.cash(l, -V(l, d.d[0][1] * 2 / 1000), 'Mua nước'); } else buy(l, r, log, d, d.d[d.like], true); } },
      { k: 'khong', l: 'Thôi, nhắn tin hỏi han là được', ai: { w: 0.4 }, run: function (l, r, log, d) { log(d.t && d.t.n ? 'Chỉ nhắn tin hỏi han ' + d.t.n + '.' : 'Chỉ nhắn tin hỏi han.', 'neutral'); } }
    ])
  });
  var GOOD = ['{Uc} biết đúng món tủ của {I} luôn!', 'Thương {U} ghê, uống một ngụm là hết mệt.', 'Đúng ly {I} đang thèm, {U} giỏi thật!', 'Cảm ơn {U} nha, để {I} chụp ảnh đăng story.'];
  var MEH = ['{Ic} dặn ít đường rồi mà!', '{Ic} không uống được trân châu đâu…', 'Lần sau nhớ size L nhé.', 'Ủa sao không mua cho cả nhà luôn?', '{Ic} đang giảm cân mà {U} lại mua trà sữa…', 'Đá nhiều quá, uống buốt cả răng.', 'Lần sau mua ít ngọt thôi {U} ơi.'];
  function buy(l, r, log, d, x, liked) {
    H.cash(l, -V(l, x[1] * 2 / 1000), 'Mua ' + x[0]);
    var t = d.t, who = whoOf(t); if (!t.I) { t.I = 'tớ'; t.U = 'cậu'; }
    if (liked || ch(r, 0.6)) { log('Mua ly ' + x[0] + ' cho ' + who + '. ' + U.cap(who) + ' cười tít mắt: "' + fill(t, pick(r, GOOD)) + '"', 'good'); fx(l, { hap: 3, soc: 1 }); if (t.s) t.s.close = Math.min(100, (t.s.close || 50) + 4); if (t.kid) t.kid.close = Math.min(100, (t.kid.close || 50) + 3); if (t.fr) t.fr.close = Math.min(100, (t.fr.close || 50) + 3); if (t.k === 'b' && l.bff) l.bff.close = Math.min(100, (l.bff.close || 60) + 3); }
    else log('Mua ' + x[0] + ' cho ' + who + ', nhận lại câu: "' + fill(t, pick(r, MEH.filter(function (m) { return !(t.k === 'mom' || t.k === 'dad') || !/cả nhà/.test(m); }))) + '" Cười trừ, rút kinh nghiệm.', 'neutral');
  }
  T('mua_nuoc', function (l, a) { return a >= 14 && a <= 55 && !!(l.partner || (l.bff && l.bff.alive)); }, 0.015, 5, 1);
  A('mua_nuoc', 'Tình cảm', 'Mua trà sữa / đồ uống cho người thân', { min: 12, max: 70, sc: 'mua_nuoc_ai', avail: function (l) { return people(l).length ? true : 'Chưa có ai để mua cho'; } });

  // [mã, tên (VN), tên chung (nước ngoài), giá mỗi người (triệu đồng), lời kể]
  var EATS = [['dookki', 'buffet tokbokki Dookki', 'buffet tokbokki Hàn Quốc', 0.15, 'Cả hội tự nấu tokbokki, cãi nhau chuyện cho bao nhiêu phô mai.'],
    ['ga_ran', 'gà rán KFC / Jollibee', 'quán gà rán', 0.1, 'Gọi combo gà rán, mì Ý Jollibee, ăn đến dính hết tay.'],
    ['mi_cay', 'mì cay 7 cấp độ', 'quán mì cay', 0.08, 'Thách nhau ăn mì cấp 7 — đứa nào bỏ cuộc phải trả tiền.'],
    ['lau', 'lẩu Haidilao', 'lẩu Haidilao', 0.45, 'Ngồi lẩu Haidilao cả tối, nhân viên còn hát mừng sinh nhật hộ.'],
    ['buffet', 'buffet hải sản Cửu Vân Long', 'buffet hải sản', 0.4, 'Ăn buffet hải sản no căng, chụp ảnh từng đĩa cua ghẹ.'],
    ['nuong', 'buffet nướng Gogi / King BBQ', 'quán thịt nướng Hàn Quốc', 0.3, 'Nướng thịt xèo xèo, nói chuyện trên trời dưới biển.'],
    ['tra_sua', 'trà sữa rồi về xem Netflix', 'trà sữa rồi về xem Netflix', 0.08, 'Mua trà sữa về nhà, cả hội chen nhau xem Netflix đến khuya.'],
    ['oc', 'quán ốc vỉa hè', 'quán ăn vặt đường phố', 0.12, 'Ngồi quán ốc vỉa hè, gọi đủ món ốc hương, sò điệp nướng mỡ hành.']];
  SC('ru_ban_an', {
    title: 'Rủ hội bạn đi ăn', prep: function (l, r) { return { e: shuffle(r, EATS).slice(0, 5), n: 3 + Math.floor(r() * 3) }; },
    text: function (l, d) { return 'Nhóm chat sôi lên: "Cuối tuần đi đâu ăn đi!" Có ' + d.n + ' đứa hưởng ứng. Bạn chốt đi đâu?'; },
    opts: [0, 1, 2, 3, 4].map(function (i) {
      return { k: 'e' + i, l: function (l, d) { var x = d.e[i]; return 'Đi ' + (vnd(l) ? x[1] : x[2]); }, h: function (l, d) { return '~' + mo(l, V(l, d.e[i][3])) + ' / người · chia đều'; }, ai: { w: 1 },
        run: function (l, r, log, d) { var x = d.e[i]; pay(l, x[3], 'Đi ăn cùng bạn bè'); var bao = ch(r, 0.15); log(x[4] + (bao ? ' Cuối bữa bạn giành trả tiền cả bàn — "lần sau tụi mày bao lại".' : ''), 'good'); if (bao) pay(l, x[3] * d.n, 'Bao cả hội'); fx(l, { hap: 4, soc: 4 }); if (l.bff && l.bff.alive) l.bff.close = Math.min(100, (l.bff.close || 60) + 2); } };
    }).concat([{ k: 'khong', l: 'Thôi, cuối tháng rồi, cháy túi', ai: { w: 0.5 }, run: function (l, r, log) { log('Từ chối vì cuối tháng cháy túi, ngồi nhà xem cả hội đăng ảnh.', 'neutral'); fx(l, { hap: -1 }); } }])
  });
  // chống quá tải lựa chọn: vài chuyện đời thường cũ hay lặp — tối đa 2 lần một đời
  E.TRIG.forEach(function (t) { if (/^(mua_sam|sib_vay|nhat_vi|ban_muon_tien|viec_online|csgt|den_vang)$/.test(t.id) && !t.rep) t.max = Math.min(t.max || 3, 2); });
  E.TRIG.forEach(function (t) { if (/^(mua_sam|nhat_vi)$/.test(t.id) && !t.rep) t.max = 1; });
  T('ru_ban_an', function (l, a) { return a >= 15 && a <= 45 && l.urban; }, 0.02, 5, 1);
  A('ru_ban_an', 'Gia đình & bạn bè', 'Rủ bạn bè đi ăn uống', { min: 14, max: 70, sc: 'ru_ban_an' });

  // ===================================================================
  // 5. v3.8.1: TÊN CON ĐỒNG NHẤT — con mang họ cha (đúng kiểu đặt tên từng nước), anh chị em không trùng tên
  // ===================================================================
  function kidSur(l) {
    var P = G.NAMES && G.NAMES.P && G.NAMES.P[l.pool], p = l.partner;
    var dad = l.sex === 'M' ? String(l.name || '') : p && p.sex === 'M' ? String(p.name || '') : null;
    if (!dad) return l.sur;
    var w = dad.split(' ');
    if (l.pool === 'vn') return l.sex === 'M' ? l.sur : w[0];
    if (!P) return l.sex === 'M' ? l.sur : w[w.length - 1];
    if (P.style === 'patronym' || P.style === 'bin') return w[0];   // họ của con là tên của cha
    if (l.sex === 'M') return l.sur;
    if (P.style === 'double') return w[1] || w[w.length - 1];       // con lấy họ thứ nhất của cha
    if (P.native) return w[0];                                      // họ đứng trước tên
    return w[w.length - 1];
  }
  function givenOf(l, n) { var w = String(n).split(' '); var P = G.NAMES && G.NAMES.P && G.NAMES.P[l.pool]; return l.pool === 'vn' || (P && P.native) ? w[w.length - 1] : w[0]; }
  var ka0 = E.DEC.kid.apply;
  E.DEC.kid.apply = function (l, d, k, r, log) {
    var n0 = l.kids.length;
    var lg = [], x = ka0.call(this, l, d, k, r, function (t, kk) { lg.push([t, kk]); });
    var kid = l.kids.length > n0 ? l.kids[l.kids.length - 1] : null;
    if (kid && !(l.partner && l.partner.sex === l.sex)) {
      var old = kid.name, sur = kidSur(l), taken = l.kids.slice(0, -1).map(function (c) { return givenOf(l, c.name); }).concat([givenOf(l, l.name)]);
      var nm = old, t = 0;
      if (l.pool !== 'vn' || l.sex === 'F') { nm = H.name(l, r, kid.sex, sur).full; }
      while (taken.indexOf(givenOf(l, nm)) >= 0 && t++ < 8) nm = H.name(l, r, kid.sex, sur).full;
      var P2 = G.NAMES && G.NAMES.P && G.NAMES.P[l.pool];
      if (P2 && P2.style === 'double') { var mom = l.sex === 'F' ? String(l.name).split(' ') : l.partner ? String(l.partner.name).split(' ') : null; if (mom && mom.length >= 3) { var ww = nm.split(' '); ww[ww.length - 1] = mom[mom.length - 2]; nm = ww.join(' '); } } // họ thứ hai của con là họ thứ nhất của mẹ
      if (nm !== old) { kid.name = nm; lg.forEach(function (e) { e[0] = e[0].split(old).join(nm); }); (l.mem || []).forEach(function (m) { if (m && m.t) m.t = m.t.split(old).join(nm); }); }
    }
    lg.forEach(function (e) { log(e[0], e[1]); });
    return x;
  };
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
/* ===== js/life39.js ===== */
/* Một Đời — v3.8 (tiếp): ca sĩ được mời tham gia show thực tế âm nhạc
   · Anh trai "Say Hi" (ca sĩ nam trẻ, tân binh tiềm năng hoặc đã nổi): Bài nhóm liên quân → Livestage 1 → 2 → 3 → 4 (Dance battle) → Chung kết (Best 5, quán quân)
   · Em xinh "Say Hi" (ca sĩ nữ trẻ): cùng thể thức
   · Anh trai vượt ngàn chông gai (nghệ sĩ nam có tên tuổi, từ 30 tuổi): Đêm Hội ngộ → Công diễn 1 → 5 → Đêm chung kết (Gia tộc Anh tài Toàn năng)
   Mỗi vòng ghép đội ngẫu nhiên với các anh trai / em xinh / anh tài thật của chương trình; có thể bị loại rồi được bình chọn cứu / hồi sinh, hoặc vô địch nếu đủ mạnh.
   Diễn biến hư cấu, chỉ mô phỏng thể thức chương trình. */
(function (G) {
  'use strict';
  var U = G.U, E = G.E, H = E.H, SC = E.SC, isVN = H.isVN;
  function fx(l, o) { H.fx(l, o); }
  function pick(r, a) { return U.pick(r, a); }
  function ch(r, p) { return r() < p; }
  function mo(l, v) { return H.money(l, v); }
  function vnd(l) { return isVN(l) && l.cur === 'vnd' && !(l.abroad && l.abroad.perm); }
  function V(l, tr) { return vnd(l) ? tr : tr / 90 * l.base; }
  function free(l) { return !(l.jailUntil != null && l.age < l.jailUntil) && !(l.abroad && l.abroad.trapped) && !(l.flags.military && l.age < l.flags.military); }
  function yr(l) { return l.birthYear + l.age; }
  function jid(l) { return l.job ? E.resolveJob(l.job.id) : ''; }
  function promote(l) { var c = l.job ? E.jobDef(l) : null; if (c && l.job.rank < c.t.length - 1) { l.job.rank++; l.job.yrs = 0; return true; } return false; }
  function shuffle(r, a) { a = a.slice(); for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(r() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function given(l) { var w = String(l.name || '').split(' '); return w[w.length - 1] || 'bạn'; }

  // ---------- thể thức ----------
  var FMT = {
    atsh: { pre: 'anh trai', rounds: [
      { n: 'Bài nhóm liên quân', d: '30 anh trai chia thành hai liên quân, cùng dàn dựng một bài hát mở màn để khán giả làm quen.', cut: 0 },
      { n: 'Livestage 1', d: 'Chia đội 5 người, mỗi đội dàn dựng một tiết mục. Khán giả trường quay bình chọn, nhóm cuối bảng có nguy cơ dừng chân.', cut: 0.5 },
      { n: 'Livestage 2', d: 'Tích điểm cá nhân để giành quyền chọn đồng đội, rồi thi đấu theo đề bài mới.', cut: 0.58 },
      { n: 'Livestage 3', d: 'Hai liên quân, mỗi bên 3 ca khúc mới phải kết nối thành một EP. Đề bài khó hơn hẳn.', cut: 0.63 },
      { n: 'Livestage 4 — Dance battle', d: 'Vòng đối đầu vũ đạo: mỗi đội làm việc với một biên đạo, ai nhảy yếu sẽ lộ ngay trên sân khấu.', cut: 0.68, dance: true },
      { n: 'Chung kết', d: 'Đêm chung kết trực tiếp: chọn ra nhóm "Best 5" và quán quân bằng bình chọn của khán giả.', final: true }] },
    atvncg: { pre: 'anh tài', rounds: [
      { n: 'Đêm Hội ngộ', d: 'Các anh tài lần lượt trình diễn sở trường, được chia vào các "nhà" — những người anh em sẽ cùng nhau vượt chông gai.', cut: 0 },
      { n: 'Công diễn 1', d: 'Mỗi nhà dàn dựng một tiết mục: hát, nhảy, chơi nhạc cụ, võ thuật… khán giả trường quay chấm điểm.', cut: 0.48 },
      { n: 'Công diễn 2', d: 'Các nhà được xáo lại, thi đấu đối đầu theo cặp. Nhà thua có nguy cơ mất người.', cut: 0.55 },
      { n: 'Công diễn 3', d: 'Mỗi nhà sản xuất một ca khúc mới, thi đấu truy kích vòng tròn rồi kết hợp thành liên minh.', cut: 0.6 },
      { n: 'Công diễn 4', d: 'Tiết mục kết hợp cùng khách mời đặc biệt, đòi hỏi cả thể lực lẫn tinh thần đồng đội.', cut: 0.64 },
      { n: 'Công diễn 5', d: 'Vòng cuối trước chung kết — chỉ những anh tài bền bỉ nhất được ở lại.', cut: 0.68 },
      { n: 'Đêm chung kết', d: 'Đêm chung kết chọn ra các thành viên "Gia tộc Anh tài Toàn năng".', final: true }] }
  };
  // Tân binh toàn năng (YeaH1, VTV3): 30 tân binh, 100 ngày huấn luyện cùng chuyên gia Hàn Quốc, các kỳ sát hạch sàng lọc → Survival showcase chọn đội hình thăng cấp → đối đầu nhóm nhạc quốc tế → chung kết chọn đội hình debut 7 thành viên
  FMT.tbtn = { pre: 'tân binh', rounds: [
    { n: 'Kỳ sát hạch 1 — đánh giá đầu vào', d: '30 tân binh bước vào 100 ngày huấn luyện cùng các chuyên gia Hàn Quốc. Kỳ sát hạch đầu tiên chấm hát, nhảy, rap từng người.', cut: 0.55 },
    { n: 'Kỳ sát hạch 2', d: 'Sát hạch theo nhóm nhỏ, cố vấn người Hàn chấm rất gắt — có kỳ tới 6 người phải ra về.', cut: 0.64 },
    { n: 'Kỳ sát hạch 3 — vũ đạo', d: 'Kỳ sát hạch vũ đạo: học thuộc bài nhảy khó trong vài ngày, đồng đều từng nhịp.', cut: 0.7, dance: true },
    { n: 'Survival showcase', d: 'Đêm diễn ngoài trời kết thúc giai đoạn sống còn: hội đồng chuyên môn và khán giả chọn đội hình thăng cấp.', cut: 0.74 },
    { n: 'Giai đoạn thăng cấp — đối đầu nhóm nhạc quốc tế', d: 'Đội hình thăng cấp lần lượt đối đầu các nhóm nhạc Hàn Quốc, chấm theo tiêu chuẩn quốc tế.', cut: 0.77 },
    { n: 'Chung kết — Sân khấu tinh hoa', d: 'Đêm chung kết: sân khấu solo, duo và nhóm, chọn ra đội hình debut 7 thành viên.', final: true }] };
  FMT.thsh = { pre: 'anh trai', rounds: FMT.atsh.rounds };
  FMT.exsh = { pre: 'em xinh', rounds: FMT.atsh.rounds.map(function (x) { var y = {}; for (var k in x) y[k] = x[k]; y.d = y.d.replace(/anh trai/g, 'em xinh'); return y; }) };
  function season(l, k) {
    var y = yr(l);
    if (k === 'atsh') return 'Anh trai "Say Hi" mùa ' + Math.max(1, y - 2023);
    if (k === 'exsh') return 'Em xinh "Say Hi" mùa ' + Math.max(1, y - 2024);
    if (k === 'thsh') return 'Tinh hà "Say Hi" mùa ' + Math.max(1, y - 2025);
    if (k === 'tbtn') return 'Tân binh toàn năng mùa ' + Math.max(1, y - 2024);
    return 'Anh trai vượt ngàn chông gai ' + y;
  }
  // bạn diễn: nghệ sĩ thật của chương trình cùng vũ trụ
  function pool(k, l) {
    var S = E.SHOWS || [];
    var ids = k === 'thsh' ? ['thsh'] : k === 'atsh' ? ['atsh1', 'atsh2'] : k === 'exsh' ? ['exsh'] : ['atvncg24', 'atvncg26'];
    var all = []; S.forEach(function (s) { if (ids.indexOf(s.k) >= 0 && yr(l) >= s.from && yr(l) - s.b <= 65) s.m.forEach(function (m) { if (m !== l.name && all.indexOf(m) < 0) all.push(m); }); });
    return all;
  }
  function team(l, r, n) { var T = l.flags.tv, a = T.k === 'tbtn' ? [] : pool(T.k, l), tries = 0; while (a.length < n && tries++ < 50) { var m = H.stranger(l, r, T.k === 'exsh' ? 'F' : 'M'); if (m !== l.name && a.indexOf(m) < 0) a.push(m); } return shuffle(r, a).slice(0, n).map(function (m) { return E.memberName ? E.memberName(FMT[T.k].pre, m) : FMT[T.k].pre + ' ' + m; }); }
  function base(l) { return Math.min(1, (l.skill || 40) / 100) * 0.55 + Math.min(0.3, Math.log10((l.fame || 0) + 10) / 22) + (l.st.hea >= 60 ? 0.05 : 0); }

  // ---------- lời mời ----------
  function canATSH(l) { return l.sex === 'M' && l.age >= 18 && l.age <= 35 && /^(ca_si|rapper|nhac_si)$/.test(jid(l)) && ((l.fame || 0) > 2e4 || (l.job && l.job.rank >= 1)); }
  function canEXSH(l) { return l.sex === 'F' && l.age >= 18 && l.age <= 33 && /^(ca_si|rapper|nhac_si)$/.test(jid(l)) && ((l.fame || 0) > 2e4 || (l.job && l.job.rank >= 1)); }
  function canATV(l) { return l.sex === 'M' && l.age >= 30 && l.age <= 55 && /^(ca_si|rapper|nhac_si|dien_vien|mc_tv|dv_hai|dao_dien|vdv|hlv_tt|youtuber|streamer)$/.test(jid(l)) && (l.fame || 0) > 6e4; }
  function canTBTN(l) { return l.sex === 'M' && l.age >= 16 && l.age <= 24 && (l.fame || 0) < 3e5 && (/^(ca_si|rapper|vu_cong)$/.test(jid(l)) || (l.talent === 'âm nhạc' && (l.skill || 0) >= 50)); }
  function shows(l) { var o = []; if (canATSH(l)) { o.push('atsh'); if (yr(l) >= 2026) o.push('thsh'); } if (canEXSH(l)) o.push('exsh'); if (canATV(l)) o.push('atvncg'); if (canTBTN(l) && yr(l) >= 2025) o.push('tbtn'); var H0 = (l.flags.tvHist || []).concat(l.flags.tv ? [l.flags.tv] : []).filter(function (h) { return h.res === 'win' || h.res === 'debut'; }).map(function (h) { return h.k; }); return o.filter(function (k) { return H0.indexOf(k) < 0; }); }
  function canInvite(l) { var T = l.flags.tv; return isVN(l) && shows(l).length > 0 && (!T || ((T.done || T.no) && yr(l) - T.y >= 2 && (l.flags.tvN || 0) < 3)); }
  E.tvShowsFor = shows;
  SC('tv_moi', {
    title: 'Lời mời tham gia chương trình',
    valid: function (l) { return canInvite(l); },
    prep: function (l, r) { var k = pick(r, shows(l)); return { k: k, s: season(l, k), again: !!l.flags.tv }; },
    text: function (l, d) { return (d.again ? 'Sau lần tham gia ' + l.flags.tv.s + ', ' : '') + 'Nhà sản xuất mời bạn tham gia ' + d.s + ' — ' + (d.k === 'tbtn' ? 'chương trình tìm kiếm và đào tạo nhóm nhạc nam thần tượng thế hệ mới: 100 ngày huấn luyện cùng chuyên gia Hàn Quốc, chung kết chọn đội hình ra mắt.' : d.k === 'atvncg' ? 'chương trình quy tụ những nghệ sĩ nam đa tài, nhiều tuổi nghề. Sẽ có hát, nhảy, nhạc cụ, võ thuật, thử thách thể lực.' : 'chương trình thực tế âm nhạc hot nhất, quy tụ ' + (d.k === 'exsh' ? 'các nữ nghệ sĩ trẻ' : 'các nam nghệ sĩ trẻ') + '. Khán giả bình chọn quyết định ai ở lại.') + ' Tham gia thì kín lịch mấy tháng, áp lực lớn, nhưng có thể đổi đời.'; },
    opts: [
      { k: 'nhan', l: 'Nhận lời', ai: { w: 1.3, amb: 1 }, run: function (l, r, log, d) { if (l.flags.tv) (l.flags.tvHist = l.flags.tvHist || []).push(l.flags.tv); l.flags.tvN = (l.flags.tvN || 0) + 1; l.flags.tv = { k: d.k, s: d.s, i: 0, pts: 0, y: yr(l), saved: 0, leads: 0, awards: [] }; log('Nhận lời tham gia ' + d.s + '!', 'big'); l.fame = (l.fame || 0) + 2e4; l.pending.unshift(E.DEC.tv_vong.make(l, r)); } },
      { k: 'tu_choi', l: 'Từ chối, tập trung làm nhạc', ai: { w: 0.5 }, run: function (l, r, log, d) { if (l.flags.tv) (l.flags.tvHist = l.flags.tvHist || []).push(l.flags.tv); l.flags.tv = { k: d.k, s: d.s, no: true, y: yr(l) }; log('Từ chối lời mời ' + d.s + ', tập trung vào dự án riêng.', 'neutral'); } }
    ]
  });
  E.TRIG.push({ id: 'tv_moi', when: function (l, a) { return free(l) && canInvite(l); }, p: 0.18, cd: 2, max: 4 });
  E.MAJOR && (E.MAJOR.tv_moi = 1);

  // ---------- từng vòng ----------
  SC('tv_vong', {
    title: function (l) { var T = l.flags.tv, R0 = FMT[T.k].rounds[T.i]; return T.s + ' · ' + R0.n; },
    valid: function (l) { return !!(l.flags.tv && !l.flags.tv.no && !l.flags.tv.out && !l.flags.tv.done); },
    prep: function (l, r) { var T = l.flags.tv, R0 = FMT[T.k].rounds[T.i]; return { m: team(l, r, R0.final ? 4 : 4), lead: ch(r, 0.25) }; },
    text: function (l) {
      var T = l.flags.tv, R0 = FMT[T.k].rounds[T.i], d = arguments[1];
      return R0.d + (R0.final ? ' Bạn bước vào chung kết cùng ' : ' Bạn được ghép ' + (T.k === 'atvncg' ? 'nhà' : 'đội') + ' với ') + d.m.join(', ') + '.' + (d.lead ? ' Bạn được bầu làm đội trưởng.' : '') + (R0.dance && T.dance ? ' Mấy tuần tập nhảy ngày đêm vừa qua sắp được đền đáp.' : '');
    },
    opts: [
      { k: 'ganh', l: function (l) { var R0 = FMT[l.flags.tv.k].rounds[l.flags.tv.i]; return R0.dance ? 'Nhận vị trí center, nhảy hết sức' : R0.final ? 'Dốc toàn lực cho tiết mục cuối cùng' : 'Nhận phần khó nhất, "gánh" cả đội'; }, ai: { w: 1, amb: 1, risk: 0.5 }, run: function (l, r, log, d) { perform(l, r, log, d, 0.12, 0.22); } },
      { k: 'an_toan', l: 'Chọn phần sở trường, diễn chắc chắn', ai: { w: 1.1 }, run: function (l, r, log, d) { perform(l, r, log, d, 0.05, 0.1); } },
      { k: 'sang_tao', l: function (l) { return l.flags.tv.k === 'atvncg' ? 'Thử thách bản thân: học nhạc cụ / võ thuật mới cho tiết mục' : 'Đề xuất bản phối, ý tưởng sân khấu mới lạ'; }, ai: { w: 0.8, smart: 0.6 }, run: function (l, r, log, d) { perform(l, r, log, d, 0.15, 0.32); } }
    ]
  });
  function perform(l, r, log, d, bonus, spread) {
    var T = l.flags.tv, R0 = FMT[T.k].rounds[T.i];
    var p = base(l) + bonus + (r() - 0.5) * spread * 2 + (r() - 0.5) * 0.2 + (d.lead ? 0.03 : 0) + (R0.dance ? (T.dance ? 0.12 : -0.08) : 0);
    T.pts += p; T.last = p; T.best = Math.max(T.best || 0, p); if (d.lead) T.leads = (T.leads || 0) + 1; l.skill = Math.min(100, (l.skill || 40) + 2);
    var mate = pick(r, d.m);
    if (R0.final) return finale(l, r, log);
    var good = p >= (R0.cut || 0) + 0.18;
    log(R0.n + ' (' + T.s + '): ' + (good ? pick(r, ['tiết mục của đội bùng nổ, khán giả đứng dậy vỗ tay, bạn lọt top bình chọn cá nhân.', 'bạn và ' + mate + ' có màn song ca được cắt clip lan truyền khắp mạng xã hội.', 'phần trình diễn của bạn được giám khảo khen "đẳng cấp".']) : p >= (R0.cut || 0) ? pick(r, ['đội diễn ổn, bạn an toàn đi tiếp.', 'tiết mục tròn trịa, chưa thật sự nổi bật.', mate + ' quên lời nhưng cả đội vẫn gỡ lại được.']) : pick(r, R0.dance ? ['bạn lệch nhịp ở đoạn cao trào, cả đội phải nhảy bù.', 'bạn quên vũ đạo giữa sân khấu, đứng hình mất mấy giây.'] : ['bạn hụt hơi ở nốt cao, điểm bình chọn tụt hẳn.', 'đội bất đồng ý tưởng đến phút chót, tiết mục rời rạc.', 'bạn quên lời ở đoạn điệp khúc, điểm bình chọn tụt hẳn.'])), good ? 'good' : p >= (R0.cut || 0) ? 'neutral' : 'bad');
    l.fame = (l.fame || 0) * (good ? 1.25 : 1.08) + (good ? 3e4 : 8e3);
    if (good) fx(l, { hap: 4 }); if (l.mind) l.mind.stress = Math.min(100, l.mind.stress + 4);
    if (R0.cut && p < R0.cut) { l.pending.unshift(E.DEC.tv_loai.make(l, r)); return; }
    next(l, r);
  }
  function next(l, r) {
    var T = l.flags.tv; T.i++;
    var R1 = FMT[T.k].rounds[T.i];
    if (R1 && R1.dance) { l.pending.unshift(E.DEC.tv_tap_nhay.make(l, r)); return; }
    if (R1) l.pending.unshift(E.DEC.tv_vong.make(l, r));
  }
  SC('tv_tap_nhay', {
    title: 'Trước vòng Dance battle', valid: function (l) { return !!(l.flags.tv && !l.flags.tv.out && !l.flags.tv.done); },
    text: function (l) { return 'Vòng tới là Dance battle. Biên đạo giao bài nhảy khó, cả đội chỉ có ba tuần.' + ((l.skill || 40) < 50 ? ' Bạn vốn không phải người nhảy giỏi.' : ''); },
    opts: [
      { k: 'tap', l: 'Tập nhảy 10 tiếng mỗi ngày, ở lại phòng tập đến khuya', ai: { w: 1.2, amb: 1 }, run: function (l, r, log) { l.flags.tv.dance = true; fx(l, { hea: -2 }); log('Ba tuần tập nhảy ngày đêm, đầu gối bầm tím nhưng bài nhảy đã thuộc từng nhịp.', 'neutral'); l.pending.unshift(E.DEC.tv_vong.make(l, r)); } },
      { k: 'vua', l: 'Tập vừa phải, giữ sức cho giọng hát', ai: { w: 0.8 }, run: function (l, r, log) { log('Tập vừa phải, giữ giọng. Hi vọng phần hát bù được phần nhảy.', 'neutral'); l.pending.unshift(E.DEC.tv_vong.make(l, r)); } }
    ]
  });
  // bị loại → được bình chọn cứu / hồi sinh
  SC('tv_loai', {
    title: function (l) { return 'Nguy cơ dừng chân · ' + l.flags.tv.s; }, valid: function (l) { return !!(l.flags.tv && !l.flags.tv.out); },
    text: function (l) { var T = l.flags.tv; return 'Kết quả ' + FMT[T.k].rounds[T.i].n + ': bạn nằm trong nhóm có điểm thấp nhất, có nguy cơ dừng chân. ' + (T.k === 'atvncg' ? 'Theo luật hồi sinh, các anh tài còn lại sẽ bỏ phiếu chọn người được quay lại.' : 'Cổng bình chọn trực tuyến vẫn mở — anh trai dẫn đầu bình chọn có thể được cứu.') + (T.saved ? ' Bạn đã từng được cứu một lần.' : ''); },
    opts: [
      { k: 'fan', l: function (l) { return l.flags.tv.k === 'atvncg' ? 'Hi vọng vào lá phiếu của các anh tài' : 'Kêu gọi fan bình chọn cứu'; }, ai: { w: 1.2 }, run: function (l, r, log) {
        var T = l.flags.tv, pr = T.saved ? 0.15 : T.k === 'atvncg' ? 0.25 + l.st.soc / 300 : 0.15 + Math.min(0.4, Math.log10((l.fame || 0) + 10) / 15);
        if (ch(r, pr)) { T.saved++; log(T.k === 'atvncg' ? 'Các anh tài bỏ phiếu hồi sinh bạn! Ôm nhau khóc giữa sân khấu, bạn trở lại "nhà" cũ.' : 'Fandom cày bình chọn suốt đêm — bạn được cứu ở phút chót! Cả trường quay vỡ òa.', 'big'); fx(l, { hap: 10 }); H.mem(l, 'Khoảnh khắc được ' + (T.k === 'atvncg' ? 'các anh em hồi sinh' : 'fan bình chọn cứu') + ' ở ' + T.s + '.', 7); l.fame = (l.fame || 0) * 1.3; next(l, r); }
        else out(l, log); } },
      { k: 'chap_nhan', l: 'Chấp nhận dừng chân, cảm ơn khán giả', ai: { w: 0.6 }, run: function (l, r, log) { out(l, log); } }
    ]
  });
  function out(l, log) {
    var T = l.flags.tv; T.out = true; T.done = true;
    var at = FMT[T.k].rounds[T.i].n;
    log('Dừng chân ở ' + at + ' — ' + T.s + '. Dù không đi tiếp, khán giả đã nhớ tên bạn.', 'neutral');
    l.fame = (l.fame || 0) * 1.4 + 5e4; fx(l, { hap: -4 });
    if (T.i >= 3 && promote(l)) log('Sau chương trình, lời mời biểu diễn tăng hẳn: bạn trở thành ' + E.jobTitle(l) + '.', 'good');
    H.mem(l, 'Hành trình ở ' + T.s + ' — dừng chân ở ' + at + '.', 5);
  }
  function finale(l, r, log) {
    var T = l.flags.tv, avg = T.pts / (T.i + 1) + (T.saved ? -0.05 : 0) + Math.min(0.15, Math.log10((l.fame || 0) + 10) / 50);
    T.done = true;
    if (T.k === 'tbtn') {
      if ((avg >= 0.9 && ch(r, 0.8)) || ch(r, 0.15)) { T.res = 'debut'; log('Chung kết ' + T.s + ': bạn có tên trong đội hình debut 7 thành viên — nhóm nhạc nam thế hệ mới chính thức ra mắt!', 'big'); l.fame = (l.fame || 0) * 2.5 + 3e5; if (!l.job || !/^(ca_si|rapper)$/.test(jid(l))) E.startJob(l, 'ca_si', r, log); promote(l); H.cash(l, V(l, 150), 'Hợp đồng nhóm nhạc'); H.mem(l, 'Đêm được gọi tên vào đội hình debut ' + T.s + '.', 9); fx(l, { hap: 16 }); }
      else { T.res = 'final'; log('Chung kết ' + T.s + ': dừng chân ngay trước thềm debut. Bạn ôm các đồng đội khóc, hứa sẽ ra mắt bằng con đường khác.', 'neutral'); l.fame = (l.fame || 0) * 1.6 + 8e4; fx(l, { hap: -2 }); }
      awards(l, r, log, avg); return;
    }
    if (T.k === 'atvncg') {
      if ((avg >= 0.8 && ch(r, 0.75)) || ch(r, 0.25)) { T.res = 'giatoc'; log('Đêm chung kết ' + T.s + ': bạn được gọi tên vào "Gia tộc Anh tài Toàn năng"! Các anh tài ôm chầm lấy nhau.', 'big'); l.fame = (l.fame || 0) * 2 + 2e5; promote(l); H.mem(l, 'Đêm được gọi tên vào Gia tộc Anh tài Toàn năng.', 8); }
      else { T.res = 'final'; log('Đêm chung kết ' + T.s + ': bạn không có tên trong Gia tộc Anh tài Toàn năng, nhưng ra về cùng những người anh em và sự yêu mến của khán giả.', 'good'); l.fame = (l.fame || 0) * 1.5 + 8e4; }
      fx(l, { hap: 10 }); H.cash(l, V(l, 200), 'Cát-xê chương trình, show diễn sau chung kết'); awards(l, r, log, avg); return;
    }
    var win = avg >= 0.9 && ch(r, 0.22 + (avg - 0.9) * 2.5), best = win || (avg >= 0.84 && ch(r, 0.6)) || ch(r, 0.08);
    if (win) { T.res = 'win'; log('QUÁN QUÂN ' + T.s.toUpperCase() + '! Pháo hoa rực trời, cả nước gọi tên ' + FMT[T.k].pre + ' ' + given(l) + '.', 'big'); l.fame = (l.fame || 0) * 3 + 1e6; promote(l); promote(l); H.cash(l, V(l, 1000), 'Giải quán quân và hợp đồng sau chương trình'); H.mem(l, 'Đêm đăng quang quán quân ' + T.s + ', tay run run cầm cúp.', 10); fx(l, { hap: 20 }); }
    else if (best) { T.res = 'best5'; log('Chung kết ' + T.s + ': bạn lọt vào nhóm "Best 5" — sẽ ra mắt nhóm nhạc và đi tour cùng các ' + FMT[T.k].pre + ' khác.', 'big'); l.fame = (l.fame || 0) * 2 + 3e5; promote(l); H.cash(l, V(l, 400), 'Hợp đồng nhóm Best 5'); H.mem(l, 'Ngày được gọi tên vào Best 5 ' + T.s + '.', 8); fx(l, { hap: 14 }); }
    else { T.res = 'final'; log('Chung kết ' + T.s + ': không vào Best 5, nhưng bạn đã đi đến chặng cuối và có cả một cộng đồng fan.', 'good'); l.fame = (l.fame || 0) * 1.6 + 1e5; promote(l); fx(l, { hap: 8 }); }
  }
  // các hạng mục giải phụ (theo các mùa đã phát sóng)
  var AW = {
    say: [['The Best Leader — đội trưởng được yêu thích nhất', function (T) { return T.leads >= 1 ? 0.35 : 0.03; }], ['The Best Performer — trình diễn ấn tượng nhất', function (T, a) { return a >= 0.85 ? 0.3 : 0.05; }],
      ['The Best Group Performance — tiết mục nhóm sáng tạo nhất', function () { return 0.12; }], ['The Best Transformer — thay đổi ấn tượng nhất', function (T) { return T.dance || T.saved ? 0.3 : 0.05; }],
      ['The Best Showcase — màn solo bùng nổ nhất', function (T) { return (T.best || 0) >= 0.95 ? 0.3 : 0.04; }], ['The Best Hit — ca khúc có lượt nghe cao nhất', function (T, a, l) { return 0.06 + Math.min(0.2, Math.log10((l.fame || 0) + 10) / 40); }]],
    atvncg: [['Anh Tài được yêu thích nhất', function (T, a, l) { return Math.min(0.3, Math.log10((l.fame || 0) + 10) / 25); }], ['Anh Tài quốc dân', function () { return 0.12; }], ['Anh Tài có điệu nhảy sexy', function (T) { return T.dance ? 0.2 : 0.06; }],
      ['Nam thần giải trí', function (T, a, l) { return l.st.soc >= 60 ? 0.15 : 0.05; }], ['Anh Tài truyền cảm hứng', function (T) { return T.saved ? 0.25 : 0.08; }], ['Anh Tài năng lượng', function (T, a, l) { return l.st.hap >= 60 ? 0.15 : 0.06; }], ['Anh Tài ấm áp', function (T, a, l) { return l.karma >= 60 ? 0.15 : 0.06; }]],
    tbtn: [['Tân binh dẫn đầu bảng điểm cá nhân — được diễn solo ở chung kết', function (T) { return (T.best || 0) >= 0.95 ? 0.35 : 0.06; }], ['Tân binh được khán giả yêu thích nhất', function (T, a, l) { return Math.min(0.25, Math.log10((l.fame || 0) + 10) / 28); }]]
  };
  function awards(l, r, log, avg) {
    var T = l.flags.tv, L = AW[T.k === 'atvncg' ? 'atvncg' : T.k === 'tbtn' ? 'tbtn' : 'say'], got = [];
    L.forEach(function (x) { if (got.length < 2 && ch(r, x[1](T, avg, l))) got.push(x[0]); });
    if (T.k === 'atvncg' && T.res === 'giatoc' && avg >= 0.85 && ch(r, 0.2)) got.unshift('Thủ lĩnh Gia tộc Anh tài Toàn năng');
    if (T.k === 'atvncg' && yr(l) >= 2026 && T.leads >= 1 && ch(r, 0.3)) got.push('danh hiệu Chiến tướng');
    T.awards = got;
    got.forEach(function (a) { log('Đêm trao giải ' + T.s + ': bạn nhận ' + a + '!', 'big'); l.fame = (l.fame || 0) * 1.2 + 5e4; H.mem(l, 'Giây phút được xướng tên ' + a + ' ở ' + T.s + '.', 6); });
    if (got.length) fx(l, { hap: 6 });
  }
  E.TV_AWARDS = AW;
  E.TV_FMT = FMT;
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
/* ===== js/life40.js ===== */
/* Một Đời — v3.9 (góp ý của người chơi):
   · đại học: ngành thường 4 năm; Bách khoa (kỹ sư), Kiến trúc 5 năm; Dược 5 năm; Y đa khoa, Răng – Hàm – Mặt, Y học cổ truyền 6 năm; Quân y 7 năm; cao đẳng 2 năm
   · năm cuối phải bảo vệ đồ án / khóa luận: có thể rớt và bảo vệ lại; sinh viên Bách khoa hay "dính" 1–2 lần (trừ khi học rất giỏi)
   · học Y: chọn hướng (đa khoa, răng hàm mặt, y học cổ truyền, dược, điều dưỡng, quân y), đi thực tập ở bệnh viện lớn theo nơi học, thi bác sĩ nội trú,
     ra trường chọn chuyên khoa (thu nhập khác nhau: răng hàm mặt, chỉnh hình, thẩm mỹ cao hơn…), giàu thì mở phòng khám theo chuyên môn
   · đi làm: nhật ký tự ghi số liệu nghề (đã khám bao nhiêu lượt, mổ bao nhiêu ca, dạy bao nhiêu khóa, chạy bao nhiêu chuyến…) — không phải lựa chọn
   · thực tập cuối khóa cho các ngành khác (có thể được giữ lại làm việc) */
(function (G) {
  'use strict';
  var U = G.U, E = G.E, H = E.H, SC = E.SC, isVN = H.isVN;
  function fx(l, o) { H.fx(l, o); }
  function mo(l, v) { return H.money(l, v); }
  function pick(r, a) { return U.pick(r, a); }
  function ch(r, p) { return r() < p; }
  function free(l) { return !(l.jailUntil != null && l.age < l.jailUntil) && !(l.abroad && l.abroad.trapped) && !(l.flags.military && l.age < l.flags.military); }
  function vnd(l) { return isVN(l) && l.cur === 'vnd' && !(l.abroad && l.abroad.perm); }
  function V(l, tr) { return vnd(l) ? tr : tr / 90 * l.base; }
  function jid(l) { return l.job ? E.resolveJob(l.job.id) : ''; }
  function rk(l) { return l.job ? l.job.rank || 0 : 0; }
  function fmt(n) { return U.fmtNum(Math.round(n)); }
  function city(l) { return l.uniCity || ''; }
  function north(c) { return /Hà Nội|Hải Phòng|Thái Nguyên|Nam Định|Bắc Ninh/.test(c); }
  function studying(l) { return l.school === 'uni' || (l.school === 'abroad' && l.abroad && l.abroad.study); }

  // ===================================================================
  // 1. TÊN TRƯỜNG & SỐ NĂM HỌC THEO NGÀNH
  // ===================================================================
  var LOCAL = { 'Huế': 'Đại học Huế', 'Đà Nẵng': 'Đại học Đà Nẵng', 'Cần Thơ': 'Trường Đại học Cần Thơ', 'Thái Nguyên': 'Đại học Thái Nguyên', 'Vinh': 'Trường Đại học Vinh', 'Quy Nhơn': 'Trường Đại học Quy Nhơn', 'Hải Phòng': 'Trường Đại học Hải Phòng', 'Thanh Hóa': 'Trường Đại học Hồng Đức', 'Đà Lạt': 'Trường Đại học Đà Lạt', 'Buôn Ma Thuột': 'Trường Đại học Tây Nguyên', 'Nha Trang': 'Trường Đại học Nha Trang' };
  function uniFor(l, k, r) {
    var chosen=l.flags.study54&&l.flags.study54.admitted;
    if(chosen&&chosen.age===l.age&&chosen.major===k&&E.EDUCATION54){var named=E.EDUCATION54.schools.filter(function(s){return s.id===chosen.school;})[0];if(named)return named.name;}
    var c = city(l), hn = /Hà Nội/.test(c), sg = /Hồ Chí Minh/.test(c), strong = (l.examScore != null ? l.examScore >= 24 : l.st.kno >= 66);
    if (!isVN(l) || l.school === 'abroad') return null;
    if (k === 'it') return hn ? (strong ? 'Đại học Bách khoa Hà Nội' : pick(r, ['Trường Đại học Công nghiệp Hà Nội', 'Học viện Công nghệ Bưu chính Viễn thông', 'Trường Đại học Thủy lợi'])) : sg ? (strong ? 'Trường Đại học Bách khoa – ĐHQG TP.HCM' : pick(r, ['Trường Đại học Công nghiệp TP.HCM', 'Trường Đại học Sư phạm Kỹ thuật TP.HCM', 'Trường Đại học Công nghệ Thông tin – ĐHQG TP.HCM'])) : /Đà Nẵng/.test(c) && strong ? 'Trường Đại học Bách khoa – Đại học Đà Nẵng' : LOCAL[c] || 'trường đại học ở ' + c;
    if (k === 'eco') return hn ? pick(r, strong ? ['Trường Đại học Kinh tế Quốc dân', 'Trường Đại học Ngoại thương', 'Học viện Tài chính'] : ['Học viện Ngân hàng', 'Trường Đại học Thương mại']) : sg ? pick(r, strong ? ['Trường Đại học Kinh tế TP.HCM', 'Trường Đại học Kinh tế – Luật'] : ['Trường Đại học Tài chính – Marketing', 'Trường Đại học Ngân hàng TP.HCM']) : LOCAL[c] || 'trường đại học ở ' + c;
    if (k === 'law') return hn ? pick(r, ['Trường Đại học Luật Hà Nội', 'Học viện Báo chí và Tuyên truyền', 'Trường Đại học Khoa học Xã hội và Nhân văn']) : sg ? pick(r, ['Trường Đại học Luật TP.HCM', 'Trường Đại học Khoa học Xã hội và Nhân văn TP.HCM']) : LOCAL[c] || 'trường đại học ở ' + c;
    if (k === 'edu') return hn ? 'Trường Đại học Sư phạm Hà Nội' : sg ? 'Trường Đại học Sư phạm TP.HCM' : /Huế/.test(c) ? 'Trường Đại học Sư phạm – Đại học Huế' : LOCAL[c] || 'trường đại học ở ' + c;
    if (k === 'art') return hn ? pick(r, ['Trường Đại học Kiến trúc Hà Nội', 'Trường Đại học Mỹ thuật Công nghiệp']) : sg ? pick(r, ['Trường Đại học Kiến trúc TP.HCM', 'Trường Đại học Mỹ thuật TP.HCM']) : LOCAL[c] || 'trường đại học ở ' + c;
    return LOCAL[c] || null;
  }
  function medUni(l, track) {
    var c = city(l);
    if (!isVN(l) || l.school === 'abroad') return null;
    if (track === 'qy') return 'Học viện Quân y';
    if (track === 'duoc') return /Hà Nội/.test(c) ? 'Trường Đại học Dược Hà Nội' : /Hồ Chí Minh/.test(c) ? 'Đại học Y Dược TP.HCM' : 'Trường Đại học Y Dược ' + (c || 'Huế');
    if (track === 'yhct') return /Hà Nội/.test(c) ? 'Học viện Y Dược học cổ truyền Việt Nam' : /Hồ Chí Minh/.test(c) ? 'Đại học Y Dược TP.HCM' : 'Trường Đại học Y Dược ' + (c || 'Huế');
    return /Hà Nội/.test(c) ? 'Trường Đại học Y Hà Nội' : /Hồ Chí Minh/.test(c) ? 'Đại học Y Dược TP.HCM' : /Huế/.test(c) ? 'Trường Đại học Y Dược Huế' : /Cần Thơ/.test(c) ? 'Trường Đại học Y Dược Cần Thơ' : /Thái Nguyên/.test(c) ? 'Trường Đại học Y Dược Thái Nguyên' : /Hải Phòng/.test(c) ? 'Trường Đại học Y Dược Hải Phòng' : 'trường y ở ' + (c || 'tỉnh');
  }
  function isBK(l) { return /Bách khoa/.test(l.uniName || (l.flags.tSchool && l.flags.tSchool.n) || ''); }
  var ma0 = E.DEC.major.apply;
  E.DEC.major.apply = function (l, d, k, r, log) {
    var x = ma0.apply(this, arguments);
    l.uniName = uniFor(l, k, r); l.flags.gradTries = 0; l.flags.gradOK = false;
    if (k === 'med') { l.schoolEnd = l.age + 6; l.pending.unshift(E.DEC.nganh_y.make(l, r)); return x; }
    var yrs = (k === 'it' && isBK(l)) || (k === 'art' && /Kiến trúc/.test(l.uniName || '')) ? 5 : 4;
    l.schoolEnd = l.age + yrs; if (l.abroad && l.abroad.study) l.abroad.until = l.schoolEnd;
    if (l.uniName) log('Trường: ' + l.uniName + ' — chương trình ' + yrs + ' năm' + (yrs === 5 ? (k === 'it' ? ' (kỹ sư)' : ' (kiến trúc sư)') : '') + '.', 'neutral');
    return x;
  };

  // ===================================================================
  // 2. NGÀNH Y
  // ===================================================================
  var TRACK = {
    dk: { n: 'Y khoa (bác sĩ đa khoa)', y: 6, job: 'bac_si', d: '6 năm · ra trường thực hành 18 tháng mới có chứng chỉ hành nghề' },
    rhm: { n: 'Răng – Hàm – Mặt', y: 6, job: 'nha_si', d: '6 năm · điểm chuẩn rất cao · ra trường thu nhập cao' },
    yhct: { n: 'Y học cổ truyền', y: 6, job: 'bac_si', spec: 'yhct', d: '6 năm · châm cứu, bốc thuốc, phục hồi chức năng' },
    duoc: { n: 'Dược học', y: 5, job: 'duoc_si', d: '5 năm · làm bệnh viện, công ty dược, mở nhà thuốc' },
    dd: { n: 'Điều dưỡng', y: 4, job: 'dieu_duong', d: '4 năm · dễ xin việc, vất vả, lương thấp hơn bác sĩ' },
    qy: { n: 'Bác sĩ quân y', y: 7, job: 'bac_si', d: '7 năm ở Học viện Quân y · kỷ luật quân đội, ra trường làm ở bệnh viện quân đội' }
  };
  E.MED_TRACK = TRACK;
  SC('nganh_y', {
    title: 'Học ngành gì trong khối Y?', valid: function (l) { return studying(l) && l.major === 'med'; },
    text: function (l) { return 'Bạn đỗ khối ngành sức khỏe. Mỗi hướng học số năm khác nhau, cơ hội nghề nghiệp cũng khác nhau.'; },
    opts: Object.keys(TRACK).map(function (k) {
      var t = TRACK[k];
      return { k: k, l: t.n, h: t.d, req: function (l) { return k !== 'qy' || (isVN(l) && l.st.hea >= 55); }, ai: { w: k === 'dk' ? 1.4 : k === 'rhm' ? 0.6 : k === 'qy' ? 0.3 : 0.8 },
        run: function (l, r, log) { l.med = { track: k, spec: t.spec || (k === 'rhm' ? 'rhm' : null) }; l.majorName = t.n; l.schoolEnd = l.age + t.y; if (l.abroad && l.abroad.study) l.abroad.until = l.schoolEnd; l.uniName = medUni(l, k) || l.uniName; if (k === 'qy') { l.flags.milDone = true; l.uniCity = 'Hà Nội'; }
          log('Vào học ' + t.n + (l.uniName ? ' ở ' + l.uniName : '') + ' — ' + t.y + ' năm đèn sách.', 'good'); } };
    })
  });
  E.MAJOR && (E.MAJOR.nganh_y = 1);
  // bệnh viện thực hành theo nơi học
  function hospitals(l) {
    var c = city(l), t = l.med && l.med.track;
    if (!isVN(l) || l.school === 'abroad') return ['bệnh viện đại học', 'bệnh viện thành phố'];
    if (t === 'qy') return ['Bệnh viện Trung ương Quân đội 108', 'Bệnh viện Quân y 103'];
    if (t === 'rhm') return /Hồ Chí Minh/.test(c) ? ['Bệnh viện Răng Hàm Mặt Trung ương TP.HCM', 'Bệnh viện Răng Hàm Mặt TP.HCM'] : ['Bệnh viện Răng Hàm Mặt Trung ương Hà Nội', 'Bệnh viện Đại học Y Hà Nội'];
    if (/Hà Nội/.test(c)) return ['Bệnh viện Bạch Mai', 'Bệnh viện Hữu nghị Việt Đức', 'Bệnh viện K', 'Bệnh viện Nhi Trung ương', 'Bệnh viện Phụ sản Trung ương'];
    if (/Hồ Chí Minh/.test(c)) return ['Bệnh viện Chợ Rẫy', 'Bệnh viện Từ Dũ', 'Bệnh viện Nhi Đồng 1', 'Bệnh viện Đại học Y Dược TP.HCM', 'Bệnh viện Nhân dân 115'];
    if (/Huế/.test(c)) return ['Bệnh viện Trung ương Huế'];
    if (/Cần Thơ/.test(c)) return ['Bệnh viện Đa khoa Trung ương Cần Thơ'];
    if (/Thái Nguyên/.test(c)) return ['Bệnh viện Trung ương Thái Nguyên'];
    if (/Hải Phòng/.test(c)) return ['Bệnh viện Hữu nghị Việt Tiệp'];
    if (/Đà Nẵng/.test(c)) return ['Bệnh viện Đà Nẵng'];
    return ['bệnh viện đa khoa tỉnh'];
  }
  E.medHospitals = hospitals;
  function workPlace(l, r) {
    var c = city(l), sp = l.med && l.med.spec, hn = /Hà Nội/.test(c) || !/Hồ Chí Minh/.test(c) && north(c);
    if (l.med.track === 'duoc') return pick(r, isVN(l) && !(l.abroad && l.abroad.perm) ? ['khoa Dược của bệnh viện tỉnh', 'một công ty dược', 'chuỗi nhà thuốc lớn'] : ['một chuỗi nhà thuốc', 'một công ty dược']);
    if (!isVN(l) || (l.abroad && l.abroad.perm)) return 'bệnh viện thành phố';
    if (l.med.track === 'qy') return pick(r, hn ? ['Bệnh viện Trung ương Quân đội 108', 'Bệnh viện Quân y 103'] : ['Bệnh viện Quân y 175']);
    var M = { san: hn ? 'Bệnh viện Phụ sản Trung ương' : 'Bệnh viện Từ Dũ', nhi: hn ? 'Bệnh viện Nhi Trung ương' : 'Bệnh viện Nhi Đồng 1', ubuou: hn ? 'Bệnh viện K' : 'Bệnh viện Ung bướu TP.HCM', yhct: hn ? 'Bệnh viện Y học cổ truyền Trung ương' : 'Bệnh viện Y học cổ truyền TP.HCM', tamthan: hn ? 'Bệnh viện Tâm thần Trung ương 1' : 'Bệnh viện Tâm thần TP.HCM', dalieu: hn ? 'Bệnh viện Da liễu Trung ương' : 'Bệnh viện Da liễu TP.HCM', rhm: hn ? 'Bệnh viện Răng Hàm Mặt Trung ương Hà Nội' : 'Bệnh viện Răng Hàm Mặt Trung ương TP.HCM', chinhhinh: hn ? 'Bệnh viện Hữu nghị Việt Đức' : 'Bệnh viện Chấn thương Chỉnh hình TP.HCM', tim: hn ? 'Viện Tim mạch – Bệnh viện Bạch Mai' : 'Viện Tim TP.HCM' };
    if (sp && M[sp]) return M[sp];
    if (l.med.track === 'duoc') return pick(r, ['khoa Dược của bệnh viện tỉnh', 'một công ty dược', 'chuỗi nhà thuốc lớn']);
    if (l.med.track === 'dd') return pick(r, hospitals(l));
    return pick(r, hn ? ['Bệnh viện Bạch Mai', 'Bệnh viện Hữu nghị Việt Đức', 'Bệnh viện đa khoa tỉnh'] : ['Bệnh viện Chợ Rẫy', 'Bệnh viện Nhân dân 115', 'Bệnh viện đa khoa tỉnh']);
  }
  var YT = [
    ['dem', 'Ca trực đêm đầu tiên', function (l, h) { return 'Lần đầu trực đêm ở khoa Cấp cứu ' + h + ': xe cấp cứu về liên tục, bác sĩ hướng dẫn giao bạn theo dõi ba bệnh nhân nặng.'; }, [
      ['hoc', 'Chạy theo bác sĩ, hỏi từng ca, ghi chép đến sáng', { w: 1.2, smart: 1 }, function (l, r, log, h) { fx(l, { kno: 3, hea: -2 }); log('Thức trắng đêm ở ' + h + ', học được nhiều hơn cả một học kỳ trên giảng đường.', 'good'); H.mem(l, 'Ca trực đêm đầu tiên ở ' + h + '.', 4); }],
      ['ngu', 'Tranh thủ chợp mắt ở phòng trực', { w: 0.6 }, function (l, r, log) { log('Chợp mắt được một lúc thì bị gọi dậy, bác sĩ nhắc khéo "trực là phải tỉnh".', 'neutral'); }]]],
    ['mo', 'Lần đầu vào phòng mổ', function (l, h) { return 'Bạn được vào phòng mổ ở ' + h + ' quan sát một ca mổ bụng. Mùi thuốc sát trùng, ánh đèn mổ chói chang…'; }, [
      ['xem', 'Đứng sát bàn mổ, quan sát kỹ', { w: 1 }, function (l, r, log) { if (ch(r, 0.25)) { log('Đứng được nửa tiếng thì choáng váng, ngã ngồi xuống sàn — "nghi lễ" của sinh viên y năm đầu đi viện. Hôm sau quay lại đứng hết ca.', 'neutral'); } else { log('Đứng hết ca mổ bốn tiếng, mắt không rời phẫu trường. Từ đó mê ngoại khoa.', 'good'); l.flags.yNgoai = true; } fx(l, { kno: 2 }); }],
      ['sau', 'Đứng phía sau cho an toàn', { w: 0.8 }, function (l, r, log) { log('Đứng phía sau quan sát, ghi chép từng bước.', 'neutral'); fx(l, { kno: 1 }); }]]],
    ['mat', 'Bệnh nhân đầu tiên ra đi', function (l, h) { return 'Một cụ ông bạn chăm suốt tuần thực tập ở ' + h + ' không qua khỏi. Gia đình cụ khóc ngoài hành lang.'; }, [
      ['o_lai', 'Ở lại an ủi gia đình cụ', { w: 1.2, soc: 1 }, function (l, r, log) { log('Ở lại bên gia đình cụ. Bác sĩ hướng dẫn vỗ vai: "Làm nghề này, phải học cách đứng vững."', 'neutral'); fx(l, { karma: 3, hap: -4 }); H.mem(l, 'Lần đầu tiễn một bệnh nhân ra đi trong đời làm y.', 5); }],
      ['ve', 'Lặng lẽ về phòng trọ khóc một mình', { w: 0.8 }, function (l, r, log) { log('Về phòng trọ khóc cả đêm, rồi sáng mai vẫn đến viện đúng giờ.', 'neutral'); fx(l, { hap: -5 }); }]]],
    ['nha', 'Người nhà bệnh nhân', function (l, h) { return 'Ở ' + h + ', người nhà một bệnh nhân quát tháo vì phải chờ lâu, chỉ thẳng mặt bạn: "Sinh viên thì biết gì!"'; }, [
      ['binh_tinh', 'Bình tĩnh giải thích, mời bác sĩ phụ trách ra', { w: 1.2 }, function (l, r, log) { log('Giữ bình tĩnh giải thích, người nhà dịu lại. Bác sĩ khen bạn biết cách giao tiếp.', 'good'); fx(l, { soc: 2 }); }],
      ['cai', 'Cãi lại', { risk: 0.6, w: 0.4 }, function (l, r, log) { log('Cãi lại, bị khoa nhắc nhở, viết bản tường trình.', 'bad'); fx(l, { hap: -3 }); }]]],
    ['cap_cuu', 'Ca cấp cứu', function (l, h) { return 'Đang trực ở ' + h + ', một bệnh nhân ngừng tim ngay trước mặt bạn, bác sĩ chưa kịp tới.'; }, [
      ['ep_tim', 'Ép tim ngay như đã học', { w: 1.2 }, function (l, r, log) { if (ch(r, 0.5)) { log('Ép tim liên tục đến khi kíp cấp cứu tới — bệnh nhân có mạch trở lại. Cả khoa nhắc tên bạn.', 'big'); fx(l, { karma: 5, hap: 6 }); H.mem(l, 'Lần đầu tự tay giành lại sự sống cho một người.', 7); } else { log('Ép tim đến khi kíp cấp cứu tới, nhưng bệnh nhân không qua khỏi. Bác sĩ bảo bạn đã làm đúng.', 'neutral'); fx(l, { kno: 2 }); } }],
      ['goi', 'Bấm chuông báo động, chạy gọi bác sĩ', { w: 0.8 }, function (l, r, log) { log('Chạy gọi bác sĩ, kíp cấp cứu tới kịp.', 'neutral'); }]]]
  ];
  YT.forEach(function (x) {
    var forDuoc = x[0] === 'nha';
    SC('yt_' + x[0], { title: x[1] + ' (sinh viên y)', valid: function (l) { return studying(l) && l.major === 'med' && (forDuoc || !(l.med && l.med.track === 'duoc')); },
      prep: function (l, r) { return { h: pick(r, hospitals(l)) }; }, text: function (l, d) { return x[2](l, d.h); },
      opts: x[3].map(function (o) { return { k: o[0], l: o[1], ai: o[2], run: function (l, r, log, d) { o[3](l, r, log, d.h); } }; }) });
    E.TRIG.push({ id: 'yt_' + x[0], when: function (l) { return free(l) && studying(l) && l.major === 'med' && (forDuoc || !(l.med && l.med.track === 'duoc')) && l.schoolEnd - l.age <= 4; }, p: 0.22, cd: 1, max: 1 });
  });
  // thi bác sĩ nội trú (năm cuối, học giỏi)
  SC('noi_tru', {
    title: 'Thi bác sĩ nội trú', valid: function (l) { return studying(l) && l.major === 'med' && l.med && /^(dk|rhm|yhct|qy)$/.test(l.med.track); },
    text: function (l) { return 'Năm cuối, bạn có thể thi bác sĩ nội trú — kỳ thi khó nhất ngành y, chỉ dành cho sinh viên giỏi. Đỗ thì học thêm 3 năm, ra trường có chuyên môn vững, được các bệnh viện lớn săn đón.'; },
    opts: [
      { k: 'thi', l: 'Dốc sức ôn thi nội trú', ai: { w: 1, amb: 1, smart: 1 }, run: function (l, r, log) { if (ch(r, Math.max(0.05, (l.st.kno - 60) / 60))) { l.flags.noiTru = true; l.schoolEnd += 3; if (l.abroad && l.abroad.study) l.abroad.until = l.schoolEnd; log('Đỗ bác sĩ nội trú! Thêm 3 năm "cày" ở bệnh viện, nhưng con đường chuyên môn rộng mở.', 'big'); H.mem(l, 'Ngày có tên trong danh sách trúng tuyển bác sĩ nội trú.', 6); fx(l, { hap: 8 }); } else { log('Trượt nội trú, ra trường theo con đường thông thường.', 'neutral'); fx(l, { hap: -3 }); } } },
      { k: 'khong', l: 'Không thi, ra trường đi làm sớm', ai: { w: 0.8 }, run: function (l, r, log) { log('Không thi nội trú, chuẩn bị ra trường đi làm.', 'neutral'); } }
    ]
  });
  E.TRIG.push({ id: 'noi_tru', when: function (l) { return free(l) && studying(l) && l.major === 'med' && l.med && /^(dk|rhm|yhct|qy)$/.test(l.med.track) && l.schoolEnd - l.age === 1 && !l.flags.noiTru && l.st.kno >= 62; }, p: 0.85, cd: 1, max: 1 });
  // chuyên khoa → thu nhập
  var SPEC = {
    noi: ['Nội khoa', 1, 0], ngoai: ['Ngoại khoa', 1.15, 1], nhi: ['Nhi khoa', 0.95, 0], san: ['Sản phụ khoa', 1.2, 1], tim: ['Tim mạch', 1.3, 0], cdha: ['Chẩn đoán hình ảnh', 1.2, 0],
    gmhs: ['Gây mê hồi sức', 1.2, 1], dalieu: ['Da liễu', 1.4, 0], chinhhinh: ['Chấn thương chỉnh hình', 1.5, 1], thammy: ['Phẫu thuật thẩm mỹ', 1.8, 1], tamthan: ['Tâm thần', 0.9, 0], ubuou: ['Ung bướu', 1.15, 0],
    yhct: ['Y học cổ truyền', 0.9, 0], rhm: ['Răng – Hàm – Mặt', 1, 1]
  };
  E.MED_SPEC = SPEC;
  SC('chuyen_khoa', {
    title: 'Chọn chuyên khoa', valid: function (l) { return !!(l.med && !l.med.spec && /^(dk|qy)$/.test(l.med.track)); },
    prep: function (l, r) { var ks = Object.keys(SPEC).filter(function (k) { return !/^(yhct|rhm)$/.test(k); }); for (var i = ks.length - 1; i > 0; i--) { var j = Math.floor(r() * (i + 1)), t = ks[i]; ks[i] = ks[j]; ks[j] = t; } if (l.flags.yNgoai && ks.indexOf('ngoai') > 5) { ks.splice(ks.indexOf('ngoai'), 1); ks.unshift('ngoai'); } return { ks: ks.slice(0, 6) }; },
    text: function (l) { return 'Ra trường, bạn phải chọn chuyên khoa để theo cả đời. Mỗi chuyên khoa một áp lực, một mức thu nhập.' + (l.flags.noiTru ? ' Là bác sĩ nội trú, bạn được ưu tiên chọn.' : ''); },
    opts: [0, 1, 2, 3, 4, 5].map(function (i) {
      return { k: 's' + i, l: function (l, d) { var s = SPEC[d.ks[i]]; return s ? s[0] : ''; }, h: function (l, d) { var s = SPEC[d.ks[i]]; return s ? (s[1] >= 1.4 ? 'thu nhập cao' : s[1] >= 1.15 ? 'thu nhập khá' : s[1] < 1 ? 'thu nhập thấp hơn, ít người theo' : 'thu nhập trung bình') + (s[2] ? ' · nhiều ca mổ, áp lực cao' : ' · khám, điều trị') : ''; }, req: function (l, d) { return !!d.ks[i]; }, ai: { w: 1 },
        run: function (l, r, log, d) { var k = d.ks[i]; l.med.spec = k; log('Chọn chuyên khoa ' + SPEC[k][0] + ', về công tác ở ' + workPlace(l, r) + '. Thực hành 18 tháng để được cấp chứng chỉ hành nghề.', 'good'); } };
    })
  });
  // ra trường: vào nghề theo hướng đã học
  E.HOOKS.year.push(function (l, r, log, a) {
    if (!l.med || l.med.out || studying(l)) return;
    if (l.edu < 5 || (l.abroad && l.abroad.study)) return; l.med.out = true;
    if (l.job) return;
    var t = TRACK[l.med.track]; if (!t) return;
    l.flags.needJob = false;
    E.startJob(l, t.job, r, log);
    if (l.flags.noiTru && l.job && l.job.rank < 1) l.job.rank = 1;
    if (!l.med.spec && /^(dk|qy)$/.test(l.med.track)) { l.pending.push(E.DEC.chuyen_khoa.make(l, r)); return; }
    log('Về công tác ở ' + workPlace(l, r) + (t.job === 'bac_si' || t.job === 'nha_si' ? '. Thực hành 18 tháng để được cấp chứng chỉ hành nghề.' : '.'), 'neutral');
  });
  // thu nhập theo chuyên khoa
  var cy0 = E.careerYear;
  E.careerYear = function (l) { var inc = cy0.apply(this, arguments); if (inc > 0 && l.med && l.med.spec && /^(bac_si|phong_kham)$/.test(jid(l)) && SPEC[l.med.spec]) inc *= SPEC[l.med.spec][1]; return inc; };
  // mở phòng khám theo chuyên môn
  SC('mo_phong_kham_ck', {
    title: 'Mở phòng khám riêng', valid: function (l) { return (jid(l) === 'bac_si' && rk(l) >= 2) || (jid(l) === 'nha_si' && rk(l) === 1); },
    text: function (l) { var s = l.med && SPEC[l.med.spec]; return 'Có tiếng trong nghề, bệnh nhân quen đông. Mở một phòng khám ' + (jid(l) === 'nha_si' ? 'nha khoa' : s ? 'chuyên khoa ' + s[0].toLowerCase() : 'tư') + ' cần khoảng ' + mo(l, V(l, 2500)) + ' (thuê mặt bằng, máy móc, giấy phép).'; },
    opts: [
      { k: 'mo', l: 'Mở phòng khám', h: function (l) { return '~' + mo(l, V(l, 2500)); }, req: function (l) { return l.money >= V(l, 1200); }, ai: { w: 1, amb: 1, risk: 0.5 }, run: function (l, r, log) {
        H.cash(l, -V(l, 2500), 'Mở phòng khám'); var s = l.med && SPEC[l.med.spec];
        if (jid(l) === 'nha_si') { l.job.rank = 2; log('Khai trương phòng khám nha khoa riêng — niềng răng, trồng răng implant, bọc sứ.', 'big'); }
        else { E.startJob(l, 'phong_kham', r, log); l.job.p = 'phòng khám ' + (s ? 'chuyên khoa ' + s[0].toLowerCase() : 'đa khoa'); log('Khai trương ' + l.job.p + ' của riêng mình. Ngày đầu đã kín lịch hẹn.', 'big'); }
        H.mem(l, 'Ngày cắt băng khánh thành phòng khám mang tên mình.', 7); fx(l, { hap: 8 }); } },
      { k: 'khong', l: 'Ở lại bệnh viện, chuyên tâm chuyên môn', ai: { w: 0.8 }, run: function (l, r, log) { log('Ở lại bệnh viện, tiếp tục cống hiến cho chuyên môn.', 'neutral'); } }
    ]
  });
  E.TRIG.push({ id: 'mo_phong_kham_ck', when: function (l, a) { return free(l) && ((jid(l) === 'bac_si' && rk(l) >= 2) || (jid(l) === 'nha_si' && rk(l) === 1)) && a >= 33 && a <= 60 && l.money >= V(l, 1200); }, p: 0.15, cd: 4, max: 2 });

  // ===================================================================
  // 3. BẢO VỆ ĐỒ ÁN / KHÓA LUẬN TỐT NGHIỆP
  // ===================================================================
  function passP(l) {
    var k = l.st.kno, bk = isBK(l), med = l.major === 'med';
    var p = bk ? (k >= 80 ? 0.85 : k >= 70 ? 0.6 : 0.45) : med ? (k >= 70 ? 0.92 : 0.78) : (k >= 60 ? 0.93 : k >= 45 ? 0.82 : 0.68);
    if ((l.flags.gradTries || 0) >= 1) p += 0.2; if ((l.flags.gradTries || 0) >= 2) p += 0.3;
    return Math.min(0.98, p);
  }
  function thesisName(l) { return l.major === 'med' ? 'thi tốt nghiệp bác sĩ (lý thuyết, lâm sàng)' : isBK(l) || l.major === 'it' || /Kiến trúc/.test(l.uniName || '') ? 'đồ án tốt nghiệp' : 'khóa luận tốt nghiệp'; }
  SC('bao_ve_tn', {
    title: function (l) { return 'Bảo vệ ' + thesisName(l); }, valid: function (l) { return studying(l) && l.schoolEnd != null && l.age + 1 >= l.schoolEnd; },
    text: function (l) { return 'Năm cuối ' + (l.uniName || 'đại học') + ': chỉ còn ' + thesisName(l) + ' là ra trường.' + (isBK(l) ? ' Sinh viên Bách khoa vẫn truyền tai nhau: "ra trường đúng hạn là kỳ tích".' : '') + ((l.flags.gradTries || 0) ? ' Đây là lần bảo vệ lại thứ ' + l.flags.gradTries + '.' : ''); },
    opts: [
      { k: 'doc_suc', l: 'Dốc sức làm, thức đêm chỉnh sửa theo góp ý thầy', ai: { w: 1.2, amb: 1, smart: 0.8 }, run: function (l, r, log) { defend(l, r, log, 0.08); fx(l, { hea: -1 }); } },
      { k: 'vua', l: 'Làm vừa sức, kịp hạn là được', ai: { w: 1 }, run: function (l, r, log) { defend(l, r, log, -0.03); } },
      { k: 'thue', l: 'Thuê người làm hộ đồ án / khóa luận', ai: { bad: 1.2, risk: 0.6, w: 0.3 }, run: function (l, r, log) { H.cash(l, -V(l, 8), 'Thuê làm đồ án'); fx(l, { karma: -4 }); if (ch(r, 0.35)) { log('Hội đồng hỏi vài câu là lộ: bạn không hiểu chính bài của mình. Bị đánh trượt, còn bị nhắc nhở kỷ luật.', 'bad'); fail(l, log); } else { log('Bảo vệ trót lọt bằng bài thuê người làm — tấm bằng có, nhưng kiến thức thì không.', 'neutral'); l.flags.gradOK = true; l.st.kno -= 3; } } }
    ]
  });
  E.TRIG.push({ id: 'bao_ve_tn', when: function (l, a) { return free(l) && studying(l) && l.schoolEnd != null && a + 1 >= l.schoolEnd && l.flags.gradTry !== a && !l.flags.gradOK; }, p: 1, cd: 1, rep: true });
  E.MAJOR && (E.MAJOR.bao_ve_tn = 1);
  function defend(l, r, log, b) {
    l.flags.gradTry = l.age;
    if (ch(r, passP(l) + b)) { l.flags.gradOK = true; log('Bảo vệ ' + thesisName(l) + ' thành công' + (l.st.kno >= 75 ? ', hội đồng chấm điểm xuất sắc' : '') + '!', 'good'); fx(l, { hap: 5 }); }
    else { log(pick(r, ['Bảo vệ ' + thesisName(l) + ' thất bại: hội đồng chỉ ra hàng loạt lỗi trong bài, phải làm lại.', 'Rớt tốt nghiệp — phần demo chạy lỗi ngay trước hội đồng.', 'Không qua được buổi bảo vệ, thầy hướng dẫn động viên: "Năm sau làm lại cho chắc."']), 'bad'); fail(l, log); }
  }
  function fail(l, log) { l.flags.gradTries = (l.flags.gradTries || 0) + 1; l.flags.gradTry = l.age; l.flags.gradOK = false; l.schoolEnd = l.age + 2; if (l.abroad && l.abroad.study) l.abroad.until = l.schoolEnd; fx(l, { hap: -6 }); if (l.mind) l.mind.stress = Math.min(100, l.mind.stress + 8); log('Phải học thêm một năm để bảo vệ lại' + (l.flags.gradTries >= 2 ? ' (lần thứ ' + (l.flags.gradTries + 1) + ')' : '') + '.', 'neutral'); }
  // engine gọi trước khi cho tốt nghiệp: chưa qua bảo vệ thì tự bảo vệ (người chơi không kịp chọn / chế độ tự động)
  E.gradFail = function (l, r, log, a) {
    if (!(l.school === 'uni' || (l.school === 'abroad' && l.abroad && l.abroad.study))) return false;
    if (l.flags.gradOK) { l.flags.gradOK = false; l.flags.gradTries = 0; return false; }
    if (l.flags.gradTry === a) return true; // vừa rớt trong năm, đã lùi hạn ra trường
    defend(l, r, log, 0); if (l.flags.gradOK) { l.flags.gradOK = false; l.flags.gradTries = 0; return false; } return true;
  };

  // ===================================================================
  // 4. THỰC TẬP CUỐI KHÓA (ngành khác)
  // ===================================================================
  var INTERN = {
    it: [['một công ty phần mềm lớn', 'dev'], ['một tập đoàn viễn thông', 'ky_su'], ['một startup công nghệ', 'dev']],
    eco: [['một ngân hàng', 'ngan_hang'], ['một công ty kiểm toán', 'ke_toan'], ['phòng marketing của một tập đoàn', 'marketing']],
    law: [['một văn phòng luật sư', 'luat_su'], ['tòa soạn một tờ báo', 'phong_vien']],
    edu: [['một trường THPT (thực tập sư phạm)', 'giao_vien']],
    art: [['một công ty thiết kế kiến trúc', 'kien_truc'], ['một agency quảng cáo', 'thiet_ke']]
  };
  SC('thuc_tap', {
    title: 'Thực tập cuối khóa', valid: function (l) { return studying(l) && !!INTERN[l.major]; },
    prep: function (l, r) { return { p: pick(r, INTERN[l.major]) }; },
    text: function (l, d) { return 'Năm cuối, bạn đi thực tập ở ' + d.p[0] + '. Thực tập tốt có thể được giữ lại làm việc sau khi ra trường.'; },
    opts: [
      { k: 'cham', l: 'Thực tập nghiêm túc, xung phong nhận việc', ai: { w: 1.2, amb: 1 }, run: function (l, r, log, d) { fx(l, { kno: 2 }); if (ch(r, 0.35 + l.st.kno / 300)) { l.flags.internJob = d.p[1]; log('Thực tập ở ' + d.p[0] + ' được đánh giá xuất sắc — trưởng phòng hứa giữ chỗ cho bạn sau khi tốt nghiệp.', 'good'); } else log('Thực tập chăm chỉ ở ' + d.p[0] + ', học được nhiều việc thực tế.', 'good'); } },
      { k: 'xin_dau', l: 'Xin dấu thực tập cho xong', ai: { w: 0.6 }, run: function (l, r, log, d) { log('Xin dấu xác nhận thực tập cho đủ thủ tục, cả kỳ chủ yếu ngồi photo tài liệu.', 'neutral'); } }
    ]
  });
  E.TRIG.push({ id: 'thuc_tap', when: function (l) { return free(l) && studying(l) && !!INTERN[l.major] && l.schoolEnd - l.age <= 2 && !l.flags.internDone; }, p: 0.6, cd: 1, max: 1 });
  var ta0 = E.DEC.thuc_tap.apply; E.DEC.thuc_tap.apply = function (l) { l.flags.internDone = true; return ta0.apply(this, arguments); };
  E.HOOKS.year.push(function (l, r, log) {
    if (!l.flags.internJob || studying(l) || l.edu < 5 || (l.abroad && l.abroad.study)) return;
    var j = l.flags.internJob; l.flags.internJob = null;
    if (l.job || !E.CAR[j]) return;
    l.flags.needJob = false; log('Nơi thực tập năm cuối giữ lời hứa, nhận bạn vào làm chính thức.', 'good'); E.startJob(l, j, r, log);
  });

  // ===================================================================
  // 5. SỐ LIỆU NGHỀ TỰ CHẠY TRONG NHẬT KÝ
  // ===================================================================
  // [đơn vị, [min, max] mỗi năm ở bậc thấp nhất, hệ số tăng mỗi bậc, câu kể (n năm nay, tổng), mốc]
  function surgeon(l) { var s = l.med && SPEC[l.med.spec]; return !!(s && s[2]); }
  var STAT = {
    // v4.0: số liệu theo thực tế bệnh viện công ở Việt Nam (khám ngoại trú 25–45 lượt / ngày, ~250 ngày làm việc; phẫu thuật viên 1–2 ca / ngày…)
    bac_si: function (l) {
      var sp = l.med && l.med.spec, k = rk(l), f = k === 0 ? 0.6 : k >= 5 ? 0.3 : k === 4 ? 0.75 : 1; // thực hành: làm dưới sự giám sát; trưởng khoa, giám đốc: nhiều việc quản lý
      var D = { noi: ['lượt khám', 6000, 10000, 'khám khoảng {n} lượt bệnh nhân'], nhi: ['lượt khám', 7000, 12000, 'khám khoảng {n} lượt bệnh nhi'], tim: ['lượt khám', 4000, 7000, 'khám khoảng {n} lượt bệnh nhân tim mạch'], dalieu: ['lượt khám', 8000, 14000, 'khám khoảng {n} lượt bệnh nhân da liễu'],
        tamthan: ['lượt khám', 2500, 5000, 'khám khoảng {n} lượt bệnh nhân'], ubuou: ['lượt khám', 3000, 6000, 'khám, điều trị khoảng {n} lượt bệnh nhân ung bướu'], yhct: ['lượt điều trị', 3000, 6000, 'châm cứu, bốc thuốc khoảng {n} lượt'],
        cdha: ['ca đọc phim', 8000, 14000, 'đọc khoảng {n} phim X-quang, CT, MRI'], san: ['ca đỡ đẻ, mổ lấy thai', 250, 450, 'đỡ đẻ và mổ lấy thai {n} ca'], ngoai: ['ca mổ', 180, 320, 'đứng mổ {n} ca'], chinhhinh: ['ca mổ', 220, 380, 'mổ {n} ca chấn thương chỉnh hình'],
        thammy: ['ca phẫu thuật', 150, 300, 'thực hiện {n} ca phẫu thuật thẩm mỹ'], gmhs: ['ca gây mê', 600, 1000, 'gây mê cho {n} ca mổ'], rhm: ['ca điều trị răng', 1200, 2500, 'điều trị khoảng {n} ca răng'] }[sp] || ['lượt khám', 5000, 9000, 'khám khoảng {n} lượt bệnh nhân'];
      var big = D[2] >= 2000;
      return [D[0], [D[1] * f, D[2] * f], 0, 'Năm nay ' + D[3], big ? [10000, 50000, 100000, 200000] : [500, 1000, 3000, 5000, 10000]];
    },
    phong_kham: function (l) { return ['lượt khám', [6000, 12000], 0.05, 'Phòng khám đón khoảng {n} lượt bệnh nhân năm nay', [10000, 50000, 100000]]; },
    nha_si: function () { return ['ca điều trị răng', [1200, 2500], 0.05, 'Năm nay điều trị khoảng {n} ca răng (trám, nhổ, niềng, implant)', [5000, 10000, 30000]]; },
    dieu_duong: function () { return ['ca trực đêm', [60, 100], 0, 'Năm nay trực {n} ca đêm, chăm sóc hàng trăm bệnh nhân', [500, 1000, 2000]]; },
    duoc_si: function () { return ['đơn thuốc', [12000, 25000], 0.05, 'Năm nay cấp phát khoảng {n} đơn thuốc', [50000, 100000, 300000]]; },
    giao_vien: function () { return ['học trò', [120, 250], 0, 'Năm học này dạy {n} học trò', [1000, 3000, 5000]]; },
    gv_mam_non: function () { return ['bé', [20, 35], 0.03, 'Năm học này chăm {n} bé', [200, 500]]; },
    giang_vien: function () { return ['sinh viên', [200, 500], 0.05, 'Năm nay dạy khoảng {n} sinh viên', [2000, 5000, 10000]]; },
    luat_su: function () { return ['vụ việc', [10, 30], 0.15, 'Năm nay nhận {n} vụ việc', [100, 300, 500]]; },
    cong_an: function () { return ['vụ việc', [20, 60], 0.08, 'Năm nay tham gia giải quyết {n} vụ việc', [200, 500, 1000]]; },
    tx_cn: function () { return ['chuyến xe', [4000, 7000], 0, 'Năm nay chạy khoảng {n} cuốc xe', [10000, 30000, 60000]]; },
    shipper: function () { return ['đơn hàng', [9000, 16000], 0, 'Năm nay giao khoảng {n} đơn hàng', [20000, 50000, 100000]]; },
    dau_bep: function () { return ['suất ăn', [25000, 60000], 0.05, 'Năm nay nấu khoảng {n} suất ăn', [100000, 300000]]; },
    ca_si: function () { return ['đêm diễn', [30, 90], 0.25, 'Năm nay chạy {n} show diễn', [300, 1000]]; },
    dev: function () { return ['dự án', [2, 6], 0.15, 'Năm nay tham gia {n} dự án phần mềm', [20, 50]]; },
    ky_su_xd: function () { return ['công trình', [1, 3], 0.15, 'Năm nay giám sát {n} công trình', [10, 30]]; },
    kien_truc: function () { return ['công trình', [2, 6], 0.15, 'Năm nay thiết kế {n} công trình', [20, 50, 100]]; },
    tho_toc: function () { return ['lượt khách', [2500, 5000], 0.1, 'Năm nay làm tóc cho khoảng {n} lượt khách', [20000, 50000]]; },
    nong: function (l) { return ['tấn lúa', [6, 14], 0, 'Vụ mùa năm nay thu khoảng {n} tấn lúa', [100, 300]]; },
    phong_vien: function () { return ['bài báo', [80, 200], 0.08, 'Năm nay viết khoảng {n} bài báo', [1000, 3000]]; },
    hdv: function () { return ['đoàn khách', [25, 50], 0.05, 'Năm nay dẫn {n} đoàn khách', [300, 800]]; },
    sale_bds: function () { return ['giao dịch', [2, 12], 0.15, 'Năm nay chốt {n} giao dịch nhà đất', [50, 100]]; }
  };
  E.JOB_STAT = STAT;
  E.HOOKS.year.push(function (l, r, log, a) {
    if (!l.job || !l.alive || !free(l)) return;
    var j = jid(l), f = STAT[j]; if (!f) return;
    var S = f(l), unit = S[0], lo = S[1][0], hi = S[1][1];
    var n = (lo + r() * (hi - lo)) * (1 + rk(l) * S[2]);
    if (n >= 50) n = Math.round(n / 10) * 10; else n = Math.round(n);
    var W = l.work || (l.work = {}), key = j + ':' + unit, before = W[key] || 0; W[key] = before + n;
    var mile = S[4].filter(function (m) { return before < m && W[key] >= m; }).pop();
    var show = { 'lượt khám': 'lượt bệnh nhân', 'ca điều trị răng': 'ca răng' }[unit] || unit;
    if (mile) { log('Cột mốc nghề nghiệp: tính đến nay đã ' + verbOf(j, unit) + ' ' + fmt(mile) + ' ' + show + '.', 'good'); H.mem(l, 'Cột mốc ' + fmt(mile) + ' ' + unit + ' trong đời làm nghề.', 3); }
    else if (before > 0 && r() < 0.25) log(S[3].replace('{n}', fmt(n)) + ' — tính đến nay đã ' + verbOf(j, unit) + ' ' + fmt(W[key]) + ' ' + show + '.', 'quiet');
  });
  function verbOf(j, unit) { return { 'ca mổ': 'mổ', 'lượt khám': 'khám', 'ca điều trị răng': 'điều trị', 'ca trực đêm': 'trực', 'lượt điều trị': 'điều trị', 'ca đọc phim': 'đọc', 'ca đỡ đẻ, mổ lấy thai': 'thực hiện', 'ca phẫu thuật': 'thực hiện', 'ca gây mê': 'gây mê', 'đơn thuốc': 'cấp', 'học trò': 'dạy', 'bé': 'chăm', 'sinh viên': 'dạy', 'vụ việc': 'giải quyết', 'chuyến xe': 'chạy', 'đơn hàng': 'giao', 'suất ăn': 'nấu', 'đêm diễn': 'diễn', 'dự án': 'làm', 'công trình': 'thực hiện', 'lượt khách': 'phục vụ', 'tấn lúa': 'thu hoạch', 'bài báo': 'viết', 'đoàn khách': 'dẫn', 'giao dịch': 'chốt' }[unit] || 'làm'; }
  // hồ sơ: số liệu nghề
  var pf0 = E.profile;
  if (pf0) E.profile = function (l) { var P = pf0.apply(this, arguments); var W = l.work || {}; P.workStats = Object.keys(W).map(function (k) { return fmt(W[k]) + ' ' + k.split(':')[1]; }); if (l.med && l.med.spec && SPEC[l.med.spec]) P.medSpec = SPEC[l.med.spec][0]; return P; };
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
