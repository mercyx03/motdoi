/* ===== js/jobs.js ===== */
/* Một Đời — v2.5: nghề mới & hướng đi logic giữa các nghề, sự kiện riêng theo từng nghề
   (thám tử, công an theo ngành, luật sư, thẩm phán, bác sĩ, giáo viên, chủ quán, tiệm điện thoại, cầm đồ, xây dựng, nhà báo, môi giới, ngân hàng),
   và ~1% sinh ra trong gia đình tài phiệt / chủ ngân hàng / chính trị — giàu có nhưng phải theo khuôn phép, từ chối sắp xếp thì bị cắt chu cấp. */
(function (G) {
  'use strict';
  var U = G.U, E = G.E, H = E.H, SC = E.SC, isVN = H.isVN;
  function T(id, when, p, cd) { E.TRIG.push({ id: id, when: when, p: p, cd: cd || 0 }); }
  function EV(c, p, run) { E.EVENTS.push({ c: c, p: p, run: run }); }
  function fx(l, o) { H.fx(l, o); }
  function cashB(l, x, why) { H.cash(l, x * l.base, why); }
  function mb(l, x) { return H.mb(l, x); }
  function mo(l, v) { return H.money(l, v); }
  function pick(r, a) { return U.pick(r, a); }
  function ch(r, p) { return r() < p; }
  function free(l) { return !(l.jailUntil != null && l.age < l.jailUntil) && !(l.abroad && l.abroad.trapped); }
  function jid(l) { return l.job ? E.resolveJob(l.job.id) : null; }
  function hasJob(l, ids) { return !!(l.job && ids.indexOf(jid(l)) >= 0); }
  function rank(l) { return l.job ? l.job.rank || 0 : 0; }
  function yr(l) { return l.birthYear + l.age; }
  function rep(l, d) { if (l.job) l.job.rep = U.clamp((l.job.rep || 50) + d, 0, 100); } // uy tín trong nghề: ảnh hưởng thăng tiến
  function cash(l) { return Math.max(0, l.money); }

  // ===================================================================
  // 1. NGHỀ MỚI (cùng cấu trúc với careers.js)
  // ===================================================================
  function addJob(id, t, vn, yrs, o) {
    E.CAR[id] = { id: id, t: t, vn: vn, yrs: yrs, cat: o.cat || 'other', sec: o.sec || 'inf', edu: o.edu || 0, major: o.major, majors: o.majors, soft: o.soft,
      talent: o.talent, sex: o.sex, haz: o.haz, crime: o.crime, fame: o.fame, sigma: o.sigma || 0.12, fail: o.fail || 0, hidden: o.hidden, w: o.w || 1,
      rural: o.rural, coast: o.coast, vnOnly: o.vn, ladder: o.ladder, skillRank: o.skillRank, maxAge: o.maxAge, prod: o.prod, promo: o.promo, loss: o.loss, tag: o.tag, owner: o.owner };
  }
  addJob('chu_quan_an', ['phụ quán', 'chủ quán ăn', 'chủ chuỗi quán ăn'], [6, 18, 60], [3, 6], { cat: 'biz', sec: 'inf', edu: 1, sigma: 0.45, fail: 0.03, w: 0.6, prod: ['quán phở', 'quán cơm tấm', 'quán bún bò', 'quán lẩu', 'quán nướng', 'quán bánh mì'] });
  addJob('chu_nha_hang', ['quản lý nhà hàng', 'chủ nhà hàng', 'chủ chuỗi nhà hàng'], [15, 45, 150], [4, 6], { cat: 'biz', sec: 'inf', edu: 2, sigma: 0.5, fail: 0.04, w: 0.25, prod: ['nhà hàng hải sản', 'nhà hàng tiệc cưới', 'nhà hàng lẩu nướng', 'nhà hàng chay', 'nhà hàng Nhật'] });
  addJob('tiem_dt', ['nhân viên bán điện thoại', 'kỹ thuật viên sửa điện thoại', 'chủ tiệm điện thoại', 'chủ chuỗi cửa hàng điện thoại'], [7, 12, 30, 100], [2, 4, 6], { cat: 'biz', sec: 'inf', edu: 1, sigma: 0.4, w: 0.6 });
  addJob('tham_tu', ['cộng tác viên văn phòng thám tử', 'thám tử tư', 'chủ văn phòng thám tử'], [7, 14, 35], [3, 6], { cat: 'other', sec: 'inf', edu: 3, sigma: 0.5, w: 0.25, vn: 1 });
  addJob('cong_chung', ['thư ký nghiệp vụ công chứng', 'công chứng viên', 'trưởng văn phòng công chứng'], [9, 30, 70], [3, 6], { cat: 'office', sec: 'formal', edu: 5, major: 'law', w: 0.4 });
  addJob('phong_kham', ['chủ phòng khám tư', 'chủ chuỗi phòng khám'], [60, 200], [6], { cat: 'med', sec: 'inf', edu: 5, major: 'med', hidden: 1, sigma: 0.4, fail: 0.02 });
  addJob('chu_dau_tu', ['chủ đầu tư dự án nhỏ', 'chủ đầu tư bất động sản', 'chủ tịch tập đoàn bất động sản'], [40, 200, 1500], [4, 8], { cat: 'biz', sec: 'inf', edu: 2, hidden: 1, sigma: 0.9, fail: 0.07, owner: 1 });
  // --- dành cho gia đình siêu giàu (ẩn, chỉ vào được qua gia đình hoặc đi lên từ dưới) ---
  addJob('tai_phiet', ['thành viên ban điều hành tập đoàn', 'phó tổng giám đốc tập đoàn', 'tổng giám đốc tập đoàn', 'chủ tịch tập đoàn'], [200, 800, 3000, 20000], [3, 5, 6], { cat: 'biz', sec: 'inf', edu: 5, hidden: 1, sigma: 0.35, owner: 1, prod: ['tập đoàn bất động sản', 'tập đoàn bán lẻ', 'tập đoàn công nghiệp', 'tập đoàn hàng không', 'tập đoàn thép', 'tập đoàn thực phẩm'] });
  addJob('ngan_hang_cao', ['giám đốc khối ngân hàng', 'phó tổng giám đốc ngân hàng', 'tổng giám đốc ngân hàng', 'chủ tịch HĐQT ngân hàng'], [150, 350, 900, 2500], [3, 5, 6], { cat: 'office', sec: 'formal', edu: 5, major: 'eco', hidden: 1, sigma: 0.2, owner: 1 });
  addJob('chinh_tri', ['chuyên viên văn phòng tỉnh ủy', 'phó bí thư huyện ủy', 'bí thư huyện ủy', 'phó chủ tịch UBND tỉnh', 'chủ tịch UBND tỉnh', 'bí thư tỉnh ủy', 'ủy viên Trung ương Đảng'], [12, 18, 22, 30, 36, 42, 55], [3, 4, 5, 5, 5, 6], { cat: 'state', sec: 'formal', edu: 5, hidden: 1, vn: 1, promo: 0.12, loss: 0.002 });
  addJob('chinh_khach', ['trợ lý nghị sĩ', 'ủy viên hội đồng thành phố', 'thị trưởng', 'nghị sĩ quốc hội', 'bộ trưởng'], [12, 20, 35, 45, 60], [3, 5, 6, 6], { cat: 'state', sec: 'formal', edu: 5, hidden: 1, promo: 0.12, loss: 0.01 });
  E.PARENT_PAY['chủ tịch tập đoàn'] = 6000; E.PARENT_PAY['phó chủ tịch tập đoàn'] = 2500;
  E.PARENT_PAY['chủ tịch HĐQT ngân hàng'] = 2500; E.PARENT_PAY['tổng giám đốc ngân hàng'] = 900;
  E.PARENT_PAY['bí thư tỉnh ủy'] = 45; E.PARENT_PAY['phó chủ tịch UBND tỉnh'] = 32; E.PARENT_PAY['bộ trưởng'] = 60; E.PARENT_PAY['nghị sĩ quốc hội'] = 45;

  // v2.9: nhóm nghề Pháp luật & tòa án — gom thẩm phán, kiểm sát viên (công tố viên), luật sư, công chứng; thêm điều tra viên, chấp hành viên, thừa phát lại
  E.CAT.law = 'Pháp luật & tòa án';
  addJob('dieu_tra_vien', ['cán bộ điều tra', 'điều tra viên sơ cấp', 'điều tra viên trung cấp', 'điều tra viên cao cấp'], [9, 13, 18, 26], [3, 6, 7], { cat: 'law', sec: 'formal', edu: 5, major: 'law', promo: 0.2, loss: 0.002, w: 0.5 });
  addJob('chap_hanh_vien', ['thẩm tra viên thi hành án', 'chấp hành viên sơ cấp', 'chấp hành viên trung cấp', 'chấp hành viên cao cấp'], [8, 12, 16, 22], [3, 6, 7], { cat: 'law', sec: 'formal', edu: 5, major: 'law', promo: 0.2, loss: 0.002, w: 0.4 });
  addJob('thua_phat_lai', ['thư ký nghiệp vụ thừa phát lại', 'thừa phát lại', 'trưởng văn phòng thừa phát lại'], [8, 25, 60], [3, 6], { cat: 'law', sec: 'inf', edu: 5, major: 'law', sigma: 0.35, w: 0.3 });
  addJob('tro_giup_phap_ly', ['trợ giúp viên pháp lý', 'trợ giúp viên pháp lý hạng II', 'giám đốc trung tâm trợ giúp pháp lý'], [9, 12, 18], [5, 7], { cat: 'law', sec: 'formal', edu: 5, major: 'law', promo: 0.2, loss: 0.003, w: 0.3 });
  ['luat_su', 'tham_phan', 'kiem_sat', 'cong_chung'].forEach(function (id) { if (E.CAR[id]) E.CAR[id].cat = 'law'; });
  if (E.CAR.kiem_sat) E.CAR.kiem_sat.t = ['kiểm tra viên viện kiểm sát', 'kiểm sát viên (công tố viên) sơ cấp', 'kiểm sát viên (công tố viên) trung cấp', 'kiểm sát viên (công tố viên) cao cấp', 'viện trưởng VKSND tỉnh'];
  // công an theo ngành
  var POLICE_BR = { gt: 'Cảnh sát giao thông', hs: 'Cảnh sát hình sự', mt: 'Cảnh sát điều tra tội phạm ma túy', kt: 'Cảnh sát kinh tế', cd: 'Cảnh sát cơ động', kv: 'Công an khu vực' };
  E.POLICE_BR = POLICE_BR;
  function policeBr(l, r) {
    if (!hasJob(l, ['cong_an'])) return null;
    if (!l.job.br) l.job.br = U.wkey(r || H.rf(l), 'gt:0.25,hs:0.2,mt:0.12,kt:0.13,cd:0.1,kv:0.2');
    return l.job.br;
  }

  // ===================================================================
  // 2. HƯỚNG ĐI LOGIC GIỮA CÁC NGHỀ: làm lâu, có vốn → mở riêng / chuyển ngành gần
  // [nghề đích, bậc vào, vốn (× thu nhập cơ sở), điều kiện bậc tối thiểu, lời mời]
  // ===================================================================
  var PATHS = {
    phuc_vu: [['chu_quan_an', 1, 0.8, 1, 'Làm quản lý quán bao năm, bạn đã thuộc lòng nghề. Hay là ra mở quán ăn của riêng mình?']],
    dau_bep: [['chu_quan_an', 1, 0.8, 1, 'Tay nghề bếp đã vững. Mở một quán ăn nhỏ của riêng mình?'], ['chu_nha_hang', 1, 3, 2, 'Làm bếp trưởng nhiều năm, có người rủ góp vốn mở nhà hàng, bạn đứng bếp và làm chủ.']],
    chu_quan_an: [['chu_nha_hang', 1, 3, 1, 'Quán ăn đông khách quanh năm. Nâng lên thành nhà hàng khang trang?']],
    barista: [['kd_quan', 0, 0.8, 1, 'Pha chế lâu năm, khách quen nhiều. Mở quán cà phê của riêng mình?']],
    tiem_dt: [['tiem_dt', 2, 1, 1, 'Sửa điện thoại giỏi, khách tìm đến tận nơi. Thuê mặt bằng mở tiệm riêng?']],
    tho_sua_xe: [['tho_sua_xe', 2, 0.5, 1, 'Tay nghề đã vững. Thuê mặt bằng mở tiệm sửa xe riêng?']],
    cam_do: [['cam_do', 1, 1.5, 0, 'Làm ở tiệm cầm đồ lâu, bạn hiểu hết cái nghề. Tự mở một tiệm?']],
    tiem_vang: [['tiem_vang', 1, 4, 0, 'Đã rành nghề kim hoàn và có mối quen. Mở tiệm vàng riêng?']],
    cong_an: [['tham_tu', 1, 0.3, 3, 'Một văn phòng thám tử tư mời bạn về với mức thu nhập gấp mấy lần lương ngành, nhờ kinh nghiệm điều tra.']],
    tham_phan: [['luat_su', 2, 0.2, 2, 'Một hãng luật lớn mời bạn rời tòa án về làm luật sư thành viên.']],
    kiem_sat: [['luat_su', 2, 0.2, 2, 'Một hãng luật lớn mời bạn rời viện kiểm sát về làm luật sư thành viên.']],
    luat_su: [['cong_chung', 1, 0.5, 1, 'Có thể chuyển sang làm công chứng viên — đều đặn, ít căng thẳng hơn.']],
    bac_si: [['phong_kham', 0, 3, 2, 'Có tiếng trong nghề, bệnh nhân tìm đến tận nhà. Mở phòng khám tư?']],
    nha_si: [['nha_si', 2, 2, 1, 'Mở phòng khám nha khoa của riêng mình?']],
    giao_vien: [['gia_su', 1, 0.5, 1, 'Nhiều phụ huynh xin gửi con học thêm. Mở trung tâm dạy thêm?']],
    ky_su_xd: [['phu_ho', 3, 1, 1, 'Quen biết nhiều chủ đầu tư. Ra lập đội thầu xây dựng riêng?']],
    sale_bds: [['chu_dau_tu', 0, 5, 1, 'Có vốn và có mối, bạn tính tự gom đất làm chủ đầu tư dự án nhỏ.']],
    ngan_hang: [['ngan_hang_cao', 0, 0, 3, 'Ngân hàng đề bạt bạn lên cấp điều hành khối.']],
    dev: [['kd_tu_do', 1, 1, 2, 'Mấy đồng nghiệp rủ ra làm startup công nghệ, bạn làm giám đốc kỹ thuật kiêm cổ đông.']],
    shipper: [['kd_online', 0, 0.2, 0, 'Giao hàng lâu, bạn hiểu dân mua online thích gì. Tự mở shop online?']],
    tx_cn: [['tai_xe_tai', 1, 0.1, 0, 'Có người giới thiệu chỗ lái xe tải đường dài, thu nhập khá hơn.']],
    kd_tu_do: [['chu_dau_tu', 0, 8, 2, 'Công ty làm ăn tốt, bạn tính lấn sân đầu tư bất động sản.']]
  };
  function pathFor(l) {
    var ps = PATHS[jid(l)]; if (!ps) return null;
    return ps.filter(function (p) { return rank(l) >= p[3] && !(p[0] === jid(l) && rank(l) >= p[1]); })[0] || null;
  }
  SC('chuyen_huong', {
    title: 'Ngã rẽ sự nghiệp', prep: function (l) { var p = pathFor(l); return p ? { to: p[0], rk: p[1], cost: p[2], t: p[4] } : null; },
    valid: function (l) { return !!(l.job && pathFor(l)); },
    text: function (l, d) { return d.t + (d.cost ? ' Cần khoảng ' + mb(l, d.cost) + ' vốn ban đầu, hiện bạn có ' + mo(l, l.money) + '.' : ''); },
    opts: [
      { k: 'go', l: function (l, d) { return 'Chuyển sang làm ' + E.CAR[d.to].t[Math.min(d.rk, E.CAR[d.to].t.length - 1)]; }, req: function (l, d) { return cash(l) >= d.cost * l.base * 0.6; }, ai: { w: 1, amb: 1, risk: 0.5 },
        run: function (l, r, log, d) {
          var from = E.jobTitle(l);
          if (d.cost) cashB(l, -d.cost, 'Vốn chuyển hướng sự nghiệp');
          if (d.to === jid(l)) { l.job.rank = d.rk; l.job.yrs = 0; }
          else { E.startJob(l, d.to, r, log, true); l.job.rank = Math.min(d.rk, E.CAR[d.to].t.length - 1); }
          log('Rời vị trí ' + from + ', chuyển sang làm ' + E.jobTitle(l) + '.', 'big'); fx(l, { hap: 5 });
          H.mem(l, 'Ngày quyết định rẽ hướng: từ ' + from + ' thành ' + E.jobTitle(l) + '.', 4);
        } },
      { k: 'stay', l: 'Thôi, cứ làm việc đang làm', ai: { w: 1.2 }, run: function (l, r, log) { log('Quyết định gắn bó với công việc hiện tại.', 'neutral'); } }
    ]
  });
  T('chuyen_huong', function (l, a) { return l.job && l.job.yrs >= 3 && a >= 24 && a <= 58 && !!pathFor(l) && free(l); }, 0.08, 6);

  // ===================================================================
  // 3. SỰ KIỆN RIÊNG THEO NGHỀ
  // ===================================================================
  // ---- Thám tử tư: ở Việt Nam phần lớn là vụ theo dõi ngoại tình, thù lao vài chục triệu một vụ ----
  var TT_CASES = [
    { w: 6, t: 'Một bà chủ chuỗi spa nghi chồng ngoại tình, muốn có ảnh và địa chỉ "nhà nhỏ".', fee: 0.4 },
    { w: 3, t: 'Một ông giám đốc muốn biết vợ trẻ đi đâu mỗi tối thứ Năm.', fee: 0.5 },
    { w: 2, t: 'Một doanh nghiệp thuê xác minh đối tác sắp ký hợp đồng chục tỷ có phải "công ty ma".', fee: 0.6 },
    { w: 1.5, t: 'Gia đình nhờ tìm cô con gái bỏ nhà đi theo người yêu quen trên mạng.', fee: 0.25 },
    { w: 1, t: 'Một người mẹ nghi con trai mới lớn dính vào đường dây cá độ.', fee: 0.2 },
    { w: 0.4, t: 'Gia đình nạn nhân không tin kết luận "tự tử", nhờ âm thầm tìm hiểu thêm.', fee: 0.8 }
  ];
  SC('tt_vu', {
    title: 'Vụ việc mới', prep: function (l, r) { var c = U.wpick(r, TT_CASES, function (x) { return x.w; }); return { t: c.t, fee: c.fee * (1 + rank(l) * 0.4) }; },
    valid: function (l) { return hasJob(l, ['tham_tu']); },
    text: function (l, d) { return d.t + ' Thù lao khoảng ' + mb(l, d.fee) + ' nếu xong việc.'; },
    opts: [
      { k: 'careful', l: 'Theo dõi kiên nhẫn, đúng luật', h: 'Chậm, an toàn', ai: { w: 1.4, smart: 1 }, run: function (l, r, log, d) {
        var p = U.clamp(0.45 + (l.st.kno - 50) / 150 + rank(l) * 0.08 + ((l.job.rep || 50) - 50) / 200, 0.2, 0.9);
        if (ch(r, p)) { cashB(l, d.fee, 'Thù lao vụ thám tử'); rep(l, 5); log(ch(r, 0.3) ? 'Hoàn thành xuất sắc: đủ hình ảnh, giờ giấc, địa chỉ. Khách hàng thưởng thêm và giới thiệu bạn bè.' : 'Xong vụ việc, giao đủ bằng chứng cho khách hàng.', 'good'); if (ch(r, 0.3)) cashB(l, d.fee * 0.5, 'Thưởng thêm từ khách'); fx(l, { hap: 4 }); }
        else { rep(l, -4); log('Bám theo cả tháng vẫn không có kết quả. Khách hàng chỉ trả phí cơ bản.', 'neutral'); cashB(l, d.fee * 0.2, 'Phí cơ bản vụ thám tử'); }
      } },
      { k: 'gps', l: 'Lén gắn định vị, cài phần mềm theo dõi', h: 'Nhanh nhưng phạm luật', ai: { risk: 1, bad: 0.8 }, run: function (l, r, log, d) {
        fx(l, { karma: -4 });
        if (ch(r, 0.2)) { log('Đối tượng phát hiện thiết bị định vị, báo công an. Bạn bị phạt nặng vì xâm phạm bí mật đời tư.', 'bad'); cashB(l, -0.3, 'Phạt xâm phạm đời tư'); rep(l, -15); if (ch(r, 0.25)) H.sched(l, 'bi_bat', 0, { why: 'xâm phạm bí mật đời tư', sev: 1 }); }
        else { cashB(l, d.fee, 'Thù lao vụ thám tử'); rep(l, 2); log('Có bằng chứng chỉ sau một tuần. Khách hài lòng — miễn là không ai biết bạn làm cách nào.', 'neutral'); }
      } },
      { k: 'caught', l: 'Bám sát tận nơi để chụp cho rõ', h: 'Ảnh đẹp, dễ bị lộ', ai: { risk: 1.2 }, run: function (l, r, log, d) {
        if (ch(r, 0.3)) { log('Bị phát hiện khi đang chụp ảnh. Đối tượng gọi người đến đánh, đập vỡ máy ảnh.', 'bad'); fx(l, { hea: -10, hap: -5 }); cashB(l, -0.1, 'Máy ảnh bị đập vỡ'); rep(l, -6); }
        else { cashB(l, d.fee * 1.3, 'Thù lao vụ thám tử'); rep(l, 6); log('Ảnh rõ từng khuôn mặt. Khách hàng trả thêm vì bằng chứng "không thể chối cãi".', 'good'); }
      } },
      { k: 'no', l: 'Từ chối vụ này', ai: { w: 0.4 }, run: function (l, r, log) { log('Từ chối vụ việc — có những chuyện không nên dính vào.', 'neutral'); } }
    ]
  });
  T('tt_vu', function (l) { return hasJob(l, ['tham_tu']) && free(l); }, 0.55, 1);

  // ---- Công an theo ngành ----
  var CA_CASES = {
    gt: [{ t: 'Đang làm nhiệm vụ ở chốt, bạn dừng một chiếc xe sang chạy ẩu. Tài xế nồng nặc mùi rượu, rút điện thoại: "Anh biết tôi là ai không?"', danger: 0, bribe: 0.15 },
      { t: 'Ca trực đêm, một nhóm thanh niên đua xe lạng lách, lao thẳng vào chốt khi bị yêu cầu dừng.', danger: 0.04, bribe: 0 },
      { t: 'Một người quen của sếp vi phạm nồng độ cồn, gọi điện "nhờ anh em linh động".', danger: 0, bribe: 0.05 }],
    hs: [{ t: 'Chuyên án truy bắt nghi phạm giết người đang lẩn trốn trong một khu trọ.', danger: 0.05, bribe: 0 },
      { t: 'Băng cướp giật dùng hung khí hoạt động liên tỉnh, cả đội phải phục kích nhiều đêm liền.', danger: 0.04, bribe: 0 },
      { t: 'Gia đình nghi phạm một vụ cố ý gây thương tích tìm đến, đặt phong bì lên bàn xin "nhẹ tay".', danger: 0, bribe: 0.4 }],
    mt: [{ t: 'Chuyên án triệt phá đường dây ma túy xuyên biên giới, đối tượng có súng và sẵn sàng chống trả.', danger: 0.08, bribe: 0 },
      { t: 'Một trùm ma túy cho người nhắn: chỉ cần bạn "nhắm mắt" một đêm, tiền sẽ có ngay.', danger: 0.02, bribe: 2 }],
    kt: [{ t: 'Chuyên án đường dây lừa đảo việc nhẹ lương cao đưa người sang Campuchia. Cần phối hợp giải cứu nạn nhân.', danger: 0.02, bribe: 0 },
      { t: 'Doanh nghiệp làm hàng giả cỡ lớn bị phát hiện, chủ doanh nghiệp đề nghị "lo" cho cả đội.', danger: 0, bribe: 1 },
      { t: 'Đường dây lừa đảo đầu tư tiền ảo chiếm đoạt hàng trăm tỷ của người dân.', danger: 0, bribe: 0 }],
    cd: [{ t: 'Được điều động giữ an ninh trận chung kết bóng đá, cổ động viên quá khích đốt pháo sáng.', danger: 0.01, bribe: 0 },
      { t: 'Tham gia cứu hộ người dân trong trận lũ lịch sử.', danger: 0.03, bribe: 0 }],
    kv: [{ t: 'Hai nhà hàng xóm trong khu vực xô xát vì tranh chấp lối đi, gọi bạn đến giải quyết.', danger: 0.005, bribe: 0 },
      { t: 'Phát hiện một ổ nhóm cho vay nặng lãi đang hoạt động trong khu dân cư.', danger: 0.02, bribe: 0.3 }]
  };
  SC('ca_chuyen_an', {
    title: function (l) { return (POLICE_BR[policeBr(l)] || 'Công an') + ' · nhiệm vụ mới'; },
    prep: function (l, r) { var b = policeBr(l, r); if (!b) return null; var c = pick(r, CA_CASES[b]); return { b: b, t: c.t, danger: c.danger, bribe: c.bribe }; },
    valid: function (l) { return hasJob(l, ['cong_an']) && isVN(l); },
    text: function (l, d) { return d.t; },
    opts: [
      { k: 'law', l: 'Làm đúng quy trình, đúng pháp luật', ai: { w: 1.5 }, run: function (l, r, log, d) {
        if (d.danger && ch(r, d.danger * 0.5)) { H.kill(l, 'hy sinh khi làm nhiệm vụ', log, true); return; }
        rep(l, 6); fx(l, { karma: 3, hap: 3 });
        log(d.b === 'gt' ? 'Lập biên bản, tạm giữ phương tiện đúng quy định. Clip người vi phạm "dọa" bạn lan truyền, dân mạng khen bạn cứng rắn.' : d.bribe ? 'Từ chối phong bì, làm hồ sơ đúng quy định.' : 'Phối hợp đồng đội hoàn thành nhiệm vụ, được đơn vị biểu dương.', 'good');
        if (ch(r, 0.25)) { log('Được tặng bằng khen vì thành tích xuất sắc trong chuyên án.', 'good'); H.mem(l, 'Ngày nhận bằng khen trước toàn đơn vị.', 3); }
      } },
      { k: 'brave', l: 'Xông lên đi đầu', req: function (l, d) { return d.danger > 0; }, h: 'Lập công lớn, nguy hiểm tính mạng', ai: { risk: 1.2, w: 0.6 }, run: function (l, r, log, d) {
        if (ch(r, d.danger * 1.5)) { H.kill(l, 'hy sinh khi làm nhiệm vụ', log, true); return; }
        if (ch(r, 0.3)) { log('Bị đối tượng chống trả, bị thương nặng phải nằm viện nhiều tuần.', 'bad'); fx(l, { hea: -15 }); }
        rep(l, 12); log('Trực tiếp khống chế đối tượng, phá thành công chuyên án. Được đề nghị tặng Huân chương Chiến công.', 'big'); fx(l, { hap: 8, karma: 4 });
        if (l.job.rank < E.CAR.cong_an.t.length - 1 && ch(r, 0.4) && l.job.yrs >= 1 && (l.job.rank < 7 || !E.canAdvance || E.canAdvance(l, E.CAR.cong_an, false))) { l.job.rank++; l.job.yrs = 0; log('Được thăng quân hàm vượt cấp lên ' + E.CAR.cong_an.t[l.job.rank] + ' nhờ thành tích.', 'big'); }
        H.mem(l, 'Chuyên án năm ' + yr(l) + ' — lần bạn đi đầu đối mặt với tội phạm.', 6);
        if (d.b === 'mt' || d.b === 'hs') l.flags.revenge = (l.flags.revenge || 0) + 1;
      } },
      { k: 'bribe', l: 'Nhận tiền, cho qua', req: function (l, d) { return d.bribe > 0; }, h: function (l, d) { return 'Khoảng ' + mb(l, d.bribe) + ' · có thể bị phát hiện, đi tù'; }, ai: { bad: 1.5, w: 0.5 }, run: function (l, r, log, d) {
        cashB(l, d.bribe, 'Tiền "bôi trơn"'); fx(l, { karma: -12 }); l.flags.dirty = (l.flags.dirty || 0) + 1;
        log('Nhận tiền và cho qua. Đêm đó bạn trằn trọc mãi.', 'bad');
        if (ch(r, 0.15 + d.bribe * 0.08)) { log('Camera và tin nhắn bị thanh tra thu thập. Bạn bị đình chỉ công tác, khởi tố tội nhận hối lộ.', 'bad'); l.job = null; l.flags.needJob = true; H.sched(l, 'bi_bat', 0, { why: 'nhận hối lộ', sev: 2 }); }
      } },
      { k: 'pass', l: 'Báo cáo cấp trên, chờ chỉ đạo', ai: { w: 0.8 }, run: function (l, r, log) { rep(l, 1); log('Báo cáo lên trên, làm theo chỉ đạo. An toàn, nhưng không ai nhớ tên bạn.', 'neutral'); } }
    ]
  });
  T('ca_chuyen_an', function (l) { return hasJob(l, ['cong_an']) && isVN(l) && free(l); }, 0.35, 1);
  // bị trả thù sau những chuyên án lớn
  SC('ca_tra_thu', {
    title: 'Lời đe dọa', valid: function (l) { return hasJob(l, ['cong_an']) && (l.flags.revenge || 0) > 0; },
    text: 'Đàn em của tên trùm bị bạn bắt cho người theo dõi nhà bạn, nhắn tin: "Mày có vợ con mà."',
    opts: [
      { k: 'guard', l: 'Báo đơn vị, bố trí bảo vệ gia đình', ai: { w: 1.4 }, run: function (l, r, log) { l.flags.revenge = 0; if (ch(r, 0.04)) { H.kill(l, 'bị tội phạm trả thù', log, true); return; } log('Đơn vị bố trí lực lượng bảo vệ, bắt được kẻ theo dõi.', 'good'); fx(l, { hap: -3 }); } },
      { k: 'move', l: 'Xin chuyển công tác sang địa bàn khác', ai: { w: 0.8 }, run: function (l, r, log) { l.flags.revenge = 0; l.job.br = 'kv'; log('Chuyển công tác về làm công an khu vực ở địa bàn khác, cả nhà dọn đi.', 'neutral'); fx(l, { hap: -4 }); } },
      { k: 'ignore', l: 'Mặc kệ, không sợ', ai: { risk: 1.3 }, run: function (l, r, log) { if (ch(r, 0.12)) { H.kill(l, 'bị tội phạm trả thù', log, true); return; } log('Không có chuyện gì xảy ra… lần này.', 'neutral'); fx(l, { hap: -2 }); } }
    ]
  });
  T('ca_tra_thu', function (l) { return hasJob(l, ['cong_an']) && (l.flags.revenge || 0) > 0 && free(l); }, 0.25);

  // ---- Luật sư ----
  SC('ls_vu_an', {
    title: 'Hồ sơ vụ án mới', prep: function (l, r) { return pick(r, [
      { t: 'Một đại gia nhờ bạn đại diện trong vụ ly hôn tranh chấp tài sản hàng trăm tỷ.', fee: 1, kind: 'civ' },
      { t: 'Một doanh nghiệp bị kiện vi phạm hợp đồng, cần luật sư tranh tụng.', fee: 0.6, kind: 'civ' },
      { t: 'Một thiếu niên nghèo bị cáo buộc cướp tài sản, gia đình không có tiền thuê luật sư.', fee: 0, kind: 'free' },
      { t: 'Con trai một ông chủ lớn gây tai nạn chết người, gia đình muốn "bằng mọi giá" được hưởng án treo.', fee: 1.5, kind: 'dirty' }
    ]); },
    valid: function (l) { return hasJob(l, ['luat_su']) && l.job.rank >= 1; },
    text: function (l, d) { return d.t + (d.fee ? ' Thù lao khoảng ' + mb(l, d.fee * (1 + rank(l) * 0.3)) + '.' : ' Trợ giúp pháp lý miễn phí.'); },
    opts: [
      { k: 'fight', l: 'Nhận vụ, chuẩn bị hồ sơ thật kỹ', ai: { w: 1.4, smart: 1 }, run: function (l, r, log, d) {
        var p = U.clamp(0.4 + (l.st.kno - 50) / 120 + rank(l) * 0.07 + ((l.job.rep || 50) - 50) / 150, 0.15, 0.9);
        if (ch(r, p)) { cashB(l, d.fee * (1 + rank(l) * 0.3), 'Thù lao luật sư'); rep(l, 8); log(d.kind === 'free' ? 'Chứng minh được thân chủ bị oan, tòa tuyên vô tội. Mẹ cậu bé quỳ xuống cảm ơn bạn.' : 'Thắng kiện! Tên bạn bắt đầu được nhắc đến trong giới luật.', 'good'); fx(l, { hap: 6, karma: d.kind === 'free' ? 8 : 1 }); if (d.kind === 'free') H.mem(l, 'Phiên tòa minh oan cho cậu bé nghèo.', 5); }
        else { cashB(l, d.fee * 0.3, 'Phí luật sư'); rep(l, -4); log('Thua kiện. Thân chủ thất vọng, bạn mất mấy đêm xem lại hồ sơ.', 'bad'); fx(l, { hap: -4 }); }
      } },
      { k: 'fix', l: 'Nhận tiền "lo" cho thân chủ qua quen biết', req: function (l, d) { return d.kind === 'dirty'; }, h: 'Tiền lớn, có thể bị tước thẻ luật sư', ai: { bad: 1.4 }, run: function (l, r, log, d) {
        fx(l, { karma: -10 }); l.flags.dirty = (l.flags.dirty || 0) + 1;
        if (ch(r, 0.25)) { log('Đường dây "chạy án" bị phanh phui. Bạn bị tước thẻ luật sư và khởi tố tội môi giới hối lộ.', 'bad'); l.job = null; l.flags.needJob = true; H.sched(l, 'bi_bat', 0, { why: 'môi giới hối lộ', sev: 2 }); }
        else { cashB(l, d.fee * 3, 'Tiền "lo" vụ án'); log('Vụ án được "xử nhẹ". Tiền về túi, nhưng gia đình nạn nhân khóc ngất ngoài hành lang tòa.', 'bad'); }
      } },
      { k: 'no', l: 'Từ chối vụ này', ai: { w: 0.5 }, run: function (l, r, log) { log('Từ chối nhận vụ án.', 'neutral'); } }
    ]
  });
  T('ls_vu_an', function (l) { return hasJob(l, ['luat_su']) && l.job.rank >= 1 && free(l); }, 0.4, 1);

  // ---- Thẩm phán / kiểm sát viên: "chạy án" ----
  SC('tp_chay_an', {
    title: 'Phong bì trước phiên tòa', prep: function (l, r) { return { x: pick(r, [0.5, 1, 3]) * (1 + rank(l) * 0.5) }; },
    valid: function (l) { return hasJob(l, ['tham_phan', 'kiem_sat']) && l.job.rank >= 1; },
    text: function (l, d) { return 'Trước phiên xử một vụ án kinh tế, người nhà bị cáo tìm đến tận nhà, để lại túi quà ' + mb(l, d.x) + ' cùng lời nhắn "mong được xem xét".'; },
    opts: [
      { k: 'refuse', l: 'Trả lại, xử đúng pháp luật', ai: { w: 1.5 }, run: function (l, r, log) { rep(l, 6); fx(l, { karma: 8, hap: 2 }); log('Gửi trả túi quà, xét xử đúng người đúng tội.', 'good'); if (ch(r, 0.2)) H.mem(l, 'Lần từ chối túi tiền trước phiên tòa — lương tâm thanh thản.', 3); } },
      { k: 'report', l: 'Báo cáo lên cấp trên về hành vi đưa hối lộ', ai: { w: 0.8, smart: 1 }, run: function (l, r, log) { rep(l, 10); fx(l, { karma: 10 }); log('Báo cáo hành vi đưa hối lộ, người đưa bị xử lý. Bạn được đánh giá cao về liêm chính.', 'good'); } },
      { k: 'take', l: 'Nhận, "nương tay" một chút', ai: { bad: 1.6 }, run: function (l, r, log, d) {
        cashB(l, d.x, 'Tiền "chạy án"'); fx(l, { karma: -15 }); l.flags.dirty = (l.flags.dirty || 0) + 1;
        if (ch(r, 0.2)) { log('Bản án bị kháng nghị, thanh tra vào cuộc. Bạn bị khởi tố tội nhận hối lộ.', 'bad'); l.job = null; l.flags.needJob = true; H.sched(l, 'bi_bat', 0, { why: 'nhận hối lộ', sev: 3 }); }
        else log('Bản án "nhẹ nhàng" hơn đề nghị. Không ai biết vì sao.', 'bad');
      } }
    ]
  });
  T('tp_chay_an', function (l) { return hasJob(l, ['tham_phan', 'kiem_sat']) && l.job.rank >= 1 && free(l); }, 0.12, 2);

  // ---- Kiểm sát viên (công tố viên): phát hiện oan sai ----
  SC('ks_oan_sai', {
    title: 'Hồ sơ có dấu hiệu oan sai', valid: function (l) { return hasJob(l, ['kiem_sat']) && rank(l) >= 1; },
    text: 'Đọc lại hồ sơ một vụ cướp tài sản, bạn thấy lời khai mâu thuẫn, bị cáo khai bị ép cung. Cơ quan điều tra muốn truy tố cho kịp tiến độ.',
    opts: [
      { k: 'return', l: 'Trả hồ sơ, yêu cầu điều tra bổ sung', ai: { w: 1.4, smart: 1 }, run: function (l, r, log) { rep(l, 6); fx(l, { karma: 8 }); if (ch(r, 0.6)) { log('Điều tra bổ sung tìm ra hung thủ thật. Một người vô tội được trả tự do.', 'big'); H.mem(l, 'Ngày người bị oan bước ra khỏi trại tạm giam, gia đình họ ôm nhau khóc.', 6); } else log('Điều tra bổ sung không có gì mới, nhưng bạn đã làm đúng lương tâm.', 'good'); } },
      { k: 'sign', l: 'Ký cáo trạng cho kịp chỉ tiêu', ai: { bad: 0.8 }, run: function (l, r, log) { fx(l, { karma: -10 }); if (ch(r, 0.25)) { log('Nhiều năm sau vụ án được minh oan. Bạn bị kỷ luật vì truy tố sai.', 'bad'); rep(l, -20); fx(l, { hap: -10 }); } else log('Vụ án khép lại. Đêm đó bạn mất ngủ.', 'bad'); } }
    ]
  });
  T('ks_oan_sai', function (l) { return hasJob(l, ['kiem_sat']) && rank(l) >= 1 && free(l); }, 0.1, 3);
  // ---- Thẩm phán: đại án, áp lực dư luận ----
  SC('tp_dai_an', {
    title: 'Xét xử đại án', valid: function (l) { return hasJob(l, ['tham_phan']) && rank(l) >= 2; },
    text: 'Bạn được phân công làm chủ tọa một đại án tham nhũng hàng nghìn tỷ, hàng chục bị cáo, báo chí theo dõi từng phiên.',
    opts: [
      { k: 'fair', l: 'Xét xử độc lập, chỉ tuân theo pháp luật', ai: { w: 1.4 }, run: function (l, r, log) { rep(l, 10); fx(l, { karma: 6, hea: -3 }); if (l.mind) l.mind.stress += 10; log('Phiên tòa kéo dài hai tháng. Bản án được dư luận đánh giá nghiêm minh, thấu tình đạt lý.', 'big'); H.mem(l, 'Đọc bản án đại án trước hàng trăm phóng viên.', 5); if (rank(l) < E.CAR.tham_phan.t.length - 1 && ch(r, 0.3)) { l.job.rank++; l.job.yrs = 0; log('Được bổ nhiệm: ' + E.jobTitle(l) + '.', 'big'); } } },
      { k: 'soft', l: 'Nghe "góp ý" từ bên ngoài', ai: { bad: 1 }, run: function (l, r, log) { fx(l, { karma: -10 }); l.flags.dirty = (l.flags.dirty || 0) + 1; log('Bản án nhẹ tay bất ngờ. Báo chí đặt nhiều câu hỏi.', 'bad'); } }
    ]
  });
  T('tp_dai_an', function (l) { return hasJob(l, ['tham_phan']) && rank(l) >= 2 && free(l); }, 0.08, 4);
  // ---- Điều tra viên ----
  SC('dtv_hoi_cung', {
    title: 'Phòng hỏi cung', valid: function (l) { return hasJob(l, ['dieu_tra_vien']); },
    text: 'Nghi phạm một vụ giết người im lặng suốt ba ngày. Cấp trên giục phải có lời khai trước khi hết hạn tạm giữ.',
    opts: [
      { k: 'evidence', l: 'Thu thập thêm chứng cứ, camera, dấu vết', ai: { w: 1.4, smart: 1 }, run: function (l, r, log) { if (ch(r, 0.55 + (l.st.kno - 50) / 150)) { rep(l, 8); log('Dấu vết ADN và camera khớp hoàn toàn. Nghi phạm cúi đầu nhận tội trước chứng cứ.', 'big'); fx(l, { hap: 5 }); } else { log('Chưa đủ chứng cứ, phải tạm thả nghi phạm. Cả tổ chuyên án làm lại từ đầu.', 'neutral'); fx(l, { hap: -3 }); } } },
      { k: 'force', l: 'Gây sức ép để có lời khai', ai: { bad: 1.2, risk: 0.8 }, run: function (l, r, log) { fx(l, { karma: -12 }); if (ch(r, 0.3)) { log('Luật sư phát hiện dấu hiệu bức cung. Bạn bị đình chỉ, điều tra tội dùng nhục hình.', 'bad'); l.job = null; l.flags.needJob = true; H.sched(l, 'bi_bat', 0, { why: 'dùng nhục hình', sev: 2 }); } else log('Có lời khai, vụ án được chuyển đi. Bạn không chắc đó là sự thật.', 'bad'); } }
    ]
  });
  T('dtv_hoi_cung', function (l) { return hasJob(l, ['dieu_tra_vien']) && free(l); }, 0.25, 1);
  // ---- Chấp hành viên: cưỡng chế thi hành án ----
  SC('chv_cuong_che', {
    title: 'Ngày cưỡng chế', valid: function (l) { return hasJob(l, ['chap_hanh_vien']); },
    text: 'Bạn phụ trách cưỡng chế giao một căn nhà theo bản án. Gia đình bên trong có cụ già và con nhỏ, hàng xóm kéo đến đông.',
    opts: [
      { k: 'talk', l: 'Thuyết phục, gia hạn thêm vài ngày cho họ dọn đồ', ai: { w: 1.4, soc: 1 }, run: function (l, r, log) { fx(l, { karma: 5 }); rep(l, 3); log('Ngồi nói chuyện cả buổi. Gia đình tự nguyện dọn đi sau một tuần, không có xô xát.', 'good'); } },
      { k: 'force', l: 'Cưỡng chế ngay theo kế hoạch', ai: { w: 0.8 }, run: function (l, r, log) { if (ch(r, 0.2)) { log('Người nhà chống đối, ném đồ đạc. Bạn bị thương nhẹ ở tay.', 'bad'); fx(l, { hea: -5 }); } else log('Cưỡng chế xong trong ngày, bàn giao nhà cho người được thi hành án.', 'neutral'); fx(l, { hap: -2 }); } }
    ]
  });
  T('chv_cuong_che', function (l) { return hasJob(l, ['chap_hanh_vien']) && free(l); }, 0.25, 1);
  // ---- Thừa phát lại: lập vi bằng, tống đạt ----
  SC('tpl_vi_bang', {
    title: 'Yêu cầu lập vi bằng', valid: function (l) { return hasJob(l, ['thua_phat_lai']) && rank(l) >= 1; },
    text: 'Một khách muốn lập vi bằng "mua bán nhà bằng giấy tay" — thực chất là che giấu khoản vay nặng lãi để sau này siết nhà người vay.',
    opts: [
      { k: 'refuse', l: 'Từ chối, giải thích vi bằng không thay thế hợp đồng công chứng', ai: { w: 1.4 }, run: function (l, r, log) { fx(l, { karma: 5 }); rep(l, 4); log('Từ chối lập vi bằng trái quy định.', 'good'); } },
      { k: 'do', l: 'Lập vi bằng, thu phí cao', ai: { bad: 1 }, run: function (l, r, log) { cashB(l, 0.2, 'Phí lập vi bằng'); fx(l, { karma: -8 }); if (ch(r, 0.25)) { log('Vụ siết nhà bị khởi kiện, văn phòng bị Sở Tư pháp xử phạt, bạn bị tạm đình chỉ hành nghề.', 'bad'); rep(l, -20); cashB(l, -0.3, 'Bị xử phạt'); } else log('Lập vi bằng, nhận phí. Vài tháng sau nghe tin người vay mất nhà.', 'bad'); } }
    ]
  });
  T('tpl_vi_bang', function (l) { return hasJob(l, ['thua_phat_lai']) && rank(l) >= 1 && free(l); }, 0.2, 2);
  // ---- Trợ giúp viên pháp lý ----
  SC('tgpl_vu_viec', {
    title: 'Người tìm đến trợ giúp pháp lý', valid: function (l) { return hasJob(l, ['tro_giup_phap_ly']); },
    text: function (l) { return pick(H.rf(l), ['Một người mẹ đơn thân bị chồng cũ giành quyền nuôi con.', 'Một nhóm công nhân bị công ty nợ lương ba tháng rồi bỏ trốn.', 'Một cụ bà bị con cháu lừa ký giấy cho nhà.']) + ' Họ không có tiền thuê luật sư.'; },
    opts: [
      { k: 'help', l: 'Theo vụ việc đến cùng', ai: { w: 1.4 }, run: function (l, r, log) { fx(l, { karma: 8, hap: 3 }); log(ch(r, 0.6) ? 'Bảo vệ được quyền lợi cho họ. Một lá thư cảm ơn viết tay được gửi đến trung tâm.' : 'Thua kiện, nhưng họ biết đã có người đứng về phía mình.', 'good'); } },
      { k: 'basic', l: 'Tư vấn cơ bản rồi chuyển nơi khác', ai: { w: 0.7 }, run: function (l, r, log) { log('Tư vấn cơ bản, hướng dẫn họ làm đơn.', 'neutral'); } }
    ]
  });
  T('tgpl_vu_viec', function (l) { return hasJob(l, ['tro_giup_phap_ly']) && free(l); }, 0.3, 1);
  PATHS.dieu_tra_vien = [['luat_su', 2, 0.2, 2, 'Một hãng luật mời bạn — người hiểu rõ quy trình điều tra — về làm luật sư hình sự.']];
  PATHS.chap_hanh_vien = [['thua_phat_lai', 1, 0.5, 2, 'Có thể ra mở văn phòng thừa phát lại, thu nhập cao hơn nhiều.']];

  // ---- Bác sĩ, điều dưỡng ----
  SC('bs_ca_kho', {
    title: 'Ca bệnh nguy kịch', valid: function (l) { return hasJob(l, ['bac_si', 'phong_kham']) && l.job.rank >= 1; },
    text: 'Nửa đêm, một bệnh nhân tai nạn được đưa vào trong tình trạng nguy kịch. Ca mổ rất khó, chuyển tuyến thì có thể không kịp.',
    opts: [
      { k: 'op', l: 'Trực tiếp mổ cấp cứu', ai: { w: 1.3, smart: 1 }, run: function (l, r, log) {
        var p = U.clamp(0.5 + (l.st.kno - 50) / 100 + rank(l) * 0.06, 0.25, 0.92);
        if (ch(r, p)) { rep(l, 10); fx(l, { hap: 8, karma: 4 }); log('Ca mổ kéo dài 7 tiếng — bệnh nhân qua cơn nguy kịch. Báo chí viết bài về "bác sĩ trực đêm".', 'big'); H.mem(l, 'Ca mổ cứu sống bệnh nhân nguy kịch, bước ra khỏi phòng mổ trời đã sáng.', 5); }
        else { rep(l, -5); fx(l, { hap: -10 }); log('Đã cố hết sức nhưng bệnh nhân không qua khỏi. Gia đình họ gào khóc ngoài hành lang.', 'bad'); if (ch(r, 0.3)) H.sched(l, 'bs_hanh_hung', 0); }
      } },
      { k: 'transfer', l: 'Sơ cứu và chuyển tuyến trên', ai: { w: 1 }, run: function (l, r, log) { log('Sơ cứu ổn định rồi chuyển lên tuyến trên. Không biết sau đó bệnh nhân ra sao.', 'neutral'); } }
    ]
  });
  T('bs_ca_kho', function (l) { return hasJob(l, ['bac_si', 'phong_kham']) && l.job.rank >= 1 && free(l); }, 0.2, 2);
  SC('bs_hanh_hung', {
    title: 'Người nhà bệnh nhân quá khích', valid: function (l) { return hasJob(l, ['bac_si', 'dieu_duong', 'phong_kham']); },
    text: 'Người nhà một bệnh nhân say rượu xông vào phòng trực, lớn tiếng đổ lỗi bạn chữa sai rồi lao vào định đánh.',
    opts: [
      { k: 'calm', l: 'Bình tĩnh giải thích, gọi bảo vệ', ai: { w: 1.4 }, run: function (l, r, log) { if (ch(r, 0.3)) { log('Bị đánh mấy cú trước khi bảo vệ kịp đến. Clip được đăng lên mạng, cả nước lên tiếng bảo vệ y bác sĩ.', 'bad'); fx(l, { hea: -6, hap: -6 }); } else log('Bảo vệ kịp can ngăn, người nhà sau đó xin lỗi.', 'neutral'); } },
      { k: 'sue', l: 'Báo công an xử lý đến cùng', ai: { w: 0.8 }, run: function (l, r, log) { log('Đối tượng bị khởi tố tội gây rối trật tự công cộng.', 'neutral'); fx(l, { hap: -2 }); } }
    ]
  });
  T('bs_hanh_hung', function (l) { return hasJob(l, ['bac_si', 'dieu_duong']) && free(l); }, 0.03, 4);

  // ---- Giáo viên ----
  SC('gv_phu_huynh', {
    title: 'Chuyện ở trường', prep: function (l, r) { return { k: pick(r, ['them', 'diem', 'ca_biet']) }; },
    valid: function (l) { return hasJob(l, ['giao_vien', 'gv_mam_non']); },
    text: function (l, d) { return d.k === 'them' ? 'Nhà trường cấm dạy thêm tràn lan, nhưng phụ huynh cả lớp xin bạn mở lớp học thêm buổi tối.' : d.k === 'diem' ? 'Một phụ huynh có chức có quyền gặp riêng, gợi ý "nâng điểm" để con đạt học sinh giỏi.' : 'Một học sinh cá biệt đánh bạn trong lớp, quay clip đăng mạng. Phụ huynh em đó lại bênh con.'; },
    opts: [
      { k: 'good', l: function (l, d) { return d.k === 'them' ? 'Mở lớp học thêm đúng quy định, thu vừa phải' : d.k === 'diem' ? 'Từ chối, chấm đúng năng lực' : 'Gặp riêng gia đình, kiên nhẫn giáo dục em'; }, ai: { w: 1.4 }, run: function (l, r, log, d) {
        if (d.k === 'them') { cashB(l, 0.25, 'Dạy thêm'); log('Mở lớp học thêm buổi tối, thu thêm được ít tiền trang trải.', 'good'); fx(l, { hea: -2 }); }
        else if (d.k === 'diem') { fx(l, { karma: 6 }); rep(l, 4); log('Từ chối khéo. Phụ huynh không vui, nhưng bạn ngủ ngon.', 'good'); }
        else { fx(l, { karma: 5, hap: -2 }); if (ch(r, 0.6)) { log('Sau nhiều buổi trò chuyện, em ấy thay đổi hẳn. Cuối năm em viết thư cảm ơn cô thầy.', 'good'); H.mem(l, 'Lá thư của cậu học trò cá biệt năm ấy.', 4); } else log('Em ấy vẫn chưa thay đổi, nhưng bạn không bỏ cuộc.', 'neutral'); }
      } },
      { k: 'bad', l: function (l, d) { return d.k === 'them' ? 'Ép cả lớp đi học thêm, ai không học thì "để ý"' : d.k === 'diem' ? 'Nâng điểm, nhận quà' : 'Xin chuyển em đó sang lớp khác'; }, ai: { bad: 1 }, run: function (l, r, log, d) {
        if (d.k === 'them') { cashB(l, 0.6, 'Dạy thêm'); fx(l, { karma: -6 }); if (ch(r, 0.25)) { log('Phụ huynh phản ánh lên báo chuyện ép học thêm. Bạn bị kỷ luật cảnh cáo.', 'bad'); rep(l, -15); fx(l, { hap: -8 }); } else log('Lớp học thêm đông nghịt, tiền vào đều.', 'neutral'); }
        else if (d.k === 'diem') { cashB(l, 0.15, 'Quà phụ huynh'); fx(l, { karma: -8 }); log('Nâng điểm cho em học sinh. Cả lớp xì xào.', 'bad'); }
        else { log('Em học sinh bị chuyển lớp. Vấn đề chỉ chuyển sang chỗ khác.', 'neutral'); }
      } }
    ]
  });
  T('gv_phu_huynh', function (l) { return hasJob(l, ['giao_vien']) && free(l); }, 0.15, 2);

  // ---- Chủ quán ăn / nhà hàng / quán cà phê ----
  SC('qa_su_co', {
    title: 'Chuyện ở quán', prep: function (l, r) { return { k: pick(r, ['ngo_doc', 'review', 'mat_bang', 'nhan_vien']), n: l.job.p || 'quán' }; },
    valid: function (l) { return hasJob(l, ['chu_quan_an', 'chu_nha_hang', 'kd_quan']) && (rank(l) >= 1 || jid(l) === 'kd_quan'); },
    text: function (l, d) { return { ngo_doc: 'Một bàn khách ăn ở ' + d.n + ' xong bị đau bụng, đăng bài tố quán làm ngộ độc. Đoàn kiểm tra an toàn thực phẩm sắp đến.', review: 'Một food reviewer hơn triệu người theo dõi ghé ' + d.n + ' quay clip. Món ăn hôm đó bếp làm hơi vội.', mat_bang: 'Chủ nhà báo tăng tiền thuê mặt bằng 40% từ tháng sau, không đồng ý thì trả mặt bằng.', nhan_vien: 'Bếp chính đòi tăng lương gấp rưỡi, không thì nghỉ ngay giữa mùa đông khách.' }[d.k]; },
    opts: [
      { k: 'a', l: function (l, d) { return { ngo_doc: 'Xin lỗi, đền bù, rà soát lại khâu nguyên liệu', review: 'Mời reviewer quay lại hôm khác, tự tay nấu', mat_bang: 'Chấp nhận giá mới, tăng giá món', nhan_vien: 'Tăng lương giữ người' }[d.k]; }, ai: { w: 1.3 }, run: function (l, r, log, d) {
        if (d.k === 'ngo_doc') { cashB(l, -0.15, 'Đền bù khách, rà soát bếp'); log('Đền bù cho khách, thay nhà cung cấp. Đoàn kiểm tra đạt, khách quen vẫn ủng hộ.', 'neutral'); }
        else if (d.k === 'review') { if (ch(r, 0.6)) { log('Clip khen hết lời — quán đông nghịt cả tháng, phải thuê thêm người.', 'big'); cashB(l, 0.5, 'Doanh thu tăng sau clip review'); l.job.yrs++; } else log('Clip chấm điểm "tạm được". Không đông thêm mà cũng không vắng đi.', 'neutral'); }
        else if (d.k === 'mat_bang') { cashB(l, -0.3, 'Tăng tiền thuê mặt bằng'); log('Chấp nhận giá thuê mới, tăng giá món. Vài khách quen phàn nàn.', 'neutral'); }
        else { cashB(l, -0.15, 'Tăng lương bếp chính'); log('Tăng lương giữ chân bếp chính, quán vẫn chạy đều.', 'neutral'); }
      } },
      { k: 'b', l: function (l, d) { return { ngo_doc: 'Chối, thuê người "dẹp" bài đăng', review: 'Gửi "phong bì" nhờ clip khen', mat_bang: 'Trả mặt bằng, tìm chỗ mới', nhan_vien: 'Cho nghỉ, tự đứng bếp' }[d.k]; }, ai: { risk: 1 }, run: function (l, r, log, d) {
        if (d.k === 'ngo_doc') { fx(l, { karma: -6 }); if (ch(r, 0.5)) { log('Bài đăng lan rộng hơn vì bị "dẹp". Đoàn kiểm tra phát hiện nguyên liệu không rõ nguồn gốc — quán bị phạt và đình chỉ 3 tháng.', 'bad'); cashB(l, -0.6, 'Phạt & đình chỉ kinh doanh'); fx(l, { hap: -10 }); } else log('Bài đăng chìm dần. Chuyện qua đi.', 'neutral'); }
        else if (d.k === 'review') { cashB(l, -0.1, 'Phong bì reviewer'); if (ch(r, 0.3)) { log('Dân mạng phát hiện clip "khen có tiền", quay ra tẩy chay quán.', 'bad'); cashB(l, -0.3, 'Doanh thu giảm'); } else log('Clip khen ngợi, quán đông hơn hẳn.', 'good'); }
        else if (d.k === 'mat_bang') { cashB(l, -0.4, 'Chuyển mặt bằng'); if (ch(r, 0.5)) log('Chỗ mới rộng hơn, khách cũ vẫn tìm đến.', 'good'); else { log('Chỗ mới vắng khách, mất nửa năm mới gây dựng lại.', 'bad'); fx(l, { hap: -6 }); } }
        else { fx(l, { hea: -5 }); log('Cho bếp chính nghỉ, tự mình đứng bếp từ sáng đến khuya.', 'neutral'); }
      } }
    ]
  });
  T('qa_su_co', function (l) { return hasJob(l, ['chu_quan_an', 'chu_nha_hang', 'kd_quan']) && free(l); }, 0.25, 1);

  // ---- Tiệm điện thoại ----
  SC('dt_may_gian', {
    title: 'Chiếc điện thoại giá rẻ', valid: function (l) { return hasJob(l, ['tiem_dt']); },
    text: 'Một thanh niên mang đến chiếc iPhone đời mới, không hộp, không hóa đơn, bán rẻ bằng một nửa giá thị trường: "Bán gấp anh ơi."',
    opts: [
      { k: 'no', l: 'Từ chối, đòi giấy tờ chứng minh', ai: { w: 1.4 }, run: function (l, r, log) { fx(l, { karma: 3 }); log('Từ chối mua máy không rõ nguồn gốc. Hai hôm sau công an đến hỏi về một vụ cướp điện thoại.', 'good'); } },
      { k: 'buy', l: 'Mua rẻ, bán lại kiếm lời', ai: { bad: 1, risk: 1 }, run: function (l, r, log) { fx(l, { karma: -6 }); if (ch(r, 0.3)) { log('Máy là tang vật một vụ cướp. Bạn bị xử lý tội tiêu thụ tài sản do người khác phạm tội mà có.', 'bad'); cashB(l, -0.2, 'Phạt tiêu thụ đồ gian'); if (ch(r, 0.3)) H.sched(l, 'bi_bat', 0, { why: 'tiêu thụ tài sản do người khác phạm tội mà có', sev: 1 }); } else { cashB(l, 0.08, 'Lời bán máy'); log('Bán lại lời gấp đôi.', 'neutral'); } } },
      { k: 'report', l: 'Giữ chân người bán, báo công an', ai: { w: 0.6, risk: 0.5 }, run: function (l, r, log) { if (ch(r, 0.2)) { log('Đối tượng bỏ chạy, sau đó quay lại đập kính tiệm.', 'bad'); cashB(l, -0.05, 'Sửa kính cửa tiệm'); } else { log('Công an bắt được đối tượng — hóa ra là cả một nhóm chuyên cướp giật.', 'good'); fx(l, { karma: 5 }); } } }
    ]
  });
  T('dt_may_gian', function (l) { return hasJob(l, ['tiem_dt']) && free(l); }, 0.15, 2);

  // ---- Cầm đồ ----
  SC('cd_xe_gian', {
    title: 'Khách cắm xe', valid: function (l) { return hasJob(l, ['cam_do']); },
    text: 'Một người mang xe SH đến cắm, không có giấy tờ, chỉ cần lấy nhanh tiền mặt. Bên cạnh đó một bà cụ xin cắm chiếc nhẫn cưới lấy tiền viện phí cho chồng.',
    opts: [
      { k: 'law', l: 'Từ chối xe không giấy tờ, cho bà cụ cầm với lãi thấp', ai: { w: 1.4 }, run: function (l, r, log) { fx(l, { karma: 6 }); log('Từ chối chiếc xe không rõ nguồn gốc. Bà cụ cảm ơn rối rít.', 'good'); } },
      { k: 'take', l: 'Nhận cả hai, lãi theo "giá thị trường"', ai: { bad: 1, risk: 1 }, run: function (l, r, log) { fx(l, { karma: -6 }); cashB(l, 0.1, 'Lãi cầm đồ'); if (ch(r, 0.3)) { log('Chiếc xe là tài sản trộm cắp. Công an thu hồi xe, bạn mất trắng tiền đã đưa và bị phạt.', 'bad'); cashB(l, -0.4, 'Mất tiền xe gian, bị phạt'); } else log('Hết hạn không ai chuộc xe, bạn thanh lý được một khoản.', 'neutral'); } }
    ]
  });
  T('cd_xe_gian', function (l) { return hasJob(l, ['cam_do']) && free(l); }, 0.15, 2);

  // ---- Xây dựng ----
  SC('xd_vat_lieu', {
    title: 'Công trình đang thi công', valid: function (l) { return hasJob(l, ['ky_su_xd']) || (hasJob(l, ['phu_ho']) && rank(l) >= 2); },
    text: 'Nhà cung cấp gợi ý thay thép đúng chuẩn bằng loại rẻ hơn, "chênh lệch anh em chia nhau, mắt thường không ai nhìn ra".',
    opts: [
      { k: 'no', l: 'Từ chối, làm đúng thiết kế', ai: { w: 1.5 }, run: function (l, r, log) { fx(l, { karma: 5 }); rep(l, 3); log('Làm đúng thiết kế. Công trình nghiệm thu đạt chuẩn.', 'good'); } },
      { k: 'yes', l: 'Đồng ý "rút ruột" một ít', ai: { bad: 1.4 }, run: function (l, r, log) {
        cashB(l, 0.5, 'Tiền chênh lệch vật liệu'); fx(l, { karma: -12 }); l.flags.dirty = (l.flags.dirty || 0) + 1;
        if (ch(r, 0.12)) { log('Một mảng tường công trình sập khi đang thi công, công nhân bị thương nặng. Bạn bị khởi tố.', 'bad'); H.mem(l, 'Ngày công trình đổ sập vì những cây thép không đủ chuẩn.', 6); H.sched(l, 'bi_bat', 0, { why: 'vi phạm quy định về xây dựng gây hậu quả nghiêm trọng', sev: 2 }); }
        else log('Công trình vẫn nghiệm thu. Bạn không dám đi ngang qua đó.', 'bad');
      } }
    ]
  });
  T('xd_vat_lieu', function (l) { return (hasJob(l, ['ky_su_xd']) || (hasJob(l, ['phu_ho']) && rank(l) >= 2)) && free(l); }, 0.1, 3);

  // ---- Nhà báo ----
  SC('pv_dieu_tra', {
    title: 'Loạt bài điều tra', valid: function (l) { return hasJob(l, ['phong_vien']); },
    text: 'Bạn thu thập được bằng chứng về một xưởng sản xuất thực phẩm bẩn cung cấp cho hàng trăm trường học. Chủ xưởng gọi điện "mời cà phê".',
    opts: [
      { k: 'publish', l: 'Đăng bài, theo đến cùng', ai: { w: 1.3 }, run: function (l, r, log) { rep(l, 10); fx(l, { karma: 8, hap: 4 }); if (ch(r, 0.15)) { log('Đăng bài xong bị nhóm côn đồ chặn đường hành hung.', 'bad'); fx(l, { hea: -10 }); } log('Loạt bài gây chấn động, cơ quan chức năng vào cuộc đóng cửa xưởng. Bạn được giải báo chí quốc gia.', 'big'); H.mem(l, 'Loạt bài điều tra về xưởng thực phẩm bẩn.', 5); } },
      { k: 'sell', l: 'Nhận tiền, "ém" bài', ai: { bad: 1.4 }, run: function (l, r, log) { cashB(l, 0.8, 'Tiền "ém" bài'); fx(l, { karma: -15 }); l.flags.dirty = (l.flags.dirty || 0) + 1; if (ch(r, 0.2)) { log('Đồng nghiệp phanh phui chuyện bạn nhận tiền. Bạn bị thu thẻ nhà báo, khởi tố tội cưỡng đoạt tài sản.', 'bad'); l.job = null; l.flags.needJob = true; H.sched(l, 'bi_bat', 0, { why: 'cưỡng đoạt tài sản', sev: 2 }); } else log('Bài viết không bao giờ được đăng. Bọn trẻ vẫn ăn suất cơm đó.', 'bad'); } },
      { k: 'drop', l: 'Bỏ qua cho an toàn', ai: { w: 0.6 }, run: function (l, r, log) { log('Bỏ qua đề tài. Bạn tự nhủ "không phải việc của mình".', 'neutral'); fx(l, { hap: -2 }); } }
    ]
  });
  T('pv_dieu_tra', function (l) { return hasJob(l, ['phong_vien']) && free(l); }, 0.12, 3);

  // ---- Môi giới bất động sản ----
  SC('bds_deal', {
    title: 'Thương vụ lớn', valid: function (l) { return hasJob(l, ['sale_bds']); },
    text: function (l) { return 'Một khách Việt kiều muốn mua lô đất giá chục tỷ. ' + (l.mkt && l.mkt.land === 'sốt' ? 'Đất đang sốt, ' : '') + 'Chủ đất muốn bạn "thổi giá" thêm, phần chênh chia đôi.'; },
    opts: [
      { k: 'honest', l: 'Môi giới đúng giá, lấy hoa hồng', ai: { w: 1.3 }, run: function (l, r, log) { if (ch(r, 0.55)) { cashB(l, 0.5, 'Hoa hồng môi giới'); rep(l, 5); log('Chốt deal! Hoa hồng một lần bằng cả năm làm văn phòng.', 'big'); } else log('Khách đổi ý vào phút chót. Công cốc mấy tháng.', 'bad'); } },
      { k: 'inflate', l: 'Thổi giá, ăn chênh lệch', ai: { bad: 1.2, risk: 1 }, run: function (l, r, log) { fx(l, { karma: -8 }); if (ch(r, 0.25)) { log('Khách phát hiện bị thổi giá, kiện ra tòa và tung lên mạng. Bạn mất trắng.', 'bad'); rep(l, -20); cashB(l, -0.2, 'Án phí'); } else { cashB(l, 1.2, 'Chênh lệch "thổi giá"'); log('Chốt deal với giá đã thổi, ôm một cục tiền chênh.', 'neutral'); } } }
    ]
  });
  T('bds_deal', function (l) { return hasJob(l, ['sale_bds']) && free(l); }, 0.3, 1);

  // ---- Ngân hàng ----
  SC('nh_chi_tieu', {
    title: 'Chỉ tiêu cuối quý', valid: function (l) { return hasJob(l, ['ngan_hang', 'ngan_hang_cao']); },
    text: function (l) { return rank(l) >= 2 || jid(l) === 'ngan_hang_cao' ? 'Một "sếp lớn" ép bạn duyệt khoản vay nghìn tỷ cho công ty "sân sau" dù tài sản thế chấp bị định giá khống.' : 'Chi nhánh giao chỉ tiêu bán bảo hiểm. Cách nhanh nhất: "gài" bảo hiểm vào hồ sơ vay của khách.'; },
    opts: [
      { k: 'right', l: 'Làm đúng quy định, chấp nhận không đạt chỉ tiêu', ai: { w: 1.3 }, run: function (l, r, log) { fx(l, { karma: 4, hap: -2 }); rep(l, -2); log('Làm đúng quy định. Bị nhắc nhở trong cuộc họp, nhưng hồ sơ sạch.', 'neutral'); } },
      { k: 'push', l: function (l) { return rank(l) >= 2 || jid(l) === 'ngan_hang_cao' ? 'Ký duyệt theo chỉ đạo' : 'Gài bảo hiểm cho khách'; }, ai: { bad: 1, amb: 0.5 }, run: function (l, r, log) {
        var big = rank(l) >= 2 || jid(l) === 'ngan_hang_cao';
        fx(l, { karma: big ? -10 : -4 }); cashB(l, big ? 1.5 : 0.1, big ? 'Thưởng "ngoài"' : 'Thưởng chỉ tiêu');
        if (big) { l.flags.dirty = (l.flags.dirty || 0) + 1; if (ch(r, 0.2)) { log('Khoản vay thành nợ xấu, cơ quan điều tra vào cuộc. Bạn bị khởi tố tội vi phạm quy định cho vay.', 'bad'); l.job = null; l.flags.needJob = true; H.sched(l, 'bi_bat', 0, { why: 'vi phạm quy định về cho vay gây hậu quả nghiêm trọng', sev: 3 }); return; } log('Ký duyệt. Tiền thưởng về đều — và nỗi lo cũng thế.', 'bad'); }
        else log('Đạt chỉ tiêu. Một khách hàng gọi điện mắng vì "không hề biết có mua bảo hiểm".', 'neutral');
      } }
    ]
  });
  T('nh_chi_tieu', function (l) { return hasJob(l, ['ngan_hang', 'ngan_hang_cao']) && free(l); }, 0.15, 2);

  // ---- Chính trị: bầu cử, "cơ chế", thanh tra kỷ luật ----
  function electionYear(l) { var y = yr(l); return isVN(l) ? (y - 2026) % 5 === 0 : y % 4 === 0; }
  SC('ct_bau_cu', {
    title: function (l) { return isVN(l) ? 'Bầu cử đại biểu Quốc hội' : 'Mùa bầu cử'; },
    valid: function (l) { return hasJob(l, ['chinh_tri', 'chinh_khach']) && rank(l) >= 2; },
    text: function (l) { return isVN(l) ? 'Bạn được giới thiệu ứng cử đại biểu Quốc hội khóa mới. Phải tiếp xúc cử tri ở nhiều xã vùng sâu.' : 'Đảng của bạn đề cử bạn ra tranh cử. Đối thủ đang dẫn trước trong các cuộc thăm dò.'; },
    opts: [
      { k: 'campaign', l: 'Đi khắp địa bàn, lắng nghe cử tri', ai: { w: 1.4, soc: 1 }, run: function (l, r, log) {
        var p = U.clamp(0.5 + (l.st.soc - 50) / 120 + (l.karma || 0) / 200 + (l.flags.eliteBoost ? 0.15 : 0), 0.2, 0.92);
        fx(l, { hea: -3 });
        if (ch(r, p)) { l.flags.daibieu = (l.flags.daibieu || 0) + 1; log(isVN(l) ? 'Trúng cử đại biểu Quốc hội với số phiếu cao.' : 'Thắng cử sát nút!', 'big'); fx(l, { hap: 8 }); H.mem(l, 'Đêm nghe công bố kết quả bầu cử năm ' + yr(l) + '.', 5); if (rank(l) < E.CAR[jid(l)].t.length - 1 && ch(r, 0.4) && (jid(l) !== 'chinh_tri' || rank(l) < 6 || !E.canAdvance || E.canAdvance(l, E.CAR[jid(l)], false))) { l.job.rank++; l.job.yrs = 0; log('Được giao trọng trách mới: ' + E.jobTitle(l) + '.', 'big'); } }
        else { log(isVN(l) ? 'Không trúng cử lần này.' : 'Thất cử.', 'bad'); fx(l, { hap: -6 }); }
      } },
      { k: 'money', l: 'Chi tiền "vận động" ngầm', ai: { bad: 1.3, risk: 1 }, run: function (l, r, log) { cashB(l, -1, 'Chi phí vận động'); fx(l, { karma: -8 }); l.flags.dirty = (l.flags.dirty || 0) + 1; if (ch(r, 0.6)) { l.flags.daibieu = (l.flags.daibieu || 0) + 1; log('Trúng cử. Ai cũng biết cái giá của nó.', 'neutral'); } else log('Mất tiền mà vẫn thất cử.', 'bad'); } },
      { k: 'skip', l: 'Xin rút, nhường người khác', ai: { w: 0.4 }, run: function (l, r, log) { log('Xin rút khỏi danh sách ứng cử.', 'neutral'); } }
    ]
  });
  T('ct_bau_cu', function (l) { return hasJob(l, ['chinh_tri', 'chinh_khach']) && rank(l) >= 2 && electionYear(l) && free(l); }, 0.9);
  SC('ct_co_che', {
    title: 'Lời đề nghị "cơ chế"', valid: function (l) { return hasJob(l, ['chinh_tri', 'chinh_khach']) && rank(l) >= 1; },
    text: 'Chủ một tập đoàn xin gặp riêng: dự án khu đô thị cần được "tạo điều kiện" chuyển đổi đất. Ông ta nói sẽ "không quên ơn".',
    opts: [
      { k: 'no', l: 'Từ chối, yêu cầu làm đúng quy trình', ai: { w: 1.5 }, run: function (l, r, log) { fx(l, { karma: 8 }); log('Từ chối thẳng. Dự án phải làm đủ thủ tục như mọi người.', 'good'); } },
      { k: 'yes', l: 'Nhận "quà cảm ơn", ký tạo điều kiện', ai: { bad: 1.6, amb: 0.5 }, run: function (l, r, log) { cashB(l, 3 + rank(l) * 2, '"Quà cảm ơn"'); fx(l, { karma: -15 }); l.flags.dirty = (l.flags.dirty || 0) + 2; log('Dự án được "bật đèn xanh". Một chiếc vali được gửi đến nhà.', 'bad'); } }
    ]
  });
  T('ct_co_che', function (l) { return hasJob(l, ['chinh_tri', 'chinh_khach']) && rank(l) >= 1 && free(l); }, 0.12, 3);
  SC('ct_ky_luat', {
    title: 'Đoàn thanh tra', tone: 'dark', valid: function (l) { return (l.flags.dirty || 0) > 0 && !!l.job; },
    text: 'Đoàn thanh tra, kiểm tra về làm việc. Những dự án, khoản tiền năm xưa đang được rà soát lại từng tờ giấy.',
    opts: [
      { k: 'confess', l: 'Thành khẩn khai báo, nộp lại tiền', ai: { w: 1.2 }, run: function (l, r, log) { var x = Math.min(cash(l), l.base * (l.flags.dirty || 1) * 2); H.cash(l, -x, 'Nộp lại tiền sai phạm'); log('Thành khẩn khai báo, nộp lại ' + mo(l, x) + '. Bị kỷ luật cách chức, được xem xét giảm nhẹ.', 'bad'); l.flags.dirty = 0; if (ch(r, 0.4)) H.sched(l, 'bi_bat', 0, { why: 'lợi dụng chức vụ quyền hạn', sev: 1 }); else { l.job = null; l.flags.needJob = true; } fx(l, { hap: -15 }); H.mem(l, 'Ngày nhận quyết định kỷ luật.', 5); } },
      { k: 'deny', l: 'Chối, nhờ quan hệ "chạy"', ai: { risk: 1.2, bad: 0.8 }, run: function (l, r, log) { if (ch(r, 0.35)) { log('Thoát được lần này nhờ "ô dù". Nhưng hồ sơ vẫn nằm đó.', 'neutral'); cashB(l, -1, 'Chi phí "chạy"'); } else { log('Bằng chứng quá rõ. Bạn bị bắt tạm giam, báo chí đưa tin khắp nơi.', 'bad'); l.flags.dirty = 0; H.sched(l, 'bi_bat', 0, { why: 'nhận hối lộ, lợi dụng chức vụ', sev: 3 }); } } }
    ]
  });
  T('ct_ky_luat', function (l) { return (l.flags.dirty || 0) > 0 && l.job && free(l); }, function (l) { return Math.min(0.4, 0.04 * l.flags.dirty * (hasJob(l, ['chinh_tri', 'chinh_khach', 'ngan_hang_cao', 'tai_phiet']) ? 1.5 : 1)); }, 2);

  // ---- Tài phiệt: khủng hoảng trái phiếu, thâu tóm ----
  SC('tp_trai_phieu', {
    title: 'Trái phiếu đến hạn', valid: function (l) { return hasJob(l, ['tai_phiet', 'chu_dau_tu']) && rank(l) >= 1; },
    text: 'Thị trường đóng băng, hàng nghìn tỷ trái phiếu của tập đoàn sắp đến hạn trả. Dòng tiền gần như cạn.',
    opts: [
      { k: 'sell', l: 'Bán bớt dự án, cổ phần để trả nợ đúng hạn', ai: { w: 1.3, smart: 1 }, run: function (l, r, log) { var A = l.assets; if (A && A.stock > 0.5) A.stock *= 0.6; cashB(l, -3, 'Trả nợ trái phiếu'); log('Bán tháo nhiều dự án, cổ phần để trả nợ đúng hạn. Tập đoàn thu nhỏ nhưng giữ được uy tín.', 'neutral'); fx(l, { hap: -6 }); } },
      { k: 'roll', l: 'Phát hành thêm trái phiếu lãi cao "đảo nợ"', ai: { risk: 1.4, bad: 0.6 }, run: function (l, r, log) { fx(l, { karma: -8 }); if (ch(r, 0.3)) { log('Cơ quan điều tra khởi tố vụ án lừa đảo trong phát hành trái phiếu. Hàng nghìn nhà đầu tư kéo đến trụ sở.', 'bad'); H.mem(l, 'Ngày bị bắt giữa tâm bão trái phiếu.', 7); H.sched(l, 'bi_bat', 0, { why: 'lừa đảo chiếm đoạt tài sản trong phát hành trái phiếu', sev: 3 }); } else log('Đảo nợ thành công thêm một vòng. Quả bom được hẹn giờ lại.', 'neutral'); } },
      { k: 'extend', l: 'Đàm phán gia hạn với trái chủ', ai: { w: 1 }, run: function (l, r, log) { if (ch(r, 0.6)) log('Trái chủ đồng ý gia hạn hai năm, đổi lấy lãi suất cao hơn.', 'neutral'); else { log('Đàm phán thất bại, cổ phiếu tập đoàn bị bán tháo.', 'bad'); var A = l.assets; if (A && A.stock > 0.5) A.stock *= 0.5; } } }
    ]
  });
  T('tp_trai_phieu', function (l) { return hasJob(l, ['tai_phiet', 'chu_dau_tu']) && rank(l) >= 1 && free(l) && l.mkt && (l.mkt.land === 'đóng băng' || l.mkt.land === 'vỡ bong bóng'); }, 0.4, 4);
  SC('tp_thau_tom', {
    title: 'Cơ hội thâu tóm', valid: function (l) { return hasJob(l, ['tai_phiet', 'kd_tu_do']) && rank(l) >= 2; },
    text: 'Một đối thủ cạnh tranh đang khó khăn, sẵn sàng bán lại toàn bộ công ty với giá rẻ.',
    opts: [
      { k: 'buy', l: 'Thâu tóm', ai: { amb: 1, risk: 0.8 }, run: function (l, r, log) { if (ch(r, 0.55)) { cashB(l, 5, 'Lợi nhuận sau thâu tóm'); log('Thâu tóm thành công, thị phần tăng gấp rưỡi.', 'big'); fx(l, { hap: 6 }); } else { cashB(l, -4, 'Lỗ sau thâu tóm'); log('Mua phải "cái vỏ" đầy nợ ẩn. Mất mấy năm mới xử lý xong.', 'bad'); fx(l, { hap: -6 }); } } },
      { k: 'no', l: 'Tập trung vào mảng đang làm', ai: { w: 1 }, run: function (l, r, log) { log('Bỏ qua thương vụ, tập trung vào thế mạnh.', 'neutral'); } }
    ]
  });
  T('tp_thau_tom', function (l) { return hasJob(l, ['tai_phiet', 'kd_tu_do']) && rank(l) >= 2 && free(l); }, 0.1, 4);

  // ===================================================================
  // 4. GIA ĐÌNH SIÊU GIÀU (~1%): tài phiệt · chủ ngân hàng · chính trị
  // ===================================================================
  var ELITE = {
    tp: { n: 'tài phiệt', dad: 'chủ tịch tập đoàn', mom: 'phó chủ tịch tập đoàn', job: 'tai_phiet', major: 'eco', allow: 5, inherit: 3000 },
    nh: { n: 'chủ ngân hàng', dad: 'chủ tịch HĐQT ngân hàng', mom: 'tổng giám đốc ngân hàng', job: 'ngan_hang_cao', major: 'eco', allow: 3, inherit: 800 },
    ct: { n: 'chính trị', dad: 'bí thư tỉnh ủy', mom: 'phó chủ tịch UBND tỉnh', job: 'chinh_tri', major: 'law', allow: 1, inherit: 60 }
  };
  function elite(l) { return l.fam && l.fam.elite ? ELITE[l.fam.elite] : null; }
  function eliteJob(l) { var e = elite(l); return e ? (e.job === 'chinh_tri' && !isVN(l) ? 'chinh_khach' : e.job) : null; }
  function follower(l) { return !!(elite(l) && l.flags.eliteFollow && !l.flags.eliteCut); }
  E.eliteBirth = function (l, PA) {
    var f = l.fam, kind = PA && PA.elite ? PA.elite : null;
    if (!kind && !PA) {
      var h = { rs: (l.rs ^ 0x7e1173) | 0 }, x = U.rand(h);
      if (l.urban && x < 0.045) kind = U.rand(h) < 0.5 ? 'tp' : U.rand(h) < 0.5 ? 'nh' : 'ct'; // ~1% tổng số ca sinh (chỉ ở thành thị)
    }
    if (!kind) return;
    var e = ELITE[kind];
    f.elite = kind; f.q = 5; f.vice = null; f.noDad = false; f.fAlive = true; f.home = 'nhà riêng';
    if (!PA) {
      f.fJob = isVN(l) || kind !== 'ct' ? e.dad : 'nghị sĩ quốc hội'; f.mJob = isVN(l) || kind !== 'ct' ? e.mom : 'bộ trưởng';
      f.fInc = E.parentMonthly(l, f.fJob, null); f.mInc = E.parentMonthly(l, f.mJob, null);
    }
    l.houseType = isVN(l) ? 'biệt thự' : '';
  };
  function eliteLog(l, a, r, log) {
    var e = elite(l); if (!e) return;
    if (a === 0) log('Bạn chào đời trong một gia đình ' + e.n + ': bố là ' + l.fam.fJob + ', mẹ là ' + l.fam.mJob + '. Ngay từ ngày đầu đã có bảo mẫu riêng.', 'big');
  }
  // tuổi thơ gia giáo, khuôn phép
  EV(function (l, a) { return !!elite(l) && a >= 4 && a <= 16; }, 0.25, function (l, a, r, log) {
    var e = elite(l);
    var t = pick(r, ['Học trường quốc tế, có tài xế riêng đưa đón, vệ sĩ đi theo mỗi khi ra phố.', 'Bữa cơm nào cũng phải ngồi đúng chỗ, mời đủ người lớn, không được cầm điện thoại trên bàn.',
      'Mẹ dặn không được chơi với "bọn trẻ trong xóm", chỉ chơi với con các gia đình cùng giới.', 'Lịch học kín từ sáng đến tối: piano, golf, tiếng Anh, tiếng Trung, lễ nghi.',
      e.n === 'chính trị' ? 'Nhà lúc nào cũng có khách đến "thăm" bố, quà cáp chất đầy phòng khách.' : 'Sinh nhật được tổ chức ở khách sạn năm sao, bạn bè toàn con nhà đại gia.',
      'Mỗi lần đi đâu bố mẹ đều nhắc: "Con mang họ của gia đình, đừng làm mất mặt."']);
    log(t, 'neutral'); if (/không được|phải|nhắc/.test(t)) fx(l, { hap: -1 }); else fx(l, { hap: 1 });
  });
  // 17 tuổi: gia đình sắp xếp con đường
  SC('elite_dinh_huong', {
    title: 'Con đường gia đình đã vạch sẵn', valid: function (l) { return !!elite(l) && !l.flags.eliteChoice; },
    text: function (l) { var e = elite(l); return e.n === 'chính trị' ? 'Bố gọi bạn vào thư phòng: "Con sẽ học Luật, rồi về làm ở văn phòng tỉnh ủy. Đường công danh bố đã lo." Bạn thì mơ một con đường khác.' : 'Bố mẹ đã chọn sẵn: du học ngành Quản trị kinh doanh ở Mỹ, về nước vào ban điều hành ' + (e.job === 'ngan_hang_cao' ? 'ngân hàng' : 'tập đoàn') + ' gia đình. "Nhà này cần người kế nghiệp."'; },
    opts: [
      { k: 'follow', l: 'Nghe theo sắp xếp của gia đình', h: 'Chu cấp đầy đủ, tương lai trải thảm đỏ', ai: { w: 1.6 }, run: function (l, r, log) { l.flags.eliteChoice = true; l.flags.eliteFollow = true; l.flags.eliteBoost = eliteJob(l); log('Gật đầu nghe theo bố mẹ. Con đường phía trước đã được trải thảm.', 'big'); fx(l, { hap: -2 }); } },
      { k: 'own', l: 'Từ chối, tự chọn con đường riêng', h: 'Bị cắt chu cấp, có thể mất quyền thừa kế', ai: { risk: 1.2, amb: 0.5, w: 0.4 }, run: function (l, r, log) { l.flags.eliteChoice = true; l.flags.eliteCut = true; log('Bạn nói "không". Bố đập bàn: "Từ nay tự lo lấy thân!" Thẻ tín dụng bị khóa ngay hôm sau.', 'big'); fx(l, { hap: -6, karma: 2 }); H.mem(l, 'Ngày nói "không" với con đường bố mẹ vạch sẵn.', 6); } },
      { k: 'deal', l: 'Thỏa hiệp: học ngành gia đình chọn, giữ đam mê riêng', ai: { w: 0.8, smart: 0.6 }, run: function (l, r, log) { l.flags.eliteChoice = true; l.flags.eliteFollow = true; l.flags.eliteBoost = eliteJob(l); l.flags.eliteSoft = true; log('Thỏa hiệp với gia đình: học ngành bố mẹ muốn, nhưng giữ cho mình khoảng trời riêng.', 'neutral'); } }
    ]
  });
  T('elite_dinh_huong', function (l, a) { return !!elite(l) && a >= 17 && a <= 19 && !l.flags.eliteChoice && free(l); }, 1);
  E.MAJOR.elite_dinh_huong = 1;
  // hôn nhân sắp đặt
  SC('elite_hon_nhan', {
    title: 'Mối hôn sự môn đăng hộ đối', prep: function (l, r) { var sx = H.partnerSex(l, r); return { n: H.stranger(l, r, sx), sex: sx, who: pick(r, ['con gái út một chủ tịch tập đoàn bất động sản', 'con trai một gia đình chủ ngân hàng', 'cháu nội một vị nguyên bộ trưởng', 'con một gia đình đại gia ngành thép']) }; },
    valid: function (l) { return follower(l) && !l.flags.eliteMarry && !(l.partner && l.partner.status !== 'dating'); },
    text: function (l, d) { return 'Gia đình sắp xếp cho bạn gặp ' + d.n + ' — ' + d.who + '. "Hai nhà mà thành thông gia thì cả hai cùng lớn mạnh."' + (l.partner ? ' Trong khi đó bạn đang yêu ' + l.partner.name + '.' : ''); },
    opts: [
      { k: 'yes', l: 'Đồng ý kết hôn theo sắp xếp', ai: { w: 1.2 }, run: function (l, r, log, d) { l.flags.eliteMarry = true; if (l.partner) { log('Chia tay ' + l.partner.name + ' trong nước mắt.', 'bad'); l.exes++; } l.partner = { name: d.n, sex: d.sex, age: l.age + U.randint(r, -2, 3), status: 'married', since: l.age, alive: true }; log('Đám cưới xa hoa ở khách sạn năm sao, báo chí gọi là "đám cưới thế kỷ". Hai gia đình bắt tay nhau.', 'big'); cashB(l, 20, 'Của hồi môn & quà cưới'); fx(l, { hap: -2 }); H.mem(l, 'Đám cưới thế kỷ với ' + d.n + ' — người bạn mới gặp vài lần.', 6); } },
      { k: 'love', l: function (l) { return l.partner ? 'Xin cưới người mình yêu' : 'Xin được tự tìm hiểu, tự yêu'; }, ai: { w: 0.8 }, run: function (l, r, log) { l.flags.eliteMarry = true; if (ch(r, 0.4)) { log('Bố mẹ giận suốt nửa năm, rồi cũng mềm lòng: "Miễn là con hạnh phúc."', 'good'); fx(l, { hap: 4 }); } else { l.flags.eliteCut = true; log('Bố mẹ tuyên bố: không nghe lời thì đừng hòng nhận một đồng nào. Bạn bị gạch tên khỏi ban điều hành.', 'bad'); fx(l, { hap: -6 }); if (l.job && jid(l) === eliteJob(l)) { l.job = null; l.flags.needJob = true; } } } }
    ]
  });
  T('elite_hon_nhan', function (l, a) { return follower(l) && a >= 23 && a <= 32 && !l.flags.eliteMarry && free(l); }, 0.3, 2);
  E.MAJOR.elite_hon_nhan = 1;
  // bị cắt chu cấp: về sau có cơ hội hòa giải
  SC('elite_hoa_giai', {
    title: 'Cuộc gọi từ nhà', valid: function (l) { return !!elite(l) && l.flags.eliteCut && !l.flags.eliteReconcile && (l.fam.fAlive || l.fam.mAlive); },
    text: function (l) { return (l.fam.fAlive ? 'Bố' : 'Mẹ') + ' giờ đã già, gọi bạn về nhà ăn cơm sau bao năm im lặng. "Về đi con, nhà này vẫn cần con."'; },
    opts: [
      { k: 'back', l: 'Về nhà, làm lành với gia đình', ai: { w: 1.2, soc: 1 }, run: function (l, r, log) { l.flags.eliteReconcile = true; l.flags.eliteCut = false; l.flags.eliteFollow = true; l.flags.eliteJobDone = false; l.flags.eliteBoost = eliteJob(l); log('Về nhà sau bao năm. Bố mẹ già đi nhiều quá. Cả nhà ngồi ăn cơm, không ai nhắc chuyện cũ.', 'big'); fx(l, { hap: 10 }); H.mem(l, 'Bữa cơm làm lành với bố mẹ sau bao năm xa cách.', 6); } },
      { k: 'no', l: 'Cảm ơn, nhưng con đã có cuộc đời riêng', ai: { w: 0.6 }, run: function (l, r, log) { l.flags.eliteReconcile = true; log('Bạn về thăm, nhưng từ chối quay lại guồng máy của gia đình.', 'neutral'); fx(l, { hap: 2 }); } }
    ]
  });
  T('elite_hoa_giai', function (l, a) { return !!elite(l) && l.flags.eliteCut && !l.flags.eliteReconcile && a >= 30 && (l.fam.fAlive || l.fam.mAlive) && free(l); }, 0.08, 3);
  // tranh quyền thừa kế với anh chị em
  SC('elite_tranh_quyen', {
    title: 'Cuộc chiến thừa kế', valid: function (l) { return follower(l) && !l.flags.eliteHeir && H.sibs && H.sibs(l).length > 0; },
    text: function (l) { var s = H.sibs(l)[0]; return 'Bố tuyên bố sẽ chọn người kế nhiệm. ' + U.cap(H.sibCall(l, s)) + ' cũng muốn chiếc ghế ấy, đã âm thầm gom phiếu các cổ đông.'; },
    opts: [
      { k: 'fight', l: 'Tranh đến cùng', ai: { amb: 1.2, risk: 0.6 }, run: function (l, r, log) { l.flags.eliteHeir = true; H.sibs(l).forEach(function (s) { s.close -= 30; }); if (ch(r, 0.5 + (l.st.kno - 50) / 150)) { l.flags.eliteSeat = true; log('Giành được sự ủng hộ của đa số cổ đông, bạn được chọn làm người kế nghiệp. Anh chị em từ đó không nhìn mặt nhau.', 'big'); } else log('Thua trong cuộc bỏ phiếu. Chiếc ghế thuộc về người khác.', 'bad'); } },
      { k: 'share', l: 'Đề nghị cùng điều hành, chia lĩnh vực', ai: { w: 1, soc: 1 }, run: function (l, r, log) { l.flags.eliteHeir = true; l.flags.eliteSeat = true; log('Anh chị em chia nhau điều hành từng mảng. Gia đình giữ được hòa khí.', 'good'); H.sibs(l).forEach(function (s) { s.close += 5; }); } },
      { k: 'yield', l: 'Nhường, chỉ giữ phần cổ phần của mình', ai: { w: 0.6 }, run: function (l, r, log) { l.flags.eliteHeir = true; log('Bạn rút lui, giữ cổ phần và sự bình yên.', 'neutral'); fx(l, { hap: 3 }); } }
    ]
  });
  T('elite_tranh_quyen', function (l, a) { return follower(l) && a >= 30 && a <= 55 && !l.flags.eliteHeir && H.sibs && H.sibs(l).length > 0 && free(l); }, 0.12, 3);
  E.MAJOR.elite_tranh_quyen = 1;

  function eliteYear(l, r, log, a) {
    var e = elite(l); if (!e) return;
    if (a === 0) eliteLog(l, a, r, log);
    // du học theo sắp xếp
    if (follower(l) && a >= 18 && a <= 20 && !l.flags.eliteStudy && l.edu >= 3 && !(l.abroad && l.abroad.perm)) {
      l.flags.eliteStudy = true;
      if (e.n === 'chính trị' && isVN(l)) { if (l.abroad && l.abroad.study) { l.abroad = null; l.uniCity = null; } l.major = 'law'; if (l.school !== 'uni') { l.school = 'uni'; l.schoolEnd = a + 4; } l.uniTier = Math.max(l.uniTier || 1, 1.25); log('Theo sắp xếp của gia đình, vào học ngành Luật ở một trường danh tiếng.', 'neutral'); }
      else { l.major = e.major; l.school = 'abroad'; l.schoolEnd = a + 4; l.abroad = { code: 'US', name: 'Hoa Kỳ', study: true, until: a + 4, pool: 'en' }; l.flags.studiedAbroad = 'Hoa Kỳ'; l.uniTier = 1.5; l.uniCity = 'Hoa Kỳ'; log('Theo sắp xếp của gia đình, sang Mỹ học Quản trị kinh doanh ở một trường danh tiếng. Có căn hộ riêng gần trường.', 'big'); }
      if (l.job) l.job = null;
    }
    // chu cấp
    if (follower(l) && a >= 16 && a <= 40) cashB(l, e.allow, 'Gia đình chu cấp');
    // ra trường: vào thẳng cơ nghiệp gia đình
    var ej = eliteJob(l);
    if (follower(l) && !l.school && a >= 21 && !(l.abroad && !l.abroad.perm) && (!l.job || jid(l) !== ej) && !l.flags.eliteJobDone && free(l)) {
      l.flags.eliteJobDone = true;
      if (l.abroad && l.abroad.study) l.abroad = null;
      E.startJob(l, ej, r, log, true); l.edu = Math.max(l.edu, 5); l.job.fam = true; // cơ nghiệp gia đình: không bị "cắt giảm nhân sự"
      log('Về ' + (e.n === 'chính trị' ? 'nhận công tác: ' : 'gia nhập cơ nghiệp gia đình: ') + E.jobTitle(l) + '. Ai cũng biết bạn là con ai.', 'big');
      H.mem(l, 'Ngày đầu tiên đi làm ở ' + (e.n === 'chính trị' ? 'cơ quan bố sắp xếp' : 'tòa nhà mang tên gia đình') + '.', 4);
    }
    // bố/mẹ có biến cố: bị kỷ luật (chính trị) hoặc làm ăn sa sút
    if (!l.flags.famFall && (l.fam.fAlive || l.fam.mAlive) && ch(r, e.n === 'chính trị' ? 0.01 : 0.004)) {
      l.flags.famFall = true;
      log(e.n === 'chính trị' ? 'Bố bị kỷ luật, cách hết chức vụ sau một đợt thanh tra. Những người từng tấp nập đến nhà bỗng biến mất.' : 'Tập đoàn của gia đình rơi vào khủng hoảng, cổ phiếu mất nửa giá trị, bố phải bán bớt tài sản.', 'bad');
      fx(l, { hap: -10 }); l.flags.eliteBoost = null; H.mem(l, 'Năm gia đình sa sút, mới biết ai là bạn thật.', 5);
    }
    // thừa kế khi bố mẹ đều đã mất
    if (!l.fam.fAlive && !l.fam.mAlive && !l.flags.eliteInherit && a >= 18) {
      l.flags.eliteInherit = true;
      if (l.flags.eliteCut) { log('Bố mẹ đã khuất. Bạn không có tên trong di chúc — cái giá của lần nói "không" năm ấy.', 'bad'); fx(l, { hap: -6 }); }
      else {
        var share = e.inherit * (l.flags.famFall ? 0.3 : 1) / Math.max(1, (H.sibs ? H.sibs(l).length : 0) + 1) * (l.flags.eliteSeat ? 1.5 : 1);
        l.assets = l.assets || {}; l.basis = l.basis || {};
        if (e.n === 'chính trị') { H.cash(l, share * l.base, 'Thừa kế'); log('Nhận phần thừa kế bố mẹ để lại: nhà cửa, đất đai ' + mo(l, share * l.base) + '.', 'good'); }
        else { l.assets.stock = (l.assets.stock || 0) + share * l.base; l.basis.stock = (l.basis.stock || 0) + share * l.base; log('Thừa kế cổ phần ' + (e.job === 'ngan_hang_cao' ? 'ngân hàng' : 'tập đoàn') + ' trị giá ' + mo(l, share * l.base) + '.', 'big'); }
        if (l.job && jid(l) === ej && (l.flags.eliteSeat || !(H.sibs && H.sibs(l).length)) && rank(l) < E.CAR[ej].t.length - 1) { l.job.rank = E.CAR[ej].t.length - 1; l.job.yrs = 0; log('Chính thức ngồi vào ghế ' + E.jobTitle(l) + '.', 'big'); H.mem(l, 'Ngày ngồi vào chiếc ghế của bố.', 6); }
      }
    }
  }

  // ===================================================================
  // ĐĂNG KÝ VÀO VÒNG NĂM
  // ===================================================================
  E.HOOKS.year.push(function (l, r, log, a) {
    if (hasJob(l, ['cong_an'])) policeBr(l, r);
    if (l.job && l.job.rep == null && (hasJob(l, ['tham_tu', 'luat_su', 'cong_an', 'bac_si', 'phong_vien', 'sale_bds']))) l.job.rep = 50;
    eliteYear(l, r, log, a);
  });
  // v2.8: đang làm chủ cửa hàng / quán mở bằng vốn riêng thì có thể chọn tập trung điều hành, không cần đi làm thuê
  var jobDec = E.DEC.job, jobMake = jobDec.make, jobApply = jobDec.apply;
  jobDec.make = function (life, r, arg) {
    var d = jobMake.call(this, life, r, arg), v = (life.ventures || [])[0];
    if (v && !life.job) d.opts.splice(d.opts.length - 1, 0, { k: 'own', l: 'Tập trung điều hành ' + v.n + ' của mình', h: 'Không đi làm thuê, sống bằng lãi kinh doanh' });
    return d;
  };
  jobDec.apply = function (life, d, k, r, log) {
    if (k === 'own') { life.flags.upgradeJob = false; life.flags.needJob = false; life.flags.selfRun = true; log('Quyết định không đi làm thuê nữa, tập trung điều hành ' + ((life.ventures || [])[0] || { n: 'việc kinh doanh' }).n + ' của mình.', 'neutral'); return; }
    if (k !== 'none') life.flags.selfRun = false;
    return jobApply.call(this, life, d, k, r, log);
  };
  var jobAuto = jobDec.auto;
  jobDec.auto = function (life, d, r) { return d.opts.some(function (o) { return o.k === 'own'; }) && (life.ventures[0].cap > life.base * 2 || r() < 0.5) ? 'own' : jobAuto.call(this, life, d, r); };
  // đang giữ ghế trong cơ nghiệp gia đình thì không "nhảy việc" (muốn đi thì phải chủ động nghỉ việc)
  E.ACT.forEach(function (a) { if (a.id === 'tim_viec') { var av = a.avail; a.avail = function (l) { return l.job && l.job.fam ? 'Đang giữ vị trí trong cơ nghiệp gia đình' : av ? av(l) : true; }; } });
  // du học theo sắp xếp gia đình thì không ở lại định cư
  var dhv = E.DEC.du_hoc_ve && E.DEC.du_hoc_ve.def;
  if (dhv) dhv.opts.forEach(function (o) { if (o.k === 'stay') { var q = o.req; o.req = function (l, d) { return !follower(l) && (!q || q(l, d)); }; } });
  // childOpts: đời con tiếp nối gia đình siêu giàu (nếu chưa bị cắt chu cấp)
  var oldChild = E.childOpts;
  E.childOpts = function (l, k) { var o = oldChild(l, k); if (elite(l) && !l.flags.eliteCut) o.parent.elite = l.fam.elite; return o; };
  E.jobs = { PATHS: PATHS, ELITE: ELITE, pathFor: pathFor, policeBr: policeBr, elite: elite, eliteJob: eliteJob, eliteYear: eliteYear };
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
/* ===== js/childhood.js ===== */
/* Một Đời — v2.5: tuổi thơ 0–15 đa dạng hơn: nhiều tình huống ngẫu nhiên theo độ tuổi, giới tính, nông thôn/thành thị, giàu/nghèo;
   các dòng kể chuyện không lặp lại trong cùng một đời. */
(function (G) {
  'use strict';
  var U = G.U, E = G.E, H = E.H, SC = E.SC, isVN = H.isVN;
  function fx(l, o) { H.fx(l, o); }
  function cashB(l, x, why) { H.cash(l, x * l.base, why); }
  function pick(r, a) { return U.pick(r, a); }
  function ch(r, p) { return r() < p; }
  function free(l) { return !(l.jailUntil != null && l.age < l.jailUntil) && !(l.abroad && l.abroad.trapped); }
  function boy(l) { return l.sex === 'M'; }
  function girl(l) { return l.sex === 'F'; }
  function sexW(l, m, f) { return boy(l) ? m : f; }
  function mom(l) { return l.fam.mAlive ? 'mẹ' : l.fam.fAlive ? 'bố' : 'bà'; }
  function dad(l) { return l.fam.fAlive && !l.fam.noDad ? 'bố' : l.fam.mAlive ? 'mẹ' : 'ông'; }
  function rich(l) { return l.fam.q >= 4; }
  function poor(l) { return l.fam.q <= 2; }
  function talent(l, t, p, r) { if (!l.talent && r() < p) l.talent = t; if (l.talent === t) l.skill = Math.min(100, (l.skill || 20) + 4); }
  // tình huống tuổi thơ: cw có thể là hàm (theo giới tính, hoàn cảnh)
  function CT(id, when, cd, cw) { E.TRIG.push({ id: id, when: function (l, a) { return free(l) && when(l, a); }, p: function (l, a) { var w = typeof cw === 'function' ? cw(l, a) : (cw || 1); return 0.1 * Math.min(1.5, w); }, cd: cd || 3, child: true, cw: cw || 1 }); } // v3.7: xác suất xuất hiện cũng theo trọng số (giới tính, hoàn cảnh)
  // chọn câu chưa dùng trong đời này → không lặp lại
  function fresh(l, r, arr) {
    var seen = l.flags.kidSeen || (l.flags.kidSeen = []);
    var ok = arr.filter(function (t) { return t && seen.indexOf(t) < 0; });
    if (!ok.length) return null;
    var t = pick(r, ok); seen.push(t); if (seen.length > 120) seen.shift();
    return t;
  }

  // ===================================================================
  // 1. NHỮNG DÒNG KỂ CHUYỆN NHỎ (không cần lựa chọn) — chia theo tuổi, giới tính, hoàn cảnh
  // ===================================================================
  function kidLines(l, a) {
    var vn = isVN(l), m = mom(l), d = dad(l), L = [];
    if (a <= 1) L.push('Lần đầu biết lẫy, cả nhà vỗ tay rần rần.', 'Mọc chiếc răng sữa đầu tiên, đêm nào cũng quấy khóc.', (l.fam.mAlive ? 'Bập bẹ tiếng đầu tiên — là "bà", không phải "mẹ".' : 'Bập bẹ tiếng đầu tiên — là "bà".'), 'Lần đầu ăn dặm, phun cháo đầy mặt ' + m + '.', 'Nắm chặt ngón tay ' + d + ' không chịu buông.');
    if (a >= 1 && a <= 3) L.push('Biết vẫy tay "bai bai" với khách đến nhà.', 'Ôm chặt chiếc chăn nhỏ đi khắp nhà, không cho ai giặt.', 'Bị ngã u đầu khi chạy theo con mèo.', 'Lần đầu được đi sở thú, sợ khóc thét khi thấy con voi.', 'Học được câu hát đầu tiên, hát đi hát lại cả ngày.', 'Lén bốc vụng đường trong hũ, bị bắt quả tang.');
    if (a >= 3 && a <= 6) {
      L.push('Hỏi "tại sao?" đến cả trăm lần mỗi ngày.', 'Vẽ lên tường nhà một "bức tranh" to đùng, bị mắng một trận.', 'Có một người bạn tưởng tượng tên là "Bin".', 'Sợ ma, tối nào cũng đòi ngủ với ' + m + '.', 'Lần đầu tự buộc được dây giày.', 'Rụng chiếc răng sữa đầu tiên, ' + (vn ? 'ném lên mái nhà theo lời bà dặn.' : 'giấu dưới gối chờ "tiên răng".'));
      L.push(sexW(l, 'Mặc áo choàng siêu nhân, nhảy từ ghế xuống đất "bay".', 'Lấy khăn của mẹ quấn làm váy công chúa, đi diễn khắp nhà.'), sexW(l, 'Mê xe máy xúc, đứng xem công trình cả buổi.', 'Tết tóc cho búp bê, bắt cả nhà khen đẹp.'));
      if (!l.urban) L.push('Theo ' + d + ' ra đồng bắt châu chấu, cào cào.', 'Lần đầu được cưỡi lên lưng trâu.');
      else L.push('Được ' + d + ' chở đi một vòng phố đêm, mắt tròn xoe nhìn đèn.', 'Lần đầu đi thang máy, nắm chặt tay ' + m + '.');
    }
    if (a >= 6 && a <= 10) {
      L.push('Được cô khen chữ đẹp, về khoe cả nhà.', 'Lần đầu bị điểm kém, giấu sổ liên lạc dưới gầm giường.', 'Đổi được bộ sưu tập thẻ bài hiếm nhất lớp.', 'Bị cô phạt đứng góc lớp vì nói chuyện riêng.', 'Ốm sốt mấy ngày, được ' + m + ' nấu cháo hành.', 'Lần đầu ngủ lại nhà bạn, nửa đêm khóc đòi về.');
      if (boy(l)) L.push('Chơi bắn bi, đánh khăng với tụi con trai cả buổi chiều.', 'Thả diều trên đê đến khi trời tối mịt.', 'Bị bạn gái cùng bàn kẻ "đường biên giới" giữa bàn.', 'Leo cây bị ngã, trầy hết đầu gối.', 'Đá bóng bằng quả bưởi trong sân.');
      else L.push('Nhảy dây, chơi ô ăn quan với đám bạn gái giờ ra chơi.', 'Sưu tầm cả hộp giấy viết thư thơm.', 'Học tết tóc cho em, cho bạn.', 'Chơi đồ hàng, nấu "cơm" bằng lá cây với hoa dại.', 'Được bà dạy thêu chiếc khăn tay đầu tiên.');
      if (!l.urban) L.push('Đi bắt cá, mò cua ngoài ruộng về khoe ' + m + '.', 'Chăn trâu, thả diều trên bờ đê lộng gió.', 'Mùa gặt theo ' + m + ' ra đồng, nằm trên đống rơm ngắm trời.');
      else L.push('Đi học thêm tiếng Anh mỗi tối, ngồi sau xe ' + m + ' ngủ gật.', 'Được dẫn đi siêu thị, chọn được một món đồ ăn vặt.');
      if (poor(l)) L.push(E.hasOlderSib && !E.hasOlderSib(l) ? 'Mặc lại quần áo cũ người quen cho, ống quần xắn mấy vòng.' : 'Mặc lại quần áo cũ của anh chị, ống quần xắn mấy vòng.', 'Mơ ước có một đôi giày mới đi học.');
      if (rich(l)) L.push('Được đi du lịch nước ngoài cùng gia đình dịp hè.', 'Học piano mỗi tối thứ Ba, thứ Năm.');
    }
    if (a >= 10 && a <= 15) {
      L.push('Lần đầu được làm lớp trưởng, oai lắm.', 'Thức khuya đọc trộm truyện dưới chăn bằng đèn pin.', 'Viết nhật ký, khóa bằng ổ khóa nhỏ xíu.', 'Cãi nhau với bạn thân rồi làm lành sau ba ngày.', 'Bị ' + m + ' tịch thu điện thoại vì thức khuya.', 'Lần đầu đi chơi xa cùng lớp, cả đêm không ngủ.', 'Vỡ giọng, bị cả lớp trêu.');
      if (boy(l)) L.push('Lần đầu đạp xe thả dốc, tim muốn nhảy ra ngoài.', 'Tụ tập đá bóng sau giờ học đến tối mịt.', 'Lén tập hút thử điếu thuốc của ai đó rồi ho sặc sụa — và không bao giờ thử lại.', 'Cao vọt lên, quần áo năm ngoái đã ngắn cũn.');
      else L.push('Mê đọc truyện ngôn tình, khóc sưng mắt.', 'Lần đầu được ' + m + ' dẫn đi mua áo ngực, ngại đỏ mặt.', 'Cùng nhóm bạn gái chụp ảnh "sống ảo" ở quán trà sữa.', 'Tập trang điểm theo video trên mạng, bị ' + m + ' bắt rửa mặt.', 'Có ' + (l.orient === 'straight' ? 'cậu bạn' : 'người bạn') + ' lớp bên cạnh hay đứng đợi ở cổng trường.');
      if (!l.urban && poor(l)) L.push('Sau giờ học phụ ' + m + ' cắt cỏ, nấu cám heo.', 'Đi bộ mấy cây số đến trường, chiều về chân rã rời.');
    }
    return L;
  }
  E.EVENTS.push({ c: function (l, a) { return a >= 0 && a <= 15 && free(l); }, p: function (l, a) { return a <= 5 ? 0.75 : 0.5; }, run: function (l, a, r, log) {
    var t = fresh(l, r, kidLines(l, a)); if (!t) return;
    log(t, /mắng|phạt|kém|ốm|ngã|khóc|sợ|ho sặc|rã rời/.test(t) ? 'neutral' : 'good');
    if (/u đầu|ngã|trầy/.test(t)) fx(l, { hea: -1 }); else fx(l, { hap: 1 });
    if (r() < 0.15) H.mem(l, t, 2);
  } });

  // ===================================================================
  // 2. TÌNH HUỐNG CÓ LỰA CHỌN
  // ===================================================================
  SC('nhat_vi_be', {
    title: 'Chiếc ví rơi trên đường', prep: function (l, r) { return { x: pick(r, [0.005, 0.01, 0.02]) }; },
    text: 'Trên đường đi học về, bạn nhặt được một chiếc ví, bên trong có kha khá tiền và tấm thẻ căn cước.',
    opts: [
      { k: 'return', l: 'Mang đến đồn công an / trả lại', run: function (l, r, log) { fx(l, { karma: 5, hap: 2 }); log('Mang ví đến công an phường. Người mất tìm đến cảm ơn'+(l.school?', còn viết thư khen gửi nhà trường.':', gửi tặng bạn một lá thư cảm ơn.'), 'good'); H.mem(l, l.school?'Lá thư khen của nhà trường vì nhặt được của rơi trả người đánh mất.':'Lá thư cảm ơn vì nhặt được của rơi trả người đánh mất.', 3); } },
      { k: 'keep', l: 'Giữ lại tiền, vứt ví đi', run: function (l, r, log, d) { cashB(l, d.x, 'Tiền nhặt được'); fx(l, { karma: -5 }); log('Giữ lại tiền. Mấy hôm liền không dám nhìn vào mắt ' + mom(l) + '.', 'neutral'); } },
      { k: 'parent', l: function (l) { return 'Mang về đưa ' + (l.fam.mAlive && l.fam.fAlive ? 'bố mẹ' : mom(l)); }, run: function (l, r, log) { fx(l, { karma: 3 }); log('Mang về nhà. Cả nhà cùng đi tìm người đánh rơi.', 'good'); } }
    ]
  });
  CT('nhat_vi_be', function (l, a) { return a >= 7 && a <= 14 && l.school; }, 99);

  SC('trom_xoai', {
    title: 'Cây xoài nhà hàng xóm', text: 'Cây xoài nhà ông Tư sai trĩu quả, chìa cả sang bờ rào. Tụi bạn rủ trưa nay lúc ông ngủ thì trèo hái.',
    opts: [
      { k: 'go', l: 'Trèo lên hái', run: function (l, r, log) { if (ch(r, 0.3)) { log('Bị chó nhà ông Tư đuổi chạy té khói, rách cả quần.', 'bad'); fx(l, { hap: -2 }); H.mem(l, 'Trưa hè bị chó đuổi vì trèo hái trộm xoài.', 3); } else if (ch(r, 0.15)) { log('Trượt chân ngã từ trên cây xuống, bong gân cổ chân.', 'bad'); fx(l, { hea: -5 }); } else { log('Cả bọn ngồi bờ mương chấm xoài xanh với muối ớt, chua tê đầu lưỡi.', 'good'); fx(l, { hap: 4, soc: 2 }); H.mem(l, 'Những trưa hè chấm xoài xanh với muối ớt.', 3); } } },
      { k: 'watch', l: 'Đứng dưới canh chừng', run: function (l, r, log) { log('Đứng canh, được chia hai quả xoài.', 'neutral'); fx(l, { hap: 2 }); } },
      { k: 'ask', l: 'Sang xin ông Tư đàng hoàng', run: function (l, r, log) { fx(l, { karma: 3 }); log('Sang xin, ông Tư cười rồi hái cho cả rổ.', 'good'); } }
    ]
  });
  CT('trom_xoai', function (l, a) { return a >= 6 && a <= 12 && !l.urban; }, 99, function (l) { return boy(l) ? 1.4 : 0.8; });

  SC('tam_song', {
    title: 'Trưa hè oi ả', text: function (l) { return 'Tụi bạn rủ ra ' + (l.coast ? 'biển' : 'sông') + ' tắm cho mát. Người lớn vẫn dặn chỗ đó có xoáy nước.'; },
    opts: [
      { k: 'swim', l: 'Đi tắm cùng tụi bạn', run: function (l, r, log) { if (!l.flags.swim && ch(r, 0.04)) { if (ch(r, 0.25)) { H.kill(l, 'đuối nước', log, true); return; } log('Bị đuối nước, may được người lớn kéo lên kịp.', 'bad'); fx(l, { hea: -10 }); H.mem(l, 'Lần suýt chết đuối năm ' + l.age + ' tuổi.', 6); } else { log('Tắm sông cả buổi chiều, về bị ' + mom(l) + ' cầm roi đứng đợi ở cổng.', 'neutral'); fx(l, { hap: 3 }); } } },
      { k: 'no', l: 'Không đi, nhớ lời người lớn dặn', run: function (l, r, log) { log('Ở nhà. Chiều hôm ấy cả xóm xôn xao vì có đứa trẻ suýt đuối nước.', 'neutral'); fx(l, { karma: 1 }); } },
      { k: 'learn', l: 'Xin bố mẹ cho đi học bơi tử tế', run: function (l, r, log) { l.flags.swim = true; log('Được cho đi học bơi ở hồ bơi huyện. Giờ đã bơi được ếch.', 'good'); fx(l, { hea: 2 }); } }
    ]
  });
  CT('tam_song', function (l, a) { return a >= 8 && a <= 14 && !l.urban && isVN(l); }, 4, function (l) { return boy(l) ? 1.3 : 0.6; });

  SC('ban_moi', {
    title: 'Bạn mới chuyển đến', prep: function (l, r) { var s = r() < 0.5 ? 'M' : 'F'; return { n: H.stranger(l, r, s), s: s, why: pick(r, ['nói giọng vùng khác', 'mặc đồ cũ sờn', 'nhút nhát, ít nói', 'đeo kính dày cộp']) }; },
    text: function (l, d) { return 'Lớp có ' + (d.s === 'M' ? 'bạn nam' : 'bạn nữ') + ' mới tên ' + d.n + ' chuyển đến, ' + d.why + '. Mấy đứa trong lớp bắt đầu trêu chọc.'; },
    opts: [
      { k: 'friend', l: 'Rủ bạn ấy chơi cùng', run: function (l, r, log, d) { fx(l, { karma: 4, soc: 3 }); log('Rủ ' + d.n + ' chơi cùng nhóm. Bạn ấy cười lần đầu tiên từ ngày chuyển đến.', 'good'); if (!l.bff && ch(r, 0.4)) { l.bff = { name: d.n, sex: d.s, since: l.age, alive: true, close: 70, token: 'chiếc ảnh chụp chung năm lớp ' + Math.max(1, l.age - 5) }; log('Từ đó ' + d.n + ' thành bạn thân nhất của bạn.', 'good'); H.mem(l, 'Ngày quen ' + d.n + ' — người bạn mới chuyển đến.', 4); } } },
      { k: 'ignore', l: 'Mặc kệ, không phải việc của mình', run: function (l, r, log) { log('Không tham gia, cũng không bênh.', 'neutral'); } },
      { k: 'join', l: 'Hùa theo cả lớp trêu', run: function (l, r, log, d) { fx(l, { karma: -5 }); log('Hùa theo trêu ' + d.n + '. Tối về nằm nghĩ mãi, thấy áy náy.', 'bad'); H.mem(l, 'Lần hùa theo cả lớp trêu ' + d.n + ' — điều bạn ân hận.', 3); } }
    ]
  });
  CT('ban_moi', function (l, a) { return a >= 7 && a <= 13 && l.school; }, 99);

  SC('hoi_khoe', {
    title: 'Hội khỏe Phù Đổng', prep: function (l, r) { return { m: pick(r, boy(l) ? ['chạy 100 mét', 'nhảy xa', 'bóng đá mini', 'đá cầu'] : ['chạy 60 mét', 'nhảy dây', 'cầu lông', 'đá cầu']) }; },
    text: function (l, d) { return 'Trường tổ chức Hội khỏe Phù Đổng. Thầy thể dục gọi bạn vào đội tuyển môn ' + d.m + '.'; },
    opts: [
      { k: 'join', l: 'Đăng ký thi, tập luyện mỗi chiều', run: function (l, r, log, d) { fx(l, { hea: 3 }); if (ch(r, 0.25 + (l.talent === 'thể thao' ? 0.35 : 0))) { log('Giành huy chương vàng môn ' + d.m + ' cấp huyện!', 'big'); talent(l, 'thể thao', 0.3, r); fx(l, { hap: 6 }); H.mem(l, 'Tấm huy chương ' + d.m + ' Hội khỏe Phù Đổng.', 4); } else log('Thi ' + d.m + ' nhưng không có giải. Vui vì được cả lớp cổ vũ.', 'neutral'); } },
      { k: 'cheer', l: 'Từ chối, đứng ngoài cổ vũ', run: function (l, r, log) { log('Ngồi hàng ghế cổ vũ, hét khản cả cổ.', 'neutral'); fx(l, { soc: 2 }); } }
    ]
  });
  CT('hoi_khoe', function (l, a) { return a >= 8 && a <= 14 && l.school && isVN(l); }, 3);

  SC('ve_tranh', {
    title: 'Cuộc thi vẽ tranh', prep: function (l, r) { return { t: pick(r, ['Em yêu biển đảo quê hương', 'Ngôi nhà mơ ước', 'Thành phố tương lai', 'Gia đình em', 'Bảo vệ môi trường']) }; },
    text: function (l, d) { return 'Trường phát động cuộc thi vẽ tranh chủ đề "' + d.t + '".'; },
    opts: [
      { k: 'draw', l: 'Thức khuya vẽ thật kỹ', run: function (l, r, log, d) { if (ch(r, 0.25 + (l.talent === 'hội họa' ? 0.45 : 0))) { log('Bức tranh "' + d.t + '" đoạt giải nhất, được treo ở phòng truyền thống.', 'big'); talent(l, 'hội họa', 0.4, r); fx(l, { hap: 6 }); H.mem(l, 'Bức tranh đoạt giải được treo ở trường.', 4); } else { log('Nộp tranh, được giải khuyến khích.', 'good'); fx(l, { hap: 2 }); talent(l, 'hội họa', 0.1, r); } } },
      { k: 'help', l: function (l) { return 'Nhờ ' + (l.fam.mAlive && l.fam.fAlive ? 'bố mẹ' : mom(l)) + ' vẽ giúp'; }, run: function (l, r, log) { fx(l, { karma: -2 }); log(ch(r, 0.4) ? 'Tranh "bố mẹ vẽ" đẹp quá, cô giáo nhìn là biết ngay.' : 'Bức tranh được giải ba. Bạn biết đó không phải tranh của mình.', 'neutral'); } },
      { k: 'skip', l: 'Không tham gia', run: function (l, r, log) { log('Bỏ qua cuộc thi vẽ.', 'neutral'); } }
    ]
  });
  CT('ve_tranh', function (l, a) { return a >= 6 && a <= 12 && l.school; }, 4);

  SC('sinh_nhat', {
    title: 'Sinh nhật', prep: function (l, r) { return { n: l.age }; },
    text: function (l, d) { return 'Sắp đến sinh nhật ' + d.n + ' tuổi. ' + (poor(l) ? 'Nhà không dư dả gì.' : rich(l) ? 'Bố mẹ hỏi con muốn tổ chức thế nào.' : 'Bạn ước có một bữa tiệc nhỏ.'); },
    opts: [
      { k: 'party', l: function (l) { return rich(l) ? 'Tổ chức tiệc ở nhà hàng, mời cả lớp' : 'Mời vài đứa bạn thân đến nhà'; }, req: function (l) { return !poor(l); }, run: function (l, r, log) { cashB(l, rich(l) ? -0.03 : -0.005, 'Tiệc sinh nhật'); fx(l, { hap: 5, soc: 3 }); log(rich(l) ? 'Tiệc sinh nhật ở nhà hàng, có cả ảo thuật gia. Cả lớp trầm trồ.' : 'Mấy đứa bạn đến nhà, cùng thổi nến, ăn bánh kem.', 'good'); if (ch(r, 0.25)) H.mem(l, 'Bữa tiệc sinh nhật ' + l.age + ' tuổi.', 2); } },
      { k: 'simple', l: 'Chỉ cần ' + 'cả nhà ăn một bữa cơm', run: function (l, r, log) { fx(l, { hap: 3 }); var M = mom(l).charAt(0).toUpperCase() + mom(l).slice(1); log(poor(l) ? pick(r, [M + ' luộc cho quả trứng, cắm một cây nến lên bát xôi. Bạn nhớ mãi.', M + ' nấu nồi chè đậu đen, cả nhà ngồi hát chúc mừng sinh nhật.', 'Được ' + mom(l) + ' mua cho gói bánh và một que kem — vậy là vui cả ngày.']) : pick(r, ['Cả nhà ăn bữa cơm, ' + mom(l) + ' mua cái bánh kem nhỏ.', 'Cả nhà đi ăn lẩu, thổi nến trên chiếc bánh kem có tên mình.', M + ' tự tay làm bánh, vẽ chữ chúc mừng méo xệch mà ngon lạ.']), 'good'); if (poor(l)) H.mem(l, 'Cây nến cắm trên bát xôi ngày sinh nhật.', 4); } },
      { k: 'gift', l: 'Xin một món quà thay vì tiệc', run: function (l, r, log) { var g = pick(r, boy(l) ? ['bộ lego', 'quả bóng đá', 'xe đạp mới', 'bộ truyện tranh'] : ['con gấu bông to', 'bộ bút màu', 'chiếc váy mới', 'bộ truyện tranh']); fx(l, { hap: 4 }); log('Được tặng ' + g + ' — món quà sinh nhật nhớ nhất tuổi thơ.', 'good'); } }
    ]
  });
  CT('sinh_nhat', function (l, a) { return a >= 4 && a <= 13; }, 3);

  SC('to_ong', {
    title: 'Tổ ong trên cây', text: 'Đám bạn phát hiện một tổ ong vò vẽ to bằng quả bưởi trên cây sau nhà, rủ nhau lấy que chọc.',
    opts: [
      { k: 'poke', l: 'Chọc thử xem sao', run: function (l, r, log) { if (ch(r, 0.55)) { log('Ong vỡ tổ bay ra, bị đốt sưng vù mặt, phải đi trạm xá.', 'bad'); fx(l, { hea: -6, hap: -3 }); H.mem(l, 'Lần bị ong đốt sưng mặt vì chọc tổ ong.', 3); } else { log('Chọc xong cả bọn chạy thục mạng, may không ai bị đốt.', 'neutral'); fx(l, { hap: 2 }); } } },
      { k: 'tell', l: 'Về báo người lớn', run: function (l, r, log) { fx(l, { karma: 2 }); log('Về báo người lớn. ' + 'Tối đó ' + dad(l) + ' gọi người đến đốt tổ ong.', 'good'); } }
    ]
  });
  CT('to_ong', function (l, a) { return a >= 5 && a <= 11 && !l.urban; }, 99, function (l) { return boy(l) ? 1.3 : 0.6; });

  SC('dien_thoai_be', {
    title: function (l) { return 'Chiếc điện thoại của ' + mom(l); }, text: function (l) { return 'Nhân lúc ' + mom(l) + ' ngủ trưa, bạn lén lấy điện thoại. Mật khẩu là ngày sinh của bạn.'; },
    opts: [
      { k: 'yt', l: 'Xem hoạt hình trên mạng', run: function (l, r, log) { fx(l, { hap: 2, kno: -1 }); log('Xem hoạt hình liền ba tiếng, mắt đỏ hoe.', 'neutral'); } },
      { k: 'game', l: 'Tải game về chơi', run: function (l, r, log) { if (ch(r, 0.25)) { cashB(l, -0.01, 'Lỡ nạp tiền trong game'); log('Bấm nhầm nạp tiền trong game, tài khoản ' + mom(l) + ' bị trừ cả trăm nghìn. Ăn một trận đòn nhớ đời.', 'bad'); fx(l, { hap: -4 }); } else { log('Chơi game cả buổi chiều, giấu điện thoại về chỗ cũ trót lọt.', 'neutral'); fx(l, { hap: 2 }); } } },
      { k: 'no', l: 'Thôi, trả lại chỗ cũ', run: function (l, r, log) { fx(l, { karma: 1 }); log('Đặt điện thoại về chỗ cũ, ra sân chơi.', 'neutral'); } }
    ]
  });
  CT('dien_thoai_be', function (l, a) { return a >= 4 && a <= 9 && (l.urban || l.fam.q >= 3) && (l.fam.mAlive || l.fam.fAlive); }, 99);

  SC('da_bong_vo_kinh', {
    title: 'Quả bóng bay qua cửa kính', text: 'Đang đá bóng ngoài ngõ, bạn sút một quả thật mạnh — "choang!" — cửa kính nhà bác hàng xóm vỡ tan.',
    opts: [
      { k: 'admit', l: 'Sang nhận lỗi', run: function (l, r, log) { fx(l, { karma: 4 }); cashB(l, -0.005, 'Đền cửa kính'); log('Sang nhận lỗi, ' + dad(l) + ' đền tiền kính. Bác hàng xóm còn khen thật thà.', 'good'); } },
      { k: 'run', l: 'Cả bọn bỏ chạy', run: function (l, r, log) { fx(l, { karma: -3 }); if (ch(r, 0.5)) { log('Bác hàng xóm cầm quả bóng sang tận nhà. Bị ' + dad(l) + ' phạt quỳ cả buổi.', 'bad'); fx(l, { hap: -3 }); } else log('Chạy thoát. Mất luôn quả bóng.', 'neutral'); } }
    ]
  });
  CT('da_bong_vo_kinh', function (l, a) { return a >= 7 && a <= 13 && boy(l); }, 99);

  SC('thach_danh', {
    title: 'Lời thách sau giờ học', prep: function (l, r) { return { n: H.stranger(l, r, 'M') }; },
    text: function (l, d) { return d.n + ' lớp bên cạnh thách bạn ra sau trường "nói chuyện" vì một câu đùa trên mạng.'; },
    opts: [
      { k: 'fight', l: 'Ra đánh nhau', run: function (l, r, log, d) { fx(l, { karma: -2 }); if (ch(r, 0.5)) { log('Đánh nhau một trận, mặt mũi bầm dập. Cả hai bị mời phụ huynh, viết bản kiểm điểm.', 'bad'); fx(l, { hea: -4, hap: -3 }); } else { log('Đánh thắng ' + d.n + '. Từ đó không ai dám trêu bạn — nhưng bị hạ hạnh kiểm.', 'neutral'); fx(l, { soc: 2 }); } } },
      { k: 'talk', l: 'Gặp nhưng nói chuyện cho ra lẽ', run: function (l, r, log, d) { fx(l, { karma: 3 }); log(ch(r, 0.6) ? 'Hóa ra hiểu lầm. Hai đứa bắt tay, sau thành bạn.' : 'Nói mãi không xong, nhưng cũng không ai động tay.', 'good'); } },
      { k: 'teacher', l: 'Báo thầy chủ nhiệm', run: function (l, r, log) { log('Báo thầy, thầy gọi cả hai lên hòa giải.', 'neutral'); fx(l, { soc: -1 }); } }
    ]
  });
  CT('thach_danh', function (l, a) { return a >= 11 && a <= 15 && l.school; }, 99, function (l) { return boy(l) ? 1.5 : 0.1; });

  SC('dua_xe_dap', {
    title: 'Con dốc đầu làng', text: 'Tụi bạn thách đua xe đạp thả dốc, ai bóp phanh trước là thua.',
    opts: [
      { k: 'race', l: 'Đua, không bóp phanh', run: function (l, r, log) { if (ch(r, 0.25)) { log('Mất lái lao xuống ruộng, gãy tay phải bó bột cả tháng.', 'bad'); fx(l, { hea: -8 }); H.mem(l, 'Cánh tay bó bột sau lần thả dốc không phanh.', 3); } else { log('Về nhất! Gió thổi rát mặt, sướng run người.', 'good'); fx(l, { hap: 4, soc: 2 }); } } },
      { k: 'safe', l: 'Vừa đi vừa bóp phanh', run: function (l, r, log) { log('Thua cuộc, bị trêu "nhát gan". Nhưng không trầy xước gì.', 'neutral'); } }
    ]
  });
  CT('dua_xe_dap', function (l, a) { return a >= 10 && a <= 14 && boy(l) && !l.urban; }, 99);

  SC('kpop', {
    title: 'Thần tượng', prep: function (l, r) { return { n: l.idol || H.pickIdol(r, l) }; },
    text: function (l, d) { return 'Bạn mê ' + d.n + ' như điếu đổ. Album mới ra mắt, kèm thẻ ảnh có chữ ký — đắt bằng tiền tiêu vặt ba tháng.'; },
    opts: [
      { k: 'buy', l: 'Nhịn ăn sáng để mua', run: function (l, r, log, d) { if (!l.idol) l.idol = d.n; cashB(l, -0.004, 'Album ' + d.n); fx(l, { hap: 5, hea: -1 }); log('Ôm album ' + d.n + ' về, mở ra trúng đúng thẻ ảnh mình thích nhất. Hét ầm cả nhà.', 'good'); H.mem(l, 'Chiếc album ' + d.n + ' mua bằng tiền nhịn ăn sáng.', 3); } },
      { k: 'fanclub', l: 'Tham gia fanclub, cày view cho thần tượng', run: function (l, r, log, d) { if (!l.idol) l.idol = d.n; fx(l, { soc: 3, kno: -1 }); log('Thức khuya cày view, bình chọn cho ' + d.n + ' cùng hội bạn trên mạng.', 'neutral'); } },
      { k: 'no', l: 'Thôi, nghe nhạc thôi là đủ', run: function (l, r, log) { log('Chỉ nghe nhạc, dán poster trong phòng.', 'neutral'); } }
    ]
  });
  CT('kpop', function (l, a) { return a >= 11 && a <= 15 && (!!l.idol || !isVN(l)); }, 4, function (l) { return girl(l) ? 1.6 : 0.4; });

  SC('nau_com', {
    title: 'Lần đầu vào bếp', text: function (l) { return (l.fam.mAlive ? 'Mẹ' : 'Bố') + ' về muộn. Lần đầu tiên bạn tự nấu bữa tối cho cả nhà.'; },
    opts: [
      { k: 'cook', l: 'Nấu cơm, rán trứng, luộc rau', run: function (l, r, log) { if (ch(r, 0.35)) { log('Cơm khê, trứng cháy. Cả nhà vẫn ăn hết, còn khen ngon.', 'good'); } else log('Bữa cơm đầu tay tròn vị. ' + (l.fam.mAlive ? 'Mẹ' : 'Bố') + ' về ngạc nhiên lắm.', 'good'); fx(l, { hap: 3, karma: 2 }); H.mem(l, 'Bữa cơm đầu tiên tự tay nấu cho cả nhà.', 3); } },
      { k: 'noodle', l: 'Úp mì gói cho nhanh', run: function (l, r, log) { log('Úp gói mì, ăn xong ngồi chờ người lớn về.', 'neutral'); } }
    ]
  });
  CT('nau_com', function (l, a) { return a >= 9 && a <= 14 && (l.fam.mAlive || l.fam.fAlive); }, 99, function (l) { return girl(l) ? 1.3 : 0.9; });

  SC('son_moi', {
    title: 'Thỏi son của mẹ', text: function (l) { return 'Thấy mấy bạn trong lớp đánh son, bạn lén lấy thỏi son của ' + (l.fam.mAlive ? 'mẹ' : 'chị họ') + ' bỏ vào cặp.'; },
    opts: [
      { k: 'wear', l: 'Đánh son đi học', run: function (l, r, log) { if (ch(r, 0.5)) { log('Bị cô chủ nhiệm nhắc nhở trước lớp, xấu hổ đỏ mặt.', 'bad'); fx(l, { hap: -2 }); } else { log('Cả nhóm bạn khen xinh. Vui cả ngày.', 'good'); fx(l, { hap: 3, soc: 2 }); } talent(l, 'làm đẹp', 0.15, r); } },
      { k: 'ask', l: 'Xin mẹ dạy trang điểm nhẹ nhàng', req: function (l) { return l.fam.mAlive; }, run: function (l, r, log) { fx(l, { soc: 2 }); log('Mẹ cười, dạy bạn cách tô son nhẹ cho hợp tuổi. Hai mẹ con nói chuyện cả buổi tối.', 'good'); talent(l, 'làm đẹp', 0.2, r); } },
      { k: 'back', l: 'Trả lại chỗ cũ', run: function (l, r, log) { log('Lặng lẽ đặt thỏi son về bàn trang điểm.', 'neutral'); } }
    ]
  });
  CT('son_moi', function (l, a) { return a >= 12 && a <= 15 && girl(l); }, 99);

  SC('toc_dai', {
    title: 'Mái tóc', text: function (l) { return 'Hè này ' + mom(l) + ' muốn cắt tóc bạn thật ngắn cho mát, đỡ chấy. Bạn thì muốn nuôi tóc dài như mấy chị trong xóm.'; },
    opts: [
      { k: 'long', l: 'Năn nỉ được để tóc dài', run: function (l, r, log) { fx(l, { hap: 3 }); log('Được nuôi tóc dài, sáng nào cũng tự tết tóc đi học.', 'good'); } },
      { k: 'short', l: 'Cắt ngắn cho gọn', run: function (l, r, log) { log('Cắt tóc ngắn cũn, cả tuần không dám soi gương. Nhưng mà mát thật.', 'neutral'); } },
      { k: 'dye', l: 'Đòi nhuộm highlight như idol', run: function (l, r, log) { if (ch(r, 0.3)) { log('Được cho nhuộm mấy lọn tóc màu hồng. Đầu năm học bị nhà trường bắt nhuộm đen lại.', 'neutral'); fx(l, { hap: 2 }); } else { log('Bị mắng: "Học sinh nhuộm tóc cái gì!"', 'bad'); fx(l, { hap: -1 }); } } }
    ]
  });
  CT('toc_dai', function (l, a) { return a >= 7 && a <= 13 && girl(l) && (l.fam.mAlive || l.fam.fAlive); }, 99);

  SC('thu_nac_danh', {
    title: 'Lá thư không tên', text: 'Mở ngăn bàn, bạn thấy một lá thư gấp hình trái tim, không đề tên người gửi, chỉ ghi: "Tớ thích cậu từ hồi đầu năm."',
    opts: [
      { k: 'find', l: 'Âm thầm tìm xem ai gửi', run: function (l, r, log) { log(ch(r, 0.5) ? 'Nhận ra nét chữ của bạn cùng lớp ngồi bàn cuối. Hai đứa ngại không dám nhìn nhau.' : 'Tìm mãi không ra. Lá thư được cất kỹ trong hộp bút.', 'good'); fx(l, { hap: 4 }); H.mem(l, 'Lá thư gấp hình trái tim trong ngăn bàn năm ' + l.age + ' tuổi.', 3); } },
      { k: 'show', l: 'Đưa cho bạn thân xem', run: function (l, r, log) { log(ch(r, 0.4) ? 'Bạn thân lỡ miệng, cả lớp biết chuyện. Trêu suốt cả tháng.' : 'Hai đứa thì thầm đoán già đoán non cả buổi.', 'neutral'); fx(l, { soc: 1 }); } },
      { k: 'throw', l: 'Vứt đi, đang tuổi ăn tuổi học', run: function (l, r, log) { log('Vứt lá thư đi. Tự nhủ phải tập trung học.', 'neutral'); fx(l, { kno: 1 }); } }
    ]
  });
  CT('thu_nac_danh', function (l, a) { return a >= 11 && a <= 15 && l.school; }, 99, function (l) { return girl(l) ? 1.3 : 0.8; });

  SC('nap_game', {
    title: 'Skin mới ra mắt', prep: function (l, r) { return { g: l.game || pick(r, girl(l) ? ['Play Together', 'Roblox', 'Liên Quân Mobile', 'Minecraft'] : ['Liên Quân Mobile', 'Free Fire', 'PUBG Mobile', 'Mobile Legends: Bang Bang', 'Roblox', 'Minecraft']) }; },
    text: function (l, d) { return d.g + ' vừa ra skin giới hạn. Cả nhóm bạn đều có, chỉ mình bạn chưa.'; },
    opts: [
      { k: 'beg', l: 'Năn nỉ bố mẹ nạp tiền', run: function (l, r, log) { if (!poor(l) && ch(r, 0.4)) { cashB(l, -0.002, 'Nạp game'); log('Được nạp cho một lần, với điều kiện cuối kỳ phải học khá.', 'neutral'); fx(l, { hap: 3 }); } else { log('Bị từ chối thẳng: "Tiền đâu mà nạp game!"', 'neutral'); fx(l, { hap: -1 }); } } },
      { k: 'card', l: 'Lén lấy tiền mua thẻ cào', run: function (l, r, log) { fx(l, { karma: -4 }); if (ch(r, 0.5)) { log('Bị phát hiện lấy tiền trong ví. Ăn một trận đòn, bị cấm chơi game cả tháng.', 'bad'); fx(l, { hap: -5 }); } else { log('Nạp được skin mới. Nhưng lòng thấp thỏm mãi.', 'neutral'); fx(l, { hap: 2 }); } } },
      { k: 'no', l: 'Kệ, chơi đồ mặc định cũng được', run: function (l, r, log) { fx(l, { karma: 1 }); log('Chơi bằng trang phục mặc định, vẫn thắng đều.', 'good'); } }
    ]
  });
  CT('nap_game', function (l, a) { return a >= 9 && a <= 15; }, 4, function (l) { return l.talent === 'game' ? 2 : boy(l) ? 1 : 0.35; });

  SC('tiktok', {
    title: 'Video đầu tiên', prep: function (l, r) { return { t: pick(r, girl(l) ? ['nhảy theo bài hát đang hot', 'trang điểm biến hình', 'nấu món ăn vặt', 'hát cover'] : ['chơi game hài hước', 'tâng bóng', 'troll em ở nhà', 'hát cover']) }; },
    text: function (l, d) { return 'Bạn quay một video ' + d.t + ' đăng lên mạng.'; },
    opts: [
      { k: 'post', l: 'Đăng công khai', run: function (l, r, log, d) { if (ch(r, 0.08)) { log('Video ' + d.t + ' bất ngờ viral, cả trường nhận ra bạn!', 'big'); l.fame = (l.fame || 0) + 3000; fx(l, { hap: 6, soc: 3 }); H.mem(l, 'Video ' + d.t + ' viral năm ' + l.age + ' tuổi.', 4); } else if (ch(r, 0.15)) { log('Bị một nhóm vào bình luận chê bai ác ý. Buồn mất mấy hôm.', 'bad'); fx(l, { hap: -4 }); if (l.mind) l.mind.stress += 5; } else { log('Video được vài trăm lượt xem, đủ vui.', 'neutral'); fx(l, { hap: 2 }); } } },
      { k: 'friends', l: 'Chỉ để chế độ bạn bè', run: function (l, r, log) { log('Chỉ bạn bè xem, ai cũng thả tim.', 'good'); fx(l, { hap: 2 }); } }
    ]
  });
  CT('tiktok', function (l, a) { return a >= 12 && a <= 15 && (l.urban || l.fam.q >= 3); }, 99);

  SC('meo_ket', {
    title: 'Chú mèo trên cây', text: 'Một chú mèo con kêu thảm thiết trên ngọn cây trước cổng trường, không trèo xuống được.',
    opts: [
      { k: 'climb', l: 'Trèo lên cứu', run: function (l, r, log) { if (ch(r, 0.2)) { log('Cứu được mèo nhưng bị cào xước cả tay, lại ngã trầy chân.', 'neutral'); fx(l, { hea: -2, karma: 3 }); } else { log('Trèo lên ôm được chú mèo xuống. Cả đám học sinh vỗ tay.', 'good'); fx(l, { karma: 4, hap: 3 }); } H.chain(l, 'meo_theo'); } },
      { k: 'adult', l: 'Gọi bác bảo vệ giúp', run: function (l, r, log) { log('Bác bảo vệ bắc thang đưa mèo xuống. Bạn ôm chú mèo vào lòng vuốt ve mãi.', 'good'); fx(l, { karma: 2 }); H.chain(l, 'meo_theo'); } },
      { k: 'leave', l: 'Đi qua, sợ muộn học', run: function (l, r, log) { log('Đi qua, cả buổi học cứ nghĩ đến chú mèo.', 'neutral'); } }
    ]
  });
  CT('meo_ket', function (l, a) { return a >= 6 && a <= 13 && l.school; }, 99);
  // v6.5: chú mèo mến bạn — được chọn mang về hay không, mang về thì có thú cưng thật và đặt tên
  SC('meo_theo', {
    title: 'Chú mèo đi theo bạn',
    text: function (l) { return 'Tan học, chú mèo con cứ lẽo đẽo đi theo sau, dụi đầu vào chân bạn rồi kêu meo meo. Có vẻ nó đã mến bạn và muốn được về với bạn.' + (H.pets(l).length >= 3 ? ' Nhưng nhà đã nuôi khá nhiều con vật rồi.' : ''); },
    opts: [
      { k: 'take', l: 'Ôm mèo về, xin bố mẹ cho nuôi', h: function (l) { return H.pets(l).length >= 3 ? 'Nhà đã đủ thú cưng' : 'Có thêm một người bạn nhỏ · được đặt tên'; }, req: function (l) { return H.pets(l).length < 3; }, ai: { soc: 1, w: 1.3 }, run: function (l, r, log) { var p = H.addPet(l, r, 'mèo', 'mèo ta', pick(r, ['Mun', 'Cam', 'Bé Mèo', 'Sữa', 'Mướp', 'Bông'])); log((l.fam.q <= 1 ? 'Bố mẹ thở dài vì nhà còn chật vật, nhưng rồi cũng gật đầu. ' : 'Bố mẹ mỉm cười gật đầu. ') + 'Từ nay nhà có thêm chú mèo ' + p.n + '.', 'good'); fx(l, { hap: 5, karma: 1 }); l.flags.meoTheo = true; H.mem(l, 'Ôm chú mèo con đi theo mình từ cổng trường về nhà.', 3); } },
      { k: 'friend', l: 'Nhờ bạn cùng lớp mang về nuôi giúp', ai: { w: 0.8 }, run: function (l, r, log) { log('Đứa bạn thân reo lên nhận nuôi. Thỉnh thoảng bạn lại sang nhà nó chơi với chú mèo.', 'good'); fx(l, { hap: 2, soc: 1 }); } },
      { k: 'leave', l: 'Vuốt ve rồi để nó ở lại trường', ai: { w: 0.6 }, run: function (l, r, log) { log('Bạn vuốt ve chú mèo rồi đi về. Mấy hôm sau, bác bảo vệ bắt đầu cho nó ăn cơm thừa.', 'neutral'); } }
    ]
  });

  SC('chuyen_ma', {
    title: 'Đêm kể chuyện ma', text: 'Mất điện. Đám trẻ trong xóm ngồi quây quần, thằng lớn nhất bắt đầu kể chuyện ma ở cây đa đầu làng.',
    opts: [
      { k: 'listen', l: 'Ngồi nghe đến hết', run: function (l, r, log) { log(ch(r, 0.5) ? 'Nghe xong cả đêm không dám đi vệ sinh một mình.' : 'Nghe xong cười ha hả, chẳng sợ gì.', 'neutral'); fx(l, { soc: 2 }); } },
      { k: 'dare', l: 'Nhận lời thách ra cây đa một mình', run: function (l, r, log) { fx(l, { soc: 3 }); if (ch(r, 0.3)) { log('Ra đến nơi thì một con cú vụt bay ra, chạy về một mạch, ngã trầy đầu gối.', 'neutral'); fx(l, { hea: -2 }); } else { log('Ra cây đa một mình rồi về, được cả bọn phong "gan dạ nhất xóm".', 'good'); fx(l, { hap: 3 }); H.mem(l, 'Đêm một mình ra cây đa đầu làng.', 2); } } },
      { k: 'home', l: function (l) { return 'Chạy về nhà với ' + mom(l); }, run: function (l, r, log) { log('Chạy về nhà rúc vào lòng người lớn.', 'neutral'); } }
    ]
  });
  CT('chuyen_ma', function (l, a) { return a >= 6 && a <= 12 && isVN(l); }, 99);

  SC('choi_le_hoi', {
    title: function (l) { return isVN(l) ? 'Hội làng' : 'Lễ hội trong vùng'; }, prep: function (l, r) { return { x: 0.003 }; },
    text: function (l) { return (isVN(l) ? 'Làng mở hội: có đu quay, bắn súng nước trúng thưởng, kẹo kéo, tò he.' : 'Lễ hội cuối năm có vòng quay, trò chơi trúng thưởng, kẹo bông.') + ' Trong túi bạn có ít tiền ' + (isVN(l) ? 'mừng tuổi' : 'tiêu vặt') + '.'; },
    opts: [
      { k: 'game', l: 'Chơi trò trúng thưởng', run: function (l, r, log, d) { cashB(l, -d.x, 'Chơi hội'); log(ch(r, 0.2) ? 'Trúng một con gấu bông to, ôm về khoe cả xóm!' : 'Tiêu hết tiền mà không trúng gì. Bài học đầu đời về "trò may rủi".', 'neutral'); fx(l, { hap: 2 }); } },
      { k: 'eat', l: 'Mua đồ ăn vặt, tò he', run: function (l, r, log, d) { cashB(l, -d.x, 'Đồ ăn hội làng'); log('Mua tò he hình con gà, kẹo kéo dài cả gang tay.', 'good'); fx(l, { hap: 3 }); } },
      { k: 'save', l: 'Đi xem, giữ tiền lại', run: function (l, r, log) { log('Đi xem một vòng, về nhà còn nguyên tiền.', 'neutral'); fx(l, { kno: 1 }); } }
    ]
  });
  CT('choi_le_hoi', function (l, a) { return a >= 4 && a <= 11; }, 4);

  // quán net: con gái ít được rủ đi net hơn (trừ khi có năng khiếu game)
  E.TRIG.forEach(function (t) {
    if (t.id === 'net_coi') { var p0 = t.p; t.p = function (l, a) { var p = typeof p0 === 'function' ? p0(l, a) : p0; return girl(l) && l.talent !== 'game' ? p * 0.15 : p; }; t.cw = function (l) { return girl(l) && l.talent !== 'game' ? 0.1 : 1; }; }
    if (t.id === 'quay_cop' || t.id === 'bat_nat') t.cw = 0.8;
  });
  E.childhood = { kidLines: kidLines, fresh: fresh };
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
/* ===== js/family.js ===== */
/* Một Đời — v2.7: người yêu / bạn đời có nghề nghiệp & thu nhập (quen lâu mới biết lương), ai trả tiền khi hẹn hò,
   bố mẹ khá giả chu cấp tiền sinh hoạt cho con. */
(function (G) {
  'use strict';
  var U = G.U, E = G.E, H = E.H;
  function pick(r, a) { return U.pick(r, a); }
  function mo(l, v) { return H.money(l, v); }

  // ===================================================================
  // 1. NGHỀ NGHIỆP & THU NHẬP CỦA NGƯỜI YÊU / BẠN ĐỜI
  // ===================================================================
  function partnerJob(l, p, r) {
    if (p.age < 18) { p.job = p.age < 15 ? 'học sinh THCS' : 'học sinh THPT'; p.jobId = null; p.inc = 0; return p; }
    if (p.age < 22 && r() < 0.65) { p.job = 'sinh viên'; p.jobId = null; p.inc = 0; return p; }
    if (p.age >= 62) { p.job = 'đã nghỉ hưu'; p.jobId = null; p.inc = l.base / 12 * (0.2 + r() * 0.3); return p; }
    var cands = Object.keys(E.CAR).map(function (k) { return E.CAR[k]; }).filter(function (c) { return !c.hidden && !c.fame && c.sec !== 'crime' && c.skillRank == null && (c.minAge == null || p.age >= c.minAge) && (p.age >= 24 || c.cat !== 'med') && (p.age >= 22 || (c.edu || 0) <= (p.age >= 20 ? 4 : 3)) && !(c.vnOnly && !H.isVN(l)); });
    var c = U.wpick(r, cands, function (c) { var w = c.w || 1; if (c.sex) w *= p.sex === 'M' ? c.sex[0] : c.sex[1]; if (c.edu >= 5) w *= 1.3; if (c.rural && l.urban) w *= 0.3; return w; });
    var rk = Math.max(0, Math.min(c.t.length - 1, Math.floor((p.age - 22) / 6)));
    p.jobId = c.id; p.job = c.t[rk]; p.rankSince = l.age;
    p.inc = Math.max(0, E.monthlyEst(l, c.id, rk) * Math.exp(U.normal(r) * 0.25));
    return p;
  }
  function incKnown(l, p) { return !!(p && (p.incKnown || p.status === 'married' || p.status === 'cohabit')); }
  H.partnerJob = partnerJob; H.partnerIncKnown = incKnown;

  // người mới quen: hiện cả nghề nghiệp
  var love = E.DEC.love, mk = love.make, ap = love.apply;
  love.make = function (life, r, arg) {
    var d = mk.call(this, life, r, arg), p = d.data.p;
    partnerJob(life, p, r);
    d.text = d.text.replace(/\.$/, '') + ', ' + (p.job === 'sinh viên' ? 'đang là sinh viên' : p.job === 'đã nghỉ hưu' ? 'đã nghỉ hưu' : 'đang làm ' + p.job) + '.';
    return d;
  };
  love.apply = function (life, d, k, r, log) {
    ap.call(this, life, d, k, r, log);
    var p = d.data.p, q = life.partner;
    if (q && q.name === p.name) { q.job = p.job; q.jobId = p.jobId; q.inc = p.inc; q.incKnown = false; }
  };

  function partnerYear(l, r, log, a) {
    var p = l.partner; if (!p || !p.alive) return;
    if (p.job == null) partnerJob(l, p, r);
    // quen đủ lâu mới biết người ấy kiếm bao nhiêu
    if (!p.incKnown && (a - p.since >= 2 || p.status !== 'dating')) {
      p.incKnown = true;
      if (p.inc > 0 && p.status === 'dating') log('Quen nhau lâu, bạn mới biết ' + p.name + ' kiếm khoảng ' + mo(l, p.inc) + '/tháng' + (p.inc > (l.income || 0) / 12 * 2 && l.income > 0 ? ' — gấp mấy lần bạn.' : '.'), 'neutral');
    }
    // sinh viên ra trường đi làm; đi làm lâu thì lên lương; đến tuổi thì nghỉ hưu
    if (p.job === 'sinh viên' && p.age >= 22) { partnerJob(l, p, r); if (p.job !== 'sinh viên') log(p.name + ' ra trường, bắt đầu đi làm ' + p.job + '.', 'neutral'); }
    else if (p.jobId && p.age >= 62 && p.job !== 'đã nghỉ hưu') { p.job = 'đã nghỉ hưu'; p.inc *= 0.5; p.jobId = null; }
    else if (p.jobId && p.inc > 0 && p.age < 55) {
      var c = E.CAR[p.jobId], rk = c ? c.t.indexOf(p.job) : -1;
      if (p.rankSince == null) p.rankSince = a;
      if (c && rk >= 0 && rk < c.t.length - 1 && a - p.rankSince >= Math.max(1, (c.yrs && c.yrs[rk]) || 3) && r() < 0.08) { p.job = c.t[rk + 1]; p.rankSince = a; p.inc = Math.max(p.inc * 1.15, E.monthlyEst(l, c.id, rk + 1)); if (p.incKnown && r() < 0.6) log(p.name + ' được thăng chức lên ' + p.job + '.', 'good'); }
      else p.inc *= 1.01;
    }
  }

  // ===================================================================
  // 2. AI TRẢ TIỀN BUỔI HẸN
  // nữ hẹn hò với nam: phần lớn bạn nam trả · nam: thường tự trả, đôi khi được người yêu "bao" · cùng giới: chia đôi
  // ===================================================================
  H.datePay = function (l, r, cost, why) {
    var p = l.partner, nm = p ? p.name : 'người ấy', richer = p && p.inc > 0 && l.income > 0 && p.inc * 12 > l.income * 1.5;
    if (!p) { H.cash(l, -cost * l.base, why); return ''; }
    if (l.sex === 'F' && p.sex === 'M') {
      if (r() < 0.8) return ' ' + nm + ' giành trả tiền.';
      if (r() < 0.6) { H.cash(l, -cost * l.base / 2, why); return ' Hai người chia đôi tiền.'; }
      H.cash(l, -cost * l.base, why); return ' Lần này bạn mời.';
    }
    if (l.sex === 'M' && p.sex === 'F') {
      if (r() < (richer ? 0.45 : 0.15)) return ' ' + nm + ' nhất quyết trả tiền: "Để em bao anh hôm nay."';
      if (r() < 0.15) { H.cash(l, -cost * l.base / 2, why); return ' Hai người chia đôi tiền.'; }
      H.cash(l, -cost * l.base, why); return '';
    }
    if (richer && r() < 0.5) return ' ' + nm + ' trả tiền.';
    H.cash(l, -cost * l.base / 2, why); return ' Hai người chia đôi tiền.';
  };

  // ===================================================================
  // 3. BỐ MẸ KHÁ GIẢ CHU CẤP TIỀN SINH HOẠT
  // ===================================================================
  function allowanceYear(l, r, log, a) {
    var f = l.fam; if (!f || a < 15 || a > 26) return;
    if (f.elite && l.flags.eliteFollow && !l.flags.eliteCut) return; // đã có khoản chu cấp riêng của gia đình siêu giàu
    if (!(f.mAlive || f.fAlive) || l.jailUntil != null && a < l.jailUntil) return;
    var pm = (f.mAlive ? f.mInc || 0 : 0) + (f.fAlive ? f.fInc || 0 : 0); // thu nhập bố mẹ mỗi tháng
    var share = f.q >= 5 ? 0.12 : f.q === 4 ? 0.06 : f.q === 3 ? 0.02 : 0;
    if (!share) return;
    var studying = !!l.school, working = !!l.job && l.indep;
    // v3.0: còn ở nhà với bố mẹ (chưa xa nhà) thì chỉ là tiền tiêu vặt — ăn ở đã có bố mẹ lo; đi học xa / ra ở riêng mới là tiền sinh hoạt
    var away = !!(l.cityStudent || (l.abroad && l.abroad.study) || l.movedTo || l.indep);
    var k = !away ? (studying ? 0.12 : 0.1) : studying ? 1 : working ? (a <= 23 ? 0.5 : 0.25) : 0.7;
    var amt = pm * 12 * share * k;
    if (amt < l.base * 0.03) return;
    var pw = f.mAlive && f.fAlive ? 'Bố mẹ' : f.mAlive ? 'Mẹ' : 'Bố';
    H.cash(l, amt, away ? 'Bố mẹ chu cấp' : 'Tiền tiêu vặt bố mẹ cho');
    if (!away && !l.flags.pocketNoted) { l.flags.pocketNoted = true; log(pw + ' cho tiền tiêu vặt hằng tháng, khoảng ' + mo(l, amt / 12) + '/tháng — đủ ăn sáng, mua sách vở, thỉnh thoảng đi chơi với bạn.', 'good'); }
    if (away && !l.flags.allowNoted) { l.flags.allowNoted = true; log(pw + ' gửi tiền sinh hoạt đều đặn mỗi tháng' + (l.cityStudent ? ' lên ' + l.cityStudent.city : l.abroad && l.abroad.study ? ' sang ' + l.abroad.name : '') + ', khoảng ' + mo(l, amt / 12) + '/tháng — ' + (studying ? '"con cứ lo học, tiền nong để bố mẹ".' : working ? '"mới đi làm lương còn thấp, bố mẹ đỡ thêm".' : '"trong lúc con chưa tìm được việc, bố mẹ lo cho".'), 'good'); }
  }

  E.HOOKS.year.push(function (l, r, log, a) { partnerYear(l, r, log, a); allowanceYear(l, r, log, a); });
  E.family = { partnerJob: partnerJob, partnerYear: partnerYear, allowanceYear: allowanceYear };
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
/* ===== js/sports.js ===== */
/* Một Đời — v2.9: nghề vận động viên chia theo từng môn: bóng đá, bóng rổ, bóng chuyền, bơi lội, điền kinh, cầu lông, bóng bàn,
   quần vợt, võ thuật, cử tạ, bắn cung, thể dục dụng cụ, đua xe đạp, bi-a, golf — mỗi môn có danh xưng, mức thu nhập,
   tuổi đỉnh cao / giải nghệ và sự kiện riêng (giải câu lạc bộ, AFF Cup, xuất ngoại, kỷ lục, tài trợ…). */
(function (G) {
  'use strict';
  var U = G.U, E = G.E, H = E.H, SC = E.SC, isVN = H.isVN;
  function T(id, when, p, cd) { E.TRIG.push({ id: id, when: when, p: p, cd: cd || 0 }); }
  function fx(l, o) { H.fx(l, o); }
  function cashB(l, x, why) { H.cash(l, x * l.base, why); }
  function mb(l, x) { return H.mb(l, x); }
  function pick(r, a) { return U.pick(r, a); }
  function ch(r, p) { return r() < p; }
  function free(l) { return !(l.jailUntil != null && l.age < l.jailUntil) && !(l.abroad && l.abroad.trapped); }
  function yr(l) { return l.birthYear + l.age; }

  // t: danh xưng 4 bậc (năng khiếu → chuyên nghiệp → đội tuyển quốc gia → đỉnh cao) · pay: hệ số thu nhập theo bậc
  // peak: tuổi đỉnh cao · max: tuổi giải nghệ · team: môn đồng đội · sea/olympic: có thi ở SEA Games / Olympic
  var SPORTS = {
    'bóng đá': { team: 1, t: ['cầu thủ học viện bóng đá', 'cầu thủ hạng Nhất', 'cầu thủ V.League', 'tuyển thủ quốc gia'], pay: [1, 2, 4, 4], peak: 27, max: 35, club: ['Hà Nội FC', 'Công an Hà Nội', 'Thép Xanh Nam Định', 'Hoàng Anh Gia Lai', 'Becamex Bình Dương', 'Hải Phòng', 'Sông Lam Nghệ An', 'Thể Công Viettel'], abroad: ['J-League (Nhật Bản)', 'K-League (Hàn Quốc)', 'Thai League (Thái Lan)', 'một đội hạng Hai Bỉ', 'Liga 1 (Indonesia)'] },
    'bóng rổ': { team: 1, t: ['cầu thủ bóng rổ năng khiếu', 'cầu thủ bóng rổ chuyên nghiệp VBA', 'tuyển thủ bóng rổ quốc gia', 'ngôi sao bóng rổ'], pay: [1, 1.6, 1.8, 1.6], peak: 27, max: 34, club: ['Saigon Heat', 'Hanoi Buffaloes', 'Danang Dragons', 'Thang Long Warriors', 'Cantho Catfish'], abroad: ['giải bóng rổ Nhật Bản B.League', 'giải bóng rổ Philippines PBA'] },
    'bóng chuyền': { team: 1, t: ['vận động viên bóng chuyền trẻ', 'vận động viên bóng chuyền câu lạc bộ', 'tuyển thủ bóng chuyền quốc gia', 'ngôi sao bóng chuyền'], pay: [1, 1.2, 1.2, 1.2], peak: 26, max: 33, club: ['Biên Phòng', 'Thông tin LienVietPostBank', 'Ninh Bình', 'Sanest Khánh Hòa', 'Hóa chất Đức Giang'], abroad: ['giải bóng chuyền Thái Lan', 'giải bóng chuyền Nhật Bản V.League'] },
    'bơi lội': { t: ['vận động viên bơi năng khiếu', 'vận động viên bơi đội tuyển tỉnh', 'kình ngư đội tuyển quốc gia', 'kình ngư số một quốc gia'], pay: [1, 1, 1, 1.1], peak: 22, max: 28 },
    'điền kinh': { t: ['vận động viên điền kinh năng khiếu', 'vận động viên điền kinh đội tuyển tỉnh', 'vận động viên điền kinh quốc gia', 'nữ hoàng / ông hoàng tốc độ'], pay: [1, 1, 1, 1], peak: 25, max: 32 },
    'cầu lông': { t: ['tay vợt cầu lông năng khiếu', 'tay vợt cầu lông đội tuyển tỉnh', 'tay vợt cầu lông quốc gia', 'tay vợt cầu lông hàng đầu châu Á'], pay: [1, 1, 1.1, 1.5], peak: 25, max: 32 },
    'bóng bàn': { t: ['vận động viên bóng bàn năng khiếu', 'vận động viên bóng bàn đội tuyển tỉnh', 'tay vợt bóng bàn quốc gia', 'tay vợt bóng bàn số một'], pay: [1, 1, 1, 1], peak: 26, max: 35 },
    'quần vợt': { t: ['tay vợt quần vợt trẻ', 'tay vợt quần vợt chuyên nghiệp', 'tay vợt quần vợt số một quốc gia', 'tay vợt hệ thống ATP / WTA'], pay: [1, 1.3, 1.5, 3], peak: 26, max: 34 },
    'võ thuật': { t: ['võ sĩ năng khiếu', 'võ sĩ đội tuyển tỉnh', 'võ sĩ đội tuyển quốc gia', 'nhà vô địch võ thuật'], pay: [1, 1, 1, 1.2], peak: 25, max: 33, arts: ['karate', 'taekwondo', 'vovinam', 'pencak silat', 'boxing', 'judo'] },
    'cử tạ': { t: ['lực sĩ cử tạ năng khiếu', 'lực sĩ cử tạ đội tuyển tỉnh', 'lực sĩ cử tạ quốc gia', 'lực sĩ cử tạ hàng đầu thế giới'], pay: [1, 1, 1, 1.2], peak: 25, max: 32 },
    'bắn cung': { t: ['cung thủ năng khiếu', 'cung thủ đội tuyển tỉnh', 'cung thủ quốc gia', 'cung thủ hàng đầu'], pay: [1, 1, 1, 1], peak: 28, max: 42 },
    'thể dục dụng cụ': { t: ['vận động viên thể dục dụng cụ năng khiếu', 'vận động viên thể dục dụng cụ đội tuyển tỉnh', 'vận động viên thể dục dụng cụ quốc gia', 'ngôi sao thể dục dụng cụ'], pay: [1, 1, 1, 1.1], peak: 20, max: 27 },
    'đua xe đạp': { t: ['cua-rơ trẻ', 'cua-rơ câu lạc bộ', 'cua-rơ đội tuyển quốc gia', 'cua-rơ hàng đầu'], pay: [1, 1, 1.1, 1.2], peak: 27, max: 34 },
    'bi-a': { t: ['cơ thủ phong trào', 'cơ thủ chuyên nghiệp', 'cơ thủ đội tuyển quốc gia', 'cơ thủ hàng đầu thế giới'], pay: [1, 1.2, 1.5, 3], peak: 32, max: 48, olympic: false },
    'golf': { t: ['golfer nghiệp dư', 'golfer chuyên nghiệp', 'golfer số một quốc gia', 'golfer thi đấu hệ thống quốc tế'], pay: [1, 1.5, 2, 4], peak: 30, max: 45, sea: true }
  };
  Object.keys(SPORTS).forEach(function (k) { SPORTS[k].n = k; });
  function info(l) { return SPORTS[l.talentSub] || SPORTS['điền kinh']; }
  E.SPORTS = SPORTS;
  E.sportInfo = info;
  E.sportTitle = function (l, rk) {
    var S = info(l), t = S.t[Math.min(rk, 3)];
    if (S.arts && l.job && l.job.art) t += ' (' + l.job.art + ')';
    if (S.team && l.job && l.job.club && rk >= 1) t += ' · ' + l.job.club;
    return t;
  };
  E.sportPay = function (l, rk) { var S = info(l); return (S.pay[Math.min(rk, 3)] || 1) * (l.job && l.job.abroadUntil > l.age ? 2 : 1); };

  function result(l, tier, kind, key) { if (E.recordSportResult) E.recordSportResult(l, tier, kind, key); }

  // ---------- mỗi năm: câu lạc bộ, chuyển nhượng, giải đấu riêng của từng môn ----------
  function sportYear(l, r, log, a) {
    if (!l.job || E.resolveJob(l.job.id) !== 'vdv') return;
    var S = info(l), rk = l.job.rank || 0, y = yr(l);
    if (S.arts && !l.job.art) l.job.art = pick(r, S.arts);
    if (S.team && rk >= 1 && !l.job.club && S.club) { l.job.club = pick(r, S.club); log('Ký hợp đồng chuyên nghiệp với câu lạc bộ ' + l.job.club + '.', 'good'); }
    if (l.job.abroadUntil && a >= l.job.abroadUntil) { l.job.abroadUntil = null; log('Hết hợp đồng thi đấu ở nước ngoài, trở về khoác áo câu lạc bộ trong nước.', 'neutral'); }
    if (S.n === 'bóng đá') {
      if (rk >= 2 && l.job.club && ch(r, 0.1)) { log(l.job.club + ' vô địch V.League! Bạn cùng đồng đội diễu hành trên xe buýt mui trần.', 'big'); cashB(l, 0.3, 'Thưởng vô địch V.League'); result(l, 'national', 'win', 'vleague'); l.fame = (l.fame || 0) + 3e4; H.mem(l, 'Mùa giải vô địch V.League cùng ' + l.job.club + '.', 5); }
      if (rk >= 3 && isVN(l) && y % 2 === 0 && ch(r, 0.3 + (l.skill - 80) / 100)) { log('Đội tuyển Việt Nam vô địch ASEAN Cup ' + y + '! Cả nước xuống đường mừng chiến thắng, bạn được thưởng nóng.', 'big'); cashB(l, 2, 'Thưởng vô địch ASEAN Cup'); l.fame = (l.fame || 0) * 1.5 + 2e5; fx(l, { hap: 12 }); l.medals.push({ ev: 'ASEAN Cup ' + y, m: 'vàng', y: y, career: 'vdv', sport: S.n }); H.mem(l, 'Đêm vô địch ASEAN Cup ' + y + ', biển cờ đỏ sao vàng trên khắp phố.', 8); }
      if (rk >= 3 && y % 4 === 1 && ch(r, 0.05)) { log('Đội tuyển lọt vào vòng loại cuối World Cup — thành tích lịch sử!', 'big'); fx(l, { hap: 8 }); l.fame = (l.fame || 0) + 1e5; }
    }
    if (S.n === 'quần vợt' && rk >= 2 && ch(r, 0.15 + (l.skill - 80) / 100)) { log('Vô địch một giải ATP Challenger, điểm xếp hạng thế giới tăng vọt.', 'big'); cashB(l, 0.6, 'Tiền thưởng giải quần vợt'); result(l, 'regional', 'win', 'challenger'); l.fame = (l.fame || 0) + 5e4; }
    if (S.n === 'bơi lội' && rk >= 2 && ch(r, 0.12 + (l.skill - 80) / 120)) { log('Phá kỷ lục quốc gia nội dung ' + pick(r, ['200 m tự do', '400 m hỗn hợp', '1.500 m tự do', '100 m bướm']) + '.', 'good'); fx(l, { hap: 6 }); result(l, 'national', 'record', 'swim-record'); H.mem(l, 'Nhìn lên bảng điện tử thấy chữ "KỶ LỤC" cạnh tên mình.', 4); }
    if (S.n === 'bi-a' && rk >= 2 && ch(r, 0.12 + (l.skill - 80) / 100)) { log('Vô địch một giải bi-a carom 3 băng World Cup, cả làng bi-a Việt Nam tự hào.', 'big'); cashB(l, 0.8, 'Tiền thưởng giải bi-a'); result(l, 'world', 'win', 'billiards-world-cup'); l.fame = (l.fame || 0) + 8e4; }
    if (S.n === 'golf' && rk >= 1 && ch(r, 0.15)) { log('Về nhất một giải golf chuyên nghiệp, nhận tấm séc tiền thưởng.', 'good'); cashB(l, 0.5, 'Tiền thưởng giải golf'); result(l, 'national', 'win', 'golf-pro'); }
    if (S.n === 'võ thuật' && rk >= 2 && ch(r, 0.15)) { log('Giành đai vô địch ' + (l.job.art || 'võ thuật') + ' châu Á.', 'good'); result(l, 'regional', 'win', 'martial-title'); fx(l, { hap: 6 }); }
    if (rk >= 3 && (l.fame || 0) >= 1e5 && ch(r, 0.2)) { var b = pick(r, ['một hãng đồ uống thể thao', 'một hãng giày', 'một ngân hàng', 'một hãng sữa']); log('Ký hợp đồng quảng cáo với ' + b + '.', 'good'); cashB(l, 1 + (l.fame || 0) / 1e6, 'Hợp đồng quảng cáo'); }
  }

  // ---------- trận đấu lớn ----------
  var BIG = {
    'bóng đá': ['Trận derby căng như dây đàn, đối thủ chơi rắn.', 'Chung kết Cúp Quốc gia, khán đài kín chỗ.', 'Trận cầu sinh tử trụ hạng cuối mùa.'],
    'bóng rổ': ['Trận chung kết VBA, tỉ số bám đuổi đến những giây cuối.'], 'bóng chuyền': ['Trận chung kết giải vô địch quốc gia, set thứ năm giằng co.'],
    'quần vợt': ['Trận bán kết dưới cái nắng 38 độ, đối thủ hạng cao hơn bạn 100 bậc.'], 'võ thuật': ['Trận chung kết gặp nhà vô địch châu Á.'],
    'bi-a': ['Trận chung kết kéo dài đến nửa đêm, chỉ còn một lượt cơ.'], 'golf': ['Lỗ cuối cùng của vòng chung kết, chỉ cần một cú putt.']
  };
  SC('tt_tran_lon', {
    title: 'Trận đấu quan trọng', prep: function (l, r) { var S = info(l); return { t: pick(r, BIG[S.n] || ['Chung kết giải vô địch quốc gia môn ' + S.n + '.']), n: S.n }; },
    valid: function (l) { return !!(l.job && E.resolveJob(l.job.id) === 'vdv' && l.job.rank >= 1); },
    text: function (l, d) { return d.t + (l.injured ? ' Chấn thương cũ vẫn còn âm ỉ.' : ''); },
    opts: [
      { k: 'all', l: 'Thi đấu hết mình', ai: { w: 1.4, amb: 1 }, run: function (l, r, log, d) {
        if (ch(r, 0.12)) { log('Dốc hết sức thì dính chấn thương, phải nghỉ thi đấu mấy tháng.', 'bad'); fx(l, { hea: -10 }); l.skill = Math.max(0, l.skill - 6); return; }
        if (ch(r, 0.4 + (l.skill - 60) / 100)) { log('Chiến thắng! Bạn là nhân tố quyết định của trận đấu.', 'big'); l.fame = (l.fame || 0) + 2e4; fx(l, { hap: 8 }); cashB(l, 0.1, 'Thưởng trận thắng'); result(l, 'national', 'win', 'big-match'); H.mem(l, 'Khoảnh khắc ' + (d.n === 'bóng đá' ? 'ghi bàn quyết định' : 'giành điểm quyết định') + ' giữa tiếng hò reo.', 4); }
        else { log('Thua sát nút. Ngồi lặng trong phòng thay đồ rất lâu.', 'bad'); fx(l, { hap: -5 }); }
      } },
      { k: 'safe', l: 'Thi đấu chừng mực, tránh chấn thương', ai: { w: 0.8, smart: 0.5 }, run: function (l, r, log) { log(ch(r, 0.35) ? 'Thắng nhẹ nhàng nhờ đồng đội tỏa sáng.' : 'Thua trận, bị huấn luyện viên phê bình thiếu quyết tâm.', 'neutral'); } }
    ]
  });
  T('tt_tran_lon', function (l) { return !!(l.job && E.resolveJob(l.job.id) === 'vdv' && l.job.rank >= 1) && free(l); }, 0.3, 1);

  // ---------- lời mời thi đấu ở nước ngoài ----------
  SC('tt_xuat_ngoai', {
    title: 'Lời mời từ nước ngoài', prep: function (l, r) { var S = info(l); return { c: pick(r, S.abroad || ['một câu lạc bộ nước ngoài']), m: U.randint(r, 2, 3) }; },
    valid: function (l) { var S = info(l); return !!(l.job && E.resolveJob(l.job.id) === 'vdv' && S.abroad && l.job.rank >= 2 && !l.job.abroadUntil); },
    text: function (l, d) { return 'Một đội bóng ở ' + d.c + ' muốn mượn bạn ' + d.m + ' năm, lương gấp đôi. Ở đó cạnh tranh suất đá chính rất khốc liệt.'; },
    opts: [
      { k: 'go', l: 'Sang thử thách bản thân', ai: { amb: 1.2, risk: 0.6 }, run: function (l, r, log, d) { l.job.abroadUntil = l.age + d.m; H.visit(l, String(d.c).replace(/.*\((.*)\).*/, '$1')); if (ch(r, 0.45 + (l.skill - 75) / 80)) { log('Sang ' + d.c + ', giành được suất đá chính sau nửa mùa giải. Truyền thông trong nước theo dõi từng trận.', 'big'); l.skill = Math.min(100, l.skill + 6); l.fame = (l.fame || 0) + 1e5; H.mem(l, 'Mùa giải đầu tiên ở ' + d.c + '.', 5); } else { log('Sang ' + d.c + ' nhưng chủ yếu ngồi dự bị. Một bài học lớn.', 'neutral'); fx(l, { hap: -4 }); } } },
      { k: 'stay', l: 'Ở lại câu lạc bộ trong nước', ai: { w: 1 }, run: function (l, r, log) { log('Từ chối lời mời, ở lại làm trụ cột cho câu lạc bộ.', 'neutral'); } }
    ]
  });
  T('tt_xuat_ngoai', function (l) { var S = info(l); return !!(l.job && E.resolveJob(l.job.id) === 'vdv' && S.abroad && l.job.rank >= 2 && l.skill >= 72 && !l.job.abroadUntil) && free(l); }, 0.12, 4);

  E.HOOKS.year.push(sportYear);
  E.sports = { SPORTS: SPORTS, sportYear: sportYear };
})(typeof window !== 'undefined' ? (window.G = window.G || {}) : (globalThis.G = globalThis.G || {}));

;
